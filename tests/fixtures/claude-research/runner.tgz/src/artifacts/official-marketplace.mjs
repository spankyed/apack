import assert from 'node:assert/strict';
import {access,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';

const repository='https://github.com/anthropics/skills.git';
const commit='dbd4588f9e1033efb41dad4bef2f7947c8993d44';
const git=(directory,args)=>execFileSync('/usr/bin/git',['-c','core.hooksPath=/dev/null',...(directory?['-C',directory]:[]),...args],{encoding:'utf8',timeout:60000,maxBuffer:8*1024*1024,env:{...process.env,GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_OPTIONAL_LOCKS:'0',GIT_TERMINAL_PROMPT:'0',GIT_NO_LAZY_FETCH:'1',GIT_LFS_SKIP_SMUDGE:'1'}});

/** Manual acquisition only. No vendor CLI, hooks, plugin code or update scheduler runs here. */
export async function prepareOfficialMarketplaceSnapshot(destination){
 const root=resolve(destination),checkout=join(root,'repository');
 let exists=true;try{await access(root)}catch(error){if(error.code!=='ENOENT')throw error;exists=false}
 if(!exists){
  await mkdir(root,{recursive:true});git(undefined,['init',checkout]);git(checkout,['remote','add','origin',repository]);
  git(checkout,['fetch','--depth=1','origin',commit]);git(checkout,['checkout','--detach',commit]);
 }
 assert.equal(git(checkout,['rev-parse','HEAD']).trim(),commit,'Preserve mismatched snapshots; never overwrite them');
 assert.equal(git(checkout,['remote','get-url','origin']).trim(),repository);
 const objects=git(checkout,['rev-list','--objects','--all','--missing=print']).trim().split('\n');
 assert.ok(objects.length>0&&objects.length<=10000);assert.ok(!objects.some(row=>row.startsWith('?')),'Complete the pinned object closure before offline replay');
 const bytes=await readFile(join(checkout,'.claude-plugin/marketplace.json')),manifest=JSON.parse(bytes);assert.equal(manifest.name,'anthropic-agent-skills');assert.ok(manifest.plugins.some(plugin=>plugin.name==='document-skills'));
 const receipt={repository,commit,lookupDate:new Date().toISOString().slice(0,10),manifestSha256:createHash('sha256').update(bytes).digest('hex'),marketplaceName:manifest.name,plugins:manifest.plugins.map(plugin=>plugin.name),completeGitObjectClosure:true,objectCount:objects.length,scope:'Pinned unmodified official Git objects/metadata for offline original-native registration; no plugin installed or executed.'};
 if(exists){const old=JSON.parse(await readFile(join(root,'provenance.json'),'utf8'));for(const key of ['repository','commit','manifestSha256','marketplaceName','completeGitObjectClosure'])assert.equal(old[key],receipt[key]);return old}
 await writeFile(join(root,'provenance.json'),JSON.stringify(receipt,null,2)+'\n');return receipt;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){assert.equal(process.argv.length,3,'Usage: node src/artifacts/official-marketplace.mjs <new-or-verified-snapshot-directory>');console.log(JSON.stringify(await prepareOfficialMarketplaceSnapshot(process.argv[2]),null,2))}
