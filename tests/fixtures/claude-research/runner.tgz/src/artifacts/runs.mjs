import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { basename, dirname, join, resolve } from 'node:path';

export function hash(bytes) { return createHash('sha256').update(bytes).digest('hex'); }

export async function createRun(output, stage, inputs) {
  const id = `${new Date().toISOString().replaceAll(':', '-')}-${stage}-${randomUUID().slice(0, 8)}`;
  const directory = join(output, 'runs', id);
  await mkdir(directory, { recursive: true });
  const manifest = { schemaVersion: 1, id, stage, inputs, startedAt: new Date().toISOString(),
    host: { platform: process.platform, arch: process.arch, node: process.version }, status: 'running' };
  async function save() {
    await writeFile(join(directory, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  }
  await save();
  return { directory, manifest, async finish(fields) {
    Object.assign(manifest, fields, { finishedAt: new Date().toISOString() });
    await save();
  } };
}

export async function readCompleteRun(directory, stage) {
  const value = JSON.parse(await readFile(join(directory, 'manifest.json'), 'utf8'));
  if (value.schemaVersion !== 1 || value.status !== 'complete' || value.stage !== stage) {
    throw new Error(`Expected a complete ${stage} run: ${directory}`);
  }
  return value;
}


/** Resolve a recorded parent, or a sibling with the same run identity after moving the archive. */
export async function readRecordedRunParent(childDirectory, recordedPath, parentId, stage, targetSha256) {
  if (typeof parentId !== 'string' || !parentId || basename(parentId) !== parentId || parentId === '.' || parentId === '..') {
    throw new Error(`Invalid ${stage} parent run ID`);
  }
  let directory = recordedPath;
  let manifest;
  try {
    manifest = await readCompleteRun(directory, stage);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    directory = join(dirname(resolve(childDirectory)), parentId);
    manifest = await readCompleteRun(directory, stage);
  }
  if (manifest.id !== parentId || manifest.inputs.targetSha256 !== targetSha256) {
    throw new Error(`${stage} parent identity changed`);
  }
  return { directory, manifest };
}
