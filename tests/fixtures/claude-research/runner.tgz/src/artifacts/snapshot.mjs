import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { copyFile, mkdir, mkdtemp, readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import { hostname } from 'node:os';
import { join, resolve } from 'node:path';

async function digestFile(path) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest('hex');
}

async function verify(directory, digest) {
  const manifest = JSON.parse(await readFile(join(directory, 'manifest.json'), 'utf8'));
  const binary = join(directory, 'binary');
  if (manifest.schemaVersion !== 1 || manifest.sha256 !== digest ||
      manifest.size !== (await stat(binary)).size || await digestFile(binary) !== digest) {
    throw new Error(`Snapshot integrity check failed: ${directory}`);
  }
  return manifest;
}

/** Copy and identify bytes without executing the supplied artifact. */
export async function snapshot(input, output) {
  const source = resolve(input);
  if (!(await stat(source)).isFile()) throw new Error(`Expected a file: ${source}`);
  const store = join(resolve(output), 'artifacts', 'sha256');
  await mkdir(store, { recursive: true });
  const temporary = await mkdtemp(join(store, '.snapshot-'));
  try {
    const binary = join(temporary, 'binary');
    await copyFile(source, binary);
    const sha256 = await digestFile(binary);
    const manifest = {
      schemaVersion: 1, sha256, size: (await stat(binary)).size,
      sourcePath: source, capturedAt: new Date().toISOString(),
      host: { platform: process.platform, arch: process.arch, hostname: hostname(), node: process.version },
    };
    await writeFile(join(temporary, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
    const directory = join(store, sha256);
    try {
      await rename(temporary, directory);
    } catch (error) {
      if (!['EEXIST', 'ENOTEMPTY'].includes(error.code)) throw error;
      await verify(directory, sha256);
    }
    return { directory, manifest: await verify(directory, sha256) };
  } finally {
    await rm(temporary, { recursive: true, force: true });
  }
}
