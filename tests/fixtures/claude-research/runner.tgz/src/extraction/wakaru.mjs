import { open, readFile, writeFile } from 'node:fs/promises';
import { isAbsolute, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRun, hash } from '../artifacts/runs.mjs';
import { record } from '../protocol/record.mjs';

/** Validate every recovered file against original byte ranges rather than trusting extractor exit. */
export async function verifyExtraction(binary, directory, manifest) {
  if (!Array.isArray(manifest.files) || manifest.files.length !== manifest.file_count || !manifest.files.length) {
    throw new Error('Missing or inconsistent file inventory');
  }
  const handle = await open(binary, 'r');
  const inventory = [];
  const seen = new Set();
  try {
    const size = (await handle.stat()).size;
    for (const entry of manifest.files) {
      const target = resolve(directory, entry.output_path);
      const path = relative(resolve(directory), target);
      if (!path || path.startsWith('..') || isAbsolute(path) || seen.has(path)) throw new Error('Unsafe or duplicate extracted path');
      seen.add(path);
      const [start, end] = entry.executable_range ?? [];
      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end > size || end - start !== entry.bytes) {
        throw new Error(`Invalid executable range: ${path}`);
      }
      const recovered = await readFile(target);
      const original = Buffer.alloc(end - start);
      const { bytesRead } = await handle.read(original, 0, original.length, start);
      if (bytesRead !== original.length || !original.equals(recovered)) throw new Error(`Byte mismatch: ${path}`);
      inventory.push({ path, loader: entry.loader, encoding: entry.encoding, entry: entry.is_entry, bytes: recovered.length,
        sha256: hash(recovered), executableRange: [start, end] });
    }
    if (!inventory.some(e => e.entry)) throw new Error('No entry point in extracted inventory');
    return inventory;
  } finally { await handle.close(); }
}

export async function extract(binary, output) {
  const resolved = resolve(binary);
  const targetSha256 = hash(await readFile(resolved));
  const root = fileURLToPath(new URL('../../', import.meta.url));
  const tool = join(root, 'node_modules/wakaru/bin/wakaru');
  const metadata = JSON.parse(await readFile(join(root, 'node_modules/wakaru/package.json'), 'utf8'));
  const toolSha256 = hash(await readFile(tool));
  const lockSha256 = hash(await readFile(join(root, 'package-lock.json')));
  const run = await createRun(output, 'extract', { binary: resolved, targetSha256,
    tool: `wakaru@${metadata.version}`, toolSha256, lockSha256 });
  try {
    const directory = join(run.directory, 'extracted');
    const probe = await record({ executable: process.execPath, args: [tool, 'bun', 'extract', resolved,
      '--output', directory, '--include-internals', '--json'], cwd: root, env: { PATH: process.env.PATH, HOME: process.env.HOME },
      output, timeoutMs: 120000, maxBytes: 32 * 1024 * 1024 });
    if (probe.status !== 'complete') throw new Error(`Extractor failed; see ${probe.directory}`);
    const result = JSON.parse(await readFile(join(probe.directory, 'stdout.bin'), 'utf8'));
    const inventory = await verifyExtraction(resolved, directory, result);
    await writeFile(join(run.directory, 'extraction.json'), JSON.stringify(result, null, 2) + '\n');
    await writeFile(join(run.directory, 'inventory.json'), JSON.stringify(inventory, null, 2) + '\n');
    await run.finish({ status: 'complete', probe: probe.directory, files: inventory.length,
      javascriptFiles: inventory.filter(f => ['js', 'jsx', 'ts', 'tsx'].includes(f.loader)).length,
      inventorySha256: hash(await readFile(join(run.directory, 'inventory.json'))) });
    return { directory: run.directory, ...run.manifest };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}

/** A readable derivative keeps its own manifest and source map; extracted bytes remain untouched. */
export async function makeReadable(source, output) {
  const root = fileURLToPath(new URL('../../', import.meta.url));
  const tool = join(root, 'node_modules/wakaru/bin/wakaru');
  const metadata = JSON.parse(await readFile(join(root, 'node_modules/wakaru/package.json'), 'utf8'));
  const run = await createRun(output, 'readable', { source: resolve(source), sourceSha256: hash(await readFile(source)),
    tool: `wakaru@${metadata.version}`, lockSha256: hash(await readFile(join(root, 'package-lock.json'))) });
  try {
    const destination = join(run.directory, 'readable.js');
    const probe = await record({ executable: process.execPath, args: [tool, resolve(source), '--level', 'minimal',
      '--emit-source-map', '--formatter', '--output', destination], cwd: root,
      env: { PATH: process.env.PATH, HOME: process.env.HOME }, output, timeoutMs: 120000 });
    if (probe.status !== 'complete') throw new Error(`Readable transform failed; see ${probe.directory}`);
    await run.finish({ status: 'complete', probe: probe.directory, outputs: {
      'readable.js': hash(await readFile(destination)),
      'readable.js.map': hash(await readFile(`${destination}.map`)),
    } });
    return { directory: run.directory, status: 'complete' };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
