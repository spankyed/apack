# Wakaru extraction and readable transforms

See the implemented modules in this directory, `docs/architecture.md`,
`docs/update-workflow.md`, and `docs/findings/2026-10-15-progress.md` for boundaries and verified scope.
