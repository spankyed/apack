import { probePtyStatusOwner } from './protocol/pty-status-owner.mjs';
import { probePromptEdit } from './protocol/prompt-edit-probe.mjs';
import { compareEnvRuns } from './analysis/env-comparison.mjs';
import { catalogEnvSchema } from './analysis/env-schema.mjs';
import { catalogKeybindings } from './analysis/keybindings.mjs';
import { compareExtractionAssets } from './analysis/asset-comparison.mjs';
import { catalogHtmlAssets } from './analysis/html-assets.mjs';
import { catalogModDeclarations, compareModTypes } from './analysis/mod-declarations.mjs';
import { catalogCodeAssets } from './analysis/code-assets.mjs';
import { probeConversationReset } from './integration/conversation-reset.mjs';
import { probeAppSlashDispatch } from './integration/slash-dispatch.mjs';
import { catalogSlashCommands } from './analysis/slash-commands.mjs';
import { probeAppRetry } from './integration/retry.mjs';
import { probeAppControlExit } from './integration/control-exit.mjs';
import { probeSubagentHandbackCancel } from './protocol/subagent-handback-cancel.mjs';
import { probeSubagentHandback } from './protocol/subagent-handback.mjs';
import { probeAttributionSettings } from './protocol/attribution-settings.mjs';
import { probeStructuredOutputApp } from './integration/structured-output-app.mjs';
import { probeStructuredOutput } from './protocol/structured-output.mjs';
import { catalogToolAccess } from './analysis/tool-access.mjs';
import { probeEffortPreferenceApp } from './integration/effort-preference-app.mjs';
import { probeEffortSettings } from './protocol/effort-settings.mjs';
import { probeModelSettings } from './protocol/model-settings.mjs';
import { probeTaskListApp } from './integration/task-list-app.mjs';
import { probeTaskLifecycle } from './protocol/task-lifecycle.mjs';
import { catalogToolGates } from './analysis/tool-gates.mjs';
import { probeNativeUsage } from './protocol/native-usage.mjs';
import { probeDelegatedControls } from './protocol/delegated-controls.mjs';
import { probeLiveThinking } from './protocol/live-thinking.mjs';
import { catalogRequestDispatch } from './analysis/request-dispatch.mjs';
import { probeModelCatalog } from './protocol/model-catalog.mjs';
import { probeWorkflowStop } from './protocol/workflow-stop.mjs';
import { probeWorkflowApp } from './integration/workflow-app.mjs';
import { probeWorkflow } from './protocol/workflow.mjs';
import { catalogDialogAccess } from './analysis/dialog-access.mjs';
import { probeMetadataLifecycleApp } from './integration/metadata-lifecycle.mjs';
import { probeAppLiveModel } from './integration/live-model.mjs';
import { probeLiveModel } from './protocol/live-model.mjs';
import { catalogAppControlAccess } from './analysis/app-control-access.mjs';
import { probeMcpCommandOutput } from './protocol/mcp-command-output.mjs';
import { probeHookDiscoveryLifecycle } from './protocol/hook-discovery-lifecycle.mjs';
import { probeHookListing } from './protocol/hook-listing.mjs';
import { probeHookEdit } from './protocol/hook-edit.mjs';
import { probeRefusalResult } from './integration/refusal-result.mjs';
import { probeElicitationLifecycle } from './integration/elicitation-lifecycle.mjs';
import { probeRefusalDialog } from './protocol/refusal-dialog.mjs';
import { probeElicitationApp } from './integration/elicitation-app.mjs';
import { probeMcpElicitation } from './protocol/mcp-elicitation.mjs';
import { catalogUserDialogs } from './analysis/user-dialogs.mjs';
import { probePermissionEnforcementApp } from './integration/permission-enforcement-app.mjs';
import { probePermissionLiveEnforcement } from './protocol/permission-live-enforcement.mjs';
import { probePermissionLiveSettings } from './protocol/permission-live-settings.mjs';
import { probeSettingsDirectories } from './protocol/settings-directories.mjs';
import { probeWorkspaceTrust } from './protocol/workspace-trust.mjs';
import { probePermissionCatalogTrust } from './protocol/permission-catalog-trust.mjs';
import { probePermissionRuleEnforcement } from './protocol/permission-rule-enforcement.mjs';
import { probePermissionRuleEdit } from './protocol/permission-rule-edit.mjs';
import { probeExtensionWriterGuard } from './protocol/extension-writer-guard.mjs';
import { catalogExtensionCommands } from './analysis/extension-commands.mjs';
import { probeMemoryLiveSettings } from './protocol/memory-live-settings.mjs';
import { probeMemoryDiscovery } from './protocol/memory-discovery.mjs';
import { probeSkillManagementApp } from './integration/skill-management-app.mjs';
import { probeSkillEdit } from './protocol/skill-edit.mjs';
import { probeSkillDiscovery } from './protocol/skill-discovery.mjs';
import { probeUiSurface } from './protocol/ui-surface-probe.mjs';
import { probeMod } from './protocol/mod-probe.mjs';
import { catalogModApi } from './analysis/mod-api.mjs';
import { probePlanRead } from './protocol/plan-read-probe.mjs';
import { probePtyPlan } from './protocol/pty-plan.mjs';
import { probePtyOnboarding } from './protocol/pty-onboarding.mjs';
import { probeCommandHelp } from './protocol/command-help-probe.mjs';
import { probeScheduling, probeSchedulingResume } from './protocol/scheduling-probe.mjs';
import { catalogToolRegistries } from './analysis/tool-registries.mjs';
import { probeFileRewind } from './protocol/file-rewind-probe.mjs';
import { probeSessionFork } from './protocol/session-fork-probe.mjs';
import { probeSettingsPrecedence } from './protocol/settings-precedence.mjs';
import { probeConfiguredHookValidation } from './protocol/configured-hook-validation.mjs';
import { catalogConfiguredHooks } from './analysis/configured-hooks.mjs';
import { catalogSettingsSchema } from './analysis/settings-schema.mjs';
import { catalogToolDefinitions } from './analysis/tool-definitions.mjs';
import { catalogControlHandlerMaps } from './analysis/control-handler-maps.mjs';
import { probeSessionRename } from './protocol/session-rename-probe.mjs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { catalogMessageSchemas, compareMessageSchemas } from './analysis/message-schemas.mjs';
import { snapshot } from './artifacts/snapshot.mjs';
import { catalogProtocolSchemas, compareProtocolSchemas } from './analysis/protocol-schemas.mjs';
import { compareCliCoverage } from './analysis/cli-coverage.mjs';
import { catalogExtraction, compareCatalogs } from './analysis/catalog.mjs';
import { extract, makeReadable } from './extraction/wakaru.mjs';
import {compareCommandRuns} from './analysis/command-comparison.mjs';
import { indexExtraction, compareIndexes } from './analysis/index.mjs';
import { probePtyStartup } from './protocol/pty-startup.mjs';
import { record } from './protocol/record.mjs';
import { probeSyntheticTool } from './protocol/synthetic-tool-probe.mjs';
import { probeControls } from './protocol/control-probe.mjs';
import { probeApackControls } from './integration/run-apack-controls.mjs';

const usage = `Usage: npm run research -- <command> [arguments]
  apack-refusal-result <checkout> <executable> <workspace>   native refusal error semantics through query and owner
  apack-elicitation-lifecycle <checkout> <executable> <workspace>   native form/URL interrupt and exit through the process owner
  apack-elicitation <checkout> <executable> <workspace>   compiled app MCP URL/form choices and form validation retry
  apack-metadata-lifecycle <checkout> <executable> <workspace>   source metadata commands and actual native session-hook startup
  apack-retry <checkout> <executable> <workspace> [recover|exhaust|interrupt]   native local 429 retry and cancellation
  apack-control-exit <checkout> <executable> <workspace>   actual native death while a host control awaits local validation
  compare-mod-types <before-code-assets> <after-code-assets>   compare normalized shipped declaration syntax
  mod-declarations <code-assets-run> <mod-api-run>   compare shipped declarations with runtime candidates
  html-assets <code-assets-run>   inspect embedded HTML scripts without browser execution
  compare-assets <before-extraction> <after-extraction>   compare all non-JS embedded asset bytes
  code-assets <extraction-run>   supplementary static catalog of code-shaped non-JS assets
  apack-conversation-reset <checkout> <executable> <workspace> [raw|owner|compiled]   native clear/reset identity and follow-up contract
  apack-slash-dispatch <checkout> <executable> <workspace>   selected native slash commands through the retained app owner
  apack-live-model <checkout> <executable> <workspace>   actual app query/owner native model switching
  live-model <executable> <workspace>   native model change/refusal/default across local turns
  slash-commands <extraction-run>   native slash definition candidates and mode/gate fields
  app-control-access <protocol-run> <isolated-checkout>   compare declared native controls with reviewed app call sites
  mcp-command-output <executable> <workspace>   private native MCP list/get output and health activation
  hook-discovery-lifecycle <executable> <workspace>   lifecycle activation during no-prompt native discovery
  hook-listing <executable> <workspace>   native populated hook catalog and masked edit targets
  hook-edit <executable> <workspace>   private native hook add/replace/remove contract
  refusal-dialog <executable> <workspace>   local refusal with declared/undeclared dialog capability
  mcp-elicitation <executable> <workspace>   local MCP form elicitation and host actions
  apack-effort-preference <checkout> <executable> <workspace>   actual native saved effort/readback and retained/fresh behavior
  apack-task-deletion <checkout> <executable> <workspace>   actual native deletion receipt and observation command
  apack-task-list <checkout> <executable> <workspace>   actual native task owner/source consumer/command
  apack-workflow <checkout> <executable> <workspace> [completed|failed|stopped]   actual native Workflow approval and original source-consumer row
  live-thinking <executable> <workspace> [adaptive|budgeted|partial-refusal|null-budget]   idle thinking mutations and outgoing local API fields
  apack-structured-chat-compiled <checkout> <executable> <workspace> [valid|repair|exhaust|queued]   compiled flow/action native acceptance
  apack-structured-chat <checkout> <executable> <workspace> [valid|repair|exhaust|queued]   actual Chat action schema forwarding
  apack-structured-output <checkout> <executable> <workspace> [valid|repair|exhaust]   native owner and source presentation
  subagent-handback-cancel <executable> <workspace>   original caller cancellation with a held foreground child
  subagent-handback <executable> <workspace> [child-auto|auto-hook|auto-continue|auto-duplicate|auto-nested|auto-blocked|auto-refused]   private native child report availability and delivery
  attribution-settings <executable> <workspace>   native attribution settings normalization without a model turn
  structured-output <executable> <workspace> [repair|exhaust]   native JSON schema result and validation
  tool-access <definitions-run> <assembly-run>   lexical access for named candidates outside central assembly
  task-deletion <executable> <workspace>    private native task deletion and missing update
  task-lifecycle <executable> <workspace>   fixed private native task CRUD
  effort-settings <executable> <workspace>   private native effort writer/readback semantics
  model-settings <executable> <workspace>   private parsed per-model effort settings
  native-usage <executable> <workspace> [empty|turn]   private no-account usage and cost shapes
  delegated-controls <executable> <workspace>   safe internal candidate refusals/no-op receipt
  model-catalog <executable> <workspace>   native model catalog before/after known-alias selection
  workflow-stop <executable> <workspace>   native Workflow stop receipts, terminal state and same-session follow-up
  workflow <executable> <workspace>   fixed native Workflow script and permission/task observations
  dialog-access <extraction-run> <dialog-run>   static descriptor aliases and producer/display reference candidates
  user-dialogs <extraction-run>   descriptor-shaped native user-dialog catalog
  command-help <executable> <workspace>   isolated nested namespace help and fallback classification
  scheduling-wakeup-fire <executable> <workspace>   native dynamic-loop timed delivery and stop
  scheduling-wakeup <executable> <workspace>   native dynamic-loop wakeup clamp and cancellation
  scheduling-fire <executable> <workspace>   bounded native one-shot timed firing
  scheduling <executable> <workspace>   native session-only cron create/list/delete
  scheduling-resume <executable> <workspace>   native cron restoration and deletion across resume
  file-rewind <executable> <workspace>   native file checkpoint preview and restoration
  apack-file-rewind <isolated-checkout> <executable> <workspace>   native rewind service verification
  session-compact-fork <executable> <workspace>   compaction and old/current boundary fork checks
  session-fork <executable> <workspace>   synthetic persisted fork-at-message verification
  prompt-edit-virtual <executable> <workspace>   check native zero-width prompt hint export
  prompt-edit <executable> <workspace>   native composer edit rewrites and programmatic adoption
  ui-surface-press <executable> <workspace>   native plugin button interaction
  ui-surface-plugin <executable> <workspace>   native plugin render tree and attribution
  ui-surface <executable> <workspace>   structured UI attach/render/detach without a model turn
  mod-question <executable> <workspace>   native plugin ui.ask over stdio
  mod-ui-limits <executable> <workspace>   native headless view and unmanaged identity refusals
  mod-probe <executable> <workspace>   explicit private local mod; no gate overrides
  mod-api <extraction-run>   native mods operation/event registries and dispatch roots
  settings-precedence <executable> <private-workspace>   inert native settings source markers
  apack-skill-once-app <isolated-checkout> <executable> <workspace>   native skill/file once lifecycle across app turns
  apack-configured-hooks-app <isolated-checkout> <executable> <workspace>   native configured exec/HTTP hooks through app
  apack-permission-enforcement <checkout> <executable> <workspace>   actual tool enforcement after compiled permission edits
  apack-skill-management-retained <checkout> <executable> <workspace>   compiled Skill edits in one native conversation
  apack-skill-management <checkout> <executable> <workspace>   compiled app Skill commands, no model input
  memory-live-settings <executable> <workspace>   immediate retained memory views after native writes
  permission-rule-enforcement <executable> <workspace>   fixed local tool under native allow/deny/ask rules
  permission-live-refresh-enforcement <executable> <workspace>   empty flag patch after durable permission writes
  permission-live-flag-enforcement <executable> <workspace>   explicit flag permission changes across retained inputs
  permission-live-enforcement <executable> <workspace>   retained native tool enforcement after durable writes
  permission-live-settings <executable> <workspace>   retained native permission catalog after durable writes
  settings-directories <executable> <workspace>   root/subfolder settings and instruction startup reads
  workspace-trust <executable> <workspace>   private repository/worktree trust scope and restart checks
  permission-catalog-trust <executable> <workspace>   private trust-gated native permission catalog
  permission-rule-edit <executable> <workspace>   private native durable permission rule mutations
  extension-writer-guard <executable> <workspace>   private native child-session writer refusals
  extension-commands <extraction-run>   hidden action registrations, imports and stdin arguments
  memory-discovery <executable> <workspace>   private native instruction metadata and memory-setting persistence
  skill-edit-refresh <executable> <workspace>   native writer plus retained-process refresh
  skill-edit <executable> <workspace>   native extension-facing Skill writer in a private project
  skill-states <executable> <workspace>   native listing states and rejected generic mutation
  skill-reload <executable> <workspace>   native live add/remove discovery refresh, no model input
  skill-discovery <executable> <workspace>   private native Skill/legacy command metadata, no model input
  configured-hook-validation <executable> <private-workspace>   file-loader versus internal hook types
  configured-hooks <extraction-run>   native configured hook handler declarations
  settings-schema <extraction-run>   core settings declarations and policy table candidates
  tool-registries <tool-definition-run>   native assembly roots and cross-module definition references
  tool-gates <tool-definitions-run>   local predicate facts for every tool candidate
  tool-definitions <extraction-run>   tool-shaped definitions and gate candidates
  compare-env <before-run> <after-run>   typed environment declaration changes
  env-schema <extraction-run>            typed environment getter-table candidates
  keybindings <extraction-run>           terminal binding/action syntax candidates
  request-dispatch <protocol-schema-run>   all-source direct request subtype navigation
  control-handler-maps <protocol-schema-run>   delegated dispatch candidates across recovered modules
  compare-message-schemas <older-message-run> <newer-message-run>
  message-schemas <protocol-schema-run>   static wire inventory; fails on unresolved branches
  snapshot <file> [--output <directory>]
  extract <file> [--output <directory>]
  compare-commands <before-slash-run> <after-slash-run>   command/prompt declaration metadata changes
  index <extraction-run> [--output <directory>]
  cli-coverage <root-help-run> <apack-args-source> [--output <directory>]
  compare-protocol-schemas <older-protocol-run> <newer-protocol-run> [--output <directory>]
  protocol-schemas <catalog-run> [--output <directory>]
  catalog <extraction-run> [--output <directory>]
  compare-catalogs <before-catalog> <after-catalog> [--output <directory>]
  readable <extracted-source-file> [--output <directory>]
  compare <before-index-run> <after-index-run> [--output <directory>]
  probe <executable> <cwd> -- <arguments...>
  plan-read <executable> <workspace>   populated structured plan while approval is pending
  pty-plan-clear <executable> <workspace>   native populated plan clear-context continuation
  pty-plan <executable> <workspace>   isolated populated plan and approval-dialog observation
  pty-onboarding <executable> <workspace>   recognized onboarding and own-workspace trust; no model prompt
  pty-terminal-approvals <executable> <workspace>   same-terminal delegated native ask allow/deny
  pty-native-thinking <executable> <workspace>   ordinary thinking does not invoke native summary hooks
  pty-native-narration <executable> <workspace>   actual terminal summary producer and native UUID proof
  pty-terminal-bridge <executable> <workspace>   native terminal draft read/fill through a private plugin bridge
  pty-status-inspector <executable> <workspace>   check private Bun inspector during a terminal conversation
  pty-native-status-export <executable> <workspace>   owned terminal status stdout export
  pty-status-owner <executable> <workspace>   same-terminal native status and two conversation turns
  pty-startup <executable> <workspace>   isolated terminal startup only; no prompt
  synthetic-cancel-queued <executable> <workspace>   cancel one queued input without interrupting
  synthetic-interrupt-queue <executable> <workspace>   cancel queued input and pending permission
  synthetic-interrupt-resume <executable> <workspace>   continue same process after interrupt
  synthetic-interrupt <executable> <workspace>   cancel pending permission using local fixture API
  synthetic-background-close <executable> <workspace>   observe background work when stdin closes at first result
  synthetic-background <executable> <workspace>   native background completion after a turn
  synthetic-mcp <executable> <workspace>   local stdio MCP echo through native tool permission
  synthetic-hook-deny <executable> <workspace>   native hook denies tool before permission
  synthetic-hook <executable> <workspace>   native PreToolUse callback via local API
  synthetic-session-rename <executable> <workspace>   persist a native title in a disposable synthetic session
  synthetic-search-plan <executable> <workspace>   native plan approval with explicit tool search enabled
  synthetic-plan <executable> <workspace>   native ExitPlanMode approval via local API
  synthetic-question <executable> <workspace>   native AskUserQuestion via local synthetic API
  synthetic-context <executable> <workspace>   populated native memory/skill context via local API
  synthetic-tools-full <executable> <workspace>   isolated non-bare tool catalog/permissions
  synthetic-tools <executable> <workspace>   local synthetic API, allow/deny tools, no real model
  controls <executable> <cwd>   read-only controls, isolated bare mode, no model prompts
  apack-resume-target <isolated-checkout> <executable> <workspace>   native compacted-history validation service
  apack-app-owner <isolated-checkout> <executable> <workspace>   compiled app flow with native question, scheduling and follow-up
  apack-agent-stop <isolated-checkout> <executable> <workspace>   stop a native background Agent
  apack-agent-exit <isolated-checkout> <executable> <workspace>   process exit while a native Agent is active
  apack-agent-overlap <isolated-checkout> <executable> <workspace>   input while a native Agent remains active
  apack-agent-multi-permission <isolated-checkout> <executable> <workspace>   simultaneous native child requests and reverse replies
  apack-agent-multi-permission-app <isolated-checkout> <executable> <workspace>   app approval queue across concurrent workers
  apack-agent-permission-app <isolated-checkout> <executable> <workspace>   compiled app child allow/deny routes
  apack-agent-permission-deny <isolated-checkout> <executable> <workspace>   native child denial without process termination
  apack-agent-permission <isolated-checkout> <executable> <workspace>   child permission after launching input completes
  apack-agent-app-owner <isolated-checkout> <executable> <workspace>   native Agent lifecycle through the compiled app flow
  apack-agent-owner <isolated-checkout> <executable> <workspace>   native Agent lifecycle through the persistent owner
  apack-terminal-owner <isolated-checkout> <executable> <workspace>   native product source terminal handoff/status
  apack-subagent-status <isolated-checkout> <executable> <workspace>   native local-agent status command lifecycle
  apack-status-line <isolated-checkout> <executable> <workspace>   compare native terminal and streaming status commands
  apack-question-forms-app <isolated-checkout> <executable> <workspace>   mounted custom and multi-select questions
  apack-question-wizard-app <isolated-checkout> <executable> <workspace>   mounted question wizard and Cancel verification
  apack-question-app <isolated-checkout> <executable> <workspace>   mounted native question verification
  apack-ui-app <isolated-checkout> <executable> <workspace>   native composer Electron verification
  apack-thinking-cycles-app <isolated-checkout> <executable> <workspace>   actual app thinking/tool cycles
  apack-terminal-question-render-owner <isolated-checkout> <executable> <workspace> guarded native question rewrite replies
  apack-terminal-question-render <isolated-checkout> <executable> <workspace> native question render-hook rewrite/callback
  apack-terminal-question-owner <isolated-checkout> <executable> <workspace> native-owned question reply/refusal/replay
  apack-terminal-question-contract <isolated-checkout> <executable> <workspace> original native question request/reply
  apack-terminal-ui-owner <isolated-checkout> <executable> <workspace> native desktop UI under interactive owner
  apack-composer-app <isolated-checkout> <executable> <workspace>   actual composer, Code, panes and scroll acceptance
  apack-ui-messages <isolated-checkout> <executable> <workspace>   native text-block identities and message render callbacks
  apack-ui-panes <isolated-checkout> <executable> <workspace>   native panes and scroll contracts without model requests
  apack-ui-mount <isolated-checkout> <executable> <workspace>   native mounted-view callbacks and lifecycle
  apack-owner-cron <isolated-checkout> <executable> <workspace>   autonomous scheduled native turn in persistent owner
  apack-owner <isolated-checkout> <executable> <workspace>   persistent native process owner and idle UI
  apack-multi-turn <isolated-checkout> <executable> <workspace>   consecutive host inputs in one native process
  apack-ui-surface <isolated-checkout> <executable> <workspace>   native UI controls and callback lifecycle
  apack-question-exit <isolated-checkout> <executable> <workspace>   pending native question process death
  apack-pending-exit <isolated-checkout> <executable> <workspace>   native exit during pending permission
  apack-tool-availability <isolated-checkout> <executable> <workspace>   native coordinator tool-pool comparison
  apack-scheduling <isolated-checkout> <executable> <workspace>   live scheduling stream and pending-task classification
  apack-background <isolated-checkout> <executable> <workspace>   native background result snapshot integration
  apack-mcp <isolated-checkout> <executable> <workspace>   connected local MCP status/tool integration
  apack-tool-search <isolated-checkout> <executable> <workspace>   deferred plan-tool discovery integration
  apack-rename <isolated-checkout> <executable> <workspace>   persisted native rename integration
  apack-agents <isolated-checkout> <executable> <workspace>   no-model native session-list integration
  apack-hook <isolated-checkout> <executable> <workspace>   native initialized hook callback integration
  apack-interrupt <isolated-checkout> <executable> <workspace>   synthetic interrupt/continuation integration
  apack-launch <isolated-checkout> <executable> <workspace>   no-model settings/policy launch checks
  apack-resume <isolated-checkout> <executable> <workspace>   synthetic persisted session/context integration
  apack-synthetic <isolated-checkout> <executable> <workspace>   synthetic permission/context integration
  apack-plan <isolated-checkout> <executable> <workspace>   live and saved native plan integration
  apack-controls <isolated-checkout> <executable> <workspace>   no-model integration probe
All outputs default to this repository's ignored output/. The probe command sends no stdin; synthetic commands use only a local fixture API.`;
const args = process.argv.slice(2);
const defaultOutput = fileURLToPath(new URL('../output/', import.meta.url));
try {
  const command = args.shift();
  if (!command || ['help', '--help', '-h'].includes(command)) console.log(usage);
  else {
    let result;
    if (command === 'prompt-edit' || command === 'prompt-edit-virtual') {
      if (args.length !== 2) throw new Error('Expected executable and private workspace');
      result = await probePromptEdit(resolve(args[0]), resolve(args[1]), defaultOutput, {virtualText:command==='prompt-edit-virtual'});
    } else if (['ui-surface','ui-surface-plugin','ui-surface-press'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probeUiSurface(resolve(args[0]), resolve(args[1]), defaultOutput, {pluginRender:command!=='ui-surface',interaction:command==='ui-surface-press'});
    } else if (['mod-probe', 'mod-question', 'mod-ui-limits'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probeMod(resolve(args[0]), resolve(args[1]), defaultOutput, command === 'mod-question' ? 'question' : command === 'mod-ui-limits' ? 'ui-limits' : 'filesystem');
    } else if (command === 'mod-api') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogModApi(resolve(args[0]), defaultOutput);
    } else if (command === 'plan-read') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePlanRead(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (['pty-plan','pty-plan-clear'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probePtyPlan(resolve(args[0]), resolve(args[1]), defaultOutput, {clearContext:command==='pty-plan-clear'});
    } else if (command === 'pty-onboarding') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePtyOnboarding(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'command-help') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeCommandHelp(args[0], args[1], defaultOutput);
    } else if (['scheduling', 'scheduling-resume', 'scheduling-fire', 'scheduling-wakeup', 'scheduling-wakeup-fire'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = command === 'scheduling-resume' ? await probeSchedulingResume(resolve(args[0]), resolve(args[1]), defaultOutput)
        : await probeScheduling(resolve(args[0]), resolve(args[1]), defaultOutput, command === 'scheduling-fire' ? {mode:'CronFire'} : command === 'scheduling-wakeup' ? {mode:'WakeupLifecycle'} : command === 'scheduling-wakeup-fire' ? {mode:'WakeupFire'} : {});
    } else if (command === 'tool-registries') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogToolRegistries(resolve(args[0]), defaultOutput);
    } else if (command === 'file-rewind') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeFileRewind(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (['session-fork', 'session-compact-fork'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSessionFork(resolve(args[0]), resolve(args[1]), defaultOutput, { compact: command === 'session-compact-fork' });
    } else if (command === 'settings-precedence') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSettingsPrecedence(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'apack-permission-enforcement') {
      if (args.length !== 3) throw new Error(usage);
      result = await probePermissionEnforcementApp(resolve(args[0]), resolve(args[1]), resolve(args[2]), defaultOutput);
    } else if (['apack-skill-management','apack-skill-management-retained'].includes(command)) {
      if (args.length !== 3) throw new Error(usage);
      result = await probeSkillManagementApp(resolve(args[0]), resolve(args[1]), resolve(args[2]), defaultOutput, {retained:command==='apack-skill-management-retained'});
    } else if (command === 'memory-live-settings') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeMemoryLiveSettings(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'permission-rule-enforcement') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePermissionRuleEnforcement(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'apack-refusal-result') {
      if (args.length !== 3) throw new Error(usage);
      result = await probeRefusalResult(...args.map(p => resolve(p)), defaultOutput);
    } else if (command === 'apack-elicitation-lifecycle') {
      if (args.length !== 3) throw new Error(usage);
      result = await probeElicitationLifecycle(...args.map(p => resolve(p)), defaultOutput);
    } else if (command === 'apack-elicitation') {
      if (args.length !== 3) throw new Error(usage);
      result = await probeElicitationApp(resolve(args[0]), resolve(args[1]), resolve(args[2]), defaultOutput);
    } else if (command === 'apack-metadata-lifecycle') {
      if (args.length !== 3) throw new Error(usage);
      result = await probeMetadataLifecycleApp(resolve(args[0]), resolve(args[1]), resolve(args[2]), defaultOutput);
    } else if (command === 'apack-retry') {
      if(args.length<3||args.length>4)throw new Error(usage);
      result=await probeAppRetry(...args.slice(0,3).map(p=>resolve(p)),defaultOutput,{mode:args[3]??'recover'});
    } else if (command === 'apack-control-exit') {
      if(args.length!==3)throw new Error(usage);
      result=await probeAppControlExit(...args.map(p=>resolve(p)),defaultOutput);
    } else if (command === 'compare-mod-types') {
      if(args.length!==2)throw new Error('Expected two code-assets runs');
      result=await compareModTypes(resolve(args[0]),resolve(args[1]),defaultOutput);
    } else if (command === 'mod-declarations') {
      if(args.length!==2)throw new Error('Expected code-assets and mod-api runs');
      result=await catalogModDeclarations(resolve(args[0]),resolve(args[1]),defaultOutput);
    } else if (command === 'html-assets') {
      if(args.length!==1)throw new Error('Expected code-assets run');
      result=await catalogHtmlAssets(resolve(args[0]),defaultOutput);
    } else if (command === 'compare-assets') {
      if(args.length!==2)throw new Error('Expected two extraction runs');
      result=await compareExtractionAssets(resolve(args[0]),resolve(args[1]),defaultOutput);
    } else if (command === 'code-assets') {
      if(args.length!==1)throw new Error(usage);
      result=await catalogCodeAssets(resolve(args[0]),defaultOutput);
    } else if (command === 'apack-conversation-reset') {
      if(args.length<3||args.length>4)throw new Error(usage);
      result=await probeConversationReset(...args.slice(0,3).map(p=>resolve(p)),defaultOutput,{mode:args[3]??'raw'});
    } else if (command === 'apack-slash-dispatch') {
      if(args.length!==3)throw new Error(usage);
      result=await probeAppSlashDispatch(...args.map(p=>resolve(p)),defaultOutput);
    } else if (command === 'apack-live-model') {
      if (args.length !== 3) throw new Error(usage);
      result = await probeAppLiveModel(resolve(args[0]), resolve(args[1]), resolve(args[2]), defaultOutput);
    } else if (command === 'live-model') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeLiveModel(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'app-control-access') {
      if (args.length !== 2) throw new Error(usage);
      result = await catalogAppControlAccess(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'mcp-command-output') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeMcpCommandOutput(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'hook-discovery-lifecycle') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeHookDiscoveryLifecycle(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'hook-listing') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeHookListing(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'hook-edit') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeHookEdit(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'refusal-dialog') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeRefusalDialog(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'mcp-elicitation') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeMcpElicitation(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'apack-effort-preference') {
      if (args.length !== 3) throw new Error(usage);
      result = await probeEffortPreferenceApp(resolve(args[0]), resolve(args[1]), resolve(args[2]), defaultOutput);
    } else if (command === 'apack-task-list' || command === 'apack-task-deletion') {
      if (args.length !== 3) throw new Error(usage);
      result = await probeTaskListApp(resolve(args[0]), resolve(args[1]), resolve(args[2]), defaultOutput, {deletion:command === 'apack-task-deletion'});
    } else if (command === 'apack-workflow') {
      if (args.length < 3 || args.length > 4) throw new Error(usage);
      result = await probeWorkflowApp(resolve(args[0]), resolve(args[1]), resolve(args[2]), defaultOutput, args[3] ?? 'completed');
    } else if (command === 'live-thinking') {
      if (args.length < 2 || args.length > 3) throw new Error(usage);
      result = await probeLiveThinking(resolve(args[0]), resolve(args[1]), defaultOutput, args[2] ?? 'adaptive');
    } else if (command === 'apack-structured-output' || command === 'apack-structured-chat' || command === 'apack-structured-chat-compiled') {
      if (args.length < 3 || args.length > 4) throw new Error(usage);
      result = await probeStructuredOutputApp(resolve(args[0]), resolve(args[1]), resolve(args[2]), defaultOutput, {mode:args[3] ?? 'repair',chat:command !== 'apack-structured-output',compiled:command === 'apack-structured-chat-compiled'});
    } else if (command === 'subagent-handback-cancel') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSubagentHandbackCancel(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'subagent-handback') {
      if (args.length < 2 || args.length > 3 || args[2] && !['child-auto','auto-hook','auto-continue','auto-duplicate','auto-nested','auto-blocked','auto-refused'].includes(args[2])) throw new Error(usage);
      result = await probeSubagentHandback(resolve(args[0]), resolve(args[1]), defaultOutput, {profile:args[2] ?? 'default'});
    } else if (command === 'attribution-settings') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeAttributionSettings(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'structured-output') {
      if (args.length < 2 || args.length > 3 || (args[2] && !['repair','exhaust'].includes(args[2]))) throw new Error(usage);
      result = await probeStructuredOutput(resolve(args[0]), resolve(args[1]), defaultOutput, {repair:args[2] === 'repair',exhaust:args[2] === 'exhaust'});
    } else if (command === 'compare-commands') {
      if(args.length!==2)throw new Error(usage);
      result=await compareCommandRuns(resolve(args[0]),resolve(args[1]),defaultOutput);
    } else if (command === 'slash-commands') {
      if(args.length!==1)throw new Error(usage);
      result=await catalogSlashCommands(resolve(args[0]),defaultOutput);
    } else if (command === 'tool-access') {
      if (args.length !== 2) throw new Error(usage);
      result = await catalogToolAccess(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'task-lifecycle' || command === 'task-deletion') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeTaskLifecycle(resolve(args[0]), resolve(args[1]), defaultOutput, {deletion:command === 'task-deletion'});
    } else if (command === 'effort-settings') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeEffortSettings(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'model-settings') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeModelSettings(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'native-usage') {
      if (args.length < 2 || args.length > 3) throw new Error(usage);
      result = await probeNativeUsage(resolve(args[0]), resolve(args[1]), defaultOutput, args[2] ?? 'empty');
    } else if (command === 'delegated-controls') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeDelegatedControls(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'model-catalog') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeModelCatalog(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'workflow-stop') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeWorkflowStop(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'workflow') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeWorkflow(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'dialog-access') {
      if (args.length !== 2) throw new Error(usage);
      result = await catalogDialogAccess(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'user-dialogs') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogUserDialogs(resolve(args[0]), defaultOutput);
    } else if (command === 'permission-live-refresh-enforcement') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePermissionLiveEnforcement(resolve(args[0]), resolve(args[1]), defaultOutput, {applyFlag:true,refreshOnly:true});
    } else if (command === 'permission-live-flag-enforcement') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePermissionLiveEnforcement(resolve(args[0]), resolve(args[1]), defaultOutput, {applyFlag:true});
    } else if (command === 'permission-live-enforcement') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePermissionLiveEnforcement(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'permission-live-settings') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePermissionLiveSettings(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'settings-directories') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSettingsDirectories(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'workspace-trust') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeWorkspaceTrust(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'permission-catalog-trust') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePermissionCatalogTrust(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'permission-rule-edit') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePermissionRuleEdit(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'extension-writer-guard') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeExtensionWriterGuard(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'extension-commands') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogExtensionCommands(resolve(args[0]), defaultOutput);
    } else if (command === 'memory-discovery') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeMemoryDiscovery(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'skill-edit') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSkillEdit(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (['skill-discovery','skill-reload','skill-states','skill-edit-refresh'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSkillDiscovery(resolve(args[0]), resolve(args[1]), defaultOutput, {reload:command==='skill-reload',states:command==='skill-states',editRefresh:command==='skill-edit-refresh'});
    } else if (command === 'configured-hook-validation') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeConfiguredHookValidation(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'configured-hooks') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogConfiguredHooks(resolve(args[0]), defaultOutput);
    } else if (command === 'settings-schema') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogSettingsSchema(resolve(args[0]), defaultOutput);
    } else if (command === 'tool-gates') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogToolGates(resolve(args[0]), defaultOutput);
    } else if (command === 'tool-definitions') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogToolDefinitions(resolve(args[0]), defaultOutput);
    } else if (command === 'compare-env') {
      if (args.length !== 2) throw new Error(usage);
      result = await compareEnvRuns(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'env-schema') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogEnvSchema(resolve(args[0]), defaultOutput);
    } else if (command === 'keybindings') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogKeybindings(resolve(args[0]), defaultOutput);
    } else if (command === 'request-dispatch') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogRequestDispatch(resolve(args[0]), defaultOutput);
    } else if (command === 'control-handler-maps') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogControlHandlerMaps(resolve(args[0]), defaultOutput);
    } else if (command === 'compare-message-schemas') {
      if (args.length !== 2) throw new Error(usage);
      result = await compareMessageSchemas(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'message-schemas') {
      if (args.length !== 1) throw new Error(usage);
      result = await catalogMessageSchemas(resolve(args[0]), defaultOutput);
    } else if (['pty-native-status-export','pty-status-owner','pty-status-inspector','pty-terminal-bridge','pty-terminal-approvals','pty-native-narration','pty-native-thinking'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probePtyStatusOwner(resolve(args[0]), resolve(args[1]), defaultOutput, { mirrorStatus: command === 'pty-native-status-export', thinkingKind: command === 'pty-native-narration' ? 'narration' : command === 'pty-native-thinking' ? 'ordinary' : undefined, bridgePrompt: ['pty-native-status-export','pty-terminal-bridge','pty-terminal-approvals','pty-native-narration','pty-native-thinking'].includes(command), bridgeApprovals: command === 'pty-terminal-approvals', inspectRuntime: command === 'pty-status-inspector' });
    } else if (command === 'pty-startup') {
      if (args.length !== 2) throw new Error(usage);
      result = await probePtyStartup(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (['synthetic-interrupt', 'synthetic-interrupt-resume', 'synthetic-interrupt-queue', 'synthetic-cancel-queued'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSyntheticTool(resolve(args[0]), resolve(args[1]), defaultOutput, command.slice('synthetic-'.length));
    } else if (['synthetic-background', 'synthetic-background-close'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSyntheticTool(resolve(args[0]), resolve(args[1]), defaultOutput, command === 'synthetic-background' ? 'background' : 'background-close', 'full');
    } else if (command === 'synthetic-mcp') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSyntheticTool(resolve(args[0]), resolve(args[1]), defaultOutput, 'mcp-echo', 'full');
    } else if (['synthetic-hook', 'synthetic-hook-deny'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSyntheticTool(resolve(args[0]), resolve(args[1]), defaultOutput, command === 'synthetic-hook' ? 'hook-callback' : 'hook-deny', 'full');
    } else if (command === 'synthetic-session-rename') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSessionRename(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (['synthetic-plan', 'synthetic-search-plan'].includes(command)) {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSyntheticTool(resolve(args[0]), resolve(args[1]), defaultOutput, 'approve-plan', command === 'synthetic-plan' ? 'full' : 'full-search');
    } else if (command === 'synthetic-question') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSyntheticTool(resolve(args[0]), resolve(args[1]), defaultOutput, 'ask-question', 'full');
    } else if (command === 'synthetic-context') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeSyntheticTool(resolve(args[0]), resolve(args[1]), defaultOutput, 'allow', 'full-context');
    } else if (['synthetic-tools', 'synthetic-tools-full'].includes(command)) {
      if(args.length !== 2) throw new Error(usage);
      const runs=[];
      for(const decision of ['allow','deny']) runs.push(await probeSyntheticTool(resolve(args[0]),resolve(args[1]),defaultOutput,decision,command === 'synthetic-tools' ? 'bare' : 'full'));
      result={status:runs.every(run=>run.status==='complete')?'complete':'failed',runs};
    } else if (['apack-terminal-plan-app-question-forms','apack-terminal-plan-app-parent-commands','apack-terminal-parent-lifecycle','apack-terminal-agent-view','apack-terminal-plan-app-task-steering','apack-terminal-plan-app-task-controls','apack-terminal-plan-app-agent-layout','apack-terminal-plan-app-client-fields','apack-terminal-plan-app-client','apack-terminal-plan-app-theme','apack-terminal-plan-edited-adapter','apack-terminal-plan-app-composer-layout','apack-terminal-plan-app-mcp-status','apack-terminal-plan-app-mcp-controls','apack-terminal-plan-app-rename','apack-terminal-plan-app-direct-resume','apack-terminal-plan-app-onboarding-import','apack-terminal-plan-app-import','apack-terminal-plan-app-resume','apack-terminal-plan-app-rewind','apack-terminal-plan-app-revert','apack-terminal-plan-app-fork','apack-terminal-plan-app-reset','apack-terminal-plan-app-clear-accept-edits','apack-terminal-plan-app-accept-edits','apack-terminal-plan-app-auto-enter','apack-terminal-plan-app-keep-auto','apack-terminal-plan-app-enter','apack-terminal-plan-app-keep','apack-terminal-plan-app-clear','apack-terminal-plan-app-deny','apack-terminal-plan-app-cancel','apack-terminal-plan-app-withheld','apack-terminal-plan-app-empty','apack-terminal-plan-app-managed-clear','apack-terminal-plan-managed-adapter','apack-terminal-plan-adapter','apack-terminal-plan-clear-adapter','apack-terminal-plan-enter-adapter','apack-terminal-plan-enter-contract','apack-terminal-plan-contract','apack-terminal-plan-clear-contract','apack-terminal-client-lifetime-app','apack-terminal-file-app','apack-terminal-file-contract','apack-terminal-bash-app','apack-terminal-bash-contract','apack-terminal-managed-transition-app','apack-terminal-managed-transition','apack-terminal-managed-no-helper-app','apack-terminal-managed-disable-hooks-app','apack-terminal-managed-no-helper','apack-terminal-managed-disable-hooks','apack-terminal-managed-app','apack-terminal-managed-snapshot','apack-terminal-managed-owner','apack-terminal-question-html-app','apack-terminal-question-contract','apack-terminal-question-owner','apack-terminal-question-render','apack-terminal-question-render-owner','apack-ui-messages','apack-thinking-cycles-app','apack-composer-app','apack-ui-panes','apack-question-forms-app','apack-question-wizard-app','apack-question-app', 'apack-skill-once-app', 'apack-configured-hooks-app', 'apack-agent-multi-permission-app', 'apack-agent-multi-permission', 'apack-agent-permission-app', 'apack-agent-permission-deny', 'apack-agent-permission', 'apack-agent-stop', 'apack-agent-exit', 'apack-agent-overlap', 'apack-agent-app-owner', 'apack-agent-owner', 'apack-process-status','apack-terminal-ui-owner','apack-terminal-live-main','apack-terminal-owner-app','apack-status-settings','apack-terminal-owner','apack-subagent-status', 'apack-status-line', 'apack-ui-app', 'apack-ui-mount', 'apack-app-owner', 'apack-owner-cron', 'apack-owner', 'apack-multi-turn', 'apack-ui-surface', 'apack-question-exit', 'apack-plan', 'apack-controls', 'apack-synthetic', 'apack-resume', 'apack-launch', 'apack-interrupt', 'apack-hook', 'apack-agents', 'apack-rename', 'apack-tool-search', 'apack-mcp', 'apack-background', 'apack-resume-target', 'apack-file-rewind', 'apack-scheduling', 'apack-tool-availability', 'apack-pending-exit'].includes(command)) {
      if (args.length !== 3) throw new Error(usage);
      result = await probeApackControls(...args.map(p => resolve(p)), defaultOutput, command.slice('apack-'.length));
    } else if (command === 'controls') {
      if (args.length !== 2) throw new Error(usage);
      result = await probeControls(resolve(args[0]), resolve(args[1]), defaultOutput);
    } else if (command === 'probe') {
      const [executable, cwd, separator, ...argv] = args;
      if (!executable || !cwd || separator !== '--') throw new Error(usage);
      result = await record({ executable: resolve(executable), cwd: resolve(cwd), args: argv,
        env: { PATH: process.env.PATH, HOME: cwd, CLAUDE_CONFIG_DIR: resolve(cwd, '.claude'),
          DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' }, output: defaultOutput });
    } else {
      let output = defaultOutput;
      const at = args.indexOf('--output');
      if (at !== -1) {
        if (at !== args.length - 2 || !args[at + 1]) throw new Error(usage);
        output = resolve(args[at + 1]); args.splice(at);
      }
      if (command === 'compare-protocol-schemas' && args.length === 2) result = await compareProtocolSchemas(...args.map(path => resolve(path)), output);
      else if (command === 'cli-coverage' && args.length === 2) result = await compareCliCoverage(...args.map(p => resolve(p)), output);
      else if (command === 'compare-catalogs' && args.length === 2) result = await compareCatalogs(...args.map(p => resolve(p)), output);
      else if (command === 'compare' && args.length === 2) result = await compareIndexes(...args.map(p => resolve(p)), output);
      else if (args.length === 1 && ['snapshot', 'extract', 'index', 'readable', 'catalog', 'protocol-schemas'].includes(command)) {
        result = await ({ snapshot, extract, index: indexExtraction, readable: makeReadable, catalog: catalogExtraction, 'protocol-schemas': catalogProtocolSchemas }[command])(resolve(args[0]), output);
      } else throw new Error(usage);
    }
    console.log(JSON.stringify(result, null, 2));
    if (result.status === 'failed') process.exitCode = 1;
  }
} catch (error) { console.error(error.message); process.exitCode = 1; }
