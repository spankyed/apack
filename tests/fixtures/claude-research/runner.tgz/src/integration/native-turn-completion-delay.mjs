import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {mkdtemp,chmod,lstat,unlink,rmdir} from 'node:fs/promises';
import {join} from 'node:path';
import {randomBytes} from 'node:crypto';

/** Delay one original completion through its public hook API; never fabricate bridge notifications. */
export async function startNativeTurnCompletionDelay({maxHoldMs=10000}={}){
 assert.ok(Number.isInteger(maxHoldMs)&&maxHoldMs>=50&&maxHoldMs<=10000);
 const directory=await mkdtemp('/tmp/cc-turn-completion-');await chmod(directory,0o700);
 const socket=join(directory,'delay.sock'),token=randomBytes(24).toString('hex'),rows=[],connections=new Set();
 let armedSession,held,closed=false,armedOnce=false,requests=0,closing;
 const finish=outcome=>{
  assert.ok(held);const{response,row,timer}=held;held=undefined;clearTimeout(timer);row.outcome=outcome;row.releasedAt=Date.now();response.writeHead(200,{'content-type':'application/json'});response.end(JSON.stringify({outcome}));
 };
 const server=createServer(async(req,res)=>{
  try{
   assert.ok(++requests<=128);assert.equal(req.method,'POST');assert.equal(req.headers['x-completion-delay-token'],token);
   assert.ok(['/completion','/session'].includes(req.url));
   let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;assert.ok(size<=4096);chunks.push(chunk)}
   const body=JSON.parse(Buffer.concat(chunks));assert.match(body.sessionId,/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/);
   const keys=Object.keys(body).sort();
   if(req.url==='/completion'){
    assert.deepEqual(keys,['observedSessionId','phase','reason','sessionId','turnId']);assert.match(body.observedSessionId,/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/);assert.ok(['entered','returned'].includes(body.phase));assert.ok(['answer','aborted','refusal','error'].includes(body.reason));assert.equal(typeof body.turnId,'string');assert.ok(body.turnId.length>0&&body.turnId.length<=256);
   }else assert.deepEqual(keys,['sessionId']);
   const row={...body,route:req.url,receivedAt:Date.now()};rows.push(row);
   if(req.url==='/completion'&&body.phase==='entered'&&body.sessionId===armedSession){
    assert.ok(!held);armedSession=undefined;row.held=true;
    const timer=setTimeout(()=>finish('timeout'),maxHoldMs);held={response:res,row,timer};
    res.once('close',()=>{if(held?.row===row){clearTimeout(timer);held=undefined;row.outcome='peer-closed';row.releasedAt=Date.now()}});return;
   }
   res.writeHead(200,{'content-type':'application/json'});res.end('{}');
  }catch{res.writeHead(400);res.end('{}')}
 });
 server.on('connection',c=>{connections.add(c);c.once('close',()=>connections.delete(c));if(connections.size>16)c.destroy()});
 try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(socket,resolve)});await chmod(socket,0o600)}catch(error){await rmdir(directory).catch(()=>{});throw error}
 const source=`const socket=${JSON.stringify(socket)},token=${JSON.stringify(token)};let observedSession;async function post($,route,body){const response=await $.http.fetch('http://completion-delay'+route,{method:'POST',socketPath:socket,headers:{'content-type':'application/json','x-completion-delay-token':token},body:JSON.stringify(body)});if(!response.ok)throw Error('Owned completion delay refused');}export function register(on){on('turn.complete',async($,e,next)=>{if(e.agentId)return next(e);const body={sessionId:await $.session.id(),turnId:e.turnId,reason:e.reason};await post($,'/completion',{...body,phase:'entered',observedSessionId:body.sessionId});const result=await next(e);await post($,'/completion',{...body,phase:'returned',observedSessionId:await $.session.id()});return result;});on('ui.render',{component:'SessionMode'},async($,e,next)=>{const result=await next(e),sessionId=await $.session.id();if(sessionId!==observedSession){await post($,'/session',{sessionId});observedSession=sessionId;}return result;});}`;
 return{
  source,
  arm(sessionId){assert.ok(!closed&&!held&&!armedOnce);assert.match(sessionId,/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/);armedSession=sessionId;armedOnce=true},
  receipts(){return rows.map(row=>({...row}))},
  release(){assert.ok(!closed&&held);finish('released')},
  close(){return closing??=(async()=>{closed=true;armedSession=undefined;if(held)finish('closed');const stopped=new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()));for(const c of connections)c.destroy();await stopped;try{assert.ok((await lstat(socket)).isSocket());await unlink(socket)}catch(error){if(error.code!=='ENOENT')throw error}await rmdir(directory);return{closed:true,requests,held:false}})()},
 };
}
