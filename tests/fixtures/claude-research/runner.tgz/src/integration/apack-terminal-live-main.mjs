// Exercise native live user-settings reload, preserving ordinary owner acceptance.
process.argv[5]='live-main';
await import('./apack-terminal-owner.mjs');
