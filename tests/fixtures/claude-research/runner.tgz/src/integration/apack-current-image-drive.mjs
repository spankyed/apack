import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {prepareCurrentImageProfile} from './current-image-profile.mjs';
import {processStart,liveOriginals} from './native-process-state.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');

/** Current pinned broker, original Image and one native action in the ordinary composer. */
export async function driveCurrentImageApp({checkout,workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
 const project=join(workspace,'project');await mkdir(project);execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),configPath=join(workspace,'.claude/.claude.json'),settingsPath=join(workspace,'.claude/settings.json'),config=JSON.parse(await readFile(configPath));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({theme:'dark',model:'opus'}));const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath);
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,config,settings:JSON.parse(settingsBefore)}));
 const output=join(workspace,'electron-results');let model,billing,profile;
 try{
  model=await startSyntheticModel(workspace,'TextOnly',{textReply:'The release preview review is complete.',captureMessages:true,maxRequests:8});const tls=await prepareNativeCreditTls(join(workspace,'account-tls'));billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
  const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  profile=await prepareCurrentImageProfile({workspace,env:launchEnv});
  const pressTrace=join(workspace,'ui-press');await mkdir(pressTrace,{mode:0o700});launchEnv.CLAUDE_RESEARCH_UI_PRESS_TRACE=pressTrace;
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-current-image',journeyBudgetMs:150000,journey:args=>imageJourney({...args,model,profile,inspectTerminalImage:env.CLAUDE_RESEARCH_FULL_TERMINAL_IMAGE_VIEW==='1'})});
 }finally{
  await model?.close();await billing?.close();await mkdir(output,{recursive:true});if(model)await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls));if(billing)await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state));
  let remaining;for(let i=0;i<100;i++){remaining=await liveOriginals();if(!remaining.length)break;await new Promise(r=>setTimeout(r,50))}await writeFile(join(output,'writer-retirement.json'),JSON.stringify({retired:remaining.length===0,originalProcessesRemaining:remaining}));assert.equal(remaining.length,0,'Original processes must retire before restoring profile');
  let proof;try{proof=JSON.parse(await readFile(join(output,'current-image.json')))}catch(e){if(e.code!=='ENOENT')throw e}
  if(proof?.sessionId){const root=join(workspace,'.claude/projects'),files=await readdir(root,{recursive:true});assert.ok(files.length<=4096);const paths=files.filter(f=>basename(f)===proof.sessionId+'.jsonl');assert.equal(paths.length,1);await writeFile(join(output,'native-parent-transcript.jsonl'),await readFile(join(root,paths[0])))}
  await profile?.restore();await writeFile(configPath,configBefore);assert.deepEqual(await readFile(configPath),configBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configSha256:sha(configBefore),settingsSha256:sha(settingsBefore)}));
 }
}

async function imageJourney({app,page,output,workspace,project,userDataDir,expect,phase,model,profile,inspectTerminalImage}){
 page.setDefaultTimeout(10000);
 const proof={status:'running',captures:[],layouts:[],scope:'CI-01–CI-04 current broker regular RGBA file preview, one native source update, remount and same-session recovery. No shared-memory/other format or whole-parity claim.'},save=()=>writeFile(join(output,'current-image.json'),JSON.stringify(proof,null,2));
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews}});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await expect(composer).toHaveText('');await composer.pressSequentially(text);await expect(composer).toHaveText(text)},document=()=>composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
 const pixels=()=>page.getByRole('img',{name:'Release cover preview',exact:true}).last().evaluate(e=>({width:e.width,height:e.height,pixels:[...e.getContext('2d').getImageData(0,0,e.width,e.height).data]}));
 const sameOwner=async()=>{const c=await context();assert.equal(c.claude.sessionId,proof.sessionId);assert.equal(c.native.state.nativePid,proof.pid);assert.equal(await processStart(proof.pid),proof.processStart);return c};
 const expected=color=>({width:2,height:2,pixels:Array(4).fill(color).flat()});
 const capture=async(tag,color)=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await page.evaluate(()=>document.fonts.ready);if(color){proof.captureProbe={tag,size,context:await context()};await save();await expect(page.getByRole('img',{name:'Release cover preview',exact:true}).last()).toBeVisible({timeout:15000})}if(color){await page.getByTestId('chat-transcript').hover();await page.mouse.wheel(0,-50);await expect(page.locator('[aria-label="Conversation navigation"]')).toBeVisible()}const targets=[composer,send,...color?[page.getByRole('img',{name:'Release cover preview',exact:true}).last(),page.getByRole('button',{name:'Update release preview',exact:true}).last()]:[]];for(const target of targets)await target.evaluate(e=>e.scrollIntoView({block:'nearest',inline:'nearest',behavior:'instant'}));await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));for(const target of targets)await expect(target).toBeInViewport({ratio:1});if(color)await expect.poll(pixels).toEqual(expected(color));const layout=[];for(const target of targets)layout.push(await target.evaluate(e=>{const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return{x:r.x,y:r.y,width:r.width,height:r.height,reachable:!!hit&&(hit===e||e.contains(hit))}}));proof.layouts.push({tag,size,layout,...color?{image:await pixels()}:{}});const name='current-image-'+tag+'-'+size+'.png';await page.screenshot({path:join(output,name),animations:'disabled'});proof.captures.push(name)}await save()};
 try{
  const producer=JSON.parse(await readFile('/control/producer-pack-inputs.json'));for(const file of ['runtime/fe.js','runtime/index.cjs'])assert.equal(sha(await readFile(join(userDataDir,'apack/packs/default-setup',file))),producer[file]);
  await app.waitForSurface('default-setup/threads');await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');await page.waitForTimeout(700);await app.navigate('default-setup/threads');await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return!!c.currentThread?.id&&c.tabs.every(t=>c.tabsRead.includes(t.id))}),{timeout:15000}).toBe(true);await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'})});
  proof.seed='Review the release cover before publishing.';await replace(proof.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);await section.getByRole('button',{name:'Use native interface',exact:true}).click();const seen=new Set();for(let i=0;i<100;i++){if((await context()).native?.state?.status==='live')break;const stage=recognizeOnboardingPrompt(await section.locator('[data-terminal-text]').innerText().catch(()=>''),project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100)}await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.pid=proof.initial.native.state.nativePid;proof.processStart=await processStart(proof.pid);assert.ok(proof.processStart);await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  proof.previewPrompt='Check the release preview before publishing.';const beforePreview=await sameOwner();await replace(proof.previewPrompt);await send.click();await expect.poll(async()=>{const c=await sameOwner();return c.claude.chatState==='success'&&c.native.state.busy===false&&c.messages.filter(m=>m.sender==='user'&&m.text===proof.previewPrompt&&m.context?.cliUuid).length===1&&c.claude.totalCostUsd>beforePreview.claude.totalCostUsd&&c.claude.totalCostUsd===c.native.state.session.totalCostUsd},{timeout:20000}).toBe(true);proof.previewState=await sameOwner();await save();
  proof.draft='Keep the release notes draft while reviewing the cover.';await replace(proof.draft);proof.retained=await document();await capture('initial',[255,136,0,255]);proof.beforeAction=await sameOwner();const before=model.calls.length;proof.beforeActionModelCalls=before;
  await page.evaluate(()=>{const events=[];const add=row=>{if(events.length<32)events.push(row)};const inspection=window.applicationState.system.inspect(e=>{if(e.type==='@xstate.event'&&e.event?.type==='CLAUDE_UI_PRESS'){const v=e.event;add({kind:'actor-press',threadId:v.threadId,mountId:v.mountId,actionId:v.actionId,hrefPresent:v.href!==undefined})}});const click=e=>{const target=e.target instanceof Element?e.target:null,button=target?.closest('button'),preview=[...document.querySelectorAll('button')].find(b=>b.getAttribute('aria-label')==='Update release preview'),r=preview?.getBoundingClientRect();add({kind:e.type,trusted:e.isTrusted,targetTag:target?.tagName,buttonLabel:button?.getAttribute('aria-label'),defaultPrevented:e.defaultPrevented,x:e.clientX,y:e.clientY,preview:r?{x:r.x,y:r.y,width:r.width,height:r.height}:null})};for(const type of ['pointerdown','pointerup','click'])document.addEventListener(type,click,true);window.__currentImagePressObservation={events,stop:()=>{inspection.unsubscribe();for(const type of ['pointerdown','pointerup','click'])document.removeEventListener(type,click,true)}}});
  await page.getByRole('button',{name:'Update release preview',exact:true}).last().click();await expect.poll(async()=>{try{return JSON.parse(await readFile(join(project,'release-preview-actions.json'))).generation}catch(error){if(error.code==='ENOENT')return;throw error}},{timeout:10000}).toBe(1);await expect.poll(pixels).toEqual(expected([0,136,255,255]));proof.receipt=JSON.parse(await readFile(join(project,'release-preview-actions.json')));proof.afterAction=await sameOwner();assert.equal(model.calls.length,before);assert.deepEqual(proof.afterAction.messages,proof.beforeAction.messages);assert.equal(proof.afterAction.claude.totalCostUsd,proof.beforeAction.claude.totalCostUsd);proof.afterActionDocument=await document();proof.afterActionModelCalls=model.calls.length;assert.deepEqual(proof.afterActionDocument,proof.retained);await capture('updated',[0,136,255,255]);
  proof.returnTransition={previousMountIds:Object.keys((await context()).ui)};await save();
  await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await expect.poll(async()=>(await context()).threadId).toBeUndefined();await expect(page.getByRole('img',{name:'Release cover preview',exact:true})).toHaveCount(0);await page.evaluate(threadId=>window.applicationState.system.get('default-setup/threads').send({type:'OPEN_THREAD_CHAT',threadId}),proof.initial.threadId);await expect(composer).toBeVisible();await expect.poll(async()=>{const c=await context();return Object.entries(c.ui).some(([id,v])=>!proof.returnTransition.previousMountIds.includes(id)&&v.threadId===proof.initial.threadId&&v.state?.status==='live')},{timeout:15000}).toBe(true);proof.afterReturnDocument=await document();assert.deepEqual(proof.afterReturnDocument,proof.retained);proof.returnTransition.restored=await sameOwner();await capture('returned',[0,136,255,255]);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  if(inspectTerminalImage){
   await inspectTerminalViewport({page,section,output,expect,proof,save,sameOwner});
   await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
   await expect(composer).toHaveText(proof.draft);
   assert.deepEqual((await document()).document,proof.retained.document);
   await sameOwner();
   await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  }
  await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processStart(proof.pid),{timeout:15000}).not.toBe(proof.processStart);const back=section.getByRole('button',{name:'Back to conversation',exact:true});if(await back.isVisible())await back.click();await expect(composer).toBeVisible();await expect(composer).toBeEditable();await expect(page.getByRole('img',{name:'Release cover preview',exact:true,includeHidden:true})).toHaveCount(0);proof.afterStop=await context();proof.afterStopDocument=await document();assert.deepEqual(proof.afterStopDocument.document,proof.retained.document);await save();proof.followup='Continue the release review after checking the cover.';await replace(proof.followup);await send.click();await expect.poll(async()=>{const c=await context();return c.claude.chatState==='success'&&c.claude.sessionId===proof.sessionId&&c.messages.filter(m=>m.sender==='user'&&m.text===proof.followup&&m.context?.cliUuid).length===1},{timeout:20000}).toBe(true);await replace('Ready for the next release-review step.');proof.final=await context();proof.files={initial:[...await readFile(profile.picture)],updated:[...await readFile(profile.updatedPicture)]};assert.deepEqual(proof.files.initial,expected([255,136,0,255]).pixels);assert.deepEqual(proof.files.updated,expected([0,136,255,255]).pixels);await capture('recovered');proof.status='complete';phase('current-image-complete');
 }catch(error){proof.error={message:error.message,stack:error.stack};proof.observed=await context().catch(()=>null);await page.screenshot({path:join(output,'current-image-failure.png')}).catch(()=>{});throw error}finally{proof.pressObservation=await page.evaluate(()=>{const observation=window.__currentImagePressObservation;observation?.stop();return observation?.events??[]}).catch(()=>null);await save()}
}

// Exercise the real terminal reader, without setting the broker viewport or writing input to Claude.
async function inspectTerminalViewport({page,section,output,expect,proof,save,sameOwner}){
 const terminal=section.locator('[data-native-terminal]');
 const canvas=terminal.locator('canvas').first();
 const mirror=terminal.locator('[data-terminal-text]');
 const draw=()=>canvas.evaluate(element=>{
  const width=element.width,height=element.height;
  if(!width||!height)return null;
  const context=element.getContext('2d');
  if(!context)return null;
  const bounds=element.getBoundingClientRect(),scaleX=bounds.width/width,scaleY=bounds.height/height;
  if(!scaleX||!scaleY)return null;
  const pixels=context.getImageData(0,0,width,height).data;
  // Require a solid 16×16 CSS pixel interior. The original tile is 30×30 at the standard font size.
  const run=Math.ceil(16/scaleX),rows=Math.ceil(16/scaleY);
  const blue=(x,y)=>{const i=(y*width+x)*4;return pixels[i]===0&&pixels[i+1]===136&&pixels[i+2]===255&&pixels[i+3]===255};
  for(let y=0;y+rows<=height;y++)for(let x=0;x+run<=width;x++){
   if(!blue(x,y)||!blue(x+run-1,y)||!blue(x,y+rows-1)||!blue(x+run-1,y+rows-1))continue;
   let solid=true;
   for(let dy=0;solid&&dy<rows;dy++)for(let dx=0;dx<run;dx++)if(!blue(x+dx,y+dy)){solid=false;break}
   if(!solid)continue;
   const box={left:bounds.left+x*scaleX,top:bounds.top+y*scaleY,width:run*scaleX,height:rows*scaleY};
   const right=box.left+box.width,bottom=box.top+box.height,pane=element.closest('[data-native-terminal]').getBoundingClientRect();
   if(box.left<Math.max(0,pane.left)||box.top<Math.max(0,pane.top)||right>Math.min(innerWidth,pane.right)||bottom>Math.min(innerHeight,pane.bottom))continue;
   const hit=document.elementFromPoint(box.left+box.width/2,box.top+box.height/2);
   if(element.closest('[data-native-terminal]').contains(hit))return box;
  }
  return null;
 });
 const currentRows=async()=>Number(await terminal.getAttribute('data-native-terminal-rows'));
 const imageVisible=async()=>(await mirror.textContent())?.includes('Release preview')?await draw():null;
 proof.terminalViewport=[];
 let normalRows;
 for(const [label,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
  await page.setViewportSize(viewport);
  await expect(terminal).toBeVisible();
  await expect(canvas).toBeVisible();
  await expect.poll(currentRows).toBeGreaterThan(1);
  if(label==='normal')normalRows=await currentRows();
  else await expect.poll(currentRows).toBeLessThan(normalRows);
  const before=await mirror.textContent(),wheel=[];
  let region=await imageVisible();
  if(!region){
   await canvas.hover();
   // Shift sends the wheel to terminal history even if the program requested mouse reporting.
   await page.keyboard.down('Shift');
   try{
    for(let i=0;i<16&&!region;i++){
     const prior=await mirror.textContent();
     await page.mouse.wheel(0,-80);
     await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
     const text=await mirror.textContent();
     wheel.push({changed:text!==prior});
     region=await imageVisible();
    }
   }finally{await page.keyboard.up('Shift')}
  }
  const text=await mirror.textContent();
  const state=await sameOwner();
  const filename='current-image-terminal-'+label+'.png';
  const visible={label,viewport,filename,region,wheel,rows:await currentRows(),viewportChanged:before!==text,
   originalLabelVisible:text.includes('Release preview'),sessionId:state.claude.sessionId,nativePid:state.native.state.nativePid};
  proof.terminalViewport.push(visible);
  await page.screenshot({path:join(output,filename),animations:'disabled'});
  await save();
  assert.ok(region&&visible.originalLabelVisible,'Expected original updated Image and its Release preview label in the terminal viewport');
 }
}
