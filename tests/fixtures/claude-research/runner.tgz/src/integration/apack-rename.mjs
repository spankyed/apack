import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
const [checkout, executable, workspace] = process.argv.slice(2);
assert.equal(process.env.HOME, workspace);
const base = join(checkout, 'packages/default-setup/src/features/code/be/services/claude-code');
const { query } = await import(pathToFileURL(join(base, 'query.ts')).href);
const { renameSession } = await import(pathToFileURL(join(base, 'session-controls.ts')).href);
const model = await startSyntheticModel(workspace);
const env = { HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'), ANTHROPIC_BASE_URL: model.url };
let handle;
try {
  handle = await query({ cliPath: executable, cwd: workspace, env, tools: [],
    strictMcpConfig: true, settingSources: [], model: 'claude-sonnet-4-6',
    settings: JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' }) });
  await handle.initialized;
  handle.send('Confirm the synthetic session fixture.');
  const result = await handle.result;
  await handle.close(); handle = undefined;
  const projects = join(workspace, '.claude', 'projects');
  let file;
  for (const bucket of await readdir(projects)) {
    const candidate = join(projects, bucket, `${result.sessionId}.jsonl`);
    try { await readFile(candidate); file = candidate; } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  assert.ok(file);
  const before = (await readFile(file, 'utf8')).trim().split('\n').map(JSON.parse);
  const callsBefore = model.calls.length;
  await renameSession({ sessionId: result.sessionId, title: 'Renamed native fixture', cwd: workspace, cliPath: executable, env });
  const after = (await readFile(file, 'utf8')).trim().split('\n').map(JSON.parse);
  assert.equal(after.findLast(row => row.type === 'custom-title')?.customTitle, 'Renamed native fixture');
  const conversation = rows => rows.filter(row => ['user', 'assistant'].includes(row.type));
  assert.deepEqual(conversation(after), conversation(before));
  assert.equal(model.calls.length, callsBefore);
  console.log(JSON.stringify({ evidence: 'apack-native-rename',
    targetSha256: createHash('sha256').update(await readFile(executable)).digest('hex'),
    persistedTitle: true, conversationUnchanged: true, resumedApiRequests: 0, userPromptsSent: 1, realModelRequests: 0 }));
} finally { try { if (handle) await handle.close(); } finally { await model.close(); } }
