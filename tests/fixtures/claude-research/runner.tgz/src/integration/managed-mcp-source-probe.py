"""Observe the pinned CLI's MCP source rules using an isolated Linux policy mount."""

import hashlib
import json
import os
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path


CLAUDE = Path('/frozen-claude/claude')
CLI_SHA256 = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
POLICY = Path('/etc/claude-code/managed-settings.json')
OUTPUT = Path('/control/managed-mcp-source-proof.json')
NAMES = ('managed-review', 'local-review', 'user-denied-review')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify_boundary(output=OUTPUT):
    assert os.geteuid() == 0 and Path('/.dockerenv').is_file()
    assert digest(CLAUDE) == CLI_SHA256
    boundary = json.loads(Path('/control/offline-verified').read_text())
    assert boundary['networkDisabled'] and boundary['pinnedExecutableReadOnly']
    interfaces = [name for _, name in socket.if_nameindex()]
    ipv4 = Path('/proc/net/route').read_text().splitlines()[1:]
    ipv6_path = Path('/proc/net/ipv6_route')
    ipv6 = ipv6_path.read_text().splitlines() if ipv6_path.exists() else []
    # Linux exposes unconfigured kernel tunnel devices even with Docker network mode none.
    assert all(row.split()[0] == 'lo' for row in ipv4) and all(row.split()[-1] == 'lo' for row in ipv6)
    assert any(line.split()[4] == str(POLICY.parent) and ' - tmpfs ' in line
               for line in Path('/proc/self/mountinfo').read_text().splitlines())
    assert POLICY.parent.resolve() == POLICY.parent and not POLICY.exists() and not POLICY.is_symlink()
    assert not output.exists()
    return interfaces


def configure(workspace, receipts):
    config = workspace / '.claude'
    config.mkdir()
    source = '/research/src/protocol/synthetic-mcp-health-server.mjs'
    node = shutil.which('node')
    assert node
    servers = {name: {'type': 'stdio', 'command': node, 'args': [source, str(receipts / name)]}
               for name in NAMES}
    (config / '.claude.json').write_text(json.dumps({'mcpServers': servers}))
    settings = {'allowedMcpServers': [{'serverName': name} for name in NAMES],
                'deniedMcpServers': [{'serverName': 'user-denied-review'}]}
    (config / 'settings.json').write_text(json.dumps(settings))
    for path in (workspace, config, receipts, *config.iterdir()):
        shutil.chown(path, user='node', group='node')
    return config, settings


def install_policy():
    value = {'allowManagedMcpServersOnly': True,
             'allowedMcpServers': [{'serverName': name} for name in ('managed-review', 'user-denied-review')]}
    body = (json.dumps(value) + '\n').encode()
    fd = os.open(POLICY, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(body)
    assert POLICY.stat().st_uid == 0 and stat.S_IMODE(POLICY.stat().st_mode) == 0o644
    return value, hashlib.sha256(body).hexdigest()


def observe(workspace, config, receipts, stage):
    for item in receipts.iterdir():
        assert item.name in NAMES and item.is_file() and not item.is_symlink()
        item.unlink()
    process = subprocess.run(['runuser', '-u', 'node', '--', 'env', '-i',
        f'HOME={workspace}', f'CLAUDE_CONFIG_DIR={config}', 'PATH=/usr/local/bin:/usr/bin:/bin',
        'DISABLE_AUTOUPDATER=1', 'DISABLE_TELEMETRY=1', 'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1',
        str(CLAUDE), 'mcp', 'list'], cwd=workspace, capture_output=True, text=True, timeout=30)
    startups = {path.name: path.read_text().splitlines() for path in sorted(receipts.iterdir())}
    return {'stage': stage, 'exitCode': process.returncode, 'stdout': process.stdout,
            'stderr': process.stderr, 'started': startups}


def main():
    interfaces = verify_boundary()
    evidence = {'cliSha256': CLI_SHA256, 'policyPath': str(POLICY), 'interfaces': interfaces, 'phases': []}
    policy_hash = None
    try:
        with tempfile.TemporaryDirectory(prefix='claude-mcp-policy-') as temporary:
            workspace = Path(temporary)
            receipts = workspace / 'startups'
            receipts.mkdir()
            config, settings = configure(workspace, receipts)
            evidence['userSettings'] = settings
            evidence['phases'].append(observe(workspace, config, receipts, 'user-settings'))
            evidence['managedSettings'], policy_hash = install_policy()
            evidence['policySha256'] = policy_hash
            evidence['phases'].append(observe(workspace, config, receipts, 'managed-only-allowlist'))
            assert digest(POLICY) == policy_hash
            POLICY.unlink()
            evidence['phases'].append(observe(workspace, config, receipts, 'policy-removed'))
    finally:
        if policy_hash is not None and POLICY.exists():
            assert not POLICY.is_symlink() and digest(POLICY) == policy_hash
            POLICY.unlink()
        evidence['policyAbsenceRestored'] = not POLICY.exists()
        OUTPUT.write_text(json.dumps(evidence, indent=2) + '\n')

    expected = [{'managed-review', 'local-review'}, {'managed-review'}, {'managed-review', 'local-review'}]
    for phase, names in zip(evidence['phases'], expected, strict=True):
        assert phase['exitCode'] == 0, phase
        assert set(phase['started']) == names, phase
        assert all(lines == ['started'] for lines in phase['started'].values()), phase
    assert evidence['policyAbsenceRestored']


def live():
    output = Path('/control/managed-mcp-standalone.json')
    interfaces = verify_boundary(output)
    assert json.loads(Path('/control/offline-verified').read_text())['standaloneManagedMcp'] is True
    evidence = {'cliSha256': CLI_SHA256, 'policyPath': str(POLICY), 'interfaces': interfaces, 'transitions': []}
    with tempfile.TemporaryDirectory(prefix='native-credit-admission-mcp-') as temporary:
        workspace = Path(temporary)
        shutil.chown(workspace, user='node', group='node')
        managed, initial_hash = install_policy()
        initial = POLICY.read_bytes()
        current = initial
        evidence['initialPolicySha256'] = initial_hash
        try:
            with subprocess.Popen(['runuser', '-u', 'node', '--', 'env', '-i', f'HOME={workspace}',
                'PATH=/usr/local/bin:/usr/bin:/bin', 'node', '/research/src/integration/managed-mcp-standalone.mjs'],
                cwd=workspace) as process:
                try:
                    deadline = time.monotonic() + 100
                    for sequence, requested in [(1, {}), (2, managed)]:
                        request = workspace / f'request-{sequence}.json'
                        while not request.exists() and process.poll() is None:
                            if time.monotonic() >= deadline:
                                raise TimeoutError('Standalone policy request deadline expired')
                            time.sleep(0.03)
                        if process.poll() is not None:
                            break
                        request_info = request.lstat()
                        assert stat.S_ISREG(request_info.st_mode) and request_info.st_uid == 1000 and request_info.st_size < 256
                        assert json.loads(request.read_text()) == {'sequence': sequence}
                        assert not POLICY.is_symlink() and POLICY.read_bytes() == current
                        body = (json.dumps(requested) + '\n').encode()
                        replacement = POLICY.with_name(f'managed-settings.standalone-{sequence}')
                        fd = os.open(replacement, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
                        with os.fdopen(fd, 'wb') as stream:
                            stream.write(body)
                        os.replace(replacement, POLICY)
                        current = body
                        receipt = {'sequence': sequence, 'at': time.time(), 'sha256': hashlib.sha256(body).hexdigest(),
                                   'uid': POLICY.stat().st_uid, 'mode': stat.S_IMODE(POLICY.stat().st_mode)}
                        evidence['transitions'].append(receipt)
                        receipt_file = workspace / f'receipt-{sequence}.json'
                        with receipt_file.open('x') as stream:
                            json.dump(receipt, stream)
                    evidence['exitCode'] = process.wait(timeout=max(1, deadline - time.monotonic()))
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=5)
        finally:
            assert not POLICY.is_symlink() and POLICY.read_bytes() == current
            POLICY.unlink()
            evidence['policyAbsenceRestored'] = not POLICY.exists()
            for name in ['standalone-proof.json', 'native-debug.log', 'terminal.bin']:
                path = workspace / name
                if path.exists():
                    info = path.lstat()
                    assert stat.S_ISREG(info.st_mode) and info.st_uid == 1000 and info.st_size <= 8 * 1024 * 1024
                    shutil.copyfile(path, output.with_name(name))
            output.write_text(json.dumps(evidence, indent=2) + '\n')
    assert evidence['exitCode'] == 0 and evidence['policyAbsenceRestored'] and len(evidence['transitions']) == 2


if __name__ == '__main__':
    if sys.argv[1:] == ['--standalone']:
        live()
    else:
        assert not sys.argv[1:]
        main()
