import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const {query}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href);
const model=await startSyntheticModel(workspace,'TextOnly');
const ids=['11111111-1111-4111-8111-111111111111'];
const turn=index=>({type:'user',uuid:ids[index],message:{role:'user',content:`Synthetic host turn ${index+1}`},parent_tool_use_id:null});
let handle;const events=[],results=[];
try{
 handle=await query({cliPath:executable,cwd:workspace,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:undefined,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},tools:[],strictMcpConfig:true,settingSources:[],noSessionPersistence:true,replayUserMessages:true,keepStdinOpen:true,signal:AbortSignal.timeout(15000),settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})});
 await handle.initialized;assert.equal(handle.send(turn(0)),ids[0]);
 for await(const event of handle.events){events.push(event);console.log(JSON.stringify({diagnostic:'native-event',event}));if(event.type==='result'){assert.equal(event.subtype,'success');results.push(event);if(results.length===1){await handle.getPlan();ids.push(handle.send('Synthetic host turn 2'));}else if(results.length===2){ids.push(handle.send({type:'user',message:{role:'user',content:[{type:'text',text:'Synthetic host turn 3'}]},parent_tool_use_id:null}));}else break;}}
 const first=await handle.result;assert.equal(first.raw,results[0]);
 await handle.close();
 for await(const event of handle.events){events.push(event);console.log(JSON.stringify({diagnostic:'native-event',event}));}
 assert.throws(()=>handle.send('Expired synthetic input'),/stdin is closed/);
 const replayIds=events.filter(event=>event.type==='user'&&event.isReplay===true).map(event=>event.uuid);
 assert.deepEqual(replayIds,ids);assert.deepEqual(results.map(result=>result.user_message_uuid),ids);assert.ok(results.every(result=>result.queued_turn_count===0));assert.equal(new Set(ids).size,3);assert.equal(results.length,3);assert.ok(results.every(result=>result.session_id===results[0].session_id));
 assert.equal(model.calls.length,3);assert.ok(model.calls[1].messageCount>model.calls[0].messageCount);
 const lifecycle=events.filter(event=>event.type==='command_lifecycle').map(({command_uuid,state})=>({command_uuid,state}));
 for(const id of ids)assert.deepEqual(lifecycle.filter(event=>event.command_uuid===id).map(event=>event.state),['queued','started','completed']);
 assert.ok(results[1].total_cost_usd>results[0].total_cost_usd&&results[2].total_cost_usd>results[1].total_cost_usd);
 assert.ok(results.every(result=>result.usage.input_tokens===10&&result.usage.output_tokens===5&&result.num_turns===1));
 console.log(JSON.stringify({evidence:'apack-native-multi-turn',targetSha256:hash(await readFile(executable)),sameSession:true,replayIds,lifecycle,hostReceiptsMatch:true,resultInputsMatch:true,closedInputRejected:true,cumulativeCost:true,perInputUsage:true,streamDrained:true,firstResultPromiseOnly:true,controlBetweenTurns:true,conversationRetained:true,results:results.map(({user_message_uuid,queued_turn_count,total_cost_usd,duration_ms,duration_api_ms,num_turns,usage,modelUsage})=>({user_message_uuid,queued_turn_count,total_cost_usd,duration_ms,duration_api_ms,num_turns,usage,modelUsage})),syntheticApiRequests:model.calls.length,realModelRequests:0,userPromptsSent:3}));
}finally{try{if(handle)await handle.close()}finally{await model.close()}}
