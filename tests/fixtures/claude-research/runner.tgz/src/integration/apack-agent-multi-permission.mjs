import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticMultiAgentModel} from '../protocol/synthetic-multi-agent-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const model=await startSyntheticMultiAgentModel();
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(base,'query.ts')).href);
let native;const events=[],permissions=[],nested=[];
try{
 native=await query({cliPath:executable,cwd:workspace,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:undefined,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},permissionMode:'default',tools:['Agent','Bash'],allowedTools:['Agent'],agents:{'multi-permission-fixture':{description:'Disposable local permission workers',prompt:'NativeMultiChildSystem. Use the provided fixture tool once, then return the fixed marker.',tools:['Bash'],maxTurns:2}},settingSources:[],strictMcpConfig:true,replayUserMessages:true,keepStdinOpen:true,surfaceControlRequests:true,signal:AbortSignal.timeout(28000),settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})});
 await native.initialized;
 native.send('Launch both disposable permission workers.');
 for await(const event of native.events){
  events.push(event);
  if(event.parent_tool_use_id&&(event.type==='assistant'||event.type==='user'))nested.push(event);
  if(event.type==='control_request'){
    const request=event.request;assert.equal(request.subtype,'can_use_tool');assert.equal(request.tool_name,'Bash');assert.ok(['multi_child_a','multi_child_b'].includes(request.tool_use_id));assert.ok(events.some(event=>event.type==='result'));
    permissions.push(event);
    if(permissions.length===2){
      assert.equal(new Set(permissions.map(event=>event.request.agent_id)).size,2);
      for(const permission of [...permissions].reverse()){
        const req=permission.request;
        assert.equal(req.input.command,`/usr/bin/printf MultiChild${req.tool_use_id.endsWith('_a')?'A':'B'} > multi-child-${req.tool_use_id.endsWith('_a')?'a':'b'}.txt`);
        native.respond(permission.request_id,req.tool_use_id==='multi_child_a'?{behavior:'allow',updatedInput:req.input}:{behavior:'deny',message:'Deny only WorkerB marker write.'});
      }
    }
  }
  if(event.type==='result'&&!native.hasPendingBackgroundTasks(event)&&events.filter(event=>event.type==='system'&&event.subtype==='task_notification').length===2)break;
 }
 assert.equal(permissions.length,2);
 assert.equal(await readFile(join(workspace,'multi-child-a.txt'),'utf8'),'MultiChildA');await assert.rejects(readFile(join(workspace,'multi-child-b.txt')),error=>error.code==='ENOENT');
 const started=events.filter(event=>event.type==='system'&&event.subtype==='task_started');const terminal=events.filter(event=>event.type==='system'&&event.subtype==='task_notification');
 for(const permission of permissions)assert.ok(started.some(task=>task.task_id===permission.request.agent_id&&terminal.some(done=>done.task_id===task.task_id&&done.status==='completed')));
 assert.ok(nested.some(event=>JSON.stringify(event).includes('WorkerAComplete')));assert.ok(nested.some(event=>JSON.stringify(event).includes('WorkerBComplete')));
 assert.equal(model.calls.filter(call=>call.childToolError===true).length,1);assert.equal(model.calls.filter(call=>call.childToolError===false).length,1);
 await native.close();
 console.log(JSON.stringify({evidence:'apack-native-agent-multi-permission',targetSha256:hash(await readFile(executable)),hostInputs:1,simultaneousPermissions:2,distinctNativeAgents:true,reverseReplies:true,allowedAOnly:true,bothTasksCompleted:true,bothChildOutputsRetained:true,nativeResults:events.filter(event=>event.type==='result').map(event=>({inputId:event.user_message_uuid??null,cost:event.total_cost_usd,pending:native.hasPendingBackgroundTasks(event)})),syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{
 await writeFile(join(workspace,'multi-permission-events.json'),JSON.stringify(events,null,2));await writeFile(join(workspace,'multi-permission-requests.json'),JSON.stringify(model.requests,null,2));
 console.log(JSON.stringify({diagnostic:'multi-permission',permissions,calls:model.calls}));
 try{if(native){native.kill();await native.close().catch(()=>{})}}finally{await model.close()}
}
