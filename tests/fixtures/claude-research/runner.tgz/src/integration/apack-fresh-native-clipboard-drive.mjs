import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {prepareNativeGlyphFonts} from './native-glyph-fonts.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function birth(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),f=raw.slice(raw.lastIndexOf(')')+2).split(' ');return f[0]==='Z'?null:f[19]}catch(error){if(error.code==='ENOENT')return null;throw error}}

/** Verify the shared native drawing seam and real terminal OSC52 clipboard transport. */
export async function driveFreshNativeClipboard({checkout,workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-clipboard[0-9]+$/);
 env=await prepareNativeGlyphFonts(workspace,env);const project=join(workspace,'project');await mkdir(project);await writeFile(join(project,'release-notes.md'),'# Release notes\n\nReview local permissions before continuing.\n');execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),configPath=join(workspace,'.claude/.claude.json'),settingsPath=join(workspace,'.claude/settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({theme:'dark',model:'opus'}));const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath);
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,defaultProfile:'shared',config,settings:JSON.parse(settingsBefore)},null,2));
 const output=join(workspace,'electron-results');let model,billing,proof;
 try{
  model=await startSyntheticModel(workspace,'TextOnly',{textReply:'The release review is complete: 日本語 🙂.',captureMessages:true,maxRequests:8});
  const tls=await prepareNativeCreditTls(join(workspace,'account-tls'));billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
  const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-fresh-native-clipboard',journeyBudgetMs:120000,journey:async({app,page,electronApp,expect,phase,userDataDir})=>{
   proof={status:'running',scope:'Actual original native main mount/draft/return/Stop after shared terminal ownership move, then real shell OSC52 copy through broker and main IPC with real OS clipboard paste. Not original CLI /copy command or full parity acceptance.',captures:[],layouts:[]};const save=()=>writeFile(join(output,'native-clipboard.json'),JSON.stringify(proof,null,2));
   const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews}});
   const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
   const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await composer.pressSequentially(text);await expect(composer).toHaveText(text)};
   try{
    await app.waitForSurface('default-setup/threads');await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');await page.waitForTimeout(700);
    await app.navigate('default-setup/threads');await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return!!c.currentThread?.id&&c.openedThreadId===null&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code')}),{timeout:15000}).toBe(true);
    await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
    proof.seed='Review the local release notes before checking permissions.';await replace(proof.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);await section.getByRole('button',{name:'Use native interface',exact:true}).click();
    const seen=new Set();for(let i=0;i<100;i++){const native=(await context()).native?.state;if(native?.nativePid&&native.status==='live')break;const text=await section.locator('[data-terminal-text]').innerText().catch(()=>''),stage=recognizeOnboardingPrompt(text,project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100);}
    await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.pid=proof.initial.native.state.nativePid;proof.processStart=await birth(proof.pid);assert.ok(proof.processStart);
    const input=section.locator('[aria-label="Terminal input"]'),nativeText=()=>section.locator('[data-terminal-text]').innerText();
    const clipboardBefore=await electronApp.evaluate(({clipboard})=>clipboard.readText());
    try {
     proof.nativeDraft='Keep the release review draft.';await input.focus();await input.pressSequentially(proof.nativeDraft);await expect.poll(nativeText,{timeout:10000}).toContain(proof.nativeDraft);
     const capture=async(stage)=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);const file='native-clipboard-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file)}};
     await capture('native-draft');await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(nativeText,{timeout:10000}).toContain(proof.nativeDraft);proof.afterReopen=await context();assert.equal(proof.afterReopen.native.state.nativePid,proof.pid);assert.equal(proof.afterReopen.claude.sessionId,proof.sessionId);
     await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);proof.stopped=true;await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toBeInViewport({ratio:1});
     await app.navigate('default-setup/code');await page.evaluate(directory=>window.__sendToSystem('default-setup/code',{type:'SET_BASE_DIRECTORY',path:directory,fromUserNavigation:false}),project);
     const drawn=page.locator('[data-apack-terminal]'),before=await drawn.evaluateAll(all=>all.map(e=>e.dataset.apackTerminal));await page.evaluate(()=>window.applicationState.send({type:'SEND_TO_SURFACE',surface:'default-setup/code',events:[{type:'terminal.CREATE'}]}));
     await expect.poll(async()=>proof.shellId=(await drawn.evaluateAll(all=>all.map(e=>e.dataset.apackTerminal))).find(id=>!before.includes(id)),{timeout:15000}).toBeTruthy();
     const shell=page.locator('[data-apack-terminal="'+proof.shellId+'"]'),field=shell.locator('textarea'),screen=()=>shell.locator('[data-terminal-text]').innerText();await expect(shell).toBeVisible();
     await field.focus();await field.pressSequentially("printf 'SHELLPID=%s\\n' \"$$\"\n");await expect.poll(async()=>proof.shellPid=Number(/SHELLPID=(\d+)/.exec(await screen())?.[1]),{timeout:10000}).toBeTruthy();proof.shellProcessStart=await birth(proof.shellPid);assert.ok(proof.shellProcessStart);
     proof.copied='Release review 日本語 🙂';const encoded=Buffer.from(proof.copied).toString('base64');await field.focus();await field.pressSequentially("printf '\\033]52;c;"+encoded+"\\007'\n");
     await expect.poll(()=>electronApp.evaluate(({clipboard})=>clipboard.readText()),{timeout:10000}).toBe(proof.copied);proof.afterOsc52=await electronApp.evaluate(({clipboard})=>clipboard.readText());
     await field.pressSequentially("review_clipboard=\"");await field.press('Control+Shift+V');await field.pressSequentially("\"; printf 'PASTE[%s]\\n' \"$review_clipboard\"; printf 'PASTE-BYTES=%s\\n' \"$(printf '%s' \"$review_clipboard\" | base64 | tr -d '\\n')\"\n");proof.expectedPaste='PASTE['+proof.copied+']';proof.expectedPasteBytes='PASTE-BYTES='+encoded;await expect.poll(async()=>(await screen()).replace(/\s+/g,''),{timeout:10000}).toContain(proof.expectedPasteBytes);proof.shellAfterPaste=await screen();await capture('osc52-pasted');
     proof.emptyWriteAcknowledged=await page.evaluate(()=>window.electronAPI.clipboard.writeText(''));assert.equal(proof.emptyWriteAcknowledged,true);assert.equal(await electronApp.evaluate(({clipboard})=>clipboard.readText()),'');
     await page.evaluate(id=>window.applicationState.send({type:'SEND_TO_SURFACE',surface:'default-setup/code',events:[{type:'terminal.CLOSE',terminalId:id}]}),proof.shellId);await expect(shell).toHaveCount(0);await expect.poll(()=>birth(proof.shellPid),{timeout:15000}).toBe(null);proof.shellClosed=true;
     await app.navigate('default-setup/threads');proof.final=await context();assert.equal(proof.final.claude.sessionId,proof.sessionId);assert.equal(proof.final.claude.totalCostUsd,proof.initial.claude.totalCostUsd);assert.deepEqual(proof.final.messages,proof.initial.messages);await capture('recovered');
    } finally {
     await electronApp.evaluate(async({clipboard},text)=>{if(text==='')clipboard.clear();else await clipboard.writeText(text)},clipboardBefore);assert.equal(await electronApp.evaluate(({clipboard})=>clipboard.readText()),clipboardBefore);proof.clipboardRestored=true;await save();
    }
    proof.status='complete';await save();phase('native-clipboard-complete');
   }catch(error){proof.status='failed';proof.error=error.message;proof.failureContext=await context().catch(()=>null);await save();throw error}
  }});
 }finally{
  await model?.close();await billing?.close();await mkdir(output,{recursive:true});if(model)await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2));if(billing)await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2));
  const retired=(!proof?.pid||await birth(proof.pid)!==proof.processStart)&&(!proof?.shellPid||await birth(proof.shellPid)!==proof.shellProcessStart);await writeFile(join(output,'writer-retirement.json'),JSON.stringify({retired,pid:proof?.pid,processStart:proof?.processStart}));assert.ok(retired,'Native writer must retire before profile restoration');await writeFile(join(output,'native-config-after.json'),await readFile(configPath));await writeFile(configPath,configBefore);await writeFile(settingsPath,settingsBefore);assert.deepEqual(await readFile(configPath),configBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configSha256:sha(configBefore),settingsSha256:sha(settingsBefore)}));
  if(proof?.sessionId){const root=join(workspace,'.claude/projects'),files=await readdir(root,{recursive:true}),matches=files.filter(name=>basename(name)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);await writeFile(join(output,'native-parent-transcript.jsonl'),await readFile(join(root,matches[0])))}
 }
}
