import assert from 'node:assert/strict';
import {mkdir, mkdtemp, readFile, readdir, rm, writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createServer} from 'node:http';
import {installNativeStatusPrefix} from '../protocol/native-status-prefix.mjs';
import {createHash, randomBytes} from 'node:crypto';

/** A private configured formatter records its own native invocations; it never runs itself. */
export async function prepareNativeBackgroundFormatterAudit(workspace, {observePrefix = false, observeSubagent = false} = {}) {
  const directory = join(workspace, 'formatter-invocations');
  await mkdir(directory);
  const helper = join(workspace, 'formatter-helper.mjs');
  const source = `import {writeFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
let input='';for await(const chunk of process.stdin){input+=chunk;if(Buffer.byteLength(input)>65536)process.exit(65);}
const value=JSON.parse(input);if(typeof value.session_id!=='string'||!value.cost||!value.context_window)process.exit(66);
const stdout='NativeConfiguredFormatter '+value.session_id+'\\n';
writeFileSync(${JSON.stringify(directory)}+'/'+randomUUID()+'.json',JSON.stringify({at:Date.now(),pid:process.pid,parentPid:process.ppid,sessionId:value.session_id,stdout,input:value}));
process.stdout.write(stdout);
`;
  await writeFile(helper, source);
  const quote = value => "'" + value.replaceAll("'", "'\\''") + "'";
  const settings = join(workspace, '.claude/settings.json');
  const previous = JSON.parse(await readFile(settings, 'utf8'));
  await writeFile(settings, JSON.stringify({...previous, statusLine:{type:'command', command:quote(process.execPath)+' '+quote(helper)}}));
  const commands={[quote(process.execPath)+' '+quote(helper)]:'main'};
  let subagentHelperSha256;
  if(observeSubagent){
    const subagentHelper=join(workspace,'subagent-formatter-helper.mjs');
    const subagentSource=`import {writeFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
let input='';for await(const chunk of process.stdin){input+=chunk;if(Buffer.byteLength(input)>65536)process.exit(65);}
const value=JSON.parse(input);if(typeof value.session_id!=='string'||!Array.isArray(value.tasks)||typeof value.columns!=='number')process.exit(66);
const stdout=value.tasks.map(task=>JSON.stringify({id:task.id,content:'NativeConfiguredAgent '+task.id+' '+task.status})).join('\\n')+'\\n';
writeFileSync(${JSON.stringify(directory)}+'/'+randomUUID()+'.json',JSON.stringify({at:Date.now(),pid:process.pid,parentPid:process.ppid,sessionId:value.session_id,kind:'subagent',stdout,input:value,observedPrefix:process.env.CLAUDE_CODE_SHELL_PREFIX??null}));
process.stdout.write(stdout);
`;
    await writeFile(subagentHelper,subagentSource);
    subagentHelperSha256=createHash('sha256').update(subagentSource).digest('hex');
    const command=quote(process.execPath)+' '+quote(subagentHelper);commands[command]='subagent';
    const current=JSON.parse(await readFile(settings,'utf8'));
    await writeFile(settings,JSON.stringify({...current,subagentStatusLine:{type:'command',command}}));
  }
  let server, socketDirectory, prefix;
  const exports=[];
  if(observePrefix){
    socketDirectory=await mkdtemp('/tmp/cc-formatter-');
    const token=randomBytes(32).toString('hex'),socketPath=join(socketDirectory,'status.sock');
    server=createServer(async(req,res)=>{
      const finish=code=>{res.writeHead(code);res.end('{}');};
      try{
        if(req.method!=='POST'||req.url!=='/native-status'||req.headers['x-research-token']!==token)return finish(403);
        let text='';for await(const chunk of req){text+=chunk;if(Buffer.byteLength(text)>32768)return finish(413);}
        const value=JSON.parse(text);
        if(exports.length>=128||!['main','subagent'].includes(value.kind)||typeof value.sessionId!=='string'||typeof value.stdout!=='string'||Buffer.byteLength(value.stdout)>8192)return finish(400);
        exports.push({...value,receivedAt:Date.now()});finish(200);
      }catch{if(!res.headersSent)finish(400);else res.destroy();}
    });
    await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(socketPath,resolve);});
    prefix=await installNativeStatusPrefix(workspace,{socketPath,token,commands});
  }
  const registration=prefix?`const originalPrefix=await $.env.get('CLAUDE_CODE_SHELL_PREFIX');let setResult;if(originalPrefix===undefined)setResult=await $.env.set('CLAUDE_CODE_SHELL_PREFIX',${JSON.stringify(prefix.path)});await $.fs.write('native-formatter-prefix-'+sessionId+'.json',JSON.stringify({sessionId,originalPrefix:originalPrefix??null,setResult,readback:await $.env.get('CLAUDE_CODE_SHELL_PREFIX')}));`:'';
  const snapshots=[];
  return {
    registration,
    async close(){if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}if(socketDirectory)await rm(socketDirectory,{recursive:true,force:true});},
    helperSha256:createHash('sha256').update(source).digest('hex'),
    async snapshot(stage, childSessionId) {
      assert.ok(['before-attach','after-attach'].includes(stage));
      const names=await readdir(directory);assert.ok(names.length<=128);
      const invocations=await Promise.all(names.filter(name=>/^[a-f0-9-]{36}\.json$/.test(name)).map(async name=>JSON.parse(await readFile(join(directory,name),'utf8'))));
      const value={stage,at:Date.now(),childSessionId,invocations,childInvocations:invocations.filter(row=>row.sessionId===childSessionId).length};
      snapshots.push(value);return {helperSha256:this.helperSha256,...(subagentHelperSha256?{subagentHelperSha256}:{}),snapshots,exports:[...exports],prefix:prefix?{sha256:prefix.sha256,implementationSha256:prefix.implementationSha256}:undefined,scope:'Configured helper invocation only; absence is bounded to recorded windows. No app formatter support or observer mechanism is established.'};
    },
  };
}
