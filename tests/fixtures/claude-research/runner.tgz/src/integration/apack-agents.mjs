import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
const [checkout, executable, workspace] = process.argv.slice(2);
assert.equal(process.env.HOME, workspace);
for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN']) assert.equal(process.env[key], undefined);
const { list } = await import(pathToFileURL(join(checkout,
  'packages/default-setup/src/features/code/be/services/claude-code/agents.ts')).href);
const result = await list({ cliPath: executable, cwd: workspace, all: true, settingSources: '',
  env: { HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude') } });
assert.deepEqual(result, []);
console.log(JSON.stringify({ evidence: 'apack-native-agents',
  targetSha256: createHash('sha256').update(await readFile(executable)).digest('hex'),
  emptySessionList: true, userPromptsSent: 0, realModelRequests: 0 }));
