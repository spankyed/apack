import assert from 'node:assert/strict';
import {once} from 'node:events';
import {existsSync,appendFileSync,createWriteStream} from 'node:fs';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';

/** Drive the persisted-artifact journey on real Electron with container-scoped launch arguments. */
export async function driveArtifactWheel({checkout,workspace,env}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv'));
 assert.ok(existsSync('/control/offline-verified'));
 assert.ok(!env.NODE_OPTIONS?.includes('linux-electron-launch.mjs'),'Direct launch scopes --no-sandbox to Electron; no global launch patch');
 const output=join(workspace,'electron-results');await mkdir(output,{recursive:true});
 const phase=(kind,extra={})=>appendFileSync(join(workspace,'direct-electron-events.jsonl'),JSON.stringify({at:Date.now(),kind,...extra})+'\n');
 const require=createRequire(join(checkout,'package.json'));
 phase('loading-playwright');
 const {_electron}=require('@playwright/test');
 phase('loading-app-environment');
 const {appLaunchEnv}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/launch-env.ts')).href);
 const {waitForApplicationWindow}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/application-window.ts')).href);
 phase('loading-shared-journey');
 const {verifyArtifactWheel}=await import(pathToFileURL(join(checkout,'tests/fixtures/claude-research/artifact-wheel-journey.ts')).href);
 const JOURNEY_TIMEOUT_MS=60000;
 let electronApp,appProcess,page,timer,cleanupTimer,log,logBytes=0,quit='not-started',status='failed';
 try {
   // Leave the fresh profile to the app's normal shipped-pack installation.
   phase('preparing-app-helpers');
   const {resolveAppEnvironment}=await import(pathToFileURL(require.resolve('@apackdev/sdk/env')).href);
   const {appDir}=resolveAppEnvironment({env:'test',userDataDir:join(workspace,'app-data')});
   const {createAppDriver,waitForAppReady}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/index.ts')).href);
   phase('launch-requested');
   // Let Playwright install its Electron loader; executablePath bypasses that loader.
   assert.equal(require('electron'),createRequire(require.resolve('playwright-core/package.json'))('electron/index.js'));
   electronApp=await _electron.launch({args:['--no-sandbox',checkout],cwd:checkout,env:appLaunchEnv(env,join(workspace,'app-data')),timeout:60000});
   appProcess=electronApp.process();
   log=createWriteStream(join(output,'app-0.log'));
   const capture=chunk=>{const bytes=Buffer.from(chunk).subarray(0,Math.max(0,4*1048576-logBytes));logBytes+=bytes.length;if(bytes.length)log.write(bytes);};
   appProcess.stdout?.on('data',capture);appProcess.stderr?.on('data',capture);
   phase('process-attached',{pid:appProcess.pid});
   // The app owns its60s API clock. Attachment can precede API startup; a second
   // clock here would shorten that allowance. The enclosing recorder bounds setup.
   let backendReady=false;
   while(!backendReady){
    assert.ok(appProcess.exitCode===null&&appProcess.signalCode===null,'App exited before API readiness');
    const text=await readFile(join(appDir,'logs/main.jsonl'),'utf8').catch(error=>{if(error.code==='ENOENT')return '';throw error});
    assert.ok(!text.includes('[MAIN] API server failed to start'),'App API startup failed; inspect the original main log');
    backendReady=text.includes('[MAIN] API server is running on port ');
    if(!backendReady)await new Promise(resolve=>setTimeout(resolve,200));
   }
   phase('backend-ready');
   // Match the existing standard app fixture's window discovery budget.
   page=await waitForApplicationWindow(electronApp,45000);await page.setViewportSize({width:1400,height:900});
   phase('app-window-ready',{url:page.url()});
   page.setDefaultTimeout(0);
   await waitForAppReady(page);phase('app-connected');
   const app=createAppDriver(page,output);
  await Promise.race([(async()=>{
   phase('shared-ui-journey-started');
   await verifyArtifactWheel({app,appPage:page,testInfo:{outputPath:(...parts)=>join(output,...parts)}});
   status='complete';phase('journey-complete');
  })(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Artifact wheel journey exceeded its existing app-test allowance')),JOURNEY_TIMEOUT_MS)})]);
 }catch(error){
  phase('journey-failed',{message:error.message});
  if(!page&&electronApp)page=electronApp.windows().find(candidate=>!candidate.isClosed());
  if(page&&!page.isClosed()){
   await page.screenshot({path:join(output,'direct-artifact-wheel-failure.png'),timeout:5000}).catch(()=>{});
   await writeFile(join(output,'direct-artifact-wheel-failure.txt'),await page.locator('body').innerText({timeout:5000}).catch(()=>''));
  }
  throw error;
 }finally{
  clearTimeout(timer);
  if(electronApp){
   try{await Promise.race([(async()=>{await electronApp.close();if(appProcess.exitCode===null&&appProcess.signalCode===null)await once(appProcess,'exit')})(),new Promise((_,reject)=>{cleanupTimer=setTimeout(()=>reject(Error('Owned Electron close did not finish')),30000)})]);quit='normal';}
   catch{quit='forced';if(appProcess.exitCode===null&&appProcess.signalCode===null)appProcess.kill('SIGKILL');}
   finally{clearTimeout(cleanupTimer);}
  }
  if(log)await new Promise(resolve=>log.end(resolve));
  await writeFile(join(workspace,'direct-electron-proof.json'),JSON.stringify({route:'real-Electron-shared-artifact-wheel-journey',status,quit,rootExitObserved:!!appProcess&&(appProcess.exitCode!==null||appProcess.signalCode!==null),pageUrl:page?.url(),testRunnerUsed:false,packPreparation:'app-first-boot',preparationIncludedInJourneyBudget:false,startupIncludedInJourneyBudget:false,journeyBudgetMs:JOURNEY_TIMEOUT_MS},null,2));
  if(status==='complete')assert.equal(quit,'normal','Actual-app shutdown must finish without a forced stop');
 }
}
