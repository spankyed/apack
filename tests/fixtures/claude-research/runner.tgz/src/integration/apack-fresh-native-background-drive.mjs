import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {execFile,execFileSync} from 'node:child_process';
import {promisify} from 'node:util';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {prepareNativeAppCliProfile} from './native-app-cli-profile.mjs';
import {prepareBackgroundStatusProfile} from './native-background-status-profile.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {createNativeTestImage} from '../protocol/native-test-image.mjs';
import {verifyStatusKeyboardFocus} from './native-composer-status-focus-journey.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function birth(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),f=raw.slice(raw.lastIndexOf(')')+2).split(' ');return f[0]==='Z'?null:f[19]}catch(error){if(error.code==='ENOENT')return null;throw error}}

/** Original background attach through the normal app controls and shared broker drawing. */
export async function driveFreshNativeBackground({checkout,workspace,env,clarification=false,images=false,submitImage=false,stopWithImage=false,interruptWithImage=false,invalidImageRecovery=false,statusKeyboardFocus=false,statusDecorations=false}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+$/);
 assert.ok(!images||clarification);
 assert.ok(!submitImage||images);
 assert.ok(!stopWithImage||(images&&!submitImage));
 assert.ok(!interruptWithImage||(images&&!submitImage&&!stopWithImage));
 assert.ok(!invalidImageRecovery||submitImage);
 assert.ok(!statusKeyboardFocus||!clarification);
 assert.ok(!statusDecorations||statusKeyboardFocus);
 const project=join(workspace,'project');await mkdir(project);await writeFile(join(project,'release-notes.md'),'# Release notes\n\nReview local permissions before continuing.\n');execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),profileDir=await prepareNativeAppCliProfile({checkout,workspace,account,owned:clarification}),configPath=join(profileDir,'.claude.json'),settingsPath=join(profileDir,'settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({...JSON.parse(await readFile(settingsPath,'utf8')),theme:'dark',model:'opus'}));const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath);
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,defaultProfile:'shared',cliProfileMode:clarification?'app-owned':'external',config,settings:JSON.parse(settingsBefore)},null,2));
 const statusProfile=await prepareBackgroundStatusProfile(workspace,{configDir:profileDir,allowEmptyStatus:statusKeyboardFocus});const output=join(workspace,'electron-results');let model,billing,proof,launchEnv;
 try{
  model=await startSyntheticModel(workspace,'TextOnly',{textReply:'The background release review is complete.',childControlScenario:clarification&&!interruptWithImage,childCancellationScenario:interruptWithImage,captureMessages:true,maxRequests:16});
  const tls=await prepareNativeCreditTls(join(workspace,'account-tls'));billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
  launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:statusKeyboardFocus?'real-Electron-main-status-keyboard-focus':invalidImageRecovery?'real-Electron-background-question-invalid-image':interruptWithImage?'real-Electron-background-question-image-interrupt':stopWithImage?'real-Electron-background-question-image-stop':submitImage?'real-Electron-background-question-image-submit':images?'real-Electron-background-question-image':clarification?'real-Electron-background-clarification':'real-Electron-fresh-native-background',journeyBudgetMs:120000,journey:async({app,page,electronApp,expect,phase,userDataDir})=>{
   proof={status:'running',scope:'Original background terminal open/input/close/reopen with retained parent draft, exact original child reply/status cost and scoped Stop; not full background/policy/lifecycle or parity acceptance.',captures:[],layouts:[]};const save=()=>writeFile(join(output,'native-background.json'),JSON.stringify(proof,null,2));
   const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews}});
   const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
   const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await composer.pressSequentially(text);await expect(composer).toHaveText(text)};
   try{
    await app.waitForSurface('default-setup/threads');await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');await page.waitForTimeout(700);
    await app.navigate('default-setup/threads');await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return!!c.currentThread?.id&&c.openedThreadId===null&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code')}),{timeout:15000}).toBe(true);
    await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
    proof.seed='Review the local release notes before checking permissions.';await replace(proof.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);await section.getByRole('button',{name:'Use native interface',exact:true}).click();
    const seen=new Set();for(let i=0;i<100;i++){const native=(await context()).native?.state;if(native?.nativePid&&native.status==='live')break;const text=await section.locator('[data-terminal-text]').innerText().catch(()=>''),stage=recognizeOnboardingPrompt(text,project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100);}
    await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.pid=proof.initial.native.state.nativePid;proof.processStart=await birth(proof.pid);assert.ok(proof.processStart);await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
    if(statusKeyboardFocus){
     proof.scope='Main composer keyboard focus returns after original status output withdraws.';
     await verifyStatusKeyboardFocus({page,electronApp,expect,context,composer,send,section,model,proof,output,profileDir,statusProfile,birth,save,statusDecorations});
     phase('native-main-status-keyboard-focus-complete');
     return;
    }
    proof.backgroundCommand=clarification
      ? (interruptWithImage?'/background ResearchChildCancel1 Ask which release branch to review.':'/background ResearchChildControl1 Ask which release branch to review.')
      : '/background Continue reviewing the release notes.';await replace(proof.backgroundCommand);await send.click();
    const widget=page.getByRole('region',{name:'Background Claude session',exact:true});await expect(widget.getByRole('button',{name:'Open session',exact:true})).toBeEnabled({timeout:25000});await expect.poll(async()=>(await context()).native?.background?.session?.pid,{timeout:25000}).toBeTruthy();
    proof.running=await context();proof.worker=proof.running.native.background.session;proof.workerStart=await birth(proof.worker.pid);assert.ok(proof.workerStart);assert.notEqual(proof.worker.sessionId,proof.sessionId);assert.equal(proof.worker.cwd,project);
    proof.parentDraft='Keep the parent release notes while I review the background session.';await replace(proof.parentDraft);proof.parentDocument=await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));proof.parentBeforeAttach=await context();
    const sameParent=async()=>{const c=await context();assert.equal(c.claude.sessionId,proof.sessionId);assert.deepEqual(c.messages,proof.parentBeforeAttach.messages);assert.equal(c.claude.totalCostUsd,proof.parentBeforeAttach.claude.totalCostUsd);assert.deepEqual(await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()})),proof.parentDocument);return c};
    if (clarification) {
     proof.scope=invalidImageRecovery?'Recover an owned background question from a decoder refusal and send the original answer with its valid image.':interruptWithImage?'Interrupt a background question with an unsent image and answer a fresh question in the same worker.':stopWithImage?'Stop an owned background session with an unsent question image and retain the parent notes.':submitImage?'Original background question submission with an image, retained parent notes and a separate child follow-up.':'Original background question clarification with retained parent notes and a separate child follow-up.';
     await backgroundClarification({page,expect,model,profileDir,widget,composer,proof,output,sameParent,save,images,submitImage,stopWithImage,interruptWithImage,invalidImageRecovery,context});
    } else {
     const panel=page.getByRole('region',{name:'Background Claude terminal',exact:true}),input=panel.locator('[aria-label="Terminal input"]'),text=()=>panel.locator('[data-terminal-text]').innerText();
     const normalized=value=>value.replace(/\s+/g,'');
     const capture=async(stage,expected)=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect(panel).toBeInViewport({ratio:1});await expect(panel.getByRole('button',{name:'Close connection',exact:true})).toBeInViewport({ratio:1});await page.evaluate(()=>document.fonts.ready);await expect.poll(()=>panel.locator('[data-native-terminal]').evaluate(e=>{const canvas=e.querySelector('canvas'),host=e.parentElement;if(!canvas||!host)return false;const r=canvas.getBoundingClientRect(),h=host.getBoundingClientRect(),text=e.querySelector('[data-terminal-text]')?.innerText??'',rulers=text.split('\n').filter(line=>/^─{10,}$/.test(line.trim()));return r.width<=h.width+1&&r.height<=h.height+1&&h.width-r.width<16&&h.height-r.height<30&&rulers.at(-1)?.trim().length===Number(e.dataset.nativeTerminalColumns)}),{timeout:15000}).toBe(true);await expect.poll(async()=>normalized(await text()),{timeout:15000}).toContain(normalized(expected));proof.layouts.push({stage,size,text:await text(),box:await panel.boundingBox(),drawing:await panel.locator('[data-native-terminal]').evaluate(e=>({columns:e.dataset.nativeTerminalColumns,rows:e.dataset.nativeTerminalRows,canvas:(()=>{const r=e.querySelector('canvas').getBoundingClientRect();return{width:r.width,height:r.height}})(),host:(()=>{const r=e.parentElement.getBoundingClientRect();return{width:r.width,height:r.height}})()}))});const file='native-background-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);await sameParent();await save()}};
     proof.childDraft='Keep this child release draft あ🙂';proof.attachments=[];
     for(const cycle of ['first','reopened']){
      const before=model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length;await widget.getByRole('button',{name:'Open session',exact:true}).click();await expect(panel).toBeVisible({timeout:15000});await expect.poll(async()=>(await context()).native?.attachment?.state?.status,{timeout:15000}).toBe('live');const current=(await context()).native.attachment.state;assert.equal(current.sessionId,proof.worker.sessionId);assert.equal(current.jobId,proof.worker.id);assert.notEqual(current.terminalSession.id,proof.initial.native.state.terminalSession.id);proof.attachments.push({...current,output:undefined,workerStart:await birth(proof.worker.pid),clientStart:current.clientPid?await birth(current.clientPid):null});assert.equal(proof.attachments.at(-1).workerStart,proof.workerStart);
      await expect(input).toBeFocused();if(cycle==='first')await input.pressSequentially(proof.childDraft);await capture(cycle,proof.childDraft);assert.equal(model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length,before,'Opening/typing unsent draft must not query the model');
      if(cycle==='reopened'){
       proof.childFollowup='Continue the background release review with these notes.';await input.press('Control+u');await input.pressSequentially(proof.childFollowup);await input.press('Enter');
       const root=join(profileDir,'projects'),journal=async()=>{const paths=(await readdir(root,{recursive:true})).filter(n=>basename(n)===proof.worker.sessionId+'.jsonl');assert.equal(paths.length,1);return readFile(join(root,paths[0]))};
       await expect.poll(async()=>{const rows=(await journal()).toString().split('\n').filter(Boolean).map(JSON.parse),human=rows.find(r=>r.type==='user'&&r.origin?.kind==='human'&&r.message?.content===proof.childFollowup);if(!human)return false;const byId=new Map(rows.map(r=>[r.uuid,r]));return rows.some(r=>{if(r.type!=='assistant'||!Array.isArray(r.message?.content)||!r.message.content.some(b=>b.type==='text'&&b.text==='The background release review is complete.'))return false;let id=r.parentUuid;for(let i=0;id&&i<rows.length;i++){if(id===human.uuid)return true;id=byId.get(id)?.parentUuid}return false})},{timeout:20000}).toBe(true);await writeFile(join(output,'native-child-transcript.jsonl'),await journal());await widget.getByRole('button',{name:'Refresh status',exact:true}).click();await expect.poll(async()=>(await context()).native?.backgroundInfo?.sessionId,{timeout:15000}).toBe(proof.worker.sessionId);proof.childInfo=(await context()).native.backgroundInfo;await expect.poll(async()=>{const rows=await statusProfile.invocations();return rows.some(r=>r.input.session_id===proof.worker.sessionId&&r.input.cost.total_cost_usd===proof.childInfo.totalCostUsd)},{timeout:15000}).toBe(true);proof.statusInvocations=await statusProfile.invocations();await capture('answered','The background release review is complete.');proof.parentAfterChild=await sameParent();
      }
      await panel.getByRole('button',{name:'Close connection',exact:true}).click();await expect(panel).toBeHidden({timeout:15000});await expect.poll(async()=>(await context()).native?.attachment,{timeout:15000}).toBeUndefined();const saved=proof.attachments.at(-1);if(saved.clientPid)await expect.poll(()=>birth(saved.clientPid),{timeout:15000}).toBe(null);assert.equal(await birth(proof.worker.pid),proof.workerStart);await sameParent();await expect(composer).toBeEditable();
     }
     assert.notEqual(proof.attachments[0].id,proof.attachments[1].id);assert.notEqual(proof.attachments[0].terminalSession.id,proof.attachments[1].terminalSession.id);proof.closePreservedWorker=true;
    }
    await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});await expect.poll(()=>birth(proof.worker.pid),{timeout:15000}).toBe(null);proof.nativeStopped=JSON.parse(await readFile(join(profileDir,'jobs',proof.worker.id,'state.json'),'utf8'));assert.equal(proof.nativeStopped.sessionId,proof.worker.sessionId);assert.equal(proof.nativeStopped.state,'stopped');proof.parentAfterStop=await sameParent();proof.stopped=true;
    if(stopWithImage){
     await expect(widget.getByRole('region',{name:'Claude Code questions',exact:true})).toHaveCount(0);
     const root=join(profileDir,'projects');
     const names=(await readdir(root,{recursive:true})).filter(name=>basename(name)===proof.worker.sessionId+'.jsonl');
     assert.equal(names.length,1);
     const journal=await readFile(join(root,names[0]));
     const unsent=createNativeTestImage([30,115,230,255]).toString('base64');
     assert.ok(!journal.includes(unsent));
     assert.ok(!JSON.stringify(model.calls).includes(unsent));
     assert.ok(!model.calls.some(call=>call.childControlResult?.tool_use_id==='toolu_child_control_1'&&!call.childControlResult.is_error));
     await writeFile(join(output,'native-child-transcript.jsonl'),journal);
     proof.unsentImageStop={...proof.unsentImageStop,journalSha256:sha(journal),noModelImage:true,noJournalImage:true,noSubmittedAnswer:true};
    }
    await expect(composer).toHaveText(proof.parentDraft);await expect(send).toBeDisabled();await expect(card.getByText('This conversation moved to the background. Your notes stay here.',{exact:true})).toBeVisible();proof.notesOnly=true;proof.final=await sameParent();proof.finalDocument=await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
    for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect(composer).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});await expect(send).toBeDisabled();const file='native-background-recovered-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file)}
    if((await context()).native?.state?.status==='live'){await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null)}proof.status='complete';await save();phase('native-background-complete');
   }catch(error){proof.status='failed';proof.error=error.message;proof.failureContext=await context().catch(()=>null);await save();throw error}
  }});
 }finally{
  await mkdir(output,{recursive:true});
  // The public native listing owns process identity; state.json owns task state.
  const cleanup=[],run=promisify(execFile),listed=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:launchEnv??{...env,...account},timeout:20000,maxBuffer:2*1024**2})).stdout);assert.ok(Array.isArray(listed)&&listed.length<=64);
  const owned=listed.filter(job=>job.kind==='background'&&/^[a-f0-9]{8}$/.test(job.id??'')&&job.cwd===project&&Number.isSafeInteger(job.pid)&&job.state!=='stopped');
  for(const job of owned){const state=JSON.parse(await readFile(join(profileDir,'jobs',job.id,'state.json'),'utf8'));assert.equal(state.cwd,project);assert.equal(state.sessionId,job.sessionId);const start=await birth(job.pid);if(!start)continue;if(proof?.worker?.id===job.id)assert.equal(start,proof.workerStart);await run('/frozen-claude/claude',['stop',job.id],{cwd:project,env:launchEnv??{...env,...account},timeout:20000,maxBuffer:2*1024**2});cleanup.push({id:job.id,sessionId:job.sessionId,pid:job.pid,start});}
  await writeFile(join(output,'cleanup-owned-workers.json'),JSON.stringify(cleanup));
  await model?.close();await billing?.close();if(model)await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2));if(billing)await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2));
  const retirementStarted=Date.now();let retired=false;for(let attempt=0;attempt<100;attempt++){retired=(!proof?.pid||await birth(proof.pid)!==proof.processStart)&&(!proof?.worker||await birth(proof.worker.pid)!==proof.workerStart)&&(await Promise.all(cleanup.map(async job=>await birth(job.pid)!==job.start))).every(Boolean)&&(await Promise.all((await statusProfile.invocations()).map(async row=>await birth(row.pid)!==row.start))).every(Boolean);if(retired)break;await new Promise(resolve=>setTimeout(resolve,50));}await writeFile(join(output,'writer-retirement.json'),JSON.stringify({retired,elapsedMs:Date.now()-retirementStarted,pid:proof?.pid,processStart:proof?.processStart,worker:proof?.worker,workerStart:proof?.workerStart,cleanup}));assert.ok(retired,'Native writer must retire before profile restoration');await writeFile(join(output,'background-status-receipts.json'),JSON.stringify(await statusProfile.invocations()));await statusProfile.restore();await writeFile(join(output,'native-config-after.json'),await readFile(configPath));await writeFile(configPath,configBefore);await writeFile(settingsPath,settingsBefore);assert.deepEqual(await readFile(configPath),configBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configSha256:sha(configBefore),settingsSha256:sha(settingsBefore)}));
  if(proof?.sessionId){const root=join(profileDir,'projects'),files=await readdir(root,{recursive:true}),matches=files.filter(name=>basename(name)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);await writeFile(join(output,'native-parent-transcript.jsonl'),await readFile(join(root,matches[0])))}
 }
}


async function backgroundClarification({page,expect,model,profileDir,widget,composer,proof,output,sameParent,save,images,submitImage,stopWithImage,interruptWithImage,invalidImageRecovery,context}) {
 const open=widget.getByRole('button',{name:'Answer question',exact:true});
 const question=widget.getByRole('region',{name:'Claude Code questions',exact:true});
 await expect.poll(()=>model.calls.some(call=>(interruptWithImage?call.childCancellationRound==='1':call.childControlStage===1)),{timeout:20000}).toBe(true);
 const timeline=join(profileDir,'jobs',proof.worker.id,'timeline.jsonl');
 await expect.poll(async()=>await readFile(timeline,'utf8').then(value=>value.includes('Which release branch should be reviewed first?'),()=>false),{timeout:15000}).toBe(true);
 await widget.getByRole('button',{name:'Refresh status',exact:true}).click();
 await expect(open).toBeEnabled({timeout:25000});
 await expect(question).toHaveCount(0);
 await open.click();
 const branch=question.getByRole('radio',{name:'Stable Review the current release',exact:true});
 const submit=question.getByRole('button',{name:'Submit answers',exact:true});
 const action=submitImage?submit:question.getByRole('button',{name:'Chat about this',exact:true});
 let image;
 if(images){
  image=createNativeTestImage([30,115,230,255]);
  await question.getByRole('button',{name:'Write your own answer',exact:true}).click();
  const files=[{name:'Branch-chart.png',mimeType:'image/png',buffer:image}];
  if(invalidImageRecovery) files.unshift({name:'Broken-branch-chart.png',mimeType:'image/png',buffer:Buffer.from('89504e470d0a1a0a','hex')});
  await question.getByLabel('Attach image',{exact:true}).setInputFiles(files);
  await expect(question.getByRole('button',{name:'Remove Branch-chart.png',exact:true})).toBeVisible();
 }
 await branch.check();
 for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
  await page.setViewportSize(viewport);
  if(submitImage||stopWithImage||interruptWithImage){
   await branch.scrollIntoViewIfNeeded();
   await expect(branch).toBeInViewport({ratio:1});
   const remove=question.getByRole('button',{name:'Remove Branch-chart.png',exact:true});
   await remove.scrollIntoViewIfNeeded();
   await expect(remove).toBeInViewport({ratio:1});
   await expect(submit).toBeInViewport({ratio:1});
   if(interruptWithImage) await expect(widget.getByRole('button',{name:'Interrupt response',exact:true})).toBeInViewport({ratio:1});
   if(stopWithImage) await expect(widget.getByRole('button',{name:'Stop background session',exact:true})).toBeInViewport({ratio:1});
  }else{
   for(const control of [branch,action,submit]) await expect(control).toBeInViewport({ratio:1});
  }
  const file='background-question-'+(interruptWithImage?'image-interrupt':stopWithImage?'image-stop':submitImage?'image-submit':'clarification')+'-'+size+'.png';
  await page.screenshot({path:join(output,file),animations:'disabled'});
  proof.captures.push(file);
 }
 const result=interruptWithImage
  ? ()=>model.calls.find(call=>call.childCancellationRound==='1'&&call.childCancellationResult)?.childCancellationResult
  : ()=>model.calls.find(call=>call.childControlStage===1&&call.childControlResult)?.childControlResult;
 await question.getByRole('button',{name:'Back to parent notes',exact:true}).click();
 await expect(question).toBeHidden();
 await expect(composer).toBeFocused();
 await sameParent();
 assert.equal(result(),undefined);
 await open.click();
 await expect(branch).toBeChecked();
 if(image) await expect(question.getByRole('button',{name:'Remove Branch-chart.png',exact:true})).toHaveCount(1);
 if(stopWithImage){
  assert.equal(result(),undefined);
  proof.unsentImageStop={imageSha256:sha(image),retainedAcrossParentReturn:true};
  await save();
  return;
 }
 if(interruptWithImage){
  assert.equal(result(),undefined);
  await interruptBackgroundQuestionImage({page,expect,model,profileDir,widget,question,proof,output,image,context,sameParent,save});
  return;
 }
 if(invalidImageRecovery) {
  proof.invalidImageRecovery=await refuseBackgroundQuestionImage({page,expect,question,branch,submit,result,context,proof,output,sameParent});
 }
 await action.click();
 await expect(question).toHaveCount(0,{timeout:15000});
 await expect.poll(result,{timeout:15000}).toBeTruthy();
 const original=result();
 assert.equal(original.tool_use_id,'toolu_child_control_1');
 if(submitImage){
  assert.notEqual(original.is_error,true);
  const answer=JSON.stringify(original.content);
  assert.ok(answer.includes('Which release branch should be reviewed first?'));
  assert.ok(answer.includes('Stable'));
  assert.ok(!answer.includes('The user wants to clarify these questions.'));
 }else{
  assert.equal(original.is_error,true);
  assert.ok(original.content.includes('The user wants to clarify these questions.'));
  assert.ok(original.content.endsWith('- "Which release branch should be reviewed first?"\n  Answer: Stable'));
 }
 const response={result:original,parentNotesPreserved:true,heldChoicePreserved:true};
 if(submitImage) proof.submission=response;
 else proof.clarification=response;
 if(image){
  const call=model.calls.find(call=>call.childControlResult?.tool_use_id===original.tool_use_id);
  const row=call.messages.find(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='tool_result'&&block.tool_use_id===original.tool_use_id));
  const index=row.content.findIndex(block=>block.type==='tool_result'&&block.tool_use_id===original.tool_use_id);
  const native=row.content[index+1];
  assert.equal(native?.type,'image');
  assert.equal(native.source.media_type,'image/png');
  assert.deepEqual(Buffer.from(native.source.data,'base64'),image);
  response.image={sha256:sha(image),afterToolResult:true,retainedAcrossParentReturn:true};
 }
 const form=widget.getByRole('form',{name:'Background session message',exact:true});
 const editor=form.locator('[contenteditable="true"]');
 await expect(editor).toBeEditable();
 proof.childFollowup='Start with the stable release, with migration notes in a separate section.';
 await editor.fill(proof.childFollowup);
 await form.getByRole('button',{name:'Send message',exact:true}).click();
 const root=join(profileDir,'projects');
 const journal=async()=>{
  const names=(await readdir(root,{recursive:true})).filter(name=>basename(name)===proof.worker.sessionId+'.jsonl');
  assert.equal(names.length,1);
  return readFile(join(root,names[0]));
 };
 await expect.poll(async()=>{
  const rows=(await journal()).toString().trim().split('\n').map(JSON.parse);
  return rows.filter(row=>row.type==='user'&&row.origin?.kind==='human'&&row.message?.content===proof.childFollowup).length;
 },{timeout:20000}).toBe(1);
 const bytes=await journal();
 const rows=bytes.toString().trim().split('\n').map(JSON.parse);
 assert.ok(rows.some(row=>Array.isArray(row.message?.content)&&row.message.content.some(block=>block.type==='tool_result'&&block.tool_use_id===original.tool_use_id&&Boolean(block.is_error)===Boolean(original.is_error)&&JSON.stringify(block.content)===JSON.stringify(original.content))));
 await writeFile(join(output,'native-child-transcript.jsonl'),bytes);
 response.childJournalSha256=sha(bytes);
 await sameParent();
 await save();
}


async function interruptBackgroundQuestionImage({page,expect,model,profileDir,widget,question,proof,output,image,context,sameParent,save}){
 const current=await context();
 const originalTurn=current.native.background.turn;
 const originalQuestion=Object.values(current.ui).find(view=>view.state?.question?.messageId)?.state.question;
 assert.ok(originalTurn?.id&&!originalTurn.cancelled&&originalQuestion?.messageId);
 const stop=widget.getByRole('button',{name:'Interrupt response',exact:true});
 await stop.click();
 await expect(question).toHaveCount(0);
 await expect.poll(async()=>{
  const active=(await context()).native.background;
  return active?.status==='done'&&(active.turn?.id!==originalTurn.id||active.turn.cancelled===true);
 },{timeout:15000}).toBe(true);
 assert.equal((await context()).native.background.session.sessionId,proof.worker.sessionId);
 assert.equal(await birth(proof.worker.pid),proof.workerStart);
 await sameParent();

 const form=widget.getByRole('form',{name:'Background session message',exact:true});
 const editor=form.locator('[contenteditable="true"]');
 await expect(editor).toBeEditable();
 await editor.fill('ResearchChildCancel2 Ask a fresh release branch question.');
 await form.getByRole('button',{name:'Send message',exact:true}).click();
 await expect(question).toBeVisible({timeout:15000});
 const next=Object.values((await context()).ui).find(view=>view.state?.question?.messageId)?.state.question;
 assert.ok(next?.messageId);
 assert.notEqual(next.messageId,originalQuestion.messageId);
 await expect(question.getByRole('button',{name:'Remove Branch-chart.png',exact:true})).toHaveCount(0);
 const stable=question.getByRole('radio',{name:'Stable Review the current release',exact:true});
 await expect(stable).not.toBeChecked();
 await stable.check();
 const submit=question.getByRole('button',{name:'Submit answers',exact:true});
 for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
  await page.setViewportSize(viewport);
  await stable.scrollIntoViewIfNeeded();
  await expect(stable).toBeInViewport({ratio:1});
  await expect(submit).toBeInViewport({ratio:1});
  const file='background-question-image-fresh-'+size+'.png';
  await page.screenshot({path:join(output,file),animations:'disabled'});
  proof.captures.push(file);
 }
 await submit.click();
 await expect(question).toHaveCount(0,{timeout:15000});
 const answered=()=>model.calls.find(call=>call.childCancellationRound==='2'&&call.childCancellationResult)?.childCancellationResult;
 await expect.poll(answered,{timeout:15000}).toBeTruthy();
 assert.ok(!answered().is_error&&JSON.stringify(answered().content).includes('Stable'));
 const root=join(profileDir,'projects'), names=(await readdir(root,{recursive:true})).filter(name=>basename(name)===proof.worker.sessionId+'.jsonl');
 assert.equal(names.length,1);
 const answer=answered();
 let journal;
 await expect.poll(async()=>{
  journal=await readFile(join(root,names[0]));
  const results=journal.toString().trim().split('\n').map(JSON.parse)
   .flatMap(row=>Array.isArray(row.message?.content)?row.message.content:[])
   .filter(block=>block.type==='tool_result');
  const canceled=results.filter(block=>block.tool_use_id==='toolu_child_cancellation_1');
  const fresh=results.filter(block=>block.tool_use_id===answer.tool_use_id);
  return canceled.length===1&&canceled[0].is_error===true&&fresh.length===1&&fresh[0].content===answer.content&&!fresh[0].is_error;
 },{timeout:15000}).toBe(true);
 const unsent=image.toString('base64');
 assert.ok(!journal.includes(unsent)&&!JSON.stringify(model.calls).includes(unsent));
 await writeFile(join(output,'native-child-transcript.jsonl'),journal);
 await sameParent();
 proof.unsentImageInterrupt={imageSha256:sha(image),journalSha256:sha(journal),originalTurn:originalTurn.id,originalMessage:originalQuestion.messageId,freshMessage:next.messageId,sameWorker:true,retainedAcrossParentReturn:true,freshAnswer:answer,noDeliveredImage:true};
 await save();
}


async function refuseBackgroundQuestionImage({page,expect,question,branch,submit,result,context,proof,output,sameParent}){
 const frame=async()=>Object.values((await context()).ui).find(view=>view.state?.question?.messageId)?.state.question;
 const first=await frame();
 assert.ok(first?.messageId&&first?.token);
 const bad=question.getByRole('button',{name:'Remove Broken-branch-chart.png',exact:true});
 const good=question.getByRole('button',{name:'Remove Branch-chart.png',exact:true});
 await expect(bad).toBeVisible();
 await expect(good).toBeVisible();
 await submit.click();
 const alert=question.getByRole('alert');
 const problem='Claude Code could not prepare an attached image. Remove it or replace it, then submit again.';
 await expect(alert).toHaveText(problem,{timeout:15000});
 const held=await frame();
 assert.equal(held.messageId,first.messageId);
 assert.equal(held.token,first.token);
 assert.equal(held.problem,problem);
 await expect(submit).toBeEnabled();
 await expect(branch).toBeChecked();
 await expect(bad).toHaveCount(1);
 await expect(good).toHaveCount(1);
 assert.equal(result(),undefined);
 assert.equal(await birth(proof.worker.pid),proof.workerStart);
 await sameParent();
 await capture('refusal',alert);
 await bad.click();
 await expect(bad).toHaveCount(0);
 await expect(good).toHaveCount(1);
 await expect(branch).toBeChecked();
 await capture('replacement',good);
 return {problem,questionId:held.messageId,sameWorker:true,choiceRetained:true,noPrematureResult:true};

 async function capture(stage,control){
  for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(viewport);
   await control.scrollIntoViewIfNeeded();
   await expect(control).toBeInViewport({ratio:1});
   await expect(submit).toBeInViewport({ratio:1});
   const file='background-invalid-question-image-'+stage+'-'+size+'.png';
   await page.screenshot({path:join(output,file),animations:'disabled'});
   proof.captures.push(file);
  }
 }
}
