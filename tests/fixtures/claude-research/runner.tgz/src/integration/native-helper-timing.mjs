import {Server} from 'node:http';
import {createHash} from 'node:crypto';

const routes=new Set(['/background-register','/background-status','/background-formatter','/native-status']);
const hash=value=>createHash('sha256').update(value).digest('hex');
/** Disposable-process observer: never reads request bodies or changes response bytes/return values. */
export function observeNativeHelperTiming(record,prototype=Server.prototype,{registrationDelayMs=0}={}){
 if(!Number.isSafeInteger(registrationDelayMs)||registrationDelayMs<0||registrationDelayMs>1000)throw Error('Invalid diagnostic registration delay');
 const emit=prototype.emit;let sequence=0,rejectionStacks=0;
 prototype.emit=function(event,...args){
  const [request,response]=args;
  if(event==='request'&&request?.method==='POST'&&routes.has(request.url)){
   const id=++sequence,path=request.url;
   record({id,path,phase:'request',monotonicNs:process.hrtime.bigint().toString()});
   const chunks=[];let bytes=0,rejectionStack;
   const collect=(chunk,encoding)=>{if(typeof chunk==='string'||Buffer.isBuffer(chunk)||chunk instanceof Uint8Array){const data=Buffer.from(chunk,typeof encoding==='string'?encoding:undefined);bytes+=data.length;if(bytes<=131072)chunks.push(data)}};
   const write=response.write,end=response.end;
   response.write=function(...values){collect(values[0],values[1]);return Reflect.apply(write,this,values)};
   response.end=function(...values){
    collect(values[0],values[1]);
    if(path==='/background-status'&&this.statusCode===409&&rejectionStacks++<64)rejectionStack=String(new Error('Background status refused').stack??'').slice(0,4096);
    // Delay only delivery of a real successful identity response. No identity, policy or helper
    // outcome is synthesized; the original worker keeps running while registration is in flight.
    if(path==='/background-register'&&this.statusCode===200&&registrationDelayMs){setTimeout(()=>Reflect.apply(end,this,values),registrationDelayMs);return this}
    return Reflect.apply(end,this,values)
   };
   response.once('finish',()=>{
    const result={id,path,phase:'finish',monotonicNs:process.hrtime.bigint().toString(),statusCode:response.statusCode,truncated:bytes>131072,...(rejectionStack?{rejectionStack}:{})};
    if(!result.truncated){try{
     const body=JSON.parse(Buffer.concat(chunks).toString());
     if(path==='/background-register'&&typeof body.token==='string')result.leaseHash=hash(body.token);
     if(path==='/background-status'&&typeof body.shellPrefix==='string'){
      result.hasPrefix=true;
      const split=body.shellPrefix.lastIndexOf(' -');
      if(split>0){const config=JSON.parse(Buffer.from(body.shellPrefix.slice(split+2),'base64url').toString());
       if(typeof config.sessionId==='string'&&Number.isSafeInteger(config.pid)&&typeof config.generation==='string'&&typeof config.token==='string'){
        result.formatter={sessionId:config.sessionId,pid:config.pid,generation:config.generation,leaseHash:hash(config.token)};
       }
      }
     }
    }catch{result.unparsed=true}}
    record(result);
   });
  }
  return Reflect.apply(emit,this,[event,...args]);
 };
 const installed=prototype.emit;
 return()=>{if(prototype.emit===installed)prototype.emit=emit};
}
