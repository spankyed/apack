/** Response receipts and an explicitly armed connection cut for the owned Linux app broker. */
import http from 'node:http';
import {appendFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {syncBuiltinESMExports} from 'node:module';
const destination=process.env.CLAUDE_RESEARCH_BACKGROUND_BROKER_AUDIT;
if(destination){
 if(process.platform!=='linux'||!existsSync('/.dockerenv')||!destination.startsWith('/work/.claude-research/'))throw Error('Background broker audit requires the owned Linux workspace');
 const original=http.createServer;let count=0;
 http.createServer=function(...args){
  const at=args.findIndex(value=>typeof value==='function');
  if(at>=0){const listener=args[at];args[at]=function(request,response){
   if(request.url==='/background-status'&&existsSync(destination+'.disconnect')){queueMicrotask(()=>this.closeAllConnections());return;}
   if(['/background-register','/background-status','/background-formatter'].includes(request.url)){
    const chunks=[];let bytes=0;request.on('data',chunk=>{bytes+=chunk.length;if(bytes<=262144)chunks.push(Buffer.from(chunk));});
    const end=response.end;
    response.end=function(...values){
     if(count++<1024){let body;try{body=JSON.parse(String(values[0]??''));}catch{}
      const leaseHash=typeof body?.token==='string'?createHash('sha256').update(body.token).digest('hex'):null;
      let input;try{if(bytes<=262144)input=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{}
      const formatterAudit=process.env.CLAUDE_RESEARCH_BACKGROUND_FORMATTER_LIFECYCLE_APP==='1';
      appendFileSync(destination,JSON.stringify({at:Date.now(),pid:process.pid,path:request.url,status:response.statusCode,leaseHash,...formatterAudit?{input,reply:body}:{} })+'\n',{mode:0o600});
     }
     return end.apply(this,values);
    };
   }
   return listener.apply(this,arguments);
  };}
  return original.apply(this,args);
 };
 syncBuiltinESMExports();
}
