import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs';
import { readCombinedEverydayJournal } from './apack-combined-everyday-drive.mjs';
import { processStart } from './native-process-state.mjs';
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs';
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs';
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs';
import { agentCompaction as scenario, startSyntheticAgentCompactionModel } from '../protocol/synthetic-agent-compaction-model.mjs';

export async function driveAgentCompaction({ checkout, workspace, env }) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly);
  const project = join(workspace, 'project');
  const agents = join(project, '.claude/agents');
  await mkdir(agents, { recursive: true });
  const definition = join(agents, scenario.agent + '.md');
  await writeFile(definition, [
    '---', 'name: ' + scenario.agent, 'description: Review the release checklist', 'tools: Read',
    'autoCompactWindow: 100000', 'maxTurns: 5', '---', scenario.instruction + '. Read the checklist and report.',
  ].join('\n') + '\n');
  execFileSync('/usr/bin/git', ['init', '--quiet', project], {
    env: { PATH: '/usr/bin:/bin', HOME: workspace, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_NOSYSTEM: '1' }, timeout: 5000,
  });
  const files = await Promise.all(scenario.fileContents.map(async (text, index) => {
    const path = join(project, 'checklist-' + (index + 1) + '.txt');
    await writeFile(path, text + '\n');
    return path;
  }));

  const account = await configureNativeCreditAccount(workspace, 'oauth', { featureCache: 'native-defaults' });
  const configDir = join(workspace, '.claude');
  const configPath = join(configDir, '.claude.json'), settingsPath = join(configDir, 'settings.json');
  const config = JSON.parse(await readFile(configPath, 'utf8'));
  config.hasCompletedOnboarding = true;
  const configBefore = JSON.stringify(config), settingsBefore = JSON.stringify({ theme: 'dark', model: 'sonnet' });
  await writeFile(configPath, configBefore);
  await writeFile(settingsPath, settingsBefore);
  const model = await startSyntheticAgentCompactionModel(files);
  const proof = { captures: [], status: 'running' };
  let billing;
  try {
    const tls = await prepareNativeCreditTls(join(workspace, 'account-tls'));
    billing = await startNativeCreditBilling(tls, { allowMutations: false, evidencePath: join(workspace, 'account-live.json') });
    const launchEnv = { ...env, ...account, NODE_EXTRA_CA_CERTS: tls.ca, ANTHROPIC_BASE_URL: model.url,
      DISABLE_AUTOUPDATER: '1', PATH: '/frozen-claude:' + env.PATH, CLAUDE_RESEARCH_PROJECT: project };
    delete launchEnv.ANTHROPIC_API_KEY;
    await driveFreshNativeApp({ checkout, workspace, env: launchEnv, route: 'real-Electron-agent-compaction',
      journeyBudgetMs: 145000, journey: args => journey({ ...args, configDir, model, proof }) });
  } finally {
    await model.close();
    await billing?.close();
    const output = join(workspace, 'electron-results');
    await mkdir(output, { recursive: true });
    await writeFile(join(output, 'model-calls.json'), JSON.stringify({ calls: model.calls, errors: model.errors }, null, 2));
    await writeFile(configPath, configBefore);
    assert.equal(await readFile(configPath, 'utf8'), configBefore);
    assert.equal(await readFile(settingsPath, 'utf8'), settingsBefore);
    await writeFile(join(output, 'profile-restoration.json'), JSON.stringify({ restored: true }));
  }
}

async function journey({ app, page, electronApp, output, project, userDataDir, expect, phase, configDir, model, proof }) {
  const save = () => writeFile(join(output, 'agent-compaction.json'), JSON.stringify(proof, null, 2));
  const context = () => page.evaluate(() => {
    const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    const thread = c.currentThread;
    return { thread: thread?.id, claude: thread?.context?.claudeCode, messages: thread?.messages ?? [],
      native: Object.values(c.nativeTerminalViews).find(view => view.threadId === thread?.id)?.state };
  });
  const card = page.locator('[data-onboarding-id="agent-chat-input"]');
  const composer = card.locator('[contenteditable="true"]');
  const send = card.getByRole('button', { name: 'Send', exact: true });
  const section = page.getByRole('region', { name: 'Claude native interface', exact: true });
  const parentDraft = 'Keep the parent release notes while I inspect the worker.';
  const workerDraft = 'Keep the Agent follow-up as a draft.';
  const sendPrompt = async text => {
    await composer.fill(text);
    await expect(composer).toHaveText(text);
    await send.click();
  };
  try {
    await app.waitForSurface('default-setup/threads');
    await app.navigate('host/settings');
    await page.evaluate(() => {
      const settings = window.applicationState.system.get('host/settings');
      settings.send({ type: 'TAB.SELECT', tab: 'general' });
      settings.send({ type: 'GENERAL_NAV.SELECT', item: 'secrets' });
    });
    const provider = page.getByText('Claude Code CLI', { exact: true }).locator('..').locator('..').locator('..');
    await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');
    await page.waitForTimeout(700);
    await app.navigate('default-setup/threads');
    await expect.poll(() => page.evaluate(() => {
      const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
      return !!c.currentThread?.id && c.tabs.every(tab => c.tabsRead.includes(tab.id));
    }), { timeout: 15000 }).toBe(true);
    await page.evaluate(directory => {
      const threads = window.applicationState.system.get('default-setup/threads');
      threads.send({ type: 'NEW_THREAD_IN_PROJECT', directory });
      threads.send({ type: 'SET_MODE', mode: 'Claude Code' });
      threads.send({ type: 'SET_PHASE', phase: 'Edit' });
    }, project);
    await sendPrompt(scenario.seedPrompt);
    await expect.poll(async () => (await context()).messages.some(row => row.sender === 'assistant' && row.text === scenario.seedReply), { timeout: 30000 }).toBe(true);
    proof.session = (await context()).claude.sessionId;
    await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
    const lastSent = new Map();
    const terminal = section.locator('[data-terminal-text]').first();
    for (let i = 0; i < 120 && (await context()).native?.status !== 'live'; i++) {
      const text = await terminal.textContent({ timeout: 1000 }).catch(() => '');
      const prompt = recognizeOnboardingPrompt(text ?? '', project);
      if (prompt && Date.now() - (lastSent.get(prompt) ?? 0) >= 1000) {
        const input = section.locator('[aria-label="Terminal input"]');
        await electronApp.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0]?.focus());
        await input.focus();
        if (prompt.startsWith('workspace-trust')) await page.waitForTimeout(200);
        await input.press(prompt === 'workspace-trust' ? 'ArrowDown' : 'Enter');
        lastSent.set(prompt, Date.now());
      }
      await page.waitForTimeout(100);
    }
    await expect.poll(async () => (await context()).native?.status, { timeout: 25000 }).toBe('live');
    proof.owner = (await context()).native;
    proof.processStart = await processStart(proof.owner.nativePid);
    assert.ok(proof.processStart);
    assert.equal(proof.owner.sessionId, proof.session);
    await section.getByRole('button', { name: 'Back to conversation', exact: true }).click();
    await sendPrompt(scenario.launchPrompt);
    const completedWorker = async () => (await context()).native?.tasks.find(task =>
      task.name === scenario.agent && task.status === 'completed');
    await expect.poll(async () => (await completedWorker())?.id, { timeout: 22000 }).toBeTruthy();
    phase('worker-completed');
    proof.taskId = (await completedWorker()).id;
    const workerCalls = model.calls.filter(call => call.child);
    assert.equal(workerCalls.filter(call => call.tool === 'Read').length, 3);
    assert.equal(workerCalls.filter(call => call.compacting).length, 1);
    assert.ok(workerCalls.at(-1).receivedSummary && workerCalls.at(-1).receivedFinalRead);
    const journal = await readCombinedEverydayJournal(userDataDir, proof.session, proof.taskId, configDir);
    await writeFile(join(output, 'worker-journal.jsonl'), journal);
    const records = journal.toString().trim().split('\n').map(JSON.parse);
    const [boundary] = records.filter(row => row.type === 'system' && row.subtype === 'compact_boundary');
    const [summary] = records.filter(row => row.isCompactSummary && JSON.stringify(row.message).includes(scenario.summary));
    assert.equal(boundary?.compactMetadata?.trigger, 'auto');
    assert.ok(summary?.uuid);
    proof.boundary = { uuid: boundary.uuid, trigger: boundary.compactMetadata.trigger, summaryId: summary.uuid };
    const tools = page.getByRole('button', { name: /^Native tools/ }).first();
    await expect(tools).toBeVisible();
    if (await tools.getAttribute('aria-expanded') !== 'true') await tools.click();
    const row = page.locator('[data-native-agent-id]').filter({ has: page.getByRole('button', { name: 'Open Agent', exact: true }) }).first();
    await expect(row).toBeVisible();
    assert.equal(await row.getAttribute('data-native-agent-id'), proof.taskId);
    const sizes = [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]];
    const markerSelector = '[data-native-agent-message="' + boundary.uuid + '"]';
    const summarySelector = '[data-native-agent-message="' + summary.uuid + '"] details';
    const inline = row.getByRole('region', { name: 'Agent conversation', exact: true });
    const inlineToggle = inline.locator(summarySelector).locator('summary');
    await composer.fill(parentDraft);
    await row.getByRole('button', { name: 'View Agent conversation', exact: true }).click();
    await expect(inline.locator(markerSelector)).toHaveText('Conversation compacted');
    await expect(inlineToggle).toHaveText('Compact summary');
    const inlineText = inline.locator(summarySelector).locator('p');
    proof.inlineDisclosures = [];
    for (const [size, viewport] of sizes) {
      await page.setViewportSize(viewport);
      await expect(inlineText).toBeHidden();
      await inlineToggle.scrollIntoViewIfNeeded();
      await inlineToggle.press('Enter');
      await expect(inlineText).toContainText(scenario.summary);
      await expect(inlineText).toBeVisible();
      await expect(inlineToggle).toBeInViewport();
      proof.inlineDisclosures.push({ size, boundaryUuid: boundary.uuid, summaryUuid: summary.uuid });
      const capture = 'agent-inline-compact-summary-' + size + '.png';
      await page.screenshot({ path: join(output, capture), animations: 'disabled' });
      proof.captures.push(capture);
      await inlineToggle.press('Enter');
      await expect(inlineText).toBeHidden();
    }
    await row.getByRole('button', { name: 'Hide Agent conversation', exact: true }).click();
    await expect(inline).toBeHidden();
    await expect(composer).toHaveText(parentDraft);
    await row.getByRole('button', { name: 'Open Agent', exact: true }).click();
    const focused = page.getByRole('region', { name: 'Focused Agent conversation', exact: true });
    const editor = focused.getByRole('form', { name: 'Agent message', exact: true }).locator('[contenteditable="true"]');
    await editor.fill(workerDraft);
    await expect(editor).toHaveText(workerDraft);
    const transcript = focused.getByRole('region', { name: 'Agent transcript', exact: true });
    const marker = focused.locator(markerSelector);
    const disclosure = focused.locator(summarySelector);
    const jump = focused.getByRole('button', { name: 'Jump to latest Agent message', exact: true });
    const toggle = disclosure.locator('summary');
    await expect(marker).toHaveText('Conversation compacted');
    await expect(toggle).toHaveText('Compact summary');
    await expect(disclosure.locator('p')).toBeHidden();
    proof.focusedDisclosures = [];
    for (const [size, viewport] of sizes) {
      await page.setViewportSize(viewport);
      const viewportBox = await transcript.boundingBox();
      const markerBox = await marker.boundingBox();
      assert.ok(viewportBox && markerBox);
      await page.mouse.move(viewportBox.x + viewportBox.width / 2, viewportBox.y + viewportBox.height / 2);
      await page.mouse.wheel(0, Math.round(markerBox.y - viewportBox.y - 8));
      await expect(marker).toBeInViewport();
      await toggle.focus();
      await toggle.press('Enter');
      await expect(disclosure.locator('p')).toContainText(scenario.summary);
      await expect(disclosure.locator('p')).toBeInViewport();
      await expect(marker).toBeInViewport();
      await expect(editor).toBeInViewport();
      await expect(jump).toBeVisible();
      const scrollBounds = await transcript.boundingBox();
      const jumpBounds = await jump.boundingBox();
      assert.ok(scrollBounds && jumpBounds && scrollBounds.x + scrollBounds.width <= jumpBounds.x,
        'Jump to latest overlaps the Agent transcript');
      proof.focusedDisclosures.push({ size, transcriptRight: scrollBounds.x + scrollBounds.width, jumpLeft: jumpBounds.x });
      const capture = 'agent-compact-summary-' + size + '.png';
      await page.screenshot({ path: join(output, capture), animations: 'disabled' });
      proof.captures.push(capture);
      await toggle.press('Enter');
      await expect(disclosure.locator('p')).toBeHidden();
    }
    await jump.press('Enter');
    await expect(jump).toBeHidden();
    await expect(transcript).toBeFocused();
    await expect.poll(() => transcript.evaluate(element =>
      Math.abs(element.scrollHeight - element.clientHeight - element.scrollTop))).toBeLessThan(2);
    proof.jumpRestoredTranscriptFocus = true;
    await expect(editor).toHaveText(workerDraft);
    await focused.getByRole('button', { name: 'Back to conversation', exact: true }).click();
    await expect(composer).toHaveText(parentDraft);
    assert.equal((await context()).claude.sessionId, proof.session);
    await sendPrompt(scenario.continuationPrompt);
    await expect.poll(async () => (await context()).messages.some(row => row.sender === 'assistant' && row.text === scenario.continuationReply), { timeout: 22000 }).toBe(true);
    const continued = await context();
    assert.equal(continued.claude.sessionId, proof.session);
    assert.equal(continued.native.ownerId, proof.owner.ownerId);
    assert.equal(await processStart(proof.owner.nativePid), proof.processStart);
    await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
    await section.getByRole('button', { name: 'Stop session', exact: true }).click();
    await expect.poll(() => processStart(proof.owner.nativePid), { timeout: 15000 }).not.toBe(proof.processStart);
    assert.deepEqual(model.errors, []);
    assert.ok(!model.calls.some(call => !call.child && (call.compacting || call.receivedSummary)));
    proof.status = 'complete';
    proof.drafts = { parentDraft, workerDraft };
    proof.continued = { sessionId: continued.claude.sessionId, ownerId: continued.native.ownerId, nativeRetired: true };
    phase('agent-compaction-complete');
  } catch (error) {
    proof.status = 'failed';
    proof.error = { message: error.message, stack: error.stack };
    proof.observed = await context().catch(() => undefined);
    await page.screenshot({ path: join(output, 'agent-compaction-failure.png') }).catch(() => {});
    throw error;
  } finally {
    await save();
  }
}
