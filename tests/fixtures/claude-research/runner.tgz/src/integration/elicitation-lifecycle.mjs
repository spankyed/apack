import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,realpath,stat,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createRun,hash} from '../artifacts/runs.mjs';
import {record} from '../protocol/record.mjs';

export async function probeElicitationLifecycle(checkout,executable,root,output){
 checkout=await realpath(checkout);assert.ok((await stat(join(checkout,'.git'))).isFile(),'Use the isolated linked worktree');
 assert.equal(await realpath(join(checkout,'node_modules')),join(checkout,'node_modules'),'Do not share node_modules');
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'elicitation-owner-'));await mkdir(join(workspace,'.claude'));
 const driver=fileURLToPath(new URL('./elicitation-lifecycle-driver.mjs',import.meta.url)),sourceHashes={};
 for(const name of ['query.ts','conversation.ts','runner.ts','types.ts','args.ts','control.ts','hooks.ts','host-controls.ts','nested-activity.ts','background-tasks.ts','../../../shared/mcp-elicitation-form.ts'])sourceHashes[name]=hash(await readFile(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code',name)));
 const run=await createRun(output,'elicitation-owner-lifecycle',{targetSha256:hash(await readFile(executable)),baseCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:checkout,encoding:'utf8'}).trim(),sourceHashes,driverSha256:hash(await readFile(driver)),orchestratorSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('../protocol/synthetic-model.mjs',import.meta.url))),serverSha256:hash(await readFile(new URL('../protocol/synthetic-elicitation-server.mjs',import.meta.url)))});
 try{
  const transport=await record({executable:process.execPath,cwd:checkout,args:['--import',join(checkout,'node_modules/tsx/dist/loader.mjs'),driver,checkout,executable,workspace],env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},output,timeoutMs:65000});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);
  const stdout=await readFile(join(transport.directory,'stdout.bin'),'utf8'),evidence=stdout.split('\n').filter(line=>line.startsWith('{')).map(line=>JSON.parse(line)).find(value=>value.evidence==='native-elicitation-owner-lifecycle');
  assert.ok(evidence);assert.deepEqual(evidence.cases.map(value=>[value.mode,value.ending]),[['form','interrupt'],['form','kill'],['url','interrupt'],['url','kill']]);assert.equal(evidence.realModelRequests,0);
  for(const value of evidence.cases){for(const key of ['requestRetired','lateResponseRejected','lateInputRejected','resultRejected'])assert.equal(value[key],true);assert.equal(value.localModelRequests,1);assert.equal(value.permissionCount,1);assert.equal(value.busy,false);if(value.ending==='interrupt'){assert.deepEqual(value.serverAnswer,{action:'cancel'});assert.equal(value.nativeWithdrawal,true);}}
  for(const[name,sha]of Object.entries(sourceHashes))assert.equal(hash(await readFile(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code',name))),sha);
  await writeFile(join(run.directory,'elicitation-owner-lifecycle.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
