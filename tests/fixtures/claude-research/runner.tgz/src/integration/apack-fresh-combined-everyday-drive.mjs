import { prepareNativePartialPdf } from './native-partial-pdf-profile.mjs';
import { prepareNativeGlyphFonts } from './native-glyph-fonts.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { nativeReadImageFormats, nativeReadSvgFile, nativeReadGifCases, nativeReadPartialPdf } from '../protocol/native-read-image-formats.mjs';
import { prepareFleetFooterWorker } from './native-fleet-footer-worker.mjs';
import assert from 'node:assert/strict';
import {copyFile,mkdir,readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {combinedJourney,readCombinedEverydayJournal} from './apack-combined-everyday-drive.mjs';
import {prepareFreshCombinedEverydayProfile} from './combined-everyday-profile.mjs';
import {startCombinedEverydayModel} from '../protocol/combined-everyday-model.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {holdOwnedPromptDelivery} from './owned-prompt-delivery-hold.mjs';
import {preparePromptReplacementPlugin} from './prompt-replacement-plugin.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function alive(pid,start){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]!=='Z'&&fields[19]===start}catch(error){if(error.code==='ENOENT')return false;throw error}}

/** Existing combined everyday interactions against the normal shared-profile default, with fresh owned data. */
export async function driveFreshCombinedEveryday({checkout,workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
 const project=join(workspace,'project');await mkdir(project);await writeFile(join(project,'release-notes.md'),'# Release notes\n\nDescribe the behavior changes and migration guidance.\n');execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),configPath=join(workspace,'.claude/.claude.json'),settingsPath=join(workspace,'.claude/settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({theme:'dark',model:'opus'}));const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath);
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,defaultProfile:'shared',config,settings:JSON.parse(settingsBefore)},null,2));
 const agentStatusTransitions=env.CLAUDE_RESEARCH_COMBINED_AGENT_STATUS_TRANSITIONS==='1';
 const verifyAgentStatusFocus=env.CLAUDE_RESEARCH_AGENT_STATUS_FOCUS==='1';
 const keepLongAgentStatus=env.CLAUDE_RESEARCH_KEEP_LONG_AGENT_STATUS==='1';
 assert.ok(!keepLongAgentStatus||verifyAgentStatusFocus);
 assert.ok(!verifyAgentStatusFocus||agentStatusTransitions);
 const verifyReadImageFormats=env.CLAUDE_RESEARCH_READ_IMAGE_FORMATS==='1';
 const verifyReadSvg=env.CLAUDE_RESEARCH_READ_SVG==='1';
 const verifyReadGif=env.CLAUDE_RESEARCH_READ_GIF==='1';
 const verifyPartialPdf=env.CLAUDE_RESEARCH_PARTIAL_PDF==='1';
 const readImageCases=verifyPartialPdf?[nativeReadPartialPdf]:verifyReadGif?nativeReadGifCases:verifyReadSvg?[nativeReadSvgFile]:verifyReadImageFormats?nativeReadImageFormats:undefined;
 const verifyReadClear=env.CLAUDE_RESEARCH_HELD_READ_CLEAR==='1';
 const profile=await prepareFreshCombinedEverydayProfile({workspace,agentStatusTransitions});let model,billing,promptPlugin,fleetFooterWorker;
 try{
  if(readImageCases){
   if(!verifyPartialPdf)for(const item of readImageCases)await copyFile(new URL('../../fixtures/native-read-image-formats/'+item.file,import.meta.url),join(project,item.file));
   model=await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:16,readImageFormats:verifyPartialPdf?'pdf':verifyReadGif?'gif':verifyReadSvg?'svg':true,textReply:'Ready to review the release notes.'});
  }else if(verifyReadClear)model=await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:12,textReply:'The native draft-read replay is ready.'});
  else model=await startCombinedEverydayModel({workspace,project,maxRequests:32,agentReadingProbe:true,holdWorker:agentStatusTransitions});
  const tls=await prepareNativeCreditTls(join(workspace,'account-tls'));billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
  const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  const verifyPromptEditReplacement=env.CLAUDE_RESEARCH_PROMPT_EDIT_REPLACEMENT==='1';
  const verifyPromptControlReplacement=env.CLAUDE_RESEARCH_PROMPT_CONTROLS_REPLACEMENT==='1';
  const promptRetiredBeforeExpiry=env.CLAUDE_RESEARCH_PROMPT_RETIRED_BEFORE_EXPIRY==='1';
  const measurePromptCompletionLayout=env.CLAUDE_RESEARCH_PROMPT_COMPLETION_LAYOUT==='1';
  const verifyCompletionWindowFocus=env.CLAUDE_RESEARCH_COMPLETION_WINDOW_FOCUS==='1';
  const measureAgentFooter=env.CLAUDE_RESEARCH_AGENT_FOOTER==='1';
  const verifyRestingAgentHint=env.CLAUDE_RESEARCH_RESTING_AGENT_HINT==='1';
  const verifyFleetWaitingHint=env.CLAUDE_RESEARCH_FLEET_WAITING_HINT==='1';
  const verifyResetImage=env.CLAUDE_RESEARCH_COMBINED_RESET_IMAGE==='1';
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
 assert.ok(boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
 assert.equal(verifyReadClear,boundary.requireHeldReadClear===true);
 assert.equal(agentStatusTransitions,boundary.requireAgentStatusTransitions===true);
 assert.equal(verifyAgentStatusFocus,boundary.requireAgentStatusFocus===true);
 assert.equal(keepLongAgentStatus,boundary.requireLongAgentStatusThroughCompletion===true);
 assert.equal(verifyRestingAgentHint,boundary.requireRestingAgentHint===true);
 assert.equal(verifyFleetWaitingHint,boundary.requireFleetWaitingHint===true);
 assert.equal(verifyReadImageFormats,boundary.requireReadImageFormats===true);
 assert.equal(verifyReadSvg,boundary.requireReadSvg===true);
 assert.equal(verifyReadGif,boundary.requireReadGif===true);
 assert.equal(verifyPartialPdf,boundary.requirePartialPdf===true);
 if(verifyPartialPdf)launchEnv.PATH=(await prepareNativePartialPdf(workspace,project))+':'+launchEnv.PATH;
 if(boundary.requireImageGlyphOverlay){
  assert.ok(readImageCases);
  Object.assign(launchEnv,await prepareNativeGlyphFonts(workspace,launchEnv,{toolResultBranch:true}));
 }
 if(verifyFleetWaitingHint){
  const config=JSON.parse(await readFile(configPath,'utf8'));
  await writeFile(configPath,JSON.stringify({...config,projects:{...config.projects,[project]:{...config.projects?.[project],hasTrustDialogAccepted:true}}}));
  fleetFooterWorker=await prepareFleetFooterWorker({workspace,project,env:launchEnv});
 }
  assert.ok([verifyReadClear,verifyPromptEditReplacement,verifyPromptControlReplacement,measurePromptCompletionLayout,verifyRestingAgentHint,verifyFleetWaitingHint,verifyReadImageFormats,verifyReadSvg,verifyReadGif,verifyPartialPdf].filter(Boolean).length<=1);
  assert.ok(!promptRetiredBeforeExpiry||verifyPromptControlReplacement);
  assert.ok(!measureAgentFooter||measurePromptCompletionLayout);
  assert.ok(!verifyCompletionWindowFocus||(measurePromptCompletionLayout&&!measureAgentFooter));
  if(verifyReadClear||verifyPromptControlReplacement||measurePromptCompletionLayout){
   promptPlugin=await preparePromptReplacementPlugin({workspace,project,env:launchEnv,readClear:verifyReadClear});
   await promptPlugin.install();
  }
  let promptEditHold;
  const preparePage=(verifyPromptEditReplacement||verifyPromptControlReplacement||verifyCompletionWindowFocus)?async page=>{
   promptEditHold=await holdOwnedPromptDelivery(page);
   await page.reload({waitUntil:'domcontentloaded',timeout:30000});
  }:undefined;
  const route=verifyReadClear?'real-Electron-cleared-held-prompt-read':verifyPartialPdf?'real-Electron-partial-native-pdf':verifyReadGif?'real-Electron-native-gif-file-read':verifyReadSvg?'real-Electron-native-svg-file-read':verifyReadImageFormats?'real-Electron-native-read-image-formats':verifyFleetWaitingHint?'real-Electron-fleet-waiting-hint':verifyRestingAgentHint?'real-Electron-resting-agent-hint':verifyCompletionWindowFocus?'real-Electron-prompt-completion-window-focus':measurePromptCompletionLayout?'real-Electron-prompt-completion-layout':verifyPromptControlReplacement?'real-Electron-prompt-controls-replacement':verifyPromptEditReplacement?'real-Electron-prompt-edit-replacement':'real-Electron-fresh-combined-everyday';
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route,journeyBudgetMs:verifyPromptEditReplacement?120000:165000,preparePage,journey:async args=>{
   try{
    await combinedJourney({...args,profile,model,verifyAttachmentRecovery:boundary.requireAttachmentRecovery===true,agentStatusTransitions,verifyAgentStatusFocus,keepLongAgentStatus,agentReadingProbe:true,agentFormattingProbe:true,agentRapidSelectionProbe:env.CLAUDE_RESEARCH_AGENT_RAPID_SELECTION==='1',freshProfile:true,verifySessionReset:true,verifyResetImage,verifyPermissionOwnership:true,verifyMemoryRoundTrip:boundary.requireMemoryRoundTrip===true,verifyCompactAgentWorkspace:boundary.requireCompactAgentWorkspace===true,verifyQuestionAttachment:boundary.requireQuestionAttachment===true,verifyWindowControls:env.CLAUDE_RESEARCH_EVERYDAY_WINDOWS==='1',verifyStaleWindowResponses:env.CLAUDE_RESEARCH_STALE_WINDOW_RESPONSES==='1',verifyStableToolDisclosure:env.CLAUDE_RESEARCH_REQUIRE_STABLE_TOOL_DISCLOSURE==='1',verifyWorkspaceHeader:env.CLAUDE_RESEARCH_REQUIRE_WORKSPACE_HEADER==='1',measureResetFooter:env.CLAUDE_RESEARCH_MEASURE_RESET_FOOTER==='1',promptEditHold,verifyPromptControlReplacement,promptRetiredBeforeExpiry,measurePromptCompletionLayout,measureAgentFooter,verifyCompletionWindowFocus,verifyRestingAgentHint,fleetFooterWorker,readImageCases,verifyReadClear});
   }finally{await promptEditHold?.close();}
  }});
  const output=join(workspace,'electron-results'),path=join(output,'combined-everyday.json'),proof=JSON.parse(await readFile(path,'utf8')),userDataDir=join(workspace,'app-data');
  const main=await readCombinedEverydayJournal(userDataDir,proof.parentSessionId,undefined,profile.configDir);
  await writeFile(join(output,'native-parent-transcript.jsonl'),main);
  if(verifyReadClear){
   const p=proof.promptReadClear;
   assert.ok(proof.nativeWriterRetired&&proof.status==='complete'&&p.old.releasedAt<p.deadline);
   const fresh=await readCombinedEverydayJournal(userDataDir,p.replacement.claude.sessionId,undefined,profile.configDir);
   await writeFile(join(output,'native-fresh-transcript.jsonl'),fresh);
   const summaries=[main,fresh].map(journal=>{
    const rows=journal.toString().trim().split('\n').map(JSON.parse);
    const userRows=rows.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&!row.isSidechain
       &&(row.origin===undefined||row.origin.kind==='human'));
    const isClear=row=>typeof row.message.content==='string'&&row.message.content.startsWith('<command-name>/clear</command-name>');
    const humans=userRows.filter(row=>!isClear(row)).map(row=>row.message.content);
    return {humans,clearRecords:userRows.filter(isClear).length,cost:rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD??0,sha256:sha(journal)};
   });
   assert.deepEqual(summaries[0].humans,['Help me review the release notes and checklist.']);
   assert.deepEqual(summaries[1].humans,[p.freshText]);
   assert.deepEqual(summaries.map(row=>row.clearRecords),[0,1]);
   assert.equal(summaries[1].cost,proof.final.claude.totalCostUsd);
   const helpers=await profile.invocations();
   assert.ok((await Promise.all(helpers.map(row=>alive(row.pid,row.start)))).every(value=>!value));
   p.journals=summaries;p.helpersRetired=true;
   await writeFile(path,JSON.stringify(proof,null,2));
   return;
  }
  if(readImageCases){
   assert.equal(proof.imageFormats?.length,readImageCases.length);
   assert.ok(proof.nativeWriterRetired&&proof.resumedPrintSameSession);
   return;
  }
  if(verifyRestingAgentHint||verifyFleetWaitingHint){
   assert.ok((proof.fleetWaitingHint??proof.restingAgentHint)?.captures.length===4&&proof.nativeWriterRetired);
   return;
  }
  if(measurePromptCompletionLayout){
   assert.ok(proof.promptCompletionLayout&&proof.nativeWriterRetired);
   if(verifyCompletionWindowFocus)assert.deepEqual(proof.promptCompletionLayout.windowFocus.map(entry=>entry.owner),['main','agent']);
   return;
  }
  if(verifyPromptEditReplacement||verifyPromptControlReplacement){
   const entry=proof.promptEditReplacement??proof.promptControlsReplacement, rows=main.toString().trim().split('\n').map(JSON.parse);
   const humans=rows.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&!row.isSidechain
    &&(row.origin===undefined||row.origin.kind==='human')).flatMap(row=>{
     const content=row.message?.content;
     const text=typeof content==='string'?content:Array.isArray(content)&&content.length&&content.every(block=>block.type==='text')?content.map(block=>block.text).join(''):undefined;
     return text===undefined?[]:[{uuid:row.uuid,text}];
    });
   const displayed=proof.final.messages.filter(message=>message.sender==='user'&&message.context?.cliUuid)
    .map(message=>({uuid:message.context.cliUuid,text:message.text}));
   const cost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;
   assert.equal(humans.length,2);
   assert.deepEqual(humans,displayed);
   assert.equal(humans.at(-1).text,entry.followup);
   assert.ok(cost>0&&cost===proof.final.claude.totalCostUsd);
   Object.assign(entry,{journalSha256:sha(main),persistedCost:cost,followupUuid:humans.at(-1).uuid});
   await writeFile(path,JSON.stringify(proof,null,2));
   return;
  }
  const worker=await readCombinedEverydayJournal(userDataDir,proof.parentSessionId,proof.taskId,profile.configDir);
  await writeFile(join(output,'native-agent-transcript.jsonl'),worker);
  const reset=proof.reset;
  assert.ok(reset.writerRetired&&reset.sessionId!==proof.parentSessionId);
  const freshJournal=await readCombinedEverydayJournal(userDataDir,reset.sessionId,undefined,profile.configDir);
  const rows=freshJournal.toString().split('\n').filter(Boolean).map(JSON.parse);
  const humans=rows.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&
   (row.origin===undefined||row.origin.kind==='human')).map(row=>({
    uuid:row.uuid,
    text:typeof row.message.content==='string'?row.message.content:
     row.message.content.filter(block=>block.type==='text').map(block=>block.text).join(''),
   }));
  const displayed=reset.followup.messages.find(message=>message.sender==='user'&&message.text===(reset.image?.submittedText??reset.prompt));
  assert.ok(displayed?.context?.cliUuid);
  assert.equal(humans.length,2);
  const [command,reply]=humans;
  assert.deepEqual(command.text.split('\n').map(line=>line.trim()),[
   '<command-name>/clear</command-name>',
   '<command-message>clear</command-message>',
   '<command-args></command-args>',
  ]);
  assert.ok(command.uuid&&command.uuid!==reply.uuid);
  assert.deepEqual(reply,{uuid:displayed.context.cliUuid,text:reset.image?.submittedText??reset.prompt});
  const resetCost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;
  assert.ok(resetCost>0);
  assert.equal(resetCost,reset.followup.claude.totalCostUsd);
  await writeFile(join(output,'native-reset-transcript.jsonl'),freshJournal);
  Object.assign(reset,{journalSha256:sha(freshJournal),persistedCost:resetCost});
  const costs=main.toString().split('\n').filter(Boolean).map(JSON.parse).filter(row=>row.type==='cost-state');assert.equal(costs.at(-1)?.totalCostUSD,proof.final.claude.totalCostUsd);proof.persistedCost=costs.at(-1).totalCostUSD;proof.journals={parentSha256:sha(main),agentSha256:sha(worker)};proof.allInvocations=await profile.invocations();proof.helperWritersRetired=(await Promise.all(proof.allInvocations.map(row=>alive(row.pid,row.start)))).every(value=>!value);assert.ok(proof.helperWritersRetired);await writeFile(path,JSON.stringify(proof,null,2));
 }finally{
  await fleetFooterWorker?.close();await model?.close();await billing?.close();const output=join(workspace,'electron-results');await mkdir(output,{recursive:true});
  if(model?.agentCalls){await writeFile(join(output,'everyday-agent-calls.json'),JSON.stringify(model.agentCalls,null,2));await writeFile(join(output,'everyday-seed-calls.json'),JSON.stringify(model.seedCalls,null,2));}
  if(model)await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2));
  if(billing)await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2));
  let proof;try{proof=JSON.parse(await readFile(join(output,'combined-everyday.json'),'utf8'))}catch(error){if(error.code!=='ENOENT')throw error}
  const replacement=proof?.promptEditReplacement, second=proof?.reset??{pid:replacement?.newPid,start:replacement?.newStart};
  const writers=proof?.promptControlsReplacement?.writers??[{pid:proof?.pid,start:proof?.processStart},second].filter(writer=>writer.pid);
  const helpers=await profile.invocations(),retirementStarted=Date.now();let retired=false;for(let attempt=0;attempt<100;attempt++){retired=(await Promise.all([...writers,...helpers].map(row=>alive(row.pid,row.start)))).every(value=>!value);if(retired)break;await new Promise(resolve=>setTimeout(resolve,50));}await writeFile(join(output,'writer-retirement.json'),JSON.stringify({retired,elapsedMs:Date.now()-retirementStarted,pid:proof?.pid,processStart:proof?.processStart,
   ...(proof?.reset&&{resetPid:proof.reset.pid,resetProcessStart:proof.reset.start}),
   ...(replacement&&{replacementPid:replacement.newPid,replacementProcessStart:replacement.newStart}),
   ...(proof?.promptControlsReplacement&&{writers})}));assert.ok(retired,'Native/status writers must retire before profile restoration');
  await promptPlugin?.restore();
  await profile.restore();for(const name of ['before','after','restored'])await writeFile(join(output,'combined-settings-'+name+'.json'),await readFile(join(workspace,'combined-settings-'+name+'.json')));await writeFile(join(output,'combined-agent-restoration.json'),await readFile(join(workspace,'combined-agent-restoration.json')));
  await writeFile(join(output,'native-config-after.json'),await readFile(configPath));await writeFile(configPath,configBefore);assert.deepEqual(await readFile(configPath),configBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configSha256:sha(configBefore),settingsSha256:sha(settingsBefore)}));
 }
}
