import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {combinedJourney,readCombinedEverydayJournal} from './apack-combined-everyday-drive.mjs';
import {prepareFreshCombinedEverydayProfile} from './combined-everyday-profile.mjs';
import {startCombinedEverydayModel} from '../protocol/combined-everyday-model.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function alive(pid,start){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]!=='Z'&&fields[19]===start}catch(error){if(error.code==='ENOENT')return false;throw error}}

/** Existing combined everyday interactions against the normal shared-profile default, with fresh owned data. */
export async function driveFreshCombinedEveryday({checkout,workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
 const project=join(workspace,'project');await mkdir(project);await writeFile(join(project,'release-notes.md'),'# Release notes\n\nDescribe the behavior changes and migration guidance.\n');execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),configPath=join(workspace,'.claude/.claude.json'),settingsPath=join(workspace,'.claude/settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({theme:'dark',model:'opus'}));const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath);
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,defaultProfile:'shared',config,settings:JSON.parse(settingsBefore)},null,2));
 const profile=await prepareFreshCombinedEverydayProfile({workspace});let model,billing;
 try{
  model=await startCombinedEverydayModel({workspace,project,maxRequests:32,agentReadingProbe:true});
  const tls=await prepareNativeCreditTls(join(workspace,'account-tls'));billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
  const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-fresh-combined-everyday',journeyBudgetMs:120000,journey:args=>combinedJourney({...args,profile,model,verifyAttachmentRecovery:false,agentReadingProbe:true,agentFormattingProbe:true,freshProfile:true,verifyPermissionOwnership:true})});
  const output=join(workspace,'electron-results'),path=join(output,'combined-everyday.json'),proof=JSON.parse(await readFile(path,'utf8')),userDataDir=join(workspace,'app-data');
  const main=await readCombinedEverydayJournal(userDataDir,proof.parentSessionId,undefined,profile.configDir),worker=await readCombinedEverydayJournal(userDataDir,proof.parentSessionId,proof.taskId,profile.configDir);await writeFile(join(output,'native-parent-transcript.jsonl'),main);await writeFile(join(output,'native-agent-transcript.jsonl'),worker);
  const costs=main.toString().split('\n').filter(Boolean).map(JSON.parse).filter(row=>row.type==='cost-state');assert.equal(costs.at(-1)?.totalCostUSD,proof.final.claude.totalCostUsd);proof.persistedCost=costs.at(-1).totalCostUSD;proof.journals={parentSha256:sha(main),agentSha256:sha(worker)};proof.allInvocations=await profile.invocations();proof.helperWritersRetired=(await Promise.all(proof.allInvocations.map(row=>alive(row.pid,row.start)))).every(value=>!value);assert.ok(proof.helperWritersRetired);await writeFile(path,JSON.stringify(proof,null,2));
 }finally{
  await model?.close();await billing?.close();const output=join(workspace,'electron-results');await mkdir(output,{recursive:true});
  if(model){await writeFile(join(output,'everyday-agent-calls.json'),JSON.stringify(model.agentCalls,null,2));await writeFile(join(output,'everyday-seed-calls.json'),JSON.stringify(model.seedCalls,null,2));await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2));}
  if(billing)await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2));
  let proof;try{proof=JSON.parse(await readFile(join(output,'combined-everyday.json'),'utf8'))}catch(error){if(error.code!=='ENOENT')throw error}
  const helpers=await profile.invocations(),retirementStarted=Date.now();let retired=false;for(let attempt=0;attempt<100;attempt++){retired=!(proof?.pid&&await alive(proof.pid,proof.processStart))&&(await Promise.all(helpers.map(row=>alive(row.pid,row.start)))).every(value=>!value);if(retired)break;await new Promise(resolve=>setTimeout(resolve,50));}await writeFile(join(output,'writer-retirement.json'),JSON.stringify({retired,elapsedMs:Date.now()-retirementStarted,pid:proof?.pid,processStart:proof?.processStart}));assert.ok(retired,'Native/status writers must retire before profile restoration');
  await profile.restore();for(const name of ['before','after','restored'])await writeFile(join(output,'combined-settings-'+name+'.json'),await readFile(join(workspace,'combined-settings-'+name+'.json')));await writeFile(join(output,'combined-agent-restoration.json'),await readFile(join(workspace,'combined-agent-restoration.json')));
  await writeFile(join(output,'native-config-after.json'),await readFile(configPath));await writeFile(configPath,configBefore);assert.deepEqual(await readFile(configPath),configBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configSha256:sha(configBefore),settingsSha256:sha(settingsBefore)}));
 }
}
