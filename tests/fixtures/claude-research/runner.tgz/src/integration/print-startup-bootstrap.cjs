const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
const directory=process.env.CLAUDE_RESEARCH_PRINT_STARTUP_TRACE;
assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
assert.match(directory,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+\/print-startup$/);
const boundary=JSON.parse(fs.readFileSync('/control/offline-verified','utf8'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
process.env.NODE_OPTIONS=(process.env.NODE_OPTIONS??'')+' --import='+pathToFileURL(path.join(__dirname,'print-startup-preload.mjs')).href;
