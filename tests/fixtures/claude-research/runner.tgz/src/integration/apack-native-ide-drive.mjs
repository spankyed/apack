import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat,mkdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {prepareCombinedEverydayProfile} from './combined-everyday-profile.mjs';
const sha=data=>createHash('sha256').update(data).digest('hex');
async function processStart(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]==='Z'?undefined:fields[19]}catch(error){if(error.code==='ENOENT')return;throw error}}

import {prepareNativeIdeFixture} from '../protocol/native-ide-fixture.mjs';
/** Real original IDE discovery/auth/context; terminal /ide fallback is recorded, not called inline delivery. */
export async function driveNativeIde(options){
 const output=join(options.workspace,'electron-results');await mkdir(output,{recursive:true});const profile=await prepareCombinedEverydayProfile(options);let ide;
 try{ide=await prepareNativeIdeFixture(options);await driveChildComposer({...options,env:{...options.env,CLAUDE_CODE_AUTO_CONNECT_IDE:'1',CLAUDE_CODE_IDE_SKIP_AUTO_INSTALL:'1'},modelRequestLimit:12,modelOptions:{textReply:'The editor context review is complete.'},journey:args=>ideJourney({...args,profile,ide}),journeyName:'native-ide'});}
 finally{try{await ide?.restore();}finally{await profile.restore();}for(const name of ['before','after','restored'])await writeFile(join(output,'combined-settings-'+name+'.json'),await readFile(join(options.workspace,'combined-settings-'+name+'.json')));await writeFile(join(output,'combined-agent-restoration.json'),await readFile(join(options.workspace,'combined-agent-restoration.json')));if(ide){await writeFile(join(output,'ide-fixture-restoration.json'),await readFile(join(options.workspace,'ide-fixture-restoration.json')));await writeFile(join(output,'ide-settings-applied.json'),await readFile(join(options.workspace,'ide-settings-applied.json')));for(const name of ['ide-preferences-before.json','ide-preferences-restored.json'])await writeFile(join(output,name),await readFile(join(options.workspace,name)));}}
}
async function ideJourney({app,page,electronApp,output,project,userDataDir,expect,phase,profile,model,ide}){
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});a.send({type:'TAB.SELECT',tab:'features'});});await expect(page.locator('#claude-profile')).toHaveValue('app');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.tabs.every(tab=>c.tabsRead.includes(tab.id));}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:Object.values(c.nativeUiViews).find(v=>v.threadId===c.currentThread?.id)};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await composer.fill('Help me review the release notes and checklist.');await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');const initial=await context(),pid=initial.native.state.nativePid,start=await processStart(pid);assert.ok(start);
 await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toBeVisible();
 let initialUiRecovery;
 await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toMatch(/^(live|error)$/);
 if((await context()).ui?.state?.status==='error'){
  const before=await context();initialUiRecovery={before};await writeFile(join(output,'initial-ui-recovery.json'),JSON.stringify(initialUiRecovery,null,2));
  await card.getByRole('button',{name:'Reconnect controls',exact:true}).click({timeout:5000});
  await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toBe('live');
  const after=await context();assert.equal(after.native.state.nativePid,pid);assert.equal(after.native.state.sessionId,initial.native.state.sessionId);assert.equal(after.native.state.ownerId,before.native.state.ownerId);assert.equal(await processStart(pid),start);
  initialUiRecovery.after=after;await writeFile(join(output,'initial-ui-recovery.json'),JSON.stringify(initialUiRecovery,null,2));
 }
 await expect.poll(async()=>(await context()).native?.state?.mainStatus,{timeout:15000}).toContain('Release review');
 const proof={status:'running',scope:'Original local IDE discovery/WebSocket auth/allowed-denied selection context. Existing /ide terminal fallback is not inline chooser acceptance; no installation, WSL, real editor or full parity.',sessionId:initial.claude.sessionId,pid,processStart:start,port:ide.port,allowedPath:ide.allowed,deniedPath:ide.denied,deniedRule:ide.deniedRule,marker:ide.marker,markerReturn:ide.markerReturn,deniedMarker:ide.deniedMarker,captures:[],initialUiRecovery};
 const save=()=>writeFile(join(output,'native-ide.json'),JSON.stringify({...proof,ideReceipts:ide.receipts},null,2));
 const capture=async stage=>{for(const [size,viewport]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);const name='native-ide-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,name)});proof.captures.push(name);}await save();};
 const requests=()=>model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages');
 try{
  await expect.poll(()=>ide.receipts.some(r=>r.kind==='rpc'&&r.method==='ide_connected'&&r.pid===pid),{timeout:20000}).toBe(true);assert.ok(ide.receipts.some(r=>r.kind==='upgrade'&&r.authorized&&r.mcpProtocol));assert.ok(!ide.overflow);
  const inline=process.env.CLAUDE_RESEARCH_IDE_INLINE==='1',confirmationVariants=process.env.CLAUDE_RESEARCH_IDE_CONFIRMATIONS==='1';
  if(inline){
   proof.scope='Original native inline IDE chooser, context label/dismissal and unchanged allowed-denied-recovered context; no installer, WSL, server tools or full parity.';
   proof.beforePanelRequests=requests().length;await composer.fill('/ide');await send.click();
   const panel=page.getByRole('dialog',{name:'Claude Code IDE connection',exact:true});
   await expect(panel).toBeVisible({timeout:15000});await expect(panel.locator('[data-native-ide-choice]').first()).toBeVisible({timeout:10000});
   proof.panelPresentation='inline-native';proof.chooserLabels=await panel.locator('[data-native-ide-choice]').allTextContents();assert.ok(proof.chooserLabels.some(x=>x.includes('Owned release review IDE')));assert.ok(proof.chooserLabels.some(x=>x.trim()==='None'));
   await capture('inline-chooser');await panel.getByRole('button',{name:'Close IDE selection',exact:true}).click();await expect(panel).toBeHidden();await expect(composer).toBeEditable();assert.equal(requests().length,proof.beforePanelRequests);
   await composer.fill('/ide');await send.click();await expect(panel).toBeVisible({timeout:15000});
   const closedBefore=ide.receipts.filter(r=>r.kind==='closed').length;
   await panel.locator('[data-native-ide-choice]').filter({hasText:/^None$/}).click();
   const decline=panel.getByRole('button',{name:'No',exact:true});
   await expect.poll(async()=>await panel.isVisible()?(await decline.isVisible()?'confirmation':'pending'):'closed',{timeout:15000}).toMatch(/^(confirmation|closed)$/);
   if(await decline.isVisible()){proof.disconnectConfirmation=true;await capture('disconnect-confirmation');await panel.getByRole('button',{name:'Yes',exact:true}).click();}
   await expect(panel).toBeHidden({timeout:15000});await expect.poll(()=>ide.receipts.filter(r=>r.kind==='closed').length,{timeout:10000}).toBeGreaterThan(closedBefore);
   await composer.fill('/ide');await send.click();await expect(panel).toBeVisible({timeout:15000});
   const connectedBefore=ide.receipts.filter(r=>r.kind==='rpc'&&r.method==='ide_connected').length;
   await panel.locator('[data-native-ide-choice]').filter({hasText:'Owned release review IDE'}).click();
   await expect.poll(async()=>await panel.isVisible()?(await decline.isVisible()?'confirmation':'pending'):'closed',{timeout:15000}).toMatch(/^(confirmation|closed)$/);
   if(await decline.isVisible()){proof.connectConfirmation=true;await capture('connect-confirmation');await panel.getByRole('button',{name:'Refresh IDE choices',exact:true}).click();await expect(decline).toBeEnabled();proof.connectDecision=confirmationVariants?'yes':'no';await panel.getByRole('button',{name:confirmationVariants?'Yes':'No',exact:true}).click();}
   await expect(panel).toBeHidden({timeout:15000});await expect.poll(()=>ide.receipts.filter(r=>r.kind==='rpc'&&r.method==='ide_connected'&&r.pid===pid).length,{timeout:15000}).toBeGreaterThan(connectedBefore);proof.reconnected=true;proof.idePreferences=await ide.preferences();proof.idePreferenceNormalization='Native default autoConnectIde:false may be omitted from serialized preferences';if(proof.connectConfirmation){assert.equal(proof.idePreferences.autoConnectIde,confirmationVariants);assert.equal(proof.idePreferences.hasIdeAutoConnectDialogBeenShown,true);}
   assert.equal(requests().length,proof.beforePanelRequests);assert.equal((await context()).native.state.nativePid,pid);
   if(confirmationVariants){
    assert.equal(proof.connectConfirmation,true);proof.confirmationVariants=[];
    for(const decision of ['no','cancel','yes']){
     await composer.fill('/ide');await send.click();await expect(panel).toBeVisible({timeout:15000});
     const closes=ide.receipts.filter(r=>r.kind==='closed').length;
     await panel.locator('[data-native-ide-choice]').filter({hasText:/^None$/}).click();
     await expect(panel.getByRole('heading',{name:'Do you wish to disable auto-connect to IDE?',exact:true})).toBeVisible({timeout:10000});
     await capture('disable-'+decision);await panel.getByRole('button',{name:'Refresh IDE choices',exact:true}).click();
     const control=panel.getByRole('button',{name:decision==='cancel'?'Close IDE selection':decision==='yes'?'Yes':'No',exact:true});await expect(control).toBeEnabled();await control.click();
     await expect(panel).toBeHidden({timeout:15000});await expect.poll(()=>ide.receipts.filter(r=>r.kind==='closed').length,{timeout:10000}).toBeGreaterThan(closes);
     const expected=decision!=='yes';await expect.poll(async()=>(await ide.preferences()).autoConnectIde,{timeout:5000}).toBe(expected);
     const preferences=await ide.preferences();proof.confirmationVariants.push({decision,preferences,nativeDisconnected:true,state:await context()});
     await composer.fill('/ide');await send.click();await expect(panel).toBeVisible({timeout:15000});const connections=ide.receipts.filter(r=>r.kind==='rpc'&&r.method==='ide_connected').length;
     await panel.locator('[data-native-ide-choice]').filter({hasText:'Owned release review IDE'}).click();await expect(panel).toBeHidden({timeout:15000});
     await expect.poll(()=>ide.receipts.filter(r=>r.kind==='rpc'&&r.method==='ide_connected'&&r.pid===pid).length,{timeout:10000}).toBeGreaterThan(connections);
    }
    assert.equal(requests().length,proof.beforePanelRequests);
   }
   await ide.select('allowed');await composer.fill('Keep my editor review notes.');
   const chip=card.getByRole('status',{name:'Claude IDE context',exact:true});await expect(chip).toBeVisible({timeout:10000});proof.contextLabel=await chip.textContent();await capture('context');
   await chip.getByRole('button',{name:'Dismiss IDE context',exact:true}).click();await expect(chip).toBeHidden({timeout:10000});await expect(composer).toHaveText('Keep my editor review notes.');
   const before=requests().length;await send.click();await expect.poll(()=>requests().length,{timeout:20000}).toBeGreaterThan(before);await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:20000}).toBe(false);
   proof.dismissedRequests=requests().slice(before);assert.ok(proof.dismissedRequests.every(c=>!JSON.stringify(c.messages).includes(ide.marker)));proof.contextDismissed=true;await capture('context-dismissed');
  }else{
  proof.beforePanelRequests=requests().length;await composer.fill('/ide');await send.click();const panel=page.getByRole('dialog',{name:'Native /ide panel',exact:true});await expect(panel).toBeVisible({timeout:15000});proof.panelPresentation='terminal-fallback';await capture('chooser');await panel.getByRole('button',{name:'Close panel',exact:true}).click();await expect(panel).toBeHidden();await expect(composer).toBeEditable();assert.equal(requests().length,proof.beforePanelRequests);
  }
  for(const kind of ['allowed','denied','allowed-return']){
   await ide.select(kind);await composer.fill(kind==='denied'?'Review the denied selection without reading that file.':kind==='allowed-return'?'Review the newly changed editor selection.':'Review the currently selected editor release line.');await capture(kind+'-ready');
   const before=requests().length;await send.click();await expect.poll(()=>requests().length,{timeout:20000}).toBeGreaterThan(before);await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:20000}).toBe(false);
   const fresh=requests().slice(before);assert.ok(kind==='denied'?fresh.every(c=>!JSON.stringify(c.messages).includes(ide.deniedMarker)):fresh.some(c=>JSON.stringify(c.messages).includes(kind==='allowed-return'?ide.markerReturn:ide.marker)));
   proof[kind]={requests:fresh,state:await context()};assert.equal(proof[kind].state.claude.sessionId,proof.sessionId);assert.equal(proof[kind].state.native.state.nativePid,pid);await composer.fill('Keep my editor review notes.');await expect(send).toBeEnabled();await capture(kind+'-result');
  }
  proof.beforeStop=await context();assert.equal(await processStart(pid),start);proof.requests=requests();proof.ideReceipts=[...ide.receipts];assert.ok(!ide.overflow);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processStart(pid),{timeout:15000}).not.toBe(start);proof.nativeWriterRetired=true;
  const root=join(userDataDir,'claude-code-profile/config/projects'),names=await readdir(root,{recursive:true}),matches=names.filter(n=>basename(n)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);const journal=await readFile(join(root,matches[0]));await writeFile(join(output,'native-ide-transcript.jsonl'),journal);proof.journalSha256=sha(journal);const rows=journal.toString().split('\n').filter(Boolean).map(JSON.parse);proof.persistedCost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(proof.persistedCost,proof.beforeStop.claude.totalCostUsd);assert.ok(journal.includes(Buffer.from(ide.marker)));assert.ok(journal.includes(Buffer.from(ide.markerReturn)));assert.ok(!journal.includes(Buffer.from(ide.deniedMarker)));proof.status='complete';await save();phase('native-ide-context-complete');
 }catch(error){proof.error={name:error.name,message:error.message.slice(0,2000)};await page.screenshot({path:join(output,'native-ide-failure.png')}).catch(()=>{});await save();throw error;}
}
