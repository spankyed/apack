import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir,readFile,writeFile,lstat,rename} from 'node:fs/promises';
import {join,basename,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {record} from '../protocol/record.mjs';
import {MANAGED_SECURITY_KEY} from '../protocol/native-managed-security-fixture.mjs';

/** Install two ordinary local plugins through Claude; retain every temporary registry preimage. */
export async function prepareForeignNoticeProfile({setupWorkspace,workspace,env}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.equal(process.getuid(),1000);assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');assert.match(workspace,/^\/work\/\.claude-research\/foreign-notice-app[0-9]+$/);
 const sha=b=>createHash('sha256').update(b).digest('hex'),executable='/frozen-claude/claude';assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 const config=join(setupWorkspace,'app-data/claude-code-profile/config'),market=basename(workspace),marketplace=join(workspace,'marketplace'),plugin=join(marketplace,'plugins/release-notice-owner'),peer=join(marketplace,'plugins/release-notice-peer');
 const saved=new Map();for(const relative of ['settings.json','plugins/known_marketplaces.json','plugins/installed_plugins.json']){
  const path=join(config,relative);let bytes;try{const info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1048576);bytes=await readFile(path)}catch(error){if(error.code!=='ENOENT')throw error}saved.set(relative,bytes);
 }
 await mkdir(join(workspace,'profile-preimages'),{recursive:true});const preimages=[];for(const [relative,bytes]of saved){if(bytes!==undefined)await writeFile(join(workspace,'profile-preimages',relative.replaceAll('/','-')),bytes,{mode:0o600,flag:'wx'});preimages.push({path:relative,present:bytes!==undefined,sha256:bytes===undefined?null:sha(bytes)});}await writeFile(join(workspace,'profile-preimages/manifest.json'),JSON.stringify(preimages),{mode:0o600,flag:'wx'});
 assert.ok(saved.get('settings.json'));for(const name of ['app-foreign-notice-owner-result.json','app-foreign-notice-owner-enqueue.json','app-foreign-notice-peer-enqueue.json'])assert.equal(existsSync(join(setupWorkspace,'project',name)),false,'Fixture receipts must be new');for(const kind of ['cache','marketplaces'])assert.equal(existsSync(join(config,'plugins',kind,market)),false,'Fixture marketplace must be new');
 const ownerSource=`export function register(on){let lastQuestionId;on('prompt.submit',async($,e,next)=>{if(e.text==='Ask the plugin-owned release question.'){const result=await $.ui.ask('Who should receive the release review?',{header:'Audience',multiSelect:false,options:['Developers','Operators']});await $.fs.write('app-foreign-notice-owner-result.json',JSON.stringify({toolUseId:lastQuestionId,result}));}return next(e)});on('tool.call',{tool:'AskUserQuestion'},async($,e,next)=>{lastQuestionId=e.tool_use_id;$.ui.notice(e.tool_use_id,'Owner release policy remains authoritative.');await $.fs.write('app-foreign-notice-owner-enqueue.json',JSON.stringify({toolUseId:e.tool_use_id,enqueued:true}));return next(e)});}`;
 const peerSource=`export function register(on){on('tool.call',{tool:'AskUserQuestion'},async($,e,next)=>{$.ui.notice(e.tool_use_id,'FOREIGN_NOTICE_MUST_NOT_APPEAR');await $.fs.write('app-foreign-notice-peer-enqueue.json',JSON.stringify({toolUseId:e.tool_use_id,enqueued:true}));return next(e)});}`;
 await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});
 await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:market,owner:{name:'Local release review'},plugins:[{name:'release-notice-owner',source:'./plugins/release-notice-owner'},{name:'release-notice-peer',source:'./plugins/release-notice-peer'}]}));
 for(const [directory,name,source]of [[plugin,'release-notice-owner',ownerSource],[peer,'release-notice-peer',peerSource]]){await mkdir(join(directory,'.claude-plugin'),{recursive:true});await mkdir(join(directory,'hooks'));await writeFile(join(directory,'.claude-plugin/plugin.json'),JSON.stringify({name,version:'0.0.1'}));await writeFile(join(directory,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));await writeFile(join(directory,'hooks/register.ts'),source);}
 const pluginSources={'release-notice-owner':ownerSource,'release-notice-peer':peerSource};let restored=false;
 async function restore(){if(restored)return;const result=[];for(const[relative,before]of saved){const path=join(config,relative),preserved=join(workspace,'preserved-'+relative.replaceAll('/','-'));if(existsSync(path))await rename(path,preserved);if(before!==undefined){await mkdir(dirname(path),{recursive:true});await writeFile(path,before,{mode:0o600,flag:'wx'});assert.deepEqual(await readFile(path),before)}else assert.equal(existsSync(path),false);result.push({path:relative,originalPresent:before!==undefined,restoredPresent:existsSync(path),sha256:before===undefined?null:sha(before)});}
  for(const kind of ['cache','marketplaces']){const path=join(config,'plugins',kind,market);if(existsSync(path)){const info=await lstat(path);assert.ok(info.isDirectory()&&info.uid===process.getuid());await rename(path,join(workspace,'preserved-plugin-'+kind));}}
  for(const name of ['app-foreign-notice-owner-result.json','app-foreign-notice-owner-enqueue.json','app-foreign-notice-peer-enqueue.json']){const path=join(setupWorkspace,'project',name);if(existsSync(path))await rename(path,join(workspace,name));}
  await writeFile(join(workspace,'foreign-notice-profile-restoration.json'),JSON.stringify({restored:true,files:result}));restored=true;
 }
 try{
  const environment={...env,HOME:join(setupWorkspace,'home'),CLAUDE_CONFIG_DIR:config,ANTHROPIC_API_KEY:MANAGED_SECURITY_KEY,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
  const runs=[];for(const args of [['--setting-sources','','plugin','marketplace','add',marketplace],...Object.keys(pluginSources).map(name=>['--setting-sources','','plugin','install',name+'@'+market])]){
   const run=await record({executable,cwd:join(setupWorkspace,'project'),output:join(workspace,'installation'),env:environment,args,timeoutMs:20000,maxBytes:1048576});runs.push(run);assert.equal(run.code,0,'Original local plugin installation refused');assert.equal(run.status,'complete');
  }
  const registry=JSON.parse(await readFile(join(config,'plugins/installed_plugins.json'),'utf8')),installations={};
  for(const [name,source]of Object.entries(pluginSources)){const entries=registry.plugins?.[name+'@'+market];assert.ok(Array.isArray(entries)&&entries.length===1);assert.equal(entries[0].scope,'user');assert.equal(sha(await readFile(join(entries[0].installPath,'hooks/register.ts'))),sha(Buffer.from(source)));installations[name]={...entries[0],sourceSha256:sha(source)};}
  await writeFile(join(workspace,'foreign-notice-installation.json'),JSON.stringify({runs,marketplace:market,installations,binarySha256:sha(await readFile(executable)),scope:'Two original-installed local plugins; no manual registry fabrication.'}));
  return {restore};
 }catch(error){await restore();throw error}
}
