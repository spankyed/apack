import assert from 'node:assert/strict';
import {createServer,request} from 'node:http';
import {mkdtemp,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {holdOwnedSessionHandoff} from './owned-session-handoff-hold.mjs';

/** Exercise byte preservation and abort restoration before the native app uses the relay. */
export async function checkOwnedSessionHandoffRelay(){
 const directory=await mkdtemp('/tmp/cc-app-relay-check-'),socket=join(directory,'bridge.sock'),old=randomUUID(),fresh=randomUUID(),calls=[];
 await writeFile(join(directory,'observer.json'),JSON.stringify({socketPath:socket,sessionId:old}),{mode:0o600});
 const server=createServer(async(req,res)=>{const bytes=[];for await(const chunk of req)bytes.push(chunk);assert.equal(req.headers['x-parity-check'],'owned');const body=Buffer.concat(bytes).toString();calls.push({path:req.url,body});res.writeHead(200,{'content-type':'application/json','x-parity-reply':'original'});res.end(req.url==='/poll'?'{"reportEveryMs":0}':'{}');});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(socket,resolve);});
 const send=(path,sessionId)=>new Promise((resolve,reject)=>{const body=JSON.stringify({sessionId,...path==='/turn'?{running:true}:{}}),r=request({socketPath:socket,path,method:'POST',headers:{'x-parity-check':'owned','content-type':'application/json'}},res=>{const chunks=[];res.on('data',c=>chunks.push(c));res.on('end',()=>resolve({body:Buffer.concat(chunks).toString(),status:res.statusCode,header:res.headers['x-parity-reply']}));});r.on('error',reject);r.end(body);});
 const until=async predicate=>{const signal=AbortSignal.timeout(3000);while(!predicate()){signal.throwIfAborted();await new Promise(r=>setTimeout(r,5));}};
 let relay;
 try{
  const abort=new AbortController();relay=await holdOwnedSessionHandoff({directory,sessionId:old,signal:abort.signal});relay.arm();
  const pendingOld=send('/poll',old);await until(()=>relay.receipts().some(r=>r.kind==='old-poll'));
  const pendingReady=send('/turn',fresh);await until(()=>relay.receipts().some(r=>r.kind==='new-turn'));assert.equal(calls.filter(r=>r.path==='/turn').length,0);
  assert.deepEqual(await send('/poll',fresh),{body:'{"reportEveryMs":0}',status:200,header:'original'});
  relay.release('old-poll');assert.deepEqual(await pendingOld,{body:'{"reportEveryMs":0}',status:200,header:'original'});
  relay.release('new-turn');assert.deepEqual(await pendingReady,{body:'{}',status:200,header:'original'});
  await until(()=>relay.receipts().every(r=>r.deliveredAt&&!r.closedBeforeDelivery));assert.deepEqual(relay.errors(),[]);assert.equal((await relay.close()).restored,true);
  const cancel=new AbortController();relay=await holdOwnedSessionHandoff({directory,sessionId:old,signal:cancel.signal});cancel.abort();assert.equal((await relay.close()).restored,true);
  assert.deepEqual(await send('/poll',old),{body:'{"reportEveryMs":0}',status:200,header:'original'});
  return {verified:true,scope:'Synthetic relay only: exact responses/headers, held turn-start not forwarded early, fresh poll, delivered old response and original Unix socket identity restoration on normal close and abort. No native/app acceptance.'};
 }finally{if(relay)await relay.close();await new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()));}
}
