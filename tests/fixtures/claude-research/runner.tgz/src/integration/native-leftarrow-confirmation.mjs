import {prepareNativeBackgroundFormatterAudit} from './native-background-formatter-audit.mjs';
import {pathToFileURL} from 'node:url';
import {nativeBackgroundReplyAudit} from './native-background-reply-audit.mjs';
import {prepareNativeBackgroundDispatchAudit} from './native-background-dispatch-audit.mjs';
import {startSyntheticAgentModel,WORKFLOW_APPROVAL_FIXTURE_SCRIPT} from '../protocol/synthetic-agent-model.mjs';
import assert from 'node:assert/strict';
import {observeOriginalBackgroundAttach} from './native-background-attach-check.mjs';
import {readFile,mkdir,writeFile,readdir}from'node:fs/promises';
import {join,basename,isAbsolute}from'node:path';
import {stripVTControlCharacters}from'node:util';
import {createHash}from'node:crypto';
import {execFileSync}from'node:child_process';
import {prepareNativeManagedSecurity}from'../protocol/native-managed-security-fixture.mjs';
import {recognizeOnboardingPrompt}from'../protocol/pty-onboarding.mjs';
import {adaptNativeResearchPreload} from './native-platform-preload.mjs';
import {record}from'../protocol/record.mjs';
const [executable,workspace,output,checkout]=process.argv.slice(2);
const childFormatterAudit=process.env.CLAUDE_RESEARCH_CHILD_FORMATTER_AUDIT==='1';
const childHostAudit=process.env.CLAUDE_RESEARCH_CHILD_HOST_AUDIT==='1',dispatchPreloadAudit=process.env.CLAUDE_RESEARCH_DISPATCH_PRELOAD_AUDIT==='1';
const childReplyAudit=process.env.CLAUDE_RESEARCH_CHILD_REPLY_AUDIT==='1';
const childUiAudit=process.env.CLAUDE_RESEARCH_CHILD_UI_AUDIT==='1';
const childStatusAudit=process.env.CLAUDE_RESEARCH_CHILD_STATUS_AUDIT==='1';
const childIdentityAudit=process.env.CLAUDE_RESEARCH_CHILD_IDENTITY_AUDIT==='1';
assert.ok(!childIdentityAudit||childStatusAudit,'Child identity audit requires public status observations');
assert.ok(!childStatusAudit||childUiAudit,'Child status audit requires the original UI hook diagnostic');
assert.ok(!childUiAudit||childHostAudit,'Child UI audit requires the child hook diagnostic');
assert.ok(!dispatchPreloadAudit||childHostAudit,'Per-job preload audit requires the child hook diagnostic');
assert.equal(process.platform,'linux');assert.ok(isAbsolute(workspace)&&basename(workspace).startsWith('apack-terminal-owner-app-'));assert.ok(isAbsolute(output));
assert.equal(createHash('sha256').update(await readFile(executable)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
await mkdir(workspace,{recursive:true});assert.deepEqual(await readdir(workspace),[],'Fresh private profile required');await mkdir(output,{recursive:true});
await mkdir(join(workspace,'.claude'),{recursive:true});
// Match the already-onboarded profile used by app journeys; approvals remain native.
await writeFile(join(workspace,'.claude/.claude.json'),JSON.stringify({hasCompletedOnboarding:true}));
await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify({theme:'dark'}));
const formatterAudit=childFormatterAudit?await prepareNativeBackgroundFormatterAudit(workspace,{observePrefix:process.env.CLAUDE_RESEARCH_CHILD_FORMATTER_PREFIX_AUDIT==='1'}):undefined;
const project=join(workspace,'project');await mkdir(project);
execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null'},timeout:5000,maxBuffer:1024*1024});
const sources={};for(const name of [new URL(import.meta.url),new URL('./native-background-formatter-audit.mjs',import.meta.url),new URL('../protocol/native-managed-security-fixture.mjs',import.meta.url),new URL('./native-background-attach-check.mjs',import.meta.url),new URL('../protocol/record.mjs',import.meta.url),new URL('../protocol/synthetic-agent-model.mjs',import.meta.url),new URL('./native-platform-preload.mjs',import.meta.url),new URL('./native-background-dispatch-audit.mjs',import.meta.url),new URL('./native-background-reply-audit.mjs',import.meta.url)])sources[name.pathname]=createHash('sha256').update(await readFile(name)).digest('hex');
for(const name of ['native-platform-bindings.ts','native-platform-runtime.ts','terminal-background-reply-runtime.ts']){const file=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code',name);sources[file]=createHash('sha256').update(await readFile(file)).digest('hex');}
await writeFile(join(output,'source-inputs.json'),JSON.stringify(sources,null,2)+'\n');
const auth=await prepareNativeManagedSecurity(workspace,executable);await auth.close();
assert.ok(isAbsolute(checkout));
const preload=join(workspace,'background-observer.mjs');
const observation=String.raw`import {createHash} from 'node:crypto';import {readFileSync} from 'node:fs';
{
 const {writeFileSync,renameSync}=await import('node:fs');let last;const rows=[],deadline=Date.now()+100000;
 const timer=setInterval(async()=>{if(Date.now()>deadline){clearInterval(timer);return}try{
  const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),binding=runtime.ey();if(binding?.surface!=='terminal'||typeof binding.toolContext!=='function')return;
  const context=binding.toolContext(new AbortController()),tasks=Object.entries(context.taskRegistry.all()).slice(0,64).map(([id,t])=>({id,type:t.type,status:t.status,isBackgrounded:t.isBackgrounded,v2Run:t.v2Run!==undefined,stoppedByUser:t.stoppedByUser,workflowAgents:t.workflowProgress?.filter(row=>row.type==='workflow_agent').map(row=>({state:row.state,queuedAt:row.queuedAt,startedAt:row.startedAt}))}));
  const value={tasks,dialogs:context.dialogStore.getState().open.map(d=>({id:d.id,kind:d.kind}))},key=JSON.stringify(value),current={at:Date.now(),pid:process.pid,sessionId:String((await import('/$bunfs/root/chunk-hdxpvbx1.js')).q()),...value},file=OBSERVATION_FILE+'.'+process.pid;
  writeFileSync(file+'.tmp',JSON.stringify(current));renameSync(file+'.tmp',file);
  if(key===last)return;last=key;rows.push(current);if(rows.length>128)rows.shift();
  writeFileSync(file+'.history',JSON.stringify(rows));
 }catch(error){if(rows.length<128){rows.push({at:Date.now(),error:String(error)});writeFileSync(OBSERVATION_FILE+'.'+process.pid+'.history',JSON.stringify(rows))}}},100);timer.unref();
}`.replaceAll('OBSERVATION_FILE',JSON.stringify(join(workspace,'background-task-observations.json')));
const replyRuntime=childReplyAudit?(await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-background-reply-runtime.ts')).href)).claudeTerminalBackgroundReplyRuntime:undefined;
const replyAudit=childReplyAudit?nativeBackgroundReplyAudit(workspace,project,replyRuntime):undefined;
const dispatchAudit=dispatchPreloadAudit?await prepareNativeBackgroundDispatchAudit(workspace,project):undefined;
await writeFile(preload,await adaptNativeResearchPreload(checkout,(childHostAudit||childReplyAudit?'delete process.env.BUN_OPTIONS;\n':'')+(dispatchAudit?.source??'')+(replyAudit?.source??'')+observation));
await mkdir(join(workspace,'.claude/agents'),{recursive:true});
await writeFile(join(workspace,'.claude/agents/status-fixture.md'),'---\nname: status-fixture\ndescription: Owned review task\nmodel: sonnet\n---\nNativeStatusChildSystem: return the fixed review response.\n');
const hostAuditPlugin=join(project,'host-audit-plugin');
if(childHostAudit){
 await mkdir(join(hostAuditPlugin,'.claude-plugin'),{recursive:true});await mkdir(join(hostAuditPlugin,'hooks'));
 await writeFile(join(hostAuditPlugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'research-child-host-audit',version:'0.0.1'}));
 await writeFile(join(hostAuditPlugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
 const statusAudit=childStatusAudit?`if(snapshots<8&&['Spinner','SessionMode','TurnDuration'].includes(e.component)){const index=snapshots++;const sessionId=await $.session.id();let snapshot;try{snapshot={available:true,model:await $.session.model(),turns:await $.session.turns(),usage:await $.session.usage(),surfaces:await $.session.surfaces(),prompt:await $.prompt.read()};}catch(error){snapshot={available:false,error:String(error).slice(0,256)}}await $.fs.write('native-child-status-'+sessionId+'-'+index+'.json',JSON.stringify({sessionId,component:e.component,surface:e.surface,snapshot}));}`:'';
 const renderAudit=childUiAudit?`let events=[];${['prompt.submit','turn.start'].map(event=>`on('${event}',async($,e,next)=>{const sessionId=await $.session.id();if(events.length<32){events.push({sessionId,event:'${event}'});await $.fs.write('native-child-events-'+sessionId+'-'+(events.length-1)+'.json',JSON.stringify({sessionId,events:[events.at(-1)]}));}return next(e);});`).join('')}let rows=[],snapshots=0;on('ui.render',async($,e,next)=>{const result=await next(e);if(rows.length<64){const sessionId=await $.session.id();rows.push({sessionId,component:e.component,surface:e.surface,requestId:e.requestId,argumentKeys:Object.keys(e),resultType:typeof result,resultKeys:result&&typeof result==='object'?Object.keys(result):[],treeType:typeof result?.tree});await $.fs.write('native-child-ui-'+sessionId+'-'+(rows.length-1)+'.json',JSON.stringify({sessionId,rows:[rows.at(-1)]}));}${statusAudit}return result;});`:'';

 const identityAudit=childIdentityAudit?`let hostIdentity;try{const result=await $.process.run(['/bin/sh','-c','printf \"%s\" \"$PPID\"'],{timeoutMs:3000});hostIdentity={exitCode:result.exitCode,pid:Number(result.stdout.trim()),stderr:result.stderr.slice(0,256)};}catch(error){hostIdentity={error:String(error).slice(0,256)}}await $.fs.write('native-child-identity-'+sessionId+'.json',JSON.stringify({sessionId,hostIdentity}));`:'';
 const source=`export function register(on){${renderAudit}on('session.start',async($,e,next)=>{const sessionId=await $.session.id();${formatterAudit?.registration??''}${identityAudit}let promptRead;try{const value=await $.prompt.read();promptRead={available:true,keys:Object.keys(value),textLength:value.text?.length??null};}catch(error){promptRead={available:false,message:String(error).slice(0,256)}}await $.fs.write('native-child-host-'+sessionId+'.json',JSON.stringify({sessionId,cwd:await $.session.cwd(),processType:typeof process,bunType:typeof Bun,globalType:typeof globalThis,bunOptionsPresent:!!await $.env.get('BUN_OPTIONS'),claudePid:await $.env.get('CLAUDE_PID'),promptRead,agentId:e.agentId??null}));return next(e);});}`;
 await writeFile(join(hostAuditPlugin,'hooks/register.ts'),source);await writeFile(join(output,'host-audit-plugin-input.json'),JSON.stringify({sha256:createHash('sha256').update(source).digest('hex'),preloadRestoresBunOptions:true},null,2));
}
const model=await startSyntheticAgentModel({workflowProbe:true,workflowScript:WORKFLOW_APPROVAL_FIXTURE_SCRIPT,holdChildUntilRelease:true,parentLaunchOnce:true,captureMessages:true,requestLimit:12});
const env={...auth.env,ANTHROPIC_BASE_URL:model.url,BUN_OPTIONS:'--preload='+preload};
const runs=[],actions=[];let short,stopped=false;
const save=async()=>writeFile(join(output,'background-session-observation.json'),JSON.stringify({targetVersion:'2.1.302',short,stopped,runs,actions,bootstrapKeyApproved:auth.state.bootstrapKeyApproved,modelCalls:model.calls},null,2)+'\n');
async function cli(label,args,timeoutMs=20000,tty=false){
 let terminal='';const keys=[],timers=[];
 try{
  const run=await record({executable:tty?'/usr/bin/python3':executable,args:tty?[new URL('../protocol/pty_bridge.py',import.meta.url).pathname,executable,...args]:args,cwd:project,env,output:join(output,label),timeoutMs,maxBytes:2*1024*1024,...(tty?{onStdout(bytes,channel){terminal+=bytes.toString('utf8');const stage=recognizeOnboardingPrompt(terminal,project);if(stage&&!keys.includes(stage)){keys.push(stage);timers.push(setTimeout(()=>channel.send(stage==='workspace-trust'?'\x1b[B':'\r'),stage==='workspace-trust-selected'?1500:200));}}}:{})});runs.push({label,...run,tty,trustKeys:keys});await save();
  const stdout=await readFile(join(run.directory,'stdout.bin'),'utf8'),stderr=await readFile(join(run.directory,'stderr.bin'),'utf8');return{...run,stdout,stderr};
 }finally{for(const timer of timers)clearTimeout(timer)}
}
const verifyFork=process.env.CLAUDE_RESEARCH_LEFTARROW_FORK==='1',verifyAttach=process.env.CLAUDE_RESEARCH_BACKGROUND_ATTACH==='1';
assert.ok(!verifyAttach||verifyFork,'Attachment probe requires an original fork');
let forkJob,attachment;
try{
 let terminal='',initialSent=false,checking=false,taskBefore,escapeAt,parentPid,retained=false,warning=false,phase='start';const timers=[];
 let run;
 try{
 run=await record({executable:'/usr/bin/python3',args:[new URL('../protocol/pty_bridge.py',import.meta.url).pathname,executable,'--model','claude-sonnet-4-6','--setting-sources','user,project,local','--tools','Workflow','--allowed-tools','Workflow','--permission-mode','acceptEdits','--strict-mcp-config',...(childHostAudit?['--plugin-dir',hostAuditPlugin]:[])],cwd:project,env,output:join(output,'native-leftarrow'),timeoutMs:65000,maxBytes:2*1024*1024,onStdout(bytes,channel){
  terminal+=bytes.toString('utf8');const stage=recognizeOnboardingPrompt(terminal,project);
  if(stage&&!actions.includes(stage)){actions.push(stage);timers.push(setTimeout(()=>channel.send(stage==='workspace-trust'?'\x1b[B':'\r'),stage==='workspace-trust-selected'?1500:200));}
  const text=stripVTControlCharacters(terminal).replace(/\s/g,'');
  if(actions.includes('workspace-trust-selected')&&text.includes('APIUsageBilling')&&text.includes('shift+tabtocycle')&&!initialSent){initialSent=true;timers.push(setTimeout(()=>channel.send('Start the owned review task before opening the agents view.'),400),setTimeout(()=>channel.send('\r'),1100));}
  if(text.includes('Backgroundthissession?')&&phase==='await-warning'){warning=true;phase='escape-scheduled';terminal='';timers.push(setTimeout(()=>{channel.send('\x1b');escapeAt=Date.now();phase='after-escape';terminal='';},300));}
  if(!initialSent||checking||!['start','after-escape','await-fork-warning'].includes(phase))return;
  checking=true;void readdir(workspace).then(async names=>{
   const rows=await Promise.all(names.filter(name=>/^background-task-observations\.json\.\d+$/.test(name)).map(async name=>JSON.parse(await readFile(join(workspace,name),'utf8'))));
   const latest=rows.filter(row=>!parentPid||row.pid===parentPid).sort((a,b)=>b.at-a.at)[0],task=latest?.tasks?.find(t=>t.type==='local_workflow'&&t.status==='running');
   if(phase==='await-fork-warning'&&latest?.dialogs?.some(dialog=>dialog.kind==='left_arrow_confirm')){
   if(verifyAttach)warning=true;
   await writeFile(join(output,'original-fork-dialog.json'),JSON.stringify(latest,null,2));actions.push('original-left-arrow-confirm');
   phase='fork';terminal='';timers.push(setTimeout(()=>channel.send('\r'),300));
   let listing=false,attempts=0;const poll=setInterval(async()=>{if(listing||forkJob)return;listing=true;try{
    const result=await cli('fork-list-'+attempts++,['agents','--json','--all','--cwd',project]);
    const jobs=JSON.parse(result.stdout);forkJob=jobs.find(job=>job.kind==='background'&&Number.isSafeInteger(job.pid)&&job.state!=='stopped');
    if(forkJob){short=forkJob.id;await writeFile(join(output,'fork-job.json'),JSON.stringify(forkJob,null,2));phase='done';if(replyAudit){
     const raw=await readFile('/proc/'+forkJob.pid+'/stat','utf8'),processStart=raw.slice(raw.lastIndexOf(')')+2).split(' ')[19];
     await writeFile(replyAudit.requestPath,JSON.stringify({parentPid:latest.pid,parentSessionId:latest.sessionId,cwd:project,jobId:forkJob.id,sessionId:forkJob.sessionId,pid:forkJob.pid,processStart,text:'NativeOriginalChildReplyDiagnostic'}));
     let result;for(let attempt=0;attempt<180;attempt++){try{result=JSON.parse(await readFile(replyAudit.resultPath,'utf8'));break;}catch(error){if(error.code!=='ENOENT')throw error;}await new Promise(resolve=>setTimeout(resolve,100));}
     await writeFile(join(output,'child-original-reply-audit.json'),JSON.stringify({job:forkJob,result},null,2));assert.ok(result,'Original reply observation deadline');assert.equal(result.error,undefined);assert.equal(result.result,null);
    }channel.stop('owned-leftarrow-observation-complete');}
    if(attempts>=12)clearInterval(poll);
   }catch(error){actions.push('fork-list-error:'+String(error));if(replyAudit&&forkJob)channel.stop('owned-leftarrow-observation-complete');}finally{listing=false;}},1000);timers.push(poll);return;
  }
   if(!task?.workflowAgents?.some(agent=>agent.startedAt!==undefined)||latest.dialogs.some(d=>['local_jsx','left_arrow_confirm'].includes(d.kind)))return;
   if(phase==='start'){taskBefore=task;parentPid=latest.pid;phase=verifyAttach?'await-fork-warning':'await-warning';terminal='';actions.push('original-left-arrow');timers.push(setTimeout(()=>channel.send('\x1b[D'),400),setTimeout(()=>{if(!verifyAttach||phase==='await-fork-warning')channel.send('\x1b[D');},1600));}
   else if(phase==='after-escape'){
    if(latest.at<escapeAt+200)return;assert.equal(task.id,taskBefore.id);assert.deepEqual(task.workflowAgents,taskBefore.workflowAgents);retained=true;phase='done';
    await writeFile(join(output,'fresh-task-retention.json'),JSON.stringify({escapeAt,latest,taskBefore,parentPid},null,2));
    actions.push('same-original-task-retained');if(verifyFork){phase='await-fork-warning';terminal='';timers.push(setTimeout(()=>channel.send('\x1b[D'),400),setTimeout(()=>channel.send('\x1b[D'),1600));}else timers.push(setTimeout(()=>channel.stop('owned-leftarrow-observation-complete'),300));
   }
  }).catch(error=>{if(error.code!=='ENOENT')actions.push('observation-error:'+String(error));}).finally(()=>{checking=false});
 }});
 }finally{for(const timer of timers)clearTimeout(timer)}
 if(replyAudit){const result=JSON.parse(await readFile(replyAudit.resultPath,'utf8'));assert.equal(result.error,undefined);assert.equal(result.result,null);}
 if(formatterAudit&&forkJob){await new Promise(resolve=>setTimeout(resolve,2500));await writeFile(join(output,'child-formatter-audit.json'),JSON.stringify(await formatterAudit.snapshot('before-attach',forkJob.sessionId),null,2));}
 if(verifyFork&&forkJob&&verifyAttach)attachment=await observeOriginalBackgroundAttach({executable,project,env,job:forkJob,output,cli,...(childUiAudit?{probeInput:'NativeChildHookDiagnostic'}:{})});
 if(formatterAudit&&forkJob)await writeFile(join(output,'child-formatter-audit.json'),JSON.stringify(await formatterAudit.snapshot('after-attach',forkJob.sessionId),null,2));
 if(childHostAudit&&forkJob){
  let entries=[];for(let attempt=0;attempt<30;attempt++){entries=await Promise.all((await readdir(project)).filter(name=>/^native-child-host-[a-f0-9-]{36}\.json$/i.test(name)).map(async name=>JSON.parse(await readFile(join(project,name),'utf8'))));if(entries.some(entry=>entry.sessionId===forkJob.sessionId))break;await new Promise(resolve=>setTimeout(resolve,100));}
  const state=JSON.parse(await readFile(join(env.CLAUDE_CONFIG_DIR??join(workspace,'.claude'),'jobs',forkJob.id,'state.json'),'utf8'));
  const proof={job:forkJob,entries,pluginInherited:state.respawnFlags?.includes(hostAuditPlugin)===true,providerEnvKeys:Object.keys(state.providerEnv??{}),preloadRestoresBunOptions:true,scope:'Native hook execution context only; no app structured child hosting or privileged import is attempted.'};await writeFile(join(output,'child-host-audit.json'),JSON.stringify(proof,null,2));
  if(childUiAudit){const renders=await Promise.all((await readdir(project)).filter(name=>/^native-child-ui-[a-f0-9-]{36}-\d+\.json$/i.test(name)).map(async name=>JSON.parse(await readFile(join(project,name),'utf8'))));await writeFile(join(output,'child-ui-hook-audit.json'),JSON.stringify({job:forkJob,renders,events:await Promise.all((await readdir(project)).filter(name=>/^native-child-events-[a-f0-9-]{36}-\d+\.json$/i.test(name)).map(async name=>JSON.parse(await readFile(join(project,name),'utf8')))),scope:'Original UI hook observation with one owned terminal submission; no desktop attachment, UI actions or app acceptance.'},null,2));assert.ok(renders.some(entry=>entry.sessionId===forkJob.sessionId&&entry.rows.length),'Original child UI hook was not observed');}
  if(childStatusAudit){const entries=await Promise.all((await readdir(project)).filter(name=>/^native-child-status-[a-f0-9-]{36}-\d+\.json$/i.test(name)).map(async name=>JSON.parse(await readFile(join(project,name),'utf8'))));const child=entries.filter(entry=>entry.sessionId===forkJob.sessionId);await writeFile(join(output,'child-status-hook-audit.json'),JSON.stringify({job:forkJob,entries,scope:'Native public status/prompt reads only; no desktop drawing/action, transport or app acceptance.'},null,2));assert.ok(child.length,'Original child status hook was not observed');assert.ok(child.every(entry=>entry.snapshot.available),'Original child status read failed');}
  if(childIdentityAudit){const entries=await Promise.all((await readdir(project)).filter(name=>/^native-child-identity-[a-f0-9-]{36}\.json$/i.test(name)).map(async name=>JSON.parse(await readFile(join(project,name),'utf8'))));const child=entries.filter(entry=>entry.sessionId===forkJob.sessionId);await writeFile(join(output,'child-host-identity-audit.json'),JSON.stringify({job:forkJob,entries,scope:'Original public process.run helper parent identity only; no app transport or privilege override.'},null,2));assert.equal(child.length,1);assert.equal(child[0].hostIdentity.exitCode,0);assert.equal(child[0].hostIdentity.pid,forkJob.pid,'Original helper parent must equal listed native worker');}
  assert.ok(proof.pluginInherited);if(!dispatchPreloadAudit)assert.ok(entries.some(entry=>entry.sessionId===forkJob.sessionId),'Original child session.start hook audit was not observed');
  if(dispatchPreloadAudit){const dispatch=JSON.parse(await readFile(join(workspace,'native-dispatch-preload-audit.json'),'utf8'));const markers=await Promise.all((await readdir(workspace)).filter(name=>/^child-preload-audit-\d+\.json$/.test(name)).map(async name=>JSON.parse(await readFile(join(workspace,name),'utf8'))));const child=markers.find(marker=>marker.pid===forkJob.pid&&marker.sessionIds.includes(forkJob.sessionId));await writeFile(join(output,'child-dispatch-preload-audit.json'),JSON.stringify({dispatch,markers,childObserved:!!child,scope:'Native per-job environment diagnostic only; structured child app bridge remains unfinished.'},null,2));assert.ok(child,'Original worker did not load its per-job authored preload');assert.equal(dispatch.sessionId,forkJob.sessionId);assert.equal(dispatch.authPreserved,true);assert.equal(dispatch.launchObjectPreserved,true);}
 }
 if(verifyFork&&forkJob){const result=await cli('stop-fork',['stop',forkJob.id]);assert.equal(result.status,'complete');stopped=true;const listed=await cli('after-stop-fork',['agents','--json','--all','--cwd',project]);assert.equal(JSON.parse(listed.stdout).find(job=>job.id===forkJob.id)?.state,'stopped');}
 const evidence={verifyFork,verifyAttach,nativeAttachmentObserved:attachment?.frameSeen===true,escapeRetested:!verifyAttach,forkJob,stopped,targetVersion:'2.1.302',warning,retained,phase,taskBefore,actions,run,syntheticRequests:model.calls.length,realModelRequests:0,scope:verifyAttach?'Original warning/confirm/fork, public attach frame, retained worker after owned client SIGTERM and native Stop only. Escape was not retested; graceful detach, app attachment, prompt/approval/question interaction and stopped-child resume remain open.':verifyFork?'Original native left-arrow warning/Escape/confirm/fork/native Stop only; desktop, full agents-view interaction and attach/resume remain open.':'Original left-arrow admission/warning/Escape only; confirmation and desktop remain open.'};
 await writeFile(join(output,'leftarrow-evidence.json'),JSON.stringify(evidence,null,2));
 assert.ok(warning&&(verifyAttach||retained),'Original warning required; Escape retention is required only for the dedicated Escape journey');assert.equal(run.reason,'owned-leftarrow-observation-complete');if(verifyFork)assert.ok(forkJob&&stopped,'Original fork and native Stop required');
 console.log(JSON.stringify(evidence));
}finally{if(short&&!stopped)await cli('cleanup-stop',['stop',short],15000).catch(()=>{});await model.close();await formatterAudit?.close();}
