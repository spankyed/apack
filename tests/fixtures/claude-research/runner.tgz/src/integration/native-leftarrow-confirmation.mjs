import {startSyntheticAgentModel,WORKFLOW_APPROVAL_FIXTURE_SCRIPT} from '../protocol/synthetic-agent-model.mjs';
import assert from 'node:assert/strict';
import {observeOriginalBackgroundAttach} from './native-background-attach-check.mjs';
import {readFile,mkdir,writeFile,readdir}from'node:fs/promises';
import {join,basename,isAbsolute}from'node:path';
import {stripVTControlCharacters}from'node:util';
import {createHash}from'node:crypto';
import {execFileSync}from'node:child_process';
import {prepareNativeManagedSecurity}from'../protocol/native-managed-security-fixture.mjs';
import {recognizeOnboardingPrompt}from'../protocol/pty-onboarding.mjs';
import {adaptNativeResearchPreload} from './native-platform-preload.mjs';
import {record}from'../protocol/record.mjs';
const [executable,workspace,output,checkout]=process.argv.slice(2);
assert.equal(process.platform,'linux');assert.ok(isAbsolute(workspace)&&basename(workspace).startsWith('apack-terminal-owner-app-'));assert.ok(isAbsolute(output));
assert.equal(createHash('sha256').update(await readFile(executable)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
await mkdir(workspace,{recursive:true});assert.deepEqual(await readdir(workspace),[],'Fresh private profile required');await mkdir(output,{recursive:true});
await mkdir(join(workspace,'.claude'),{recursive:true});
// Match the already-onboarded profile used by app journeys; approvals remain native.
await writeFile(join(workspace,'.claude/.claude.json'),JSON.stringify({hasCompletedOnboarding:true}));
await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify({theme:'dark'}));
const project=join(workspace,'project');await mkdir(project);
execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null'},timeout:5000,maxBuffer:1024*1024});
const sources={};for(const name of [new URL(import.meta.url),new URL('../protocol/native-managed-security-fixture.mjs',import.meta.url),new URL('./native-background-attach-check.mjs',import.meta.url),new URL('../protocol/record.mjs',import.meta.url),new URL('../protocol/synthetic-agent-model.mjs',import.meta.url),new URL('./native-platform-preload.mjs',import.meta.url)])sources[name.pathname]=createHash('sha256').update(await readFile(name)).digest('hex');
await writeFile(join(output,'source-inputs.json'),JSON.stringify(sources,null,2)+'\n');
const auth=await prepareNativeManagedSecurity(workspace,executable);await auth.close();
assert.ok(isAbsolute(checkout));
const preload=join(workspace,'background-observer.mjs');
const observation=String.raw`import {createHash} from 'node:crypto';import {readFileSync} from 'node:fs';
{
 const {writeFileSync,renameSync}=await import('node:fs');let last;const rows=[],deadline=Date.now()+100000;
 const timer=setInterval(async()=>{if(Date.now()>deadline){clearInterval(timer);return}try{
  const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),binding=runtime.ey();if(binding?.surface!=='terminal'||typeof binding.toolContext!=='function')return;
  const context=binding.toolContext(new AbortController()),tasks=Object.entries(context.taskRegistry.all()).slice(0,64).map(([id,t])=>({id,type:t.type,status:t.status,isBackgrounded:t.isBackgrounded,v2Run:t.v2Run!==undefined,stoppedByUser:t.stoppedByUser,workflowAgents:t.workflowProgress?.filter(row=>row.type==='workflow_agent').map(row=>({state:row.state,queuedAt:row.queuedAt,startedAt:row.startedAt}))}));
  const value={tasks,dialogs:context.dialogStore.getState().open.map(d=>({id:d.id,kind:d.kind}))},key=JSON.stringify(value),current={at:Date.now(),pid:process.pid,...value},file=OBSERVATION_FILE+'.'+process.pid;
  writeFileSync(file+'.tmp',JSON.stringify(current));renameSync(file+'.tmp',file);
  if(key===last)return;last=key;rows.push(current);if(rows.length>128)rows.shift();
  writeFileSync(file+'.history',JSON.stringify(rows));
 }catch(error){if(rows.length<128){rows.push({at:Date.now(),error:String(error)});writeFileSync(OBSERVATION_FILE+'.'+process.pid+'.history',JSON.stringify(rows))}}},100);timer.unref();
}`.replaceAll('OBSERVATION_FILE',JSON.stringify(join(workspace,'background-task-observations.json')));
await writeFile(preload,await adaptNativeResearchPreload(checkout,observation));
await mkdir(join(workspace,'.claude/agents'),{recursive:true});
await writeFile(join(workspace,'.claude/agents/status-fixture.md'),'---\nname: status-fixture\ndescription: Owned review task\nmodel: sonnet\n---\nNativeStatusChildSystem: return the fixed review response.\n');
const model=await startSyntheticAgentModel({workflowProbe:true,workflowScript:WORKFLOW_APPROVAL_FIXTURE_SCRIPT,holdChildUntilRelease:true,parentLaunchOnce:true,captureMessages:true,requestLimit:12});
const env={...auth.env,ANTHROPIC_BASE_URL:model.url,BUN_OPTIONS:'--preload='+preload};
const runs=[],actions=[];let short,stopped=false;
const save=async()=>writeFile(join(output,'background-session-observation.json'),JSON.stringify({targetVersion:'2.1.302',short,stopped,runs,actions,bootstrapKeyApproved:auth.state.bootstrapKeyApproved,modelCalls:model.calls},null,2)+'\n');
async function cli(label,args,timeoutMs=20000,tty=false){
 let terminal='';const keys=[],timers=[];
 try{
  const run=await record({executable:tty?'/usr/bin/python3':executable,args:tty?[new URL('../protocol/pty_bridge.py',import.meta.url).pathname,executable,...args]:args,cwd:project,env,output:join(output,label),timeoutMs,maxBytes:2*1024*1024,...(tty?{onStdout(bytes,channel){terminal+=bytes.toString('utf8');const stage=recognizeOnboardingPrompt(terminal,project);if(stage&&!keys.includes(stage)){keys.push(stage);timers.push(setTimeout(()=>channel.send(stage==='workspace-trust'?'\x1b[B':'\r'),stage==='workspace-trust-selected'?1500:200));}}}:{})});runs.push({label,...run,tty,trustKeys:keys});await save();
  const stdout=await readFile(join(run.directory,'stdout.bin'),'utf8'),stderr=await readFile(join(run.directory,'stderr.bin'),'utf8');return{...run,stdout,stderr};
 }finally{for(const timer of timers)clearTimeout(timer)}
}
const verifyFork=process.env.CLAUDE_RESEARCH_LEFTARROW_FORK==='1',verifyAttach=process.env.CLAUDE_RESEARCH_BACKGROUND_ATTACH==='1';
assert.ok(!verifyAttach||verifyFork,'Attachment probe requires an original fork');
let forkJob,attachment;
try{
 let terminal='',initialSent=false,checking=false,taskBefore,escapeAt,parentPid,retained=false,warning=false,phase='start';const timers=[];
 let run;
 try{
 run=await record({executable:'/usr/bin/python3',args:[new URL('../protocol/pty_bridge.py',import.meta.url).pathname,executable,'--model','claude-sonnet-4-6','--setting-sources','user,project,local','--tools','Workflow','--allowed-tools','Workflow','--permission-mode','acceptEdits','--strict-mcp-config'],cwd:project,env,output:join(output,'native-leftarrow'),timeoutMs:65000,maxBytes:2*1024*1024,onStdout(bytes,channel){
  terminal+=bytes.toString('utf8');const stage=recognizeOnboardingPrompt(terminal,project);
  if(stage&&!actions.includes(stage)){actions.push(stage);timers.push(setTimeout(()=>channel.send(stage==='workspace-trust'?'\x1b[B':'\r'),stage==='workspace-trust-selected'?1500:200));}
  const text=stripVTControlCharacters(terminal).replace(/\s/g,'');
  if(actions.includes('workspace-trust-selected')&&text.includes('APIUsageBilling')&&text.includes('shift+tabtocycle')&&!initialSent){initialSent=true;timers.push(setTimeout(()=>channel.send('Start the owned review task before opening the agents view.'),400),setTimeout(()=>channel.send('\r'),1100));}
  if(text.includes('Backgroundthissession?')&&phase==='await-warning'){warning=true;phase='escape-scheduled';terminal='';timers.push(setTimeout(()=>{channel.send('\x1b');escapeAt=Date.now();phase='after-escape';terminal='';},300));}
  if(!initialSent||checking||!['start','after-escape','await-fork-warning'].includes(phase))return;
  checking=true;void readdir(workspace).then(async names=>{
   const rows=await Promise.all(names.filter(name=>/^background-task-observations\.json\.\d+$/.test(name)).map(async name=>JSON.parse(await readFile(join(workspace,name),'utf8'))));
   const latest=rows.filter(row=>!parentPid||row.pid===parentPid).sort((a,b)=>b.at-a.at)[0],task=latest?.tasks?.find(t=>t.type==='local_workflow'&&t.status==='running');
   if(phase==='await-fork-warning'&&latest?.dialogs?.some(dialog=>dialog.kind==='left_arrow_confirm')){
   if(verifyAttach)warning=true;
   await writeFile(join(output,'original-fork-dialog.json'),JSON.stringify(latest,null,2));actions.push('original-left-arrow-confirm');
   phase='fork';terminal='';timers.push(setTimeout(()=>channel.send('\r'),300));
   let listing=false,attempts=0;const poll=setInterval(async()=>{if(listing||forkJob)return;listing=true;try{
    const result=await cli('fork-list-'+attempts++,['agents','--json','--all','--cwd',project]);
    const jobs=JSON.parse(result.stdout);forkJob=jobs.find(job=>job.kind==='background'&&Number.isSafeInteger(job.pid)&&job.state!=='stopped');
    if(forkJob){short=forkJob.id;await writeFile(join(output,'fork-job.json'),JSON.stringify(forkJob,null,2));phase='done';channel.stop('owned-leftarrow-observation-complete');}
    if(attempts>=12)clearInterval(poll);
   }catch(error){actions.push('fork-list-error:'+String(error));}finally{listing=false;}},1000);timers.push(poll);return;
  }
   if(!task?.workflowAgents?.some(agent=>agent.startedAt!==undefined)||latest.dialogs.some(d=>['local_jsx','left_arrow_confirm'].includes(d.kind)))return;
   if(phase==='start'){taskBefore=task;parentPid=latest.pid;phase=verifyAttach?'await-fork-warning':'await-warning';terminal='';actions.push('original-left-arrow');timers.push(setTimeout(()=>channel.send('\x1b[D'),400),setTimeout(()=>{if(!verifyAttach||phase==='await-fork-warning')channel.send('\x1b[D');},1600));}
   else if(phase==='after-escape'){
    if(latest.at<escapeAt+200)return;assert.equal(task.id,taskBefore.id);assert.deepEqual(task.workflowAgents,taskBefore.workflowAgents);retained=true;phase='done';
    await writeFile(join(output,'fresh-task-retention.json'),JSON.stringify({escapeAt,latest,taskBefore,parentPid},null,2));
    actions.push('same-original-task-retained');if(verifyFork){phase='await-fork-warning';terminal='';timers.push(setTimeout(()=>channel.send('\x1b[D'),400),setTimeout(()=>channel.send('\x1b[D'),1600));}else timers.push(setTimeout(()=>channel.stop('owned-leftarrow-observation-complete'),300));
   }
  }).catch(error=>{if(error.code!=='ENOENT')actions.push('observation-error:'+String(error));}).finally(()=>{checking=false});
 }});
 }finally{for(const timer of timers)clearTimeout(timer)}
 if(verifyFork&&forkJob&&verifyAttach)attachment=await observeOriginalBackgroundAttach({executable,project,env,job:forkJob,output,cli});
 if(verifyFork&&forkJob){const result=await cli('stop-fork',['stop',forkJob.id]);assert.equal(result.status,'complete');stopped=true;const listed=await cli('after-stop-fork',['agents','--json','--all','--cwd',project]);assert.equal(JSON.parse(listed.stdout).find(job=>job.id===forkJob.id)?.state,'stopped');}
 const evidence={verifyFork,verifyAttach,nativeAttachmentObserved:attachment?.frameSeen===true,escapeRetested:!verifyAttach,forkJob,stopped,targetVersion:'2.1.302',warning,retained,phase,taskBefore,actions,run,syntheticRequests:model.calls.length,realModelRequests:0,scope:verifyAttach?'Original warning/confirm/fork, public attach frame, retained worker after owned client SIGTERM and native Stop only. Escape was not retested; graceful detach, app attachment, prompt/approval/question interaction and stopped-child resume remain open.':verifyFork?'Original native left-arrow warning/Escape/confirm/fork/native Stop only; desktop, full agents-view interaction and attach/resume remain open.':'Original left-arrow admission/warning/Escape only; confirmation and desktop remain open.'};
 await writeFile(join(output,'leftarrow-evidence.json'),JSON.stringify(evidence,null,2));
 assert.ok(warning&&(verifyAttach||retained),'Original warning required; Escape retention is required only for the dedicated Escape journey');assert.equal(run.reason,'owned-leftarrow-observation-complete');if(verifyFork)assert.ok(forkJob&&stopped,'Original fork and native Stop required');
 console.log(JSON.stringify(evidence));
}finally{if(short&&!stopped)await cli('cleanup-stop',['stop',short],15000).catch(()=>{});await model.close();}
