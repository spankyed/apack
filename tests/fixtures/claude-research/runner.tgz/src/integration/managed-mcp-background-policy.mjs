import assert from 'node:assert/strict';
import {lstat,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {mcpTaskPrompt} from './native-mcp-task-journey.mjs';

const requests=(frames,method)=>frames.filter(frame=>frame.direction==='in'&&frame.value.method===method);

export async function holdManagedMcpBackgroundPoll({page,expect,context,replace,send,receipt,holdPath,serverName,taskTool}) {
  await replace(mcpTaskPrompt);
  await send.click();
  const approval=page.getByRole('region',{name:taskTool+' approval',exact:true});
  const yes=approval.getByRole('button',{name:'Yes',exact:true});
  await expect(yes).toBeEnabled();
  assert.equal(requests(await receipt(),'tools/call').length,0);
  await yes.click();
  await expect(approval).toBeHidden();
  const getTask=async()=> (await context()).native.state.tasks.find(task=>task.mcp?.serverName===serverName);
  await expect.poll(getTask,{timeout:20000}).toMatchObject({
    status:'running',mcp:{serverName,serverTaskId:'owned-review-1'},
  });
  const task=await getTask();
  const opened=await context();
  const owner={threadId:opened.threadId,sessionId:opened.claude.sessionId,
    ownerId:opened.native.state.ownerId,nativePid:opened.native.state.nativePid};
  const found=()=>receipt().then(frames=>frames.find(frame=>frame.value.event==='policy-poll-held')?.value);
  await writeFile(holdPath,'Hold the next owned poll until the connection retires.\n',{flag:'wx'});
  await expect.poll(found,{timeout:12000}).toMatchObject({taskId:task.mcp.serverTaskId});
  const before=await receipt();
  const held=await found();
  assert.equal(requests(before,'tools/call').length,1);
  assert.ok(!before.some(row=>row.direction==='out'&&row.value.id===held.id));
  return {prompt:mcpTaskPrompt,task,owner,held};
}

export async function observeManagedMcpBackgroundPolicy({page,expect,output,context,receipt,background,transport}) {
  const getState=async()=> {
    const current=await context();
    assert.deepEqual({
      threadId:current.threadId,sessionId:current.claude.sessionId,
      ownerId:current.native.state.ownerId,nativePid:current.native.state.nativePid,
    },background.owner);
    return current.native.state.tasks.find(task=>task.id===background.task.id);
  };
  await expect.poll(async()=> (await getState())?.mcp?.statusMessage,{timeout:18000}).toBe('reconnecting…');
  background.after=await getState();
  assert.equal(background.after.status,'running');
  assert.equal(background.after.mcp.serverTaskId,background.task.mcp.serverTaskId);
  if(transport==='http'){
    const closure=async()=> (await receipt()).find(row=>row.value.event==='policy-poll-closed'&&row.value.id===background.held.id)?.value;
    await expect.poll(closure).toMatchObject({taskId:background.held.taskId});
    background.transportClosure=await closure();
  }
  const frames=await receipt();
  assert.ok(!frames.some(row=>row.value.event==='policy-peer-error'));
  assert.equal(frames.filter(row=>row.value.event==='policy-peer-started').length,1);
  assert.equal(frames.filter(row=>row.value.event==='policy-poll-held').length,1);
  assert.equal(requests(frames,'tasks/cancel').length,0);
  assert.ok(!frames.some(row=>row.direction==='out'&&row.value.id===background.held.id));
  const row=page.getByRole('region',{name:'MCP tasks',exact:true})
    .locator('[data-native-mcp-task-id="'+background.task.id+'"]');
  await row.getByRole('button',{name:'Task details',exact:true}).click();
  const details=page.getByRole('dialog',{name:'MCP task details',exact:true});
  await expect(details.getByText('reconnecting…',{exact:true})).toBeVisible();
  const file='managed-mcp-background-reconnecting-compact.png';
  await page.screenshot({path:join(output,file),animations:'disabled'});
  await details.getByRole('button',{name:'Close',exact:true}).click();
  await expect(details).toBeHidden();
  return file;
}

export async function observeManagedMcpReconnectExhaustion({page,expect,output,context,background,captures,restrictionAt,parkedPresentation}) {
  const task=async()=> (await context()).native.state.tasks.find(candidate=>candidate.id===background.task.id);
  const row=page.getByRole('region',{name:'MCP tasks',exact:true})
    .locator('[data-native-mcp-task-id="'+background.task.id+'"]');
  const details=page.getByRole('dialog',{name:'MCP task details',exact:true});
  const open=()=>row.getByRole('button',{name:'Task details',exact:true}).click();
  if(parkedPresentation){
    await open();
    await expect(details.getByText('reconnecting…',{exact:true})).toBeVisible();
    await expect(details.getByText('Every 1s',{exact:true})).toBeVisible();
    await expect(details.getByText('Outcome unknown',{exact:true})).toHaveCount(0);
  }
  // Let the original native reconnect deadline run under the live managed restriction.
  const reconnectDeadline=/did not reconnect within 300s/;
  await expect.poll(async()=> (await task())?.mcp?.statusMessage??'',{
    timeout:335000,intervals:[1000,2000,4000],
  }).toMatch(reconnectDeadline);
  const exhausted=await task(),at=Date.now();
  assert.ok(at-restrictionAt>=300000);
  assert.equal(exhausted.mcp.serverTaskId,background.task.mcp.serverTaskId);
  if(parkedPresentation){
    assert.equal(exhausted.mcp.parked,true);
    assert.equal(exhausted.mcp.pollIntervalMs,1000);
  }else await open();
  for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
    await page.setViewportSize({width,height});
    await expect(details.getByText(exhausted.mcp.statusMessage,{exact:true})).toBeVisible();
    await expect(details.getByText(exhausted.mcp.serverTaskId,{exact:true})).toBeVisible();
    if(parkedPresentation){
      await expect(row.locator(':scope > div:first-child').getByText('Outcome unknown',{exact:true})).toHaveCount(1);
      await expect(details.getByText('Outcome unknown',{exact:true})).toBeInViewport({ratio:1});
      await expect(details.getByText('Last server status',{exact:true})).toBeVisible();
      await expect(details.getByText(exhausted.mcp.status,{exact:true})).toBeVisible();
      await expect(details.getByText('Polling',{exact:true})).toHaveCount(0);
      await expect(details.getByRole('button',{name:'Stop task',exact:true})).toBeEnabled();
    }
    const file=`managed-mcp-native-reconnect-exhausted-${size}.png`;
    await page.screenshot({path:join(output,file),animations:'disabled'});
    captures.push(file);
  }
  await details.getByRole('button',{name:'Close',exact:true}).click();
  await expect(details).toBeHidden();
  background.exhausted={task:exhausted,at,restrictionAt,elapsedMs:at-restrictionAt,...(parkedPresentation&&{liveStatusUpdated:true})};
}

export async function observeManagedMcpParkedRecovery({page,expect,output,context,background,captures,control,finishPath,receipt}) {
  const before=await receipt(),reallowPath=join(control,'receipt-3.json');
  await writeFile(finishPath,'Complete the original task on its next admitted poll.\n',{flag:'wx'});
  await writeFile(join(control,'request-3.json'),JSON.stringify({sequence:3,mode:'unrestricted'}),{flag:'wx',mode:0o600});
  await expect.poll(async()=>{
    try{return (await lstat(reallowPath)).uid===0;}
    catch(error){if(error.code==='ENOENT')return false;throw error;}
  },{timeout:10000}).toBe(true);
  const policy=JSON.parse(await readFile(reallowPath,'utf8'));
  assert.equal(policy.sequence,3);
  assert.equal(policy.mode,'unrestricted');
  assert.deepEqual(JSON.parse(await readFile(policy.path,'utf8')),{});
  const recovered=async()=> (await receipt()).slice(before.length).find(frame=>frame.direction==='out'
    &&frame.value.result?.taskId===background.task.mcp.serverTaskId&&frame.value.result.status==='completed')?.value;
  await expect.poll(recovered,{timeout:60000,intervals:[250,500,1000]}).toBeDefined();
  const reply=await recovered();
  const transcript=await receipt();
  const completed=transcript.filter(frame=>frame.direction==='out'&&frame.value.result?.taskId===background.task.mcp.serverTaskId
    &&frame.value.result.status==='completed');
  assert.equal(completed.length,1);
  assert.equal(requests(transcript,'tools/call').length,1);
  assert.ok(transcript.slice(before.length).some(frame=>frame.direction==='in'&&frame.value.method==='tasks/get'
    &&frame.value.id===reply.id&&frame.value.params.taskId===background.task.mcp.serverTaskId));
  const row=page.getByRole('region',{name:'MCP tasks',exact:true})
    .locator('[data-native-mcp-task-id="'+background.task.id+'"]');
  await expect(row).toHaveCount(0,{timeout:20000});
  const current=await context();
  assert.equal(current.claude.sessionId,background.owner.sessionId);
  assert.equal(current.native.state.ownerId,background.owner.ownerId);
  assert.equal(current.native.state.nativePid,background.owner.nativePid);
  const file='managed-mcp-parked-task-recovered-compact.png';
  await page.screenshot({path:join(output,file),animations:'disabled'});
  captures.push(file);
  background.recovery={rootReceipt:policy,trafficBefore:before,reply,owner:background.owner};
}
