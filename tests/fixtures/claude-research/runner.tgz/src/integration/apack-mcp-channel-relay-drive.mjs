import assert from 'node:assert/strict';
import {readFile,rename,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {channelEchoTool,channelRelayPrompts,channelRelayRequest,channelRelayReply} from '../protocol/owned-channel-relay.mjs';
import {channelSelector,channelServer} from './owned-channel-installation.mjs';

export async function driveOwnedChannelRelay({page,expect,context,composer,send,section,replace,proof,output,debug,receipts,relayDirectory,model,birth,save,phase}) {
  proof.scope='Owned local legacy channel permission relay with original addressed choices and desktop approval retirement.';
  const registration='MCP server "'+channelServer+'": Channel notifications registered';
  const log=()=>readFile(debug,'utf8');
  await expect.poll(async()=> (await log()).includes(registration),{timeout:18000}).toBe(true);
  assert.deepEqual((await context()).claude.nativeLaunch.channels,[channelSelector]);
  const initialOwner=proof.initial.native.state.ownerId;
  const wire=async()=>{
    const text=await readFile(receipts,'utf8');
    return text.slice(0,text.lastIndexOf('\n')+1).split('\n').filter(Boolean).map(JSON.parse);
  };
  const relayRequests=async()=> (await wire()).filter(row=>row.direction==='in'&&row.value.method===channelRelayRequest)
    .map(row=>row.value.params);
  const toolCalls=async()=> (await wire()).filter(row=>row.direction==='in'&&row.value.method==='tools/call');
  const approval=page.getByRole('region',{name:channelEchoTool+' approval',exact:true});
  const resultFor=round=>model.calls.flatMap(row=>row.messages??[]).flatMap(message=>
    Array.isArray(message.content)?message.content:[]).find(block=>block.type==='tool_result'
     &&block.tool_use_id==='toolu_owned_relay_'+round);
  const answer=async(slot,requestId,behavior)=>{
    const destination=join(relayDirectory,'reply-'+slot+'.json');
    await writeFile(destination+'.pending',JSON.stringify({requestId,behavior}),{flag:'wx'});
    await rename(destination+'.pending',destination);
  };
  const verifyRelay=async(requestId,behavior,disposition)=>{
    const marker='notifications/claude/channel/permission: '+requestId+' → '+behavior+' ('+disposition;
    await expect.poll(async()=> (await log()).includes(marker),{timeout:8000}).toBe(true);
  };

  proof.relayRounds=[];
  for(const [i,prompt] of channelRelayPrompts.entries()){
    const round=i+1;
    await replace(prompt);await send.click();
    await expect(approval).toBeVisible();
    await expect.poll(async()=> (await relayRequests()).length,{timeout:12000}).toBe(round);
    const pending=(await context()).claude.pendingControlRequest;
    const offer=(await relayRequests())[i];
    assert.equal(pending.toolName,channelEchoTool);
    assert.equal(pending.nativeTerminal.ownerId,initialOwner);
    assert.equal(offer.tool_name,channelEchoTool);
    assert.ok(offer.input_preview&&offer.description);
    assert.ok(!proof.relayRounds.some(row=>row.approvalId===pending.approvalMessageId||row.request.request_id===offer.request_id));
    assert.equal((await toolCalls()).length,0);
    const priorInterruptions=new Set((await context()).messages.filter(message=>message.context?.claudeNativeInterruption).map(message=>message.id));
    const entry={prompt,request:offer,approvalId:pending.approvalMessageId};
    proof.relayRounds.push(entry);await save();
    if(round===1){
      await approval.getByRole('button',{name:'Deny',exact:true}).click();
      entry.decision='desktop-deny';
    }else if(round===2){
      const retired=proof.relayRounds[0].request.request_id;
      await answer(1,retired,'allow');
      await verifyRelay(retired,'allow','no pending entry');
      assert.equal((await context()).claude.pendingControlRequest.approvalMessageId,entry.approvalId);
      assert.equal((await toolCalls()).length,0);
      await expect(approval).toBeVisible();
      await answer(2,offer.request_id,'deny');
      await verifyRelay(offer.request_id,'deny','matched pending');
      entry.decision='channel-deny';
    }else{
      await page.setViewportSize({width:680,height:600});
      await expect(approval.getByRole('button',{name:'Deny',exact:true})).toBeInViewport({ratio:1});
      const capture='native-channel-permission-pending-compact.png';
      await page.screenshot({path:join(output,capture),animations:'disabled'});
      proof.captures.push(capture);
      await answer(3,offer.request_id,'allow');
      await verifyRelay(offer.request_id,'allow','matched pending');
      entry.decision='channel-allow';
    }
    await expect(approval).toHaveCount(0);
    if(round===1){
      const interruption=async()=> (await context()).messages.find(message=>
        !priorInterruptions.has(message.id)&&message.context?.claudeNativeInterruption?.sessionId===proof.sessionId);
      await expect.poll(async()=>!!await interruption(),{timeout:15000}).toBe(true);
      entry.interruption=(await interruption()).context.claudeNativeInterruption;
      assert.equal((await toolCalls()).length,0);
    }else{
      await expect.poll(()=>!!resultFor(round),{timeout:20000}).toBe(true);
      entry.result=resultFor(round);
      if(round===2){
        assert.equal(entry.result.is_error,true);
        assert.ok(JSON.stringify(entry.result.content).includes('Denied via channel '+channelServer));
        assert.equal((await toolCalls()).length,0);
      }else{
        assert.notEqual(entry.result.is_error,true);
        assert.ok(JSON.stringify(entry.result.content).includes(channelRelayReply));
      }
    }
    await expect.poll(async()=>{
      const state=await context();
      return !state.native.state.busy&&!state.claude.pendingControlRequest&&state.claude.chatState==='success';
    },{timeout:15000}).toBe(true);
    await save();
  }
  const [call]=await toolCalls();
  assert.equal((await toolCalls()).length,1);
  assert.deepEqual(call.value.params.arguments,{message:'Owned release echo 3'});
  await replace(proof.draft);
  await expect(composer).toHaveText(proof.draft);
  proof.final=await context();
  assert.equal(proof.final.threadId,proof.initial.threadId);
  assert.equal(proof.final.claude.sessionId,proof.sessionId);
  assert.equal(proof.final.native.state.ownerId,initialOwner);
  assert.equal(await birth(proof.pid),proof.processStart);
  const capture='native-channel-permission-settled-compact.png';
  await page.screenshot({path:join(output,capture),animations:'disabled'});
  proof.captures.push(capture);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
  proof.status='complete';
  await save();
  phase('native-channel-relay-complete');
}
