/** Public native theme files for the owned Permissions feedback journey. */
export const permissionsFeedbackThemes={
 initial:{name:'Permissions review',base:'dark',overrides:{error:'#ff9b85'}},
 reloaded:{name:'Permissions review',base:'dark',overrides:{error:'#ffb3d1'}},
};
