import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {randomUUID} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {createRun,hash} from '../artifacts/runs.mjs';
import {record} from '../protocol/record.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {nativeDialogInspector} from '../protocol/native-dialog-inspector.mjs';
import {requireReviewedNativeAppTarget,adaptNativeResearchPreload} from './native-platform-preload.mjs';

/** Observe a genuine fallback request under the product terminal owner; no dialog injection or gate overrides. */
export async function probeNativeRefusalOwner(checkout,executable,root,output,{decision='escape'}={}){
 assert.ok(['escape','retry_fallback','edit_prompt','cancelled'].includes(decision));
 const target=await requireReviewedNativeAppTarget(checkout,executable);
 assert.equal(target.platform,'linux','Run original native only in the isolated Linux container');
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'refusal-owner-')),home=join(workspace,'home'),config=join(home,'.claude');await mkdir(config,{recursive:true});
 const source=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-owner.ts');
 const run=await createRun(output,'native-refusal-owner',{...target,decision,driverSha256:hash(await readFile(new URL(import.meta.url))),productOwnerSha256:hash(await readFile(source)),workspace});
 const sessionId=randomUUID(),settings={apiKeyHelper:'/usr/bin/printf research-fixture-key',switchModelsOnFlag:false,statusLine:{type:'command',command:'/usr/bin/printf RefusalOwnerReady',refreshInterval:1}};
 await writeFile(join(config,'settings.json'),JSON.stringify(settings));
 const inspection=join(workspace,'native-dialogs.json'),preload=join(workspace,'refusal-inspector.mjs');
 await writeFile(preload,await adaptNativeResearchPreload(checkout,nativeDialogInspector(inspection,{promptRestoration:decision==='edit_prompt'})));
 const env={PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',ANTHROPIC_DEFAULT_OPUS_MODEL:'claude-opus-4-8',BUN_OPTIONS:'--preload='+preload};
 const seedModel=await startSyntheticModel(workspace,'TextOnly',{maxRequests:2}),model=await startSyntheticModel(workspace,'Refusal',{maxRequests:4,refusalCategory:'cyber',...(decision==='edit_prompt'?{refusalText:''}:{})});
 let prepared,native,timer,terminal='',sequence=0,lastInput=0;const onboarding=new Set(),states=[];let receipt,found,restoredNativeDraft;
 const controller=new AbortController(),watchdog=setTimeout(()=>controller.abort(Error('Bounded refusal owner observation expired')),65000);
 const save=async error=>{await writeFile(join(workspace,'terminal.txt'),terminal);await writeFile(join(workspace,'result.json'),JSON.stringify({sessionId,receipt,found,restoredNativeDraft,states,seedCalls:seedModel.calls,modelCalls:model.calls,...error?{error:String(error)}:{}},null,2)+'\n');};
 async function waitFor(check,label,ms=20000){const deadline=Date.now()+ms;while(Date.now()<deadline){if(controller.signal.aborted)throw controller.signal.reason;if(await check())return;await delay(50);}throw Error(label);}
 try{
  const seed=await record({executable,cwd:workspace,output,timeoutMs:15000,maxBytes:1024*1024,args:['--print','--output-format','json','--session-id',sessionId,'--model','claude-opus-5','--setting-sources','user','--settings',JSON.stringify(settings),'--tools','','--','Seed the private refusal-owner session.'],env:{...env,ANTHROPIC_BASE_URL:seedModel.url}});
  assert.equal(seed.code,0,'Original seed must finish successfully');assert.equal(seedModel.calls.length,1);
  const {prepareClaudeNativeTerminal}=await import(pathToFileURL(source).href);
  prepared=await prepareClaudeNativeTerminal({sessionId,cwd:workspace,settings:{effective:settings,sources:[{source:'userSettings',settings}]},permissionMode:'default',cliPath:executable,env:{...env,ANTHROPIC_BASE_URL:model.url},model:'claude-opus-5',columns:110,rows:34,signal:controller.signal});native=await prepared.start();
  const observe=()=>{
   for(const chunk of native.output)if(chunk.sequence>sequence){terminal+=chunk.text;sequence=chunk.sequence;}
   if(terminal.length>1024*1024)terminal=terminal.slice(-1024*1024);
   const state=native.state;if(states.length<128&&JSON.stringify(states.at(-1))!==JSON.stringify(state))states.push(state);
   if(Date.now()-lastInput<250)return;
   const screen=recognizeOnboardingPrompt(terminal,workspace);let input;
   if(screen==='theme'&&!onboarding.has(screen))input='\r';
   if(screen==='security-notes'&&!onboarding.has(screen))input='\r';
   if(screen==='workspace-trust'&&!onboarding.has(screen))input='\x1b[B';
   if(screen==='workspace-trust-selected'&&onboarding.has('workspace-trust')&&!onboarding.has(screen))input='\r';
   if(input!==undefined){onboarding.add(screen);lastInput=Date.now();native.input(state.ownerId,input);}
  };
  timer=setInterval(observe,100);observe();
  await waitFor(()=>native.state.status==='live'&&native.state.mainStatus?.includes('RefusalOwnerReady'),'Original terminal owner did not become ready');
  receipt=await native.submit('Return the fixed local refusal fixture.');assert.equal(receipt.sessionId,sessionId);assert.ok(receipt.uuid);assert.equal(receipt.text,'Return the fixed local refusal fixture.');
  await waitFor(async()=>{try{const report=JSON.parse(await readFile(inspection,'utf8'));for(const event of report.events??[]){const open=event.value?.open;if(Array.isArray(open)){const item=open.find(item=>item.kind==='refusal_fallback_prompt');if(item){found={item,eventType:event.type};return true;}}}return false;}catch{return false;}},'No original populated refusal dialog observed');
  assert.equal(found.item.payload.originalModel,'claude-opus-5');assert.equal(found.item.payload.fallbackModel,'claude-opus-4-8');
  await save();
  if(decision==='escape')assert.equal(native.input(native.state.ownerId,'\x1b'),true);
  else{
   await waitFor(async()=>{await native.refreshNotice();return native.state.notice?.kind==='refusal_fallback_prompt';},'Desktop refusal projection did not become available');
   const notice=native.state.notice;assert.equal(notice.originalModel,'claude-opus-5');assert.equal(notice.fallbackModel,'claude-opus-4-8');
   await writeFile(join(workspace,'desktop-notice.json'),JSON.stringify(notice,null,2)+'\n');
   await native.answerNotice({id:notice.id,revision:notice.revision,sessionId:notice.sessionId,decision});
  }
  await waitFor(async()=>{try{const report=JSON.parse(await readFile(inspection,'utf8'));return report.events.some(event=>event.type==='closed'&&event.value.id===found.item.id);}catch{return false;}},'Original refusal callback did not retire the dialog');
  if(decision==='edit_prompt')await waitFor(async()=>{const report=JSON.parse(await readFile(inspection,'utf8'));const close=report.events.findIndex(event=>event.type==='closed'&&event.value.id===found.item.id);restoredNativeDraft=report.events.slice(close+1).find(event=>event.type==='local-prompt'&&event.value.text===receipt.text&&event.value.turn===null)?.value;return close>=0&&!!restoredNativeDraft;},'Original local editor did not restore its submitted prompt');
  await native.close();await native.done;clearInterval(timer);timer=undefined;await save();
  await run.finish({status:'complete',sessionId,inspection,syntheticModelRequests:seedModel.calls.length+model.calls.length,realModelRequests:0,scope:decision==='escape'?'Product terminal owner original refusal dialog and Escape only; no desktop host acceptance.':'Original populated refusal projection and callback under product terminal owner; no mounted actual-app acceptance.'});
  return {directory:run.directory,status:'complete',workspace,sessionId};
 }catch(error){await save(error);await run.finish({status:'failed',error:String(error),workspace});throw error;}
 finally{clearInterval(timer);clearTimeout(watchdog);await native?.close().catch(()=>{});await prepared?.dispose().catch(()=>{});await seedModel.close();await model.close();}
}
