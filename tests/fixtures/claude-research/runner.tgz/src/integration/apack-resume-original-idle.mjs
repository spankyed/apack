import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { basename, dirname, join } from 'node:path';
import { pathToFileURL } from 'node:url';

const [research, product, executable, source, workspace] = process.argv.slice(2);
assert.equal(process.arch, 'arm64');
assert.equal(process.platform, 'darwin');
assert.match(basename(workspace), /^claude-idle-resume-proof-[A-Za-z0-9]+$/);
assert.equal(process.env.HOME, workspace);
for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN']) {
  assert.equal(process.env[key], undefined);
}
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const pin = JSON.parse(await readFile(join(research, 'docs/reviews/release-2.1.302-pin.json'), 'utf8'));
assert.equal(pin.version, '2.1.302');
assert.equal(pin.platform, 'darwin-arm64');
const targetSha256 = sha(await readFile(executable));
assert.equal(targetSha256, pin.binarySha256);
const fixture = JSON.parse(await readFile(join(research, 'docs/reviews/release-300-302-dispositions.json'), 'utf8')).scheduledIdleCompactionObservation;
const original = await readFile(source);
assert.equal(sha(original), fixture.journalSha256);
const rows = original.toString().trim().split('\n').map(JSON.parse);
const boundary = rows.find(row => row.uuid === fixture.boundary.uuid);
const summary = rows.find(row => row.uuid === fixture.summary.uuid);
assert.equal(boundary.subtype, 'compact_boundary');
assert.equal(boundary.compactMetadata.trigger, 'auto');
assert.equal(summary.parentUuid, boundary.uuid);
assert.equal(summary.isCompactSummary, true);
const sessionId = boundary.sessionId;
assert.match(sessionId, /^[a-f0-9-]{36}$/);
const cwd = join(workspace, 'project');
const profile = join(workspace, '.claude');
const bucket = cwd.replace(/[^a-zA-Z0-9]/g, '-');
const imported = join(profile, 'projects', bucket, sessionId + '.jsonl');
await mkdir(dirname(imported), { recursive: true, mode: 0o700 });
await mkdir(cwd);
await writeFile(imported, original, { flag: 'wx', mode: 0o600 });

const { idleReply, idleSummary, startIdleCompactionModel } = await import(pathToFileURL(join(research, 'src/protocol/native-idle-compaction-model.mjs')).href);
const { query } = await import(pathToFileURL(join(product, 'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href);
const prompt = 'Continue from the saved release checklist after compaction.';
const model = await startIdleCompactionModel();
const events = [];
let handle;
try {
  handle = await query({
    cliPath: executable, cwd, model: 'sonnet', resume: sessionId,
    env: { HOME: workspace, CLAUDE_CONFIG_DIR: profile, ANTHROPIC_BASE_URL: model.url, DISABLE_AUTOUPDATER: '1',
      CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
    strictMcpConfig: true, settingSources: [], tools: [],
    settings: JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' }),
    replayUserMessages: true, keepStdinOpen: true, signal: AbortSignal.timeout(30_000),
  });
  await handle.initialized;
  handle.send(prompt);
  for await (const event of handle.events) {
    events.push(event);
    if (event.type === 'result' && !handle.hasPendingBackgroundTasks(event)) break;
  }
  const result = events.find(row => row.type === 'result');
  assert.equal(result?.subtype, 'success');
  assert.equal(result.session_id, sessionId);
  assert.equal(result.result, idleReply);
  assert.deepEqual(model.errors, []);
  assert.equal(model.calls.filter(call => call.kind === 'summary').length, 0);
  assert.ok(model.calls.some(call => call.receivedSummary), 'Original resume did not use the saved compact summary');
  const pid = handle.pid;
  await handle.close();
  handle = undefined;
  assert.throws(() => process.kill(pid, 0), { code: 'ESRCH' });
  const after = await readFile(imported);
  const resumed = after.toString().trim().split('\n').map(JSON.parse);
  assert.ok(resumed.some(row => row.uuid === summary.uuid && JSON.stringify(row.message).includes(idleSummary)));
  assert.equal(resumed.filter(row => row.sessionId === sessionId && row.type === 'user' && row.message?.content === prompt).length, 1);
  assert.equal(sha(await readFile(source)), fixture.journalSha256);
  const evidence = { status:'verified-original-saved-idle-resume',
    targetSha256, sourceJournalSha256: sha(original), resumedJournalSha256: sha(after), sessionId,
    boundaryUuid: boundary.uuid, summaryUuid: summary.uuid, modelCalls: model.calls,
    result: { subtype: result.subtype, result: result.result, sessionId: result.session_id }, retired: true,
    scope: 'Pinned macOS CLI print resumes a private byte-identical Linux journal from the timed desktop run. Original warm owner, desktop recovery and compact rendering are separate.' };
  await writeFile(join(workspace, 'saved-idle-resume.json'), JSON.stringify(evidence, null, 2) + '\n');
  console.log(JSON.stringify(evidence));
} finally {
  await handle?.close();
  await model.close();
  await writeFile(join(workspace, 'native-events.json'), JSON.stringify(events, null, 2) + '\n');
}
