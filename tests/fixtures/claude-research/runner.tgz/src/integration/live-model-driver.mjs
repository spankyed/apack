import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const[checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const{query}=await import(pathToFileURL(join(base,'query.ts'))),{createClaudeConversation}=await import(pathToFileURL(join(base,'conversation.ts')));
const cwd=join(workspace,'project'),config=join(workspace,'.claude');await mkdir(cwd);await mkdir(config,{recursive:true});
const settings=join(config,'settings.json'),before=JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',language:'preserve'});await writeFile(settings,before);
const model=await startSyntheticModel(cwd,'TextOnly');let native,owner;const results=[],models=[];
try{
 native=await query({cliPath:executable,cwd,env:{HOME:workspace,CLAUDE_CONFIG_DIR:config,ANTHROPIC_BASE_URL:model.url},tools:[],strictMcpConfig:true,settingSources:['user'],noSessionPersistence:true,model:'sonnet',replayUserMessages:true,keepStdinOpen:true,signal:AbortSignal.timeout(25000)});
 await native.initialized;
 let finish,reject;
 const consume=async turn=>{try{for await(const event of turn.handle.events){if(event.type==='system'&&event.subtype==='init')models.push(event.model);if(event.type==='result')results.push(event)}await turn.handle.result;owner.release(turn.handle);finish();}catch(error){reject(error);}};
 owner=createClaudeConversation(native,consume);
 const input=async text=>{await new Promise((yes,no)=>{finish=yes;reject=no;owner.start(text,consume)});assert.equal(owner.busy,false);};
 await input('First fixed synthetic text.');const session=owner.sessionId;
 await owner.handle.setModel('haiku');assert.equal(owner.modelSelection,'haiku');await input('Second fixed synthetic text.');
 await owner.handle.setModel('research-custom-model');assert.equal(owner.modelSelection,'research-custom-model');await input('Third fixed synthetic text.');
 await assert.rejects(owner.handle.setModel(''));assert.equal(owner.modelSelection,'research-custom-model');assert.equal(owner.busy,false);
 assert.equal(results.length,3);assert.ok(results.every(value=>value.subtype==='success'&&!value.is_error&&value.session_id===session));assert.equal(model.calls.length,4);
 assert.match(models[0],/sonnet/);assert.match(models[1],/haiku/);assert.equal(models[2],'research-custom-model');assert.equal(await readFile(settings,'utf8'),before);
 await owner.close();
 console.log(JSON.stringify({evidence:'apack-native-live-model',sameOwner:true,sameSession:true,turns:results.length,effectiveModels:models,modelCalls:model.calls.map(value=>({path:value.path,model:value.model})),emptySelectionRejected:true,selectionPreservedOnRejection:true,settingsUnchanged:true,realModelRequests:0,qualification:'Actual app query and conversation source; source command/reuse tested separately, compiled publication and mounted UI unverified.'}));
}finally{owner?.kill();native?.kill();await native?.close().catch(()=>{});await model.close();}
