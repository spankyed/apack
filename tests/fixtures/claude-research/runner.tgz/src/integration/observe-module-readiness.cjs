const http = require('node:http');
const { syncBuiltinESMExports } = require('node:module');
const { appendFileSync, readFileSync, lstatSync } = require('node:fs');
const { dirname, basename, join } = require('node:path');

const directory = process.env.CLAUDE_RESEARCH_MODULE_READINESS;
if (directory && !process.versions.bun && typeof process.env.API_PORT === 'string') {
  if (process.platform !== 'linux' || process.getuid() !== 1000 ||
      !/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+\/readiness$/.test(directory))
    throw Error('Unexpected observer boundary');
  const owner = lstatSync(directory);
  if (!owner.isDirectory() || owner.uid !== 1000 || (owner.mode & 0o077)) throw Error('Unexpected observer owner');
  let count = 0;
  let held = false;
  const record = (kind, data = {}) => {
    if (++count <= 512) appendFileSync(join(directory, 'traffic.jsonl'),
      JSON.stringify({ kind, pid: process.pid, at: Date.now(), ...data }) + '\n', { mode: 0o600 });
  };
  record('installed');
  const createServer = http.createServer;
  http.createServer = function (...args) {
    const server = Reflect.apply(createServer, this, args);
    server.prependListener('request', (req, res) => {
      if (req.method !== 'POST' || !['/ui-ready', '/poll'].includes(req.url)) return;
      const socket = server.address();
      if (typeof socket !== 'string' || basename(socket) !== 'bridge.sock' ||
          !/^\/tmp\/cc-app-[A-Za-z0-9_-]+$/.test(dirname(socket))) return;
      let target;
      try { target = readFileSync(join(directory, 'session'), 'utf8'); }
      catch (error) { if (error.code === 'ENOENT') return; throw error; }
      let size = 0;
      const chunks = [];
      req.on('data', chunk => { size += chunk.length; if (size <= 65536) chunks.push(chunk); });
      req.once('end', () => {
        if (size > 65536) return;
        let value;
        try { value = JSON.parse(Buffer.concat(chunks)); } catch { return; }
        if (value.sessionId !== target) return;
        if (req.url === '/poll') {
          record('poll', { sessionId: target, direct: value.directOwner === true });
          return;
        }
        record('ready-request', { sessionId: target });
        if (held) return;
        const end = res.end;
        res.end = function (...args) {
          res.end = end;
          if (res.statusCode !== 200 || held) return Reflect.apply(end, res, args);
          held = true;
          record('ready-held', { sessionId: target, status: res.statusCode });
          res.once('finish', () => record('ready-finished', { sessionId: target }));
          setTimeout(() => {
            if (res.destroyed) { record('ready-aborted', { sessionId: target }); return; }
            record('ready-released', { sessionId: target });
            Reflect.apply(end, res, args);
          }, 1500);
          return res;
        };
      });
    });
    return server;
  };
  syncBuiltinESMExports();
}
