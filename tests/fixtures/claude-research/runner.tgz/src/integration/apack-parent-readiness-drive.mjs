import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';

export function driveParentReadiness(options) {
 return driveChildComposer({...options,modelTool:'TextOnly',modelRequestLimit:24,journey:readinessJourney,journeyName:'parent-readiness'});
}
async function readinessJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 // Verify the actual owned profile through Settings before creating a conversation.
 // This also completes surface navigation instead of racing initial chat restoration.
 await app.navigate('host/settings');
 await page.evaluate(()=>{const actor=window.applicationState.system.get('host/settings');actor.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});actor.send({type:'TAB.SELECT',tab:'features'});});
 await expect(page.locator('#claude-profile')).toHaveValue('app');
 await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.tabs.every(tab=>c.tabsRead.includes(tab.id));}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.entries(c.nativeTerminalViews).filter(([,v])=>v.threadId===c.currentThread?.id).map(([mountId,v])=>({...v,mountId}))[0],ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');window.__claudeReadinessTrace=[];let prior='';window.__claudeReadinessSubscription=actor.subscribe(snapshot=>{const c=snapshot.context,rows=Object.values(c.nativeUiViews).filter(view=>view.threadId===c.currentThread?.id).flatMap(view=>[...(view.state?.transcriptMessages??[]),...(view.state?.composer??[])].map(row=>({component:row.component,uuid:row.uuid,status:row.body.status})));const key=JSON.stringify(rows);if(key!==prior&&window.__claudeReadinessTrace.length<256){prior=key;window.__claudeReadinessTrace.push({at:Date.now(),rows});}});});
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const proof={status:'running',parentSessionId,pid:initial.native.state.nativePid,captures:[],scope:'First parent-native message/status readiness and ordinary composer after Settings return; no broader parity claim.'};
 const save=()=>writeFile(join(output,'parent-readiness.json'),JSON.stringify(proof,null,2));
 const processIdentity=async pid=>{try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]==='Z'?undefined:fields[19];}catch(error){if(error.code==='ENOENT')return;throw error;}};
 proof.processStart=await processIdentity(proof.pid);assert.ok(proof.processStart);
 const snapshot=async()=>{const c=await context(),views=Object.entries(c.ui).filter(([,view])=>view.threadId===c.threadId);return {...c,views};};
 const ready=async()=>{const c=await snapshot();return c.views.some(([,view])=>view.state?.status==='live'&&(view.state.transcriptMessages??[]).length>0&&(view.state.transcriptMessages??[]).every(row=>row.body.status==='live'));};
 try{
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await expect.poll(ready,{timeout:15000}).toBe(true);proof.initial=await snapshot();
  await composer.fill('Keep the release summary draft while reviewing settings.');
  for(const[name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(size);await expect(card.getByRole('button',{name:'Send',exact:true})).toBeEnabled();await expect(card.getByRole('button',{name:'Send',exact:true})).toBeInViewport({ratio:1});await expect(composer).toHaveText('Keep the release summary draft while reviewing settings.');await expect(page.getByText('Claude message controls unavailable',{exact:true})).toHaveCount(0);
   const file='parent-readiness-initial-'+name+'.png';await page.screenshot({path:join(output,file)});proof.captures.push(file);await save();
  }
  await app.navigate('host/settings');await app.navigate('default-setup/threads');await expect.poll(ready,{timeout:15000}).toBe(true);await expect(composer).toHaveText('Keep the release summary draft while reviewing settings.');proof.afterSettings=await snapshot();assert.equal(proof.afterSettings.claude.sessionId,parentSessionId);
  const text='Continue the release summary after reviewing settings.';await composer.fill(text);await card.getByRole('button',{name:'Send',exact:true}).click();await expect.poll(()=>model.calls.some(call=>call.messages?.some(message=>message.role==='user'&&(message.content===text||Array.isArray(message.content)&&message.content.some(block=>block.type==='text'&&block.text===text)))),{timeout:15000}).toBe(true);
  await expect(card.getByRole('button',{name:'Send',exact:true})).toBeDisabled();await expect.poll(ready,{timeout:15000}).toBe(true);proof.afterSend=await snapshot();assert.equal(proof.afterSend.claude.sessionId,parentSessionId);proof.exactInputObserved=true;
  await composer.fill('Retain the next release summary draft.');const file='parent-readiness-return-compact.png';await page.screenshot({path:join(output,file)});proof.captures.push(file);
  proof.trace=await page.evaluate(()=>window.__claudeReadinessTrace);await save();assert.ok(!proof.trace.some(event=>event.rows.some(row=>row.status==='error')),'Original transcript/placement render failed during initial readiness or Settings return');
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processIdentity(proof.pid),{timeout:10000}).not.toBe(proof.processStart);proof.writerRetired=true;proof.final=await snapshot();proof.status='complete';await save();phase('parent-readiness-complete');
 }catch(error){proof.error={name:error.name,message:error.message.slice(0,2000)};proof.observed=await snapshot().catch(()=>null);proof.trace=await page.evaluate(()=>window.__claudeReadinessTrace).catch(()=>[]);await page.screenshot({path:join(output,'parent-readiness-failure.png')}).catch(()=>{});throw error;}
 finally{await page.evaluate(()=>window.__claudeReadinessSubscription?.unsubscribe()).catch(()=>{});await save();}
}
