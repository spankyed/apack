import assert from 'node:assert/strict';
import {join} from 'node:path';

/** Measure the live native completion menu against both composer layouts. */
export async function verifyPromptCompletionLayout({page,electronApp,section,card,composer,send,expect,context,
 output,proof,save,phase,sendMain,processStart,measureAgentFooter=false,verifyCompletionWindowFocus=false,promptEditHold}) {
  const result = proof.promptCompletionLayout = {geometry:[],captures:[],threadId:(await context()).threadId};
  const menu = page.getByRole('group',{name:'Claude suggestions',exact:true});
  const footer = page.getByTestId('thread-navigation');
  const recent = footer.getByRole('button',{name:/^Recent/});
  const verifyWindowSwitch = async (owner, editor, row) => {
    const window = await electronApp.browserWindow(page);
    const cdp = await page.context().newCDPSession(page);
    const hasFocus = () => page.evaluate(() => document.hasFocus());
    const nativeFocus = () => window.evaluate(window => window.isFocused());
    const snapshot = () => editor.evaluate(element => ({
      document:element.editor.state.doc.toJSON(),
      selection:element.editor.state.selection.toJSON(),
    }));
    const focusApp = async () => {
      await window.evaluate(window => { window.show();window.focus(); });
      await expect.poll(nativeFocus).toBe(true);
      await expect.poll(hasFocus).toBe(true);
    };
    let otherId;
    const focusOther = async () => {
      await electronApp.evaluate(({BrowserWindow}, id) => {
        const other = BrowserWindow.fromId(id);
        other.show();
        other.focus();
      },otherId);
      await expect.poll(() => electronApp.evaluate(({BrowserWindow}, id) => BrowserWindow.getFocusedWindow()?.id===id,otherId)).toBe(true);
      await expect.poll(nativeFocus).toBe(false);
      await expect.poll(hasFocus).toBe(false);
    };
    try {
      // Playwright emulates renderer focus by default, even after an Electron window blurs.
      await cdp.send('Emulation.setFocusEmulationEnabled',{enabled:false});
      await focusApp();
      const {ui,threadId} = await context();
      const mountIds = Object.entries(ui).filter(([,view]) => view.threadId===threadId
        && view.completions?.result?.suggestions?.some(item => item.label===`Complete #${owner}`)).map(([id]) => id);
      assert.equal(mountIds.length,1);
      await editor.press('ArrowDown');
      await expect(row).toBeFocused();
      const before = await snapshot();
      otherId = await electronApp.evaluate(async ({BrowserWindow}) => {
        const other = new BrowserWindow({width:380,height:250,show:false});
        await other.loadURL('about:blank');
        return other.id;
      });
      await focusOther();
      await expect(menu).toBeHidden();
      const duringBlur = await snapshot();
      assert.deepEqual(duringBlur,before);
      const focusedWhileBlurred = await hasFocus();
      assert.equal(focusedWhileBlurred,false);
      await focusApp();
      await expect(menu).toBeHidden();
      assert.deepEqual(await snapshot(),before);

      const index = (await promptEditHold.receipts()).length;
      await promptEditHold.arm({type:'CLAUDE_PROMPT_COMPLETIONS',threadId,mountId:mountIds[0],label:`Complete #${owner}x`});
      await editor.focus();
      await editor.pressSequentially('x');
      await expect.poll(async () => (await promptEditHold.receipts()).length).toBe(index+1);
      const pendingBefore = await snapshot();
      await focusOther();
      const delivery = await promptEditHold.release(index);
      assert.equal(delivery.outcome,'delivered-on-original-socket');
      await expect.poll(async () => (await context()).ui[mountIds[0]]?.completions?.revision).toBe(delivery.revision);
      await expect(menu).toBeHidden();
      const pendingDuringBlur = await snapshot();
      assert.deepEqual(pendingDuringBlur,pendingBefore);
      assert.equal(await hasFocus(),false);
      await focusApp();
      await expect(menu).toBeHidden();
      assert.deepEqual(await snapshot(),pendingBefore);
      await editor.focus();
      await editor.pressSequentially('y');
      await menu.getByRole('button',{name:`Complete #${owner}xy`,exact:true}).click();
      await expect(editor).toHaveText(`Review #${owner}xy-complete`);
      const file = `prompt-completion-window-focus-${owner}-compact-returned.png`;
      await page.screenshot({path:join(output,file),animations:'disabled'});
      (result.windowFocus??=[]).push({owner,viewport:page.viewportSize(),before,duringBlur,focusedWhileBlurred,
        pending:{before:pendingBefore,duringBlur:pendingDuringBlur,delivery},accepted:await editor.textContent()});
      result.captures.push(file);
      await save();
    } finally {
      if(otherId!==undefined)await electronApp.evaluate(({BrowserWindow}, id) => BrowserWindow.fromId(id)?.destroy(), otherId);
      await cdp.send('Emulation.setFocusEmulationEnabled',{enabled:true});
      await cdp.detach();
    }
  };
  const testOwner = async (owner, frame, editor, action) => {
    const status = frame.getByRole('status',{name:'Claude session status',exact:true});
    await expect(status).toBeVisible();
    if (verifyCompletionWindowFocus) {
      await page.setViewportSize({width:680,height:600});
      await expect(editor).toBeInViewport();
      await expect(action).toBeInViewport();
    }
    await editor.focus();
    await editor.pressSequentially(`Review #${owner}`);
    const row = menu.getByRole('button',{name:`Complete #${owner}`,exact:true});
    if (verifyCompletionWindowFocus) {
      await expect(row).toBeVisible();
      await verifyWindowSwitch(owner,editor,row);
      return;
    }
    for (const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
      await page.setViewportSize(viewport);
      for (const control of [status,editor,action,row]) await expect(control).toBeInViewport({ratio:0.98});
      const measure = async () => {
        const elements = {menu,frame,status,editor,action,...(measureAgentFooter&&{footer})};
        const boxes = Object.fromEntries(await Promise.all(Object.entries(elements)
          .map(async ([name,locator]) => [name,await locator.boundingBox()])));
        if (Object.values(boxes).some(box => !box)) return;
        return boxes;
      };
      await expect.poll(async () => {
        const boxes = await measure();
        return !!boxes && boxes.menu.y+boxes.menu.height<=boxes.frame.y-3
          && (!measureAgentFooter || boxes.frame.y+boxes.frame.height<=boxes.footer.y+1
            && boxes.action.y+boxes.action.height<=boxes.footer.y-1);
      },{timeout:5000}).toBe(true);
      const boxes = await measure();
      const rowHit = await row.evaluate(element => {
        const box=element.getBoundingClientRect();
        return element.contains(document.elementFromPoint(box.x+box.width/2,box.y+box.height/2));
      });
      assert.ok(rowHit);
      let actionHits, recentHit;
      if (measureAgentFooter) {
        await expect(recent).toBeInViewport({ratio:1});
        actionHits = await action.evaluate(element => {
          const box=element.getBoundingClientRect();
          return [box.y+4,box.y+box.height/2,box.bottom-4]
            .map(y=>element.contains(document.elementFromPoint(box.x+box.width/2,y)));
        });
        recentHit = await recent.evaluate(element => {
          const box=element.getBoundingClientRect();
          return element.contains(document.elementFromPoint(box.x+box.width/2,box.y+box.height/2));
        });
        assert.deepEqual(actionHits,[true,true,true]);
        assert.ok(recentHit);
      }
      const file = `prompt-completion-layout-${owner}-${size}.png`;
      await page.screenshot({path:join(output,file),animations:'disabled'});
      result.geometry.push({owner,size,viewport,boxes,rowHit,...(measureAgentFooter&&{actionHits,recentHit})});
      result.captures.push(file);
      await save();
    }
    await editor.press('ArrowDown');
    await expect(row).toBeFocused();
    await row.press('Escape');
    await expect(menu).toBeHidden();
    await expect(editor).toBeFocused();
    await expect(editor).toHaveText(`Review #${owner}`);
    await editor.pressSequentially('x');
    await menu.getByRole('button',{name:`Complete #${owner}x`,exact:true}).click();
    await expect(editor).toHaveText(`Review #${owner}x-complete`);
    (result.interactions??=[]).push({owner,escapeReturnedFocus:true,accepted:await editor.textContent()});
    await save();
  };

  await testOwner('main',card,composer,send);
  await page.setViewportSize({width:1100,height:900});
  await sendMain('Review the release notes with a worker.');
  await expect.poll(async () => (await context()).native.state.tasks.some(task=>task.status==='running'),{timeout:15000}).toBe(true);
  const tools = page.getByRole('button',{name:/^Native tools/}).first();
  if (await tools.getAttribute('aria-expanded')!=='true') await tools.click();
  const worker = page.locator('[data-native-agent-id]').first();
  const taskId = await worker.getAttribute('data-native-agent-id');
  assert.ok(taskId);
  result.taskId = taskId;
  await worker.getByRole('button',{name:'Open Agent',exact:true}).click();
  const focused = page.getByRole('region',{name:'Focused Agent conversation',exact:true});
  const frame = focused.getByRole('form',{name:'Agent message',exact:true});
  const editor = frame.locator('[contenteditable="true"]');
  const submit = frame.getByRole('button',{name:'Send to Agent',exact:true});
  await testOwner('agent',frame,editor,submit);
  if (measureAgentFooter) {
    // The fixture completes every # token, so accepting an offer can immediately open the next one.
    await expect(menu.getByRole('button',{name:'Complete #agentx-complete',exact:true})).toBeVisible({timeout:8000});
    await editor.press('Escape');
    await expect(menu).toBeHidden();
    await expect.poll(async () => (await context()).native.state.tasks.find(task=>task.id===taskId)?.status,{timeout:15000}).toBe('completed');
    const transcript = focused.getByRole('region',{name:'Agent transcript',exact:true});
    const jump = focused.getByRole('button',{name:'Jump to latest Agent message',exact:true});
    if (await jump.isVisible()) await jump.click({timeout:5000});
    const extent = () => transcript.evaluate(element=>({top:element.scrollTop,max:element.scrollHeight-element.clientHeight,height:element.clientHeight}));
    await expect.poll(async () => {const value=await extent();return value.max>40&&value.max-value.top<=1;}).toBe(true);
    const initial = await extent();
    await transcript.hover({timeout:5000});
    await page.mouse.wheel(0,-64);
    await expect.poll(async () => (await extent()).top).toBeLessThan(initial.top);
    await expect(jump).toBeVisible();
    const read = await extent();
    await jump.click({timeout:5000});
    await expect.poll(async () => {const value=await extent();return value.max-value.top<=1;}).toBe(true);
    const returned = await extent();
    await expect(editor).toHaveText('Review #agentx-complete');
    result.compactReading = {initial,read,returned};
    await save();
  }
  await focused.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await expect(focused).toBeHidden();
  await expect(composer).toBeVisible();
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(() => processStart(proof.pid),{timeout:15000}).not.toBe(proof.processStart);
  proof.nativeWriterRetired = true;
  proof.final = await context();
  assert.equal(proof.final.claude.sessionId,proof.parentSessionId);
  assert.equal(proof.final.threadId,result.threadId);
  proof.status='complete';
  phase(verifyCompletionWindowFocus?'completion-window-focus-verified':'completion-layout-verified');
  await save();
}
