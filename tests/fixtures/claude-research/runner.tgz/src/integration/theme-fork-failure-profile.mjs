import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir,readFile,writeFile,lstat,readdir,rename,cp,chmod} from 'node:fs/promises';
import {join,basename,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {record} from '../protocol/record.mjs';
import {MANAGED_SECURITY_KEY} from '../protocol/native-managed-security-fixture.mjs';
import {prepareThemeSaveFailureProfile} from './theme-save-failure-profile.mjs';
import {recoverThemeSaveProfile} from './recover-theme-save-profile.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const config='/work/.claude-research/profile-setup-app10/app-data/claude-code-profile/config';
function boundary(workspace){assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));assert.match(workspace,/^\/work\/\.claude-research\/theme-save-failure-app[0-9]+$/);}
async function tree(path){
 if(!existsSync(path))return null;
 const rows={};let bytes=0;
 async function visit(relative){const p=relative?join(path,relative):path,s=await lstat(p);assert.equal(s.uid,1000);assert.ok(!s.isSymbolicLink());assert.ok(Object.keys(rows).length<1024);
  if(s.isDirectory()){rows[relative]={kind:'directory',mode:s.mode&0o7777};for(const name of(await readdir(p)).sort())await visit(relative?join(relative,name):name);}
  else{assert.ok(s.isFile()&&s.size<=16*1048576);bytes+=s.size;assert.ok(bytes<=64*1048576);rows[relative]={kind:'file',mode:s.mode&0o7777,sha256:sha(await readFile(p))};}
 }
 await visit('');return rows;
}
async function copyTree(source,destination,expected){await cp(source,destination,{recursive:true,errorOnExist:true,force:false,preserveTimestamps:true});for(const[path,entry]of Object.entries(expected).sort(([a],[b])=>b.length-a.length))await chmod(path?join(destination,path):destination,entry.mode);assert.deepEqual(await tree(destination),expected);}
/** Restore this fixture's native registry layer before the ordinary theme/settings layer. */
export async function restoreThemeForkPluginProfile(workspace){
 boundary(workspace);const root=join(config,'plugins'),ledger=JSON.parse(await readFile(join(workspace,'theme-fork-plugin-profile.json'),'utf8'));
 assert.equal(ledger.pluginsPath,root);assert.equal(ledger.settingsPath,join(config,'settings.json'));assert.ok(Number.isInteger(ledger.settingsMode)&&ledger.settingsMode>=0&&ledger.settingsMode<=0o7777);
 const original=await readFile(join(workspace,'fork-plugin-preimages/settings.json'));assert.equal(sha(original),ledger.settingsSha256);
 const marker=join(workspace,'theme-fork-plugin-restoration.json');
 if(existsSync(marker)){assert.deepEqual(await tree(root),ledger.pluginsBefore);return JSON.parse(await readFile(marker,'utf8'));}
 if(existsSync(root)){assert.ok(!existsSync(join(workspace,'preserved-fork-plugins')));await rename(root,join(workspace,'preserved-fork-plugins'));}
 if(ledger.pluginsBefore!==null){const saved=join(workspace,'fork-plugin-preimages/plugins');assert.deepEqual(await tree(saved),ledger.pluginsBefore);await copyTree(saved,root,ledger.pluginsBefore);}
 assert.deepEqual(await tree(root),ledger.pluginsBefore);
 const settings=join(config,'settings.json');if(existsSync(settings))await rename(settings,join(workspace,'preserved-fork-settings.json'));
 await writeFile(settings,original,{mode:ledger.settingsMode,flag:'wx'});assert.equal(sha(await readFile(settings)),ledger.settingsSha256);
 const result={restored:true,pluginsRestoredExactly:true,pluginsBeforeSha256:sha(JSON.stringify(ledger.pluginsBefore)),settingsSha256:ledger.settingsSha256};await writeFile(marker,JSON.stringify(result),{mode:0o600,flag:'wx'});return result;
}
/** One real local theme-only plugin; original CLI commands own installation and discovery. */
export async function prepareThemeForkFailureProfile(options){
 boundary(options.workspace);const {workspace,setupWorkspace,env}=options;assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');
 const base=await prepareThemeSaveFailureProfile(options);let pluginLedger=false;
 try{
  const settings=join(config,'settings.json'),original=await readFile(settings),info=await lstat(settings);assert.ok(info.isFile()&&!info.isSymbolicLink()&&info.uid===1000);
  const pluginsPath=join(config,'plugins'),pluginsBefore=await tree(pluginsPath),preimages=join(workspace,'fork-plugin-preimages');await mkdir(preimages,{mode:0o700});await writeFile(join(preimages,'settings.json'),original,{mode:0o600,flag:'wx'});
  if(pluginsBefore!==null){await copyTree(pluginsPath,join(preimages,'plugins'),pluginsBefore);}
  const market=basename(workspace)+'-fork',marketplace=join(workspace,'theme-marketplace'),plugin=join(marketplace,'plugins/release-theme-fork');
  const fixtureFiles=[join(marketplace,'.claude-plugin/marketplace.json'),join(plugin,'.claude-plugin/plugin.json'),join(plugin,'theme-packs/team.json')];for(const path of fixtureFiles)assert.ok(!existsSync(path));
  const ledger={settingsPath:settings,settingsMode:info.mode&0o7777,settingsSha256:sha(original),pluginsPath,pluginsBefore,fixtureFiles};await writeFile(join(workspace,'theme-fork-plugin-profile.json'),JSON.stringify(ledger),{mode:0o600,flag:'wx'});pluginLedger=true;
  await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'theme-packs'));
  const definition={name:'Team Review',base:'dark',overrides:{success:'#55aa66',warning:'#cc9944'}},themeBytes=Buffer.from(JSON.stringify(definition,null,2)+'\n');
  await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:market,owner:{name:'Local release review'},plugins:[{name:'release-theme-fork',source:'./plugins/release-theme-fork'}]}));
  await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'release-theme-fork',version:'0.0.1',themes:'./theme-packs'}));await writeFile(join(plugin,'theme-packs/team.json'),themeBytes);
  const executable='/frozen-claude/claude';assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
  const environment={...env,HOME:join(setupWorkspace,'home'),CLAUDE_CONFIG_DIR:config,ANTHROPIC_API_KEY:MANAGED_SECURITY_KEY,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},runs=[];
  for(const args of [['--setting-sources','','plugin','marketplace','add',marketplace],['--setting-sources','','plugin','install','release-theme-fork@'+market]]){const run=await record({executable,args,cwd:join(setupWorkspace,'project'),env:environment,output:join(workspace,'theme-plugin-installation'),timeoutMs:20000,maxBytes:1048576});runs.push(run);assert.equal(run.code,0,'Original local theme plugin installation refused');assert.equal(run.status,'complete');}
  const registry=JSON.parse(await readFile(join(pluginsPath,'installed_plugins.json'),'utf8')),entries=registry.plugins?.['release-theme-fork@'+market];assert.ok(Array.isArray(entries)&&entries.length===1);assert.equal(entries[0].scope,'user');assert.ok(entries[0].installPath.startsWith(join(pluginsPath,'cache',market)+'/'));
  const installedThemePath=join(entries[0].installPath,'theme-packs/team.json');assert.equal(sha(await readFile(installedThemePath)),sha(themeBytes));assert.equal(JSON.parse(await readFile(settings,'utf8')).theme,base.value);
  const installed={...entries[0],market,pluginId:'release-theme-fork@'+market,sourceThemePath:join(plugin,'theme-packs/team.json'),installedThemePath,themeSha256:sha(themeBytes),definition,runs};await writeFile(join(workspace,'theme-fork-installation.json'),JSON.stringify(installed),{mode:0o600,flag:'wx'});
  return{...base,installed,readInstalledTheme:()=>readFile(installedThemePath),readSourceTheme:()=>readFile(installed.sourceThemePath),async restore(){try{await restoreThemeForkPluginProfile(workspace)}finally{await base.restore()}}};
 }catch(error){const failures=[error];try{if(pluginLedger)await restoreThemeForkPluginProfile(workspace)}catch(e){failures.push(e)}try{await base.restore()}catch(e){failures.push(e)}if(failures.length>1)throw new AggregateError(failures,'Theme fork preparation/restoration failed');throw error;}
}
export async function recoverThemeForkFailureProfile(workspace){boundary(workspace);const plugins=existsSync(join(workspace,'theme-fork-plugin-profile.json'))?await restoreThemeForkPluginProfile(workspace):{notStarted:true},themes=await recoverThemeSaveProfile(workspace);const result={restored:true,plugins,themes};await writeFile(join(workspace,'theme-fork-profile-recovery.json'),JSON.stringify(result));return result;}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){assert.equal(process.argv.length,3);console.log(JSON.stringify(await recoverThemeForkFailureProfile(process.argv[2])));}
