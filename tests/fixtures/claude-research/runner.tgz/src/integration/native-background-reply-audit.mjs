import {join} from 'node:path';

/** Invoke the original reply function in the owned parent; never implement daemon authentication. */
export function nativeBackgroundReplyAudit(workspace,project,replyRuntime) {
 const requestPath=join(workspace,'owned-background-reply-request.json'),resultPath=join(workspace,'owned-background-reply-result.json');
 if(typeof replyRuntime!=='string'||!replyRuntime.includes('async function replyNativeBackground('))throw Error('Expected authored background reply runtime');
 const source=String.raw`{
 const config={sessionId:''};
 ${replyRuntime}
 const {readFileSync,writeFileSync,renameSync}=await import('node:fs');let used=false;
 const timer=setInterval(async()=>{if(used)return;let request;try{request=JSON.parse(readFileSync(REQUEST,'utf8'));}catch{return;}
 if(request.parentPid!==process.pid)return;used=true;clearInterval(timer);
 try{
  if(request.cwd!==PROJECT||!/^[a-f0-9]{8}$/.test(request.jobId)||!/^[a-f0-9-]{36}$/.test(request.sessionId)||!Number.isSafeInteger(request.pid)||request.pid<=1||request.text!=='NativeOriginalChildReplyDiagnostic')throw Error('Invalid owned child reply diagnostic');
  const fields=readFileSync('/proc/'+request.pid+'/stat','utf8');const stateFields=fields.slice(fields.lastIndexOf(')')+2).split(' ');if(stateFields[0]==='Z'||stateFields[19]!==request.processStart)throw Error('Original child process changed');
  const state=JSON.parse(readFileSync(PROFILE+'/jobs/'+request.jobId+'/state.json','utf8'));
  if(state.sessionId!==request.sessionId||state.cwd!==request.cwd||state.daemonShort!==request.jobId||!['working','blocked'].includes(state.state))throw Error('Original child job identity changed');
  const {Ptt}=await import('/$bunfs/root/chunk-mnx9wh8s.js');
  const hash=(await import('node:crypto')).createHash('sha256').update(Function.prototype.toString.call(Ptt)).digest('hex');
  if(hash!=='c3b67e62aaed8df6ac6850195265ab5bcc7c66780b78befd952b0033174efb5c')throw Error('Original reply export changed');
  config.sessionId=request.parentSessionId;
  const acknowledged=await replyNativeBackground({parent_session_id:request.parentSessionId,child_session_id:request.sessionId,job_id:request.jobId,pid:request.pid,cwd:request.cwd,text:request.text});
  const result=acknowledged.queued===true?null:acknowledged;
  writeFileSync(RESULT+'.tmp',JSON.stringify({parentPid:process.pid,jobId:request.jobId,sessionId:request.sessionId,workerPid:request.pid,processStart:request.processStart,originalFunctionSha256:hash,result,scope:'Original authenticated reply with known state; no copied authentication, parent retargeting, forced admission or extra conversation writer.'}));renameSync(RESULT+'.tmp',RESULT);
 }catch(error){writeFileSync(RESULT+'.tmp',JSON.stringify({error:String(error),parentPid:process.pid}));renameSync(RESULT+'.tmp',RESULT);}
 },100);timer.unref();
}`.replaceAll('REQUEST',JSON.stringify(requestPath)).replaceAll('RESULT',JSON.stringify(resultPath)).replaceAll('PROJECT',JSON.stringify(project)).replaceAll('PROFILE',JSON.stringify(join(workspace,'.claude')));
 return {source,requestPath,resultPath};
}
