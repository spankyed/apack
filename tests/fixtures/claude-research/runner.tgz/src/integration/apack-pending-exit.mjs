import assert from 'node:assert/strict';
import {readFile,realpath} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkoutArg,executableArg,workspaceArg,kind='pending-exit']=process.argv.slice(2);
const question=kind==='question-exit';
const checkout=await realpath(checkoutArg),executable=resolve(executableArg),workspace=resolve(workspaceArg);
assert.notEqual(checkout,await realpath('/Users/spankyed/Develop/Projects/AgentBuddy'));
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const {query}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')));
const model=await startSyntheticModel(workspace,question?'AskUserQuestion':'Bash');
let handle,release;
const permission=Promise.withResolvers();
const decision=new Promise(resolve=>{release=resolve});
try {
 handle=await query({cliPath:executable,cwd:workspace,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:question?undefined:'1',ANTHROPIC_BASE_URL:model.url},
  tools:question?['AskUserQuestion']:['Bash'],strictMcpConfig:true,settingSources:[],noSessionPersistence:true,permissionMode:'default',model:'default',maxTurns:3,
  settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),signal:AbortSignal.timeout(20000),
  onPermissionRequest:async request=>{assert.equal(request.tool_name,question?'AskUserQuestion':'Bash');permission.resolve(request);return decision}});
 await handle.initialized;
 const resultRejected=handle.result.then(()=>false,()=>true);
 let eventCount=0;
 const drained=(async()=>{for await(const event of handle.events){eventCount++;assert.notEqual(event.type,'__parse_error')}return true})();
 handle.send('Create the disposable fixture file only after permission approval.');
 const request=await permission.promise;
 await handle.getContextUsage();
 handle.kill();
 await handle.close();
 assert.equal(await drained,true);
 assert.equal(await resultRejected,true);
 await assert.rejects(()=>handle.getContextUsage());
 const callsBeforeLate=model.calls.length;
 if(question)assert.throws(()=>handle.respond('closed-question',{behavior:'allow',updatedInput:{...request.input,answers:{[request.input.questions[0].question]:'Alpha'}}}),/stdin is closed/);
 release({behavior:'allow',updatedInput:question?{...request.input,answers:{[request.input.questions[0].question]:'Alpha'}}:request.input});
 await Promise.resolve();await Promise.resolve();
 await assert.rejects(readFile(join(workspace,'fixture.txt')),{code:'ENOENT'});
 assert.equal(model.calls.length,1);
 console.log(JSON.stringify({evidence:question?'apack-native-question-exit':'apack-native-pending-exit',targetSha256:hash(await readFile(executable)),
  questionTool:question,responseRejectedAfterExit:question,apiRequestsAfterLateDecision:model.calls.length-callsBeforeLate,permissionPendingAtKill:true,contextDuringPermission:true,streamDrained:true,closeSettled:true,resultRejected:true,
  controlsRejectedAfterExit:true,lateDecisionReleased:true,fileCreated:false,eventCount,syntheticApiRequests:1,realModelRequests:0}));
}finally{
 release?.({behavior:'deny',message:'Fixture cleanup'});
 if(handle){handle.kill();await handle.close().catch(()=>{})}
 await model.close();
}
