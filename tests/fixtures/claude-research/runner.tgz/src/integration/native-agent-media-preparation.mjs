import assert from 'node:assert/strict';
import {access,mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {nativeAgentMediaPreparationObserver,verifyNativeAgentMediaPreparation} from '../protocol/native-agent-media-preparation.mjs';
const [executable,root,hashFile]=process.argv.slice(2);
assert.equal(process.platform,'linux');await access('/.dockerenv');assert.equal(process.getuid(),1000);assert.ok(isAbsolute(root));
assert.equal(createHash('sha256').update(await readFile(executable)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'native-agent-media-preparation-'));await mkdir(join(workspace,'.claude'));
const output=join(workspace,'preparation.json'),preload=join(workspace,'observe.mjs'),hashes=JSON.parse(await readFile(hashFile,'utf8'));
await writeFile(preload,nativeAgentMediaPreparationObserver(output,hashes));
const env={...process.env};for(const name of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN','CLAUDE_CODE_SUBSCRIPTION_TYPE','CLAUDE_CODE_OAUTH_SCOPES','CLAUDE_INTERNAL_FC_OVERRIDES','CLAUDE_CODE_CUSTOM_OAUTH_URL','BUN_OPTIONS','NODE_OPTIONS'])delete env[name];
Object.assign(env,{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),BUN_OPTIONS:'--preload='+preload,ANTHROPIC_BASE_URL:'http://127.0.0.1:9',TERM:'xterm-256color'});
const pty=createRequire('/work/package.json')('node-pty'),child=pty.spawn(executable,[],{cwd:workspace,env,name:'xterm-256color',cols:100,rows:28});let terminal='',exit;
child.onData(value=>{terminal=(terminal+value).slice(-65536)});const stopped=new Promise(resolve=>child.onExit(event=>{exit=event;resolve(event)}));
try{
 const deadline=Date.now()+11000;let receipt;
 while(!exit&&Date.now()<deadline){try{receipt=JSON.parse(await readFile(output,'utf8'));break}catch(error){if(error.code!=='ENOENT')throw error;}await new Promise(resolve=>setTimeout(resolve,50));}
 if(!receipt){let detail;try{detail=await readFile(output+'.error','utf8')}catch{}throw Error('Original preparation was not observed: '+(detail??terminal.slice(-1000)));}
 assert.equal(receipt.pid,child.pid);const verified=verifyNativeAgentMediaPreparation(receipt,hashes);await writeFile(join(workspace,'verification.json'),JSON.stringify(verified,null,2)+'\n');console.log(JSON.stringify({workspace,pid:child.pid,...verified}));
}finally{
 if(!exit)child.kill('SIGTERM');await Promise.race([stopped,new Promise(resolve=>setTimeout(resolve,2000))]);if(!exit){child.kill('SIGKILL');await stopped;}
 await writeFile(join(workspace,'terminal.txt'),terminal);await writeFile(join(workspace,'exit.json'),JSON.stringify({pid:child.pid,...exit})+'\n');
}
