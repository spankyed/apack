import {constants} from 'node:fs';
import {lstat,open,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';

/** Preserve bounded original logs from an owned fixture profile; never rewrite the app's files. */
export async function preserveOwnedAppLogs(directory,output) {
 const maxBytes=4*1024**2,manifest={maxBytesPerFile:maxBytes,files:[]};
 const folder=await lstat(directory).catch(error=>{if(error.code==='ENOENT')return null;throw error;});
 if(folder){
  if(!folder.isDirectory()||folder.isSymbolicLink())throw Error('Owned log directory is not an ordinary directory');
  for(const name of ['main.jsonl','main.log']){
   let handle;
   try{
    handle=await open(join(directory,name),constants.O_RDONLY|constants.O_NOFOLLOW|constants.O_NONBLOCK);
    const stat=await handle.stat();if(!stat.isFile())throw Error('Owned log is not an ordinary file');
    const offset=Math.max(0,stat.size-maxBytes),bytes=Buffer.alloc(Math.min(stat.size,maxBytes));let used=0;
    while(used<bytes.length){const read=await handle.read(bytes,used,bytes.length-used,offset+used);if(!read.bytesRead)break;used+=read.bytesRead;}
    const tail=bytes.subarray(0,used),file='owned-'+name+'.tail';await writeFile(join(output,file),tail,{flag:'wx',mode:0o600});
    manifest.files.push({sourceName:name,file,originalBytes:stat.size,offset,copiedBytes:used,sha256:createHash('sha256').update(tail).digest('hex')});
   }catch(error){if(error.code==='ENOENT')manifest.files.push({sourceName:name,missing:true});else throw error;}
   finally{await handle?.close();}
  }
 }else manifest.directoryAbsent=true;
 await writeFile(join(output,'owned-app-logs.json'),JSON.stringify(manifest,null,2),{flag:'wx',mode:0o600});return manifest;
}
