"""Verify native child subagent formatter eligibility and the shell-prefix boundary; no app claim."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence',type=Path)
parser.add_argument('product',type=Path)
parser.add_argument('--research-commit',required=True)
parser.add_argument('--product-commit',required=True)
a=parser.parse_args();research=Path(__file__).resolve().parents[2];records=a.evidence/'export/records';workspace=a.evidence/'export/apack-terminal-owner-app-background'
load=lambda p:json.loads(p.read_text())
inputs=load(records/'source-inputs.json')
assert inputs
for name,digest in inputs.items():
    if name.startswith('/research/'):
        root,commit,relative=research,a.research_commit,name[len('/research/'):]
    else:
        assert name.startswith('/product/')
        root,commit,relative=a.product,a.product_commit,name[len('/product/'):]
    blob=subprocess.check_output(['git','show',commit+':'+relative],cwd=root)
    assert hashlib.sha256(blob).hexdigest()==digest,name
boundary=load(a.evidence/'offline-boundary.json')
assert boundary['networkDisabled'] and set(boundary['networks'])=={'none'} and boundary['pinnedExecutableReadOnly']
assert boundary['memory']==boundary['memorySwap']==6*1024**3 and boundary['nanoCpus']==2*10**9
native=load(records/'leftarrow-evidence.json');job=native['forkJob'];child=job['sessionId']
assert native['verifyFork'] and native['verifyAttach'] and native['stopped'] and native['realModelRequests']==0
assert native['run']['code']==143 and native['run']['reason']=='owned-leftarrow-observation-complete'
attachment=load(records/'original-child-attach-observation.json')
assert attachment['frameSeen'] and attachment['jobAfter']['sessionId']==child
assert attachment['jobAfter']['pid']==job['pid'] and attachment['processBefore']['startTime']==attachment['processAfter']['startTime']
assert attachment['processAfter']['state']!='Z'
formatter=load(records/'child-formatter-audit.json');before,after=formatter['snapshots']
assert before['stage']=='before-attach' and after['stage']=='after-attach' and after['at']>before['at']
sub=[row for row in after['invocations'] if row['sessionId']==child and row.get('kind')=='subagent']
assert len(sub)>=2,'Require two genuinely scheduled eligible child helper invocations'
assert hashlib.sha256((workspace/'subagent-formatter-helper.mjs').read_bytes()).hexdigest()==formatter['subagentHelperSha256']
public=[]
for p in (workspace/'project').glob('native-child-agent-list-'+child+'-*.json'):
    v=load(p);assert v['sessionId']==child;public+=v['agents']
assert public
prefix=load(workspace/'project'/('native-formatter-prefix-'+child+'.json'))
assert prefix['readback'] and prefix['originalPrefix'] is None and not prefix['setResult'].get('deny')
matched=set()
for row in sub:
    assert row['at']>before['at'] and row['observedPrefix']==prefix['readback']
    assert row['input']['session_id']==child and isinstance(row['input']['columns'],int) and row['input']['columns']>0
    tasks=row['input']['tasks'];assert tasks
    output=[json.loads(line) for line in row['stdout'].splitlines() if line.strip()]
    assert {line['id']for line in output}=={task['id']for task in tasks}
    for task in tasks:
        assert task['type']=='local_agent' and task['status']=='running' and task['agentType']=='status-fixture'
        assert any(agent['id']==task['id'] and agent['status']==task['status'] and agent['type']==task['agentType'] for agent in public)
        assert any(line['id']==task['id'] and line['content']=='NativeConfiguredAgent '+task['id']+' '+task['status'] for line in output)
        matched.add(task['id'])
exports=[row for row in formatter['exports'] if row['sessionId']==child]
assert exports and all(row['kind']=='main' for row in exports),'Native subagent runner must not be misreported as a prefix export'
frames=list((records/'original-child-attach').glob('runs/*/stdout.bin'));assert len(frames)==1
assert b'NativeConfiguredAgent' in frames[0].read_bytes()
events=list((records/'original-child-attach').glob('runs/*/events.jsonl'));assert len(events)==1
keys=[base64.b64decode(row['base64'])for row in map(json.loads,events[0].read_text().splitlines())if row['kind']=='stdin']
assert b'NativeChildAgentFormatterDiagnostic\r' in keys
proof={'status':'passed-native-only','researchCommit':a.research_commit,'productCommit':a.product_commit,'sourceInputsVerified':len(inputs),'childSessionId':child,'workerPid':job['pid'],'nativeSubagentFormatterInvocations':len(sub),'originalTaskIds':sorted(matched),'publicAgentIdentityMatches':True,'prefixAdmittedAndPresentInHelperEnvironment':True,'nativeSubagentPrefixExports':0,'nativeRootPrefixExports':len(exports),'originalTerminalShowsCaption':True,'sameWorkerAfterAttach':True,'originalStop':True,'syntheticRequests':native['syntheticRequests'],'realModelRequests':0,'scope':'Original eligible child subagent formatter and terminal caption only. The installed root shell prefix does not observe its separate runner. No desktop caption delivery, structured child UI/action transport or F1–F5 acceptance.'}
(a.evidence/'saved-record-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
