import {CHILD_REVIEW_PLAN} from '../protocol/native-child-control-scenario.mjs';
import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';

export function driveChildPlanClear(options) {
 return driveChildComposer({...options,env:{...options.env,DEBUG:'1',CLAUDE_CODE_DEBUG_LOGS_DIR:join(options.workspace,'electron-results/native-reset-debug.log')},modelTool:'TextOnly',modelOptions:{childPlanDirectory:join(options.setupWorkspace,'app-data/claude-code-profile/config/plans')},modelRequestLimit:24,journey:planClearJourney,showClearContextOnPlanAccept:true,journeyName:'plan-clear'});
}
async function planClearJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const proof={status:'running',parentSessionId,scope:'Original child populated plan keep-planning and edited clear-context approval; no unrelated standing/mode variants or full parity claim.',captures:[],sizes:[]};
 const save=()=>writeFile(join(output,'child-plan-clear.json'),JSON.stringify(proof,null,2));
 const hasResult=stage=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_child_plan_'+stage);
 const result=async(stage,error)=>{
  const read=async()=>{
   const cached=hasResult(stage);if(cached)return cached;
   if(!proof.target)return;
   const root=join(userDataDir,'claude-code-profile/config/projects');
   for(const d of(await readdir(root,{withFileTypes:true})).slice(0,64)){
    if(!d.isDirectory())continue;const path=join(root,d.name,proof.target.sessionId+'.jsonl');let info;
    try{info=await lstat(path)}catch(e){if(e.code==='ENOENT')continue;throw e}
    assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);
    const rows=(await readFile(path,'utf8')).split('\n').filter(Boolean).map(line=>JSON.parse(line));
    const value=rows.flatMap(row=>Array.isArray(row.message?.content)?row.message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_child_plan_'+stage);if(value)return value;
   }
  };
  await expect.poll(read,{timeout:15000}).toBeTruthy();const value=await read();assert.equal(value.is_error===true,error);proof['result'+stage]=value;await save();
 };
 const capture=async(name)=>{await page.screenshot({path:join(output,name+'.png')});proof.captures.push(name+'.png');await save();};
 const sizes=[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]];
 try {
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill('/background ResearchChildPlan1 Enter planning for the release review.');await card.getByRole('button',{name:'Send',exact:true}).click();
  const widget=page.getByRole('region',{name:'Background Claude session',exact:true});
  await expect.poll(async()=>(await context()).native?.background?.desktop,{timeout:25000}).toBeTruthy();
  proof.running=await context();proof.target=proof.running.native.background.desktop;assert.notEqual(proof.target.sessionId,parentSessionId);await result(1,false);
  await composer.fill('Keep the parent release planning notes here.');const parentDraft=await composer.textContent();
  await widget.getByRole('button',{name:'Reply',exact:true}).click();
  const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');await expect(editor).toBeEditable();
  await editor.fill('ResearchChildPlan2 Write the release review plan and request approval.');await form.getByRole('button',{name:'Send message',exact:true}).click();
  const panel=widget.getByRole('region',{name:'Claude Code plan review',exact:true});await expect(panel).toBeVisible({timeout:20000});
  const currentPlan=async()=>{const c=await context(),pair=Object.entries(c.ui).find(([,value])=>value.state?.approval?.control?.kind==='plan');assert.ok(pair);return{mountId:pair[0],frame:pair[1].state.approval};};
  proof.firstPlan=await currentPlan();assert.equal(proof.firstPlan.frame.control.dialog.presentation.plan,CHILD_REVIEW_PLAN);proof.planPath=proof.firstPlan.frame.control.dialog.presentation.planFilePath;assert.ok(proof.planPath.startsWith(join(userDataDir,'claude-code-profile/config/plans')+'/'));assert.equal(await readFile(proof.planPath,'utf8'),CHILD_REVIEW_PLAN);
  for(const[name,size]of sizes){await page.setViewportSize(size);await expect(panel.getByRole('button',{name:'Keep planning',exact:true})).toBeInViewport({ratio:1});await expect(panel.locator('[data-testid="native-plan-preview"]')).toBeVisible();await capture('child-plan-clear-'+name);}
  const feedback=panel.getByRole('textbox',{name:'Plan feedback',exact:true});await panel.locator('.body').hover();await page.mouse.wheel(0,600);await feedback.fill('Add an explicit summary before implementation.');
  await panel.getByRole('button',{name:'Keep planning',exact:true}).click();await expect(panel).toHaveCount(0);await result(2,true);assert.ok(proof.result2.content.includes('Add an explicit summary before implementation.'));proof.keepPlanningFeedbackObserved=true;
  await expect(editor).toBeEditable();await editor.fill('ResearchChildPlan3 Present the current plan for review again.');await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(panel).toBeVisible({timeout:15000});proof.secondPlan=await currentPlan();assert.notEqual(proof.firstPlan.frame.id,proof.secondPlan.frame.id);
  await panel.getByRole('button',{name:'Edit plan',exact:true}).click();const planEditor=panel.getByRole('textbox',{name:'Edit proposed plan',exact:true});
  proof.editedPlan=CHILD_REVIEW_PLAN+'\n4. Summarize the review before implementation.\n';await planEditor.fill(proof.editedPlan);
  await panel.getByRole('button',{name:'Back to parent notes',exact:true}).click();await expect(composer).toBeFocused();await expect(composer).toHaveText(parentDraft);
  await widget.getByRole('button',{name:'Review request',exact:true}).click();await expect(planEditor).toHaveValue(proof.editedPlan);proof.editedDraftRetained=true;
  await panel.getByRole('button',{name:'Preview',exact:true}).click();await panel.getByRole('radio',{name:'Clear context and use auto mode',exact:true}).check();
  for(const[name,size]of sizes){await page.setViewportSize(size);await expect(panel.getByRole('button',{name:'Approve plan',exact:true})).toBeInViewport({ratio:1});await panel.locator('.body').hover();await page.mouse.wheel(0,-800);await expect(panel.locator('[data-testid="native-plan-preview"]')).toContainText('Summarize the review before implementation.');await panel.locator('.body').hover();await page.mouse.wheel(0,120);await expect(panel.locator('[data-testid="native-plan-preview"] li').last()).toBeInViewport({ratio:1});await expect(panel.getByRole('button',{name:'Approve plan',exact:true})).toBeInViewport({ratio:1});await capture('child-plan-edited-'+name);}
  await panel.getByRole('button',{name:'Approve plan',exact:true}).click();await expect(panel).toHaveCount(0);const resetCall=()=>model.calls.find(call=>call.toolNames?.includes('Write')&&call.messages?.some(message=>message.role==='user'&&JSON.stringify(message.content).includes('Implement the following plan:')&&JSON.stringify(message.content).includes('Summarize the review before implementation.'))&&!JSON.stringify(call.messages).includes('ResearchChildPlan'));
  await expect.poll(resetCall,{timeout:20000}).toBeTruthy();proof.resetModelRequest=resetCall();assert.ok(!JSON.stringify(proof.resetModelRequest.messages).includes('Review the release notes and outline the next steps.'));
  proof.originalResetContinuationObserved=true;proof.afterClear=await context();proof.jobAfterClear=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));await save();
  await expect.poll(async()=>{const job=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));return job.resumeSessionId!==proof.target.sessionId?job.resumeSessionId:undefined;},{timeout:15000}).toBeTruthy();
  proof.jobAfterClear=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(proof.jobAfterClear.sessionId,proof.target.jobSessionId);assert.ok(proof.jobAfterClear.respawnFlags.includes('auto'));
  await expect.poll(async()=>(await context()).native?.background?.desktop?.sessionId,{timeout:20000}).toBe(proof.jobAfterClear.resumeSessionId);
  proof.afterClearTarget=(await context()).native.background.desktop;assert.equal(proof.afterClearTarget.jobSessionId,proof.target.jobSessionId);assert.equal(proof.afterClearTarget.jobId,proof.target.jobId);assert.equal(proof.afterClearTarget.pid,proof.target.pid);assert.equal(proof.afterClearTarget.processStart,proof.target.processStart);assert.notEqual(proof.afterClearTarget.ownerId,proof.target.ownerId);
  const activeMount=async()=>Object.entries((await context()).ui).find(([,value])=>value.mountRequest?.backgroundView?.ownerId===proof.afterClearTarget.ownerId);await expect.poll(activeMount,{timeout:15000}).toBeTruthy();const freshMount=await activeMount();assert.ok(freshMount);
  await page.evaluate(({threadId,mountId,frameId})=>window.applicationState.system.get('default-setup/threads').send({type:'CLAUDE_UI_APPROVAL_ANSWER',threadId,mountId,frameId,answer:{approved:false}}),{threadId:proof.running.threadId,mountId:freshMount[0],frameId:proof.secondPlan.frame.id});proof.oldApprovalReplayedAtFreshMount=true;


  await expect.poll(async()=>(await context()).native?.background?.session?.status,{timeout:15000}).not.toBe('waiting');await expect(widget.getByText('input needed',{exact:true})).toHaveCount(0);proof.settled=await context();
  await expect(editor).toBeEditable();await editor.fill('Summarize the approved release check.');for(const[name,size]of sizes){await page.setViewportSize(size);await expect(editor).toBeInViewport({ratio:1});await expect(form.getByRole('button',{name:'Send message',exact:true})).toBeInViewport({ratio:1});await capture('child-plan-clear-composer-'+name);}
  await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(editor).toHaveText('',{timeout:20000});await expect.poll(()=>model.calls.some(call=>call.messages?.some(message=>message.role==='user'&&message.content==='Summarize the approved release check.')),{timeout:15000}).toBe(true);proof.finalReplyObserved=true;
  const projects=join(userDataDir,'claude-code-profile/config/projects');proof.transcripts={};
  for(const kind of ['parent','child','active']){const sid=kind==='parent'?parentSessionId:kind==='active'?proof.afterClearTarget.sessionId:proof.target.sessionId;for(const directory of(await readdir(projects,{withFileTypes:true})).slice(0,64)){if(!directory.isDirectory())continue;const path=join(projects,directory.name,sid+'.jsonl');let info;try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);await writeFile(join(output,'native-'+kind+'-transcript.jsonl'),raw);proof.transcripts[kind]={sessionId:sid,path,sha256:createHash('sha256').update(raw).digest('hex')};break;}assert.ok(proof.transcripts[kind]);}
  await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});
  const stopped=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(stopped.sessionId,proof.target.sessionId);assert.equal(stopped.state,'stopped');proof.nativeStopped={jobId:proof.target.jobId,sessionId:stopped.sessionId,state:stopped.state};proof.final=await context();proof.status='complete';await save();phase('original-child-plan-clear-complete');
 } catch(error) {
  proof.status='failed';proof.error=String(error.message).slice(0,4096);proof.failureContext=await context().catch(()=>null);
  // Capture only this disposable profile's bounded identity/debug files before owned cleanup.
  proof.nativeResetDiagnostics={};
  for(const relative of ['daemon/roster.json',...new Set([proof.target?.sessionId,proof.jobAfterClear?.resumeSessionId].filter(Boolean).map(sid=>'debug/'+sid+'.txt'))]){
   const path=join(userDataDir,'claude-code-profile/config',relative);
   try{const info=await lstat(path);assert.ok(info.isFile()&&!info.isSymbolicLink()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);const name='reset-diagnostic-'+relative.replaceAll('/','-');await writeFile(join(output,name),raw);proof.nativeResetDiagnostics[relative]={name,sha256:createHash('sha256').update(raw).digest('hex')};}catch(diagnosticError){proof.nativeResetDiagnostics[relative]={unavailable:String(diagnosticError.message).slice(0,256)};}
  }

  const flags=proof.jobAfterClear?.respawnFlags??[],plugin=flags[flags.indexOf('--plugin-dir')+1];
  if(typeof plugin==='string'&&/^\/tmp\/cc-child-[A-Za-z0-9]+\/plugin$/.test(plugin)&&Number.isSafeInteger(proof.target?.pid)){
   const directory=plugin.slice(0,-'/plugin'.length),markerPath=join(directory,'worker-'+proof.target.pid+'.json');
   try{const info=await lstat(markerPath);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=65536);const marker=JSON.parse(await readFile(markerPath,'utf8'));proof.nativeResetDiagnostics.workerMarker=marker;
    const prefix=join(directory,'workers','w-'+proof.target.pid+'-');assert.ok(typeof marker.configPath==='string'&&marker.configPath.startsWith(prefix)&&/^w-[0-9]+-[A-Za-z0-9]+$/.test(marker.configPath.split('/').at(-2))&&marker.configPath.endsWith('/observer.json'));
    const configInfo=await lstat(marker.configPath);assert.ok(configInfo.isFile()&&configInfo.uid===process.getuid()&&configInfo.size<=65536);const config=JSON.parse(await readFile(marker.configPath,'utf8'));proof.nativeResetDiagnostics.workerConfig={sessionId:config.sessionId,jobSessionId:config.jobSessionId,uiSocketPath:config.uiSocketPath,hasValidToken:typeof config.token==='string'&&/^[a-f0-9]{64}$/.test(config.token)};
   }catch(diagnosticError){proof.nativeResetDiagnostics.workerFilesUnavailable=String(diagnosticError.message).slice(0,512);}
  }
  await page.screenshot({path:join(output,'child-workflow-failure-before-cleanup.png')}).catch(()=>{});
  await save();throw error;
 } finally {
  const state=await context().catch(()=>null),sessionId=proof.target?.sessionId??state?.claude?.nativeContinuation?.continuedInSessionId;
  if(sessionId){const run=promisify(execFile),cliEnv={...env,CLAUDE_CONFIG_DIR:join(userDataDir,'claude-code-profile/config')};const rows=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024})).stdout);const owned=rows.find(row=>row.sessionId===sessionId&&row.cwd===project);if(owned&&owned.state!=='stopped'){await run('/frozen-claude/claude',['stop',owned.id],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024});proof.cleanupStoppedOwnedJob=true;}}
  await save();
 }
}
