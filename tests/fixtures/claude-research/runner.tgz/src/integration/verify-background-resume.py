"""Audit authored saved app evidence, original receipts and process/history invariants."""
from pathlib import Path
import json,hashlib,subprocess,re
import argparse
parser=argparse.ArgumentParser(description='Verify saved native background resume/refusal app evidence; never execute the original CLI.')
parser.add_argument('evidence',type=Path)
parser.add_argument('product_checkout',type=Path)
parser.add_argument('--commit',help='The tested runtime commit; defaults to the checkout HEAD')
args=parser.parse_args()
e=args.evidence.resolve();product=args.product_checkout.resolve();files=list((e/'records/workspaces').glob('*/native-background-app-observation.json'));assert len(files)==1;w=files[0].parent;p=json.loads(files[0].read_text());a=p['childResume'];head=subprocess.check_output(['git','rev-parse',args.commit or 'HEAD'],cwd=product,text=True).strip();inputs=json.loads((e/'source-inputs.json').read_text())
for path,digest in inputs.items():assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+path],cwd=product)).hexdigest()==digest,path
compiled=json.loads((e/'compiled-before.json').read_text());assert compiled==json.loads((e/'compiled-after.json').read_text())
assert not p['errors'] and p['uiStop'] and p['childPidRetired'] and not p.get('cleanupStop')
assert a['refusal']['kind']=='workspace-trust-exit' and a['refusal']['originalText'] and a['refusal']['noWorker']
assert a['refusal']['attachment']['state']['status']=='exited' and a['refusal']['attachment']['state']['exitCode']==1
assert a['resumed']['job']['sessionId']==a['stoppedJob']['sessionId']==p['job']['sessionId']
assert a['resumed']['job']['id']==a['stoppedJob']['id'] and a['resumed']['job']['pid']!=a['stoppedJob']['pid']
assert a['resumed']['state']!='Z' and isinstance(a['resumed']['start'],str) and a['resumed']['start']
after=a['workerProcessAfterStop'];assert isinstance(after,dict) and (after.get('state') in ['gone','Z'] or isinstance(after.get('start'),str) and after['start']!=a['resumed']['start'])
assert a['sameSession'] and a['parentPreserved'] and a['uiStop'] and a['workerRetired']
history=a['historyRefusal'];assert history['originalText'] and history['noWorker'] and history['journalRestored']
assert history['attachment']['state']['status']=='exited' and history['attachment']['state']['exitCode']==1
output=''.join(chunk['text'] for chunk in history['attachment']['state']['output']);assert 'This session has no saved transcript' in output
childsid=a['resumed']['job']['sessionId'];parentid=p['parentSessionId']
def rows(sid):
 paths=list((w/'.claude/projects').glob('*/'+sid+'.jsonl'));assert len(paths)==1
 return paths[0],[json.loads(line) for line in paths[0].read_text().splitlines() if line]
childpath,child=rows(childsid);_,parent=rows(parentid);digest=hashlib.sha256(childpath.read_bytes()).hexdigest();assert history['journalSha256Before']==history['journalSha256After']==digest
assert not list((w/'.claude/projects').rglob('*.research-preserved')) and not list((w/'.claude/projects').rglob('*.research-unexpected'))
receipts=[row for row in child if row.get('type')=='user' and row.get('message',{}).get('content')==a['text']];assert len(receipts)==1
assert not any(row.get('message',{}).get('content')==a['text'] for row in parent)
assert a['staleText'] not in childpath.read_text()
assert all(m.get('context',{}).get('claudeTerminalMessage',{}).get('sessionId',parentid)==parentid for m in p['current']['messages'])
assert all(m.get('context',{}).get('claudeTerminalMessage',{}).get('uuid')!=receipts[0]['uuid'] for m in p['current']['messages'])
assert p['current']['claude']['totalCostUsd']==[row['totalCostUSD'] for row in parent if row.get('type')=='cost-state'][-1]
assert next(row for row in p['after'] if row['id']==a['stoppedJob']['id'])['state']=='stopped'
calls=json.loads((w/'model-calls.json').read_text());report={'status':'passed','runtimeCommit':head,'committedInputsVerified':len(inputs),'compiledFilesUnchanged':len(compiled['files']),'parentSessionId':parentid,'childSessionId':childsid,'jobId':a['stoppedJob']['id'],'initialWorkerPid':a['stoppedJob']['pid'],'resumedWorkerPid':a['resumed']['job']['pid'],'resumedWorkerStart':a['resumed']['start'],'resumedWorkerAfterStop':after,'trustExitCode':a['refusal']['attachment']['state']['exitCode'],'missingHistoryExitCode':history['attachment']['state']['exitCode'],'childHumanReceipt':receipts[0]['uuid'],'journalRestoredSha256':digest,'staleClientInputExcluded':True,'parentHistoryExcludedChildReceipt':True,'parentFinalCost':p['current']['claude']['totalCostUsd'],'retainedDraft':p['retainedDraft'],'fallbackStop':False,'pageErrors':[],'syntheticRequests':sum(len(v) for v in calls.values()),'realModelRequests':0,'eventOrder':['original Stop and process exit','trust No/exit; no worker','trust Yes; original child resumes','child input and stale-input check','close, explicit Refresh, UI Stop and resumed PID exit','preserve journal; native missing-history refusal; no worker','restore exact journal bytes'],'scope':'Raw attached terminal only. No positive resume after the final journal restoration is claimed.'};(e/'saved-record-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
