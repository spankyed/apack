import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,readdir,readlink,writeFile} from 'node:fs/promises';

/** Read only the failed app's container-local descendants; never retain environment or prompt values. */
export async function snapshotOwnedAppProcesses(rootPid,output){
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));assert.ok(Number.isSafeInteger(rootPid)&&rootPid>1);
 const names=(await readdir('/proc')).filter(name=>/^[0-9]+$/.test(name));assert.ok(names.length<=2048);
 const rows=[];
 for(const name of names){try{const status=await readFile('/proc/'+name+'/status','utf8'),parent=status.match(/^PPid:\s+(\d+)/m);if(parent)rows.push({pid:Number(name),parentPid:Number(parent[1]),name:status.match(/^Name:\s+(.+)/m)?.[1],state:status.match(/^State:\s+(.+)/m)?.[1],rssKiB:Number(status.match(/^VmRSS:\s+(\d+)/m)?.[1]??0)});}catch(error){if(!['ENOENT','ESRCH','EACCES'].includes(error.code))throw error;}}
 const owned=new Set([rootPid]);for(let i=0;i<rows.length;i++){let added=false;for(const row of rows)if(owned.has(row.parentPid)&&!owned.has(row.pid)){owned.add(row.pid);added=true;}if(!added)break;}
 const selected=rows.filter(row=>owned.has(row.pid));assert.ok(selected.length<=128);
 for(const row of selected){
  const path='/proc/'+row.pid;
  for(const field of ['exe','cwd'])try{row[field]=await readlink(path+'/'+field);}catch(error){row[field+'Error']=error.code;}
  try{const raw=await readFile(path+'/stat','utf8');row.start=raw.slice(raw.lastIndexOf(')')+2).split(' ')[19];row.waitChannel=(await readFile(path+'/wchan','utf8')).trim();}catch(error){row.stateError=error.code;}
  try{const raw=await readFile(path+'/cmdline');assert.ok(raw.length<=1048576);const argv=raw.toString().split('\0').filter(Boolean);row.argumentFlags=argv.filter(value=>/^--?[a-zA-Z][a-zA-Z0-9_-]*(?:=.*)?$/.test(value)).map(value=>value.split('=')[0]);}catch(error){row.argumentsError=error.code??error.message;}
  try{const descriptors=(await readdir(path+'/fd')).sort((a,b)=>Number(a)-Number(b));assert.ok(descriptors.length<=512);row.descriptors=[];for(const fd of descriptors.slice(0,64)){try{const target=await readlink(path+'/fd/'+fd);row.descriptors.push({fd:Number(fd),target:target.startsWith('pipe:')||target.startsWith('socket:')||target.startsWith('anon_inode:')||target==='/dev/null'?target:'file'});}catch{}}}catch(error){row.descriptorError=error.code??error.message;}
 }
 const result={observedAt:Date.now(),rootPid,rootPresent:selected.some(row=>row.pid===rootPid),processes:selected,readOnly:true,environmentCaptured:false,promptArgumentsCaptured:false};await writeFile(output,JSON.stringify(result,null,2));return result;
}
