import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, realpath } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// Launch this script with the isolated worktree's tsx loader and a minimal environment.
const [checkoutArg, executableArg, workspaceArg] = process.argv.slice(2);
if (!checkoutArg || !executableArg || !workspaceArg) {
  throw new Error('Expected isolated-apack-worktree, pinned-Claude-executable, disposable-workspace');
}
const checkout = await realpath(checkoutArg);
const primary = await realpath('/Users/spankyed/Develop/Projects/apack/monorepo');
assert.notEqual(checkout, primary, 'Refusing to load product code from the shared primary checkout');
const executable = resolve(executableArg);
const workspace = resolve(workspaceArg);
assert.equal(process.env.HOME, workspace, 'Use an isolated HOME for the probe');
assert.equal(process.env.CLAUDE_CODE_SIMPLE, '1', 'Bare-mode environment is required for this probe');
for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN']) {
  assert.equal(process.env[key], undefined, `Do not supply credentials: ${key}`);
}
const { query } = await import(pathToFileURL(join(checkout,
  'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href);
const handle = await query({ cliPath: executable, cwd: workspace, env: {
  HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'), CLAUDE_CODE_SIMPLE: '1',
  DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1',
}, tools: [], strictMcpConfig: true, noSessionPersistence: true, settings: '{}', keepStdinOpen: true, permissionMode: 'default',
  allowDangerouslySkipPermissions: true, settingSources: [], effort: 'xhigh' });
try {
  const initialization = await handle.initialized;
  const context = await handle.getContextUsage();
  assert.equal(initialization.current_permission_mode, 'default');
  const permissionModes = [];
  for (const mode of ['plan', 'acceptEdits', 'bypassPermissions', 'default']) {
    const acknowledged = await handle.setPermissionMode(mode);
    assert.equal(acknowledged, mode);
    permissionModes.push(acknowledged);
  }
  assert.match(initialization.claude_code_version, /^\d+\.\d+\.\d+(?:[-+].*)?$/);
  assert.ok(Array.isArray(initialization.commands));
  assert.ok(Array.isArray(initialization.models));
  assert.ok(Number.isFinite(context.totalTokens));
  assert.ok(context.maxTokens > 0);
  assert.ok(context.categories.every(c => c.tokens >= 0));
  console.log(JSON.stringify({ evidence: 'apack-native-controls',
    targetSha256: createHash('sha256').update(await readFile(executable)).digest('hex'),
    checkout, version: initialization.claude_code_version, initialPermissionMode: initialization.current_permission_mode, permissionModes,
    commandCount: initialization.commands.length, modelCount: initialization.models.length,
    context: { totalTokens: context.totalTokens, maxTokens: context.maxTokens,
      categoryCount: context.categories.length }, userPromptsSent: 0 }));
} finally {
  await handle.close();
}
