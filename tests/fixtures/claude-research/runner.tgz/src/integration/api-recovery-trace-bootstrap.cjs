const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
const directory=process.env.CLAUDE_RESEARCH_API_RECOVERY_TRACE_DIR;
assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
assert.match(directory,/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+\/api-recovery-trace$/);
const boundary=JSON.parse(fs.readFileSync('/control/offline-verified','utf8'));
assert.equal(boundary.diagnosticOnly,true);assert.equal(boundary.networkDisabled,true);assert.equal(boundary.requireApiCaptionRestart,true);
process.env.NODE_OPTIONS=(process.env.CLAUDE_RESEARCH_HELPER_API_NODE_OPTIONS??'--max-old-space-size=4096 --conditions=@apackdev/source')+' --import='+pathToFileURL(path.join(__dirname,'api-recovery-trace.mjs')).href;
fs.writeFileSync(path.join(directory,'main-bootstrap.json'),JSON.stringify({pid:process.pid,at:Date.now(),scope:'Passive API client-response summaries only; no helper/native import or command changes.'}),{mode:0o600,flag:'wx'});
