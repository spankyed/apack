import assert from 'node:assert/strict';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { createHash } from 'node:crypto';
import { readFile, realpath } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// Launch this script with the isolated worktree's tsx loader and a minimal environment.
const [checkoutArg, executableArg, workspaceArg] = process.argv.slice(2);
if (!checkoutArg || !executableArg || !workspaceArg) {
  throw new Error('Expected isolated-apack-worktree, pinned-Claude-executable, disposable-workspace');
}
const checkout = await realpath(checkoutArg);
const primary = await realpath('/Users/spankyed/Develop/Projects/AgentBuddy');
assert.notEqual(checkout, primary, 'Refusing to load product code from the shared primary checkout');
const executable = resolve(executableArg);
const workspace = resolve(workspaceArg);
assert.equal(process.env.HOME, workspace, 'Use an isolated HOME for the probe');
assert.equal(process.env.CLAUDE_CODE_SIMPLE, '1', 'Bare-mode environment is required for this probe');
for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN']) {
  assert.equal(process.env[key], undefined, `Do not supply credentials: ${key}`);
}
const { query } = await import(pathToFileURL(join(checkout,
  'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href);
const model = await startSyntheticModel(workspace);
let handle;
try {
  handle = await query({ cliPath: executable, cwd: workspace, env: {
    HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'),
    CLAUDE_CODE_SIMPLE: '1', ANTHROPIC_BASE_URL: model.url,
  }, tools: ['Bash'], strictMcpConfig: true, noSessionPersistence: true,
  settings: JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' }), settingSources: [],
  permissionMode: 'default', model: 'claude-sonnet-4-6', maxTurns: 3,
  surfaceControlRequests: true, signal: AbortSignal.timeout(20000) });
  const initialized = await handle.initialized;
  handle.send('Create the disposable synthetic fixture file.');
  const results = [];
  let receipt, permissionId, cancelled = false;
  for await (const event of handle.events) {
    if (event.type === 'control_request' && event.request?.subtype === 'can_use_tool') {
      permissionId = event.request_id;
      receipt = await handle.interrupt({ cancelQueued: true });
      assert.deepEqual(receipt.still_queued, []);
    }
    if (event.type === 'control_cancel_request') cancelled = event.request_id === permissionId;
    if (event.type === 'result') {
      results.push(event);
      if (results.length === 1) {
        assert.equal(event.terminal_reason, 'aborted_tools');
        assert.equal(event.is_error, true);
        handle.send('Continue with a short fixture confirmation without tools.');
      } else break;
    }
  }
  assert.equal(results.length, 2);
  assert.equal(results[1].subtype, 'success');
  assert.equal(results[0].session_id, results[1].session_id);
  assert.equal(cancelled, true);
  await assert.rejects(readFile(join(workspace, 'fixture.txt')), { code: 'ENOENT' });
  assert.equal(model.calls.length, 2);
  // The legacy one-shot result promise represents the first turn, including its interruption.
  await assert.rejects(handle.result);
  console.log(JSON.stringify({ evidence: 'apack-native-interrupt',
    targetSha256: createHash('sha256').update(await readFile(executable)).digest('hex'),
    version: initialized.claude_code_version, receipt, cancelled, sameSession: true,
    continued: true, fileCreated: false, syntheticApiRequests: 2, realModelRequests: 0,
    userPromptsSent: 2 }));
} finally {
  try { if (handle) await handle.close(); } finally { await model.close(); }
}
