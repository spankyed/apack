import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {copyFile,lstat,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {record} from '../protocol/record.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {liveOriginals} from './native-process-state.mjs';

const executable='/frozen-claude/claude';
const policy='/etc/claude-code/managed-settings.json';
const workspace=process.env.HOME;
const sha=value=>createHash('sha256').update(value).digest('hex');
const names=['managed-review','local-review','user-denied-review'];
const proof={status:'running',phases:[],onboarding:[]};
const save=()=>writeFile(join(workspace,'standalone-proof.json'),JSON.stringify(proof,null,2));
const optionalText=path=>readFile(path,'utf8').catch(error=>{
  if(error.code==='ENOENT')return '';
  throw error;
});
assert.equal(process.getuid(),1000);
assert.match(workspace,/^\/tmp\/native-credit-admission-mcp-[\w-]+$/);
assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
const project=join(workspace,'project'),debug=join(workspace,'native-debug.log');
await mkdir(project);
const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'});
const configPath=join(account.CLAUDE_CONFIG_DIR,'.claude.json');
const config=JSON.parse(await readFile(configPath,'utf8'));
const server=new URL('../protocol/synthetic-mcp-health-server.mjs',import.meta.url).pathname;
const mcpServers=Object.fromEntries(names.map(name=>[name,{type:'stdio',command:process.execPath,args:[server,join(workspace,name)]}]));
await writeFile(configPath,JSON.stringify({...config,hasCompletedOnboarding:true,mcpServers}));
await writeFile(join(account.CLAUDE_CONFIG_DIR,'settings.json'),JSON.stringify({theme:'dark',model:'opus',
  allowedMcpServers:names.map(serverName=>({serverName})),deniedMcpServers:[{serverName:'user-denied-review'}]}));
const model=await startSyntheticModel(workspace,'TextOnly',{textReply:'The isolated workspace check is complete.',captureMessages:true,maxRequests:12});
let billing,transport,running,outcome,terminal='';
const pending=new Set();
const stripAnsi=text=>text.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'');
const visibleScreen=()=>stripAnsi(terminal);
const wait=async(description,read,timeout=12000)=>{
  const deadline=Date.now()+timeout;
  do{
    if(outcome)throw Error('Terminal exited while waiting for '+description);
    const result=await read();
    if(result)return result;
    await delay(80);
  }while(Date.now()<deadline);
  throw Error('Timed out waiting for '+description);
};
const owner=async()=>{
  const entries=await liveOriginals();
  assert.equal(entries.length,1);
  return entries[0];
};
const detectCount=async()=>(await optionalText(debug)).split('Settings changed from policySettings, updating app state').length-1;
const takePanel=async()=>{
  const start=terminal.length;
  transport.send('/mcp\r');
  return wait('the original MCP panel',()=>{
    const text=stripAnsi(terminal.slice(start));
    return /Manage\s*MCP\s*servers/.test(text)&&text.includes('managed-review')&&text.slice(-5500);
  });
};
async function change(sequence){
  // Publish the complete, fixed request in one write. Only the root controller edits policy.
  await writeFile(join(workspace,`request-${sequence}.json`),JSON.stringify({sequence}),{flag:'wx'});
  const path=join(workspace,`receipt-${sequence}.json`);
  const receipt=await wait('the root-owned transition receipt',async()=>{
    const text=await optionalText(path);
    return text.endsWith('}')&&JSON.parse(text);
  });
  assert.equal((await lstat(path)).uid,0);
  assert.equal(receipt.sha256,sha(await readFile(policy)));
  assert.equal(receipt.uid,0);
  assert.equal(receipt.mode,0o644);
  await wait('the original policy state notification',async()=>await detectCount()>=sequence);
  return receipt;
}

try{
  const tls=await prepareNativeCreditTls(join(workspace,'tls'));
  billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'billing.json')});
  const env={...account,PATH:process.env.PATH,TERM:'xterm-256color',COLUMNS:'112',LINES:'35',
    NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1'};
  running=record({executable:'/usr/bin/python3',args:[new URL('../protocol/pty_bridge.py',import.meta.url).pathname,
    executable,'--model','opus','--setting-sources','user,project,local','--debug-file',debug],
    cwd:project,env,output:workspace,timeoutMs:85000,maxBytes:4*1024*1024,
    onStdout(bytes,io){
      transport=io;
      terminal+=bytes.toString('utf8');
      const stage=recognizeOnboardingPrompt(terminal,project);
      if(stage&&!proof.onboarding.includes(stage)){
        proof.onboarding.push(stage);
        const timer=setTimeout(()=>{pending.delete(timer);io.send(stage==='workspace-trust'?'\x1b[B':'\r');},180);
        pending.add(timer);
      }
    }}).then(result=>{outcome=result;return result;},error=>{outcome={error:error.message};return outcome;});
  await wait('the original terminal and approved test workspace',()=>transport&&proof.onboarding.includes('workspace-trust-selected')
    &&visibleScreen().includes('❯')&&optionalText(debug).then(log=>log.includes('Server "managed-review" connected')));
  proof.owner=await owner();
  const baseline=await takePanel();
  proof.phases.push({mode:'restricted',panel:baseline,localStarted:Boolean(await optionalText(join(workspace,'local-review')))});
  assert.equal(proof.phases[0].localStarted,false);
  assert.ok(!baseline.includes('user-denied-review'));
  await save();
  const openedAt=terminal.length;
  const withdrawal=await change(1);
  await wait('local MCP startup',()=>optionalText(join(workspace,'local-review')));
  await wait('the open original panel receiving the local server',()=>terminal.slice(openedAt).includes('local-review'));
  assert.deepEqual(await owner(),proof.owner);
  proof.phases.push({mode:'unrestricted',receipt:withdrawal,panelDelta:terminal.slice(openedAt).slice(-8000)});
  await save();
  const restored=await change(2);
  // Give the same established owner a bounded window to reconcile before the next actual request.
  await delay(18000);
  assert.deepEqual(await owner(),proof.owner);
  transport.send('\x1b');
  await delay(450);
  const reopened=await takePanel();
  const restoredPhase={mode:'restored',receipt:restored,reopenedPanel:reopened};
  proof.phases.push(restoredPhase);
  await save();
  const dismissedAt=terminal.length;
  transport.send('\x1b');
  await wait('the original panel to close',()=>/MCP\s*dialog\s*dismissed/.test(stripAnsi(terminal.slice(dismissedAt))));
  const prompt='Review the workspace after managed MCP policy has been restored.';
  const typedAt=terminal.length;
  transport.send(prompt);
  await wait('the original input to contain the prompt',()=>
    stripAnsi(terminal.slice(typedAt)).replace(/\s/g,'').includes(prompt.replace(/\s/g,'')));
  transport.send('\r');
  const request=await wait('the original model request tool inventory',()=>model.calls.find(call=>
    call.toolNames?.includes('mcp__managed-review__echo')&&JSON.stringify(call.messages).includes(prompt)),22000);
  const visibleTools=request.toolNames.filter(name=>name.startsWith('mcp__'));
  restoredPhase.visibleTools=visibleTools;
  assert.ok(!visibleTools.includes('mcp__user-denied-review__echo'));
  assert.equal(await optionalText(join(workspace,'user-denied-review')),'');
  await wait('the original terminal showing the model reply',()=>/The\s*isolated\s*workspace\s*check\s*is\s*complete\./.test(visibleScreen()));
  assert.deepEqual(await owner(),proof.owner);
  const exitAt=terminal.length;
  transport.send('/exit');
  await wait('the exit command in the original input',()=>stripAnsi(terminal.slice(exitAt)).includes('/exit'));
  transport.send('\r');
  const result=await running;
  assert.equal(result.status,'complete',JSON.stringify(result));
  assert.deepEqual(await liveOriginals(),[]);
  proof.status='complete';
}catch(error){
  proof.status='failed';
  proof.error=error.message;
  if(!outcome)transport?.stop('standalone-observation-failed');
  throw error;
}finally{
  for(const timer of pending)clearTimeout(timer);
  if(running){
    proof.process=await running;
    if(proof.process.directory)await copyFile(join(proof.process.directory,'stdout.bin'),join(workspace,'terminal.bin'));
  }
  proof.policyChanges=await detectCount();
  await save();
  await model.close();
  await billing?.close();
}
