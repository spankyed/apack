import assert from 'node:assert/strict';
import {readFile,mkdir,writeFile,readdir,copyFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {join,isAbsolute,basename} from 'node:path';
import {execFileSync} from 'node:child_process';
import {stripVTControlCharacters} from 'node:util';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {record} from '../protocol/record.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {requireReviewedNativeAppTarget,adaptNativeResearchPreload} from './native-platform-preload.mjs';

const [checkout,executable,workspace,output]=process.argv.slice(2);
assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
assert.ok(isAbsolute(workspace)&&basename(workspace).startsWith('native-credit-admission-'));assert.ok(isAbsolute(output));
const target=await requireReviewedNativeAppTarget(checkout,executable);
const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
await mkdir(workspace);await mkdir(output,{recursive:true});
const project=join(workspace,'project');await mkdir(project);
execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'});
const configPath=join(workspace,'.claude/.claude.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));
await writeFile(join(output,'profile-inputs.json'),JSON.stringify({profile:'synthetic OAuth; native-default feature gates',config,developerOverrides:false,credentialIsSynthetic:true},null,2));
const proofPath=join(workspace,'native-dialog-observer.json'),preload=join(workspace,'observe.mjs');
const observation=String.raw`
import {createHash} from 'node:crypto';import {readFileSync,writeFileSync,renameSync} from 'node:fs';
`+await adaptNativeResearchPreload(checkout,String.raw`
requireClaudeNativePlatform();
{
 let busy=false,last,changes=[];const until=Date.now()+40000;
 const timer=setInterval(async()=>{if(busy)return;if(Date.now()>until){clearInterval(timer);return}busy=true;try{
  const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),binding=runtime.ey();if(binding?.surface!=='terminal'||typeof binding.toolContext!=='function')return;
  const context=binding.toolContext(new AbortController()),sessionId=String((await import('/$bunfs/root/chunk-hdxpvbx1.js')).q());
  const dialogs=context.dialogStore.getState().open.map(item=>({id:item.id,kind:item.kind,...item.kind==='fable_overage_consent_prompt'?{payload:item.payload}:{}}));
  const [source,credit,latches]=await Promise.all(['/$bunfs/root/chunk-tm94jfk2.js','/$bunfs/root/chunk-9gw2deqq.js','/$bunfs/root/chunk-26c4qsbq.js'].map(path=>import(path)));
  const credentials=source.Fn(),gates={oauth:source.Et(),scopes:credentials?.scopes??[],subscriptionType:credentials?.subscriptionType??null,creditState:credit.Sin('claude-fable-5-1'),requiresConsent:credit.Ake('claude-fable-5-1'),usageCreditsRequired:latches.fGo(),billing:source.E('tengu_saffron_lattice',{}),latch:source.E('tengu_ember_latch',false),requestDialog:typeof context.requestDialog==='function'};
  const frame={sessionId,dialogs,gates,busy:context.turnActivity.getSnapshot()===true},key=JSON.stringify(frame);if(last===key)return;last=key;changes.push({at:Date.now(),pid:process.pid,...frame});if(changes.length>64)changes.shift();
  writeFileSync(PROOF+'.tmp',JSON.stringify({changes}));renameSync(PROOF+'.tmp',PROOF);
 }catch(error){writeFileSync(PROOF+'.error',String(error))}finally{busy=false}},100);timer.unref();
}
`.replaceAll('PROOF',JSON.stringify(proofPath)));
await writeFile(preload,observation);
const tls=await prepareNativeCreditTls(join(workspace,'tls')),billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(output,'billing.json')});
const first='Check the release review before continuing on this model.',second='Continue the same release review after the credit-limit response.',calls=[];
const server=createServer(async(req,res)=>{
 const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>65536){res.writeHead(413);res.end();return}chunks.push(chunk)}
 let body;try{body=size?JSON.parse(Buffer.concat(chunks).toString()):{}}catch{res.writeHead(400);res.end();return}
 calls.push({path:req.url,model:body.model,messages:body.messages??[]});await writeFile(join(output,'model-calls.json'),JSON.stringify(calls,null,2));
 if(calls.length>12){res.writeHead(429);res.end('{}');return}
 if(req.url==='/api/hello'){res.writeHead(200,{'content-type':'application/json'});res.end('{"ok":true}');return}
 if(!req.url?.startsWith('/v1/messages')){res.writeHead(404);res.end('{}');return}
 if(!JSON.stringify(body.messages??[]).includes(first)){
  const message={id:'msg_owned_credit_health',type:'message',role:'assistant',model:body.model,content:[{type:'text',text:'Offline review ready.'}],stop_reason:'end_turn',stop_sequence:null,usage:{input_tokens:1,output_tokens:1}};
  if(body.stream){
   res.writeHead(200,{'content-type':'text/event-stream'});
   for(const event of [{type:'message_start',message:{...message,content:[],stop_reason:null}},{type:'content_block_start',index:0,content_block:{type:'text',text:''}},{type:'content_block_delta',index:0,delta:{type:'text_delta',text:'Offline review ready.'}},{type:'content_block_stop',index:0},{type:'message_delta',delta:{stop_reason:'end_turn',stop_sequence:null},usage:{output_tokens:1}},{type:'message_stop'}])res.write('event: '+event.type+'\ndata: '+JSON.stringify(event)+'\n\n');
   res.end();return;
  }
  res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(message));return;
 }
 res.writeHead(429,{'content-type':'application/json','anthropic-ratelimit-unified-overage-disabled-reason':'overage_not_provisioned'});
 res.end(JSON.stringify({type:'error',error:{type:'rate_limit_error',message:'Usage credits are required to continue on this model.',details:{error_code:'credits_required',disabled_reason:'overage_not_provisioned',can_user_purchase_credits:true,has_chargeable_saved_payment_method:true}}}));
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const env={PATH:process.env.PATH,HOME:workspace,TERM:'xterm-256color',...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:'http://127.0.0.1:'+server.address().port,BUN_OPTIONS:'--preload='+preload,CLAUDE_CODE_DISABLE_TERMINAL_TITLE:'1'};
let terminal='',channel,firstSent=false,firstSubmitted=false,secondSent=false,secondSubmitted=false,dialogObserved=false;const actions=[],timers=[],seenTrust=new Set();
const send=(kind,text)=>{actions.push({kind,at:Date.now()});channel.send(text)};
const observer=setInterval(async()=>{if(!channel||dialogObserved)return;try{const proof=JSON.parse(await readFile(proofPath,'utf8'));if(proof.changes.some(row=>row.dialogs.some(d=>d.kind==='fable_overage_consent_prompt'))){dialogObserved=true;send('original-dialog-observed-stop','\x03');timers.push(setTimeout(()=>channel.stop('original-dialog-observed'),250));return}const frame=proof.changes.at(-1);if(firstSubmitted&&!secondSent&&frame?.gates.requiresConsent===true&&!frame.busy){secondSent=true;send('second-original-user-input',second)}}catch(error){if(error.code!=='ENOENT'&&!(error instanceof SyntaxError))throw error}},100);
let run;
try{
 run=await record({executable:'/usr/bin/python3',args:[new URL('../protocol/pty_bridge.py',import.meta.url).pathname,executable,'--model','fable','--tools','','--strict-mcp-config'],cwd:project,env,output:join(output,'transport'),timeoutMs:35000,maxBytes:2*1024*1024,onStdout(bytes,input){
  channel=input;terminal=(terminal+bytes.toString()).slice(-262144);const trust=recognizeOnboardingPrompt(terminal,project);
  if(trust&&!seenTrust.has(trust)){seenTrust.add(trust);timers.push(setTimeout(()=>send(trust,trust==='workspace-trust'?'\x1b[B':'\r'),trust==='workspace-trust-selected'?1200:200));}
  const text=stripVTControlCharacters(terminal).replace(/\s/g,'');
  if(!firstSent&&text.includes('shift+tabtocycle')){firstSent=true;timers.push(setTimeout(()=>send('first-original-user-input',first),600));}
  if(firstSent&&!firstSubmitted&&text.includes(first.replace(/\s/g,''))){firstSubmitted=true;timers.push(setTimeout(()=>send('first-original-submit','\r'),200));}
  if(secondSent&&!secondSubmitted&&text.includes(second.replace(/\s/g,''))){secondSubmitted=true;timers.push(setTimeout(()=>send('second-original-submit','\r'),200));}
 }});
}finally{clearInterval(observer);for(const timer of timers)clearTimeout(timer);await billing.close();await new Promise(resolve=>server.close(resolve));}
const after=JSON.parse(await readFile(configPath,'utf8')),proof=await readFile(proofPath,'utf8').then(JSON.parse).catch(()=>({changes:[]}));
try{await copyFile(proofPath+'.error',join(output,'observer-error.txt'))}catch(error){if(error.code!=='ENOENT')throw error}
const journalRoot=join(workspace,'.claude/projects'),journals=[];
try{for(const name of await readdir(journalRoot,{recursive:true}))if(name.endsWith('.jsonl')){const bytes=await readFile(join(journalRoot,name));assert.ok(bytes.length<=4*1024*1024);const destination=join(output,'native-journals',name);await mkdir(join(destination,'..'),{recursive:true});await writeFile(destination,bytes);journals.push({path:'native-journals/'+name,bytes:bytes.length})}}catch(error){if(error.code!=='ENOENT')throw error}
const receipt={target,run,dialogObserved,journals,actions,calls:calls.length,featureInputsSeeded:false,finalNativeFeatureCache:after.cachedGrowthBookFeatures??null,developerOverrideWritten:after.growthBookOverrides!==undefined,purchases:billing.state.purchases,adminRequests:billing.state.adminRequests,scope:'Original Linux CLI admission through ordinary terminal inputs and an offline synthetic credits_required provider response. Synthetic OAuth/account only; no persisted feature gates, dialog injection, testing-only entry, billing/admin mutations, app GUI or actual account eligibility claim.'};
await writeFile(join(output,'native-observations.json'),JSON.stringify(proof,null,2));await writeFile(join(output,'receipt.json'),JSON.stringify(receipt,null,2));
assert.equal(receipt.featureInputsSeeded,false);assert.equal(receipt.developerOverrideWritten,false);assert.deepEqual(receipt.purchases,[]);assert.deepEqual(receipt.adminRequests,[]);assert.equal(dialogObserved,true,'Original mid-session producer was not admitted; preserve the recorded source/transport evidence');
console.log(JSON.stringify(receipt));
