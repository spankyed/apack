import assert from 'node:assert/strict';
import {mkdir,readFile,realpath} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const[checkout,executable,workspace]=process.argv.slice(2);
assert.notEqual(await realpath(checkout),await realpath('/Users/spankyed/Develop/Projects/apack/monorepo'));
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const{query}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')));
const{createClaudeConversation}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/conversation.ts')));
const server=fileURLToPath(new URL('../protocol/synthetic-elicitation-server.mjs',import.meta.url)),cases=[];
for(const mode of ['form','url'])for(const ending of ['interrupt','kill']){
 const cwd=join(workspace,mode+'-'+ending),home=join(cwd,'home'),capture=join(cwd,'mcp.jsonl');await mkdir(join(home,'.claude'),{recursive:true});
 const model=await startSyntheticModel(cwd,'mcp__research__echo');let native,owner;
 const elicitation=Promise.withResolvers(),events=[];let permissionCount=0,consumerFailure;
 try{
  native=await query({cliPath:resolve(executable),cwd,env:{HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url},tools:'default',strictMcpConfig:true,mcpConfig:[JSON.stringify({mcpServers:{research:{type:'stdio',command:process.execPath,args:[server,capture,mode]}}})],settingSources:[],settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),noSessionPersistence:true,permissionMode:'default',model:'default',maxTurns:3,keepStdinOpen:true,replayUserMessages:true,surfaceControlRequests:true,signal:AbortSignal.timeout(15000)});
  await native.initialized;
  const consume=async turn=>{try{for await(const event of turn.handle.events){events.push(event);if(event.type==='control_request'){
   if(event.request.subtype==='can_use_tool'){permissionCount++;turn.handle.respond(event.request_id,{behavior:'allow',updatedInput:event.request.input});}
   else if(event.request.subtype==='elicitation')elicitation.resolve(event);
   else throw Error('Unexpected control '+event.request.subtype);
  }}}catch(error){consumerFailure=error.name;}finally{owner.release(turn.handle);}};
  owner=createClaudeConversation(native,consume);owner.start('Run the local research echo fixture once.',consume);
  const pending=await Promise.race([elicitation.promise,owner.done.then(()=>{throw Error('Native process closed before elicitation');})]);assert.equal(owner.hasPendingElicitation(pending.request_id),true);assert.equal(pending.request.mode,mode);assert.equal(permissionCount,1);
  const resultRejected=native.result.then(()=>false,()=>true);
  if(ending==='interrupt')await owner.handle.interrupt();else owner.kill();
  await owner.done.catch(()=>{});await native.close().catch(()=>{});
  assert.equal(owner.hasPendingElicitation(pending.request_id),false);assert.equal(owner.busy,false);
  assert.throws(()=>owner.handle.respondElicitation(pending.request_id,{action:'accept',...(mode==='form'?{content:{choice:'Alpha'}}:{})}),/no longer pending/);
  assert.throws(()=>owner.start('late input',consume),/closed/);
  assert.equal(await resultRejected,true);assert.equal(model.calls.length,1);
  const inputs=(await readFile(capture,'utf8')).trim().split('\n').map(line=>JSON.parse(line));
  const serverAnswer=inputs.find(value=>value.id==='fixture-elicitation'&&value.result)?.result;
  if(ending==='interrupt'){assert.deepEqual(serverAnswer,{action:'cancel'});assert.ok(events.some(value=>value.type==='control_cancel_request'&&value.request_id===pending.request_id));assert.ok(events.some(value=>value.type==='result'&&value.terminal_reason==='aborted_tools'));}
  assert.equal(inputs.some(value=>value.id==='fixture-elicitation'&&value.result?.action==='accept'),false);
  cases.push({mode,ending,permissionCount,requestRetired:true,lateResponseRejected:true,lateInputRejected:true,resultRejected:true,busy:false,serverAnswer:serverAnswer??null,nativeWithdrawal:events.some(value=>value.type==='control_cancel_request'&&value.request_id===pending.request_id),consumerFailure:consumerFailure??null,localModelRequests:model.calls.length});
 }finally{owner?.kill();await native?.close().catch(()=>{});await model.close();}
}
console.log(JSON.stringify({evidence:'native-elicitation-owner-lifecycle',cases,realModelRequests:0}));
