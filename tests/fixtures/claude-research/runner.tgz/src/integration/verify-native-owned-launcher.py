"""Verify original worker startup/helper observation in a fresh research-only Claude profile."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence',type=Path)
parser.add_argument('product',type=Path)
parser.add_argument('--research-commit',required=True)
parser.add_argument('--product-commit',required=True)
parser.add_argument('--expect-helper-transport',action='store_true')
a=parser.parse_args();load=lambda p:json.loads(p.read_text())
subprocess.run([sys.executable,str(Path(__file__).with_name('verify-native-child-subagent-formatter.py')),str(a.evidence),str(a.product),'--research-commit',a.research_commit,'--product-commit',a.product_commit],check=True,stdout=subprocess.DEVNULL)
records=a.evidence/'export/records';workspace=a.evidence/'export/apack-terminal-owner-app-background'
base=load(a.evidence/'saved-record-verification.json');audit=load(records/'owned-launcher-audit.json');job=audit['job'];worker=audit['worker'];child=job['sessionId'];remote=job['cwd'].removesuffix('/project')
assert job['pid']==base['workerPid']==worker['pid'] and child==base['childSessionId']
assert worker['binarySha256']=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10' and worker['restoredBunOptions']
assert child in worker['argv']
attachment=load(records/'original-child-attach-observation.json');assert worker['processStart']==attachment['processBefore']['startTime']==attachment['processAfter']['startTime']
assert audit['invocations'] and len({v['pid']for v in audit['invocations']})==len(audit['invocations'])
assert any(v['mode']=='pass'for v in audit['invocations'])
for v in audit['invocations']:
    assert v['configDirectory']==remote+'/.claude' and v['argv'][0]=='/frozen-claude/claude'
    if v['mode']=='worker':
        assert v['sessionKind']=='bg' and v['rendezvousSocketPresent'] and '--bg-pty-host'not in v['argv']
    else:
        assert v['mode']=='pass'
        assert not (workspace/'owned-launcher'/('worker-'+str(v['pid'])+'.json')).exists()
invocation=next(v for v in audit['invocations']if v['pid']==job['pid']);assert invocation['mode']=='worker' and child in invocation['argv']
for name,digest in audit['sources'].items():
    assert name.startswith(remote+'/owned-launcher/')
    assert hashlib.sha256((workspace/name[len(remote)+1:]).read_bytes()).hexdigest()==digest
host=load(workspace/'project'/('native-child-host-'+child+'.json'));assert host['sessionId']==child and not host['bunOptionsPresent']
assert not (workspace/'native-dispatch-preload-audit.json').exists(),'Dispatch environment interception is not this startup route'
helper_proof=None
if a.expect_helper_transport:
    config=load(workspace/'owned-launcher/workers'/str(job['pid'])/'observer.json')
    assert config['sessionId']==child
    relative='packages/default-setup/src/features/code/be/services/claude-code/terminal-status-runtime.ts'
    original=subprocess.check_output(['git','show',a.product_commit+':'+relative],cwd=a.product)
    raw=re.search(rb'String\.raw`([\s\S]*)`;?\s*$',original);assert raw
    runtime=raw[1]
    for file in [workspace/'owned-launcher/status-template.mjs',workspace/'owned-launcher/workers'/str(job['pid'])/'status.mjs']:
        assert file.read_bytes()==runtime,'Observed runtime must match the pinned authored product export'
    rows=[v for v in audit['helperEvents']if v['value'].get('sessionId')==child]
    assert any(v['path']=='/observer-ready'and v['value']['pid']==job['pid']for v in rows)
    assert not any(v['path']=='/observer-error'for v in rows)
    sub=[v for v in rows if v['path']=='/native-status'and v['value'].get('kind')=='subagent'];assert len(sub)>=2
    formatter=load(records/'child-formatter-audit.json');receipts=[v for v in formatter['snapshots'][-1]['invocations']if v['sessionId']==child and v.get('kind')=='subagent'];assert len(receipts)>=2
    settings=load(workspace/'.claude/settings.json');starts=set()
    for row in sub:
        v=row['value'];assert v['parentPid']==job['pid']and v['code']==0 and v['signal']is None and not v['truncated']
        assert v['generation']==config['generations']['subagent']
        assert v['command']==settings['subagentStatusLine']['command']
        assert re.fullmatch(r'[0-9]+',v['startedAt']);starts.add(v['startedAt'])
        assert any(receipt['stdout']==v['stdout']and row['at']>=receipt['at']and v['childPid']in[receipt['pid'],receipt['parentPid']]and {t['id']for t in receipt['input']['tasks']}=={t['id']for t in v['tasks']}for receipt in receipts),'Must match an actual original helper invocation and task input'
    assert len(starts)>=2
    helper_proof={'nativeSubagentResults':len(sub),'exactConfiguredCommandAndStdout':True,'originalTaskIds':base['originalTaskIds'],'sameOriginalWorkerAndSession':True,'additionalPinnedObserverSource':{'file':relative,'sourceSha256':hashlib.sha256(original).hexdigest(),'runtimeSha256':hashlib.sha256(runtime).hexdigest()},'scope':'Observation of native-admitted helper output only. No policy-epoch admission, app desktop caption or production profile compatibility acceptance.'}
proof={**base,'status':'passed-native-owned-launcher-only','originalWorkerBootstrap':True,'sameProcessIncarnation':True,'restoredOriginalBunOptions':True,'privateProfileOnly':True,'wrapperPassThroughProcesses':sum(v['mode']=='pass'for v in audit['invocations']),'helperTransport':helper_proof,'scope':'Original corporate-launcher startup in a fresh research-owned profile/daemon. No shared production daemon change, native dispatch-filter patch, installed config/auth/session migration, app delivery or combined F1–F5 acceptance.'}
(a.evidence/'owned-launcher-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
