import assert from 'node:assert/strict';
import {createServer,connect} from 'node:net';
import {mkdtemp,chmod} from 'node:fs/promises';
import {join} from 'node:path';

/** Transparent, disposable view-only transport fault; never touches the broker's process/control socket. */
export async function installOwnedNativeViewRelay(electronApp){
 const endpoint=await electronApp.evaluate(({ipcMain})=>{
  const listeners=ipcMain.listeners('terminal:view-endpoint');if(listeners.length!==1)throw Error('Expected one original terminal endpoint listener');
  const event={returnValue:undefined};listeners[0](event,undefined);
  if(!event.returnValue?.socket||!event.returnValue?.greeting)throw Error('Original broker endpoint unavailable');
  return event.returnValue;
 });
 const directory=await mkdtemp('/tmp/claude-view-relay-');await chmod(directory,0o700);const socket=join(directory,'view.sock');
 let next=0,dropped=0;const pairs=new Map(),records=[];
 const server=createServer(downstream=>{
  const id=++next,upstream=connect(endpoint.socket),record={id,up:0,down:0,closed:false};records.push(record);
  const pair={downstream,upstream,record};pairs.set(id,pair);
  const close=()=>{if(record.closed)return;record.closed=true;pairs.delete(id);downstream.destroy();upstream.destroy();};
  for(const stream of [downstream,upstream]){stream.on('error',close);stream.on('close',close);}
  downstream.on('data',bytes=>{record.up+=bytes.length;if(record.up>16*1024**2)close();});
  upstream.on('data',bytes=>{record.down+=bytes.length;if(record.down>16*1024**2)close();});
  downstream.pipe(upstream);upstream.pipe(downstream);
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(socket,resolve);});
 let installed=false;
 try{
  await electronApp.evaluate(({ipcMain},socket)=>{
   if(globalThis.__claudeResearchViewRelay)throw Error('View relay already installed');
   const listeners=ipcMain.listeners('terminal:view-endpoint');if(listeners.length!==1)throw Error('Endpoint listener changed');
   const original=listeners[0],wrapper=(event,target)=>{if(target!==undefined)return original(event,target);const reply={returnValue:undefined};original(reply,target);event.returnValue=reply.returnValue?.socket?{...reply.returnValue,socket}:reply.returnValue;};
   ipcMain.removeListener('terminal:view-endpoint',original);ipcMain.on('terminal:view-endpoint',wrapper);
   globalThis.__claudeResearchViewRelay={original,wrapper};
  },socket);installed=true;
 }catch(error){await new Promise(resolve=>server.close(resolve));throw error;}
 return{
  snapshot:()=>({connections:records.map(row=>({...row})),dropped}),
  drop(){const current=[...pairs.values()];assert.equal(current.length,1,'Drop only one known native view connection');assert.ok(current[0].record.up>0&&current[0].record.down>0,'Connection never exchanged broker bytes');dropped++;current[0].downstream.destroy();current[0].upstream.destroy();},
  async close(){
   try{if(installed){await electronApp.evaluate(({ipcMain})=>{const state=globalThis.__claudeResearchViewRelay;if(!state)throw Error('Owned relay listener missing');if(!ipcMain.listeners('terminal:view-endpoint').includes(state.wrapper))throw Error('Owned relay listener changed');ipcMain.removeListener('terminal:view-endpoint',state.wrapper);ipcMain.on('terminal:view-endpoint',state.original);delete globalThis.__claudeResearchViewRelay;});installed=false;}}
   finally{const streams=[...pairs.values()].flatMap(({downstream,upstream})=>[downstream,upstream]);await Promise.all(streams.map(stream=>stream.closed?Promise.resolve():new Promise(resolve=>{stream.once('close',resolve);stream.destroy();})));await new Promise(resolve=>server.close(resolve));}
   return {restored:true,...this.snapshot()};
  }
 };
}

export async function verifyNativeViewReconnect({relay,page,section,context,proof,processStart,output,save,expect}){
 const before=await context(),input=()=>section.locator('[aria-label="Terminal input"]'),text=()=>section.locator('[data-terminal-text]').innerText(),draft='Keep this native draft through the connection recovery.';
 const normalize=value=>value.replace(/\s+/g,'');
 await page.setViewportSize({width:1100,height:900});await input().focus();await input().pressSequentially(draft);await expect.poll(text,{timeout:10000}).toContain(draft);
 const observed=proof.brokerReconnect={status:'running',draft,before,connectionBefore:relay.snapshot(),captures:[]};await save();
 const capture=async tag=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect.poll(async()=>normalize(await text()),{timeout:10000}).toContain(normalize(draft));await expect(section.locator('[data-native-terminal]')).toBeInViewport();await page.evaluate(()=>document.fonts.ready.then(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))));const name='native-view-reconnect-'+tag+'-'+size+'.png';await page.screenshot({path:join(output,name),animations:'disabled'});observed.captures.push(name);await save();}};
 await capture('before');await page.setViewportSize({width:1100,height:900});await input().focus();relay.drop();
 await expect.poll(()=>relay.snapshot().connections.length,{timeout:10000}).toBe(2);
 await expect.poll(async()=>normalize(await text()),{timeout:10000}).toContain(normalize(draft));await expect(input()).toBeFocused();
 observed.after=await context();observed.connectionAfter=relay.snapshot();observed.processStartAfter=await processStart(proof.pid);
 assert.equal(observed.processStartAfter,proof.processStart);assert.equal(observed.after.native.state.nativePid,proof.pid);assert.deepEqual(observed.after.native.state.terminalSession,before.native.state.terminalSession);assert.equal(observed.after.claude.sessionId,before.claude.sessionId);assert.equal(observed.after.claude.turns,before.claude.turns);assert.equal(observed.after.claude.totalCostUsd,before.claude.totalCostUsd);assert.deepEqual(observed.after.messages,before.messages);
 await capture('after');await input().focus();await input().press('Control+u');await expect.poll(async()=>normalize(await text()),{timeout:10000}).not.toContain(normalize(draft));observed.clearedWithoutSubmit=true;observed.status='complete';await save();
}
