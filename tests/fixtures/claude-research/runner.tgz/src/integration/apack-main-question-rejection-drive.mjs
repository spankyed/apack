import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,writeFile,readdir,lstat,rename} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
import {findOwnedBroker} from './native-terminal-broker-loss-journey.mjs';
import {createNativeTestImage} from '../protocol/native-test-image.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function processStart(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]==='Z'?undefined:fields[19]}catch(error){if(error.code==='ENOENT')return;throw error}}
/** Emergency caller must first stop the owned app container and hold the work-volume lock. */
export async function restoreMainQuestionRejectionProfile(workspace){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));assert.match(workspace,/^\/work\/\.claude-research\/main-question-rejection-app[0-9]+$/);
 const settings='/work/.claude-research/profile-setup-app10/app-data/claude-code-profile/config/settings.json',before=await readFile(join(workspace,'main-question-settings-before.json')),mode=JSON.parse(await readFile(join(workspace,'main-question-settings-mode.json'),'utf8'));
 assert.equal(sha(before),'5eb7b71763d6c0fc454f048fe69cb174724f161d2f4cdc50a8776c83cbc2e128');assert.ok(Number.isInteger(mode)&&mode>=0&&mode<=0o7777);
 const stat=await lstat(settings);assert.ok(stat.isFile()&&!stat.isSymbolicLink()&&stat.uid===1000&&stat.size<=1048576);const current=await readFile(settings);
 if(!current.equals(before)){const preserved=join(workspace,'preserved-main-question-settings.json');await assert.rejects(lstat(preserved),{code:'ENOENT'});await rename(settings,preserved);await writeFile(settings,before,{mode,flag:'wx'})}
 assert.deepEqual(await readFile(settings),before);assert.equal((await lstat(settings)).mode&0o7777,mode);return{restored:true,sha256:sha(before),mode};
}
export async function driveMainQuestionRejection(options){
 assert.equal(process.platform,'linux');assert.match(options.workspace,/^\/work\/\.claude-research\/main-question-rejection-app[0-9]+$/);
 assert.equal(options.setupWorkspace,'/work/.claude-research/profile-setup-app10');
 const settings=join(options.setupWorkspace,'app-data/claude-code-profile/config/settings.json'),before=await readFile(settings);assert.equal(sha(before),'5eb7b71763d6c0fc454f048fe69cb174724f161d2f4cdc50a8776c83cbc2e128');
 await writeFile(join(options.workspace,'main-question-settings-before.json'),before,{mode:0o600,flag:'wx'});await writeFile(join(options.workspace,'main-question-settings-mode.json'),JSON.stringify((await lstat(settings)).mode&0o7777),{mode:0o600,flag:'wx'});
 let error;
 try{await driveChildComposer({...options,modelRequestLimit:16,modelFactory:async({maxRequests})=>{
  let waiting,release;const provider=await startSyntheticAgentModel({launchAgent:false,parentLaunchOnce:true,everydayProbe:true,questionProbe:true,questionRecoveryProbe:true,captureMessages:true,requestLimit:maxRequests,beforeDecision:async tool=>{assert.equal(tool,'AskUserQuestion');assert.equal(waiting,undefined);waiting=tool;await new Promise(resolve=>{release=resolve})}});
  return{...provider,get waiting(){return waiting},releaseQuestion(){assert.equal(waiting,'AskUserQuestion');waiting=undefined;const done=release;release=undefined;done()},async close(){release?.();await provider.close()}};
 },journey:args=>rejectionJourney({...args,feedback:options.feedback===true}),journeyName:'main-question-rejection'});}catch(caught){error=caught;}
 const restored=await restoreMainQuestionRejectionProfile(options.workspace);
 const output=join(options.workspace,'electron-results');let proof;try{proof=JSON.parse(await readFile(join(output,'main-question-rejection.json'),'utf8'))}catch(readError){if(error&&readError.code==='ENOENT')throw error;throw readError;}
 if(proof.sessionId){
  if(error&&await processStart(proof.pid)===proof.processStart){proof.failureCleanup={writerStillAlive:true,journalNotCopied:true,reason:'Preserve the original journey error; outer controller must stop the owned container before recovery.'};await writeFile(join(output,'main-question-rejection.json'),JSON.stringify(proof,null,2));throw error;}
  assert.notEqual(await processStart(proof.pid),proof.processStart,'Copy original journal only after its writer retires');
  const root=join(options.setupWorkspace,'app-data/claude-code-profile/config/projects'),names=await readdir(root,{recursive:true});assert.ok(names.length<=4096);const selected=names.filter(name=>basename(name)===proof.sessionId+'.jsonl');assert.equal(selected.length,1);const path=join(root,selected[0]),stat=await lstat(path);assert.ok(stat.isFile()&&stat.uid===1000&&stat.size<=16*1048576);const bytes=await readFile(path);await writeFile(join(output,'native-parent-transcript.jsonl'),bytes);proof.journal={sha256:sha(bytes),writerRetired:true};
 }
 assert.deepEqual(await readFile(settings),before);proof.settingsRestored=restored;await writeFile(join(output,'main-question-rejection.json'),JSON.stringify(proof,null,2));if(error)throw error;
}
export async function rejectionJourney({app,page,electronApp,output,project,userDataDir,expect,phase,model,feedback,freshProfile=false,addressedReplay=false,nativeViewReconnect,brokerLoss=false,clarification=false,label,images=false,imageEdges=false,extendedClarification=false,invalidImageRecovery=false}){
 const proof={status:'running',scope:'Original main-owner rejection and fresh-question/recovery. Addressed old-action dispatch is attempted without a backend/native delivery receipt; it is not independent stale-native refusal acceptance. Not process interruption or full lifecycle/F1–F5 acceptance.',captures:[]},save=()=>writeFile(join(output,'main-question-rejection.json'),JSON.stringify(proof,null,2));
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true}),panel=page.getByTestId('native-question-panel');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews}});
 const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await composer.pressSequentially(text);await expect(composer).toHaveText(text)};
 const document=()=>composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
 const capture=async(tag,question)=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);if(question){await expect(panel).toBeInViewport({ratio:1});
  if (clarification && tag === 'fresh') {
   const alert=panel.getByRole('alert');
   await alert.scrollIntoViewIfNeeded();
   await expect(alert).toBeInViewport({ratio:1});
   const staleFile='main-question-stale-refused-'+size+'.png';
   await page.screenshot({path:join(output,staleFile),animations:'disabled'});
   proof.captures.push(staleFile);
   const custom=panel.getByRole('button',{name:'Write your own answer',exact:true});
   await custom.scrollIntoViewIfNeeded();
  }
  for(const button of await panel.getByRole('button').all())await expect(button).toBeInViewport({ratio:1});}else{await expect(composer).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});}const file='main-question-'+tag+'-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);await save()}};
 let activePid,activeStart;
 const questionFrame=async()=>{const c=await context(),rows=Object.entries(c.ui).filter(([,v])=>v.state?.question?.token);assert.equal(rows.length,1);return{threadId:c.threadId,mountId:rows[0][0],...rows[0][1].state.question}};
 try{
  const producer=JSON.parse(await readFile('/control/producer-pack-inputs.json','utf8')),files={};for(const name of ['runtime/fe.js','runtime/index.cjs']){files[name]=sha(await readFile(join(userDataDir,'apack/packs/default-setup',name)));assert.equal(files[name],producer[name]);}await writeFile(join(output,'installed-candidate-before-journey.json'),JSON.stringify({passed:true,files}));
  await app.waitForSurface('default-setup/threads');
  if(freshProfile){await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');await page.waitForTimeout(700);}
  await app.navigate('default-setup/threads');await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return!!c.currentThread?.id&&c.openedThreadId===null&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code')}),{timeout:15000}).toBe(true);
  await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});await expect.poll(async()=>(await context()).claude?.sessionId).toBeUndefined();
  proof.seed='Review the release audience before writing the summary.';await replace(proof.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);
  const openNative=async()=>{
   await section.getByRole('button',{name:'Use native interface',exact:true}).click();
   if(freshProfile){const {recognizeOnboardingPrompt}=await import('../protocol/pty-onboarding.mjs'),seen=new Set();for(let i=0;i<100;i++){const native=(await context()).native?.state;if(native?.nativePid&&native.status==='live')break;const text=await section.locator('[data-terminal-text]').innerText().catch(()=>''),stage=recognizeOnboardingPrompt(text,project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100);}}
   await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
  };
  await openNative();
  proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.pid=proof.initial.native.state.nativePid;proof.processStart=await processStart(proof.pid);assert.ok(proof.processStart);activePid=proof.pid;activeStart=proof.processStart;if(nativeViewReconnect)await nativeViewReconnect({page,section,context,proof,processStart,output,save,expect});await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  proof.rejectPrompt='Ask me which release audience to target.';await replace(proof.rejectPrompt);await send.click();await expect.poll(()=>model.waiting,{timeout:15000}).toBe('AskUserQuestion');proof.draft='Keep my release notes while I decide who to address.';await replace(proof.draft);proof.retained=await document();model.releaseQuestion();
  await expect(panel).toBeVisible();
  await expect(panel.getByRole('button',{name:'Reject question',exact:true})).toBeEnabled();
  proof.old=await questionFrame();
  if (invalidImageRecovery) {
   proof.scope='Native decoder refusal retains the held question, custom answer, exact composer, and valid sibling attachment. Removing only the malformed image permits one original answer.';
   const outcome=await recoverInvalidQuestionImage({panel,page,expect,proof,output,model,questionFrame,context});
   await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:15000}).toBe(false);
   await expect(composer).toHaveText(proof.draft);
   assert.deepEqual(await document(),proof.retained);
   assert.equal((await context()).claude.sessionId,proof.sessionId);
   assert.equal(await processStart(proof.pid),proof.processStart);
   outcome.retainedComposer=true;
   await section.getByRole('button',{name:'Use native interface',exact:true}).click();
   await section.getByRole('button',{name:'Stop session',exact:true}).click();
   await expect.poll(()=>processStart(activePid),{timeout:15000}).not.toBe(activeStart);
   proof.writerRetired=true;
   proof.status='complete';
   await save();
   phase('invalid-question-image-recovery-complete');
   return;
  }
  if (extendedClarification) {
   proof.scope = 'Desktop clarification through the original opted-in extended question schema. Partial choice and text answers are retained, and the untouched number default is left unanswered.';
   assert.equal(proof.old.presentation.extendedQuestions,true);
   const clarify = panel.getByRole('button',{name:'Chat about this',exact:true});
   const next = panel.getByRole('button',{name:'Next',exact:true});
   await panel.getByRole('radio',{name:'Developers People integrating the updated behavior',exact:true}).check();
   await next.click();
   await expect(panel.getByRole('heading',{name:'What should the release be called?',exact:true})).toBeVisible();
   const text = panel.getByRole('textbox',{name:'Your answer',exact:true});
   await text.fill('Notebook release');
   await captureExtendedQuestion('text',text);
   await next.click();
   const count = panel.getByRole('spinbutton',{name:'Value (examples)',exact:true});
   await expect(count).toHaveValue('3');
   await captureExtendedQuestion('number',count);
   await clarify.click();
   await expect(panel).toBeHidden({timeout:15000});
   await expect.poll(()=>model.calls.some(call=>call.nativeQuestionError),{timeout:15000}).toBe(true);
   const result = model.calls.find(call=>call.nativeQuestionError).messages.flatMap(message=>Array.isArray(message.content)?message.content:[])
     .find(block=>block.type==='tool_result'&&block.tool_use_id==='native_question_fixture');
   assert.ok(result?.is_error);
   assert.match(result.content,/The user wants to clarify these questions/);
   assert.match(result.content,/"Who should the release summary address\?"\n  Answer: Developers/);
   assert.match(result.content,/"What should the release be called\?"\n  Answer: Notebook release/);
   assert.match(result.content,/"How many examples should be included\?"\n  \(No answer provided\)/);
   assert.ok(model.calls.some(call=>call.questionExtendedAdvertised===true));
   await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:15000}).toBe(false);
   await expect(composer).toHaveText(proof.draft);
   assert.deepEqual(await document(),proof.retained);
   assert.equal((await context()).claude.sessionId,proof.sessionId);
   assert.equal(await processStart(proof.pid),proof.processStart);
   proof.extendedClarification={result,retainedComposer:true,sameNativeSession:true,untouchedNumber:'3'};
   await section.getByRole('button',{name:'Use native interface',exact:true}).click();
   await section.getByRole('button',{name:'Stop session',exact:true}).click();
   await expect.poll(()=>processStart(activePid),{timeout:15000}).not.toBe(activeStart);
   proof.writerRetired=true;
   proof.status='complete';
   await save();
   phase('extended-question-clarification-complete');
   return;

   async function captureExtendedQuestion(stage, field) {
    for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
     await page.setViewportSize(viewport);
     await field.scrollIntoViewIfNeeded();
     await expect(field).toBeInViewport({ratio:1});
     await expect(clarify).toBeInViewport({ratio:1});
     await expect(clarify).toBeEnabled();
     const file='extended-question-'+stage+'-'+size+'.png';
     await page.screenshot({path:join(output,file),animations:'disabled'});
     proof.captures.push(file);
    }
   }
  }
  await capture('pending',true);
  if (clarification) {
   proof.scope = 'Main desktop clarification from an ordinary multi-step question, retaining its draft and verifying a fresh question after stale refusal.';
   const button = panel.getByRole('button', { name:'Chat about this', exact:true });
   if (label) {
    await expect(panel.getByRole('heading',{name:label,exact:true})).toBeVisible();
    await expect(panel.getByRole('heading',{name:'Who should the release summary address?',exact:true})).toHaveCount(0);
   }
   const imageFiles=imageEdges?await checkQuestionImageEdges({panel,page,expect,proof,output}):undefined;
   let clarificationImage;
   if (images) {
    clarificationImage=await pasteQuestionImage(electronApp,panel,expect);
    const removed=await pickQuestionImage(panel,expect,'Discarded.png',[240,25,25,255]);
    await panel.getByRole('button',{name:'Remove Discarded.png',exact:true}).click();
    await expect(panel.getByRole('button',{name:'Remove Discarded.png',exact:true})).toHaveCount(0);
    proof.questionImages={clipboard:sha(clarificationImage),removed:sha(removed),captures:[]};
    for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
     await page.setViewportSize(viewport);
     const image=panel.getByRole('list',{name:'Question images'}).locator('img');
     await image.scrollIntoViewIfNeeded();
     await expect(image).toBeInViewport({ratio:1});
     await expect(button).toBeInViewport({ratio:1});
     const filename='question-image-draft-'+size+'.png';
     await page.screenshot({path:join(output,filename),animations:'disabled'});
     proof.captures.push(filename);proof.questionImages.captures.push(filename);
    }
    await page.setViewportSize({width:1100,height:900});
   }
   const first = panel.getByRole('radio', { name:'Developers People integrating the updated behavior', exact:true });
   await first.check();
   await panel.getByText('Add notes', { exact:true }).click();
   await panel.getByRole('textbox', { name:'Notes for this question' }).fill('Highlight the migration steps.');
   await panel.getByRole('button', { name:'Next', exact:true }).click();
   await expect(panel.getByRole('heading', { name:'How should the migration be announced?', exact:true })).toBeVisible();
   await expect(button).toBeEnabled();
   await capture('clarification',true);
   await button.click();
   await expect.poll(() => model.calls.some(call => call.nativeQuestionError), { timeout:15000 }).toBe(true);
   const call = model.calls.find(call => call.nativeQuestionError);
   const result = call.messages.flatMap(message => Array.isArray(message.content) ? message.content : [])
     .find(block => block.type === 'tool_result' && block.tool_use_id === 'native_question_fixture');
   assert.equal(result?.is_error,true);
   if (clarificationImage) {
    proof.questionImages.clarification=questionImageAfterResult(call,'native_question_fixture');
    assert.equal(proof.questionImages.clarification,sha(clarificationImage));
   }
   assert.match(result.content,/The user wants to clarify these questions\./);
   assert.ok(result.content.endsWith([
    '- "Who should the release summary address?"', '  Answer: Developers', '  User notes: Highlight the migration steps.',
    '- "How should the migration be announced?"', '  (No answer provided)',
   ].join('\n')));
   if(label) assert.equal(result.content.includes(label),false);
   if(imageFiles){
    const row=call.messages.find(message=>Array.isArray(message.content)&&message.content.includes(result));
    assert.ok(row);
    const options=row.content.slice(row.content.indexOf(result)+1);
    assert.equal(options.length,imageFiles.length);
    proof.imageEdges.provider=options.map((part,index)=>{
     assert.equal(part.type,'image');
     const input=imageFiles[index],bytes=Buffer.from(part.source.data,'base64');
     if(index<3){
      assert.equal(part.source.media_type,input.mimeType);
      assert.deepEqual(bytes,input.buffer);
     }else{
      assert.equal(part.source.media_type,'image/png');
      assert.deepEqual(bytes.subarray(0,8),input.buffer.subarray(0,8));
      const width=bytes.readUInt32BE(16),height=bytes.readUInt32BE(20);
      assert.ok(width<=2000&&width>=1000);
      assert.ok(Math.abs(width/height-2500/32)<4);
      assert.notEqual(sha(bytes),sha(input.buffer));
     }
     return {input:input.name,mediaType:part.source.media_type,sha256:sha(bytes),...(index===3?{width:bytes.readUInt32BE(16),height:bytes.readUInt32BE(20)}:{})};
    });
   }
   proof.clarification = {result,...(label?{relabeledTitle:label}:{})};
   await save();
  }
  if(brokerLoss){
   proof.scope='Abrupt private terminal broker loss with an original main-owner question pending.';
   proof.owners=[{pid:activePid,processStart:activeStart}];
   const before=await context(), broker=await findOwnedBroker(activePid);
   proof.brokerLoss={broker,before,old:proof.old};
   await save();
   assert.deepEqual(await findOwnedBroker(activePid),broker);
   assert.equal(await processStart(broker.pid),broker.start);
   process.kill(broker.pid,'SIGKILL');
   await expect.poll(()=>processStart(broker.pid)).toBeUndefined();
   await expect.poll(()=>processStart(activePid),{timeout:15000}).toBeUndefined();
   await expect(panel).toBeHidden();
   await expect(section.getByRole('status')).toContainText('disconnected unexpectedly');
   await expect(composer).toHaveText(proof.draft);
   assert.deepEqual(await document(),proof.retained);
   const interrupted=await context();
   assert.equal(interrupted.claude.sessionId,proof.sessionId);
   assert.equal(interrupted.claude.totalCostUsd,before.claude.totalCostUsd);
   proof.brokerLoss.interrupted=interrupted;
   await capture('broker-disconnected',false);
   await save();
   await page.setViewportSize({width:1100,height:900});
   await openNative();
   const reopened=await context();
   activePid=reopened.native.state.nativePid;
   activeStart=await processStart(activePid);
   proof.owners.push({pid:activePid,processStart:activeStart});
   assert.ok(activeStart&&activePid!==proof.pid);
   const freshBroker=await findOwnedBroker(activePid);
   assert.equal(freshBroker.socket,broker.socket);
   assert.notDeepEqual(freshBroker,broker);
   assert.equal(reopened.native.state.sessionId,proof.sessionId);
   assert.notEqual(reopened.native.state.ownerId,before.native.state.ownerId);
   proof.brokerLoss.freshBroker=freshBroker;
   await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
   await expect(composer).toHaveText(proof.draft);
   assert.deepEqual(await document(),proof.retained);
   await save();
  }else{
   const settledTurns = clarification ? 2 : 3;
   if(feedback)await questionFeedback({page,panel,output,expect,proof,save,context,document,questionFrame});
   else if (!clarification) await panel.getByRole('button',{name:'Reject question',exact:true}).click();
   await expect(panel).toBeHidden();
   await expect.poll(async()=>{const c=await context();return c.native?.state?.busy===false&&c.claude.turns===settledTurns&&c.native.state.session?.turns===settledTurns;},{timeout:15000}).toBe(true);
   await expect(composer).toHaveText(proof.draft);
   proof.afterRejectDocument=await document();
   assert.deepEqual(proof.afterRejectDocument,proof.retained);
   proof.rejected=await context();
   assert.equal(proof.rejected.claude.turns,settledTurns);
   assert.equal(proof.rejected.messages.filter(m=>m.sender==='user').length,2);
   assert.equal(proof.rejected.native.state.nativePid,proof.pid);
   assert.equal(await processStart(proof.pid),proof.processStart);
  }
  if(addressedReplay&&!brokerLoss&&!clarification){
   const notices=proof.rejected.messages.filter(m=>m.sender==='system'&&m.context?.claudeNativeInterruption);assert.equal(notices.length,1);const notice=notices[0],row=page.locator('[data-message-id="'+notice.id+'"]');
   proof.noticeAppearance={id:notice.id,uuid:notice.context.cliUuid,text:notice.text,captures:[],layouts:[]};
   for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await page.evaluate(()=>document.fonts.ready.then(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))));await row.scrollIntoViewIfNeeded();await expect(row).toBeVisible();await expect(row).toBeInViewport({ratio:1});await expect(row).toHaveText(notice.text,{useInnerText:true});assert.deepEqual(await document(),proof.retained);proof.noticeAppearance.layouts.push({size,text:await row.innerText(),box:await row.boundingBox(),document:await document()});const name='main-question-interruption-'+size+'.png';await page.screenshot({path:join(output,name),animations:'disabled'});proof.noticeAppearance.captures.push(name);await save();}
  }
  proof.freshPrompt='Ask me which release audience to target after recovering the question.';await replace(proof.freshPrompt);await send.click();await expect.poll(()=>model.waiting,{timeout:15000}).toBe('AskUserQuestion');await replace(proof.draft);model.releaseQuestion();await expect(panel).toBeVisible();proof.fresh=await questionFrame();assert.notEqual(proof.fresh.messageId,proof.old.messageId);
  if(brokerLoss){
   assert.notEqual(proof.fresh.token,proof.old.token);
   assert.equal((await context()).native.state.nativePid,activePid);
  }
  if (clarification) {
   const stale = { type:'RESPOND_TO_BLOCK_INTERACTION', messageId:proof.fresh.messageId,
    response:{nativeQuestionAnswer:{},nativeQuestionDecision:'clarify',nativeQuestionRenderToken:proof.old.token,nativeQuestionDraftStarted:true,...(images?{nativeQuestionImages:[{mediaType:'image/png',data:createNativeTestImage().toString('base64')}]}:{})} };
   await app.sendEvent({type:'SEND_TO_SURFACE',surface:'default-setup/threads',events:[stale]});
   await expect(panel.getByRole('alert')).toBeVisible();
   assert.equal((await questionFrame()).token,proof.fresh.token);
   assert.equal(model.calls.some(call => call.messages?.some(message => Array.isArray(message.content) &&
     message.content.some(block => block.type === 'tool_result' && block.tool_use_id === 'native_question_recovery_fixture'))),false);
   proof.clarification.staleDrawingRefused = true;
   await save();
  }
  else {
   const oldEvent={type:'CLAUDE_UI_QUESTION_REJECT',threadId:proof.fresh.threadId,mountId:proof.fresh.mountId,messageId:proof.old.messageId,token:proof.old.token};if(addressedReplay){
    const c=await context(),view=c.ui[proof.fresh.mountId];assert.ok(view.state.actionKeys?.revision);const sequence=(view.actionKeyResult?.sequence??0)+100;
    const barrier={type:'CLAUDE_UI_KEY',threadId:proof.fresh.threadId,mountId:proof.fresh.mountId,sequence,revision:view.state.actionKeys.revision,event:{key:'F24',ctrl:false,alt:false,shift:false,super:false,from_composer:false}};
    proof.addressedReplay={delivery:'application SEND_TO_SURFACE with receiver scope',barrier};
    await app.sendEvent({type:'SEND_TO_SURFACE',surface:'default-setup/threads',events:[oldEvent,barrier]});
    await expect.poll(async()=>(await context()).ui[proof.fresh.mountId]?.actionKeyResult?.sequence,{timeout:15000}).toBe(sequence);proof.addressedReplay.acknowledged=await context();assert.equal(proof.addressedReplay.acknowledged.ui[proof.fresh.mountId].actionKeyResult.handled,false);assert.equal(!!(await questionFrame()).pending,false);
   }else await page.evaluate(event=>window.applicationState.system.get('default-setup/threads').send(event),oldEvent);await expect(panel).toBeVisible();assert.equal((await questionFrame()).token,proof.fresh.token);proof.addressedOldRejection=oldEvent;proof.replayQualification=addressedReplay?'Retired question rejection delivered through scoped surface route, followed by acknowledged unbound F24 on the same backend mount; current question remains unchanged. Backend stale refusal, not invocation of a retired native callback.':'An addressed old event was emitted and the fresh question survived. No backend/native receipt proves its delivery, so do not count this as direct stale-native refusal acceptance.';
  }
  await capture('fresh',true);
  let freshImage;
  if (images) {
   await panel.getByRole('button',{name:'Write your own answer',exact:true}).click();
   freshImage=await pickQuestionImage(panel,expect,'Release-chart.png',[45,110,230,255]);
   proof.questionImages.fresh=sha(freshImage);
  }
  await panel.getByRole('radio',{name:'Developers People integrating the updated behavior',exact:true}).check();
  await panel.getByRole('button',{name:'Submit answers',exact:true}).click();await expect(panel).toBeHidden();await expect.poll(()=>model.calls.some(call=>call.nativeQuestionResult!==undefined&&!call.nativeQuestionError&&JSON.stringify(call.nativeQuestionResult).includes('Developers')),{timeout:15000}).toBe(true);await expect(composer).toHaveText(proof.draft);proof.afterFreshDocument=await document();assert.deepEqual(proof.afterFreshDocument,proof.retained);await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:15000}).toBe(false);
  if (freshImage) {
   const delivered=model.calls.find(call=>call.messages?.some(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='tool_result'&&block.tool_use_id==='native_question_recovery_fixture')));
   proof.questionImages.submitted=questionImageAfterResult(delivered,'native_question_recovery_fixture');
   assert.equal(proof.questionImages.submitted,sha(freshImage));
   const state=await context();
   for (const id of [proof.old.messageId,proof.fresh.messageId]) {
    const row=state.messages.find(message=>message.id===id);
    assert.ok(row?.blockResponse);
    assert.equal(Object.hasOwn(row.blockResponse,'nativeQuestionImages'),false);
   }
   proof.questionImages.bytesKeptOutOfAppResponse=true;
  }
  const finalTurns=clarification?4:5;
  proof.followup='Continue the release summary with the confirmed audience.';await replace(proof.followup);await send.click();await expect.poll(async()=>{const c=await context();return c.claude?.chatState==='success'&&c.native?.state?.busy===false&&(brokerLoss?c.claude.turns===c.native.state.session?.turns:c.claude.turns===finalTurns&&c.native.state.session?.turns===finalTurns)&&c.messages.filter(m=>m.sender==='user'&&m.text===proof.followup).length===1&&c.claude.totalCostUsd===c.native.state.session.totalCostUsd;},{timeout:15000}).toBe(true);await replace('Ready for the next release-review step.');await expect(send).toBeEnabled();proof.final=await context();if(!brokerLoss)assert.equal(proof.final.claude.turns,finalTurns);assert.equal(proof.final.messages.filter(m=>m.sender==='user').length,4);assert.equal(proof.final.claude.sessionId,proof.sessionId);assert.equal(proof.final.native.state.nativePid,activePid);assert.equal(await processStart(activePid),activeStart);await capture('recovered',false);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processStart(activePid),{timeout:15000}).not.toBe(activeStart);proof.writerRetired=true;
  if(brokerLoss){
   const seen=model.calls.flatMap(call=>(call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]))
     .filter(block=>block.type==='tool_result'&&['native_question_fixture','native_question_recovery_fixture'].includes(block.tool_use_id));
   assert.ok(seen.some(block=>block.tool_use_id==='native_question_fixture'&&block.is_error===true));
   assert.ok(!seen.some(block=>block.tool_use_id==='native_question_fixture'&&block.is_error!==true));
   assert.ok(seen.some(block=>block.tool_use_id==='native_question_recovery_fixture'&&block.is_error!==true&&JSON.stringify(block.content).includes('Developers')));
  }
  if(proof.feedback)proof.feedback.status='complete';proof.status='complete';await save();phase('main-question-rejection-complete');
 }catch(error){
  proof.error={name:error.name,message:error.message};
  proof.observed=await context().catch(()=>null);
  await page.screenshot({path:join(output,'main-question-rejection-failure.png')}).catch(()=>{});
  if(brokerLoss&&activeStart&&await processStart(activePid)===activeStart){
   try{
    const open=section.getByRole('button',{name:'Use native interface',exact:true});
    if(await open.isVisible())await open.click({timeout:3000});
    await section.getByRole('button',{name:'Stop session',exact:true}).click({timeout:3000});
    await expect.poll(()=>processStart(activePid),{timeout:15000}).not.toBe(activeStart);
    proof.writerRetired=true;
   }catch(cleanup){proof.cleanupError=cleanup.message;}
  }
  throw error;
 }finally{await save()}
}

/** Hold only this verified native owner to exercise the existing five-second RPC timeout. */
async function questionFeedback({page,panel,output,expect,proof,save,context,document,questionFrame}){
 const pid=proof.pid,start=proof.processStart;
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv'));assert.ok(Number.isSafeInteger(pid)&&pid>1);assert.equal(await processStart(pid),start);
 const state=async()=>{const raw=await readFile('/proc/'+pid+'/stat','utf8');return raw.slice(raw.lastIndexOf(')')+2).split(' ')[0]};
 const reject=panel.getByRole('button',{name:'Reject question',exact:true});
 const observed=proof.feedback={status:'running',captures:[],deliveryQualification:'A timed-out request may have been applied before acknowledgement was lost. No cancellation or exactly-once transport claim; original journal effects remain independently verified.'};
 const capture=async(tag)=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect(panel).toBeInViewport({ratio:1});await expect(reject).toBeInViewport({ratio:1});if(tag==='pending')await expect(panel.getByRole('status')).toHaveText('Waiting for Claude…');if(tag==='error'){await expect(panel.getByRole('alert')).toBeInViewport({ratio:1});if(size==='normal'){const banner=page.getByText('Claude has not responded yet. You can retry or open the native interface.',{exact:true});await expect(banner).toBeVisible();observed.error.sessionProblemText=(await banner.textContent()).trim();}}const name='main-question-feedback-'+tag+'-'+size+'.png';await page.screenshot({path:join(output,name),animations:'disabled'});observed.captures.push(name);await save()}};
 await page.setViewportSize({width:1100,height:900});await expect(reject).toBeEnabled();observed.before=await questionFrame();
 let held=false;
 try{
  process.kill(pid,'SIGSTOP');held=true;await expect.poll(state,{timeout:2000}).toBe('T');observed.stopped={pid,processStart:await processStart(pid),state:await state()};
  await reject.click();await expect.poll(async()=>(await questionFrame()).pending,{timeout:2000}).toBe(true);
  observed.pending={frame:await questionFrame(),document:await document(),disabled:await panel.getByRole('button').evaluateAll(nodes=>nodes.map(node=>node.disabled)),statusText:await panel.getByRole('status').textContent(),ariaBusy:await panel.getByRole('group',{name:'Question details',exact:true}).getAttribute('aria-busy')};
  assert.ok(observed.pending.disabled.length&&observed.pending.disabled.every(Boolean));assert.deepEqual(observed.pending.document,proof.retained);
  await capture('pending');await expect(panel.getByRole('alert')).toHaveText('Claude has not confirmed your decision. Try again when it responds.',{timeout:10000});await expect(reject).toBeEnabled();
  observed.error={frame:await questionFrame(),document:await document(),text:await panel.getByRole('alert').textContent(),rejectEnabled:await reject.isEnabled(),ariaBusy:await panel.getByRole('group',{name:'Question details',exact:true}).getAttribute('aria-busy')};
  assert.deepEqual(observed.error.document,proof.retained);assert.equal(observed.error.frame.pending,false);await capture('error');
 }finally{if(held&&await processStart(pid)===start){process.kill(pid,'SIGCONT');observed.continueSent=true;await save()}}
 await expect.poll(state,{timeout:2000}).not.toBe('T');observed.resumed={pid,processStart:await processStart(pid),state:await state()};assert.equal(observed.resumed.processStart,start);
 try{await panel.waitFor({state:'hidden',timeout:5000});observed.retryRequired=false}catch(error){if(error.name!=='TimeoutError')throw error;await expect(reject).toBeEnabled();observed.retryRequired=true;observed.retryFrame=await questionFrame();await reject.click()}
 observed.recovered=await context();await save();
}


async function pasteQuestionImage(electronApp,panel,expect) {
 const bytes=createNativeTestImage([35,155,230,255]);
 await electronApp.evaluate(async({clipboard,nativeImage,ClipboardItem},source)=>{
  const data=nativeImage.createFromBuffer(Buffer.from(source));
  if(data.isEmpty())throw Error('Question PNG did not decode');
  await clipboard.write([new ClipboardItem({'image/png':new Blob([Uint8Array.from(data.toPNG())],{type:'image/png'})})]);
 },[...bytes]);
 try{
  await panel.getByRole('button',{name:'Write your own answer',exact:true}).click();
  const answer=panel.getByRole('textbox',{name:'Your answer',exact:true});
  await expect(answer).toBeFocused();
  await answer.press('Control+v');
  const image=panel.getByRole('list',{name:'Question images'}).locator('img');
  await expect(image).toHaveCount(1);
  const src=await image.getAttribute('src');
  assert.ok(src?.startsWith('data:image/png;base64,'));
  return Buffer.from(src.split(',')[1],'base64');
 }finally{await electronApp.evaluate(({clipboard})=>clipboard.clear());}
}
async function pickQuestionImage(panel,expect,name,rgba){
 const buffer=createNativeTestImage(rgba);
 await panel.getByLabel('Attach image',{exact:true}).setInputFiles({name,mimeType:'image/png',buffer});
 await expect(panel.getByRole('button',{name:'Remove '+name,exact:true})).toBeVisible();
 return buffer;
}
function questionImageAfterResult(call,id){
 for(const message of call?.messages??[]){
  if(!Array.isArray(message.content))continue;
  const index=message.content.findIndex(block=>block.type==='tool_result'&&block.tool_use_id===id);
  if(index<0)continue;
  const media=message.content[index+1];
  assert.equal(media?.type,'image');
  assert.equal(media.source.media_type,'image/png');
  assert.equal(message.content.slice(index+2).some(block=>block.type==='image'),false);
  return sha(Buffer.from(media.source.data,'base64'));
 }
 throw Error('Question result was not sent to the provider');
}


async function checkQuestionImageEdges({panel,page,expect,proof,output}){
 await panel.getByRole('button',{name:'Write your own answer',exact:true}).click();
 const picker=panel.getByLabel('Attach image',{exact:true}), previews=panel.getByRole('list',{name:'Question images'});
 const limits='Use up to four images totaling at most 10 MB.';
 const cases=[['release-cover.jpg','image/jpeg'],['release-motion.gif','image/gif'],['release-cover.webp','image/webp']];
 const files=await Promise.all(cases.map(async([name,mimeType])=>({name,mimeType,
  buffer:await readFile(new URL('../../fixtures/native-read-image-formats/'+name,import.meta.url))})));
 files.push({name:'Wide-release-chart.png',mimeType:'image/png',buffer:createNativeTestImage([27,115,220,255],{width:2500,height:32})});
 await picker.setInputFiles({name:'Release-notes.pdf',mimeType:'application/pdf',buffer:Buffer.from('%PDF-')});
 await expect(panel.getByText('Choose a PNG, JPEG, GIF, or WebP image.',{exact:true})).toBeVisible();
 await expect(previews).toHaveCount(0);
 const large=Buffer.concat([files[3].buffer,Buffer.alloc(6*1024*1024)]);
 await picker.setInputFiles([{name:'Limit-one.png',mimeType:'image/png',buffer:large},{name:'Limit-two.png',mimeType:'image/png',buffer:large}]);
 await expect(panel.getByText(limits,{exact:true})).toBeVisible();
 await expect(previews).toHaveCount(0);
 await picker.setInputFiles(files);
 await expect(previews.locator('img')).toHaveCount(4);
 await picker.setInputFiles({name:'Fifth-image.png',mimeType:'image/png',buffer:createNativeTestImage()});
 await expect(panel.getByText(limits,{exact:true})).toBeVisible();
 await expect(previews.locator('img')).toHaveCount(4);
 proof.imageEdges={invalidTypeRejected:true,aggregateByteLimitRejected:true,fifthRejected:true,
  input:files.map(file=>({name:file.name,mediaType:file.mimeType,sha256:sha(file.buffer)}))};
 for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
  await page.setViewportSize(viewport);
  await previews.scrollIntoViewIfNeeded();
  await expect(previews).toBeInViewport({ratio:1});
  await expect(panel.getByRole('button',{name:'Chat about this',exact:true})).toBeInViewport({ratio:1});
  const filename='question-image-formats-'+size+'.png';
  await page.screenshot({path:join(output,filename),animations:'disabled'});
  proof.captures.push(filename);
 }
 await page.setViewportSize({width:1100,height:900});
 return files;
}


async function recoverInvalidQuestionImage({panel,page,expect,proof,output,model,questionFrame,context}){
 const answer='Developers migrating this release.';
 const badName='Broken-release-chart.png';
 const goodName='Release-chart.png';
 // The signature is intact, but there is no IHDR or other usable dimension information.
 const badImage=Buffer.from('89504e470d0a1a0a','hex');
 const goodImage=createNativeTestImage([55,116,214,255]);
 const outcome=proof.invalidImageRecovery={answer,badSha256:sha(badImage),goodSha256:sha(goodImage)};
 await panel.getByRole('button',{name:'Write your own answer',exact:true}).click();
 const field=panel.getByRole('textbox',{name:'Your answer',exact:true});
 await field.fill(answer);
 const picker=panel.getByLabel('Attach image',{exact:true});
 await picker.setInputFiles([
  {name:badName,mimeType:'image/png',buffer:badImage},
  {name:goodName,mimeType:'image/png',buffer:goodImage},
 ]);
 const removeBad=panel.getByRole('button',{name:'Remove '+badName,exact:true});
 const removeGood=panel.getByRole('button',{name:'Remove '+goodName,exact:true});
 const submit=panel.getByRole('button',{name:'Submit answers',exact:true});
 await expect(removeBad).toBeVisible();
 await expect(removeGood).toBeVisible();
 const first=await questionFrame();
 await submit.click();
 const alert=panel.getByRole('alert');
 const refusal='Claude Code could not prepare an attached image. Remove it or replace it, then submit again.';
 await expect(alert).toHaveText(refusal,{timeout:15000});
 await expect(submit).toBeEnabled();
 const held=await questionFrame();
 assert.equal(held.token,first.token);
 assert.equal(held.messageId,first.messageId);
 const problem=(await context()).claude.pendingControlRequest.nativeTerminal.problem;
 assert.equal(problem,refusal);
 assert.ok(!held.pending);
 await expect(field).toHaveValue(answer);
 await expect(removeBad).toHaveCount(1);
 await expect(removeGood).toHaveCount(1);
 const result=()=>model.calls.find(call=>call.messages?.some(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='tool_result'&&block.tool_use_id==='native_question_fixture')));
 assert.equal(result(),undefined);
 outcome.refusal={problem,messageId:held.messageId,token:held.token,providerResult:false};
 await capture('refusal',alert);

 await removeBad.click();
 await expect(removeBad).toHaveCount(0);
 await expect(removeGood).toHaveCount(1);
 await expect(field).toHaveValue(answer);
 await capture('replacement',removeGood);
 await submit.click();
 await expect(panel).toBeHidden({timeout:15000});
 await expect.poll(result,{timeout:15000}).toBeTruthy();
 const block=result().messages.flatMap(message=>Array.isArray(message.content)?message.content:[])
  .find(item=>item.type==='tool_result'&&item.tool_use_id==='native_question_fixture');
 assert.notEqual(block.is_error,true);
 assert.ok(JSON.stringify(block.content).includes(answer));
 outcome.deliveredSha256=questionImageAfterResult(result(),'native_question_fixture');
 assert.equal(outcome.deliveredSha256,outcome.goodSha256);
 outcome.toolResult=block;
 return outcome;

 async function capture(stage, control){
  for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(viewport);
   await control.scrollIntoViewIfNeeded();
   await expect(control).toBeInViewport({ratio:1});
   await expect(submit).toBeInViewport({ratio:1});
   const file='invalid-question-image-'+stage+'-'+size+'.png';
   await page.screenshot({path:join(output,file),animations:'disabled'});
   proof.captures.push(file);
  }
 }
}
