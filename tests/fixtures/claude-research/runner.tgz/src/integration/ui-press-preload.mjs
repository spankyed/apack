import assert from 'node:assert/strict';
import {appendFileSync,readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {observeUiPress} from './ui-press-observer.mjs';
if(!process.versions.electron&&process.argv[1]?.endsWith('/server.js')){
 const directory=process.env.CLAUDE_RESEARCH_UI_PRESS_TRACE;
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.match(directory,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+\/ui-press$/);
 const boundary=JSON.parse(readFileSync('/control/offline-verified','utf8'));
 assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
 observeUiPress({record:row=>appendFileSync(join(directory,'press-'+process.pid+'.jsonl'),JSON.stringify(row)+'\n',{mode:0o600})});
 writeFileSync(join(directory,'ready-'+process.pid+'.json'),JSON.stringify({pid:process.pid,entry:process.argv[1],maxRequests:8,maxBytes:16384,scope:'Node HTTP native press request/response emission; no additional response data listeners'})+'\n',{mode:0o600,flag:'wx'});
}
