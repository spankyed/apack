import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';

/** The existing shared billing journey, through the common fresh-profile launcher. */
export async function driveAgentBilling(options){
 const {verifyAgentBilling,AGENT_BILLING_JOURNEY_TIMEOUT_MS}=await import(pathToFileURL(join(options.checkout,'tests/fixtures/claude-research/agent-billing-journey.ts')).href);
 return driveFreshNativeApp({...options,route:'real-Electron-shared-agent-billing-journey',journeyBudgetMs:AGENT_BILLING_JOURNEY_TIMEOUT_MS,journey:({app,page,electronApp,output})=>verifyAgentBilling({app,appPage:page,electronApp},{outputPath:(...parts)=>join(output,...parts)},{workspace:options.workspace,project:options.env.CLAUDE_RESEARCH_PROJECT,launcher:options.env.CLAUDE_RESEARCH_LAUNCHER,onboarding:options.env.CLAUDE_RESEARCH_ONBOARDING})});
}
