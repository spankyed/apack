import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs';
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs';
import { EFFORT_EVAL_ROUTE } from '../protocol/native-effort-rollout.mjs';
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs';
import { setTimeout as delay } from 'node:timers/promises';
import { idleSummary, startIdleCompactionModel, warmPrompt } from '../protocol/native-idle-compaction-model.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { readCombinedEverydayJournal } from './apack-combined-everyday-drive.mjs';
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs';
import { processStart } from './native-process-state.mjs';
import { observeResumedCompactionHistory } from './native-resumed-compaction-history.mjs';
import { observeAutoCompactWindow } from './native-autocompact-window.mjs';

const seed = 'Prepare the project release checklist.';
const nextPrompt = 'Continue with the same release checklist.';
const reply = 'The release checklist is ready.';
const idleNoticePrefix = 'Compacted while idle, before the prompt cache expired';
const returnNoticePrefix = 'Compacted after an hour idle, using a summary written while you were away';
const cacheLifetimeMs = 60 * 60 * 1000;
const cacheHalfLifeMs = cacheLifetimeMs / 2;
const draft = 'Keep these release notes while I review compaction settings.';

export async function driveIdleCompactionSettings({ checkout, workspace, env, observeTimer = false,
  manualCompaction = false, compactOnReturn = false, resumedHistory = false, autoCompactWindow = false }) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly && boundary.requireIdleCompactionSettings);
  assert.equal(typeof observeTimer, 'boolean');
  assert.equal(observeTimer, boundary.observeIdleCompactionTimer === true);
  assert.equal(manualCompaction, boundary.requireManualCompactionTranscript === true);
  assert.equal(compactOnReturn, boundary.requireCompactOnReturn === true);
  assert.equal(resumedHistory, boundary.requireResumedCompactionHistory === true);
  const expectedWindowJourney = boundary.requireAutoCompactWindow === true ? boundary.autoCompactWindowJourney ?? true : false;
  assert.equal(autoCompactWindow, expectedWindowJourney);
  assert.ok([false, true, 'typed', 'environment', 'capped-model'].includes(autoCompactWindow));
  assert.ok(!autoCompactWindow || (!observeTimer && !manualCompaction && !resumedHistory));
  assert.ok(!resumedHistory || manualCompaction);
  assert.ok(!compactOnReturn || observeTimer);
  assert.ok(!observeTimer || !manualCompaction);
  const project = join(workspace, 'project');
  const output = join(workspace, 'electron-results');
  await mkdir(project);
  await mkdir(output);
  execFileSync('/usr/bin/git', ['init', '--quiet', project], {
    env: { PATH: '/usr/bin:/bin', HOME: workspace, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_NOSYSTEM: '1' },
    timeout: 5000,
  });
  const account = await configureNativeCreditAccount(workspace, 'oauth', { featureCache: 'native-defaults' });
  const configDir = join(workspace, '.claude');
  const configPath = join(configDir, '.claude.json');
  const settingsPath = join(configDir, 'settings.json');
  const config = JSON.parse(await readFile(configPath, 'utf8'));
  assert.equal(config.cachedGrowthBookFeatures, undefined);
  assert.equal(config.growthBookOverrides, undefined);
  const baselineConfig = { ...config, hasCompletedOnboarding: true };
  const originalConfig = JSON.stringify(baselineConfig);
  const cappedModel = autoCompactWindow === 'capped-model';
  const environmentWindow = autoCompactWindow === 'environment' ? 300000 : undefined;
  const recommendationModel = cappedModel ? 'claude-haiku-4-5' : 'claude-sonnet-5-5';
  const recommendedWindow = cappedModel ? 200000 : 400000;
  const comparisonConfig = autoCompactWindow ? {
    ...baselineConfig,
    autoCompactWindowsCache: { [recommendationModel]: recommendedWindow },
  } : baselineConfig;
  const initialSettings = {
    theme: 'dark',
    model: cappedModel ? 'claude-haiku-4-5-20251001' : 'sonnet',
    ...(environmentWindow ? { modelSettings: { [recommendationModel]: { autoCompactWindow: 600000 } } } : {}),
  };
  await writeFile(configPath, JSON.stringify(comparisonConfig));
  await writeFile(settingsPath, JSON.stringify(initialSettings));
  const proof = { status: 'running', captures: [], changes: [], manualCompaction, compactOnReturn };
  const save = () => writeFile(join(output, 'idle-compaction-settings.json'), JSON.stringify(proof, null, 2));
  let model, provider;
  try {
    model = observeTimer || manualCompaction ? await startIdleCompactionModel() : await startSyntheticModel(workspace, 'TextOnly', { captureMessages: true, textReply: reply, maxRequests: 8 });
    const tls = await prepareNativeCreditTls(join(workspace, 'account-tls'));
    provider = await startNativeCreditBilling(tls, {
      idleCompactionRollout: true, idleCompactionTimer: observeTimer,
      idleCompactionMode: compactOnReturn ? 'compact_on_return' : 'compact', evidencePath: join(output, 'provider.json'),
    });
    const launchEnv = { ...env, ...account, NODE_EXTRA_CA_CERTS: tls.ca, ANTHROPIC_BASE_URL: model.url,
      DISABLE_AUTOUPDATER: '1', PATH: '/frozen-claude:' + env.PATH, CLAUDE_RESEARCH_PROJECT: project };
    delete launchEnv.ANTHROPIC_API_KEY;
    if (autoCompactWindow) delete launchEnv.CLAUDE_CODE_AUTO_COMPACT_WINDOW;
    if (environmentWindow) launchEnv.CLAUDE_CODE_AUTO_COMPACT_WINDOW = String(environmentWindow);
    const route = autoCompactWindow ? 'real-Electron-autocompact-window' : resumedHistory ? 'real-Electron-resumed-compaction-history' : compactOnReturn ? 'real-Electron-idle-compaction-on-return'
      : observeTimer ? 'real-Electron-idle-compaction-timer'
      : manualCompaction ? 'real-Electron-manual-compaction-transcript' : 'real-Electron-idle-compaction-settings';
    const journeyBudgetMs = observeTimer ? (compactOnReturn ? 3_820_000 : 2_020_000) : 145_000;
    await driveFreshNativeApp({ checkout, workspace, env: launchEnv, route, journeyBudgetMs, journey: async args => {
        try {
          await exerciseSettings({ ...args, proof, provider, model, configDir, settingsPath, initialSettings,
            observeTimer, manualCompaction, compactOnReturn, resumedHistory, autoCompactWindow, recommendedWindow });
        } catch (error) {
          proof.status = 'failed';
          proof.error = error.message;
          await save();
          if (proof.owner && await processStart(proof.owner.nativePid) === proof.processStart) {
            try {
              await stopNativeOwner(args.page, args.expect, proof);
            } catch (cleanup) {
              proof.cleanupError = cleanup.message;
            }
          }
          throw error;
        }
      } });
  } finally {
    await model?.close();
    await provider?.close();
    await writeFile(join(output, 'model-calls.json'), JSON.stringify(model?.calls ?? [], null, 2));
    if (proof.owner) assert.notEqual(await processStart(proof.owner.nativePid), proof.processStart);
    await writeFile(configPath, originalConfig);
    await writeFile(settingsPath, JSON.stringify(initialSettings));
    assert.equal(await readFile(configPath, 'utf8'), originalConfig);
    assert.deepEqual(JSON.parse(await readFile(settingsPath, 'utf8')), initialSettings);
    proof.restored = true;
    await save();
  }
}

async function exerciseSettings({ app, page, electronApp, expect, output, project, userDataDir, phase,
  proof, provider, model, configDir, settingsPath, initialSettings, observeTimer, manualCompaction, compactOnReturn, resumedHistory, autoCompactWindow, recommendedWindow }) {
  const context = () => page.evaluate(() => {
    const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    return { claude: c.currentThread?.context?.claudeCode, messages: c.currentThread?.messages ?? [],
      native: Object.values(c.nativeTerminalViews).find(view => view.threadId === c.currentThread?.id)?.state };
  });
  const card = page.locator('[data-onboarding-id="agent-chat-input"]');
  const composer = card.locator('[contenteditable="true"]');
  const send = card.getByRole('button', { name: 'Send', exact: true });
  const section = page.getByRole('region', { name: 'Claude native interface', exact: true });
  const panel = page.getByRole('dialog', { name: 'Claude Code settings', exact: true });
  const toggle = panel.getByRole('checkbox', { name: 'Idle compaction', exact: true });
  const noticePrefix = compactOnReturn ? returnNoticePrefix : idleNoticePrefix;
  const settings = async () => JSON.parse(await readFile(settingsPath, 'utf8'));
  const inference = () => model.calls.filter(call => Array.isArray(call.toolNames) && call.path.split('?')[0] === '/v1/messages');
  const replyAfter = async text => {
    const { messages } = await context();
    const index = messages.findLastIndex(row => row.sender === 'user' && row.text === text);
    return index !== -1 && messages.slice(index + 1).some(row => row.sender === 'assistant' && row.text === reply);
  };

  await app.waitForSurface('default-setup/threads');
  await app.navigate('host/settings');
  await page.evaluate(() => {
    const host = window.applicationState.system.get('host/settings');
    host.send({ type: 'TAB.SELECT', tab: 'general' });
    host.send({ type: 'GENERAL_NAV.SELECT', item: 'secrets' });
  });
  await page.getByText('Claude Code CLI', { exact: true }).locator('..').locator('..').locator('..')
    .getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');
  await page.waitForTimeout(700);
  await app.navigate('default-setup/threads');
  await expect.poll(() => page.evaluate(() => {
    const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    return !!c.currentThread?.id && c.tabs.every(tab => c.tabsRead.includes(tab.id));
  }), { timeout: 15000 }).toBe(true);
  await page.evaluate(directory => {
    const threads = window.applicationState.system.get('default-setup/threads');
    threads.send({ type: 'NEW_THREAD_IN_PROJECT', directory });
    threads.send({ type: 'SET_MODE', mode: 'Claude Code' });
    threads.send({ type: 'SET_PHASE', phase: 'Edit' });
  }, project);
  await composer.fill(seed);
  await send.click();
  await expect.poll(() => replyAfter(seed), { timeout: 30000 }).toBe(true);
  proof.sessionId = (await context()).claude.sessionId;
  const openNative = async () => {
    await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
    const lastSent = new Map();
    const terminal = section.locator('[data-terminal-text]').first();
    for (let attempt = 0; attempt < 120 && (await context()).native?.status !== 'live'; attempt++) {
      const screen = await terminal.textContent({ timeout: 1000 }).catch(() => '');
      const onboarding = recognizeOnboardingPrompt(screen ?? '', project);
      if (onboarding && Date.now() - (lastSent.get(onboarding) ?? 0) >= 1000) {
        const input = section.locator('[aria-label="Terminal input"]');
        await electronApp.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0]?.focus());
        await input.focus();
        if (onboarding.startsWith('workspace-trust')) await page.waitForTimeout(200);
        await input.press(onboarding === 'workspace-trust' ? 'ArrowDown' : 'Enter');
        lastSent.set(onboarding, Date.now());
      }
      await page.waitForTimeout(100);
    }
    await expect.poll(async () => (await context()).native?.status, { timeout: 25000 }).toBe('live');
  };
  await openNative();
  ({ native: proof.owner } = await context());
  proof.processStart = await processStart(proof.owner.nativePid);
  assert.ok(proof.processStart);
  assert.equal(proof.owner.sessionId, proof.sessionId);
  await section.getByRole('button', { name: 'Back to conversation', exact: true }).click();
  await expect.poll(() => provider.state.requests.some(row => row.path === EFFORT_EVAL_ROUTE && row.status === 200),
    { timeout: 12000 }).toBe(true);
  phase('native-idle-compaction-cohort-served');
  if (autoCompactWindow) {
    proof.window = {};
    const inferenceBefore = inference().length;
    await observeAutoCompactWindow({ page, expect, context, composer, send, settings, output, proof, recommendedWindow,
      variant: autoCompactWindow });
    assert.equal(inference().length, inferenceBefore);
    proof.window.inferenceUnchanged = true;
    await stopNativeOwner(page, expect, proof);
    proof.nativeRetired = true;
    proof.status = 'complete';
    phase('native-autocompact-window-observed');
    return;
  }

  const open = async () => {
    const direct = card.getByRole('button', { name: 'Claude settings', exact: true });
    if (await direct.isVisible()) await direct.click();
    else {
      await card.getByRole('button', { name: 'More actions', exact: true }).click();
      await page.getByRole('menuitem', { name: 'Claude settings', exact: true }).click();
    }
    await expect(panel).toBeVisible();
    await panel.getByRole('textbox', { name: 'Search Claude Code settings', exact: true }).fill('Idle compaction');
    await expect(toggle).toBeVisible({ timeout: 15000 });
    await expect(toggle).toBeEnabled();
  };
  const close = async () => {
    await panel.getByRole('button', { name: 'Close settings', exact: true }).click();
    await expect(panel).toBeHidden();
    await expect(composer).toHaveText(draft);
  };
  await composer.fill(draft);
  const inferenceBefore = inference().length;
  assert.ok(inferenceBefore >= 1);
  await open();
  await expect(toggle).toBeChecked();
  assert.deepEqual(await settings(), initialSettings);

  for (const { value, size, viewport } of observeTimer || manualCompaction ? [] : [
    { value: false, size: 'normal', viewport: { width: 1100, height: 900 } },
    { value: true, size: 'compact', viewport: { width: 680, height: 600 } },
  ]) {
    await page.setViewportSize(viewport);
    await toggle.press('Space');
    await expect.poll(async () => (await settings()).idleCompaction).toBe(value);
    await expect(toggle).toBeChecked({ checked: value });
    await expect(panel.getByRole('status')).toHaveText('Saved by Claude Code');
    const capture = 'idle-compaction-' + size + '.png';
    await expect(toggle).toBeInViewport({ ratio: 1 });
    await page.screenshot({ path: join(output, capture), animations: 'disabled' });
    proof.captures.push(capture);
    await close();
    await open();
    await expect(toggle).toBeChecked({ checked: value });
    const persisted = await settings();
    assert.deepEqual(persisted, { ...initialSettings, idleCompaction: value });
    proof.changes.push({ value, reopened: true, persisted });
  }
  await close();
  proof.inferenceBefore = inferenceBefore;
  proof.inferenceAfterSettings = inference().length;
  assert.equal(proof.inferenceAfterSettings, inferenceBefore);
  phase(observeTimer || manualCompaction ? 'native-idle-compaction-enabled' : 'native-idle-compaction-toggle-persisted');
  if (observeTimer || manualCompaction) {
    await composer.fill(warmPrompt);
    await send.click();
    await expect.poll(async () => {
      assert.deepEqual(model.errors, []);
      return replyAfter(warmPrompt);
    }, { timeout: 30_000 }).toBe(true);
    const warm = model.calls.find(call => call.kind === 'warm');
    assert.ok(warm?.cacheTtls.includes('1h'));
    await expect.poll(async () => (await context()).native?.busy, { timeout: 15_000 }).toBe(false);
    await composer.fill(draft);
    proof.warmRequest = warm;
    if (manualCompaction) {
      await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
      const input = section.locator('[aria-label="Terminal input"]');
      await input.focus();
      await input.pressSequentially('/compact');
      await input.press('Enter');
      await expect.poll(() => model.calls.filter(call => call.kind === 'summary').length, { timeout: 25_000 }).toBe(1);
      await expect.poll(async () => (await context()).native?.busy, { timeout: 15_000 }).toBe(false);
      await section.getByRole('button', { name: 'Back to conversation', exact: true }).click();
      await expect(composer).toHaveText(draft);
      if (!resumedHistory) await verifyManualCompaction({ page, expect, context, output, proof, composer });
      else {
        await expect.poll(async () => (await context()).messages.filter(row => row.context?.claudeNativeCompaction).length).toBe(2);
        const [boundary, summary] = (await context()).messages.filter(row => row.context?.claudeNativeCompaction);
        proof.manualRows = { boundaryUuid: boundary.context.cliUuid, summaryUuid: summary.context.cliUuid };
      }
    }
  }
  if (observeTimer) {
    const warm = proof.warmRequest;
    phase('native-one-hour-cache-request-observed', { at: warm.at });
    console.log(JSON.stringify({ phase: 'native-one-hour-cache-request-observed', earliestFireAt: warm.at + cacheHalfLifeMs }));
    let compaction;
    while (!compaction && Date.now() - warm.at < cacheHalfLifeMs + 75_000) {
      assert.deepEqual(model.errors, []);
      assert.equal(await processStart(proof.owner.nativePid), proof.processStart);
      compaction = model.calls.find(call => call.kind === 'summary');
      if (!compaction) await delay(10_000);
    }
    assert.ok(compaction, 'No original idle compaction request within the one-hour cache scheduling window');
    assert.ok(compaction.at - warm.at >= cacheHalfLifeMs - 1_000);
    proof.compactionRequest = compaction;
    if (compactOnReturn) {
      const expiresAt = warm.at + cacheLifetimeMs;
      phase('native-idle-summary-precomputed', { at: compaction.at, expiresAt });
      // Leave room for the original cache-write response to settle after the warm request arrives.
      while (Date.now() < expiresAt + 5_000) {
        assert.deepEqual(model.errors, []);
        assert.equal(await processStart(proof.owner.nativePid), proof.processStart);
        await delay(Math.min(10_000, expiresAt + 5_000 - Date.now()));
      }
      const before = await readCombinedEverydayJournal(userDataDir, proof.sessionId, undefined, configDir);
      const rows = before.toString().trim().split('\n').filter(Boolean).map(JSON.parse);
      assert.equal(rows.some(row => row.subtype === 'compact_boundary' || row.isCompactSummary), false);
      await expect(composer).toHaveText(draft);
      proof.precomputedBeforeReturn = { expiresAt, checkedAt: Date.now(), journalRows: rows.length };
    } else {
      await captureIdleNotice({ page, expect, context, composer, output, proof, noticePrefix });
    }
  }
  await composer.focus();
  await composer.press('ControlOrMeta+a');
  await composer.press('Backspace');
  await expect(composer).toBeEmpty();
  await composer.pressSequentially(nextPrompt);
  await expect(composer).toHaveText(nextPrompt);
  if (compactOnReturn) proof.returnSubmittedAt = Date.now();
  await send.click();
  await expect.poll(() => replyAfter(nextPrompt), { timeout: 30000 }).toBe(true);
  if (compactOnReturn) {
    await composer.fill(draft);
    await captureIdleNotice({ page, expect, context, composer, output, proof, noticePrefix });
  }
  const finished = await context();
  assert.equal(finished.claude.sessionId, proof.sessionId);
  assert.equal(finished.native.ownerId, proof.owner.ownerId);
  assert.equal(await processStart(proof.owner.nativePid), proof.processStart);
  const journal = await readCombinedEverydayJournal(userDataDir, proof.sessionId, undefined, configDir);
  await writeFile(join(output, 'native-transcript.jsonl'), journal);
  const rows = journal.toString().trim().split('\n').filter(Boolean).map(JSON.parse);
  const human = rows.filter(row => row.type === 'user' && row.isCompactSummary !== true && ['sdk', 'human'].includes(row.turnOrigin));
  assert.deepEqual(human.map(row => row.message.content), observeTimer || manualCompaction ? [seed, warmPrompt, nextPrompt] : [seed, nextPrompt]);
  if (observeTimer) {
    assert.deepEqual(model.errors, []);
    const compact = rows.find(row => row.subtype === 'compact_boundary');
    const notice = rows.find(row => row.subtype === 'informational' && row.level === 'notice' && row.content?.startsWith(noticePrefix));
    const summary = rows.find(row => row.isCompactSummary && JSON.stringify(row.message).includes(idleSummary));
    assert.ok(compact && summary && notice && compact.sessionId === proof.sessionId && notice.sessionId === proof.sessionId);
    if (compactOnReturn) assert.equal(compact.compactMetadata.precomputed, true);
    assert.equal((await context()).messages.filter(row => row.sender === 'system' && row.context?.cliUuid === notice.uuid).length, 1);
    assert.equal(model.calls.filter(call => call.kind === 'summary').length, 1);
    assert.ok(model.calls.at(-1).receivedSummary);
    proof.nativeNotice = { uuid: notice.uuid, content: notice.content, compactUuid: compact.uuid, summaryUuid: summary.uuid };
  } else if (manualCompaction) {
    const compact = rows.find(row => row.uuid === proof.manualRows.boundaryUuid);
    const summary = rows.find(row => row.uuid === proof.manualRows.summaryUuid);
    assert.equal(compact?.subtype, 'compact_boundary');
    assert.equal(compact.compactMetadata.trigger, 'manual');
    assert.equal(compact.sessionId, proof.sessionId);
    assert.ok(summary?.isCompactSummary && JSON.stringify(summary.message).includes(idleSummary));
    assert.equal(summary.sessionId, proof.sessionId);
    assert.deepEqual(model.errors, []);
    assert.equal(model.calls.filter(call => call.kind === 'summary').length, 1);
    assert.ok(model.calls.at(-1).receivedSummary);
  } else {
    assert.equal(rows.some(row => row.subtype === 'compact_boundary'), false);
  }
  proof.continued = { sessionId: finished.claude.sessionId, ownerId: finished.native.ownerId,
    prompts: human.map(row => row.message.content) };
  if (resumedHistory) {
    await composer.fill(draft);
    await expect(composer).toHaveText(draft);
  }
  await stopNativeOwner(page, expect, proof);
  proof.nativeRetired = true;
  if (resumedHistory) {
    const previous = { pid: proof.owner.nativePid, start: proof.processStart, ownerId: proof.owner.ownerId };
    // The first process has stopped. Track the replacement immediately so failures still retire it.
    await page.setViewportSize({ width: 1100, height: 900 });
    const back = section.getByRole('button', { name: 'Back to conversation', exact: true });
    if (await back.isVisible()) await back.click();
    await expect(composer).toHaveText(draft);
    await openNative();
    ({ native: proof.owner } = await context());
    proof.processStart = await processStart(proof.owner.nativePid);
    assert.ok(proof.processStart && proof.owner.nativePid !== previous.pid && proof.owner.ownerId !== previous.ownerId);
    assert.equal(proof.owner.sessionId, proof.sessionId);
    proof.resumedHistory = { previous };
    try {
      await observeResumedCompactionHistory({ page, expect, context, section, output, proof, sources: rows,
        project, composer, retainedDraft: draft });
    } finally {
      await stopNativeOwner(page, expect, proof);
    }
    proof.resumedHistory.retired = true;
    proof.status = 'complete';
    phase('native-resumed-compaction-history-observed');
    return;
  }
  if (manualCompaction) {
    await page.reload();
    const { waitForAppReady } = await import('/work/packages/apack-testing/src/index.ts');
    await waitForAppReady(page);
    await app.waitForSurface('default-setup/threads');
    await app.navigate('default-setup/threads');
    const uuidList = [proof.manualRows.boundaryUuid, proof.manualRows.summaryUuid];
    const stored = async () => (await context()).messages.filter(row => uuidList.includes(row.context?.cliUuid));
    await expect.poll(async () => (await stored()).map(row => row.context.cliUuid), { timeout: 15_000 }).toEqual(uuidList);
    const [boundary, summary] = await stored();
    await expect(compactionMarker(page, boundary.id)).toBeVisible();
    const disclosure = page.locator('[data-message-id="' + summary.id + '"] details');
    await expect(disclosure.locator('summary')).toHaveText('Compact summary');
    await expect(disclosure.locator('p')).toBeHidden();
    const reopened = (await context()).claude;
    assert.equal(reopened.sessionId, proof.sessionId);
    assert.equal(reopened.turns, finished.claude.turns);
    assert.equal(reopened.totalCostUsd, finished.claude.totalCostUsd);
    proof.reopenedRenderer = { sessionId: reopened.sessionId, turns: reopened.turns, totalCostUsd: reopened.totalCostUsd };
  }
  proof.status = 'complete';
  phase('native-idle-compaction-settings-complete');
}

async function captureIdleNotice({ page, expect, context, composer, output, proof, noticePrefix }) {
  const mirroredNotices = async () => (await context()).messages.filter(row =>
    row.sender === 'system' && row.context?.claudeNativeNotice?.level === 'notice' && row.text?.startsWith(noticePrefix));
  await expect.poll(async () => (await mirroredNotices()).length, { timeout: 25_000 }).toBe(1);
  const [mirroredNotice] = await mirroredNotices();
  const notice = page.locator('[data-message-id="' + mirroredNotice.id + '"]')
    .getByText(new RegExp('^' + noticePrefix)).filter({ visible: true });
  await expect(notice).toHaveCount(1);
  for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
    await page.setViewportSize(viewport);
    await notice.scrollIntoViewIfNeeded();
    await expect(notice).toBeInViewport();
    await expect(composer).toHaveText(draft);
    const capture = 'idle-compaction-notice-' + size + '.png';
    await page.screenshot({ path: join(output, capture), animations: 'disabled' });
    proof.captures.push(capture);
  }
}

function compactionMarker(page, id) {
  return page.locator('[data-message-id="' + id + '"]')
    .getByText('Conversation compacted', { exact: true }).filter({ visible: true });
}

async function verifyManualCompaction({ page, expect, context, output, proof, composer }) {
  const rows = async () => (await context()).messages.filter(row => row.context?.claudeNativeCompaction);
  await expect.poll(async () => (await rows()).map(row => row.context.claudeNativeCompaction), { timeout: 25_000 })
    .toEqual(['boundary', 'summary']);
  const [boundary, summary] = await rows();
  assert.equal(boundary.sender, 'system');
  assert.equal(summary.sender, 'system');
  assert.ok(boundary.context.cliUuid !== summary.context.cliUuid);
  assert.equal(summary.context.claudeNativeUserMessage, undefined);
  proof.manualRows = { boundaryUuid: boundary.context.cliUuid, summaryUuid: summary.context.cliUuid };
  const marker = compactionMarker(page, boundary.id);
  const disclosure = page.locator('[data-message-id="' + summary.id + '"] details');
  const toggle = disclosure.locator('summary');
  const text = disclosure.locator('p');
  const transcript = page.getByTestId('chat-transcript');
  await expect(marker).toHaveCount(1);
  await expect(toggle).toHaveText('Compact summary');
  for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
    await page.setViewportSize(viewport);
    await expect(text).toBeHidden();
    await toggle.scrollIntoViewIfNeeded();
    await toggle.press('Enter');
    await expect(text).toContainText(idleSummary);
    await expect(toggle).toBeFocused();
    await transcript.hover();
    // An upward reader gesture releases the transcript's follow-latest mode before positioning the divider.
    await page.mouse.wheel(0, -1);
    const [viewportBox, markerBox] = await Promise.all([transcript.boundingBox(), marker.boundingBox()]);
    assert.ok(viewportBox && markerBox);
    await page.mouse.wheel(0, Math.round(markerBox.y - viewportBox.y - 12));
    await expect(marker).toBeInViewport();
    await expect(toggle).toBeInViewport();
    // At compact height the divider and disclosure can fill the transcript above the fixed composer.
    // Read into the expanded body using the same transcript scrollbar.
    if (size === 'compact') {
      const summaryLine = () => text.evaluate((element, excerpt) => {
        const node = element.firstChild;
        const start = node?.textContent?.indexOf(excerpt) ?? -1;
        if (start < 0) throw new Error('Saved summary line is missing');
        const range = document.createRange();
        range.setStart(node, start);
        range.setEnd(node, start + excerpt.length);
        const rect = range.getBoundingClientRect();
        return { top: rect.top, bottom: rect.bottom };
      }, idleSummary);
      const { top } = await summaryLine();
      await page.mouse.wheel(0, Math.round(top - viewportBox.y - 18));
      await expect.poll(async () => {
        const line = await summaryLine();
        return line.top >= viewportBox.y && line.bottom <= viewportBox.y + viewportBox.height - 32;
      }).toBe(true);
    }
    await expect(text).toBeInViewport();
    await expect(composer).toBeInViewport();
    const capture = 'main-compact-summary-' + size + '.png';
    await page.screenshot({ path: join(output, capture), animations: 'disabled' });
    proof.captures.push(capture);
    await toggle.press('Enter');
    await expect(text).toBeHidden();
    await marker.scrollIntoViewIfNeeded();
    await expect(marker).toBeInViewport();
  }
}

async function stopNativeOwner(page, expect, proof) {
  const section = page.getByRole('region', { name: 'Claude native interface', exact: true });
  const open = section.getByRole('button', { name: 'Use native interface', exact: true });
  if (await open.isVisible()) await open.click({ timeout: 4000 });
  await section.getByRole('button', { name: 'Stop session', exact: true }).click({ timeout: 4000 });
  await expect.poll(() => processStart(proof.owner.nativePid), { timeout: 15000 }).not.toBe(proof.processStart);
}
