import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Crash only the real app's API child; native worker, renderer and original helper remain untouched. */
export async function driveApiCaptionRestart({page,electronApp,expect,context,composer,send,card,widget,panel,input,proof,save,phase,model,statusProfile,birth,sameParent,childJournal,repliedTo,profileDir,output,requireAutomaticSelection=false}){
 const review=proof.apiCaptionRestart={status:'running',restarts:[],requireAutomaticSelection};
 proof.scope=requireAutomaticSelection
  ?'Automatic selected conversation recovery after an API restart with persisted completed onboarding.'
  :'App-owned original worker caption across two actual API crashes, no helper/model rerun, parent notes, fresh child reply and Stop.';
 if(requireAutomaticSelection)assert.ok(proof.completedOnboarding);
 const modelTurns=()=>model.calls.filter(call=>call.path.split('?')[0]==='/v1/messages').length;
 await page.evaluate(()=>{
  if(window.__claudeResearchApiReady)throw Error('API readiness observer already installed');
  const state={events:[],unsubscribe:null};state.unsubscribe=window.electronAPI.apiStatus.onEvent(event=>{if(state.events.length<32)state.events.push({at:Date.now(),...event});});window.__claudeResearchApiReady=state;
 });
 const rootPid=electronApp.process().pid;assert.ok(Number.isSafeInteger(rootPid)&&rootPid>1);review.appPid=rootPid;review.appStart=await birth(rootPid);
 const api=async()=>{
  const status=await page.evaluate(()=>window.electronAPI.apiStatus.getStatus());
  const children=(await readFile('/proc/'+rootPid+'/task/'+rootPid+'/children','utf8')).trim().split(/\s+/).filter(Boolean).map(Number),matches=[];
  for(const pid of children){try{const argv=(await readFile('/proc/'+pid+'/cmdline','utf8')).split('\0');if(!argv.some(a=>a==='dist/server.js'||a.endsWith('/dist/server.js')))continue;const cwd=await import('node:fs/promises').then(fs=>fs.readlink('/proc/'+pid+'/cwd'));if(cwd==='/work/packages/api')matches.push(pid);}catch(error){if(error.code!=='ENOENT'&&error.code!=='ESRCH')throw error;}}
  assert.ok(matches.length<=1,'Only one owned API child may match');return{...status,pid:matches[0]};
 };
 const workerHelpers=async()=>(await statusProfile.invocations()).filter(r=>r.ancestry.some(a=>a.pid===proof.worker.pid&&a.start===proof.workerStart)).map(r=>({pid:r.pid,start:r.start,entryMonotonicNs:r.entryMonotonicNs,cost:r.input.cost.total_cost_usd,stdout:r.stdout})).sort((a,b)=>a.entryMonotonicNs.localeCompare(b.entryMonotonicNs));
 const allHelpers=async()=>(await statusProfile.invocations()).map(r=>({pid:r.pid,start:r.start,entryMonotonicNs:r.entryMonotonicNs,sessionId:r.input.session_id,cost:r.input.cost.total_cost_usd,stdout:r.stdout})).sort((a,b)=>a.entryMonotonicNs.localeCompare(b.entryMonotonicNs));
 const history=async()=>{const raw=await childJournal();return raw.toString().split('\n').filter(Boolean).map(JSON.parse).filter(r=>['user','assistant'].includes(r.type)).map(r=>({type:r.type,uuid:r.uuid,message:r.message,origin:r.origin}));};
 const sameWorker=async()=>{assert.equal(await birth(rootPid),review.appStart);assert.equal(await birth(proof.worker.pid),proof.workerStart);const c=await sameParent();assert.equal(c.native.backgroundInfo.pid,proof.worker.pid);assert.equal(c.native.backgroundInfo.sessionId,proof.worker.sessionId);if(c.native.background){assert.equal(c.native.background.session.pid,proof.worker.pid);assert.equal(c.native.background.session.sessionId,proof.worker.sessionId);}return c};
 const capture=async stage=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);const controls=[widget.locator('[aria-label="Background Claude configured status"]'),widget.getByRole('button',{name:'Stop background session',exact:true}),composer];for(const c of controls)await c.evaluate(e=>e.scrollIntoView({block:'nearest',inline:'nearest',behavior:'instant'}));const layout=[];for(const c of controls){await expect(c).toBeInViewport({ratio:1});layout.push(await c.evaluate(e=>{const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return{x:r.x,y:r.y,width:r.width,height:r.height,reachable:!!hit&&(e===hit||e.contains(hit))}}));}assert.ok(layout.every(r=>r.reachable));await page.evaluate(()=>document.fonts.ready);const file='native-api-caption-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);proof.layouts.push({stage,size,layout});await save();}};
 if(process.env.CLAUDE_RESEARCH_REQUIRE_PREFIXED_RECOVERY==='1'){
  const initial=await sameWorker(),cost=initial.native.backgroundInfo.totalCostUsd;
  const text='Check the release review once more before reconnecting.';
  await widget.getByRole('button',{name:'Open session',exact:true}).click();await expect(panel).toBeVisible({timeout:15000});await expect(input).toBeFocused();await input.pressSequentially(text);await page.keyboard.press('Enter');
  await expect.poll(()=>repliedTo(text),{timeout:20000}).toBe(true);
  await expect.poll(async()=>{const info=(await context()).native?.backgroundInfo;return info?.totalCostUsd>cost&&info.statusLine==='Release review\nSession cost $'+info.totalCostUsd.toFixed(6)},{timeout:15000}).toBe(true);
  const ready=await sameWorker(),currentCost=ready.native.backgroundInfo.totalCostUsd;
  const prefixed=async()=>(await statusProfile.invocations()).filter(row=>row.input.session_id===proof.worker.sessionId&&row.input.cost.total_cost_usd===currentCost&&row.ancestry.findIndex(a=>a.pid===proof.worker.pid&&a.start===proof.workerStart)===3);
  await expect.poll(async()=>(await prefixed()).length,{timeout:10000}).toBeGreaterThan(0);
  const executions=await prefixed();review.prefixedRecovery={text,info:ready.native.backgroundInfo,executions:executions.map(row=>({pid:row.pid,start:row.start,entryMonotonicNs:row.entryMonotonicNs,ancestry:row.ancestry,stdout:row.stdout}))};
  await panel.getByRole('button',{name:'Close connection',exact:true}).click();await expect(panel).toBeHidden();await expect.poll(async()=>(await context()).native?.attachment,{timeout:15000}).toBeUndefined();
 }
 review.initial=await sameWorker();review.helpersBefore=await workerHelpers();review.allHelpersBefore=await allHelpers();assert.ok(review.helpersBefore.length);review.historyBefore=await history();review.modelBefore=modelTurns();await writeFile(join(output,'native-child-before-api-restart.jsonl'),await childJournal());await capture('before');
 for(let attempt=1;attempt<=(requireAutomaticSelection?1:2);attempt++){
  const selection=()=>page.evaluate(()=>{
   const app=window.applicationState.getSnapshot(),threads=window.applicationState.system.get('default-setup/threads').getSnapshot();
   return{surfaceId:app.context.activeSurface.id,onboarding:app.hasTag('onboarding'),activeTabId:threads.context.activeTabId};
  });
  const initialSelection=await selection();
  if(requireAutomaticSelection){
   assert.deepEqual(initialSelection,{surfaceId:'default-setup/threads',onboarding:false,activeTabId:review.initial.threadId});
  }
  const before=await api();assert.equal(before.running,true);assert.ok(Number.isSafeInteger(before.pid)&&before.pid>1&&!new Set([rootPid,proof.worker.pid,proof.pid]).has(before.pid));
  const raw=await readFile('/proc/'+before.pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');assert.equal(Number(fields[1]),rootPid,'Only this app main process may own the crashed API');const start=fields[19];assert.ok(start);
  const argv=(await readFile('/proc/'+before.pid+'/cmdline','utf8')).split('\0');assert.ok(argv.some(a=>a==='dist/server.js'||a.endsWith('/dist/server.js')));const cwd=await import('node:fs/promises').then(fs=>fs.readlink('/proc/'+before.pid+'/cwd'));assert.equal(cwd,'/work/packages/api');
  const record={attempt,before,start,...(requireAutomaticSelection&&{initialSelection}),parentPid:rootPid,signal:'SIGKILL',crashedAt:Date.now(),helperCount:review.helpersBefore.length,modelBefore:modelTurns(),requestsBefore:model.calls.length};review.restarts.push(record);await save();phase('owned-api-crash',{attempt,pid:before.pid});assert.equal(await birth(before.pid),start);process.kill(before.pid,'SIGKILL');
  // running means the process exists, not that the app's own API startup has completed.
  await expect.poll(()=>page.evaluate(({at,port})=>window.__claudeResearchApiReady.events.some(event=>event.type==='api:started'&&event.at>at&&event.port===port),{at:record.crashedAt,port:before.port}),{timeout:65000}).toBe(true);
  record.startedEvent=await page.evaluate(({at,port})=>window.__claudeResearchApiReady.events.find(event=>event.type==='api:started'&&event.at>at&&event.port===port),{at:record.crashedAt,port:before.port});
  await expect.poll(async()=>{const next=await api();return next.running&&Number.isSafeInteger(next.pid)&&next.pid!==before.pid&&next.port===before.port},{timeout:65000}).toBe(true);
  record.after=await api();assert.equal(record.after.startupId,before.startupId);assert.ok(record.after.restartAttempts>=before.restartAttempts);record.afterStart=await birth(record.after.pid);assert.ok(record.afterStart);await expect.poll(()=>birth(before.pid),{timeout:10000}).toBe(null);
  record.selectionAfterRestart=await context();
  if(!requireAutomaticSelection&&record.selectionAfterRestart.threadId!==review.initial.threadId){
   record.returnedThroughExistingTab=true;
   await page.locator('[data-tab-id="'+review.initial.threadId+'"]').first().click();
   await expect.poll(async()=>(await context()).threadId,{timeout:10000}).toBe(review.initial.threadId);
  }
  try{await expect.poll(async()=>{
   const c=await context().catch(()=>null);record.lastRecoveryContext=c;
   if(!requireAutomaticSelection&&c&&c.threadId!==review.initial.threadId){record.tabReturns=(record.tabReturns??0)+1;assert.ok(record.tabReturns<=2,'Repeated startup redirection must not be hidden');await page.locator('[data-tab-id="'+review.initial.threadId+'"]').first().click();return false;}
   if(requireAutomaticSelection){
    record.selection=await selection();
    if(record.selection.surfaceId!=='default-setup/threads'||record.selection.onboarding||
       record.selection.activeTabId!==review.initial.threadId||c?.threadId!==review.initial.threadId)return false;
   }
   const info=c?.native?.backgroundInfo;return info?.observedAt>record.crashedAt&&info.pid===proof.worker.pid&&info.sessionId===proof.worker.sessionId&&info.totalCostUsd===review.initial.native.backgroundInfo.totalCostUsd&&info.statusLine===review.initial.native.backgroundInfo.statusLine;
  },{timeout:20000}).toBe(true);}finally{await save();}
  await expect(composer).toHaveText(proof.parentDraft);record.recovered=await sameWorker();record.helpers=await workerHelpers();record.allHelpers=await allHelpers();assert.deepEqual(record.allHelpers,review.allHelpersBefore,'Recovery must not execute any configured helper again');record.modelAfter=modelTurns();record.requestsAfter=model.calls.length;record.requestsDuringRecovery=model.calls.slice(record.requestsBefore,record.requestsAfter);for(const call of record.requestsDuringRecovery){assert.equal(call.path,'/api/hello','Recovery traffic must be a startup handshake, never a model or unknown request');assert.deepEqual(call.messages,[]);}record.history=await history();assert.deepEqual(record.helpers,review.helpersBefore,'Recovery must not execute the helper again');assert.equal(record.modelAfter,review.modelBefore,'Recovery must not request another model turn');assert.deepEqual(record.history,review.historyBefore);await capture('restart-'+attempt);phase('owned-api-caption-recovered',{attempt,pid:record.after.pid});
 }
 review.recoveredWithoutExecution=true;await writeFile(join(output,'native-child-after-api-restart.jsonl'),await childJournal());
 await widget.getByRole('button',{name:'Open session',exact:true}).click();await expect(panel).toBeVisible({timeout:15000});await expect(input).toBeFocused();proof.childFollowup='Continue the release review after API recovery.';await input.pressSequentially(proof.childFollowup);await page.keyboard.press('Enter');await expect.poll(()=>repliedTo(proof.childFollowup),{timeout:20000}).toBe(true);
 await expect.poll(async()=>{const c=await context(),info=c.native?.backgroundInfo;return info?.statusLine==='Release review\nSession cost $'+info?.totalCostUsd?.toFixed(6)&&info.totalCostUsd>review.initial.native.backgroundInfo.totalCostUsd},{timeout:15000}).toBe(true);review.afterReply=await sameWorker();await writeFile(join(output,'native-child-transcript.jsonl'),await childJournal());
 await panel.getByRole('button',{name:'Close connection',exact:true}).click();await expect(panel).toBeHidden();await expect.poll(async()=>(await context()).native?.attachment,{timeout:15000}).toBeUndefined();await capture('replied');
 await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});await expect.poll(()=>birth(proof.worker.pid),{timeout:15000}).toBe(null);proof.nativeStopped=JSON.parse(await readFile(join(profileDir,'jobs',proof.worker.id,'state.json'),'utf8'));assert.equal(proof.nativeStopped.state,'stopped');assert.equal(proof.nativeStopped.sessionId,proof.worker.sessionId);proof.stopped=true;await expect(composer).toHaveText(proof.parentDraft);await expect(send).toBeDisabled();await expect(card.getByText('This conversation moved to the background. Your notes stay here.',{exact:true})).toBeVisible();proof.notesOnly=true;proof.final=await sameParent();proof.finalDocument=await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
 proof.costDomEvidence=await page.evaluate(()=>{const s=window.__claudeResearchCostEvidence;s.observer.disconnect();delete window.__claudeResearchCostEvidence;return{observations:s.observations,truncated:s.truncated}});assert.equal(proof.costDomEvidence.truncated,false);for(const r of proof.costDomEvidence.observations)if(r.statusCostUsd!==null&&r.totalCostUsd!==null)assert.equal(r.statusCostUsd,r.totalCostUsd);await page.evaluate(()=>{window.__claudeResearchApiReady.unsubscribe();delete window.__claudeResearchApiReady;});review.status='complete';proof.status='complete';await save();phase('native-api-caption-restart-complete');
}
