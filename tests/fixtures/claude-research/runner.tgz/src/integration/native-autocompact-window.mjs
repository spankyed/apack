import assert from 'node:assert/strict';
import { join } from 'node:path';

const advisory = /overriding auto may result in high token usage/i;

export async function observeAutoCompactWindow({ page, expect, context, composer, send, settings, output, proof, recommendedWindow, variant = true }) {
  const panel = page.getByRole('dialog', { name: 'Native /autocompact panel', exact: true });
  const drawing = panel.locator('[data-terminal-text]');
  const input = panel.getByLabel('Terminal input', { exact: true });
  const window = proof.window;
  const preimage = await settings();
  const model = proof.owner.session.model;
  const settingsModel = variant === 'capped-model' ? 'claude-haiku-4-5' : 'claude-sonnet-5-5';
  assert.ok(model === settingsModel || model === settingsModel + '-20251001');
  const expectedPreimage = variant === 'environment' ? 600000 : undefined;
  assert.equal(preimage.modelSettings?.[settingsModel]?.autoCompactWindow, expectedPreimage);
  const applied = () => settings().then(data => data.modelSettings?.[settingsModel]?.autoCompactWindow);

  async function capture(name) {
    const file = 'native-autocompact-window-' + name + '.png';
    await page.screenshot({ path: join(output, file), animations: 'disabled' });
    proof.captures.push(file);
  }

  async function verifyReturn() {
    await expect(composer).toBeEditable();
    const finished = await context();
    assert.equal(finished.claude.sessionId, proof.sessionId);
    assert.equal(finished.native.ownerId, proof.owner.ownerId);
  }

  const screen = async () => (await drawing.textContent({ timeout: 1000 }) ?? '').replace(/\s+/g, ' ').trim();

  async function observe(name, selection, warning) {
    const record = { name, selection: selection.source, warningExpected: warning };
    (window.observations ??= []).push(record);
    try {
      await expect.poll(async () => {
        record.screen = await screen();
        return selection.test(record.screen) && advisory.test(record.screen) === warning;
      }, { timeout: 10000 }).toBe(true);
    } finally {
      await capture(name);
    }
  }

  async function openPicker() {
    await composer.fill('/autocompact');
    await send.click();
    await expect(panel).toBeVisible({ timeout: 15000 });
    await expect(input).toBeFocused();
  }

  async function observeTyped({ argument, result, saved }) {
    const entry = { argument };
    (window.typed ??= []).push(entry);
    await composer.fill('/autocompact ' + argument);
    await send.click();
    const resultPanel = page.getByRole('region', { name: 'Command result', exact: true });
    const message = resultPanel.getByText(result);
    try {
      await expect(message).toBeVisible({ timeout: 15000 });
      entry.output = await message.innerText();
      await expect(panel).toBeHidden();
      await expect.poll(applied, { timeout: 10000 }).toBe(saved);
      entry.saved = await applied() ?? null;
    } finally {
      await capture('typed-' + argument);
    }
    await page.getByRole('button', { name: 'Back to messages', exact: true }).click();
    await expect(composer).toBeEditable();
  }

  const recommendation = new RegExp('auto \\(\\s*' + recommendedWindow / 1000 + 'k tokens\\s*\\)', 'i');
  if (variant === 'environment') {
    await page.setViewportSize({ width: 1100, height: 900 });
    await openPicker();
    const precedence = /CLAUDE_CODE_AUTO_COMPACT_WINDOW is set and takes precedence/i;
    await expect.poll(screen).toMatch(/current setting for Sonnet 5\.5: 300k tokens \(from CLAUDE_CODE_AUTO_COMPACT_WINDOW\)/i);
    await observe('environment-normal', precedence, false);
    await input.press('ArrowLeft');
    await input.press('ArrowRight');
    await expect.poll(screen).toMatch(precedence);
    assert.match(await screen(), /current setting for Sonnet 5\.5: 300k tokens/i);
    assert.doesNotMatch(await screen(), /select auto-compact window:/i);
    await input.press('Enter');
    await expect(panel).toBeHidden();
    assert.deepEqual(await settings(), preimage);
    await page.setViewportSize({ width: 680, height: 600 });
    await observeTyped({ argument: '1m', result: precedence, saved: expectedPreimage });
    assert.deepEqual(await settings(), preimage);
    await verifyReturn();
    return;
  }

  if (variant === 'capped-model') {
    await page.setViewportSize({ width: 1100, height: 900 });
    await openPicker();
    await expect.poll(screen).toMatch(recommendation);
    window.recommendedWindow = recommendedWindow;
    await input.press('ArrowLeft');
    await observe('model-cap-normal', /select auto-compact window:\s*1m tokens/i, false);
    await input.press('Escape');
    await expect(panel).toBeHidden();
    assert.deepEqual(await settings(), preimage);
    await page.setViewportSize({ width: 680, height: 600 });
    await observeTyped({ argument: '1m', result: /set to 1m tokens \(capped to model limit of 200k\)/i, saved: 1000000 });
    await verifyReturn();
    return;
  }

  if (variant === 'typed') {
    await page.setViewportSize({ width: 1100, height: 900 });
    await openPicker();
    await expect.poll(screen, { timeout: 10000 }).toMatch(recommendation);
    window.recommendedWindow = recommendedWindow;
    for (let tokens = 100000; tokens <= recommendedWindow; tokens += 100000) {
      await input.press('ArrowRight');
      const selection = new RegExp('select auto-compact window:\\s*' + tokens / 1000 + 'k tokens', 'i');
      await expect.poll(screen, { timeout: 10000 }).toMatch(selection);
    }
    await observe('equal-normal', /select auto-compact window:\s*400k tokens/i, false);
    await input.press('Escape');
    await expect(panel).toBeHidden();
    assert.deepEqual(await settings(), preimage);

    const cases = [
      { argument: 'invalid-cap', result: /couldn't parse 'invalid-cap'/i, saved: undefined },
      { argument: '400', result: /auto-compact window for Sonnet 5\.5 set to 400k tokens/i, saved: recommendedWindow },
      { argument: '1m', result: /auto-compact window for Sonnet 5\.5 set to 1m tokens/i, saved: 1000000 },
      { argument: 'auto', result: /auto-compact window for Sonnet 5\.5 set to auto/i, saved: 'auto' },
    ];
    await page.setViewportSize({ width: 680, height: 600 });
    for (const command of cases) await observeTyped(command);
    await openPicker();
    await expect.poll(screen, { timeout: 10000 }).toMatch(recommendation);
    await observe('typed-restored-compact', /select auto-compact window:\s*auto/i, false);
    await input.press('Escape');
    await expect(panel).toBeHidden();
    await verifyReturn();
    return;
  }

  await page.setViewportSize({ width: 1100, height: 900 });
  await openPicker();
  await expect.poll(screen, { timeout: 10000 }).toMatch(recommendation);
  window.recommendedWindow = recommendedWindow;
  await observe('auto-normal', /select auto-compact window:\s*auto/i, false);
  await input.press('ArrowRight');
  await observe('small-normal', /select auto-compact window:\s*100k tokens/i, false);
  await input.press('Escape');
  await expect(panel).toBeHidden();
  assert.deepEqual(await settings(), preimage);

  await page.setViewportSize({ width: 680, height: 600 });
  await openPicker();
  await input.press('ArrowLeft');
  await observe('large-compact', /select auto-compact window:\s*1(?:\.0+)?m tokens/i, true);
  await input.press('Enter');
  await expect(panel).toBeHidden();
  await expect.poll(applied, { timeout: 10000 }).toBe(1000000);
  window.applied = { model, tokens: await applied() };
  await openPicker();
  await expect.poll(screen, { timeout: 10000 }).toMatch(/current setting for Sonnet 5\.5:\s*1m tokens\s*\(from settings\)/i);
  await observe('persisted-compact', /select auto-compact window:\s*1(?:\.0+)?m tokens/i, true);
  await input.press('Escape');
  await expect(panel).toBeHidden();
  assert.equal(await applied(), 1000000);
  await verifyReturn();
}
