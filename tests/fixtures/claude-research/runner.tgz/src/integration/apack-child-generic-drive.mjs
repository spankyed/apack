import {readPermissionPreview} from './read-permission-preview.mjs';
import {prepareChildGenericProfile,observeChildGenericShutdown} from './child-generic-profile.mjs';
import {genericPermissionSteps} from '../protocol/native-generic-permission-fixture.mjs';
import {existsSync} from 'node:fs';
import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat,mkdir,rm} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';

export async function driveChildGeneric(options) {
 const profile=await prepareChildGenericProfile(options);
 const output=join(options.workspace,'electron-results');await mkdir(output,{recursive:true});
 try {
  await driveChildComposer({...options,env:{...options.env,DEBUG:'1',CLAUDE_CODE_DEBUG_LOGS_DIR:join(output,'native-generic-debug.log')},modelTool:'TextOnly',modelOptions:{childGenericScenario:true},modelRequestLimit:32,journey:genericJourney,askBeforeGenericPermission:true,journeyName:'generic'});
  const bounded=async path=>{const info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1024*1024);return(await readFile(path,'utf8')).trim().split('\n').filter(Boolean).map(line=>JSON.parse(line));};
  const children=await bounded(profile.children);assert.ok(children.length>0);
  const receipts=await bounded(profile.receipts),executed=receipts.filter(row=>row.method==='tools/call');assert.equal(executed.length,2);assert.deepEqual(executed.map(row=>row.arguments),[genericPermissionSteps[0].input,genericPermissionSteps[2].input]);
  await writeFile(join(output,'child-generic-mcp.json'),JSON.stringify({children,receipts,originalConfigSha256:profile.originalConfigSha256},null,2));
 } finally {try{const shutdown=await observeChildGenericShutdown(profile);await writeFile(join(output,'child-generic-process-shutdown.json'),JSON.stringify(shutdown,null,2));assert.ok(shutdown.passed,'Owned MCP/native writer still running');}finally{await profile.restore();await writeFile(join(output,'child-generic-profile-restored.json'),JSON.stringify({restored:true,originalConfigSha256:profile.originalConfigSha256}));}}
}
async function genericJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const proof={status:'running',parentSessionId,scope:'Original child generic/MCP once/deny/remembered/withheld/cancel decisions; no broader MCP integration or combined parity claim.',captures:[],sizes:[]};
 const save=()=>writeFile(join(output,'child-generic.json'),JSON.stringify(proof,null,2));
 const hasResult=stage=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id==='native_child_generic_'+stage);
 const result=async(stage,error)=>{
  const read=async()=>{
   const cached=hasResult(stage);if(cached){(proof.resultOrigins??={})[stage]='model';return cached;}
   if(!proof.target)return;
   const projects=join(userDataDir,'claude-code-profile/config/projects');
   for(const entry of(await readdir(projects,{withFileTypes:true})).slice(0,64)){
    if(!entry.isDirectory())continue;const path=join(projects,entry.name,proof.target.sessionId+'.jsonl');let info;
    try{info=await lstat(path)}catch(e){if(e.code==='ENOENT')continue;throw e}
    assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);
    const rows=raw.toString().split('\n').filter(Boolean).map(line=>JSON.parse(line)),value=rows.flatMap(row=>Array.isArray(row.message?.content)?row.message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id==='native_child_generic_'+stage);
    if(value){(proof.resultOrigins??={})[stage]='original-journal';return value;}
   }
  };
  await expect.poll(read,{timeout:15000}).toBeTruthy();const value=await read();assert.equal(value.is_error===true,error);proof['result'+stage]=value;await save();
 };
 const capture=async(name)=>{await page.screenshot({path:join(output,name+'.png')});proof.captures.push(name+'.png');await save();};
 const sizes=[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]];
 try {
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill('/background ResearchChildGeneric1 Review migration notes with the connected local tool.');await card.getByRole('button',{name:'Send',exact:true}).click();
  const widget=page.getByRole('region',{name:'Background Claude session',exact:true});await expect(widget.getByRole('button',{name:'Review request',exact:true})).toBeEnabled({timeout:25000});
  proof.running=await context();proof.target=proof.running.native.background.desktop;assert.ok(proof.target);proof.discoveredWithReplyClosed=true;
  await composer.fill('Keep the parent connected-tool review notes here.');const parentDraft=await composer.textContent();await widget.getByRole('button',{name:'Review request',exact:true}).click();proof.previews=[];proof.detailReading=[];
  for(const stage of [1,2,3,4,5]){
   if(stage>1){const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');await expect(editor).toBeEditable();await editor.fill('ResearchChildGeneric'+stage+' '+genericPermissionSteps[stage-1].prompt);await form.getByRole('button',{name:'Send message',exact:true}).click();}
   const panel=widget.getByRole('region',{name:'mcp__research__echo approval',exact:true});await expect(panel).toBeVisible({timeout:20000});
   const c=await context(),pair=Object.entries(c.ui).find(([,v])=>v.state?.approval?.control?.dialog?.sessionId===proof.target.sessionId);assert.ok(pair);const frame={mountId:pair[0],frame:pair[1].state.approval};proof.previews.push(frame);assert.equal(frame.frame.control.kind,'generic');
   if(stage===1)proof.firstApproval=frame;else{await page.evaluate(({threadId,mountId,frameId})=>window.applicationState.system.get('default-setup/threads').send({type:'CLAUDE_UI_APPROVAL_ANSWER',threadId,mountId,frameId,answer:{approved:false}}),{threadId:proof.running.threadId,mountId:frame.mountId,frameId:proof.firstApproval.frame.id});proof.oldDenialReplayed=true;}
   const presentation=frame.frame.control.dialog.presentation,no=presentation.choices.find(choice=>choice.value==='no'),yes=presentation.choices.find(choice=>choice.value==='yes');
   assert.ok(no);let label=stage===2||stage===4?'Deny':stage===5?'Cancel':yes?.label;assert.ok(label);
   if(stage===3){const remembered=presentation.choices.find(choice=>choice.decision==='allow'&&choice.value!=='yes');assert.ok(remembered);await panel.getByRole('combobox',{name:'mcp__research__echo approval choice',exact:true}).selectOption(remembered.value);proof.rememberedChoice=remembered;label='Continue';}
   if(stage===4){
    const parameters=presentation.details.find(detail=>/parameters|arguments/i.test(detail.label));assert.ok(parameters);
    assert.match(parameters.value,/value of 200,290 characters cannot be shown — deny unless expected/);
    assert.ok(yes,'Original oversized-input warning retains an allow-once choice');await expect(panel.locator('button.approve')).toBeEnabled();
    proof.withheldInputWarning={originalWarning:parameters.value,allowOnceOffered:true,decision:'deny'};
   }
   if(stage===5)assert.equal(presentation.canCancel,true);
   const details=panel.locator('.details'),fields=panel.locator('.tool-details dd');await expect(fields.last()).toBeVisible();assert.equal(await fields.count(),presentation.details.length);
   const parameters=presentation.details.findIndex(detail=>/parameters|arguments/i.test(detail.label)),captureField=parameters<0?presentation.details.length-1:parameters;
   for(const[name,size]of sizes){await page.setViewportSize(size);const fieldsRead=[];
    for(let index=0;index<presentation.details.length;index++){const reading=await readPermissionPreview({page,details,preview:fields.nth(index),expect});fieldsRead.push({index,label:presentation.details[index].label,reading});await expect(panel.getByRole('button',{name:label,exact:true})).toBeInViewport({ratio:1});if(index===captureField)await capture('child-generic-'+stage+'-'+name);}
    proof.detailReading.push({stage,name,fieldsRead});await save();
   }
   if((stage===2||stage===4)&&no.feedback){await panel.getByText('Add feedback',{exact:true}).click();const feedback=panel.getByRole('textbox',{name:'Feedback for Claude',exact:true});await feedback.fill('Keep the original release notes.');await widget.getByRole('button',{name:'Review request',exact:true}).click();await expect(panel).toBeHidden();await expect(composer).toHaveText(parentDraft);await widget.getByRole('button',{name:'Review request',exact:true}).click();await expect(feedback).toHaveValue('Keep the original release notes.');proof.denialDraftRetained=true;}
   await panel.getByRole('button',{name:label,exact:true}).click();await expect(panel).toHaveCount(0);await result(stage,stage!==1&&stage!==3);if((stage===2||stage===4)&&no.feedback)assert.ok(JSON.stringify(proof['result'+stage]).includes('Keep the original release notes.'));
   if(stage===3){
    const paths=[join(project,'.claude/settings.local.json'),join(userDataDir,'claude-code-profile/config/settings.local.json'),join(userDataDir,'claude-code-profile/config/settings.json')];
    const readRule=async()=>{proof.rememberedSettings=[];for(const path of paths){try{const info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1024*1024);const raw=await readFile(path),settings=JSON.parse(raw);proof.rememberedSettings.push({path,permissions:settings.permissions??null,sha256:createHash('sha256').update(raw).digest('hex')});if(settings.permissions?.allow?.includes('mcp__research__echo'))return {path,rules:settings.permissions.allow.filter(rule=>rule==='mcp__research__echo')};}catch(error){if(error.code!=='ENOENT')throw error;proof.rememberedSettings.push({path,absent:true});}}};
    await expect.poll(readRule,{timeout:15000}).toBeTruthy();proof.nativeRememberedRule=await readRule();
   }
  }
  const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');await expect(editor).toBeEditable();await editor.fill('Summarize the approved release check.');
  for(const[name,size]of sizes){await page.setViewportSize(size);await expect(form.getByRole('button',{name:'Send message',exact:true})).toBeInViewport({ratio:1});await capture('child-generic-composer-'+name);}
  await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(editor).toHaveText('',{timeout:20000});await expect.poll(()=>model.calls.some(call=>call.messages?.some(message=>message.role==='user'&&(message.content==='Summarize the approved release check.'||Array.isArray(message.content)&&message.content.some(block=>block.type==='text'&&block.text==='Summarize the approved release check.')))),{timeout:15000}).toBe(true);proof.finalReplyObserved=true;
  const projects=join(userDataDir,'claude-code-profile/config/projects');proof.transcripts={};
  for(const kind of ['parent','child']){const sid=kind==='parent'?parentSessionId:proof.target.sessionId;for(const directory of(await readdir(projects,{withFileTypes:true})).slice(0,64)){if(!directory.isDirectory())continue;const path=join(projects,directory.name,sid+'.jsonl');let info;try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);await writeFile(join(output,'native-'+kind+'-transcript.jsonl'),raw);proof.transcripts[kind]={sessionId:sid,path,sha256:createHash('sha256').update(raw).digest('hex')};break;}assert.ok(proof.transcripts[kind]);}
  await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});
  const stopped=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(stopped.sessionId,proof.target.sessionId);assert.equal(stopped.state,'stopped');proof.nativeStopped={jobId:proof.target.jobId,sessionId:stopped.sessionId,state:stopped.state};proof.final=await context();proof.status='complete';await save();phase('original-child-generic-complete');
 } catch(error) {
  proof.status='failed';proof.error=String(error.message).slice(0,4096);proof.failureContext=await context().catch(()=>null);await writeFile(join(output,'remembered-settings-before-cleanup.json'),JSON.stringify(proof.rememberedSettings??[],null,2));
  await page.screenshot({path:join(output,'child-generic-failure-before-cleanup.png')}).catch(()=>{});
  await save();throw error;
 } finally {
  const state=await context().catch(()=>null),sessionId=proof.target?.sessionId??state?.claude?.nativeContinuation?.continuedInSessionId;
  if(sessionId){const run=promisify(execFile),cliEnv={...env,CLAUDE_CONFIG_DIR:join(userDataDir,'claude-code-profile/config')};const rows=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024})).stdout);const owned=rows.find(row=>row.sessionId===sessionId&&row.cwd===project);if(owned&&owned.state!=='stopped'){await run('/frozen-claude/claude',['stop',owned.id],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024});proof.cleanupStoppedOwnedJob=true;}}
  await save();
 }
}
