import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir, mkdtemp } from 'node:fs/promises';
import { join, resolve, isAbsolute } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const [checkoutArg, outputArg] = process.argv.slice(2);
assert.ok(checkoutArg && outputArg && isAbsolute(checkoutArg) && isAbsolute(outputArg));
const checkout = resolve(checkoutArg), output = resolve(outputArg);
assert.ok(output.startsWith('/private/tmp/'), 'Browser fixtures use private temporary storage');
await mkdir(output, { recursive: true });
const workspace = await mkdtemp(join(output, 'svg-browser-'));
const require = createRequire(join(checkout, 'package.json'));
const { createServer } = await import(pathToFileURL(require.resolve('vite')).href);
const { default: vue } = await import(pathToFileURL(require.resolve('@vitejs/plugin-vue')).href);
const { _electron } = require('playwright');
const { expect } = require('@playwright/test');
const component = join(checkout, 'packages/default-setup/src/features/threads/fe/chat/NativeUiSvg.vue');
const sources = {};
for (const path of [component, join(checkout, 'packages/default-setup/src/features/threads/fe/chat/native-svg.ts')]) sources[path] = createHash('sha256').update(await readFile(path)).digest('hex');
const source = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 150" onload="top.__svgEscape=1"><script>top.__svgEscape=2</script><style>#hover:hover{fill:rgb(255,0,0)}</style><rect id="hover" width="100" height="100" fill="blue"><title>Native tooltip</title></rect><rect id="motion" y="110" width="10" height="10"><animate attributeName="x" values="0;20;0" dur="0.4s" repeatCount="indefinite"/></rect></svg>';
await writeFile(join(workspace, 'index.html'), '<!doctype html><html><head><style>.max-w-full{max-width:100%}.border-0{border-width:0}</style></head><body><div id="app"></div><script type="module" src="/fixture.js"></script></body></html>');
await writeFile(join(workspace, 'fixture.js'), `import { createApp, h } from 'vue';import Svg from ${JSON.stringify('/@fs/' + component)};window.__svgEscape=0;createApp({render:()=>h('main',{},[h('h1',{},'Native SVG fixture'),h('section',{id:'static',style:'width:100%;max-width:900px'},[h(Svg,{node:{kind:'svg',source:${JSON.stringify(source)},alt:'Static diagram',width:700,interactive:false}})]),h('section',{id:'interactive',style:'width:100%;max-width:900px'},[h(Svg,{node:{kind:'svg',source:${JSON.stringify(source)},alt:'Interactive diagram',width:700,interactive:true}})])])}).mount('#app');`);
const main = join(workspace, 'electron.cjs');
await writeFile(main, `const {app,BrowserWindow}=require('electron');app.setPath('userData',${JSON.stringify(join(workspace, 'profile'))});app.whenReady().then(()=>{const window=new BrowserWindow({show:false,width:1000,height:700,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});window.loadURL(process.env.RESEARCH_SVG_URL);});app.on('window-all-closed',()=>app.quit());`);
const server = await createServer({ configFile: false, root: workspace, cacheDir: join(workspace, '.vite'), plugins: [vue()], resolve: { alias: { vue: join(checkout, 'node_modules/vue/dist/vue.runtime.esm-bundler.js') } }, server: { host: '127.0.0.1', port: 0, fs: { allow: [workspace, checkout] } } });
let electron;
const evidence = { driverSha256: createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex'), fixtureSourceSha256: createHash('sha256').update(source).digest('hex'), candidate: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: checkout, encoding: 'utf8' }).trim(), sources, workspace, scope: 'Actual committed SVG SFC in a private Electron/Vite fixture with max-width/border utility equivalents; not compiled apack/native session acceptance', realModelRequests: 0 };
try {
  await server.listen();
  const port = server.httpServer.address().port;
  const env = { PATH: process.env.PATH, HOME: workspace, TMPDIR: workspace, RESEARCH_SVG_URL: `http://127.0.0.1:${port}/` };
  electron = await _electron.launch({ executablePath: require('electron'), args: [main], env, timeout: 20000 });
  const page = await electron.firstWindow();
  evidence.browserVersions = await electron.evaluate(() => ({ electron: process.versions.electron, chrome: process.versions.chrome }));
  const errors = []; page.on('pageerror', error => errors.push(error.message));
  await expect(page.getByRole('heading', { name: 'Native SVG fixture' })).toBeVisible();
  await expect.poll(() => page.locator('#static img').evaluate(image => image.complete && image.naturalWidth > 0)).toBe(true);
  const frame = page.frameLocator('#interactive iframe');
  await expect(frame.locator('#hover')).toBeVisible();
  assert.equal(await page.evaluate(() => window.__svgEscape), 0);
  assert.equal(await page.locator('#interactive iframe').getAttribute('sandbox'), '');
  const opaque = await page.evaluate(() => { try { return !document.querySelector('iframe').contentWindow.document } catch (error) { return error.name === 'SecurityError' } });
  assert.equal(opaque, true);
  assert.equal(await page.locator('#static img').evaluate(image => decodeURIComponent(image.src.split(',')[1]).includes('<script')), false);
  const blue = await frame.locator('#hover').evaluate(element => getComputedStyle(element).fill);
  await frame.locator('#hover').hover();
  await expect.poll(() => frame.locator('#hover').evaluate(element => getComputedStyle(element).fill)).toBe('rgb(255, 0, 0)');
  await expect.poll(() => frame.locator('#motion').evaluate(element => element.x.animVal.value), { timeout: 3000 }).toBeGreaterThan(1);
  assert.equal(await frame.locator('title').textContent(), 'Native tooltip');
  const sizes = [];
  for (const width of [1000, 180]) {
    await page.setViewportSize({ width, height: 700 });
    const measured = await page.evaluate(() => ['#static img', '#interactive iframe'].map(selector => { const rect = document.querySelector(selector).getBoundingClientRect(); return { selector, width: rect.width, height: rect.height, parentWidth: document.querySelector(selector).parentElement.getBoundingClientRect().width } }));
    for (const item of measured) { assert.ok(item.width <= item.parentWidth + 1); assert.ok(item.height > 0); assert.ok(Math.abs(item.width / item.height - 2) < 0.02); }
    sizes.push({ viewportWidth: width, measured });
    await page.screenshot({ path: join(workspace, `svg-${width}.png`) });
  }
  assert.deepEqual(errors, []);
  Object.assign(evidence, { complete: true, staticImageLoaded: true, parentUnmodified: true, opaqueFrame: true, scriptlessFrame: true, cssHover: { before: blue, after: 'rgb(255, 0, 0)' }, smilAnimated: true, titleRetained: true, sizes, errors, qualification: 'Tooltip markup retained; operating-system tooltip display not asserted. No full app/native owner journey.' });
} catch (error) { evidence.complete = false; evidence.error = error.stack; process.exitCode = 1; }
finally {
  try {
    if (electron) {
      const child = electron.process(); await electron.close();
      evidence.electronExit = { code: child.exitCode, signal: child.signalCode };
      assert.ok(child.exitCode !== null || child.signalCode !== null, 'Owned Electron must exit');
    }
  } catch (error) { evidence.complete = false; evidence.cleanupError = error.stack; process.exitCode = 1; }
  try { await server.close(); evidence.localServerClosed = !server.httpServer?.listening; }
  catch (error) { evidence.complete = false; evidence.serverCleanupError = error.stack; process.exitCode = 1; }
  await writeFile(join(workspace, 'evidence.json'), JSON.stringify(evidence, null, 2) + '\n');
  console.log(JSON.stringify({ workspace, complete: evidence.complete, error: evidence.error, cleanupError: evidence.cleanupError }));
}
