import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(base,'query.ts')).href);
const {createClaudeConversation}=await import(pathToFileURL(join(base,'conversation.ts')).href);
const model=await startSyntheticAgentModel();let owner,native;const events=[],turns=[];
const wait=async(predicate,label)=>{const deadline=Date.now()+18000;while(!predicate()){if(Date.now()>deadline)throw Error('Timed out: '+label);await new Promise(resolve=>setTimeout(resolve,10))}};
try{
 native=await query({cliPath:executable,cwd:workspace,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:undefined,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},permissionMode:'acceptEdits',tools:['Agent'],allowedTools:['Agent'],agents:{'status-fixture':{description:'Disposable local status worker',prompt:'NativeStatusChildSystem. Return the requested fixed worker marker without tools.',tools:[],maxTurns:1}},settingSources:[],strictMcpConfig:true,replayUserMessages:true,keepStdinOpen:true,signal:AbortSignal.timeout(25000),settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})});
 const consume=async scoped=>{
  const lines=[];for await(const event of scoped.handle.events)lines.push(event);
  turns.push({inputId:scoped.inputId,costBaseline:scoped.costBaseline,results:lines.filter(event=>event.type==='result').map(event=>({inputId:event.user_message_uuid,cost:event.total_cost_usd,pending:native.hasPendingBackgroundTasks(event),subtype:event.subtype})),assistant:lines.filter(event=>event.type==='assistant').length});owner.release(scoped.handle);
 };
 owner=createClaudeConversation(native,consume);owner.subscribe(event=>events.push(event));await native.initialized;
 const first=owner.start('NativeSubagentParentFixture: Run the disposable status worker.',consume);
 await wait(()=>model.calls.some(call=>call.child&&call.delivered)&&turns.length>=1&&!owner.busy,'worker and parent completion');
 const afterAgent=turns.length;assert.equal(owner.closing,false);
 const second=owner.start('Synthetic follow-up after the native agent.',consume);
 await wait(()=>turns.length>afterAgent&&!owner.busy,'later host input');
 const taskStarted=events.filter(event=>event.type==='system'&&event.subtype==='task_started');
 const taskCompleted=events.filter(event=>event.type==='system'&&event.subtype==='task_notification'&&event.status==='completed');
 assert.ok(taskStarted.some(event=>event.task_type==='local_agent'));assert.ok(taskCompleted.length>=1);
 assert.ok(taskStarted.every(event=>taskCompleted.some(done=>done.task_id===event.task_id)));
 assert.equal(model.calls.filter(call=>call.response==='Agent').length,1);assert.equal(model.calls.filter(call=>call.child&&call.delivered).length,1);
 assert.ok(turns.some(turn=>turn.inputId===first));assert.ok(turns.some(turn=>turn.inputId===second));
 const results=events.filter(event=>event.type==='result');assert.ok(results.every(event=>event.subtype==='success'));
 const deltas=turns.map(turn=>Math.max(0,turn.results.at(-1).cost-turn.costBaseline));assert.ok(Math.abs(deltas.reduce((a,b)=>a+b,0)-results.at(-1).total_cost_usd)<1e-12);
 await owner.close();
 console.log(JSON.stringify({evidence:'apack-native-agent-owner',targetSha256:hash(await readFile(executable)),hostInputs:2,agentLaunches:1,childCompleted:true,taskIdsMatched:true,keptProcess:true,exactCostBaselines:true,turns,resultCount:results.length,taskStarted,taskCompleted,syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{
 await writeFile(join(workspace,'native-agent-events.json'),JSON.stringify(events,null,2));await writeFile(join(workspace,'synthetic-agent-requests.json'),JSON.stringify(model.requests,null,2));
 console.log(JSON.stringify({diagnostic:'agent-owner-turns',turns,calls:model.calls}));
 try{if(owner){owner.kill();await owner.close().catch(()=>{})}else if(native){native.kill();await native.close().catch(()=>{})}}finally{await model.close()}
}
