import assert from 'node:assert/strict';
import {access,mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {setTimeout as delay} from 'node:timers/promises';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {addNativeReadMediaFixture} from '../protocol/native-read-media-fixture.mjs';

import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {nativeAgentMediaRouteObserver} from '../protocol/native-agent-media-route.mjs';
const [checkout,executable,root]=process.argv.slice(2),sha=value=>createHash('sha256').update(value).digest('hex');
assert.equal(process.platform,'linux');await access('/.dockerenv');assert.equal(process.getuid(),1000);assert.ok(isAbsolute(root));assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
for(const name of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[name],undefined);
await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'native-main-document-paste-')),config=join(workspace,'.claude'),observation=join(workspace,'native-drafts.jsonl'),preload=join(workspace,'observe.mjs');
await mkdir(config,{recursive:true});
const plugin=join(workspace,'plugin');
for(const path of [join(plugin,'.claude-plugin'),join(plugin,'hooks')])await mkdir(path,{recursive:true});
await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'document-paste-review',version:'0.0.1'}));
await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
await addNativeReadMediaFixture(workspace,plugin);
await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('prompt.submit',async($,e,next)=>{await $.fs.write('native-document-submit.json',JSON.stringify({text:e.text,attachments:e.attachments??[]}));return next(e)});}`);
await writeFile(join(config,'settings.json'),JSON.stringify({theme:'dark',apiKeyHelper:'/usr/bin/printf research-fixture-key'})+'\n');await writeFile(preload,nativeAgentMediaRouteObserver(observation));
const service=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(service,'query.ts')).href),store=await import(pathToFileURL(join(service,'handle-store.ts')).href),{prepareClaudeNativeTerminal}=await import(pathToFileURL(join(service,'terminal-owner.ts')).href);
const seed=await startSyntheticModel(workspace,'TextOnly',{captureMessages:true}),model=await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:2,textReply:'Document path received.'});
const env={HOME:workspace,CLAUDE_CONFIG_DIR:config,BUN_OPTIONS:'--preload='+preload};
let owner,native,seedResult,unsubscribe,timer,screen,sequence=0,lastAction=0,theme=false,security=false,selected=false,trusted=false,trustAt=0,terminal='';const receipts=[];
const wait=async(check,message,ms=20000)=>{const until=Date.now()+ms;while(Date.now()<until){if(await check())return;await delay(50)}throw Error(message)};
const observed=async()=>{try{return(await readFile(observation,'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse).at(-1)}catch(error){if(error.code==='ENOENT')return;throw error}};
try{
 owner=await store.openConversation('main-document-paste',JSON.stringify({cwd:workspace,allowedTools:[],pluginDir:[plugin]}),()=>query({cliPath:executable,cwd:workspace,env:{...env,ANTHROPIC_BASE_URL:seed.url},pluginDir:[plugin],tools:[],keepStdinOpen:true,replayUserMessages:true}),async turn=>{for await(const line of turn.handle.events){}seedResult=await turn.handle.result;owner.release(turn.handle)});
 await owner.handle.initialized;owner.start('Seed the owned document paste review.',async turn=>{for await(const line of turn.handle.events){}seedResult=await turn.handle.result;owner.release(turn.handle)});await wait(()=>seedResult&&!owner.busy,'Print seed did not settle');
 const sessionId=owner.sessionId,oldPid=owner.handle.pid;native=await store.openNativeTerminal('main-document-paste',{cliPath:executable,env:{...env,ANTHROPIC_BASE_URL:model.url}},async options=>{assert.deepEqual(options.pluginDir,[plugin]);return prepareClaudeNativeTerminal(options)});
 globalThis.self??=globalThis;const {Terminal}=createRequire(join(checkout,'packages/default-setup/package.json'))('@app/claude-terminal-xterm');screen=new Terminal({cols:100,rows:30,allowProposedApi:true});let updating=false;
 const observe=async()=>{if(updating)return;updating=true;try{const chunks=native.output.filter(row=>row.sequence>sequence);if(chunks.length){terminal=(terminal+chunks.map(row=>row.text).join('')).slice(-131072);await new Promise(resolve=>screen.write(chunks.map(row=>row.text).join(''),resolve));sequence=chunks.at(-1).sequence;}if(Date.now()-lastAction<250||native.state.status==='live')return;const b=screen.buffer.active,text=Array.from({length:screen.rows},(_,i)=>b.getLine(b.baseY+i)?.translateToString(true)??'').join('\n'),prompt=recognizeOnboardingPrompt(text,workspace);let input;if(prompt==='theme'&&!theme){theme=true;input='\r'}else if(prompt==='security-notes'&&!security){security=true;input='\r'}else if(prompt==='workspace-trust'&&!selected){selected=true;trustAt=Date.now();input='\x1b[B'}else if(prompt==='workspace-trust-selected'){selected=true;if(!trustAt)trustAt=Date.now();if(!trusted&&Date.now()-trustAt>1200){trusted=true;input='\r'}}if(input){lastAction=Date.now();native.input(native.state.ownerId,input);}}finally{updating=false}};
 unsubscribe=native.subscribe(()=>void observe());timer=setInterval(()=>void observe(),100);await observe();await wait(()=>native.state.status==='live','Original native onboarding did not finish',25000);
 const file=join(workspace,'release-notes.pdf'),prefix='Review this document: ';
 assert.equal(native.input(native.state.ownerId,'\x1b[200~'+prefix+'\x1b[201~'),true);await wait(async()=>(await observed())?.draft===prefix,'Original main composer did not accept text');
 assert.equal(native.input(native.state.ownerId,'\x1b[200~'+file+'\x1b[201~'),true);await wait(async()=>(await observed())?.draft.includes('release-notes.pdf'),'Original main composer did not accept PDF path');
 const before=await observed();await writeFile(join(workspace,'paste-before.json'),JSON.stringify(before,null,2)+'\n');
 assert.equal(native.input(native.state.ownerId,'\r'),true);await wait(()=>model.calls.some(call=>call.path.startsWith('/v1/messages'))&&!native.busy,'Original terminal document submission did not complete');
 await wait(async()=>{try{return JSON.parse(await readFile(join(workspace,'native-document-submit.json'),'utf8')).text===before.draft.trim()}catch(error){if(error.code==='ENOENT')return false;throw error}},'Original terminal prompt callback did not match the pasted draft');
 const submission=JSON.parse(await readFile(join(workspace,'native-document-submit.json'),'utf8'));
 const evidence={targetSha256:sha(await readFile(executable)),sessionId,oldPid,nativePid:native.state.pid,file,fileSha256:sha(await readFile(file)),before,submission,modelCalls:model.calls,realModelRequests:0,scope:'Original main terminal PDF file-paste and Enter only; no claim about other document producers or app upload UI.'};
 await writeFile(join(workspace,'route.json'),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify({workspace,draft:before.draft,submission,realModelRequests:0}));

}finally{
 clearInterval(timer);unsubscribe?.();screen?.dispose();store.killAllHandles();if(native)await native.close();
 await writeFile(join(workspace,'terminal.txt'),terminal);await writeFile(join(workspace,'model-calls.json'),JSON.stringify({seed:seed.calls,native:model.calls},null,2)+'\n');await writeFile(join(workspace,'shutdown.json'),JSON.stringify({nativePid:native?.state.pid,nativeExit:native?.state.exitCode,ownerReleased:store.getNativeTerminal('main-document-paste')===undefined})+'\n');await seed.close();await model.close();
}
