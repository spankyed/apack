import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {lstat, mkdir, readFile, rename, writeFile} from 'node:fs/promises';
import {basename, join} from 'node:path';
import {record} from '../protocol/record.mjs';

export const fillLabel = 'Fill release checklist';
export const fillText = 'Review the release checklist with fresh details.';
export const suggestLabel = 'Suggest release follow-up';
export const suggestText = 'Review the remaining migration notes.';

/** Use the original CLI's ordinary local marketplace installation in the disposable home. */
export async function preparePromptReplacementPlugin({workspace, project, env, readClear = false}) {
  const marketplace = join(workspace, 'prompt-marketplace');
  const plugin = join(marketplace, 'plugins/prompt-replacement');
  const marketName = basename(workspace);
  const name = `prompt-replacement@${marketName}`;
  const config = join(workspace, '.claude/plugins');
  const registries = ['known_marketplaces.json', 'installed_plugins.json'];
  for (const file of registries) await assert.rejects(lstat(join(config, file)), {code:'ENOENT'});
  await mkdir(join(marketplace, '.claude-plugin'), {recursive:true});
  await mkdir(join(plugin, '.claude-plugin'), {recursive:true});
  await mkdir(join(plugin, 'hooks'), {recursive:true});
  const files = {
    '.claude-plugin/plugin.json': JSON.stringify({name:'prompt-replacement',version:'0.0.1'}),
    'hooks/hooks.json': JSON.stringify({modules:['./register.ts']}),
    'hooks/register.ts': `export function register(on) {
 on('prompt.autocomplete', {token:/^#/}, async ($,e) => ({suggestions:[{text:e.token+'-complete',label:'Complete '+e.token}]}));
 on('ui.render', {component:'AbovePrompt'}, async ($,e,next) => {
  const base=await next(e);
  if(e.surface!=='desktop'||e.view?.agentId)return base;
  const {Box,Button}=$.ui.resolve(e);
  const readButtons=(${readClear} ? ['old','fresh'] : []).map(label=>Button({key:'read-reset-'+label,label:'Read '+label+' draft',onPress:async()=>{
   const session=await $.session.id();
   let result;try{result={session,value:await $.prompt.read()}}catch(error){result={session,error:String(error)}}
   await $.fs.write('read-clear-'+label+'.json',JSON.stringify(result));
  }}));
  return Box({flexDirection:'column',children:[base,Box({flexDirection:'row',children:[
   ...readButtons,Button({key:'review-fill',label:${JSON.stringify(fillLabel)},onPress:async()=>{
    const result=await $.prompt.fill({mode:'replace',text:${JSON.stringify(fillText)}});
    await $.fs.write('prompt-replacement-fill.json',JSON.stringify(result));
   }}),
   Button({key:'review-suggest',label:${JSON.stringify(suggestLabel)},onPress:async()=>{
    const result=await $.prompt.suggest({text:${JSON.stringify(suggestText)}});
    await $.fs.write('prompt-replacement-suggest.json',JSON.stringify(result));
   }}),
  ]})]});
 });
}`,
  };
  await writeFile(join(marketplace, '.claude-plugin/marketplace.json'), JSON.stringify({
    name:marketName,owner:{name:'Local release review'},plugins:[{name:'prompt-replacement',source:'./plugins/prompt-replacement'}],
  }));
  for (const [file, source] of Object.entries(files)) await writeFile(join(plugin, file), source);
  return {
    async install() {
      const runs = [];
      for (const args of [['plugin','validate',plugin], ['plugin','marketplace','add',marketplace], ['plugin','install',name]]) {
        const result = await record({executable:'/frozen-claude/claude',cwd:project,env,
          output:join(workspace,'prompt-plugin-installation'),args:['--setting-sources','',...args],timeoutMs:20000,maxBytes:1048576});
        assert.equal(result.code,0);
        assert.equal(result.status,'complete');
        runs.push(result);
      }
      const installed = JSON.parse(await readFile(join(config, 'installed_plugins.json'), 'utf8')).plugins?.[name];
      assert.ok(installed?.length===1 && installed[0].scope==='user');
      const hashes = {};
      for (const [file, source] of Object.entries(files)) {
        const bytes = await readFile(join(installed[0].installPath, file), 'utf8');
        assert.equal(bytes, source);
        hashes[file] = createHash('sha256').update(bytes).digest('hex');
      }
      await writeFile(join(workspace, 'prompt-plugin-installation.json'), JSON.stringify({name,runs,hashes}));
    },
    async restore() {
      for (const file of registries) {
        try { await rename(join(config,file),join(workspace,`observed-${file}`)); }
        catch (error) { if (error.code!=='ENOENT') throw error; }
        await assert.rejects(lstat(join(config,file)), {code:'ENOENT'});
      }
    },
  };
}
