import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { makeNativePageReviewPdf } from '../protocol/native-read-media-fixture.mjs';

export async function prepareNativePartialPdf(workspace, project) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
  assert.equal(project, join(workspace, 'project'));
  const reference = join(workspace, 'reference-pdf-pages');
  const bin = join(workspace, 'pdf-fixture-bin');
  const input = join(project, 'release-pages.pdf');
  const poppler = '/usr/bin/pdftoppm';
  await mkdir(reference);
  await mkdir(bin);
  const bytes = makeNativePageReviewPdf();
  await writeFile(input, bytes);
  const exec = promisify(execFile);
  const options = { timeout: 15000, maxBuffer: 65536 };
  const version = await exec(poppler, ['-v'], options);
  await exec(poppler, ['-jpeg', '-r', '100', '-f', '1', '-l', '3', input, join(reference, 'page')], options);
  const digest = value => createHash('sha256').update(value).digest('hex');
  await writeFile(join(workspace, 'pdf-renderer.json'), JSON.stringify({
    packages: (await readFile('/pdf-renderer-packages', 'utf8')).trim(),
    version: (version.stdout + version.stderr).trim(), binarySha256: digest(await readFile(poppler)),
    inputSha256: digest(bytes), referencePages: await Promise.all([1, 2, 3].map(async page =>
      ({ page, sha256: digest(await readFile(join(reference, 'page-' + page + '.jpg'))) }))),
  }, null, 2));

  // Inject only a single unreadable raster after the real renderer succeeds.
  // The native Reader still processes all three paths and builds its own model response.
  await writeFile(join(bin, 'pdftoppm'), `#!/bin/bash
set -euo pipefail
/usr/bin/pdftoppm "$@"
[[ "\${1:-}" != "-v" && "$*" == *"-f 1 -l 3"* ]] || exit 0
prefix="\${!#}"
case "$prefix" in /tmp/*|"$HOME"/*) ;; *) exit 1 ;; esac
for page in 1 2 3; do
  test -s "$prefix-$page.jpg"
  test ! -L "$prefix-$page.jpg"
done
sha256sum "$prefix-1.jpg" "$prefix-2.jpg" "$prefix-3.jpg" > "$HOME/pdf-raster-before-sha256.txt"
: > "$prefix-2.jpg"
test ! -s "$prefix-2.jpg"
`, { mode: 0o700 });
  return bin;
}
