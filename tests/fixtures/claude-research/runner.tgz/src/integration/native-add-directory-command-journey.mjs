import assert from 'node:assert/strict';
import { chmod, mkdir, readFile, stat } from 'node:fs/promises';
import { join } from 'node:path';

/** Observe the existing app route before adapting the original decision controls. */
export async function driveAddDirectoryCommandJourney({ page, expect, context, composer, send, section, replace, proof, output, workspace, project, birth, save, phase, model, semantic, restart, writeRefusal, standalone }) {
  const directory = join(workspace, 'reference-notes');
  const localSettings = join(project, '.claude', 'settings.local.json');
  const readLocalSettings = () => readFile(localSettings, 'utf8').catch(error => {
    if (error.code === 'ENOENT') return null;
    throw error;
  });

  await mkdir(directory);
  const settingsBefore = await readLocalSettings();
  const callsBefore = model.calls.length;
  const panel = page.getByRole('dialog', { name: 'Native /add-dir panel', exact: true });
  const drawing = panel.locator('[data-terminal-text]');
  const choices = ['Yes, for this session', 'Yes, and remember this directory', 'No'];
  proof.scope = 'Current desktop routing of the original preselected /add-dir decision, Escape cancellation and same-session continuation.';
  proof.directory = directory;
  proof.options = [];
  const permissions = page.getByRole('dialog', { name: 'Claude Code permissions', exact: true });
  const stopNative = async pid => {
    await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
    await section.getByRole('button', { name: 'Stop session', exact: true }).click();
    await expect.poll(() => birth(pid), { timeout: 15000 }).toBe(null);
    const back = section.getByRole('button', { name: 'Back to conversation', exact: true });
    if (await back.isVisible()) await back.click();
  };
  const readWorkspace = async () => {
    await replace('/permissions');
    await send.click();
    await permissions.getByRole('tab', { name: 'Workspace', exact: true }).click();
    await expect(permissions.getByRole('tab', { name: 'Workspace', exact: true })).toHaveAttribute('aria-selected', 'true');
    await expect(permissions.getByRole('button', { name: /^Add directory/ })).toBeVisible();
    return permissions.locator('[data-native-permission-choice]').evaluateAll(nodes => nodes.map(node => node.dataset.nativePermissionChoice));
  };
  const closeWorkspace = async () => {
    await permissions.getByRole('button', { name: 'Close permissions', exact: true }).click();
    await expect(permissions).toBeHidden();
  };
  const sizes = [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]];
  if (standalone) {
    proof.scope = 'Original no-path directory form, invalid path refusal, native completion, session-only add and Cancel.';
    await page.setViewportSize(sizes[1][1]);
    await replace('/add-dir');
    await send.click();
    const choicePanel = page.getByRole('dialog', { name: 'Add directory to workspace', exact: true });
    const input = choicePanel.getByRole('combobox', { name: /Directory path/ });
    const submit = choicePanel.getByRole('button', { name: 'Add directory', exact: true });
    await expect(input).toBeFocused({ timeout: 15000 });
    const missing = join(workspace, 'missing-reference-notes');
    await input.fill(missing);
    await submit.click();
    const problem = choicePanel.getByRole('alert');
    await expect(problem).toHaveText('Path ' + missing + ' was not found.', { timeout: 15000 });
    const screenshot = async stage => {
      const file = 'native-directory-form-' + stage + '.png';
      await page.screenshot({ path: join(output, file), animations: 'disabled' });
      proof.captures.push(file);
      await save();
    };
    await screenshot('invalid-compact');
    await input.fill(join(workspace, 'reference-no'));
    const option = choicePanel.locator('[data-native-directory-suggestion=' + JSON.stringify(directory) + ']');
    await expect(option).toBeVisible({ timeout: 15000 });
    await option.click();
    await expect(input).toHaveValue(directory + '/');
    await expect(input).toBeFocused();
    await expect(problem).toHaveCount(0);
    await screenshot('suggestion-compact');
    await submit.click();
    await expect(choicePanel).toBeHidden();
    await expect(composer).toBeEditable();
    const added = await readWorkspace();
    assert.ok(added.includes(directory));
    assert.equal(await readLocalSettings(), settingsBefore);
    assert.equal(model.calls.length, callsBefore);
    await closeWorkspace();

    await page.setViewportSize(sizes[0][1]);
    await replace('/add-dir');
    await send.click();
    await expect(input).toBeFocused();
    await input.press('Escape');
    await expect(choicePanel).toBeHidden();
    await expect(composer).toBeEditable();
    assert.equal(await readLocalSettings(), settingsBefore);
    proof.standalone = { directory, added, originalPid: (await context()).native.state.nativePid };
    assert.equal(proof.standalone.originalPid, proof.pid);
    await save();
  }
  if (semantic) {
    proof.scope = 'Original preselected directory choices, cancellation, session-only and remembered state in the desktop composer.';
    const choicePanel = page.getByRole('dialog', { name: 'Add directory to workspace', exact: true });
    const remembered = join(workspace, 'reference-notes-to-remember');
    const sessionOnly = join(workspace, 'reference-notes-for-this-session');
    await mkdir(remembered);
    await mkdir(sessionOnly);
    const cases = writeRefusal ? [
      ['no', sizes[1], directory, choices[2]],
      ['remember', sizes[0], remembered, choices[1]],
    ] : [
      ['cancel', sizes[0], directory, 'Cancel'],
      ['session', sizes[1], sessionOnly, choices[0]],
      ['remember', sizes[0], remembered, choices[1]],
    ];
    for (const [stage, [size, viewport], path, decision] of cases) {
      await page.setViewportSize(viewport);
      await replace('/add-dir ' + path);
      await send.click();
      await expect(choicePanel).toBeVisible({ timeout: 15000 });
      const target = choicePanel.getByText(path, { exact: true });
      const warning = choicePanel.getByText(/Claude Code will be able to read files in this directory/);
      const buttons = choices.map(name => choicePanel.getByRole('button', { name, exact: true }));
      await expect(buttons[0]).toBeFocused({ timeout: 15000 });
      for (const item of [target, warning, ...buttons]) {
        await expect(item).toBeInViewport({ ratio: 1 });
        assert.ok(await item.evaluate(element => element.scrollWidth <= element.clientWidth + 1));
      }
      const file = 'native-add-directory-' + stage + '-' + size + '.png';
      await page.screenshot({ path: join(output, file), animations: 'disabled' });
      proof.captures.push(file);
      proof.options.push({ size, stage, path, warning: await warning.innerText(), labels: await Promise.all(buttons.map(button => button.innerText())) });
      await choicePanel.getByRole('button', { name: decision, exact: true }).click();
      await expect(choicePanel).toBeHidden({ timeout: 15000 });
      await expect(composer).toBeEditable();
      assert.equal((await context()).native.state.nativePid, proof.pid);
      assert.equal(model.calls.length, callsBefore);
      const settings = await readLocalSettings();
      if (stage === 'remember') {
        assert.deepEqual(JSON.parse(settings).permissions.additionalDirectories, [remembered]);
      } else assert.equal(settings, settingsBefore);
      await save();
    }
    proof.localSettingsAfter = await readLocalSettings();
    proof.beforeStopWorkspace = await readWorkspace();
    assert.ok(proof.beforeStopWorkspace.includes(remembered));
    if (!writeRefusal) assert.ok(proof.beforeStopWorkspace.includes(sessionOnly));
    assert.ok(!proof.beforeStopWorkspace.includes(directory));
    await closeWorkspace();
    if (writeRefusal) {
      const refused = join(workspace, 'reference-notes-without-settings-write');
      await mkdir(refused);
      const settingsDirectory = join(project, '.claude');
      const directoryMode = (await stat(settingsDirectory)).mode & 0o777;
      const fileMode = (await stat(localSettings)).mode & 0o777;
      try {
        await chmod(localSettings, 0o400);
        await chmod(settingsDirectory, 0o500);
        await page.setViewportSize(sizes[1][1]);
        await replace('/add-dir ' + refused);
        await send.click();
        const remember = choicePanel.getByRole('button', { name: choices[1], exact: true });
        await expect(remember).toBeInViewport({ ratio: 1 });
        await remember.click();
        await expect(choicePanel).toBeHidden({ timeout: 15000 });
        const report = 'Added ' + refused + ' as a working directory and saved to local settings';
        await expect.poll(async () => (await context()).messages
          .filter(message => typeof message.text === 'string' && message.text.startsWith(report)).length,
        { timeout: 15000 }).toBe(1);
        const state = await context();
        assert.equal(state.native.state.nativePid, proof.pid);
        assert.equal(await readLocalSettings(), proof.localSettingsAfter);
        assert.equal(model.calls.length, callsBefore);
        const file = 'native-add-directory-write-refusal-compact.png';
        await page.screenshot({ path: join(output, file), animations: 'disabled' });
        proof.captures.push(file);
        proof.writeRefusal = { path: refused, sameSettings: true, originalReport: report };
        await save();
      } finally {
        await chmod(settingsDirectory, directoryMode);
        await chmod(localSettings, fileMode);
      }
      proof.writeRefusal.workspace = await readWorkspace();
      assert.ok(proof.writeRefusal.workspace.includes(refused));
      await closeWorkspace();
      assert.equal((await stat(settingsDirectory)).mode & 0o777, directoryMode);
      assert.equal((await stat(localSettings)).mode & 0o777, fileMode);
      proof.writeRefusal.modesRestored = true;
      await save();
    }
  }

  for (const [name, viewport] of semantic || standalone ? [] : sizes) {
    await page.setViewportSize(viewport);
    await replace('/add-dir ' + directory);
    await send.click();
    await expect(panel).toBeVisible({ timeout: 15000 });
    await expect(drawing).toContainText('Add directory to workspace');
    for (const choice of choices) await expect(drawing).toContainText(choice);
    const close = panel.getByRole('button', { name: 'Close panel', exact: true });
    await expect(close).toBeInViewport({ ratio: 1 });
    await expect(panel.getByRole('button', { name: 'Yes, and remember this directory' })).toHaveCount(0);
    const file = 'native-add-directory-' + name + '.png';
    await page.screenshot({ path: join(output, file), animations: 'disabled' });
    proof.captures.push(file);
    proof.options.push({ size: name, text: await drawing.innerText() });
    await panel.getByLabel('Terminal input').press('Escape');
    await expect(panel).toBeHidden({ timeout: 15000 });
    await expect(composer).toBeEditable();
    assert.equal((await context()).claude.sessionId, proof.sessionId);
    assert.equal(await readLocalSettings(), settingsBefore, 'Cancel must leave local settings unchanged');
    assert.equal(model.calls.length, callsBefore, 'The local decision must not call the model');
    await save();
  }

  proof.followup = 'Continue the release summary after reviewing the directory choice.';
  await replace(proof.followup);
  await send.click();
  await expect.poll(async () => {
    const current = await context();
    return current.claude.sessionId === proof.sessionId && current.native.state.nativePid === proof.pid
      && current.claude.chatState === 'success' && current.native.state.busy === false
      && current.messages.filter(message => message.sender === 'user' && message.text === proof.followup).length === 1;
  }, { timeout: 15000 }).toBe(true);
  proof.final = await context();
  assert.equal(proof.final.claude.totalCostUsd, proof.final.native.state.session.totalCostUsd);
  await stopNative(proof.pid);
  if (restart) {
    const paths = Object.fromEntries(proof.options.map(row => [row.stage, row.path]));
    const reopen = async (sessionId, previousPid) => {
      await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
      await expect.poll(async () => {
        const state = (await context()).native?.state;
        return state?.status === 'live' && !!state.nativePid && state.nativePid !== previousPid;
      }, { timeout: 25000 }).toBe(true);
      const current = await context();
      assert.equal(current.claude.sessionId, sessionId);
      const pid = current.native.state.nativePid;
      const start = await birth(pid);
      assert.ok(start);
      proof.resumedWriter = { pid, start, ownerId: current.native.state.ownerId };
      await save();
      await section.getByRole('button', { name: 'Back to conversation', exact: true }).click();
      return proof.resumedWriter;
    };
    const resumed = await reopen(proof.sessionId, proof.pid);
    assert.notEqual(resumed.ownerId, proof.initial.native.state.ownerId);
    proof.reopened = { sessionId: proof.sessionId, ...resumed, workspace: await readWorkspace() };
    await save();
    assert.ok(proof.reopened.workspace.includes(paths.remember));
    assert.ok(!proof.reopened.workspace.includes(paths.cancel));
    await closeWorkspace();
    await stopNative(resumed.pid);

    const oldThread = (await context()).threadId;
    await page.evaluate(directory => {
      const actor = window.applicationState.system.get('default-setup/threads');
      actor.send({ type: 'VIEW_DASHBOARD' });
      actor.send({ type: 'NEW_THREAD_IN_PROJECT', directory });
      actor.send({ type: 'SET_MODE', mode: 'Claude Code' });
      actor.send({ type: 'SET_PHASE', phase: 'Edit' });
    }, project);
    await expect.poll(async () => (await context()).threadId).not.toBe(oldThread);
    proof.freshSeed = 'Start an independent release review in the same project.';
    await replace(proof.freshSeed);
    await send.click();
    await expect.poll(async () => (await context()).claude?.turns, { timeout: 30000 }).toBe(1);
    const freshSession = (await context()).claude.sessionId;
    assert.ok(freshSession && freshSession !== proof.sessionId);
    const fresh = await reopen(freshSession, resumed.pid);
    proof.fresh = { sessionId: freshSession, ...fresh, workspace: await readWorkspace() };
    await save();
    assert.ok(proof.fresh.workspace.includes(paths.remember));
    assert.ok(!proof.fresh.workspace.includes(paths.session));
    assert.ok(!proof.fresh.workspace.includes(paths.cancel));
    assert.equal(await readLocalSettings(), proof.localSettingsAfter);
    await closeWorkspace();
    await stopNative(fresh.pid);
    assert.equal(await birth(resumed.pid), null);
  }
  proof.stopped = true;
  proof.status = 'complete';
  await save();
  phase('native-add-directory-command-complete');
}
