import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir,readFile,writeFile,rename,lstat} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';

/** One ordinary user theme in the already-owned profile; native safe mode owns admission. */
export async function prepareSafeThemeProfile({setupWorkspace,workspace}){
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));assert.equal(process.getuid(),1000);
 assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');assert.match(workspace,/^\/work\/\.claude-research\/safe-theme-app[0-9]+$/);
 const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),config=join(setupWorkspace,'app-data/claude-code-profile/config'),settingsPath=join(config,'settings.json');
 const stat=await lstat(settingsPath);assert.ok(stat.isFile()&&stat.uid===1000&&stat.size<=1048576);const before=await readFile(settingsPath);assert.equal(sha(before),'b5f5daa39d948095ab450bcd3ec1ac03b3c3adeb1df532e424da9f95ad8097b5');
 const slug='release-policy-'+basename(workspace),themePath=join(config,'themes',slug+'.json');assert.ok(!existsSync(themePath));
 const theme={name:'Release policy preview',base:'dark',overrides:{text:'#55ccaa',permission:'#bb88ee'}},bytes=Buffer.from(JSON.stringify(theme,null,2)+'\n'),value='custom:'+slug;
 await mkdir(join(workspace,'profile-preimages'));await writeFile(join(workspace,'profile-preimages/settings.json'),before,{mode:0o600,flag:'wx'});
 await mkdir(join(config,'themes'),{recursive:true});await writeFile(themePath,bytes,{mode:0o600,flag:'wx'});let restored=false;
 const initial={slug,value,themePath,themeSha256:sha(bytes),settingsBeforeSha256:sha(before),originalThemeFilePresent:false,safeMode:'1',scope:'Ordinary authored user-theme file and selected setting; no plugin, registry, callback or native policy injection.'};
 async function restore(){if(restored)return;const current=await readFile(themePath);await rename(themePath,join(workspace,'preserved-safe-theme.json'));await rename(settingsPath,join(workspace,'preserved-safe-theme-settings.json'));await writeFile(settingsPath,before,{mode:0o600,flag:'wx'});assert.equal(sha(await readFile(settingsPath)),sha(before));assert.ok(!existsSync(themePath));await writeFile(join(workspace,'safe-theme-profile-restoration.json'),JSON.stringify({restored:true,settingsSha256:sha(before),fixtureThemeRemovedFromProfile:true,preservedThemeSha256:sha(current),themeUnchanged:sha(current)===sha(bytes)}));restored=true;}
 try{await writeFile(settingsPath,JSON.stringify({...JSON.parse(before),theme:value}));await writeFile(join(workspace,'safe-theme-profile.json'),JSON.stringify(initial));return{...initial,restore};}
 catch(error){await restore();throw error;}
}
