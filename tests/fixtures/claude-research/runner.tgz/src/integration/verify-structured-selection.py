"""Verify saved original-native rich prompt selection/read/fill/Send evidence."""
from pathlib import Path
import argparse, hashlib, json, subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence', type=Path)
parser.add_argument('product', type=Path)
parser.add_argument('--commit', required=True)
parser.add_argument('--research-commit', required=True)
args = parser.parse_args()
evidence = args.evidence.resolve()
research = Path(__file__).resolve().parents[2]

def load(path):
    assert path.stat().st_size < 32 * 1024**2, path
    return json.loads(path.read_text())

counts = {}
for repo, commit, name in [(args.product, args.commit, 'source-inputs.json'), (research, args.research_commit, 'authored-inputs.json')]:
    inputs = load(evidence / name)
    assert inputs
    counts[name] = len(inputs)
    for path, expected in inputs.items():
        assert not Path(path).is_absolute() and '..' not in Path(path).parts
        data = subprocess.check_output(['git', 'show', commit + ':' + path], cwd=repo)
        assert hashlib.sha256(data).hexdigest() == expected, path
compiled = load(evidence / 'compiled-before.json')
assert compiled == load(evidence / 'compiled-after.json')
boundary = load(evidence / 'offline-boundary.json')
assert boundary['networkDisabled'] and boundary['pinnedExecutableReadOnly'] and set(boundary['networks']) == {'none'}
assert boundary['memory'] == boundary['memorySwap'] == 6 * 1024**3 and boundary['nanoCpus'] == 2 * 10**9
proofs = list((evidence / 'records/workspaces').glob('*/native-all-selection-proof.json'))
assert len(proofs) == 1
workspace = proofs[0].parent
fill = load(workspace / 'native-structured-prompt-proof.json')
receipts = fill['receipts']
assert len(receipts) == 3 and [row['mode'] for row in receipts] == ['replace','append','insert']
assert all(row['result']['isFilled'] for row in receipts)
selection = load(proofs[0])
assert len(selection) == 2 and [row['size'] for row in selection] == [{'width':1100,'height':900},{'width':680,'height':600}]
for row in selection:
    assert row['before'] == row['after']
    bounds = row['before']['range']
    assert bounds['from'] <= 1 and bounds['to'] >= bounds['docSize'] - 1
    assert {'heading','codeBlock','bulletList'}.issubset({node['type'] for node in row['before']['doc']['content']})
    assert row['native'] == {'text':receipts[1]['after']['text'], 'cursor':len(receipts[1]['after']['text'])}
assert receipts[2]['before']['cursor'] == receipts[2]['before']['text'].index('Review changes.')
assert 'Please Review changes.' in fill['canonical']
app = load(workspace / 'native-terminal-app-evidence.json')
assert app['actualAppGui'] and app['nativeStructuredPrompt'] and app['nativePromptAllSelection']
assert app['sameNativeOwner'] and app['resumedPrintSameSession'] and not app['browserErrors']
assert app['sessionId'] == app['finalSessionId']
journals = list((workspace / '.claude/projects').glob('*/' + app['sessionId'] + '.jsonl'))
assert len(journals) == 1
rows = [json.loads(line) for line in journals[0].read_text().splitlines() if line]
humans = [row for row in rows if row.get('type') == 'user' and not row.get('isMeta') and not row.get('isVirtual')]
assert len(humans) == 3
for text in [fill['canonical'], 'Continue reviewing the release after the outline.']:
    matches = [row for row in humans if row.get('message',{}).get('content') == text]
    assert len(matches) == 1 and matches[0]['sessionId'] == app['sessionId']
children = [json.loads(line) for line in (workspace / 'native-children.jsonl').read_text().splitlines() if line]
exits = {row['pid']:row for row in [json.loads(line) for line in (workspace / 'native-exits.jsonl').read_text().splitlines() if line]}
assert len(children) == 3 and all(child['pid'] in exits for child in children)
assert app['boundNativePid'] == children[1]['pid']
assert exits[children[0]['pid']]['at'] <= children[1]['at'] and exits[children[1]['pid']]['at'] <= children[2]['at']
stdout = next((evidence / 'records/output/runs').glob('*/stdout.bin')).read_text()
markers = [json.loads(line) for line in stdout.splitlines() if line.startswith('{"evidence":"apack-native-terminal-owner-app"')]
assert len(markers) == 1 and markers[0]['ownedShutdown']
assert markers[0]['targetSha256'] == '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
assert markers[0]['syntheticApiRequests'] == 3 and markers[0]['realModelRequests'] == 0
screens = list((workspace / 'electron-results').rglob('*.png'))
expected = {'native-' + kind + '-' + width + '.png' for kind in ['all-selection','structured-prompt'] for width in ['1100','680']} | {'native-structured-prompt-compact-checklist.png'}
assert len(screens) == len(expected) and {path.name for path in screens} == expected
summary = {'status':'passed','runtimeCommit':args.commit,'researchCommit':args.research_commit,'verifiedInputs':counts,'compiledFilesUnchanged':len(compiled['files']),'sessionId':app['sessionId'],'selectionRead':selection,'canonicalHumanText':fill['canonical'],'nativeHumanUuids':[row['uuid'] for row in humans],'captures':len(screens),'ownedNativeExits':3,'syntheticRequests':3,'realModelRequests':0,'scope':'Main-owner whole rich-document selection/read preserves document/range; original decorated replace/append/Home-insert and exact Send/session recovery. Leading/trailing blank paragraph and atom guards have focused proof; other owners/IME/media/lifetimes and full F1–F5 remain open.'}
(evidence / 'saved-record-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
