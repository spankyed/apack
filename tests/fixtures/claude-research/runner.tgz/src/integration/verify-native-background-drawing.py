"""Verify saved native child drawing/terminal callback evidence; no desktop acceptance claim."""
import argparse
import base64
import hashlib
import json
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence',type=Path)
parser.add_argument('product',type=Path)
args=parser.parse_args()
research=Path(__file__).resolve().parents[2]
records=args.evidence/'export/records'
workspace=args.evidence/'export/apack-terminal-owner-app-background'
load=lambda path:json.loads(path.read_text())
inputs=load(records/'source-inputs.json')
for name,digest in inputs.items():
    prefix='/research/' if name.startswith('/research/') else '/product/'
    assert name.startswith(prefix)
    root=research if prefix=='/research/' else args.product
    assert hashlib.sha256((root/name[len(prefix):]).read_bytes()).hexdigest()==digest,name
boundary=load(args.evidence/'offline-boundary.json')
assert boundary['networkDisabled'] and set(boundary['networks'])=={'none'} and boundary['pinnedExecutableReadOnly']
assert boundary['memory']==boundary['memorySwap']==6*1024**3 and boundary['nanoCpus']==2*10**9
native=load(records/'leftarrow-evidence.json')
assert native['verifyFork'] and native['verifyAttach'] and native['stopped'] and native['realModelRequests']==0
attachment=load(records/'original-child-attach-observation.json')
assert attachment['frameSeen'] and attachment['jobBefore']['pid']==attachment['jobAfter']['pid']==native['forkJob']['pid']
assert attachment['processBefore']['startTime']==attachment['processAfter']['startTime'] and attachment['processAfter']['state']!='Z'
child=native['forkJob']['sessionId'];audit=load(records/'child-drawing-audit.json')
rows=[row['value']for row in audit['records']if row['value']['sessionId']==child]
drawings=[row for row in rows if row.get('drawn')]
assert drawings and all(row['surface']=='terminal' and row['component']=='AbovePrompt' for row in drawings)
handles=[]
for row in drawings:
    assert row['builtin']['type']=='engine' and isinstance(row['builtin']['ref'],int)
    assert row['drawn']['type']=='Box' and row['drawn']['children'][0]==row['builtin']
    buttons=[node for node in row['drawn']['children']if isinstance(node,dict) and node.get('type')=='Button']
    assert len(buttons)==1
    button=buttons[0];assert button['props']['key']=='child-drawing-proof' and button['props']['hotkey']=='1'
    assert button['press']['plugin']=='' and isinstance(button['press']['handle'],int)
    handles.append(button['press']['handle'])
assert len(set(handles))>1,'Callback handle changes across native redraws'
callbacks=[row for row in rows if row.get('callback')is True]
dispatch=[row for row in rows if row.get('event',{}).get('element')=='child-drawing-proof']
assert len(callbacks)==len(dispatch)==1
assert dispatch[0]['event']['plugin']=='research-child-host-audit'
assert dispatch[0]['event']['surface']=='terminal' and dispatch[0]['event']['component']=='AbovePrompt'
assert dispatch[0]['result']=={'element':'child-drawing-proof'}
assert callbacks[0]['at']<=dispatch[0]['at']
paths=list(records.glob('original-child-attach/runs/*/events.jsonl'));assert len(paths)==1
keys=[base64.b64decode(row['base64'])for row in map(json.loads,paths[0].read_text().splitlines())if row['kind']=='stdin']
assert b'\x18\t' in keys and b'1' in keys
proof={'status':'passed','scope':'Original child terminal custom drawing and callback only; no desktop transport or actual-app structured child acceptance.',
       'verifiedSourceInputs':len(inputs),'childSessionId':child,'workerPid':native['forkJob']['pid'],'nativeDrawingSamples':len(drawings),
       'engineReferences':[row['builtin']['ref']for row in drawings],'preStampHandles':handles,'nativeStampedPlugin':dispatch[0]['event']['plugin'],
       'originalCallbackInvocations':len(callbacks),'sameWorkerAfterAttach':True,'originalChildStop':True,
       'syntheticRequests':native['syntheticRequests'],'realModelRequests':0}
(args.evidence/'saved-record-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
