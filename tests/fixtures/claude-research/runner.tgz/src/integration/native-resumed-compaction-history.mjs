import assert from 'node:assert/strict';
import { basename, join } from 'node:path';

const locatorText = 'Earlier messages are saved in ';
const originalSummaryPath = 'read the full transcript at: ';

export async function observeResumedCompactionHistory({ page, expect, context, section, output, proof, sources, project, composer, retainedDraft }) {
  const boundary = sources.find(row => row.uuid === proof.manualRows.boundaryUuid);
  const summary = sources.find(row => row.uuid === proof.manualRows.summaryUuid);
  assert.ok(boundary && summary && summary.sessionId === proof.sessionId);
  const content = summary.message.content;
  const text = typeof content === 'string' ? content : content.filter(block => block.type === 'text').map(block => block.text).join('\n');
  const marker = text.lastIndexOf(originalSummaryPath);
  assert.ok(marker >= 0, 'The original summary did not contain a native transcript reference');
  const path = text.slice(marker + originalSummaryPath.length).split('\n')[0];
  assert.equal(basename(path), proof.sessionId + '.jsonl');
  assert.ok(path.startsWith(join(project, '..', '.claude', 'projects') + '/'));

  const history = proof.resumedHistory;
  history.boundaryUuid = boundary.uuid;
  history.summaryUuid = summary.uuid;
  history.transcript = path;
  const terminal = section.locator('[data-terminal-text]').first();
  const input = section.locator('[aria-label="Terminal input"]');
  const normalizeScreen = async () => (await terminal.textContent() ?? '').replace(/\s+/g, ' ').trim();
  const seeHint = async (mode, previousScreen) => {
    let screen = '';
    const observation = { mode };
    (history.views ??= []).push(observation);
    try {
      await expect.poll(async () => {
        screen = await normalizeScreen();
        const marker = screen.indexOf(locatorText);
        return screen !== previousScreen && marker >= 0 && screen.slice(marker).replace(/\s/g, '').includes(basename(path))
          && (mode !== 'fullscreen' || screen.includes('Showing detailed transcript'));
      }, { timeout: 10000 }).toBe(true);
      observation.visible = true;
    } finally {
      observation.screen = screen;
      const file = 'resumed-compaction-history-' + mode + '.png';
      await page.screenshot({ path: join(output, file), animations: 'disabled' });
      proof.captures.push(file);
    }
    return screen;
  };
  const normalScreen = await seeHint('terminal');
  await input.focus();
  await input.press('Control+o');
  await seeHint('fullscreen', normalScreen);
  await input.press('Control+o');
  await section.getByRole('button', { name: 'Back to conversation', exact: true }).click();
  const app = await context();
  const appBoundary = app.messages.find(row => row.context?.cliUuid === boundary.uuid);
  const appSummary = app.messages.find(row => row.context?.cliUuid === summary.uuid);
  assert.ok(appBoundary && appSummary);
  const earlierNativeInputs = sources.slice(0, sources.indexOf(boundary)).filter(row =>
    row.type === 'user' && ['sdk', 'human'].includes(row.turnOrigin));
  assert.ok(earlierNativeInputs.length);
  history.defaultChat = {
    boundary: appBoundary.context.cliUuid, summary: appSummary.context.cliUuid,
    earlierInputs: earlierNativeInputs.map(row => {
      const mirrors = app.messages.filter(message => message.sender === 'user' && message.context?.cliUuid === row.uuid);
      return { uuid: row.uuid, text: row.message.content, available: mirrors.length === 1 && mirrors[0].text === row.message.content };
    }),
    views: [],
  };
  const locate = page.locator('[data-message-id="' + appBoundary.id + '"]');
  for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
    await page.setViewportSize(viewport);
    await expect(composer).toHaveText(retainedDraft);
    await locate.scrollIntoViewIfNeeded();
    await expect(locate).toBeInViewport();
    const text = await locate.innerText();
    history.defaultChat.views.push({ size, text, locationHint: text.includes(locatorText) });
    const file = 'resumed-compaction-history-composer-' + size + '.png';
    await page.screenshot({ path: join(output, file), animations: 'disabled' });
    proof.captures.push(file);
  }
  assert.equal((await context()).claude.sessionId, proof.sessionId);
}
