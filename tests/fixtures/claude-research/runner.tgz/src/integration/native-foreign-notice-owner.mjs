import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,stat} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createServer} from 'node:https';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {prepareNativeCreditTls} from '../protocol/native-credit-billing.mjs';
import {MANAGED_SECURITY_KEY} from '../protocol/native-managed-security-fixture.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');
const trigger='Ask the plugin-owned release question.';
const question='Who should receive the release review?';
/** Native-only original $.tool.call ownership; this does not claim mounted app acceptance. */
export async function probeForeignNoticeOwner({checkout,workspace,setupWorkspace}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
 const executable='/frozen-claude/claude';assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');
 assert.equal(process.env.APACK_ENV,'test');assert.equal(process.env.APACK_USER_DATA_DIR,join(setupWorkspace,'app-data'));
 const userDataDir=join(setupWorkspace,'app-data'),project=join(setupWorkspace,'project'),configDir=join(userDataDir,'claude-code-profile/config');
 const settingsPath=join(configDir,'settings.json'),original=await readFile(settingsPath),saved=JSON.parse(await readFile(join(configDir,'.claude.json'),'utf8'));
 assert.equal(saved.projects?.[project]?.hasTrustDialogAccepted,true);assert.ok(saved.customApiKeyResponses?.approved?.includes(MANAGED_SECURITY_KEY.slice(-20)));
 await mkdir(join(workspace,'results'),{recursive:true});const output=join(workspace,'results');await writeFile(join(output,'settings-before.json'),original,{flag:'wx',mode:0o600});
 const proof={status:'running',scope:'Native original plugin-raised question ownership only; actual-app foreign-owner notice verification remains open.',steps:[],requests:[]};
 const save=()=>writeFile(join(output,'foreign-notice-owner.json'),JSON.stringify(proof,null,2));
 const phase=async(name,data={})=>{proof.steps.push({at:Date.now(),name,...data});await save()};
 const abort=new AbortController();let timer,model,server,seed,native,prepared;
 const until=async(check,label)=>{for(;;){abort.signal.throwIfAborted();const value=await check();if(value)return value;await new Promise(resolve=>setTimeout(resolve,100));}};
 const load=name=>import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code',name+'.ts')).href);
 try{
  timer=setTimeout(()=>abort.abort(Error('Foreign notice native journey exceeded120s')),120000);timer.unref();
  const owner=join(workspace,'owner-plugin'),peer=join(workspace,'peer-plugin');
  for(const [directory,name]of [[owner,'release-notice-owner'],[peer,'release-notice-peer']]){await mkdir(join(directory,'.claude-plugin'),{recursive:true});await mkdir(join(directory,'hooks'));await writeFile(join(directory,'.claude-plugin/plugin.json'),JSON.stringify({name,version:'0.0.1'}));await writeFile(join(directory,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));}
  const ownerSource=`export function register(on){let lastQuestionId;on('prompt.submit',async($,e,next)=>{if(e.text===${JSON.stringify(trigger)}){const result=await $.ui.ask(${JSON.stringify(question)},{header:'Audience',multiSelect:false,options:['Developers','Operators']});await $.fs.write('foreign-notice-owner-result.json',JSON.stringify({toolUseId:lastQuestionId,result}));}return next(e)});on('tool.call',{tool:'AskUserQuestion'},async($,e,next)=>{lastQuestionId=e.tool_use_id;await $.ui.notice(e.tool_use_id,'Owner release policy remains authoritative.');await $.fs.write('foreign-notice-owner-enqueue.json',JSON.stringify({toolUseId:e.tool_use_id,enqueued:true}));return next(e)});}`;
  const peerSource=`export function register(on){on('tool.call',{tool:'AskUserQuestion'},async($,e,next)=>{await $.ui.notice(e.tool_use_id,'FOREIGN_NOTICE_MUST_NOT_APPEAR');await $.fs.write('foreign-notice-peer-enqueue.json',JSON.stringify({toolUseId:e.tool_use_id,enqueued:true}));return next(e)});}`;
  for(const [directory,source]of [[owner,ownerSource],[peer,peerSource]])await writeFile(join(directory,'hooks/register.ts'),source);
  proof.plugins={owner:{name:'release-notice-owner',sha256:sha(ownerSource)},peer:{name:'release-notice-peer',sha256:sha(peerSource)}};
  const quote=s=>"'"+s.replaceAll("'","'\"'\"'")+"'",launcher=join(workspace,'launch-claude'),debug=join(workspace,'native-debug.log');
  await writeFile(launcher,'#!/bin/sh\nexec '+quote(executable)+' --debug-file '+quote(debug)+' "$@"\n',{mode:0o700});
  const tls=await prepareNativeCreditTls(join(workspace,'tls'));server=createServer({key:await readFile(tls.key),cert:await readFile(tls.cert)},(req,res)=>{req.resume();assert.ok(proof.requests.length<200);const path=new URL(req.url,'https://api.anthropic.com').pathname;proof.requests.push({method:req.method,path,foreignKey:!!req.headers['x-api-key']&&req.headers['x-api-key']!==MANAGED_SECURITY_KEY});const ok=['/api/hello','/v1/oauth/hello'].includes(path);res.writeHead(req.method==='GET'&&path==='/api/claude_code/settings'?204:ok?200:404,{'content-type':'application/json'});res.end(ok?'{}':'');});
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(443,'127.0.0.1',resolve)});
  model=await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:4,textReply:'The release audience choice is saved.'});
  const env={...process.env,HOME:join(setupWorkspace,'home'),CLAUDE_CONFIG_DIR:configDir,CLAUDE_SECURESTORAGE_CONFIG_DIR:undefined,ANTHROPIC_API_KEY:MANAGED_SECURITY_KEY,ANTHROPIC_BASE_URL:model.url,NODE_EXTRA_CA_CERTS:tls.ca,DISABLE_AUTOUPDATER:'1'};
  await writeFile(settingsPath,JSON.stringify({...JSON.parse(original),apiKeyHelper:'/usr/bin/printf '+MANAGED_SECURITY_KEY,statusLine:{type:'command',command:'/usr/bin/printf NativeNoticeOwnerReady',refreshInterval:1}}));
  const {query}=await load('query');seed=await query({cliPath:launcher,cwd:project,env,permissionMode:'default',pluginDir:[owner,peer],tools:[],strictMcpConfig:true,keepStdinOpen:true,signal:abort.signal});await seed.initialized;const settings=await seed.getSettings();
  seed.send('Prepare the private release notice ownership review.');let sessionId;for await(const event of seed.events){if(event.type==='result'){assert.equal(event.is_error,false);proof.seedResult=event;sessionId=event.session_id;break;}}
  assert.ok(sessionId);await seed.close();seed=undefined;proof.sessionId=sessionId;await phase('seed-complete');
  const {prepareClaudeNativeTerminal}=await load('terminal-owner');prepared=await prepareClaudeNativeTerminal({cliPath:launcher,sessionId,cwd:project,settings,permissionMode:'default',pluginDir:[owner,peer],env,signal:abort.signal});native=await prepared.start();
  await until(()=>native.state.status==='live'&&native.state.view?.kind==='main'&&native.state.mainStatus?.includes('NativeNoticeOwnerReady'),'native-ready');proof.ownerId=native.state.ownerId;proof.nativePid=native.state.nativePid;await phase('native-ready');
  const submission=native.submit(trigger).then(input=>{proof.input=input;return {ok:true}},error=>{proof.submissionProblem=String(error);return {ok:false}});
  const dialogs=await until(async()=>{const rows=await native.getQuestionDialogs();return rows.length===1?rows:undefined},'original-plugin-question');const dialog=dialogs[0];proof.questionBefore=dialog;
  assert.equal(dialog.shownInput.questions[0].question,question);
  const ownerReceipt=JSON.parse(await readFile(join(project,'foreign-notice-owner-enqueue.json'),'utf8')),peerReceipt=JSON.parse(await readFile(join(project,'foreign-notice-peer-enqueue.json'),'utf8'));assert.equal(ownerReceipt.toolUseId,dialog.requestId);assert.equal(peerReceipt.toolUseId,dialog.requestId);assert.ok(ownerReceipt.enqueued&&peerReceipt.enqueued);proof.enqueue={owner:ownerReceipt,peer:peerReceipt};
  await until(async()=>{const [current]=await native.getQuestionDialogs();return current?.presentation?.notice?.includes('Owner release policy remains authoritative.')},'original-owner-note');
  const info=await stat(debug);assert.ok(info.size<=8*1048576);const log=await readFile(debug,'utf8'),warning='$.ui.notice: '+dialog.requestId+" refused: the call is another plugin's $.tool.call run";assert.ok(log.includes(warning),'Original core foreign-owner refusal missing');proof.originalRefusal=warning;proof.debugSha256=sha(log);
  const [current]=await native.getQuestionDialogs();assert.equal(current.id,dialog.id);assert.equal(current.revision,dialog.revision);assert.ok(!JSON.stringify(current).includes('FOREIGN_NOTICE_MUST_NOT_APPEAR'));proof.questionAfter=current;await phase('foreign-notice-refused');
  proof.questionHoldMs=6000;await new Promise(resolve=>setTimeout(resolve,proof.questionHoldMs));const [held]=await native.getQuestionDialogs();assert.equal(held.id,current.id);assert.equal(held.revision,current.revision);proof.questionAfterHold=held;await phase('original-question-remains-open');
  await native.answerQuestionDialog({id:current.id,revision:current.revision,sessionId,answer:{answers:{[question]:'Operators'},annotations:{}}});
  await until(async()=>{try{const result=JSON.parse(await readFile(join(project,'foreign-notice-owner-result.json'),'utf8'));return result.toolUseId===dialog.requestId?result:undefined}catch(e){if(e.code==='ENOENT')return;throw e}},'original-tool-result');proof.toolResult=JSON.parse(await readFile(join(project,'foreign-notice-owner-result.json'),'utf8'));assert.ok(JSON.stringify(proof.toolResult).includes('Operators'));
  const outcome=await submission;assert.equal(outcome.ok,true,proof.submissionProblem);assert.equal(proof.input.sessionId,sessionId);
  await until(()=>model.calls.filter(call=>call.path.startsWith('/v1/messages')).length===2&&!native.state.busy&&native.state.lastTurn?.reason==='answer','ordinary-continuation');assert.equal((await native.getQuestionDialogs()).length,0);assert.equal(native.state.sessionId,sessionId);proof.final=native.state;assert.equal(proof.final.busy,false);assert.equal(proof.final.lastTurn?.reason,'answer');await native.close();native=undefined;proof.nativeClosed=true;proof.status='complete';await phase('complete');
 }catch(error){proof.status='failed';proof.problem=String(error.stack??error).slice(0,6000);throw error;}finally{
  clearTimeout(timer);const cleanup=[];
  for(const close of [async()=>{if(native)await native.close()},async()=>{if(prepared)await prepared.dispose()},async()=>{if(seed)await seed.close()},async()=>{if(model){proof.modelCalls=model.calls;await model.close()}},async()=>{if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}}])try{await close()}catch(error){cleanup.push(String(error))}
  proof.cleanupProblems=cleanup;
  await writeFile(settingsPath,original);assert.deepEqual(await readFile(settingsPath),original);proof.settingsRestoration={beforeSha256:sha(original),restoredSha256:sha(await readFile(settingsPath))};assert.ok(!proof.requests.some(r=>r.foreignKey));await save();assert.equal(cleanup.length,0,'Owned cleanup failed');
 }
 return proof;
}
