import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {decisionCancellationJourney} from './apack-decision-cancellation-drive.mjs';
import {rejectionJourney} from './apack-main-question-rejection-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {installOwnedNativeViewRelay,verifyNativeViewReconnect} from './owned-native-view-relay.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
import {record} from '../protocol/record.mjs';
import {writeQuestionRelabelPlugin} from '../protocol/native-question-relabel-fixture.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function alive(pid,start){try{const s=await readFile('/proc/'+pid+'/stat','utf8'),f=s.slice(s.lastIndexOf(')')+2).split(' ');return f[0]!=='Z'&&f[19]===start}catch(e){if(e.code==='ENOENT')return false;throw e}}

/** Current frozen app, fresh disposable account, original question producer; no private rollout overrides. */
export async function driveFreshQuestionRecovery({checkout,workspace,env,reconnect=false,decisionCancellation=false,brokerLoss=false,clarification=false,relabeled=false,images=false,imageEdges=false,cancelQuestionImage=false,heldQuestionConversion=false,extendedClarification=false,invalidImageRecovery=false}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-question[0-9]+$/);
 assert.ok(!(relabeled||images||imageEdges)||clarification);
 assert.ok(!(images&&imageEdges));
 assert.ok(!invalidImageRecovery||!(reconnect||decisionCancellation||brokerLoss||clarification||relabeled||images||imageEdges||cancelQuestionImage||extendedClarification));
 assert.ok(!extendedClarification||clarification&&!relabeled&&!images&&!imageEdges);
 assert.ok(!cancelQuestionImage||decisionCancellation&&!clarification&&!brokerLoss);
 assert.ok(!heldQuestionConversion||cancelQuestionImage);
 const conversionHold=heldQuestionConversion?join(workspace,'conversion-hold'):undefined;
 if(conversionHold)await mkdir(conversionHold,{mode:0o700});
 if(brokerLoss){
  const isolation=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(isolation.requireBrokerQuestionLoss&&isolation.networkDisabled&&isolation.pinnedExecutableReadOnly&&isolation.profileTmpfs);
  assert.ok(!reconnect&&!decisionCancellation&&!clarification);
 }
 const project=join(workspace,'project');await mkdir(project);await writeFile(join(project,'release-notes.md'),'# Release notes\n\nChoose a release audience before writing the summary.\n');execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),configPath=join(workspace,'.claude/.claude.json'),settingsPath=join(workspace,'.claude/settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({theme:'dark',model:'opus',...(decisionCancellation?{permissions:{ask:['Read','EnterPlanMode']}}:{})}));const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath);
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:extendedClarification,...(extendedClarification?{nativeLaunchProfile:'sdk-cli extended question flags'}:{}),config,settings:JSON.parse(settingsBefore)},null,2));
 if(decisionCancellation)await writeFile(join(workspace,'release-checklist.md'),'# Release checklist\n\nPreserve existing migration guidance.\n');
 let waiting,release;const model=await startSyntheticAgentModel({launchAgent:false,parentLaunchOnce:true,everydayProbe:true,questionProbe:true,questionRecoveryProbe:true,questionClarificationProbe:clarification,extendedQuestionClarification:extendedClarification,...(decisionCancellation?{referenceFile:join(workspace,'release-checklist.md'),referenceRetry:true,planEntryProbe:true}:{}),captureMessages:true,requestLimit:16,beforeDecision:async tool=>{assert.ok((decisionCancellation?['AskUserQuestion','Read','EnterPlanMode']:['AskUserQuestion']).includes(tool));assert.equal(waiting,undefined);waiting=tool;await new Promise(resolve=>{release=resolve})}});
 const controlled={...model,releaseDecision(tool){assert.equal(waiting,tool);waiting=undefined;const done=release;release=undefined;done()},get waiting(){return waiting},releaseQuestion(){assert.equal(waiting,'AskUserQuestion');waiting=undefined;const done=release;release=undefined;done()}};
 const tls=await prepareNativeCreditTls(join(workspace,'account-tls')),billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
 try{
  const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  if(conversionHold)Object.assign(launchEnv,{
   CLAUDE_RESEARCH_QUESTION_CONVERSION_HOLD:conversionHold,
   CLAUDE_RESEARCH_QUESTION_API_NODE_OPTIONS:env.NODE_OPTIONS,
  });
  if(extendedClarification) Object.assign(launchEnv,{
   CLAUDE_CODE_ENTRYPOINT:'sdk-cli',
   CLAUDE_CODE_QUESTION_EXTENDED:'1',
   CLAUDE_CODE_QUESTION_OPTIONAL_DESCRIPTIONS:'1',
  });
  const label=relabeled?'Who should read these release notes?':undefined;
  if(label) await installClarificationRelabel({workspace,project,env:launchEnv,configDir:join(workspace,'.claude'),label});
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:invalidImageRecovery?'real-Electron-question-invalid-image-recovery':extendedClarification?'real-Electron-extended-question-clarification':heldQuestionConversion?'real-Electron-held-question-image-cancellation':cancelQuestionImage?'real-Electron-question-image-cancellation':brokerLoss?'real-Electron-broker-question-loss':imageEdges?'real-Electron-question-image-edges':images?'real-Electron-question-images':relabeled?'real-Electron-relabeled-question-clarification':clarification?'real-Electron-question-clarification':'real-Electron-fresh-question-recovery',journeyBudgetMs:decisionCancellation?180000:150000,journey:async args=>{const relay=reconnect?await installOwnedNativeViewRelay(args.electronApp):undefined;try{await (decisionCancellation?decisionCancellationJourney:rejectionJourney)({...args,model:controlled,freshProfile:true,addressedReplay:true,brokerLoss,clarification,label,images,imageEdges,cancelQuestionImage,conversionHold,extendedClarification,invalidImageRecovery,...(relay?{nativeViewReconnect:options=>verifyNativeViewReconnect({...options,relay})}:{})});}finally{if(relay)await writeFile(join(workspace,'electron-results/native-view-relay-restoration.json'),JSON.stringify(await relay.close(),null,2));}}});
 }finally{
  release?.();await model.close();await billing.close();await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2));await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2));
  const output=join(workspace,'electron-results');let proof;try{proof=JSON.parse(await readFile(join(output,decisionCancellation?'decision-cancellation.json':'main-question-rejection.json'),'utf8'))}catch(error){if(error.code!=='ENOENT')throw error}
  if((await Promise.all((proof?.owners??(proof?.pid?[proof]:[])).map(owner=>alive(owner.pid,owner.processStart)))).some(Boolean))await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:false,nativeWriterStillAlive:true}));
  else{
   await writeFile(join(output,'native-config-after.json'),await readFile(configPath));await writeFile(configPath,configBefore);await writeFile(settingsPath,settingsBefore);assert.deepEqual(await readFile(configPath),configBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);
   await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configRestored:true,configSha256:sha(configBefore),settingsSha256:sha(settingsBefore)}));
   if(proof?.sessionId){const root=join(workspace,'.claude/projects'),files=await readdir(root,{recursive:true}),matches=files.filter(name=>basename(name)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);await writeFile(join(output,'native-parent-transcript.jsonl'),await readFile(join(root,matches[0])));}
  }
 }
}


async function installClarificationRelabel({workspace,project,env,configDir,label}) {
 const market=basename(workspace),marketplace=join(workspace,'marketplace'),plugin=join(marketplace,'release-question-label');
 await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});
 await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({
  name:market,owner:{name:'Local release review'},plugins:[{name:'release-question-label',source:'./release-question-label'}],
 }));
 const source=await writeQuestionRelabelPlugin(plugin,'Who should the release summary address?',label);
 const executable='/frozen-claude/claude',runs=[];
 for(const command of [['validate',plugin],['marketplace','add',marketplace],['install','release-question-label@'+market]]) {
  const run=await record({executable,cwd:project,output:join(workspace,'installation'),env,
   args:['--setting-sources','','plugin',...command],timeoutMs:20000,maxBytes:1048576});
  assert.equal(run.status,'complete');
  runs.push(run);
 }
 const registry=JSON.parse(await readFile(join(configDir,'plugins/installed_plugins.json'),'utf8'));
 const rows=registry.plugins?.['release-question-label@'+market];
 assert.ok(rows?.length===1&&rows[0].scope==='user');
 const hash=sha(Buffer.from(source));
 assert.equal(sha(await readFile(join(rows[0].installPath,'hooks/register.ts'))),hash);
 await writeFile(join(workspace,'question-relabel-installation.json'),JSON.stringify({runs,pluginSha256:hash,label,originalBinarySha256:sha(await readFile(executable))},null,2));
}
