import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {rejectionJourney} from './apack-main-question-rejection-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {installOwnedNativeViewRelay,verifyNativeViewReconnect} from './owned-native-view-relay.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function alive(pid,start){try{const s=await readFile('/proc/'+pid+'/stat','utf8'),f=s.slice(s.lastIndexOf(')')+2).split(' ');return f[0]!=='Z'&&f[19]===start}catch(e){if(e.code==='ENOENT')return false;throw e}}

/** Current frozen app, fresh disposable account, original question producer; no private rollout overrides. */
export async function driveFreshQuestionRecovery({checkout,workspace,env,reconnect=false}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-question[0-9]+$/);
 const project=join(workspace,'project');await mkdir(project);await writeFile(join(project,'release-notes.md'),'# Release notes\n\nChoose a release audience before writing the summary.\n');execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),configPath=join(workspace,'.claude/.claude.json'),settingsPath=join(workspace,'.claude/settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({theme:'dark',model:'opus'}));const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath);
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,config,settings:JSON.parse(settingsBefore)},null,2));
 let waiting,release;const model=await startSyntheticAgentModel({launchAgent:false,parentLaunchOnce:true,everydayProbe:true,questionProbe:true,questionRecoveryProbe:true,captureMessages:true,requestLimit:16,beforeDecision:async tool=>{assert.equal(tool,'AskUserQuestion');assert.equal(waiting,undefined);waiting=tool;await new Promise(resolve=>{release=resolve})}});
 const controlled={...model,get waiting(){return waiting},releaseQuestion(){assert.equal(waiting,'AskUserQuestion');waiting=undefined;const done=release;release=undefined;done()}};
 const tls=await prepareNativeCreditTls(join(workspace,'account-tls')),billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
 try{
  const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-fresh-question-recovery',journeyBudgetMs:150000,journey:async args=>{const relay=reconnect?await installOwnedNativeViewRelay(args.electronApp):undefined;try{await rejectionJourney({...args,model:controlled,freshProfile:true,addressedReplay:true,...(relay?{nativeViewReconnect:options=>verifyNativeViewReconnect({...options,relay})}:{})});}finally{if(relay)await writeFile(join(workspace,'electron-results/native-view-relay-restoration.json'),JSON.stringify(await relay.close(),null,2));}}});
 }finally{
  release?.();await model.close();await billing.close();await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2));await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2));
  const output=join(workspace,'electron-results');let proof;try{proof=JSON.parse(await readFile(join(output,'main-question-rejection.json'),'utf8'))}catch(error){if(error.code!=='ENOENT')throw error}
  if(proof?.pid&&await alive(proof.pid,proof.processStart))await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:false,nativeWriterStillAlive:true}));
  else{
   await writeFile(join(output,'native-config-after.json'),await readFile(configPath));await writeFile(configPath,configBefore);await writeFile(settingsPath,settingsBefore);assert.deepEqual(await readFile(configPath),configBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);
   await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configRestored:true,configSha256:sha(configBefore),settingsSha256:sha(settingsBefore)}));
   if(proof?.sessionId){const root=join(workspace,'.claude/projects'),files=await readdir(root,{recursive:true}),matches=files.filter(name=>basename(name)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);await writeFile(join(output,'native-parent-transcript.jsonl'),await readFile(join(root,matches[0])));}
  }
 }
}
