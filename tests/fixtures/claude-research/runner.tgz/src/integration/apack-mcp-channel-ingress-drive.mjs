import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {readNativeTranscriptRow} from './native-transcript-evidence.mjs';
import {channelBody,channelRelease} from '../protocol/owned-mcp-channel-server.mjs';
import {channelSelector,channelServer} from './owned-channel-installation.mjs';

export async function driveOwnedChannelIngress({page,expect,context,composer,section,proof,output,debug,receipts,release,model,birth,save,phase}) {
  proof.scope='Original admitted channel from an owned local marketplace with hosted rollout served by the isolated account fixture.';
  const registration='MCP server "'+channelServer+'": Channel notifications registered';
  const debugLog=()=>readFile(debug,'utf8');
  await expect.poll(async()=> (await debugLog()).includes(registration),{timeout:18000}).toBe(true);
  proof.channelDiagnostics=(await debugLog()).split('\n').filter(line=>line.endsWith(registration));
  const args=(await readFile('/proc/'+proof.pid+'/cmdline','utf8')).split('\0');
  const channelFlag=args.indexOf('--channels');
  assert.ok(channelFlag>0);
  assert.equal(args[channelFlag+1],channelSelector);
  assert.ok(!args.includes('--dangerously-load-development-channels'));
  proof.nativeArgvChannel=args.slice(channelFlag,channelFlag+2);
  assert.deepEqual((await context()).claude.nativeLaunch.channels,[channelSelector]);
  const callsBefore=model.calls.length;
  await writeFile(release,channelRelease,{flag:'wx'});
  const delivered=()=>model.calls.slice(callsBefore).filter(call=>call.messages?.some(message=>
    message.role==='user'&&Array.isArray(message.content)&&message.content.some(block=>
      block.type==='text'&&block.text.includes('<channel source="'+channelServer+'"')&&block.text.includes(channelBody))));
  await expect.poll(()=>delivered().length,{timeout:20000}).toBe(1);
  const projected=async()=> (await context()).messages.filter(message=>message.text===channelBody);
  await expect.poll(async()=> (await projected()).map(message=>message.sender)).toEqual(['system']);
  const [message]=await projected();
  assert.deepEqual(message.context.claudeNativeChannel,{server:channelServer});
  assert.ok(!message.context.claudeNativeUserMessage&&message.context.cliUuid);
  proof.projectedChannel=message;
  await expect.poll(async()=>{
    const state=await context();
    const index=state.messages.findIndex(row=>row.id===message.id);
    return index>=0&&!state.native.state.busy&&state.claude.chatState==='success'
      &&state.messages.slice(index+1).some(row=>row.sender==='assistant'&&row.context?.cliUuid);
  },{timeout:20000}).toBe(true);
  const item=page.locator('[data-message-id="'+message.id+'"]');
  for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
    await page.setViewportSize({width,height});
    await readNativeTranscriptRow(page,expect,item);
    await expect(item.getByText('Channel · '+channelServer,{exact:true})).toBeInViewport({ratio:1});
    await expect(item.getByText(channelBody,{exact:true}).and(page.locator(':visible'))).toBeInViewport({ratio:1});
    await expect(composer).toHaveText(proof.draft);
    const name='native-channel-ingress-'+size+'.png';
    await page.screenshot({path:join(output,name),animations:'disabled'});
    proof.captures.push(name);
    await save();
  }
  const wire=(await readFile(receipts,'utf8')).trim().split('\n').map(JSON.parse);
  const emitted=wire.filter(row=>row.direction==='out'&&row.value.method==='notifications/claude/channel');
  assert.equal(emitted.length,1);
  assert.equal(emitted[0].value.params.content,channelBody);
  assert.ok(!wire.some(row=>row.direction==='in'&&row.value.method==='tools/call'));
  proof.final=await context();
  assert.equal(proof.initial.threadId,proof.final.threadId);
  assert.equal(proof.sessionId,proof.final.claude.sessionId);
  assert.equal(proof.pid,proof.final.native.state.nativePid);
  assert.equal(await birth(proof.pid),proof.processStart);
  assert.equal(delivered().length,1);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
  proof.status='complete';
  await save();
  phase('native-channel-ingress-complete');
}
