import {existsSync} from 'node:fs';
import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat,mkdir,rm} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';

export async function driveChildPermissions(options) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv'));assert.ok(existsSync('/control/offline-verified'));assert.equal(options.setupWorkspace,'/work/.claude-research/profile-setup-app10');
 const root=join(options.setupWorkspace,'project/.claude/skills'),created=[];
 try {
  await mkdir(root,{recursive:true});
  for(const suffix of ['once','deny']){const name='research-child-release-review-'+suffix,directory=join(root,name);await mkdir(directory);created.push(directory);await writeFile(join(directory,'SKILL.md'),'---\nname: '+name+'\ndescription: Review local migration notes without commands.\nallowed-tools: Read\n---\nReview the release checklist. ResearchNativeSkillBody: '+name+'.\n',{flag:'wx'});}
  return await driveChildComposer({...options,modelTool:'TextOnly',modelOptions:{childPermissionScenario:true},modelRequestLimit:24,journey:permissionsJourney,askBeforeToolPermissions:true,journeyName:'permissions'});
 } finally {for(const directory of created.reverse())await rm(directory,{recursive:true});}
}
async function permissionsJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const proof={status:'running',parentSessionId,scope:'Original child Skill allow/deny and WebFetch deny/allowed offline attempt; no successful HTTP or full parity claim.',captures:[],sizes:[]};
 const save=()=>writeFile(join(output,'child-permissions.json'),JSON.stringify(proof,null,2));
 const hasResult=stage=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id==='native_child_permission_'+stage);
 const result=async(stage,error)=>{
  const read=async()=>{
   const cached=hasResult(stage);if(cached){(proof.resultOrigins??={})[stage]='model';return cached;}
   if(!proof.target)return;
   const projects=join(userDataDir,'claude-code-profile/config/projects');
   for(const entry of(await readdir(projects,{withFileTypes:true})).slice(0,64)){
    if(!entry.isDirectory())continue;const path=join(projects,entry.name,proof.target.sessionId+'.jsonl');let info;
    try{info=await lstat(path)}catch(e){if(e.code==='ENOENT')continue;throw e}
    assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);
    const rows=raw.toString().split('\n').filter(Boolean).map(line=>JSON.parse(line)),value=rows.flatMap(row=>Array.isArray(row.message?.content)?row.message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id==='native_child_permission_'+stage);
    if(value){(proof.resultOrigins??={})[stage]='original-journal';return value;}
   }
  };
  await expect.poll(read,{timeout:15000}).toBeTruthy();const value=await read();assert.equal(value.is_error===true,error);proof['result'+stage]=value;await save();
 };
 const capture=async(name)=>{await page.screenshot({path:join(output,name+'.png')});proof.captures.push(name+'.png');await save();};
 const sizes=[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]];
 try {
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill('/background ResearchChildPermission1 Use the local release review skill after approval.');await card.getByRole('button',{name:'Send',exact:true}).click();
  const widget=page.getByRole('region',{name:'Background Claude session',exact:true});
  await expect(widget.getByRole('button',{name:'Review request',exact:true})).toBeEnabled({timeout:25000});
  proof.running=await context();proof.target=proof.running.native.background.desktop;assert.ok(proof.target);proof.discoveredWithReplyClosed=true;
  await composer.fill('Keep the parent permission review notes here.');const parentDraft=await composer.textContent();
  await widget.getByRole('button',{name:'Review request',exact:true}).click();proof.previews=[];proof.detailReading=[];
  for(const stage of [1,2,3,4]){
   const tool=stage<=2?'Skill':'WebFetch',denied=stage===2||stage===3;
   if(stage>1){const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');await expect(editor).toBeEditable();await editor.fill('ResearchChildPermission'+stage+' Review the next original permission request.');await form.getByRole('button',{name:'Send message',exact:true}).click();}
   const panel=widget.getByRole('region',{name:tool+' approval',exact:true});await expect(panel).toBeVisible({timeout:20000});
   const c=await context(),pair=Object.entries(c.ui).find(([,v])=>v.state?.approval?.control?.dialog?.sessionId===proof.target.sessionId);assert.ok(pair);
   const frame={mountId:pair[0],frame:pair[1].state.approval};proof.previews.push(frame);assert.equal(frame.frame.control.kind,'tool');assert.equal(frame.frame.control.dialog.toolName,tool);
   if(stage===1)proof.firstApproval=frame;
   else{await page.evaluate(({threadId,mountId,frameId})=>window.applicationState.system.get('default-setup/threads').send({type:'CLAUDE_UI_APPROVAL_ANSWER',threadId,mountId,frameId,answer:{approved:false}}),{threadId:proof.running.threadId,mountId:frame.mountId,frameId:proof.firstApproval.frame.id});proof.oldDenialReplayed=true;}
   const presentation=frame.frame.control.dialog.presentation,yes=presentation.choices.find(choice=>choice.value==='yes'),no=presentation.choices.find(choice=>choice.value==='no');assert.ok(yes);assert.ok(no);const label=denied?'Deny':yes.label;
   const details=panel.locator('.details'),last=panel.locator('.tool-details dd').last();await expect(last).toBeVisible();
   for(const[name,size]of sizes){await page.setViewportSize(size);await details.hover();await page.mouse.wheel(0,-800);const delta=await last.evaluate(element=>{const r=element.getBoundingClientRect(),d=element.closest('.details').getBoundingClientRect();return Math.round(r.top+r.height/2-d.top-d.height/2)});await details.hover();await page.mouse.wheel(0,delta);await expect(last).toBeInViewport({ratio:1});await expect(panel.getByRole('button',{name:label,exact:true})).toBeInViewport({ratio:1});proof.detailReading.push({stage,name,...await details.evaluate(element=>({scrollTop:element.scrollTop,clientHeight:element.clientHeight,scrollHeight:element.scrollHeight}))});await capture('child-permission-'+stage+'-'+name);}
   if(denied&&no.feedback){await panel.getByText('Add feedback',{exact:true}).click();const feedback=panel.getByRole('textbox',{name:'Feedback for Claude',exact:true});await feedback.fill('Keep the original release notes.');await panel.getByRole('button',{name:'Back to parent notes',exact:true}).click();await expect(composer).toBeFocused();await expect(composer).toHaveText(parentDraft);await widget.getByRole('button',{name:'Review request',exact:true}).click();await expect(feedback).toHaveValue('Keep the original release notes.');proof.denialDraftRetained=true;}
   if(denied&&!no.feedback)await expect(panel.getByText('Add feedback',{exact:true})).toHaveCount(0);
   await panel.getByRole('button',{name:label,exact:true}).click();await expect(panel).toHaveCount(0);await result(stage,stage!==1);
   if(denied&&no.feedback)assert.ok(JSON.stringify(proof['result'+stage]).includes('Keep the original release notes.'));
   if(denied&&!no.feedback){assert.ok(!presentation.choices.some(choice=>choice.feedback));proof.nativeNoFeedbackObserved=true;}
  }
  const messageText=JSON.stringify(model.calls.flatMap(call=>call.messages??[]));assert.ok(messageText.includes('ResearchNativeSkillBody: research-child-release-review-once'));assert.ok(!messageText.includes('ResearchNativeSkillBody: research-child-release-review-deny'));proof.originalSkillBodyObserved=true;proof.deniedSkillBodyAbsent=true;proof.successfulHttpFetch=false;
  const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');await expect(editor).toBeEditable();await editor.fill('Summarize the approved release check.');
  for(const[name,size]of sizes){await page.setViewportSize(size);await expect(form.getByRole('button',{name:'Send message',exact:true})).toBeInViewport({ratio:1});await capture('child-permissions-composer-'+name);}
  await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(editor).toHaveText('',{timeout:20000});await expect.poll(()=>model.calls.some(call=>call.messages?.some(message=>message.role==='user'&&message.content==='Summarize the approved release check.')),{timeout:15000}).toBe(true);proof.finalReplyObserved=true;
  const projects=join(userDataDir,'claude-code-profile/config/projects');proof.transcripts={};
  for(const kind of ['parent','child']){const sid=kind==='parent'?parentSessionId:proof.target.sessionId;for(const directory of(await readdir(projects,{withFileTypes:true})).slice(0,64)){if(!directory.isDirectory())continue;const path=join(projects,directory.name,sid+'.jsonl');let info;try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);await writeFile(join(output,'native-'+kind+'-transcript.jsonl'),raw);proof.transcripts[kind]={sessionId:sid,path,sha256:createHash('sha256').update(raw).digest('hex')};break;}assert.ok(proof.transcripts[kind]);}
  await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});
  const stopped=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(stopped.sessionId,proof.target.sessionId);assert.equal(stopped.state,'stopped');proof.nativeStopped={jobId:proof.target.jobId,sessionId:stopped.sessionId,state:stopped.state};proof.final=await context();proof.status='complete';await save();phase('original-child-permissions-complete');
 } catch(error) {
  proof.status='failed';proof.error=String(error.message).slice(0,4096);proof.failureContext=await context().catch(()=>null);
  await page.screenshot({path:join(output,'child-permissions-failure-before-cleanup.png')}).catch(()=>{});
  await save();throw error;
 } finally {
  const state=await context().catch(()=>null),sessionId=proof.target?.sessionId??state?.claude?.nativeContinuation?.continuedInSessionId;
  if(sessionId){const run=promisify(execFile),cliEnv={...env,CLAUDE_CONFIG_DIR:join(userDataDir,'claude-code-profile/config')};const rows=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024})).stdout);const owned=rows.find(row=>row.sessionId===sessionId&&row.cwd===project);if(owned&&owned.state!=='stopped'){await run('/frozen-claude/claude',['stop',owned.id],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024});proof.cleanupStoppedOwnedJob=true;}}
  await save();
 }
}
