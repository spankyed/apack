import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {nativeAutoModeAdmissionObserver} from '../protocol/native-auto-mode-admission.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {record} from '../protocol/record.mjs';

/** Compare original CLI default sources; print-mode evidence never substitutes for terminal/app admission. */
export async function probeNativeAutoModeInputs({workspace,executable,hashes}) {
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.match(workspace,/^\/work\/\.claude-research\/native-credit-admission-auto-mode-[a-z0-9-]+$/);
 assert.equal(createHash('sha256').update(await readFile(executable)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 await mkdir(workspace,{recursive:false});
 const project=join(workspace,'project');await mkdir(project);
 const results=[];
 for(const explicitMode of [false,true]){
  const home=join(workspace,'native-credit-admission-'+(explicitMode?'explicit':'settings'));await mkdir(home);
  const env=await configureNativeCreditAccount(home,'oauth',{featureCache:'native-defaults'});
  const configPath=join(env.CLAUDE_CONFIG_DIR,'.claude.json'),settingsPath=join(env.CLAUDE_CONFIG_DIR,'settings.json');
  const config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));
  await writeFile(settingsPath,JSON.stringify({theme:'dark',model:'claude-opus-5',permissions:{defaultMode:'acceptEdits'}}));
  const receiptPath=join(home,'auto-mode-admission.json'),preload=join(home,'admission-preload.mjs');await writeFile(preload,nativeAutoModeAdmissionObserver(receiptPath,hashes));
  const model=await startSyntheticModel(home,'TextOnly',{textReply:'Admission input probe complete.',maxRequests:2});
  try{
   const transport=await record({executable,args:['--print','--model','claude-opus-5',...explicitMode?['--permission-mode','acceptEdits']:[],'Describe this empty fixture in one sentence.'],cwd:project,env:{...env,PATH:'/usr/local/bin:/usr/bin:/bin',ANTHROPIC_BASE_URL:model.url,BUN_OPTIONS:'--preload='+preload,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},output:home,timeoutMs:30000,maxBytes:1048576});
   assert.equal(transport.status,'complete');
   const receipt=JSON.parse(await readFile(receiptPath,'utf8'));assert.equal(receipt.defaults.userSettings,'acceptEdits');assert.equal(receipt.defaults.projectSettings,null);assert.equal(receipt.defaults.localSettings,null);assert.equal(receipt.defaults.flagSettings,null);assert.deepEqual(receipt.functionHashes,hashes);
   results.push({explicitMode,transport:transport.directory,receipt,modelCalls:model.calls});
  }finally{await writeFile(join(home,'model-calls.json'),JSON.stringify(model.calls,null,2));await model.close();}
 }
 const proof={status:'complete',results,scope:'Two disposable original print-mode processes, native-default feature configuration, local synthetic inference. Records flag source effects only; no terminal nudge, served rollout or app acceptance.'};
 await writeFile(join(workspace,'auto-mode-inputs.json'),JSON.stringify(proof,null,2));return proof;
}
