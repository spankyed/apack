const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
assert.match(process.env.CLAUDE_RESEARCH_UI_PRESS_TRACE,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+\/ui-press$/);
const boundary=JSON.parse(fs.readFileSync('/control/offline-verified','utf8'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
process.env.NODE_OPTIONS=(process.env.NODE_OPTIONS??'')+' --import='+pathToFileURL(path.join(__dirname,'ui-press-preload.mjs')).href;
