import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,rename,lstat} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {record} from '../protocol/record.mjs';

/** Install our completion-delay hook through the original CLI, only in a fresh offline app profile. */
export async function prepareTurnCompletionProfile({workspace,env,delay}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
 assert.equal(typeof delay.source,'string');assert.ok(delay.source.startsWith('const socket=')&&delay.source.includes('export function register(on)')&&Buffer.byteLength(delay.source)<=32768);
 const config=join(workspace,'.claude'),market='turn-completion-check',marketplace=join(workspace,'completion-marketplace'),plugin=join(marketplace,'plugins/turn-completion-check');
 const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),executable='/frozen-claude/claude';
 assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 assert.equal(existsSync(marketplace),false);
 const saved=new Map();
 for(const name of ['settings.json','plugins/known_marketplaces.json','plugins/installed_plugins.json']){
  const path=join(config,name);let bytes;
  try{const info=await lstat(path);assert.ok(info.isFile()&&!info.isSymbolicLink()&&info.uid===1000&&info.size<=1048576);bytes=await readFile(path)}catch(error){if(error.code!=='ENOENT')throw error}
  saved.set(name,bytes);
 }
 assert.ok(saved.get('settings.json'));assert.equal(saved.get('plugins/known_marketplaces.json'),undefined);assert.equal(saved.get('plugins/installed_plugins.json'),undefined);
 let restored=false;
 async function restore(){
  if(restored)return;const files=[];
  for(const[name,before]of saved){
   const path=join(config,name);
   if(existsSync(path)){const info=await lstat(path);assert.ok(info.isFile()&&!info.isSymbolicLink()&&info.uid===1000);await rename(path,join(workspace,'preserved-completion-'+name.replaceAll('/','-')))}
   if(before!==undefined){await mkdir(join(path,'..'),{recursive:true});await writeFile(path,before,{mode:0o600,flag:'wx'});assert.deepEqual(await readFile(path),before)}else assert.equal(existsSync(path),false);
   files.push({path:name,present:before!==undefined,sha256:before===undefined?null:sha(before)});
  }
  await writeFile(join(workspace,'completion-profile-restoration.json'),JSON.stringify({restored:true,files}));restored=true;
 }
 try{
  await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
  await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:market,owner:{name:'Local lifecycle review'},plugins:[{name:'turn-completion-check',source:'./plugins/turn-completion-check'}]}));
  await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'turn-completion-check',version:'0.0.1'}));
  await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));await writeFile(join(plugin,'hooks/register.ts'),delay.source,{mode:0o600,flag:'wx'});
  const runs=[];
  for(const args of [['--setting-sources','','plugin','validate',plugin],['--setting-sources','','plugin','marketplace','add',marketplace],['--setting-sources','','plugin','install','turn-completion-check@'+market]]){
   const run=await record({executable,cwd:join(workspace,'project'),output:join(workspace,'completion-installation'),env:{...env,HOME:workspace,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},args,timeoutMs:20000,maxBytes:1048576});runs.push(run);assert.equal(run.code,0);assert.equal(run.status,'complete');
  }
  const entries=JSON.parse(await readFile(join(config,'plugins/installed_plugins.json'))).plugins?.['turn-completion-check@'+market];assert.equal(entries?.length,1);assert.equal(entries[0].scope,'user');
  assert.equal(sha(await readFile(join(entries[0].installPath,'hooks/register.ts'))),sha(Buffer.from(delay.source)));
  const settingsPath=join(config,'settings.json'),installedSettings=JSON.parse(await readFile(settingsPath));assert.equal(installedSettings.appendPlugins,undefined);installedSettings.appendPlugins=['turn-completion-check@'+market];await writeFile(settingsPath,JSON.stringify(installedSettings));
  const installation={runs,installation:entries[0],requestedHookOrdering:{source:'user-settings',setting:'appendPlugins',plugins:installedSettings.appendPlugins},sourceSha256:sha(Buffer.from(delay.source)),scope:'Original public local plugin registration/install in an owned profile; no model request, native gate override, manual registry or user profile mutation.'};
  await writeFile(join(workspace,'completion-profile-installation.json'),JSON.stringify(installation));return{restore,installation};
 }catch(error){await restore();throw error}
}
