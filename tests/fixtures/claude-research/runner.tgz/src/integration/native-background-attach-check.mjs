import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join,basename,isAbsolute} from 'node:path';
import {stripVTControlCharacters} from 'node:util';
import {record} from '../protocol/record.mjs';

/** Observe the original attach CLI; terminate only its owned client and recheck the live worker. */
export async function observeOriginalBackgroundAttach({executable,project,env,job,output,cli}) {
  assert.equal(process.platform,'linux');
  assert.ok(isAbsolute(executable)&&isAbsolute(project)&&isAbsolute(output));
  assert.ok(basename(env.HOME??'').startsWith('apack-terminal-owner-app-'));
  assert.match(job.id,/^[a-f0-9]{8}$/u);assert.ok(Number.isSafeInteger(job.pid)&&job.pid>1);
  const state=async()=>{const raw=await readFile('/proc/'+job.pid+'/stat','utf8');const fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return {state:fields[0],startTime:fields[19]};};
  const before=await state();assert.notEqual(before.state,'Z');
  let text='',frameSeen=false,timer;
  let run;
  try {
    run=await record({executable:'/usr/bin/python3',args:[new URL('../protocol/pty_bridge.py',import.meta.url).pathname,executable,'attach',job.id],cwd:project,env,output:join(output,'original-child-attach'),timeoutMs:20000,maxBytes:2*1024*1024,onStdout(bytes,channel){
      text+=bytes.toString('utf8');
      if(!frameSeen&&stripVTControlCharacters(text).includes('ParentSubagentFixtureComplete')) {frameSeen=true;timer=setTimeout(()=>channel.stop('owned-attach-frame-observed'),300);}
    }});
  } finally {clearTimeout(timer);}
  const listed=await cli('after-attach-client-exit',['agents','--json','--all','--cwd',project]);
  assert.equal(listed.status,'complete');
  const after=JSON.parse(listed.stdout).find(row=>row.id===job.id),processAfter=await state();
  const evidence={frameSeen,run,jobBefore:job,jobAfter:after,processBefore:before,processAfter,scope:'Original public attach command only; client ended by owned SIGTERM, not a graceful detach claim. App attachment, prompt/approval/question interaction and stopped-child resume remain unaccepted.'};
  await writeFile(join(output,'original-child-attach-observation.json'),JSON.stringify(evidence,null,2)+'\n');
  assert.ok(frameSeen,'Original child frame was not observed');assert.equal(run.reason,'owned-attach-frame-observed');
  assert.equal(after?.sessionId,job.sessionId);assert.equal(after?.pid,job.pid);assert.ok(['working','blocked'].includes(after.state));
  assert.equal(processAfter.startTime,before.startTime);assert.notEqual(processAfter.state,'Z');
  return evidence;
}
