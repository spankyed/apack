const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const { pathToFileURL } = require('node:url');
const { join } = require('node:path');

const directory = process.env.CLAUDE_RESEARCH_QUESTION_CONVERSION_HOLD;
assert.equal(process.platform, 'linux');
assert.equal(process.getuid(), 1000);
assert.match(directory, /^\/work\/\.claude-research\/apack-terminal-owner-app-question[0-9]+\/conversion-hold$/);
const boundary = JSON.parse(readFileSync('/control/offline-verified', 'utf8'));
assert.ok(boundary.requireHeldQuestionConversion && boundary.networkDisabled && boundary.pinnedExecutableReadOnly && boundary.profileTmpfs);
// Playwright clears NODE_OPTIONS from Electron. Restore the API child's test preload.
process.env.NODE_OPTIONS = (process.env.CLAUDE_RESEARCH_QUESTION_API_NODE_OPTIONS ?? '') +
  ' --import=' + pathToFileURL(join(__dirname, 'owned-question-conversion-hold.mjs')).href;
