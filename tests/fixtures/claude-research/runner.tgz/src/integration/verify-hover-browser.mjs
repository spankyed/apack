import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir, mkdtemp } from 'node:fs/promises';
import { join, resolve, isAbsolute } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const [checkoutArg, outputArg] = process.argv.slice(2);
assert.ok(checkoutArg && outputArg && isAbsolute(checkoutArg) && isAbsolute(outputArg));
const checkout = resolve(checkoutArg), output = resolve(outputArg);
assert.ok(output.startsWith('/private/tmp/'));
await mkdir(output, { recursive: true });
const workspace = await mkdtemp(join(output, 'hover-browser-'));
const require = createRequire(join(checkout, 'package.json'));
const { createServer } = await import(pathToFileURL(require.resolve('vite')).href);
const { default: vue } = await import(pathToFileURL(require.resolve('@vitejs/plugin-vue')).href);
const { _electron } = require('playwright'), { expect } = require('@playwright/test');
const directory = join(checkout, 'packages/default-setup/src/features/threads/fe/chat');
const sources = {};
for (const name of ['StatusLine.vue', 'NativeUiNode.vue', 'native-ui-hover.ts', 'native-ui-paint.ts']) sources[name] = createHash('sha256').update(await readFile(join(directory, name))).digest('hex');
const group = JSON.stringify(['fixture', 'shared']);
const tree = { kind: 'box', boxKey: 'root', paint: { borderStyle: 'single', borderColor: 'warning', borderDimColor: true }, hover: { paint: { borderStyle: 'double', borderColor: 'success' } }, children: [
  { kind: 'text', text: 'Trigger', style: { color: 'blue' }, hover: { group, text: { color: 'red' } } },
  { kind: 'text', text: 'Peer', style: { color: 'blue' }, hover: { group, text: { color: 'red' } } },
  { kind: 'text', text: 'Foreign', style: { color: 'blue' }, hover: { group: JSON.stringify(['other', 'shared']), text: { color: 'red' } } },
  { kind: 'box', layout: { position: 'absolute', top: 4, left: 1, display: 'none' }, hover: { layout: { display: 'flex' } }, children: [{ kind: 'text', text: 'Revealed' }] },
  { kind: 'text', text: 'Inverse', style: { color: 'blue', backgroundColor: 'yellow', inverse: true }, children: [{ kind: 'text', text: ' Normal', style: { inverse: false } }] },
] };
await writeFile(join(workspace, 'index.html'), '<!doctype html><html><head><style>body{background:#171717;color:#e5e5e5;font:14px/1.5 sans-serif;padding:20px}.font-semibold{font-weight:600}.italic{font-style:italic}.opacity-60{opacity:.6}#first,#second{width:500px;margin-bottom:90px}textarea{display:block;margin-bottom:20px}</style></head><body><div id="app"></div><script type="module" src="/fixture.js"></script></body></html>');
await writeFile(join(workspace, 'fixture.js'), `import {createApp,h,ref} from 'vue';import Status from ${JSON.stringify('/@fs/' + join(directory, 'StatusLine.vue'))};const state=ref({status:'live',tree:${JSON.stringify(tree)}});window.redraw=()=>{const next=structuredClone(${JSON.stringify(tree)});next.children[0].text='Trigger after redraw';next.children[0].hover.text.color='lime';next.children[1].hover.text.color='lime';state.value={status:'live',tree:next}};window.detach=()=>state.value={status:'disconnected'};window.presses=[];createApp({render:()=>h('main',{},[h('h1',{},'Native hover fixture'),h('textarea',{id:'message','aria-label':'Message'}),h('section',{id:'first'},[h(Status,{nativeUi:state.value,onPress:(...args)=>window.presses.push(args)})]),h('section',{id:'second'},[h(Status,{nativeUi:{status:'live',tree:${JSON.stringify(tree)}}})])])}).mount('#app');`);
const main = join(workspace, 'electron.cjs');
await writeFile(main, `const {app,BrowserWindow}=require('electron');app.setPath('userData',${JSON.stringify(join(workspace, 'profile'))});app.whenReady().then(()=>{const window=new BrowserWindow({show:false,width:1000,height:800,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});window.loadURL(process.env.RESEARCH_HOVER_URL)});app.on('window-all-closed',()=>app.quit());`);
const shim = { name: 'unused-host-imports', resolveId(id) { if (id === '@apackdev/sdk/fe') return '\0host-links'; if (id === './NativeUiDocument.vue') return '\0unused-document'; }, load(id) { if (id === '\0host-links') return 'export function openLink(){throw Error("Unexpected host link")};'; if (id === '\0unused-document') return 'export default {render(){return null}};'; } };
const server = await createServer({ configFile: false, root: workspace, cacheDir: join(workspace, '.vite'), plugins: [shim, vue()], resolve: { alias: { vue: join(checkout, 'node_modules/vue/dist/vue.runtime.esm-bundler.js') } }, server: { host: '127.0.0.1', port: 0, fs: { allow: [workspace, checkout] } } });
let electron;
const evidence = { driverSha256: createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex'), candidate: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: checkout, encoding: 'utf8' }).trim(), sources, workspace, scope: 'Actual changed StatusLine/NativeUiNode/hover/paint sources in private Electron. Host openLink and unused document import stubbed; no document/link nodes exercised, no full app stylesheet or compiled/native-owner journey.', realModelRequests: 0 };
try {
  await server.listen();
  electron = await _electron.launch({ executablePath: require('electron'), args: [main], env: { PATH: process.env.PATH, HOME: workspace, TMPDIR: workspace, RESEARCH_HOVER_URL: `http://127.0.0.1:${server.httpServer.address().port}/` }, timeout: 20000 });
  const page = await electron.firstWindow(), errors = [];
  page.on('pageerror', error => errors.push(error.message));
  evidence.browserVersions = await electron.evaluate(() => ({ electron: process.versions.electron, chrome: process.versions.chrome }));
  await expect(page.getByRole('heading', { name: 'Native hover fixture' })).toBeVisible();
  const text = (site, value) => page.locator(site).getByText(value, { exact: true });
  const color = locator => locator.evaluate(element => getComputedStyle(element).color);
  await page.locator('#message').focus();
  const before = await page.locator('#first .native-box').first().boundingBox();
  await expect(text('#first', 'Revealed')).toBeHidden();
  await text('#first', 'Trigger').hover();
  await expect.poll(() => color(text('#first', 'Peer'))).toBe('rgb(255, 0, 0)');
  assert.equal(await color(text('#first', 'Foreign')), 'rgb(0, 0, 255)');
  assert.equal(await color(text('#second', 'Peer')), 'rgb(0, 0, 255)');
  await expect(text('#first', 'Revealed')).toBeVisible();
  const after = await page.locator('#first .native-box').first().boundingBox();
  assert.deepEqual(after, before);
  assert.equal(await page.locator('#message').evaluate(element => document.activeElement === element), true);
  const border = await page.locator('#first .native-box').first().evaluate(element => ({ color: getComputedStyle(element).borderTopColor, opacity: getComputedStyle(element).opacity }));
  assert.equal(border.opacity, '1');assert.ok(border.color.includes('0.6'));
  assert.equal(await color(text('#first', ' Normal')), 'rgb(0, 0, 255)');
  await page.evaluate(() => window.redraw());
  await expect.poll(() => color(text('#first', 'Peer'))).toBe('rgb(0, 255, 0)');
  await page.screenshot({ path: join(workspace, 'hover-active.png') });
  await page.mouse.move(900, 750);
  await expect.poll(() => color(text('#first', 'Peer'))).toBe('rgb(0, 0, 255)');
  await expect(text('#first', 'Revealed')).toBeHidden();
  await text('#first', 'Trigger after redraw').hover();
  await page.evaluate(() => window.detach());
  await expect(page.locator('#first .native-box')).toHaveCount(0);
  assert.deepEqual(await page.evaluate(() => window.presses), []);
  await page.screenshot({ path: join(workspace, 'hover.png') });
  assert.deepEqual(errors, []);
  Object.assign(evidence, { complete: true, namedGroup: true, pluginIsolation: true, mountedSurfaceIsolation: true, hiddenReveal: true, borderGeometryStable: { before, after }, dimBorderWithoutDimChildren: border, restingPointerRedraw: true, nestedInverseReset: true, pointerExit: true, detach: true, focusPreserved: true, noPressCallbacks: true, errors });
} catch (error) { evidence.complete = false; evidence.error = error.stack; process.exitCode = 1; }
finally {
  try { if (electron) { const child = electron.process(); await electron.close(); evidence.electronExit = { code: child.exitCode, signal: child.signalCode }; assert.ok(child.exitCode !== null || child.signalCode !== null); } } catch (error) { evidence.complete = false; evidence.cleanupError = error.stack; process.exitCode = 1; }
  try { await server.close(); evidence.localServerClosed = !server.httpServer?.listening; } catch (error) { evidence.complete = false; evidence.serverCleanupError = error.stack; process.exitCode = 1; }
  await writeFile(join(workspace, 'evidence.json'), JSON.stringify(evidence, null, 2) + '\n');
  console.log(JSON.stringify({ workspace, complete: evidence.complete, error: evidence.error, cleanupError: evidence.cleanupError }));
}
