import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,lstat,copyFile,readdir} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
const sha=value=>createHash('sha256').update(value).digest('hex');
/** Reuse exact captured native history in a distinct disposable profile; never rewrite its UUIDs. */
export async function driveSavedCommandHistory(options){
 assert.equal(process.platform,'linux');assert.match(options.workspace,/^\/work\/\.claude-research\/saved-command-app[1-9]\d*$/);
 const archive='/saved-history.tar.gz';
 const extract=async name=>(await promisify(execFile)('tar',['-xOzf',archive,name],{encoding:'buffer',maxBuffer:8*1024*1024})).stdout;
 const originalProof=JSON.parse(await extract('electron-results/child-plan-review.json'));
 const raw=await extract('electron-results/native-parent-transcript.jsonl');assert.equal(sha(raw),originalProof.transcripts.parent.sha256);
 const rows=raw.toString().split('\n').filter(Boolean).map(JSON.parse),sessionId=originalProof.parentSessionId;
 const empty=rows.filter(row=>row.type==='user'&&row.entrypoint==='cli'&&row.origin===undefined&&row.message?.content==='<local-command-stdout>(no content)</local-command-stdout>');assert.ok(empty.length>0);assert.ok(empty.every(row=>row.sessionId===sessionId));
 const profile=join(options.workspace,'native-profile'),source=join(options.setupWorkspace,'app-data/claude-code-profile/config'),project=join(options.setupWorkspace,'project');
 const bucket=project.replace(/[^a-zA-Z0-9]/g,'-');await mkdir(join(profile,'projects',bucket),{recursive:true,mode:0o700});
 for(const name of ['.claude.json','settings.json']){const info=await lstat(join(source,name));assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1024*1024);await copyFile(join(source,name),join(profile,name));}
 const journalPath=join(profile,'projects',bucket,sessionId+'.jsonl');await writeFile(journalPath,raw,{flag:'wx',mode:0o600});
 const fixture={sourceArchive:archive,sourceJournalSha256:sha(raw),sessionId,emptyNativeRows:empty,profile,journalPath,project};
 await writeFile(join(options.workspace,'saved-command-source.json'),JSON.stringify(fixture,null,2));
 return driveChildComposer({...options,env:{...options.env,CLAUDE_CONFIG_DIR:profile},modelTool:'TextOnly',modelRequestLimit:12,journey:args=>savedHistoryJourney({...args,fixture}),journeyName:'saved-command-history'});
}
async function savedHistoryJourney({app,page,output,workspace,project,expect,phase,fixture}){
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>!!window.applicationState.system.get('default-setup/threads').getSnapshot().context.currentThread?.id),{timeout:15000}).toBe(true);
 const selectProfile=async value=>{await app.navigate('host/settings');await page.evaluate(()=>{const actor=window.applicationState.system.get('host/settings');actor.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});actor.send({type:'TAB.SELECT',tab:'features'});});const select=page.locator('#claude-profile');await expect(select).toBeVisible();await select.selectOption(value);await expect(select).toHaveValue(value);await app.navigate('default-setup/threads');};
 const {waitForAppReady}=await import('/work/packages/apack-testing/src/index.ts');
 const proof={status:'running',fixture,captures:[]},save=()=>writeFile(join(output,'saved-command-history.json'),JSON.stringify(proof,null,2));let originalProfile;
 try{
  await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});a.send({type:'TAB.SELECT',tab:'features'});});originalProfile=await page.locator('#claude-profile').inputValue();if(originalProfile==='shared'){
   const prior=JSON.parse(await readFile('/work/.claude-research/saved-command-app2/electron-results/saved-command-history.json','utf8'));assert.equal(prior.status,'running');assert.equal(prior.fixture.profile,'/work/.claude-research/saved-command-app2/native-profile');
   assert.equal(prior.fixture.sourceJournalSha256,fixture.sourceJournalSha256);assert.notEqual(prior.profileSelectionRestored,true);
   const ownedProfile=await lstat(prior.fixture.profile);assert.ok(ownedProfile.isDirectory()&&ownedProfile.uid===process.getuid());
   originalProfile='app';await selectProfile(originalProfile);proof.recoveredPriorOwnedProfileSelection=true;
  }assert.equal(originalProfile,'app');await selectProfile('shared');
  await page.evaluate(project=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'VIEW_DASHBOARD'});a.send({type:'NEW_THREAD_IN_PROJECT',directory:project});a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});},project);
  const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id)};});
  const card=page.locator('[data-onboarding-id="agent-chat-input"]'),editor=card.locator('[contenteditable="true"]');
  const command=async(name,args)=>{await editor.fill('');await editor.pressSequentially('/'+name);await page.locator('.command-suggestion-popup').getByText('/'+name,{exact:true}).click();if(args)await editor.pressSequentially(args);await card.getByRole('button',{name:'Send',exact:true}).click();await expect(editor).toHaveText('');};
  await command('cc-set-dir',project);await command('cc-resume',fixture.sessionId);await expect.poll(async()=>(await context()).claude?.sessionId,{timeout:25000}).toBe(fixture.sessionId);
  proof.imported=await context();assert.equal(proof.imported.claude.profile.configDir,fixture.profile);assert.equal(sha(await readFile(fixture.journalPath)),fixture.sourceJournalSha256);await writeFile(join(output,'native-saved-command-source.jsonl'),await readFile(fixture.journalPath));
  const check=async stage=>{await expect.poll(async()=>(await context()).messages?.some(row=>row.context?.claudeNativeCommand?.name==='/background'),{timeout:15000}).toBe(true);const state=await context();assert.equal(state.claude.sessionId,fixture.sessionId);assert.ok(state.messages.some(row=>row.context?.claudeNativeCommand?.name==='/background'));for(const row of fixture.emptyNativeRows)assert.ok(!state.messages.some(message=>message.context?.cliUuid===row.uuid));await expect(page.locator('[data-chat-message]').getByText('(no content)',{exact:true})).toHaveCount(0);
   for(const[name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(size);await editor.fill('Keep the saved release review draft.');await expect(editor).toHaveText('Keep the saved release review draft.');await expect(card.getByRole('button',{name:'Send',exact:true})).toBeInViewport({ratio:1});const capture='saved-command-'+stage+'-'+name+'.png';await page.screenshot({path:join(output,capture)});proof.captures.push(capture);}proof[stage]=await context();await save();};
  await check('loaded');await editor.fill('');await page.reload();await waitForAppReady(page);await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');await expect.poll(async()=>(await context()).claude?.sessionId,{timeout:15000}).toBe(fixture.sessionId);await check('reloaded');
  const section=page.getByRole('region',{name:'Claude native interface',exact:true});await editor.fill('');await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');proof.resumedNative=await context();await save();await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  const changedView=section.getByText('The native view changed; return again',{exact:true});await expect.poll(async()=>await card.isVisible()||await changedView.isVisible(),{timeout:15000}).toBe(true);
  if(!await card.isVisible()){proof.freshReturnAfterViewRefusal=true;await section.getByRole('button',{name:'Back to conversation',exact:true}).click();}await expect(card).toBeVisible({timeout:15000});await check('resumed');
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:20000}).toBe('exited');proof.final=await context();proof.status='complete';phase('saved-command-history-complete');
 }catch(error){proof.status='failed';proof.error=String(error.message).slice(0,4096);proof.failureContext=await page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{thread:c.currentThread,native:c.nativeTerminalViews};}).catch(()=>null);await page.screenshot({path:join(output,'saved-command-failure.png')}).catch(()=>{});throw error;}
 finally{if(originalProfile){await selectProfile(originalProfile);proof.profileSelectionRestored=true;}await save();}
}
