import assert from 'node:assert/strict';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {findUiButton} from '../protocol/ui-surface-probe.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(base,'query.ts')).href);
const {createClaudeUiDrawing}=await import(pathToFileURL(join(base,'ui-tree.ts')).href);
const plugin=join(workspace,'plugin');await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
const source=`export function register(on){on('ui.render',{component:'UserMessage'},async($,e,next)=>{const{Box,Text,Button,Input}=$.ui.resolve(e);await $.fs.write('user-render.json',JSON.stringify({id:e.requestId,...e.props}));return Box({children:[Text({children:['Native user tools']}),Button({key:'inspect-user',label:'Inspect native user',onPress:async()=>$.fs.write('user-pressed.json',JSON.stringify({id:e.requestId,...e.props}))}),Input({key:'user-note',label:'User note',value:'',onInput:async value=>$.fs.write('user-note.json',JSON.stringify({id:e.requestId,value})),onSubmit:async()=>{}}),await next({...e,props:{...e.props,text:'User display: '+e.props.text}})]});});on('ui.render',{component:'AssistantMessage'},async($,e,next)=>{const{Box,Text,Button,Input}=$.ui.resolve(e);return Box({children:[Text({children:['Native message '+e.requestId]}),Button({key:'inspect-message',label:'Inspect native message',onPress:async()=>$.fs.write('message-pressed.json',JSON.stringify({id:e.requestId,text:e.props.text}))}),Input({key:'message-note',label:'Message note',value:'',onInput:async value=>$.fs.write('message-note.json',JSON.stringify({id:e.requestId,value})),onSubmit:async()=>{}}),await next(e)]});});}`;
await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'research-message-fixture',version:'0.0.1'}));await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));await writeFile(join(plugin,'hooks/register.ts'),source);
const model=await startSyntheticModel(workspace,'TextOnly',{pairedText:true,thinkingBlock:true,narration:true,captureMessages:true});
let handle,draining;const events=[];
try{
 handle=await query({cliPath:executable,cwd:workspace,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:undefined,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},tools:[],pluginDir:[plugin],strictMcpConfig:true,settingSources:[],noSessionPersistence:true,replayUserMessages:true,keepStdinOpen:true,signal:AbortSignal.timeout(20000),settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})});
 draining=(async()=>{for await(const event of handle.events)events.push(event)})();draining.catch(()=>{});
 await handle.initialized;const client={client_id:'research-messages',surface:'desktop'};await handle.ui.attach(client);
 const inputId=handle.send('Synthetic native message identity fixture.');await handle.result;
 const deadline=Date.now()+3000;while(!events.some(event=>event.type==='result')){assert.ok(Date.now()<deadline);await new Promise(resolve=>setTimeout(resolve,10));}
 const messages=events.filter(event=>event.type==='assistant');
 const texts=messages.flatMap(message=>(message.message?.content??[]).filter(block=>block.type==='text').map(block=>({id:message.uuid,apiId:message.message.id,text:block.text,sessionId:message.session_id})));
 assert.deepEqual(texts.map(row=>row.text),['Fixture completed.','Second native text block.']);assert.ok(texts.every(row=>typeof row.id==='string'&&row.id));
 const summaries=messages.flatMap(message=>(message.message?.content??[]).filter(block=>block.type==='thinking').map(block=>({id:message.uuid,apiId:message.message.id,text:block.thinking,sessionId:message.session_id})));
 assert.equal(summaries.length,1);assert.equal(summaries[0].text,'Synthetic thinking summary 1.');assert.ok(!texts.some(row=>row.id===summaries[0].id));
 const summaryFrame=await handle.ui.render({...client,component:'AssistantMessage',instance_id:summaries[0].id,props:{text:summaries[0].text.trim(),isFirstOfReply:true,isSummary:true}});assert.equal(summaryFrame.hooked,true);assert.equal(summaryFrame.props.isSummary,true);
 await writeFile(join(workspace,'native-summary-message.json'),JSON.stringify({row:summaries[0],frame:summaryFrame},null,2));
 const frames=[];
 for(const [index,row]of texts.entries()){
  const frame=await handle.ui.render({...client,component:'AssistantMessage',instance_id:row.id,props:{text:row.text,isFirstOfReply:index===0}});
  assert.equal(frame.hooked,true);frames.push({row,frame,mapped:createClaudeUiDrawing(frame.tree)});
 }
 for(const {row,frame}of frames){const press=findUiButton(frame.tree,{plugin:'research-message-fixture',key:'inspect-message'});assert.ok(press);assert.equal((await handle.ui.press({...client,...press})).handled,true);assert.deepEqual(JSON.parse(await readFile(join(workspace,'message-pressed.json'),'utf8')),{id:row.id,text:row.text});}
 function field(node){if(!node||typeof node!=='object')return; if(node.type==='Input'&&node.props?.key==='message-note')return node;for(const child of node.children??[]){const found=field(child);if(found)return found;}}
 for(const {row,frame}of frames){const input=field(frame.tree);assert.ok(input?.press);assert.equal((await handle.ui.input({...client,...input.press,key:'message-note',component:'AssistantMessage',instance_id:row.id,kind:'change',value:'Note '+row.id})).handled,true);assert.deepEqual(JSON.parse(await readFile(join(workspace,'message-note.json'),'utf8')),{id:row.id,value:'Note '+row.id});}
 const user=events.find(event=>event.type==='user'&&event.isReplay===true&&event.uuid===inputId);assert.ok(user);assert.equal(user.message.content,'Synthetic native message identity fixture.');
 const userFrames=[];
 for(const isExpanded of [false,true]){
  const props={text:user.message.content,origin:{kind:'unclassified'},isExpanded};
  const frame=await handle.ui.render({...client,component:'UserMessage',instance_id:user.uuid,props});assert.equal(frame.hooked,true);assert.equal(frame.props.text,'User display: '+props.text);assert.deepEqual(JSON.parse(await readFile(join(workspace,'user-render.json'),'utf8')),{id:user.uuid,...props});
  const press=findUiButton(frame.tree,{plugin:'research-message-fixture',key:'inspect-user'});assert.ok(press);assert.equal((await handle.ui.press({...client,...press})).handled,true);assert.deepEqual(JSON.parse(await readFile(join(workspace,'user-pressed.json'),'utf8')),{id:user.uuid,...props});
  const input=(function find(node){if(node?.type==='Input'&&node.props?.key==='user-note')return node;for(const child of node?.children??[]){const value=find(child);if(value)return value;}})(frame.tree);assert.ok(input?.press);assert.equal((await handle.ui.input({...client,...input.press,key:'user-note',component:'UserMessage',instance_id:user.uuid,kind:'change',value:'User-only note'})).handled,true);assert.deepEqual(JSON.parse(await readFile(join(workspace,'user-note.json'),'utf8')),{id:user.uuid,value:'User-only note'});
  userFrames.push({props,frame});
 }
 const summaryPress=findUiButton(summaryFrame.tree,{plugin:'research-message-fixture',key:'inspect-message'});assert.ok(summaryPress);assert.equal((await handle.ui.press({...client,...summaryPress})).handled,true);assert.deepEqual(JSON.parse(await readFile(join(workspace,'message-pressed.json'),'utf8')),{id:summaries[0].id,text:summaries[0].text});
 const summaryInput=field(summaryFrame.tree);assert.ok(summaryInput?.press);assert.equal((await handle.ui.input({...client,...summaryInput.press,key:'message-note',component:'AssistantMessage',instance_id:summaries[0].id,kind:'change',value:'Summary-only note'})).handled,true);assert.deepEqual(JSON.parse(await readFile(join(workspace,'message-note.json'),'utf8')),{id:summaries[0].id,value:'Summary-only note'});
 await writeFile(join(workspace,'native-user-message-frames.json'),JSON.stringify({user,userFrames},null,2));
 await writeFile(join(workspace,'native-message-frames.json'),JSON.stringify(frames.map(({row,frame,mapped})=>({row,frame,mappedTree:mapped.tree})),null,2));
 await handle.ui.detach(client.client_id);await handle.close();await draining;handle=undefined;
 await writeFile(join(workspace,'native-message-events.json'),JSON.stringify(events,null,2));assert.equal(model.calls.length,1);
 console.log(JSON.stringify({evidence:'apack-native-ui-messages',targetSha256:hash(await readFile(executable)),pluginSourceSha256:hash(Buffer.from(source)),inputId,messageRows:texts,uniqueNativeMessageIds:new Set(texts.map(row=>row.id)).size,uniqueApiMessageIds:new Set(texts.map(row=>row.apiId)).size,nativeRenderPerMessage:true,callbacksKeepMessageIdentity:true,fieldsKeepMessageIdentity:true,nativeSummaryMessage:true,summaryNativeUuidDistinct:true,summaryCallbacksKeepIdentity:true,summaryFieldsKeepIdentity:true,nativeUserMessage:true,userTextRewrite:true,userReadonlyProps:true,userExpandedVariants:true,userCallbacks:true,userFields:true,streamDrained:true,syntheticApiRequests:1,realModelRequests:0,userPromptsSent:1}));
}finally{try{if(handle){handle.kill();await handle.close().catch(()=>{})}await draining?.catch(()=>{})}finally{await writeFile(join(workspace,'synthetic-message-requests.json'),JSON.stringify(model.calls,null,2));await model.close()}}
