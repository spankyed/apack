import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,writeFile,lstat,mkdir,readdir,rename} from 'node:fs/promises';
import {join,resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';

/** Disposable original settings; Claude alone schedules and executes both helpers. */
export async function prepareCombinedEverydayProfile({setupWorkspace,workspace}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');assert.match(workspace,/^\/work\/\.claude-research\/combined-everyday-app[0-9]+$/);
 return prepareProfile({workspace,path:join(setupWorkspace,'app-data/claude-code-profile/config/settings.json'),agent:join(setupWorkspace,'project/.claude/agents/release-reviewer.md'),expectedSettingsSha256:'5eb7b71763d6c0fc454f048fe69cb174724f161d2f4cdc50a8776c83cbc2e128'});
}

/** Same original helpers in a fresh shared profile; never changes the older accepted profile. */
export async function prepareFreshCombinedEverydayProfile({workspace}) {
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
 return prepareProfile({workspace,path:join(workspace,'.claude/settings.json'),agent:join(workspace,'project/.claude/agents/release-reviewer.md')});
}
async function prepareProfile({workspace,path,agent,expectedSettingsSha256}) {
 const info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1048576);
 const original=await readFile(path);if(expectedSettingsSha256)assert.equal(createHash('sha256').update(original).digest('hex'),expectedSettingsSha256);const settings=JSON.parse(original),receipts=join(workspace,'helper-invocations');await mkdir(receipts,{mode:0o700});
 let agentBefore;try{const metadata=await lstat(agent);assert.ok(metadata.isFile()&&metadata.uid===process.getuid()&&metadata.size<=65536);agentBefore=await readFile(agent)}catch(error){if(error.code!=='ENOENT')throw error}
 await writeFile(join(workspace,'combined-settings-before.json'),original,{mode:0o600,flag:'wx'});
 if(agentBefore!==undefined)await writeFile(join(workspace,'combined-agent-before.md'),agentBefore,{mode:0o600,flag:'wx'});
 await writeFile(join(workspace,'combined-agent-before.json'),JSON.stringify({path:agent,present:agentBefore!==undefined,sha256:agentBefore===undefined?null:createHash('sha256').update(agentBefore).digest('hex')}),{mode:0o600,flag:'wx'});
 await mkdir(dirname(agent),{recursive:true});await writeFile(agent,'---\nname: release-reviewer\ndescription: Review release changes and migration notes\ntools: []\n---\nNativeStatusChildSystem. Review the release notes and return concise guidance.\n');
 const helper=join(workspace,'review-status.mjs');
 const source=`import {readFileSync,writeFileSync} from 'node:fs';import {randomUUID} from 'node:crypto';
let raw='';for await(const bytes of process.stdin){raw+=bytes;if(Buffer.byteLength(raw)>1048576)process.exit(65)}
const input=JSON.parse(raw),kind=process.argv[2];if(typeof input.session_id!=='string'||!['main','agent'].includes(kind))process.exit(66);
if(kind==='agent'&&!Array.isArray(input.tasks))process.exit(67);
const stdout=kind==='main'?'Release review\\nChecklist and migration notes\\n':input.tasks.map(task=>JSON.stringify({id:task.id,content:'Reviewing release notes · '+task.id+' · '+task.status})).join('\\n')+'\\n';
const stat=readFileSync('/proc/self/stat','utf8'),start=stat.slice(stat.lastIndexOf(')')+2).split(' ')[19];
const ancestry=[];let parent=process.ppid;for(let i=0;parent>1&&i<16;i++){try{const raw=readFileSync('/proc/'+parent+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');ancestry.push({pid:parent,start:fields[19]});const next=Number(fields[1]);if(!Number.isSafeInteger(next)||next===parent)break;parent=next}catch{break}}
writeFileSync(${JSON.stringify(receipts)}+'/'+randomUUID()+'.json',JSON.stringify({kind,at:Date.now(),pid:process.pid,start,ancestry,input,stdout}),{mode:0o600,flag:'wx'});process.stdout.write(stdout);
`;
 await writeFile(helper,source,{mode:0o600,flag:'wx'});const quote=value=>"'"+value.replaceAll("'","'\\''")+"'",command=quote(process.execPath)+' '+quote(helper);
 await writeFile(path,JSON.stringify({...settings,permissions:{...settings.permissions,ask:[...new Set([...(settings.permissions?.ask??[]),'Read'])]},statusLine:{type:'command',command:command+' main'},subagentStatusLine:{type:'command',command:command+' agent'}}));
 let restored=false;
 return {helper,configDir:dirname(path),helperSha256:createHash('sha256').update(source).digest('hex'),originalSettingsSha256:createHash('sha256').update(original).digest('hex'),
  async invocations(){const names=await readdir(receipts);assert.ok(names.length<=128);return Promise.all(names.map(async name=>{assert.match(name,/^[a-f0-9-]+\.json$/);const p=join(receipts,name),s=await lstat(p);assert.ok(s.isFile()&&s.uid===process.getuid()&&s.size<=2*1048576);return JSON.parse(await readFile(p,'utf8'))}))},
  async restore(){if(restored)return;await rename(agent,join(workspace,'release-reviewer-agent.md'));if(agentBefore!==undefined){await writeFile(agent,agentBefore);assert.deepEqual(await readFile(agent),agentBefore)}else assert.equal(existsSync(agent),false);await writeFile(join(workspace,'combined-agent-restoration.json'),JSON.stringify({originalPresent:agentBefore!==undefined,restoredPresent:existsSync(agent),originalSha256:agentBefore===undefined?null:createHash('sha256').update(agentBefore).digest('hex'),restoredSha256:agentBefore===undefined?null:createHash('sha256').update(await readFile(agent)).digest('hex'),preservedDefinition:'release-reviewer-agent.md'}));await writeFile(join(workspace,'combined-settings-after.json'),await readFile(path));await writeFile(path,original);assert.deepEqual(await readFile(path),original);await writeFile(join(workspace,'combined-settings-restored.json'),await readFile(path));restored=true},
 };
}

/** Emergency recovery is invoked only after the owned app has stopped and its work lock is held. */
export async function recoverCombinedEverydayProfile(workspace){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));assert.match(workspace,/^\/work\/\.claude-research\/combined-everyday-app[0-9]+$/);
 const setup='/work/.claude-research/profile-setup-app10',settings=join(setup,'app-data/claude-code-profile/config/settings.json'),agent=join(setup,'project/.claude/agents/release-reviewer.md'),hash=b=>createHash('sha256').update(b).digest('hex');
 const before=await readFile(join(workspace,'combined-settings-before.json'));assert.equal(hash(before),'5eb7b71763d6c0fc454f048fe69cb174724f161d2f4cdc50a8776c83cbc2e128');
 const ledger=JSON.parse(await readFile(join(workspace,'combined-agent-before.json'),'utf8'));assert.equal(ledger.path,agent);assert.equal(typeof ledger.present,'boolean');
 const originalAgent=ledger.present?await readFile(join(workspace,'combined-agent-before.md')):undefined;assert.equal(originalAgent===undefined?null:hash(originalAgent),ledger.sha256);
 if(existsSync(agent)){const info=await lstat(agent);assert.ok(info.isFile()&&info.uid===1000&&info.size<=65536);const current=await readFile(agent);if(originalAgent===undefined||!current.equals(originalAgent)){const saved=join(workspace,'release-reviewer-agent.md');assert.ok(!existsSync(saved));await rename(agent,saved);}}
 if(originalAgent!==undefined&&!existsSync(agent))await writeFile(agent,originalAgent,{mode:0o600,flag:'wx'});
 assert.equal(existsSync(agent),ledger.present);if(ledger.present)assert.deepEqual(await readFile(agent),originalAgent);
 const info=await lstat(settings);assert.ok(info.isFile()&&info.uid===1000&&info.size<=1048576);const after=await readFile(settings),saved=join(workspace,'combined-settings-interrupted.json');if(!existsSync(saved))await writeFile(saved,after,{mode:0o600,flag:'wx'});await writeFile(settings,before);assert.deepEqual(await readFile(settings),before);
 const result={restored:true,emergencyRecovery:true,settingsSha256:hash(before),agentOriginalPresent:ledger.present,agentRestoredExactly:true};await writeFile(join(workspace,'combined-profile-recovery.json'),JSON.stringify(result));return result;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){assert.equal(process.argv.length,3);console.log(JSON.stringify(await recoverCombinedEverydayProfile(process.argv[2])));}

/** Recover only a stopped fresh fixture's durable preimages, under the caller's work-volume lock. */
export async function recoverFreshCombinedEverydayProfile(workspace){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
 const settings=join(workspace,'.claude/settings.json'),config=join(workspace,'.claude/.claude.json'),agent=join(workspace,'project/.claude/agents/release-reviewer.md'),hash=bytes=>createHash('sha256').update(bytes).digest('hex');
 const before=await readFile(join(workspace,'combined-settings-before.json'));assert.deepEqual(JSON.parse(before),{theme:'dark',model:'opus'});
 const inputs=JSON.parse(await readFile(join(workspace,'profile-inputs.json'),'utf8'));assert.ok(inputs.accountIsSynthetic&&inputs.featureInputsSeeded===false&&inputs.defaultProfile==='shared');assert.deepEqual(JSON.parse(before),inputs.settings);
 const ledger=JSON.parse(await readFile(join(workspace,'combined-agent-before.json'),'utf8'));assert.equal(ledger.path,agent);assert.equal(typeof ledger.present,'boolean');
 const original=ledger.present?await readFile(join(workspace,'combined-agent-before.md')):undefined;assert.equal(original===undefined?null:hash(original),ledger.sha256);
 if(existsSync(agent)){const info=await lstat(agent);assert.ok(info.isFile()&&info.uid===1000&&info.size<=65536);const current=await readFile(agent);if(!original||!current.equals(original)){const saved=join(workspace,'release-reviewer-agent.md');assert.ok(!existsSync(saved));await rename(agent,saved);}}
 if(original&&!existsSync(agent))await writeFile(agent,original,{mode:0o600,flag:'wx'});assert.equal(existsSync(agent),ledger.present);if(original)assert.deepEqual(await readFile(agent),original);
 for(const[path,name]of[[settings,'settings'],[config,'config']]){const info=await lstat(path);assert.ok(info.isFile()&&info.uid===1000&&info.size<=1048576);const saved=join(workspace,'combined-'+name+'-interrupted.json');if(!existsSync(saved))await writeFile(saved,await readFile(path),{mode:0o600,flag:'wx'});}
 await writeFile(settings,before);await writeFile(config,JSON.stringify(inputs.config));assert.deepEqual(await readFile(settings),before);assert.deepEqual(JSON.parse(await readFile(config,'utf8')),inputs.config);
 const result={restored:true,emergencyRecovery:true,settingsSha256:hash(before),configSha256:hash(await readFile(config)),agentOriginalPresent:ledger.present,agentRestoredExactly:true};await writeFile(join(workspace,'combined-profile-recovery.json'),JSON.stringify(result,null,2));return result;
}
