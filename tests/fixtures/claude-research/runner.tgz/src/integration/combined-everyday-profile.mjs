import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,writeFile,lstat,mkdir,readdir,rename} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';

/** Disposable original settings; Claude alone schedules and executes both helpers. */
export async function prepareCombinedEverydayProfile({setupWorkspace,workspace}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');assert.match(workspace,/^\/work\/\.claude-research\/combined-everyday-app[0-9]+$/);
 const path=join(setupWorkspace,'app-data/claude-code-profile/config/settings.json'),info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1048576);
 const original=await readFile(path),settings=JSON.parse(original),receipts=join(workspace,'helper-invocations');await mkdir(receipts,{mode:0o700});
 const agent=join(setupWorkspace,'project/.claude/agents/release-reviewer.md');let agentBefore;try{const metadata=await lstat(agent);assert.ok(metadata.isFile()&&metadata.uid===process.getuid()&&metadata.size<=65536);agentBefore=await readFile(agent)}catch(error){if(error.code!=='ENOENT')throw error}
 await mkdir(join(setupWorkspace,'project/.claude/agents'),{recursive:true});await writeFile(agent,'---\nname: release-reviewer\ndescription: Review release changes and migration notes\ntools: []\n---\nNativeStatusChildSystem. Review the release notes and return concise guidance.\n');
 const helper=join(workspace,'review-status.mjs');
 const source=`import {readFileSync,writeFileSync} from 'node:fs';import {randomUUID} from 'node:crypto';
let raw='';for await(const bytes of process.stdin){raw+=bytes;if(Buffer.byteLength(raw)>1048576)process.exit(65)}
const input=JSON.parse(raw),kind=process.argv[2];if(typeof input.session_id!=='string'||!['main','agent'].includes(kind))process.exit(66);
if(kind==='agent'&&!Array.isArray(input.tasks))process.exit(67);
const stdout=kind==='main'?'Release review\\nChecklist and migration notes\\n':input.tasks.map(task=>JSON.stringify({id:task.id,content:'Reviewing release notes · '+task.id+' · '+task.status})).join('\\n')+'\\n';
const stat=readFileSync('/proc/self/stat','utf8'),start=stat.slice(stat.lastIndexOf(')')+2).split(' ')[19];
const ancestry=[];let parent=process.ppid;for(let i=0;parent>1&&i<16;i++){try{const raw=readFileSync('/proc/'+parent+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');ancestry.push({pid:parent,start:fields[19]});const next=Number(fields[1]);if(!Number.isSafeInteger(next)||next===parent)break;parent=next}catch{break}}
writeFileSync(${JSON.stringify(receipts)}+'/'+randomUUID()+'.json',JSON.stringify({kind,at:Date.now(),pid:process.pid,start,ancestry,input,stdout}),{mode:0o600,flag:'wx'});process.stdout.write(stdout);
`;
 await writeFile(helper,source,{mode:0o600,flag:'wx'});const quote=value=>"'"+value.replaceAll("'","'\\''")+"'",command=quote(process.execPath)+' '+quote(helper);
 await writeFile(join(workspace,'combined-settings-before.json'),original,{mode:0o600,flag:'wx'});
 await writeFile(path,JSON.stringify({...settings,permissions:{...settings.permissions,ask:[...new Set([...(settings.permissions?.ask??[]),'Read'])]},statusLine:{type:'command',command:command+' main'},subagentStatusLine:{type:'command',command:command+' agent'}}));
 let restored=false;
 return {helper,helperSha256:createHash('sha256').update(source).digest('hex'),originalSettingsSha256:createHash('sha256').update(original).digest('hex'),
  async invocations(){const names=await readdir(receipts);assert.ok(names.length<=128);return Promise.all(names.map(async name=>{assert.match(name,/^[a-f0-9-]+\.json$/);const p=join(receipts,name),s=await lstat(p);assert.ok(s.isFile()&&s.uid===process.getuid()&&s.size<=2*1048576);return JSON.parse(await readFile(p,'utf8'))}))},
  async restore(){if(restored)return;await rename(agent,join(workspace,'release-reviewer-agent.md'));if(agentBefore!==undefined){await writeFile(agent,agentBefore);assert.deepEqual(await readFile(agent),agentBefore)}else assert.equal(existsSync(agent),false);await writeFile(join(workspace,'combined-agent-restoration.json'),JSON.stringify({originalPresent:agentBefore!==undefined,restoredPresent:existsSync(agent),originalSha256:agentBefore===undefined?null:createHash('sha256').update(agentBefore).digest('hex'),restoredSha256:agentBefore===undefined?null:createHash('sha256').update(await readFile(agent)).digest('hex'),preservedDefinition:'release-reviewer-agent.md'}));await writeFile(join(workspace,'combined-settings-after.json'),await readFile(path));await writeFile(path,original);assert.deepEqual(await readFile(path),original);await writeFile(join(workspace,'combined-settings-restored.json'),await readFile(path));restored=true},
 };
}
