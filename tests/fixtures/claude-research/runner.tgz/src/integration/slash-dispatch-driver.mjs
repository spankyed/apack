import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const[checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const{query}=await import(pathToFileURL(join(base,'query.ts'))),{createClaudeConversation}=await import(pathToFileURL(join(base,'conversation.ts')));
const cwd=join(workspace,'project'),config=join(workspace,'.claude');await mkdir(cwd);await mkdir(config,{recursive:true});
const settings=join(config,'settings.json'),before=JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',language:'preserve'});await writeFile(settings,before);
const model=await startSyntheticModel(cwd,'TextOnly');let native,owner;const results=[],models=[];
try{
 native=await query({cliPath:executable,cwd,env:{HOME:workspace,CLAUDE_CONFIG_DIR:config,ANTHROPIC_BASE_URL:model.url},tools:[],strictMcpConfig:true,settingSources:['user'],noSessionPersistence:true,model:'sonnet',replayUserMessages:true,keepStdinOpen:true,signal:AbortSignal.timeout(25000)});
 await native.initialized;
 let finish,reject;
 const consume=async turn=>{try{for await(const event of turn.handle.events){if(event.type==='system'&&event.subtype==='init')models.push(event.model);if(event.type==='result')results.push(event)}await turn.handle.result;owner.release(turn.handle);finish();}catch(error){reject(error);}};
 owner=createClaudeConversation(native,consume);
 const input=async text=>{await new Promise((yes,no)=>{finish=yes;reject=no;owner.start(text,consume)});assert.equal(owner.busy,false);};
 const commands=[];
 await input('First fixed synthetic text.');const session=owner.sessionId;
 for(const command of ['/model haiku','/context','/usage']){
  const beforeCalls=model.calls.length,beforeResults=results.length;
  await input(command);
  const terminal=results.at(-1);commands.push({command,newResults:results.length-beforeResults,subtype:terminal.subtype,isError:terminal.is_error===true,textLength:typeof terminal.result==='string'?terminal.result.length:0,localApiRequests:model.calls.length-beforeCalls});
 }
 await input('Fixed follow-up after native slash commands.');
 assert.equal(results.length,5);assert.ok(results.every(value=>value.subtype==='success'&&!value.is_error&&value.session_id===session));
 const inferenceRequests=model.calls.filter(call=>!call.path.includes('count_tokens')).length,tokenCountRequests=model.calls.filter(call=>call.path.includes('count_tokens')).length;
 assert.equal(inferenceRequests,2);assert.ok(tokenCountRequests>0);assert.equal(commands[0].localApiRequests,0);assert.equal(commands[2].localApiRequests,0);
 assert.ok(model.calls.at(-1).model.includes('haiku'));assert.equal(owner.busy,false);
 await owner.close();
 console.log(JSON.stringify({evidence:'apack-native-slash-dispatch',sameOwner:true,sameSession:true,turns:results.length,commands,effectiveModels:models,modelCalls:model.calls.map(value=>({path:value.path,model:value.model})),settingsUnchanged:await readFile(settings,'utf8')===before,closed:true,localApiRequests:model.calls.length,inferenceRequests,tokenCountRequests,realModelRequests:0,qualification:'Actual native query and retained owner; only three named slash commands in private headless setup. Source consumer, compiled flow, mounted presentation and other command variants remain unverified.'}));
}finally{owner?.kill();native?.kill();await native?.close().catch(()=>{});await model.close();}
