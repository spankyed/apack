import assert from 'node:assert/strict';
import http from 'node:http';
import {mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkout,executable,workspace,mode='recover']=process.argv.slice(2);
assert.ok(['recover','exhaust','interrupt'].includes(mode));assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const {query}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')));
const cwd=join(workspace,'project');await mkdir(cwd);
const fixture=await startSyntheticModel(cwd,'TextOnly'),retry=Promise.withResolvers(),results=[],waiters=[];
let native,requests=0;
const server=http.createServer(async(req,res)=>{
 try{
  assert.ok(req.url.startsWith('/v1/messages'));let bytes=0;const chunks=[];for await(const chunk of req){bytes+=chunk.length;assert.ok(bytes<2*1024*1024);chunks.push(chunk)}
  requests++;assert.ok(requests<=3);
  if(requests===1){res.writeHead(429,{'content-type':'application/json','retry-after':mode==='interrupt'?'30':'1'});res.end(JSON.stringify({type:'error',error:{type:'rate_limit_error',message:'RESEARCH_TRANSIENT_RATE_LIMIT'}}));return;}
  const response=await fetch(fixture.url+req.url,{method:'POST',headers:{'content-type':'application/json'},body:Buffer.concat(chunks)});
  res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
 }catch(error){if(!res.headersSent)res.writeHead(400);res.end('{}');retry.reject(error)}
});server.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));
const nextResult=()=>new Promise(resolve=>waiters.push(resolve));
try{
 native=await query({cliPath:executable,cwd,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),ANTHROPIC_BASE_URL:`http://127.0.0.1:${server.address().port}`,CLAUDE_CODE_MAX_RETRIES:mode==='exhaust'?'0':'2'},tools:[],strictMcpConfig:true,settingSources:[],settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),noSessionPersistence:true,model:'sonnet',keepStdinOpen:true,signal:AbortSignal.timeout(20000)});
 const firstOutcome=native.result.then(()=> 'resolved',()=> 'rejected');
 const retries=[];const drain=(async()=>{for await(const event of native.events){assert.notEqual(event.type,'__parse_error');if(event.type==='system'&&event.subtype==='api_retry'){retries.push({attempt:event.attempt,status:event.error_status,delayMs:event.retry_delay_ms});retry.resolve(event)}if(event.type==='result'){results.push(event);waiters.shift()?.(event)}}})();
 await native.initialized;const first=nextResult();native.send('Fixed native retry fixture.');
 if(mode==='interrupt'){
  const observed=await retry.promise;assert.equal(observed.error_status,429);assert.equal(requests,1);
  await native.interrupt({cancelQueued:true});const stopped=await first;assert.equal(stopped.is_error,true);
  const second=nextResult();native.send('Fixed follow-up after retry interruption.');const result=await second;assert.equal(result.subtype,'success');assert.equal(result.is_error,false);
 }else{const result=await first;if(mode==='recover'){assert.equal(result.subtype,'success');assert.equal(result.is_error,false)}else assert.equal(result.is_error,true);}
 assert.equal(await firstOutcome,mode==='recover'?'resolved':'rejected');
 assert.equal(requests,mode==='exhaust'?1:2);assert.equal(fixture.calls.length,mode==='exhaust'?0:1);
 if(mode!=='exhaust'){assert.equal(retries.length,1);assert.equal(retries[0].status,429);}
 await native.close();await drain;
 console.log(JSON.stringify({evidence:'apack-native-retry',mode,nativeRetries:retries,terminalResults:results.map(value=>({subtype:value.subtype,isError:value.is_error})),sameProcessFollowup:mode==='interrupt',closeSettled:true,localModelRequests:requests,realModelRequests:0,qualification:'Fixed local 429, default non-watchdog native retry. Query source only; 529, watchdog budgets, credentials/providers, compiled owner and rendered retry status are not verified.'}));
}finally{native?.kill();await native?.close().catch(()=>{});server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await fixture.close();}
