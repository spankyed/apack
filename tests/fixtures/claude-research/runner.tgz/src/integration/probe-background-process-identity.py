"""Probe only reviewed original process identity exports in a capped, offline Linux container."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import uuid

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('target', type=Path, help='Directory containing the pinned Linux claude executable')
parser.add_argument('evidence', type=Path)
parser.add_argument('--image', default='claude-research-display:74d4b8cfe839')
args = parser.parse_args()
expected = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
assert hashlib.sha256((args.target / 'claude').read_bytes()).hexdigest() == expected
args.evidence.mkdir(parents=True, exist_ok=False)
source = r'''import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
assert.equal(process.platform,'linux');
assert.equal(createHash('sha256').update(readFileSync(process.execPath)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
const original=await import('/$bunfs/root/chunk-zpevf1ap.js');
assert.equal(typeof original.Bh,'function');
const start=await original.Ql(process.pid,{skipCache:true});
assert.equal(typeof start,'string');assert.ok(start.length>0);
const same=await original.Bh(process.pid,start);
const replaced=await original.Bh(process.pid,'apack-nonmatching-process-start');
const unavailable=await original.Bh(2147483647,start);
assert.equal(same,true);assert.equal(replaced,false);assert.equal(unavailable,undefined);
console.log(JSON.stringify({same,replaced,unavailable:unavailable??null,unknownRefused:unavailable!==true,pid:process.pid,originalExport:'chunk-zpevf1ap.js:Bh',targetSha256:'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10',modelRequests:0}));
process.exit(0);
'''
(args.evidence / 'probe.mjs').write_text(source)
name = 'claude-background-identity-' + uuid.uuid4().hex[:10]
created = False
try:
    with tempfile.TemporaryDirectory(prefix='claude-background-identity-') as temporary:
        scratch = Path(temporary)
        (scratch / 'probe.mjs').write_text(source)
        (scratch / 'home').mkdir()
        command = ['docker', 'create', '--pull=never', '--name', name, '--init', '--network=none',
                   '--memory=6g', '--memory-swap=6g', '--cpus=2',
                   '-v', str(args.target.resolve()) + ':/frozen-claude:ro', '-v', str(scratch) + ':/probe',
                   '-e', 'HOME=/probe/home', '-e', 'CLAUDE_CONFIG_DIR=/probe/home/.claude',
                   '-e', 'BUN_OPTIONS=--preload=/probe/probe.mjs', '-w', '/probe/home',
                   args.image, '/frozen-claude/claude', '--version']
        subprocess.run(command, check=True, capture_output=True, timeout=20)
        created = True
        info = json.loads(subprocess.check_output(['docker', 'inspect', name], timeout=10))[0]
        assert not info['State']['Running']
        assert set(info['NetworkSettings']['Networks']) == {'none'}
        assert info['HostConfig']['Memory'] == info['HostConfig']['MemorySwap'] == 6 * 1024**3
        assert info['HostConfig']['NanoCpus'] == 2 * 10**9
        assert any(m['Destination'] == '/frozen-claude' and m['RW'] is False for m in info['Mounts'])
        boundary = { 'name': name, 'imageId': info['Image'], 'inspectedBeforeStart': True,
                     'network': 'none', 'memory': info['HostConfig']['Memory'], 'memorySwap': info['HostConfig']['MemorySwap'],
                     'nanoCpus': info['HostConfig']['NanoCpus'], 'readOnlyTarget': True, 'targetSha256': expected }
        (args.evidence / 'boundary.json').write_text(json.dumps(boundary, indent=2) + '\n')
        result = subprocess.run(['docker', 'start', '--attach', name], capture_output=True, timeout=40)
        assert len(result.stdout) + len(result.stderr) <= 100000
        (args.evidence / 'stdout.log').write_bytes(result.stdout)
        (args.evidence / 'stderr.log').write_bytes(result.stderr)
        final = json.loads(subprocess.check_output(['docker', 'inspect', name], timeout=10))[0]
        assert not final['State']['Running'] and final['State']['ExitCode'] == result.returncode == 0
        proof = json.loads(result.stdout)
        assert proof['same'] is True and proof['replaced'] is False and proof['unknownRefused'] is True
        assert proof['modelRequests'] == 0
        (args.evidence / 'proof.json').write_text(json.dumps(proof, indent=2) + '\n')
        print(json.dumps(proof))
finally:
    if created:
        subprocess.run(['docker', 'rm', '--force', name], capture_output=True, timeout=15, check=True)
