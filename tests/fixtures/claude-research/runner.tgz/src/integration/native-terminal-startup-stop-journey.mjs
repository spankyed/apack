import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

export async function prepareOwnedStartingTerminal(workspace) {
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.requireStartingTerminalStop && boundary.networkDisabled && boundary.pinnedExecutableReadOnly);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-command[0-9]+$/);
  const launcher = join(workspace, 'hold-pty-startup');
  const marker = join(workspace, 'hold-pty-startup.arm');
  const claimed = join(workspace, 'hold-pty-startup.claimed');
  const receipt = join(workspace, 'starting-pty-pid');
  await writeFile(launcher, `#!/bin/bash
resume=false
interactive=true
for arg in "$@"; do
  case "$arg" in
    --resume) resume=true ;;
    -p|--print|--no-session-persistence) interactive=false ;;
  esac
done
if [[ -t 0 && $resume == true && $interactive == true && -f "${marker}" ]]; then
  mv "${marker}" "${claimed}" || exit 74
  printf '%s\\n' "$$" > "${receipt}"
  read -r -t 35 _unused || true
fi
exec /frozen-claude/claude "$@"
`, { mode: 0o700, flag: 'wx' });
  return { launcher, marker, receipt };
}

export async function stopStartingTerminal({ page, expect, context, composer, section, proof, output, birth, save, model, fixture }) {
  proof.scope = 'Broker-owned Claude launch stopped before native readiness, draft retention, and original same-session restart.';
  const before = await context();
  assert.ok(before.claude.sessionId);
  const draft = 'Keep this release note through Claude startup.';
  await composer.fill(draft);
  proof.startingTerminal = { draft, before: { sessionId: before.claude.sessionId, turns: before.claude.turns, cost: before.claude.totalCostUsd } };
  const requestCount = model.calls.length;
  await writeFile(fixture.marker, '', { flag: 'wx' });
  await section.getByRole('button', { name: 'Use native interface', exact: true }).click();

  let pid;
  await expect.poll(async () => {
    const value = await readFile(fixture.receipt, 'utf8').catch(error => {
      if (error.code === 'ENOENT') return '';
      throw error;
    });
    pid = Number(value.trim());
    return Number.isSafeInteger(pid) && pid > 1;
  }, { timeout: 15000 }).toBe(true);
  const start = await birth(pid);
  assert.ok(start);
  proof.startingTerminal.heldWriter = { pid, start };
  proof.pid = pid;
  proof.processStart = start;
  const stop = section.getByRole('button', { name: 'Stop session', exact: true });
  await expect(stop).toBeEnabled();
  const native = (await context()).native.state;
  assert.equal(native.pid, pid);
  assert.equal(native.nativePid, undefined);
  assert.equal(native.status, 'starting');
  proof.startingTerminal.terminal = { ownerId: native.ownerId, session: native.terminalSession.id, status: native.status };

  for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
    await page.setViewportSize(viewport);
    await expect(stop).toBeInViewport({ ratio: 1 });
    const filename = 'native-pty-starting-' + size + '.png';
    await page.screenshot({ path: join(output, filename), animations: 'disabled' });
    proof.captures.push(filename);
  }
  await save();
  await stop.click();
  await expect.poll(() => birth(pid), { timeout: 15000 }).toBe(null);
  const back = section.getByRole('button', { name: 'Back to conversation', exact: true });
  if (await back.isVisible()) await back.click();
  await expect(composer).toBeEditable();
  await expect(composer).toHaveText(draft);
  const after = await context();
  assert.deepEqual(after.messages, before.messages);
  assert.equal(after.claude.sessionId, before.claude.sessionId);
  assert.equal(after.claude.totalCostUsd, before.claude.totalCostUsd);
  assert.equal(after.claude.turns, before.claude.turns);
  assert.equal(model.calls.length, requestCount);
  proof.startingTerminal.retired = true;
  await save();
}

export async function finishStartingTerminalJourney({ page, expect, context, composer, send, section, replace, proof, output, birth, save, phase }) {
  const prior = proof.startingTerminal;
  assert.ok(prior.retired);
  assert.equal(proof.sessionId, prior.before.sessionId);
  assert.notEqual(proof.pid, prior.heldWriter.pid);
  assert.notEqual(proof.initial.native.state.ownerId, prior.terminal.ownerId);
  assert.equal(await birth(prior.heldWriter.pid), null);
  await expect(composer).toHaveText(prior.draft);
  proof.followup = 'Continue this release review after reopening Claude.';
  await replace(proof.followup);
  await send.click();
  await expect.poll(async () => {
    const current = await context();
    return current.claude.sessionId === proof.sessionId && current.native.state.nativePid === proof.pid
      && current.claude.chatState === 'success' && current.native.state.busy === false
      && current.messages.filter(message => message.sender === 'user' && message.text === proof.followup).length === 1;
  }, { timeout: 15000 }).toBe(true);
  proof.final = await context();
  assert.equal(proof.final.claude.totalCostUsd, proof.final.native.state.session.totalCostUsd);
  const filename = 'native-pty-reopened-compact.png';
  await page.screenshot({ path: join(output, filename), animations: 'disabled' });
  proof.captures.push(filename);
  await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
  await section.getByRole('button', { name: 'Stop session', exact: true }).click();
  await expect.poll(() => birth(proof.pid), { timeout: 15000 }).toBe(null);
  proof.stopped = true;
  proof.status = 'complete';
  await save();
  phase('starting-terminal-stop-complete');
}
