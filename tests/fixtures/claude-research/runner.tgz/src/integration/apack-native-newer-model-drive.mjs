import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { lstat, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { hash } from '../artifacts/runs.mjs';
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs';
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs';
import { ageNewerModelResumeJournal, serveSyntheticInference } from '../protocol/native-newer-model-resume.mjs';
import { addNativeModelPanelFixture } from '../protocol/native-model-panel-fixture.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs';
import { prepareNativeAppCliProfile } from './native-app-cli-profile.mjs';
import { processStart } from './native-process-state.mjs';

const executable = '/frozen-claude/claude';
const pin = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10';
const older = 'claude-opus-5';
const newer = 'claude-opus-5-5';
const seed = 'Prepare the release note for review.';
const reply = 'The release note is ready.';
const draft = 'Keep the migration checklist wording.';
const editedIdleDraft = draft + ' Retain this note too.';
const followup = 'Continue the same release note review.';
const customBindings = { bindings: [{ context: 'Chat', bindings: {
  'ctrl+y': null, 'ctrl+alt+p': 'chat:defaultToNewerModel',
} }] };
const quotaTier = 'default_claude_max_5x';
const quotaPromptTokens = 50_000;
const warmPrompt = 'Keep reviewing the release note before the cache cools.';

export async function driveNativeNewerModel({ checkout, workspace, env, decision }) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-newermodel[0-9]+$/);
  assert.ok(['accept', 'keep', 'escape', 'inline', 'configured', 'expired', 'refused', 'quota-resume', 'quota-dismiss',
    'quota-new', 'quota-idle', 'quota-no-pointer', 'quota-grace'].includes(decision));
  const configured = decision === 'configured' || decision === 'expired';
  const quota = decision.startsWith('quota-');
  const idleQuota = decision === 'quota-idle';
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly);
  assert.equal(boundary.newerModelDesktopDecision, decision);
  assert.match(await readFile('/etc/hosts', 'utf8'), /^127\.0\.0\.1\s+api\.anthropic\.com(?:\s|$)/m);
  assert.equal(hash(await readFile(executable)), pin);

  const project = join(workspace, 'project');
  await mkdir(project);
  execFileSync('/usr/bin/git', ['init', '--quiet', '-b', 'main'], { cwd: project, timeout: 5000,
    env: { PATH: '/usr/bin:/bin', HOME: workspace, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_NOSYSTEM: '1' } });
  const account = await configureNativeCreditAccount(workspace, 'oauth', { featureCache: 'native-defaults' });
  const profile = await prepareNativeAppCliProfile({ checkout, workspace, account, owned: true });
  const configFile = join(profile, '.claude.json');
  const config = JSON.parse(await readFile(configFile, 'utf8'));
  assert.equal(config.growthBookOverrides, undefined);
  assert.equal(config.cachedGrowthBookFeatures, undefined);
  await writeFile(configFile, JSON.stringify({ ...config, hasCompletedOnboarding: true, projects: {
    [project]: { hasTrustDialogAccepted: true, hasCompletedProjectOnboarding: true },
  } }));
  const settingsFile = join(profile, 'settings.json');
  if (decision === 'refused') {
    await addNativeModelPanelFixture(workspace, profile);
    await writeFile(join(workspace, 'native-model-hook-mode'), 'deny');
  }
  const settings = JSON.parse(await readFile(settingsFile, 'utf8'));
  await writeFile(settingsFile, JSON.stringify({ ...settings, model: older, ...(idleQuota && { promptCacheTtl: '5m' }) }));
  if (configured) await writeFile(join(profile, 'keybindings.json'), JSON.stringify(customBindings), { flag: 'wx', mode: 0o600 });
  const tls = await prepareNativeCreditTls(join(workspace, 'account-tls'));
  const model = await startSyntheticModel(workspace, 'TextOnly', { captureMessages: true, textReply: reply, maxRequests: 15,
    textInputTokens: quota ? quotaPromptTokens : undefined, textCacheCreation: idleQuota });
  let billing;
  try {
    billing = await startNativeCreditBilling(tls, { newerModelOfferForm: quota ? undefined : decision === 'inline' || configured ? 'line' : 'dialog',
      coldResumeQuotaRollout: quota, coldResumeQuotaIdle: idleQuota,
      coldResumeQuotaPointerDisabled: decision === 'quota-no-pointer', coldResumeQuotaPrefersNew: decision === 'quota-grace',
      evidencePath: join(workspace, 'provider.json'),
      managedConnector: (req, res) => serveSyntheticInference(req, res, model) });
    const launch = { ...env, ...account, NODE_EXTRA_CA_CERTS: tls.ca, ANTHROPIC_BASE_URL: 'https://api.anthropic.com',
      DISABLE_AUTOUPDATER: '1', PATH: '/frozen-claude:' + env.PATH, CLAUDE_RESEARCH_PROJECT: project };
    for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_MODEL', 'DISABLE_GROWTHBOOK',
      'CLAUDE_INTERNAL_FC_OVERRIDES', 'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC', 'DISABLE_TELEMETRY']) delete launch[key];
    if (quota) {
      launch.CLAUDE_CODE_SUBSCRIPTION_TYPE = 'max';
      launch.CLAUDE_CODE_RATE_LIMIT_TIER = quotaTier;
    }
    const route = idleQuota ? 'real-Electron-native-idle-quota' : quota ? 'real-Electron-native-cold-resume-quota' : 'real-Electron-native-newer-model';
    await driveFreshNativeApp({ checkout, workspace, env: launch, route, journeyBudgetMs: idleQuota ? 420000 : 145000,
      journey: args => verifyOffer({ ...args, decision, profile, settingsFile, settings, model }) });
  } finally {
    await writeFile(join(workspace, 'newer-model-app-model-calls.json'), JSON.stringify(model.calls, null, 2));
    await Promise.all([model.close(), billing?.close()]);
  }
}

async function verifyOffer({ app, page, output, project, expect, userDataDir, workspace, phase, decision, profile, settingsFile, settings, model }) {
  const installed = join(userDataDir, 'apack/packs/default-setup');
  const frozen = JSON.parse(await readFile('/control/producer-pack-inputs.json', 'utf8'));
  for (const file of ['runtime/fe.js', 'runtime/index.cjs']) assert.equal(hash(await readFile(join(installed, file))), frozen[file]);
  const proof = { status: 'running', decision, captures: [] };
  const quota = decision.startsWith('quota-');
  const idleQuota = decision === 'quota-idle';
  const pointerDisabled = decision === 'quota-no-pointer';
  const grace = decision === 'quota-grace';
  const configured = decision === 'configured' || decision === 'expired';
  const inline = decision === 'inline' || configured;
  const shortcut = configured ? 'Control+Alt+p' : 'Control+y';
  const advertised = (states, key, alt) => states.some(keys => keys.bindings.some(binding => binding.length === 1 &&
    binding[0].key === key && binding[0].ctrl && binding[0].alt === alt && !binding[0].shift && !binding[0].super));
  const save = () => writeFile(join(output, 'newer-model-desktop.json'), JSON.stringify(proof, null, 2));
  const context = () => page.evaluate(() => {
    const data = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    const threadId = data.currentThread?.id;
    const view = Object.values(data.nativeTerminalViews).find(entry => entry.threadId === threadId);
    const ui = Object.values(data.nativeUiViews).filter(entry => entry.threadId === threadId && !!entry.attachmentId);
    return { threadId, claude: data.currentThread?.context?.claudeCode, state: view?.state,
      noticeAnswer: view?.noticeAnswer, actionKeys: ui.map(entry => entry.state.actionKeys).filter(Boolean) };
  });
  const card = page.locator('[data-onboarding-id="agent-chat-input"]');
  const editor = card.locator('[contenteditable="true"]');
  const send = card.getByRole('button', { name: 'Send', exact: true });
  const region = page.getByRole('region', { name: 'Claude native interface', exact: true });
  const open = region.getByRole('button', { name: 'Use native interface', exact: true });
  const back = region.getByRole('button', { name: 'Back to conversation', exact: true });
  const offer = inline ? page.getByRole('status', { name: 'Claude model offer', exact: true }) :
    page.getByRole('dialog', { name: quota ? 'Claude quota offer' : 'Claude newer model offer', exact: true });
  const accept = offer.getByRole('button', { name: quota ? 'Resume' : 'Continue with Opus 5.5', exact: true });
  const keep = offer.getByRole('button', { name: quota ? /^Start a new conversation/ : 'Keep Opus 5', exact: !quota });
  const editorState = () => editor.evaluate(element => ({ doc: element.editor.state.doc.toJSON(), selection: element.editor.state.selection.toJSON() }));
  const hasPrompt = (value, text) => value === text || Array.isArray(value) && value.some(block => block.text === text);
  const received = text => model.calls.filter(call => call.path?.split('?')[0] === '/v1/messages' &&
    hasPrompt(call.messages?.findLast(message => message.role === 'user')?.content, text));
  const journalPath = async sessionId => {
    assert.match(sessionId, /^[a-f0-9-]{36}$/);
    const directory = join(profile, 'projects');
    const matches = (await readdir(directory, { recursive: true })).filter(path => basename(path) === sessionId + '.jsonl');
    assert.equal(matches.length, 1);
    const path = join(directory, matches[0]);
    const info = await lstat(path);
    assert.ok(info.isFile() && info.uid === process.getuid() && info.size <= 16 * 1024 ** 2);
    return path;
  };
  const retainDraft = async () => {
    await editor.fill(draft);
    await editor.press('Home');
    await editor.press('Shift+End');
    proof.retained = await editorState();
  };
  try {
    await app.waitForSurface('default-setup/threads');
    await app.navigate('default-setup/threads');
    await expect.poll(() => page.evaluate(() => {
      const data = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
      return !!data.currentThread?.id && data.tabs.every(tab => data.tabsRead.includes(tab.id)) && data.modes.some(mode => mode.name === 'Claude Code');
    }), { timeout: 15000 }).toBe(true);
    await page.evaluate(directory => {
      const threads = window.applicationState.system.get('default-setup/threads');
      threads.send({ type: 'VIEW_DASHBOARD' });
      threads.send({ type: 'NEW_THREAD_IN_PROJECT', directory });
      threads.send({ type: 'SET_MODE', mode: 'Claude Code' });
      threads.send({ type: 'SET_PHASE', phase: 'Edit' });
    }, project);
    await editor.fill(seed);
    await send.click();
    await expect.poll(async () => (await context()).claude?.chatState, { timeout: 30000 }).toBe('success');
    assert.deepEqual(received(seed).map(call => call.model), [older]);
    const initial = await context();
    proof.threadId = initial.threadId;
    proof.sessionId = initial.claude.sessionId;
    const journal = await journalPath(proof.sessionId);
    const original = await readFile(journal);
    await writeFile(join(output, 'newer-model-seed.jsonl'), original);
    if (!idleQuota) {
      const { offsetMs, aged } = ageNewerModelResumeJournal(original);
      await writeFile(journal, aged);
      proof.age = { offsetMs, originalSha256: hash(original), agedSha256: hash(aged) };
    }
    if (!quota) await writeFile(settingsFile, JSON.stringify({ ...settings, model: newer }));
    if (!idleQuota) await retainDraft();
    await open.click();
    await expect.poll(async () => (await context()).state?.status, { timeout: 25000 }).toBe('live');
    proof.before = (await context()).state;
    assert.equal(proof.before.sessionId, proof.sessionId);
    const started = await processStart(proof.before.nativePid);
    assert.ok(started);
    const argv = (await readFile(`/proc/${proof.before.nativePid}/cmdline`, 'utf8')).split('\0');
    const modelFlag = argv.indexOf('--model');
    proof.nativeModelArgument = modelFlag === -1 ? null : argv[modelFlag + 1];
    proof.terminalResume = await region.locator('[data-terminal-text]').first().innerText({ timeout: 3000 }).catch(() => null);
    await back.click();
    let warmAt;
    if (idleQuota) {
      await expect(offer).toBeHidden();
      await editor.fill(warmPrompt);
      await send.click();
      await expect.poll(() => received(warmPrompt).map(call => call.fixtureCacheUsage?.cache_creation?.ephemeral_5m_input_tokens), { timeout: 20000 }).toEqual([quotaPromptTokens]);
      warmAt = performance.now();
      await expect.poll(async () => (await context()).state?.busy, { timeout: 15000 }).toBe(false);
      await retainDraft();
      await expect(offer).toBeHidden();
      await expect(editor).toBeFocused();
      phase('native-idle-quota-cache-armed');
      await save();
    }
    await expect(offer).toBeVisible({ timeout: idleQuota ? 350000 : 15000 });
    const shownAt = performance.now();
    if (idleQuota) {
      proof.warmToOfferMs = Math.round(shownAt - warmAt);
      assert.ok(proof.warmToOfferMs >= 290_000, 'Offer appeared before the five-minute native cache expiry');
      await expect(editor).toBeFocused();
      assert.deepEqual(await editorState(), proof.retained);
      await expect(send).toBeDisabled();
    }
    assert.equal(proof.nativeModelArgument, null, 'Resume inherited an effective model as an explicit override');
    proof.notice = (await context()).state.notice;
    assert.equal(proof.notice.sessionId, proof.sessionId);
    let choseNewWithEnter = false;
    if (grace) {
      await expect(keep).toBeFocused({ timeout: 1500 });
      proof.enterSinceOfferVisibleMs = Math.round(performance.now() - shownAt);
      await page.keyboard.press('Enter');
      await expect.poll(async () => (await context()).noticeAnswer?.status ?? '', { timeout: 8000 }).toMatch(/^(?:done|error)$/);
      const answered = await context();
      proof.firstEnter = answered.noticeAnswer;
      choseNewWithEnter = answered.noticeAnswer.status === 'done';
      if (!choseNewWithEnter) {
        if (answered.noticeAnswer.problem === 'Native quota choice is temporarily refused') {
          await expect(offer.getByRole('alert')).toContainText(answered.noticeAnswer.problem);
        } else {
          assert.equal(answered.noticeAnswer.problem, 'Native quota offer changed or expired');
          await expect.poll(async () => {
            const notice = (await context()).state?.notice;
            return notice?.id === proof.notice.id && notice.revision !== proof.notice.revision;
          }).toBe(true);
        }
        const current = await context();
        assert.equal(current.state.notice.id, proof.notice.id);
        assert.equal(current.state.sessionId, proof.sessionId);
        assert.deepEqual(await editorState(), proof.retained);
        await expect.poll(() => Math.round(performance.now() - shownAt), { timeout: 4000 }).toBeGreaterThan(1300);
      }
      await save();
    }
    if (quota) {
      assert.equal(proof.notice.kind, 'cold_resume_quota');
      assert.equal(proof.notice.trigger, idleQuota ? 'idle' : 'resume');
      assert.equal(proof.notice.preferredChoice, grace ? 'quota_new_conversation' : 'quota_resume');
      assert.match(proof.notice.paragraphs.join(' '), /50k tokens long/);
      assert.match(proof.notice.paragraphs.join(' '), /about 8% of\s+your 5-hour usage limit/);
    }
    for (const [size, viewport] of choseNewWithEnter ? [] : [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
      await page.setViewportSize(viewport);
      if (inline) {
        await expect(offer).toContainText(configured ? /press\s+ctrl\+alt\+p\s+to continue with\s+Opus 5\.5/i :
          /press\s+ctrl\+y\s+to continue with\s+Opus 5\.5/i);
        await expect(offer).toBeInViewport({ ratio: 1 });
      } else {
        await expect(keep).toBeInViewport({ ratio: 1 });
        await expect(accept).toBeInViewport({ ratio: 1 });
      }
      await expect(editor).toHaveText(draft);
      const name = (quota ? 'cold-resume-quota-' : 'newer-model-') + size + '.png';
      await page.screenshot({ path: join(output, name), animations: 'disabled' });
      proof.captures.push(name);
    }
    if (idleQuota) {
      await editor.press('End');
      await page.keyboard.insertText(' Retain this note too.');
      await expect(editor).toHaveText(editedIdleDraft);
      await expect(send).toBeDisabled();
      assert.equal(received(editedIdleDraft).length, 0);
      proof.retained = await editorState();
    }
    if (inline) {
      await editor.press(shortcut);
      await expect(offer).toBeVisible();
      assert.deepEqual(await editorState(), proof.retained);
      assert.equal((await context()).state.session.model, older);
      await editor.press('ControlOrMeta+a');
      await editor.press('Backspace');
      await expect(editor).toBeEmpty();
      const currentShortcut = async () => advertised((await context()).actionKeys, configured ? 'p' : 'y', configured);
      await expect.poll(currentShortcut, { timeout: 8000 }).toBe(true);
      if (configured) {
        assert.ok(!advertised((await context()).actionKeys, 'y', false));
        await editor.press('Control+y');
        await expect(offer).toBeVisible();
        assert.equal((await context()).state.session.model, older);
      }
      if (decision === 'expired') {
        await expect(offer).toBeHidden({ timeout: 70000 });
        proof.observedLifetimeMs = Math.round(performance.now() - shownAt);
        assert.ok(proof.observedLifetimeMs >= 40000, 'Original offer disappeared before its native expiry');
        await expect.poll(currentShortcut, { timeout: 8000 }).toBe(false);
      }
      await editor.press(shortcut);
    } else if (decision === 'escape' || decision === 'quota-dismiss') await keep.press('Escape');
    else if (!choseNewWithEnter) await (['accept', 'refused', 'quota-resume', 'quota-idle'].includes(decision) ? accept : keep).click();
    await expect(offer).toBeHidden({ timeout: 15000 });
    if (!inline) assert.deepEqual(await editorState(), proof.retained);
    if (decision === 'quota-new' || pointerDisabled || grace) {
      await expect.poll(async () => {
        const current = await context();
        return current.state?.sessionId !== proof.sessionId && current.claude?.sessionId === current.state?.sessionId &&
          /^[a-f0-9-]{36}$/.test(current.state?.sessionId ?? '');
      }, { timeout: 15000 }).toBe(true);
      proof.newSessionId = (await context()).state.sessionId;
      assert.deepEqual(await editorState(), proof.retained);
    }
    if (decision === 'refused') {
      const receipts = join(workspace, 'native-model-hook-receipts.jsonl');
      await expect.poll(async () => (await readFile(receipts, 'utf8').catch(error => {
        if (error.code === 'ENOENT') return '';
        throw error;
      })).includes('"phase": "answer"'), { timeout: 12000 }).toBe(true);
      const runs = (await readFile(receipts, 'utf8')).trim().split('\n').map(JSON.parse);
      proof.refusalHooks = runs.filter(row => row.phase === 'answer' && row.mode === 'deny').map(row => row.input);
      assert.ok(proof.refusalHooks.some(input => input.hook_event_name === 'PreModelSwitch' && input.source === 'command' && input.session_id === proof.sessionId));
      const warning = page.getByText('Model switch to Opus 5.5 was blocked by a PreModelSwitch hook: Keep the current model for the review.', { exact: true }).filter({ visible: true });
      await expect(warning).toBeVisible({ timeout: 12000 });
      await warning.scrollIntoViewIfNeeded();
      await expect(warning).toBeInViewport({ ratio: 1 });
      await page.screenshot({ path: join(output, 'newer-model-refused-compact.png'), animations: 'disabled' });
      proof.captures.push('newer-model-refused-compact.png');
    }
    const nextPrompt = idleQuota ? editedIdleDraft : followup;
    if (!idleQuota) await editor.fill(nextPrompt);
    await expect(editor).toHaveText(nextPrompt);
    await send.click();
    const expected = decision === 'accept' || decision === 'inline' || decision === 'configured' ? newer : older;
    await expect.poll(() => received(nextPrompt).map(call => call.model), { timeout: 20000 }).toEqual([expected]);
    await expect.poll(async () => (await context()).state?.busy, { timeout: 15000 }).toBe(false);
    const final = await context();
    assert.equal(final.threadId, proof.threadId);
    assert.equal(final.state.sessionId, proof.newSessionId ?? proof.sessionId);
    assert.equal(final.state.ownerId, proof.before.ownerId);
    assert.equal(await processStart(final.state.nativePid), started);
    await open.click();
    await region.getByRole('button', { name: 'Stop session', exact: true }).click();
    await expect.poll(() => processStart(final.state.nativePid), { timeout: 15000 }).not.toBe(started);
    const saved = await readFile(proof.newSessionId ? await journalPath(proof.newSessionId) : journal);
    const rows = saved.toString('utf8').split('\n').filter(Boolean).map(JSON.parse);
    assert.equal(rows.filter(row => row.type === 'user' && hasPrompt(row.message?.content, nextPrompt)).length, 1);
    assert.equal(rows.filter(row => row.type === 'user' && hasPrompt(row.message?.content, seed)).length, proof.newSessionId ? 0 : 1);
    if (idleQuota) {
      assert.equal(rows.filter(row => row.type === 'user' && hasPrompt(row.message?.content, warmPrompt)).length, 1);
      assert.equal(rows.filter(row => row.type === 'user' && hasPrompt(row.message?.content, draft)).length, 0);
    }
    if (proof.newSessionId) {
      const prior = await readFile(journal);
      await writeFile(join(output, 'cold-resume-previous-journal.jsonl'), prior);
      assert.ok(!prior.includes(followup));
      const pointer = rows.find(row => row.type === 'user' && row.isMeta === true && JSON.stringify(row.message?.content).includes(`session ${proof.sessionId}`));
      if (pointerDisabled) {
        assert.equal(pointer, undefined, 'The original rollout disallowed prior-session pointers');
        const sent = JSON.stringify(received(followup)[0].messages);
        assert.ok(!sent.includes(proof.sessionId) && !sent.includes(seed));
      } else {
        assert.ok(pointer, 'The original new conversation did not include its prior-session pointer');
        proof.pointerUuid = pointer.uuid;
      }
    }
    assert.equal(rows.findLast(row => row.type === 'assistant')?.message?.model, expected);
    if (decision === 'refused') assert.match(saved.toString('utf8'), /Keep the current model for the review\./);
    await writeFile(join(output, 'newer-model-followup.jsonl'), saved);
    proof.status = 'complete';
    proof.model = expected;
  } catch (error) {
    proof.status = 'failed';
    proof.error = error.message;
    proof.failure = await context().catch(() => undefined);
    await page.screenshot({ path: join(output, 'newer-model-failure.png'), timeout: 5000 }).catch(() => {});
    throw error;
  } finally {
    await save();
  }
}
