/** Native-only contract diagnostic; artificial controls are not everyday app acceptance. */
export const nativeBackgroundDrawingAuditSource = String.raw`
let drawingSamples=0;
on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
 const builtin=await next(e),{Box,Text,Button}=$.ui.resolve(e);
 const drawn=Box({children:[builtin,Text({children:['Native child drawing contract']}),Button({key:'child-drawing-proof',label:'Native child drawing proof',hotkey:'1',onPress:async()=>{const sessionId=await $.session.id();let prompt;if(e.surface==='desktop'){const before=await $.prompt.read(),filled=await $.prompt.fill({text:'Owned child desktop replacement あ🙂',mode:'replace'}),after=await $.prompt.read();prompt={before,filled,after};}await $.fs.write('native-child-drawing-press-'+sessionId+'.json',JSON.stringify({sessionId,callback:true,...(prompt?{prompt}:{}),at:await $.clock.now()}));}})]});
 if(drawingSamples<6){const sessionId=await $.session.id(),record={sessionId,surface:e.surface,component:e.component,requestId:e.requestId,props:e.props,builtin,drawn},text=JSON.stringify(record);if(text.length<=32768)await $.fs.write('native-child-drawing-'+sessionId+'-'+(drawingSamples++)+'.json',text);}
 return drawn;
});
on('ui.press',{element:'child-drawing-proof'},async($,e,next)=>{const result=await next(e),sessionId=await $.session.id();await $.fs.write('native-child-drawing-dispatch-'+sessionId+'.json',JSON.stringify({sessionId,event:e,result,at:await $.clock.now()}));return result;});
`;
