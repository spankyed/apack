"""Verify frozen full-app restart evidence without executing the recovered/native target."""
import argparse, hashlib, json, subprocess, tarfile
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence', type=Path)
for name in ('product', 'research'):
    parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--' + name + '-commit', required=True)
a = parser.parse_args()
root = a.evidence.resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
def read(path):
    return json.loads(path.read_text())
def unique(name):
    paths = list((root / 'records').rglob(name))
    assert len(paths) == 1, (name, len(paths))
    return paths[0]
def inputs(file, repository, revision):
    commit = subprocess.check_output(['git', 'rev-parse', '--verify', '--end-of-options', revision + '^{commit}'], cwd=repository, text=True).strip()
    values = read(root / file)
    assert values
    for name, digest in values.items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        blob = subprocess.check_output(['git', 'show', commit + ':' + name], cwd=repository)
        assert sha(blob) == digest, name
    return commit, len(values)
product, product_count = inputs('source-inputs.json', a.product, a.product_commit)
research, research_count = inputs('authored-inputs.json', a.research, a.research_commit)
before = read(root / 'compiled-before.json')
assert before == read(root / 'compiled-after.json')
boundary = read(root / 'offline-boundary.json')
assert boundary['networkDisabled'] and boundary['pinnedExecutableReadOnly']
assert set(boundary['networks']) == {'none'}
assert boundary['memory'] == boundary['memorySwap'] == 6 * 1024**3
assert boundary['nanoCpus'] == 2 * 10**9
frames = []
for line in unique('stdout.bin').read_text().splitlines():
    try:
        value = json.loads(line)
    except json.JSONDecodeError:
        continue
    if value.get('evidence') == 'apack-native-terminal-owner-app':
        frames.append(value)
assert len(frames) == 1
frame = frames[0]
assert frame['actualAppGui'] and frame['nativeBackgroundAppRestart'] and frame['realModelRequests'] == 0
assert frame['targetSha256'] == '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
manifest = read(unique('manifest.json'))
assert manifest['status'] == 'complete' and manifest['code'] == 0 and manifest['signal'] is None
x = read(unique('background-app-restart-observation.json'))
saved = x['saved']; job = saved['job']
assert x['phase'] == 'verified' and x['mainPid'] != saved['mainPid'] and x['apiPid'] != saved['apiPid']
assert x['oldMain']['state'] == x['oldApi']['state'] == 'gone'
assert x['worker']['start'] == x['workerAfterReply']['start'] == saved['worker']['start']
assert x['worker']['state'] != 'Z' and x['workerAfterReply']['state'] != 'Z'
assert x['replyVisible'] and x['replyDraft'] == saved['retainedReply']
assert x['freshStatus'] and x['afterRefresh']['native']['backgroundInfo']['observedAt'] > x['reopenedAt']
info = x['parentAfterReply']['native']['backgroundInfo']
assert info['sessionId'] == job['sessionId'] and info['pid'] == job['pid'] and info['observedAt'] > x['reopenedAt']
assert job['sessionId'] in info['statusLine']
normalize = lambda value: '\n'.join(line.strip() for line in value.strip().split('\n') if line.strip())
helpers = [json.loads(line) for line in unique('background-formatter-helper.jsonl').read_text().splitlines()]
assert any(row['sessionId'] == job['sessionId'] and row['at'] > x['reopenedAt'] and normalize(row['stdout']) == info['statusLine'] for row in helpers)
audit = [json.loads(line) for line in unique('background-broker-audit.jsonl').read_text().splitlines()]
assert any(row['pid'] == x['apiPid'] and row['path'] == '/background-formatter' and row['status'] == 200 and normalize(row['input']['stdout']) == info['statusLine'] for row in audit)
for snapshot in [x['after'], x['afterRefresh'], x['parentAfterReply']]:
    assert snapshot['sessionId'] == saved['before']['sessionId']
    assert snapshot['messages'] == saved['before']['messages']
    assert snapshot['claude']['totalCostUsd'] == saved['before']['claude']['totalCostUsd']
rows = [json.loads(line) for line in unique(job['sessionId'] + '.jsonl').read_text().splitlines() if line]
assert rows[:len(x['rows'])] == x['rows']
humans = [row for row in rows if row.get('origin', {}).get('kind') == 'human' and row.get('message', {}).get('content') == saved['retainedReply']]
assert len(humans) == 1
by_id = {row['uuid']: row for row in rows if row.get('uuid')}
def answered(row):
    if row.get('type') != 'assistant' or not any(block.get('type') == 'text' and block.get('text') for block in row.get('message', {}).get('content', [])):
        return False
    parent = row.get('parentUuid'); seen = set()
    while parent and parent not in seen:
        if parent == humans[0]['uuid']:
            return True
        seen.add(parent); previous = by_id.get(parent, {})
        if previous.get('origin', {}).get('kind') == 'human':
            return False
        parent = previous.get('parentUuid')
    return False
assert any(answered(row) for row in rows)
starts = [json.loads(line) for line in unique('native-children.jsonl').read_text().splitlines() if line]
assert not any(row['at'] > saved['savedAt'] and any(arg in ['--print', '--resume'] for arg in row['args']) for row in starts)
def retired(state, identity):
    return state['state'] in ['gone', 'Z'] or bool(state.get('start')) and state['start'] != identity['start']
assert retired(x['workerAfterStop'], saved['worker'])
assert retired(x['authorityAfterStop'], x['authority']['process'])
compiled_runtime = {name.split('/packages/default-setup/dist/')[1]: digest for name, digest in before['files'].items() if '/packages/default-setup/dist/runtime/' in name}
installed = set()
with tarfile.open(root / 'raw-evidence.tgz') as archive:
    for member in archive:
        if member.isfile() and '/packs/default-setup/runtime/' in member.name:
            name = member.name.split('/packs/default-setup/')[1]
            assert sha(archive.extractfile(member).read()) == compiled_runtime[name], name
            installed.add(name)
assert {name for name in compiled_runtime if not name.endswith('.map')} <= installed
assert 'runtime/fe.js' in installed and 'runtime/index.cjs' in installed
for name, digest in frame['compiledPackHashes'].items():
    if name.startswith('runtime/'):
        assert compiled_runtime[name] == digest
review = read(root / 'visual-review.json')
assert len(review['captures']) == 8
for stage in ['before', 'reopened', 'reply', 'stopped']:
    for size in ['normal', 'compact']:
        matches = [item for item in review['captures'] if Path(item['path']).name == 'apack-native-background-app-' + stage + '-' + size + '.png']
        assert len(matches) == 1 and matches[0]['opened']
        path = (root / matches[0]['path']).resolve(); assert path.is_relative_to(root)
        assert sha(path.read_bytes()) == matches[0]['sha256']
telemetry = [json.loads(line) for line in (root / 'memory-telemetry.jsonl').read_text().splitlines()]
assert telemetry
for row in telemetry:
    events = dict(line.split() for line in row['memory.events'].splitlines())
    assert int(events['oom']) == int(events['oom_kill']) == 0
models = read(unique('model-calls.json')); requests = len(models['seed']) + len(models['agent'])
assert requests == 14
report = {'status': 'scoped-full-app-restart-accepted', 'verifierSha256': sha(Path(__file__).read_bytes()), 'productCommit': product, 'researchCommit': research, 'productInputsVerified': product_count, 'researchInputsVerified': research_count, 'compiledFilesUnchanged': len(before['files']), 'installedRuntimeFilesVerified': len(installed), 'bothAppProcessesReplaced': True, 'workerPid': job['pid'], 'workerStart': saved['worker']['start'], 'bothDraftsHistoryCostPreserved': True, 'freshNativeStatusAndReply': True, 'workerAndAuthorityRetired': True, 'reviewedCaptures': 8, 'syntheticModelRequests': requests, 'realModelRequests': 0, 'memoryPeakBytes': max(int(row['memory.peak']) for row in telemetry), 'oom': False, 'limits': ['One linked child in an owned Linux profile; other window, owner, policy and stale-action contexts remain open.', 'Compact expanded replies retain existing inner scrolling; full everyday layout polish remains open.', 'Original combined F1–F5 remains open.']}
(root / 'app-recovery-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
