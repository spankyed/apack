import { addTerminalClientFixture } from '../protocol/terminal-client-fixture.mjs';
import { nativeCommandInspector } from '../protocol/native-command-inspector.mjs';
import { nativeManagedFiles } from '../protocol/native-managed-files.mjs';
import { nativeDialogInspector } from '../protocol/native-dialog-inspector.mjs';
import assert from 'node:assert/strict';
import { stripVTControlCharacters } from 'node:util';
import { createNativeTestImage } from '../protocol/native-test-image.mjs';
import { mkdir, readFile, writeFile, readdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { startSyntheticAgentModel } from '../protocol/synthetic-agent-model.mjs';
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs';
import { hash } from '../artifacts/runs.mjs';
const [checkout,executable,workspace,scenario,extension]=process.argv.slice(2);
const managedRestriction=['managed-no-helper','managed-disable-hooks'].includes(scenario);
const managedScenario=scenario==='managed-transition'||managedRestriction||scenario==='managed'||scenario==='managed-snapshot';
assert.equal(process.env.HOME,workspace);
assert.equal(hash(await readFile(executable)),'5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');
for(const name of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[name],undefined);
const root=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const { query }=await import(pathToFileURL(join(root,'query.ts')).href);
const store=await import(pathToFileURL(join(root,'handle-store.ts')).href);
const { getClaudeUiOwner }=await import(pathToFileURL(join(root,'ui-owner.ts')).href);
const { mountClaudeUi }=await import(pathToFileURL(join(root,'ui-mount.ts')).href);
const { prepareClaudeNativeTerminal }=await import(pathToFileURL(join(root,'terminal-owner.ts')).href);
const configDir=join(workspace,'user-config');await mkdir(configDir);
await mkdir(join(configDir,'agents'),{recursive:true});
await writeFile(join(configDir,'agents/status-fixture.md'),'---\nname: status-fixture\ndescription: Disposable native status worker\ntools: []\n---\nNativeStatusChildSystem. Return the requested fixed worker marker without tools.\n');
const mainHelper=join(workspace,'main.py'),subHelper=join(workspace,'sub.py');
await writeFile(mainHelper,"import json,sys,os\np=json.load(sys.stdin)\nwith open("+JSON.stringify(join(workspace,'helper-bun-options.json'))+",'w') as f: json.dump(os.environ.get('BUN_OPTIONS'),f)\nprint('AppOwnedMain '+p['session_id']+' prefix='+os.environ.get('APACK_PREFIX_FIXTURE','original'))\nprint('Second native app status line')\n");
await writeFile(subHelper,"import json,sys,os\np=json.load(sys.stdin)\nprint('invalid fixture line')\nprint(json.dumps({'id':'foreign','content':'ForeignMustNotReachApp'}))\nfor t in p['tasks']:\n    print(json.dumps({'id':t['id'],'content':'AppOwnedAgent '+t['status']+' prefix='+os.environ.get('CLAUDE_CODE_SHELL_PREFIX','unset')}))\n");
const prefixPath=join(workspace,"user's shell prefix"),prefixLog=join(workspace,'prefix-calls.jsonl'),shellPrefix=prefixPath+' --fixture-prefix';
await writeFile(prefixPath,`#!/usr/bin/python3
import json,os,subprocess,sys
with open(${JSON.stringify(prefixLog)},'a') as f:f.write(json.dumps({'args':sys.argv[1:],'prefix':os.environ.get('CLAUDE_CODE_SHELL_PREFIX')})+'\\n')
sys.exit(subprocess.run(['/bin/sh','-c',sys.argv[-1]],stdin=sys.stdin,stdout=sys.stdout,stderr=sys.stderr).returncode)
`,{mode:0o700});
const settings={env:{CLAUDE_CODE_SHELL_PREFIX:shellPrefix},apiKeyHelper:'/usr/bin/printf research-fixture-key',statusLine:{type:'command',command:`/usr/bin/python3 '${mainHelper}'`,refreshInterval:1},subagentStatusLine:{type:'command',command:`/usr/bin/python3 '${subHelper}'`}};
const privatePolicy=join(workspace,'policy');
if(managedScenario){
 await mkdir(privatePolicy);
 await writeFile(join(privatePolicy,'managed-settings.json'),JSON.stringify(scenario==='managed-no-helper'?{allowManagedHooksOnly:true}:{allowManagedHooksOnly:true,...(scenario==='managed-disable-hooks'?{disableAllHooks:true}:{}),statusLine:settings.statusLine,subagentStatusLine:settings.subagentStatusLine}));
}
await writeFile(join(configDir,'settings.json'),JSON.stringify(managedScenario?{...settings,statusLine:{type:'command',command:'/usr/bin/printf UserMustNotExecute'},subagentStatusLine:{type:'command',command:'/usr/bin/printf UserAgentMustNotExecute'}}:settings));
if(managedRestriction){
 const commands={};
 for(const kind of ['main','sub']){const helper=join(workspace,'forbidden-'+kind+'.py');await writeFile(helper,'from pathlib import Path\nPath('+JSON.stringify(join(workspace,'forbidden-'+kind+'.executed'))+').write_text("executed")\nprint("ForbiddenUserHelper")\n');commands[kind]=`/usr/bin/python3 '${helper}'`;}
 await writeFile(join(configDir,'settings.json'),JSON.stringify({...settings,statusLine:{type:'command',command:commands.main,refreshInterval:1},subagentStatusLine:{type:'command',command:commands.sub}}));
}
let uiPluginDir;
if(scenario==='ui-engine'){
 uiPluginDir=join(workspace,'native-ui-fixture');await mkdir(join(uiPluginDir,'.claude-plugin'),{recursive:true});await mkdir(join(uiPluginDir,'hooks'));
 await writeFile(join(uiPluginDir,'.claude-plugin/plugin.json'),JSON.stringify({name:'native-ui-owner-fixture',version:'0.0.1'}));
 await writeFile(join(uiPluginDir,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
 await writeFile(join(uiPluginDir,'hooks/register.ts'),`export function register(on){let count=0,fillEvents=[],editEvents=[],paneRefused=false;on('session.start',async($,e,next)=>{if(e.surface==='terminal'){$.ui.status('Startup native status');$.ui.toast('Startup native toast',{timeoutMs:2000});await $.fs.write('native-ui-startup-notices.json',JSON.stringify({surface:e.surface}));}return next(e);});on('ui.focus',async($,e,next)=>{await $.fs.write('native-ui-focus.json',JSON.stringify(e));if(e.element==='focus-denied')return {deny:'Keep keyboard'};return next(e);});on('ui.scroll',async($,e,next)=>{await $.fs.write('native-ui-scroll.json',JSON.stringify(e));if(e.by===3)return {deny:'Keep scroll'};if(e.by===2)return next({...e,offset:e.offset+1});return next(e);});on('ui.close',async($,e,next)=>{await $.fs.write('native-ui-pane-close.json',JSON.stringify(e));if(!paneRefused){paneRefused=true;return {deny:'Keep native pane once'};}return next(e);});on('prompt.edit',async($,e,next)=>{editEvents.push(e);await $.fs.write('native-ui-edit-events.json',JSON.stringify(editEvents));const frame=await next(e);return {...frame,text:frame.text.toUpperCase(),decorations:[{start:0,end:frame.text.length,bold:true}]};});on('prompt.autocomplete',async($,e,next)=>{await $.fs.write('native-ui-autocomplete-request.json',JSON.stringify(e));const result=await next(e);return {...result,suggestions:[...result.suggestions,{text:'native-token',label:'Native token',description:'Pinned native completion'}]};});on('prompt.fill',async($,e,next)=>{fillEvents.push({text:e.text,origin:e.origin});await $.fs.write('native-ui-fill-events.json',JSON.stringify(fillEvents));return next(e);});on('ui.render',{component:'Pane'},async($,e,next)=>{const {Box,Text,Button}=$.ui.resolve(e);return Box({children:[Text({children:['Native pane body '+e.requestId]}),Button({key:'focus-target',label:'Target',onPress:async()=>{}}),Button({key:'focus-denied',label:'Denied',onPress:async()=>{}}),Box({key:'target-row',children:[Text({children:['Target row']})]}),Button({key:'follow-end',label:'Follow end',onPress:async()=>$.fs.write('native-ui-follow-end.json',JSON.stringify(await $.ui.scroll({to:'end',in:e.requestId})))}),Button({key:'move-plugin',label:'Plugin movement',onPress:async()=>{const focused=await $.ui.focus({key:'focus-target',requestId:e.requestId});const scrolled=await $.ui.scroll({to:{key:'target-row'},in:e.requestId,block:'start'});await $.fs.write('native-ui-plugin-movement.json',JSON.stringify({focused,scrolled}));}})]});});on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const {Box,Text,Button,Input,Select}=$.ui.resolve(e);return Box({children:[Text({children:['ProductNativeUi '+count]}),Button({key:'owned-notices',label:'Native notices',onPress:async()=>{$.ui.status('Live native status');$.ui.toast('Live native toast',{timeoutMs:1500});}}),Button({key:'clear-notices',label:'Clear native status',onPress:async()=>{$.ui.status();}}),Button({key:'owned-panes',label:'Open native panes',onPress:async()=>{await $.ui.open({id:'review-a',title:'Native review A',focus:true,closeOnEscape:true,holdToasts:true,rows:6,columns:40});await $.ui.open({id:'review-b',title:'Native review B'});}}),Button({key:'owned-press',label:'Owned fixture',onPress:async()=>{count++;await $.fs.write('native-ui-clicks.json',JSON.stringify({count}));$.ui.invalidate('ui.render');}}),Button({key:'owned-prompt',label:'Native prompt host',onPress:async()=>{const before=await $.prompt.read();const filled=await $.prompt.fill({text:'Native host replacement',mode:'replace'});const after=await $.prompt.read();const suggested=await $.prompt.suggest({text:'Native host suggestion'});await $.fs.write('native-ui-prompt-host.json',JSON.stringify({before,filled,after,suggested}));}}),Input({key:'owned-input',label:'Native note',rows:1,onInput:async value=>$.fs.write('native-ui-field.json',JSON.stringify({value})),onSubmit:async()=>{}}),Select({key:'owned-select',label:'Native choice',value:'concise',options:[{value:'concise',label:'Concise'},{value:'detailed',label:'Detailed'}],onSelect:async value=>$.fs.write('native-ui-choice.json',JSON.stringify({value}))}),await next(e)]});});}`);
}
if(scenario==='task-view'){
 uiPluginDir=join(workspace,'native-agent-submit-fixture');await mkdir(join(uiPluginDir,'.claude-plugin'),{recursive:true});await mkdir(join(uiPluginDir,'hooks'));
 await writeFile(join(uiPluginDir,'.claude-plugin/plugin.json'),JSON.stringify({name:'native-agent-submit-fixture',version:'0.0.1'}));
 await writeFile(join(uiPluginDir,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
 await writeFile(join(uiPluginDir,'hooks/register.ts'),`export function register(on){const events=[];on('prompt.submit',async($,e,next)=>{events.push({text:e.text,origin:e.origin});await $.fs.write('native-prompt-submit-events.json',JSON.stringify(events));if(e.text.includes('NativeAgentSteerFixture'))return {drop:'Agent prompt.submit trap'};return next(e);});}`);
}
if(scenario==='terminal-client'){
 uiPluginDir=join(workspace,'native-terminal-client-fixture');await mkdir(join(uiPluginDir,'.claude-plugin'),{recursive:true});await mkdir(join(uiPluginDir,'hooks'));
 await writeFile(join(uiPluginDir,'.claude-plugin/plugin.json'),JSON.stringify({name:'native-terminal-client-fixture',version:'0.0.1'}));
 await writeFile(join(uiPluginDir,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));await writeFile(join(uiPluginDir,'hooks/register.ts'),'export function register(on){}');
 await addTerminalClientFixture(uiPluginDir);
}
const seedModel=await startSyntheticModel(workspace,'TextOnly'),agentModel=await startSyntheticAgentModel(scenario==='task-view'?{steeringProbe:true,requestLimit:extension==='parent-lifecycle'?16:12,parentLaunchOnce:extension==='parent-lifecycle'}:managedScenario?{onPauseRequest:()=>writeFile(join(workspace,'managed-pause-ready.json'),'ready')}:{});
const userPreload=join(workspace,'user-preload.mjs'),userPreloadCalls=join(workspace,'user-preload-calls.jsonl');
await writeFile(userPreload,"import {appendFileSync} from 'node:fs';appendFileSync("+JSON.stringify(userPreloadCalls)+",JSON.stringify({pid:process.pid})+'\\n');");
if(scenario==='task-view')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+`
{const {writeFileSync:save}=await import('node:fs');const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js');const gate=await import('/$bunfs/root/chunk-ysbnj2tj.js');const globals=await import('/$bunfs/root/chunk-hdxpvbx1.js');let reading=false,cases,originalBinding,commandDialogs=[],commandHost;
 const timer=setInterval(async()=>{if(reading)return;reading=true;try{const active=runtime.ey();if(active?.surface!=='terminal')return;const binding=originalBinding??=active;const context=binding.toolContext(new AbortController()),state=context.getAppState();
  if(!cases){const rows=context.getMessages(),command={agentId:globals.Ze(),mode:'orphaned-permission',uuid:'native-admission-fixture'},queue={getCommandQueueSnapshot:()=>[],someSubmissionInFlight:()=>false,getInFlightDrainBatchStanding:()=> 'none',someInFlightDrainCommand:()=>false};const run=(changes={},read=()=>rows,signal)=>gate.ekt({...queue,...changes},read,signal)();
   cases={safe:run()===rows,queued:run({getCommandQueueSnapshot:()=>[command]})===undefined,inFlight:run({someSubmissionInFlight:fn=>fn(command)})===undefined,inFlightRecorded:run({someSubmissionInFlight:fn=>fn(command)},()=>[...rows,{uuid:command.uuid}])!==undefined,draining:run({someInFlightDrainCommand:fn=>fn(command)})===undefined,appendedDrain:run({getInFlightDrainBatchStanding:()=> 'appended',someInFlightDrainCommand:fn=>fn(command)})===rows,taskNotification:run({getCommandQueueSnapshot:()=>[{...command,mode:'task-notification'}]})===rows,foreignAgent:run({getCommandQueueSnapshot:()=>[{...command,agentId:'foreign-native-agent'}]})===rows,aborted:run({},()=>rows,AbortSignal.abort())===undefined};
  }
  if(!commandHost&&context.localJsx&&typeof context.localJsx.show==='function'){
   commandHost=context.localJsx;const originalShow=commandHost.show;
   const shape=(value,depth=0)=>{if(value===null)return null;if(typeof value==='function')return {type:'function',name:value.name};if(typeof value!=='object')return typeof value;if(depth>=2)return {type:Array.isArray(value)?'array':'object',keys:Object.keys(value).slice(0,40)};return Array.isArray(value)?value.slice(0,8).map(item=>shape(item,depth+1)):Object.fromEntries(Object.entries(value).slice(0,40).map(([key,item])=>[key,shape(item,depth+1)]));};
   commandHost.show=function(element,options){const props=element?.props;let entry;const write=()=>save(${JSON.stringify(join(workspace,'native-agent-command-dialogs.json'))},JSON.stringify(commandDialogs));if(commandDialogs.length<12){entry={...(typeof props?.title==='string'?{title:props.title}:{}),...(typeof props?.confirmLabel==='string'?{confirmLabel:props.confirmLabel}:{}),commandName:options?.commandName,component:typeof element?.type==='function'?element.type.name:typeof element?.type,props:shape(props),hostMethods:Object.getOwnPropertyNames(Object.getPrototypeOf(context.dialogStore)??{}),closed:false};commandDialogs.push(entry);write();}const handle=Reflect.apply(originalShow,this,arguments);if(entry){entry.nodeId=handle?.nodeId;const item=context.dialogStore?.getState?.().open?.find(item=>item.payload?.nodeId===handle.nodeId);entry.dialog=item?{id:item.id,kind:item.kind,payload:shape(item.payload)}:undefined;write();if(handle?.closed?.then)void handle.closed.then(reason=>{entry.closed=true;entry.closeReason=reason;write();});}return handle;};
  }
  const task=state.viewingAgentTaskId===undefined?undefined:context.taskRegistry.get(state.viewingAgentTaskId),draft=await binding.composer.read();
  save(${JSON.stringify(join(workspace,'native-task-view-observation.json'))},JSON.stringify({viewingAgentTaskId:state.viewingAgentTaskId,taskId:task?runtime.flt(task)?.id:undefined,retain:task?.retain,diskLoaded:task?.diskLoaded,draft:draft.text,model:binding.model(),commandNotices:[state.notifications?.current,...(state.notifications?.queue??[])].filter(item=>item?.key==='agent-view-command-notice').map(item=>({key:item.key,text:item.text,segments:item.segments})),gateCases:cases}));
 }catch(error){save(${JSON.stringify(join(workspace,'native-task-view-observation-error.json'))},JSON.stringify({error:String(error)}));}finally{reading=false}},100);timer.unref();}
`);
if(managedScenario)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeManagedFiles({directory:privatePolicy,receipt:join(workspace,'managed-file-reads.jsonl'),watchPolicy:scenario==='managed-transition'})+`
{const {writeFileSync:save}=await import('node:fs');const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js');let saved=false;const timer=setInterval(()=>{try{const binding=runtime.ey();if(saved||binding?.surface!=='terminal')return;const context=binding.toolContext(new AbortController());save(${JSON.stringify(join(workspace,'native-owner-binding-shape.json'))},JSON.stringify({binding:Object.keys(binding),toolContext:Object.keys(context),state:Object.keys(context.getAppState()),options:Object.keys(context.options??{}),journalMethods:Object.getOwnPropertyNames(Object.getPrototypeOf(context.session.requestJournal)),storageMethods:Object.getOwnPropertyNames(Object.getPrototypeOf(context.storageV5))},null,2));saved=true;clearInterval(timer);}catch{}},250);timer.unref();}
`);
if(extension==='parent-lifecycle')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeCommandInspector(join(workspace,'native-command-lifecycle.json')));
if(scenario==='ui-engine')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeDialogInspector(join(workspace,'native-dialog-shapes.json')));
const originalBunOptions='--preload='+userPreload;
const env={BUN_OPTIONS:originalBunOptions,HOME:workspace,CLAUDE_CONFIG_DIR:configDir,CLAUDE_CODE_SIMPLE:undefined,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
let uiTeardown;
let onboardingStep;
let owner,native,seedResult,terminal='',seenSequence=0,theme=false,security=false,navigated=false,trusted=false,lastInputAt=0;
const launchPath=['live-main','ui-engine','terminal-client'].includes(scenario)?join(workspace,'debug-native'):executable;
if(scenario==='ui-engine'){
 const earlier=join(workspace,'earlier-drop-plugin');await mkdir(join(earlier,'.claude-plugin'),{recursive:true});await mkdir(join(earlier,'hooks'));await writeFile(join(earlier,'.claude-plugin/plugin.json'),JSON.stringify({name:'earlier-drop-fixture',version:'0.0.1'}));await writeFile(join(earlier,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));await writeFile(join(earlier,'hooks/register.ts'),"export function register(on){on('prompt.submit',async($,e,next)=>e.text==='DropOwnerPromptFixture'?{drop:'Native owner hook refused'}:next(e));}");
 const quote=value=>"'"+value.replaceAll("'","'\"'\"'")+"'";await writeFile(launchPath,'#!/bin/sh\nexec '+quote(executable)+' --plugin-dir '+quote(earlier)+' \"$@\"\n',{mode:0o700});
}
if(scenario==='live-main'||scenario==='terminal-client'){
 const quote=value=>"'"+value.replaceAll("'","'\"'\"'")+"'";
 await writeFile(launchPath,'#!/bin/sh\nexec '+quote(executable)+' --debug-file '+quote(join(workspace,'native-debug.log'))+' "$@"\n',{mode:0o700});
}
let livePrefix;
const snapshots=[];
const gone=pid=>{try{execFileSync('/bin/ps',['-p',String(pid),'-o','pid='],{stdio:'pipe'});return false}catch(error){if(error.status===1)return true;throw error}};
async function waitFor(check,label,ms=20000){const deadline=Date.now()+ms;while(Date.now()<deadline){if(await check())return;await delay(50)}throw Error(label)}
await (async()=>{
try{
 owner=await store.openConversation('terminal-fixture',JSON.stringify({cwd:workspace,allowedTools:['Agent'],...(uiPluginDir?{pluginDir:[uiPluginDir]}:{})}),()=>query({cliPath:launchPath,cwd:workspace,env:{...env,ANTHROPIC_BASE_URL:seedModel.url},tools:[],keepStdinOpen:true,replayUserMessages:true,...(uiPluginDir?{pluginDir:[uiPluginDir]}:{})}),async turn=>{for await(const line of turn.handle.events){}seedResult=await turn.handle.result;owner.release(turn.handle)});
 await owner.handle.initialized;
 owner.start('Seed the private native terminal handoff.',async turn=>{for await(const line of turn.handle.events){}seedResult=await turn.handle.result;owner.release(turn.handle)});
 await waitFor(()=>!!seedResult&&!owner.busy,'Print seed did not become idle');
 const oldPid=owner.handle.pid,sessionId=owner.sessionId;
 assert.ok(oldPid&&sessionId);assert.equal(seedModel.calls.length,1);
 native=await store.openNativeTerminal('terminal-fixture',{cliPath:launchPath,env:{...env,ANTHROPIC_BASE_URL:agentModel.url}},prepareClaudeNativeTerminal);
 assert.ok(gone(oldPid),'Print child must exit before terminal is returned');
 assert.equal(native.state.sessionId,sessionId);
 const observe=()=>{
   for(const chunk of native.output)if(chunk.sequence>seenSequence){terminal+=chunk.text;seenSequence=chunk.sequence;}
   const state=native.state;
   if(snapshots.length===0||JSON.stringify(snapshots.at(-1))!==JSON.stringify(state))snapshots.push(state);
   if(Date.now()-lastInputAt<200)return;
   const screen=recognizeOnboardingPrompt(terminal,workspace);let input;
   if(screen==='theme'&&!theme){theme=true;input='\r'}
   else if(screen==='security-notes'&&theme&&!security){security=true;input='\r'}
   else if(screen==='workspace-trust'&&!navigated){navigated=true;input='\x1b[B'}
   else if(screen==='workspace-trust-selected'&&navigated&&!trusted){trusted=true;input='\r'}
   if(input!==undefined){lastInputAt=Date.now();if(scenario==='task-view')onboardingStep=setTimeout(()=>native.input(state.ownerId,input),150);else native.input(state.ownerId,input)}
 };
 const unsubscribe=native.subscribe(observe);const timer=setInterval(observe,100);observe();
 try{
   if(managedScenario){
    let snapshot;
    await waitFor(async()=>{try{snapshot=await native.uiTransport.request({subtype:'apack_owner_snapshot'});return snapshot?.metadata?.turns===1;}catch{return false;}},'Direct native owner snapshot unavailable');
    assert.equal(snapshot.policy.allowManagedHooksOnly,true);assert.equal(snapshot.statusCommand,managedRestriction?null:settings.statusLine.command);assert.equal(snapshot.subagentCommand,managedRestriction?null:settings.subagentStatusLine.command);assert.equal(snapshot.sessionId,sessionId);
    await writeFile(join(workspace,'native-owner-direct-snapshot.json'),JSON.stringify(snapshot,null,2));
    if(managedRestriction){
     await waitFor(()=>native.state.status==='live','Restricted native owner did not become live');
     const accepted=await native.submit('NativeSubagentParentFixture: run the disposable status worker.');
     await waitFor(()=>agentModel.calls.some(call=>call.child&&call.delivered)&&native.state.tasks.some(task=>task.status==='completed')&&!native.busy,'Restricted native task did not finish');
     const journal=[];await waitFor(async()=>{const batch=await native.readJournal();journal.push(...batch.entries);return journal.some(entry=>entry.row.uuid===accepted.uuid);},'Restricted native receipt did not persist');
     for(const kind of ['main','sub'])await assert.rejects(readFile(join(workspace,'forbidden-'+kind+'.executed')),error=>error.code==='ENOENT');
     assert.equal(native.state.mainStatus,undefined);assert.ok(native.state.tasks.every(task=>task.statusText===undefined));
     const nativePid=native.state.pid;await native.close();assert.ok(gone(nativePid));assert.ok(gone(oldPid));
     await writeFile(join(workspace,'native-managed-restriction.json'),JSON.stringify({scenario,snapshot,accepted,journal,snapshots},null,2));
     console.log(JSON.stringify({evidence:'apack-native-managed-restriction',targetSha256:hash(await readFile(executable)),nativeRestriction:scenario,nativeHelpersSuppressed:true,nativeReceiptsPreserved:true,nativeTaskCompleted:true,ownedShutdown:true,syntheticApiRequests:seedModel.calls.length+agentModel.calls.length,realModelRequests:0}));return;
    }
    if(scenario==='managed-snapshot'){
     const nativePid=native.state.pid;await native.close();assert.ok(gone(nativePid));assert.ok(gone(oldPid));
     console.log(JSON.stringify({evidence:'apack-native-owner-snapshot',targetSha256:hash(await readFile(executable)),nativeOwnerSnapshot:true,originalManagedCommands:true,originalMetadata:true,ownedShutdown:true,sessionId,oldPid,nativePid,syntheticApiRequests:seedModel.calls.length+agentModel.calls.length,realModelRequests:0,scope:'Direct native snapshot under managed-only policy; this probe does not establish mounted UI acceptance'}));return;
    }
   }
   await waitFor(()=>native.state.status==='live'&&native.state.mainStatus?.includes('AppOwnedMain '+sessionId),'Product owner did not receive native main status');
   if(scenario==='managed-transition'){
    await delay(5200);
    const identity={sessionId,pid:native.state.pid,ownerId:native.state.ownerId};
    await writeFile(join(privatePolicy,'managed-settings.json'),JSON.stringify({allowManagedHooksOnly:true,disableAllHooks:true,statusLine:settings.statusLine,subagentStatusLine:settings.subagentStatusLine}));
    try{await waitFor(async()=>{const current=await native.uiTransport.request({subtype:'apack_owner_snapshot'});await writeFile(join(workspace,'native-policy-transition-observed.json'),JSON.stringify({identity,current,state:native.state},null,2));return current.policy.disableAllHooks===true&&native.state.mainStatus===undefined;},'Native private policy-file change did not clear old status',7000);}catch(error){throw error;}
    await writeFile(join(privatePolicy,'managed-settings.json'),JSON.stringify({allowManagedHooksOnly:true,statusLine:settings.statusLine,subagentStatusLine:settings.subagentStatusLine}));
    await waitFor(()=>native.state.mainStatus?.includes('AppOwnedMain '+sessionId),'Native policy helper did not restore',7000);
    assert.equal(native.state.pid,identity.pid);assert.equal(native.state.ownerId,identity.ownerId);
    await native.close();assert.ok(gone(identity.pid));assert.ok(gone(oldPid));
    console.log(JSON.stringify({evidence:'apack-native-managed-transition',targetSha256:hash(await readFile(executable)),nativePolicyTransition:true,oldOutputCleared:true,statusRestored:true,ownedShutdown:true,syntheticApiRequests:seedModel.calls.length+agentModel.calls.length,realModelRequests:0}));return;
   }
   if(scenario==='terminal-client'){
    const ui=native.uiTransport,client='terminal-client-probe',surface='desktop';
    const attach=()=>ui.request({subtype:'ui_attach',surface,client_id:client,answers:[],viewport:{columns:100,rows:30}});
    await attach();let item,frame;
    const render=async()=>{const list=await ui.request({subtype:'apack_ui_terminal_placements',surface,client_id:client});item=list.placements.find(item=>item.component==='InfoNotice');if(!item)return;frame=await ui.request({subtype:'ui_render',surface,client_id:client,component:item.component,instance_id:item.id,props:{source_revision:item.revision},viewport:{columns:100,rows:30}});return frame;};
    const nodes=tree=>{const found=[];const visit=node=>{if(!node||typeof node!=='object')return;if(node.type)found.push(node);for(const child of node.children??[])visit(child);};visit(tree);return found;};
    try {await waitFor(async()=>{await render();return frame&&JSON.stringify(frame).includes('InfoNotice Client count=0 key=none');},'Original terminal Client did not project');} catch(error) {await writeFile(join(workspace,'native-terminal-client-initial.json'),JSON.stringify({item,frame},null,2));throw error;}
    const initial=frame,region=nodes(frame.tree).find(node=>node.type==='NativeClient');assert.ok(region);
    await ui.request({subtype:'apack_ui_client',surface,client_id:client,id:region.props.id,sequence:1,event:{kind:'key',key:'k'}});
    await waitFor(async()=>JSON.stringify(await render()).includes('key=k'),'Borrowed terminal key did not reach the original sandbox');
    const action=async(type,value)=>{await render();const node=nodes(frame.tree).find(node=>node.type===type);assert.ok(node);return ui.request({subtype:type==='Button'?'ui_press':type==='Input'?'ui_input':'ui_select',surface,client_id:client,component:item.component,instance_id:item.id,...node.press,key:node.props.key,...(type==='Input'?{kind:'change',value}:type==='Select'?{value}:{})});};
    assert.equal((await action('Button')).handled,true);
    await waitFor(async()=>JSON.stringify(await render()).includes('count=1 key=k'),'Original terminal Client press did not execute exactly once');
    assert.equal((await action('Input','rewrite')).handled,true);assert.equal((await action('Select','b')).handled,true);
    const events=async()=>JSON.parse(await readFile(join(workspace,'native-terminal-client-events.json'),'utf8'));
    await waitFor(async()=>{const last=(await events()).at(-1);return last?.count===1&&last.key==='k'&&last.note==='native-value'&&last.choice==='b';},'Original terminal fields did not preserve native rewrite/callback ownership');
    const beforeDetach=(await events()).at(-1);
    await ui.request({subtype:'ui_detach',surface,client_id:client});
    await waitFor(async()=> (await events()).at(-1)?.ticks>beforeDetach.ticks+1,'App detach disposed the terminal-owned clock');
    const afterDetach=(await events()).at(-1);assert.equal(afterDetach.count,1);assert.equal(afterDetach.key,'k');assert.equal(afterDetach.note,'native-value');assert.equal(afterDetach.surface,'terminal');
    await attach();await render();const remounted=nodes(frame.tree).find(node=>node.type==='NativeClient');assert.notEqual(remounted.props.id,region.props.id);
    assert.equal((await ui.request({subtype:'apack_ui_client',surface,client_id:client,id:region.props.id,sequence:2,event:{kind:'key',key:'old'}})).handled,false);
    assert.ok(JSON.stringify(frame).includes('count=1 key=k'));
    await writeFile(join(workspace,'native-terminal-client-proof.json'),JSON.stringify({initial,restored:frame,beforeDetach,afterDetach,fields:JSON.parse(await readFile(join(workspace,'native-terminal-client-fields.json'),'utf8'))},null,2));
    await ui.request({subtype:'ui_detach',surface,client_id:client});const nativePid=native.state.pid;await native.close();assert.ok(gone(nativePid));assert.ok(gone(oldPid));
    console.log(JSON.stringify({evidence:'apack-native-terminal-owner',nativeTerminalClient:true,nativeTerminalClientKeys:true,nativeTerminalClientFields:true,nativeTerminalClientHooks:true,nativeTerminalClientRemount:true,nativeOriginalClockOwnership:true,ownedShutdown:true,targetSha256:hash(await readFile(executable)),syntheticApiRequests:seedModel.calls.length+agentModel.calls.length,realModelRequests:0,scope:'Product source owner and original terminal sandbox; no mounted app acceptance'}));return;
   }
   if(scenario==='ui-engine'){
    assert.equal(await native.setPermissionMode('plan'),'plan');
    assert.equal(native.state.session.permissionMode,'plan');
    await assert.rejects(native.setPermissionMode('invalid-fixture-mode'),/mode/i);
    assert.equal(native.state.session.permissionMode,'plan');
    assert.equal(await native.setPermissionMode('acceptEdits'),'acceptEdits');
    await writeFile(join(workspace,'native-permission-mode-controls.json'),JSON.stringify({nativeAcknowledged:true,sequence:['plan','acceptEdits'],invalidModeRejected:true,realModelRequests:0}));
    const ui=native.uiTransport,client='apack-native-ui-research',events=[];
    const detachEvents=ui.subscribe(event=>events.push(event));
    let appDraft='App composer draft';const suggestions=[];
    const unregisterHost=ui.promptHosts.register(client,{read:async()=>({text:appDraft,cursor:appDraft.length}),fill:async input=>{assert.equal(input.mode,'replace');appDraft=input.text;return true;},suggest:async text=>{suggestions.push(text);return true;}});
    await ui.request({subtype:'ui_attach',surface:'desktop',client_id:client,answers:[],viewport:{columns:100,rows:30}});
    await waitFor(()=>events.some(event=>event.subtype==='ui_status'&&event.text==='Startup native status')&&events.some(event=>event.subtype==='ui_toast'&&event.text==='Startup native toast'),'Startup native notices did not replay');
    const startupEvents=events.filter(event=>['ui_status','ui_toast'].includes(event.subtype));assert.ok(startupEvents.every(event=>event.session_id===sessionId&&typeof event.uuid==='string'));
    const render=()=>ui.request({subtype:'ui_render',surface:'desktop',client_id:client,component:'AbovePrompt',instance_id:'above-prompt',props:{}});
    const nodes=(tree)=>{const result=[];const visit=value=>{if(!value||typeof value!=='object')return;if(value.type)result.push(value);for(const child of Object.values(value))visit(child);};visit(tree);return result;};
    const before=await render(),button=nodes(before.tree).find(node=>node.type==='Button'&&node.props.key==='owned-press');assert.ok(button);
    assert.equal((await ui.request({subtype:'ui_press',surface:'desktop',...button.press,key:button.props.key})).handled,true);
    await waitFor(()=>events.some(event=>event.subtype==='ui_invalidate'),'Native UI invalidation did not reach its owner');
    const after=await render();assert.ok(JSON.stringify(after).includes('ProductNativeUi 1'));
    const noticeButton=nodes(after.tree).find(node=>node.type==='Button'&&node.props.key==='owned-notices');assert.ok(noticeButton);
    await ui.request({subtype:'ui_press',surface:'desktop',...noticeButton.press,key:noticeButton.props.key});
    await waitFor(()=>events.some(event=>event.subtype==='ui_status'&&event.text==='Live native status')&&events.some(event=>event.subtype==='ui_toast'&&event.text==='Live native toast'&&event.timeout_ms===1500),'Live native notices missing');
    const clearButton=nodes(after.tree).find(node=>node.type==='Button'&&node.props.key==='clear-notices');assert.ok(clearButton);
    await ui.request({subtype:'ui_press',surface:'desktop',...clearButton.press,key:clearButton.props.key});
    await waitFor(()=>events.some(event=>event.subtype==='ui_status'&&event.text===null),'Native status clear missing');
    await writeFile(join(workspace,'native-ui-notices.json'),JSON.stringify(events.filter(event=>['ui_status','ui_toast'].includes(event.subtype))));

    assert.equal((await ui.request({subtype:'ui_press',surface:'desktop',...button.press,key:button.props.key})).handled,false);
    const input=nodes(after.tree).find(node=>node.type==='Input'),select=nodes(after.tree).find(node=>node.type==='Select');assert.ok(input&&select);
    assert.equal((await ui.request({subtype:'ui_input',surface:'desktop',component:'AbovePrompt',instance_id:'above-prompt',...input.press,key:input.props.key,kind:'change',value:'Real native field callback'})).handled,true);
    assert.equal(JSON.parse(await readFile(join(workspace,'native-ui-field.json'),'utf8')).value,'Real native field callback');
    assert.equal((await ui.request({subtype:'ui_select',surface:'desktop',component:'AbovePrompt',instance_id:'above-prompt',...select.press,key:select.props.key,value:'detailed'})).handled,true);
    assert.equal(JSON.parse(await readFile(join(workspace,'native-ui-choice.json'),'utf8')).value,'detailed');
    const promptButton=nodes(after.tree).find(node=>node.type==='Button'&&node.props.key==='owned-prompt');assert.ok(promptButton);
    assert.equal((await ui.request({subtype:'ui_press',surface:'desktop',...promptButton.press,key:promptButton.props.key})).handled,true);
    const nativeHost=JSON.parse(await readFile(join(workspace,'native-ui-prompt-host.json'),'utf8'));
    assert.equal(nativeHost.before.text,'App composer draft');assert.equal(nativeHost.filled.isFilled,true);assert.equal(nativeHost.after.text,'Native host replacement');assert.equal(nativeHost.suggested.isShown,true);assert.deepEqual(suggestions,['Native host suggestion']);
    assert.equal(appDraft,'Native host replacement');
    const completion=await ui.request({subtype:'ui_prompt_autocomplete',surface:'desktop',client_id:client,text:'hello nat',cursor:9});assert.ok(completion.suggestions.some(row=>row.text==='native-token'));assert.equal(completion.start,6);
    const emptyCompletion=await ui.request({subtype:'ui_prompt_autocomplete',surface:'desktop',client_id:client,text:'',cursor:0});assert.deepEqual(emptyCompletion,{suggestions:[]});
    await writeFile(join(workspace,'native-ui-autocomplete.json'),JSON.stringify({completion,emptyCompletion,request:JSON.parse(await readFile(join(workspace,'native-ui-autocomplete-request.json'),'utf8'))}));
    const edited=await ui.request({subtype:'ui_prompt_edit',surface:'desktop',client_id:client,text:'native edit',cursor:11,key:{key:'t'}});assert.equal(edited.text,'NATIVE EDIT');assert.equal(edited.cursor,11);assert.ok(edited.decorations.some(run=>run.bold));
    const adopted=await ui.request({subtype:'ui_prompt_edit',surface:'desktop',client_id:client,text:'restored',cursor:8,by:'app'});assert.deepEqual(adopted,{text:'restored',cursor:8});
    const afterAdopt=await ui.request({subtype:'ui_prompt_edit',surface:'desktop',client_id:client,text:'restored!',cursor:9,key:{key:'!'}});assert.equal(afterAdopt.text,'RESTORED!');
    const editEvents=JSON.parse(await readFile(join(workspace,'native-ui-edit-events.json'),'utf8'));assert.equal(editEvents.length,2);assert.equal(editEvents[0].key.key,'t');assert.equal(editEvents[1].text,'restored');assert.equal(editEvents[1].inputText,'!');
    await writeFile(join(workspace,'native-ui-edit.json'),JSON.stringify({edited,adopted,afterAdopt,editEvents}));
    const paneButton=nodes(after.tree).find(node=>node.type==='Button'&&node.props.key==='owned-panes');assert.ok(paneButton);
    assert.equal((await ui.request({subtype:'ui_press',surface:'desktop',...paneButton.press,key:paneButton.props.key})).handled,true);
    const paneRequest=(subtype,extra={})=>ui.request({subtype,client_id:client,...extra});
    const roster=await paneRequest('ui_panes');assert.equal(roster.panes.length,2);assert.ok(roster.panes.some(pane=>pane.id==='review-a'&&pane.close_on_escape&&pane.hold_toasts&&pane.rows===6&&pane.columns===40));
    await waitFor(()=>events.some(event=>event.subtype==='ui_panes'&&event.panes?.length===2),'Native pane roster push missing');
    assert.equal((await paneRequest('ui_pane_focus',{surface:'desktop',id:'review-a'})).focused_id,'review-a');
    assert.equal((await paneRequest('ui_pane_show',{surface:'desktop',id:'review-b'})).shown_id,'review-b');
    const paneDrawing=await ui.request({subtype:'ui_render',surface:'desktop',client_id:client,component:'Pane',instance_id:'review-b',props:{title:'Native review B',isFocused:true,bodyColumns:60,placement:'inline',scroll:{offset:0,bodyRows:8},view:{}}});
    const plugin='native-ui-owner-fixture',site={surface:'desktop',client_id:client,component:'Pane',instance_id:'review-b'};
    assert.equal((await ui.request({subtype:'ui_focus',...site,is_held:true,element:{plugin,key:'focus-target'},by:'person'})).element.key,'focus-target');
    assert.equal((await ui.request({subtype:'ui_focus',...site,is_held:true,element:{plugin,key:'focus-denied'},by:'person'})).moved,false);
    const layout={...site,offset:0,by:0,body_rows:8,content_rows:40,keyed:[{plugin,key:'target-row',top:20,bottom:22}]};
    assert.equal((await ui.request({subtype:'ui_scroll',...layout})).offset,0);
    assert.equal((await ui.request({subtype:'ui_scroll',...layout,by:2})).offset,3);
    const deniedScroll=await ui.request({subtype:'ui_scroll',...layout,offset:6,by:3});assert.equal(deniedScroll.moved,false);assert.equal(deniedScroll.offset,3);
    const movement=nodes(paneDrawing.tree).find(node=>node.type==='Button'&&node.props.key==='move-plugin');assert.ok(movement);
    assert.equal((await ui.request({subtype:'ui_press',surface:'desktop',...movement.press,key:movement.props.key})).handled,true);
    const pluginMovement=JSON.parse(await readFile(join(workspace,'native-ui-plugin-movement.json'),'utf8'));assert.deepEqual(pluginMovement,{focused:{},scrolled:{}});
    await waitFor(()=>events.some(event=>event.subtype==='ui_scroll'&&event.offset===20),'Plugin scroll did not reach app');
    assert.ok(events.some(event=>event.subtype==='ui_focus'&&event.key==='focus-target'));
    const follow=nodes(paneDrawing.tree).find(node=>node.type==='Button'&&node.props.key==='follow-end');assert.ok(follow);
    assert.equal((await ui.request({subtype:'ui_press',surface:'desktop',...follow.press,key:follow.props.key})).handled,true);
    assert.deepEqual(JSON.parse(await readFile(join(workspace,'native-ui-follow-end.json'),'utf8')),{});
    const grown=await ui.request({subtype:'ui_scroll',...layout,offset:42,content_rows:50});assert.equal(grown.offset,42);assert.equal(grown.follow_end,true);
    const away=await ui.request({subtype:'ui_scroll',...layout,offset:41,by:-1,content_rows:50});assert.equal(away.offset,41);assert.notEqual(away.follow_end,true);
    const foreign=await ui.request({subtype:'ui_focus',...site,instance_id:'foreign-pane',is_held:true,element:null,by:'person'});assert.equal(foreign.moved,false);

    await writeFile(join(workspace,'native-ui-site-contracts.json'),JSON.stringify({pluginMovement,deniedScroll,grown,away,foreign,events:events.filter(event=>['ui_scroll','ui_focus'].includes(event.subtype))}));

    assert.equal((await paneRequest('ui_pane_focus',{surface:'desktop',id:null})).focused_id,null);
    assert.equal((await paneRequest('ui_close',{id:'review-a'})).closed,false);
    assert.equal((await paneRequest('ui_close',{id:'review-a'})).closed,true);
    const closeEvent=JSON.parse(await readFile(join(workspace,'native-ui-pane-close.json'),'utf8'));assert.equal(closeEvent.origin.kind,'person');
    assert.equal((await paneRequest('ui_close',{id:'review-b'})).closed,true);
    assert.equal((await paneRequest('ui_panes')).panes.length,0);
    await writeFile(join(workspace,'native-ui-panes.json'),JSON.stringify({roster,closeEvent,events:events.filter(event=>event.subtype==='ui_panes')}));

    uiTeardown=async()=>{assert.equal(appDraft,'Native host replacement','Human submission must not replace the app-owned draft through prompt.fill');const current=await render(),button=nodes(current.tree).find(node=>node.type==='Button'&&node.props.key==='owned-prompt');assert.equal((await ui.request({subtype:'ui_press',surface:'desktop',...button.press,key:button.props.key})).handled,true);const focusAfterTurn=await ui.request({subtype:'ui_focus',surface:'desktop',client_id:client,component:'AbovePrompt',instance_id:'above-prompt',is_held:true,element:{plugin:'native-ui-owner-fixture',key:'owned-input'},by:'person'});assert.equal(focusAfterTurn.moved,true);assert.equal(focusAfterTurn.element.key,'owned-input');await writeFile(join(workspace,'native-ui-focus-after-turn.json'),JSON.stringify(focusAfterTurn));const afterTurn=JSON.parse(await readFile(join(workspace,'native-ui-prompt-host.json'),'utf8'));assert.equal(afterTurn.before.text,'Native host replacement');assert.equal(afterTurn.after.text,'Native host replacement');await writeFile(join(workspace,'native-ui-host-after-turn.json'),JSON.stringify(afterTurn));const fillEvents=JSON.parse(await readFile(join(workspace,'native-ui-fill-events.json'),'utf8'));assert.ok(fillEvents.some(event=>event.text==='NativeSubagentParentFixture: run the disposable status worker.'&&event.origin.kind==='plugin'&&event.origin.name==='apack-native-terminal'),'Native human preparation must run the native fill hooks');assert.equal((await ui.request({subtype:'ui_detach',client_id:client})).detached,true);unregisterHost();await assert.rejects(render(),/not attached/);detachEvents();const uiOwner=getClaudeUiOwner('terminal-fixture');assert.ok(uiOwner);assert.equal(getClaudeUiOwner('terminal-fixture'),uiOwner);const mountedStates=[];const mounted=mountClaudeUi({owner:uiOwner,isCurrent:()=>getClaudeUiOwner('terminal-fixture')===uiOwner,publish:state=>mountedStates.push(state)});await mounted.ready;await waitFor(()=>mountedStates.some(state=>state.status==='live'),'Existing UI mount did not render under terminal owner');await writeFile(join(workspace,'native-ui-existing-mount.json'),JSON.stringify(mountedStates));await mounted.dispose();};
    const noticeCount=events.filter(event=>event.subtype==='ui_toast').length,priorEvents=events.length;
    await ui.request({subtype:'ui_attach',surface:'desktop',client_id:'apack-native-notice-second',answers:[]});
    await waitFor(()=>events.slice(priorEvents).some(event=>event.subtype==='ui_status'&&event.text===null),'Second attachment must replay current status');
    assert.equal(events.filter(event=>event.subtype==='ui_toast').length,noticeCount,'Second attachment must not repeat transient notices');
    await ui.request({subtype:'ui_detach',client_id:'apack-native-notice-second'});
    await writeFile(join(workspace,'native-ui-notices.json'),JSON.stringify(events.filter(event=>['ui_status','ui_toast'].includes(event.subtype))));
    await writeFile(join(workspace,'native-ui-transport.json'),JSON.stringify({before,after,events,nativePid:native.state.nativePid,nativeDesktopUi:true,nativeFields:true,nativePromptHosts:true,nativeHost,staleNativeActionRefused:true},null,2));
   }
   if(scenario==='live-main'){
   // Native suppresses a settings-file echo for 5000ms after its own onboarding write.
   // Wait from the observed native write, not from process startup or an arbitrary retry count.
   const debugPath=join(workspace,'native-debug.log'),settingsPath=join(configDir,'settings.json');
   const ownWriteMarker='File '+settingsPath+' written atomically';
   const ownWrites=(await readFile(debugPath,'utf8')).split('\n').filter(line=>line.includes(ownWriteMarker));
   assert.ok(ownWrites.length>0,'Expected the private onboarding settings write in native debug evidence');
   const ownWriteAt=Date.parse(ownWrites.at(-1).slice(0,24));assert.ok(Number.isFinite(ownWriteAt));
   const until=ownWriteAt+5200;while(Date.now()<until)await delay(Math.min(100,until-Date.now()));
   const livePid=native.state.pid;
   const liveHelper=join(workspace,'main-live.py');
   await writeFile(liveHelper,"import json,sys\np=json.load(sys.stdin)\nprint('AppOwnedMainLive '+p['session_id'])\n");
   const changedMain={...settings.statusLine,command:`/usr/bin/python3 '${liveHelper}'`};
   await writeFile(join(configDir,'settings.json'),JSON.stringify({...settings,statusLine:changedMain}));
   await waitFor(()=>native.state.mainStatus?.includes('AppOwnedMainLive '+sessionId),'Native main command did not update live');
   await writeFile(join(configDir,'settings.json'),JSON.stringify({...settings,statusLine:undefined}));
   await waitFor(()=>native.state.mainStatus===undefined,'Removed native main status was not cleared');
   await writeFile(join(configDir,'settings.json'),JSON.stringify(settings));
   await waitFor(()=>native.state.mainStatus?.includes('AppOwnedMain '+sessionId),'Native main command did not restore live');
   const livePrefixPath=join(workspace,"user's changed prefix");livePrefix=livePrefixPath+' --live-prefix';
   await writeFile(livePrefixPath,(await readFile(prefixPath,'utf8')).replace("sys.exit(subprocess.run","os.environ['APACK_PREFIX_FIXTURE']='live'\nsys.exit(subprocess.run"),{mode:0o700});
   await writeFile(join(configDir,'settings.json'),JSON.stringify({...settings,env:{CLAUDE_CODE_SHELL_PREFIX:livePrefix}}));
   await waitFor(()=>native.state.mainStatus?.includes('prefix=live'),'Native-applied prefix replacement was not exported');
   assert.equal(native.state.pid,livePid,'Live settings must not restart the native owner');
   }
   if(scenario==='ui-engine'){await assert.rejects(native.submit('DropOwnerPromptFixture'),/Native owner hook refused/);await writeFile(join(workspace,'native-ui-earlier-drop.json'),JSON.stringify({earlierHookRejection:true,retryFollows:true}));}
   const receipt=await native.submit('NativeSubagentParentFixture: run the disposable status worker.');
   assert.equal(receipt.sessionId,sessionId);assert.equal(receipt.text,'NativeSubagentParentFixture: run the disposable status worker.');assert.match(receipt.uuid,/^[a-f0-9-]{36}$/i);
   await waitFor(()=>snapshots.some(state=>state.tasks.some(task=>task.statusText?.startsWith('AppOwnedAgent running'))),'Product owner did not receive attributed native subagent status');
   if(scenario==='task-view'){
     const taskId=native.state.tasks.find(task=>task.status==='running').id,nativePid=native.state.pid;
     const client='native-view-detachment-proof';
     await native.uiTransport.request({subtype:'ui_attach',surface:'desktop',client_id:client,answers:[],viewport:{columns:100,rows:30}});
     try{await assert.rejects(native.operateTask(taskId,'foreground'),/Detach desktop prompt handlers/);}finally{await native.uiTransport.request({subtype:'ui_detach',surface:'desktop',client_id:client});}
     const initialViewRevision=native.state.view?.revision??0;
     const focused=await native.operateTask(taskId,'foreground');assert.equal(focused.view.taskId,taskId);
     await waitFor(()=>native.state.view?.kind==='agent'&&native.state.view.taskId===taskId&&native.state.view.revision>initialViewRevision,'Authoritative native selection was not published');
     const selectedView={...native.state.view};
     const agentUiClient='native-agent-ui-scope';
     await assert.rejects(native.uiTransport.request({subtype:'ui_attach',surface:'desktop',client_id:agentUiClient,answers:[]}),/Desktop parent UI/);
     const agentAttachment={subtype:'ui_attach',surface:'desktop',client_id:agentUiClient,answers:[],native_view:{session_id:sessionId,revision:selectedView.revision,agent_id:taskId}};
     await assert.rejects(native.uiTransport.request({...agentAttachment,native_view:{...agentAttachment.native_view,revision:selectedView.revision-1}}),/selection changed/);
     await native.uiTransport.request(agentAttachment);
     const agentSite=await native.uiTransport.request({subtype:'ui_render',surface:'desktop',client_id:agentUiClient,component:'AbovePrompt',instance_id:'above-prompt',props:{view:{agentId:'foreign-agent'}}});
     assert.deepEqual(agentSite.props.view,{agentId:taskId});
     const beforeReview=await native.operateTask(taskId,'inspect');
     const review=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'NativeAgentSteerFixture:\u200b review before sending'});
     assert.deepEqual(review,{kind:'review',text:'NativeAgentSteerFixture: review before sending',removed:1});
     const afterReview=await native.operateTask(taskId,'inspect');assert.deepEqual(afterReview.details.messages,beforeReview.details.messages,'Admission review must not append an Agent message');

     await assert.rejects(native.submit('ParentMustNotReachAgentFixture'),/Return to the native main view/);
     const text='NativeAgentSteerFixture: reply inside the selected native view.';
     const observation=async()=>{try{return JSON.parse(await readFile(join(workspace,'native-task-view-observation.json'),'utf8'))}catch{return undefined}};
     await waitFor(async()=>(await observation())?.taskId===taskId,'Original native view selection was not observed');
     const focusedObservation=await observation();assert.equal(focusedObservation.retain,true);
     const queued={nativePtyInput:native.input(native.state.ownerId,'\x1b[200~'+text+'\x1b[201~')};assert.equal(queued.nativePtyInput,true);
     await waitFor(async()=>(await observation())?.draft===text,'Original foreground composer did not accept the pasted draft');
     assert.equal(native.input(native.state.ownerId,'\r'),true);
     await waitFor(()=>agentModel.calls.some(call=>call.child&&call.steeringObserved&&call.delivered)&&native.state.tasks.some(task=>task.id===taskId&&task.status==='completed'),'Selected worker did not receive human input');
     const resumed=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'NativeAgentSteerFixture: resume with the original live queue guard.   \n'});assert.equal(resumed.kind,'input');assert.equal(resumed.previousStatus,'completed');
     await waitFor(()=>agentModel.calls.filter(call=>call.child&&call.steeringObserved&&call.delivered).length===2&&native.state.tasks.some(task=>task.id===taskId&&task.status==='completed'),'Selected worker did not complete guarded resume');
     const commandDraft='Native desktop command draft',host=native.uiTransport.promptHosts.register(agentUiClient,{read:async()=>({text:commandDraft,cursor:commandDraft.length}),fill:async()=>true,suggest:async()=>true});
     await native.uiTransport.request({...agentAttachment,answers:['ui_prompt_read','ui_prompt_fill','ui_prompt_suggest']});
     const commandBaseline=await native.operateTask(taskId,'inspect'),modelBeforeCommand=(await observation()).model;
     assert.equal(native.input(native.state.ownerId,'\x15\x1b[200~/model haiku\x1b[201~'),true);
     await waitFor(async()=>(await observation())?.draft==='/model haiku','Original native command draft was not accepted');
     assert.equal(native.input(native.state.ownerId,'\r'),true);
     await waitFor(async()=>JSON.stringify((await observation())?.commandNotices).includes('changes the main conversation'), 'Original selected-Agent model command gate was not observed');
     const blockedNotice=(await observation()).commandNotices;
     assert.equal((await observation()).model,modelBeforeCommand);
     assert.deepEqual((await native.operateTask(taskId,'inspect')).details.messages,commandBaseline.details.messages,'Blocked model command reached the Agent transcript');
     await writeFile(join(workspace,'native-agent-command-gates.json'),JSON.stringify({originalDispatcher:true,desktopPromptHostAttached:true,blockedCommand:'/model haiku',notice:(await observation()).commandNotices,modelUnchanged:true,transcriptUnchanged:true},null,2));
     assert.equal(native.input(native.state.ownerId,'\x15\x1b[200~/compact\x1b[201~'),true);
     await waitFor(async()=>(await observation())?.draft==='/compact','Original native compact draft was not accepted');
     assert.equal(native.input(native.state.ownerId,'\r'),true);
     const readCommandDialogs=async()=>{try{return JSON.parse(await readFile(join(workspace,'native-agent-command-dialogs.json'),'utf8'))}catch{return []}};
     await waitFor(async()=>(await readCommandDialogs()).some(dialog=>dialog.commandName==='compact'&&dialog.title.includes('acts on the main conversation')),'Original selected-Agent compact confirmation was not observed');
     const commandDialogs=await readCommandDialogs();
     assert.deepEqual((await native.operateTask(taskId,'inspect')).details.messages,commandBaseline.details.messages,'Unconfirmed compact reached the Agent transcript');
     assert.equal(native.input(native.state.ownerId,'\x1b'),true);
     await waitFor(async()=>(await readCommandDialogs()).at(-1)?.closed===true,'Original command cancellation did not close its native dialog');
     assert.equal((await observation()).taskId,taskId);assert.equal((await observation()).draft.trim(),'/compact');
     await writeFile(join(workspace,'native-agent-command-gates.json'),JSON.stringify({originalDispatcher:true,desktopPromptHostAttached:true,blockedCommand:'/model haiku',notice:blockedNotice,modelUnchanged:(await observation()).model===modelBeforeCommand,transcriptUnchanged:true,confirmation:commandDialogs.at(-1),canceledByNativeEscape:true,retainedAgentAndDraft:true},null,2));
     assert.equal(native.input(native.state.ownerId,'\x15'),true);
     await waitFor(async()=>(await observation())?.draft==='', 'Native command draft did not clear after cancellation');
     const dispatchedBlock=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'/model haiku'});
     assert.equal(dispatchedBlock.kind,'blocked');assert.ok(dispatchedBlock.message.includes('main conversation'));
     const dispatchedConfirmation=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'/compact'});
     assert.equal(dispatchedConfirmation.kind,'confirmation');assert.equal(dispatchedConfirmation.commandName,'compact');
     await assert.rejects(native.uiTransport.request({subtype:'apack_ui_agent_command',client_id:'foreign-client',command_id:dispatchedConfirmation.id,decision:'cancel'}),/expired/);
     assert.deepEqual(await native.uiTransport.request({subtype:'apack_ui_agent_command',client_id:agentUiClient,command_id:dispatchedConfirmation.id,decision:'cancel'}),{answered:true});
     await assert.rejects(native.uiTransport.request({subtype:'apack_ui_agent_command',client_id:agentUiClient,command_id:dispatchedConfirmation.id,decision:'cancel'}),/expired/);
     const outputBaseline=await native.operateTask(taskId,'inspect');
     const dispatchedOutput=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'/reload-skills'});
     await writeFile(join(workspace,'native-agent-command-output.json'),JSON.stringify(dispatchedOutput,null,2));
     assert.equal(dispatchedOutput.kind,'command_output');assert.equal(dispatchedOutput.commandName,'reload-skills');assert.match(dispatchedOutput.messageId,/^[a-f0-9-]{36}$/);assert.ok(dispatchedOutput.text.length>0);
     assert.deepEqual((await native.operateTask(taskId,'inspect')).details.messages,outputBaseline.details.messages,'Parent command output must not become worker input');
     const panelPid=native.state.pid,panelView={...native.state.view},panelBaseline=await native.operateTask(taskId,'inspect');
     assert.equal(native.input(native.state.ownerId,'\x1b[200~/cost\x1b[201~'),true);
     await waitFor(async()=>(await observation())?.draft==='/cost','Native usage alias draft was not observed');
     assert.equal(native.input(native.state.ownerId,'\r'),true);
     await waitFor(async()=>(await readCommandDialogs()).some(dialog=>dialog.commandName==='usage'&&!dialog.closed),'Original usage panel was not observed');
     const openedPanel=(await readCommandDialogs()).findLast(dialog=>dialog.commandName==='usage');
     assert.ok(openedPanel.nodeId);assert.ok(openedPanel.props);assert.deepEqual((await native.operateTask(taskId,'inspect')).details.messages,panelBaseline.details.messages);
     assert.equal(native.input(native.state.ownerId,'\x1b'),true);
     await waitFor(async()=>(await readCommandDialogs()).find(dialog=>dialog.nodeId===openedPanel.nodeId)?.closed===true,'Native Escape did not close the original usage panel');
     const closedPanel=(await readCommandDialogs()).find(dialog=>dialog.nodeId===openedPanel.nodeId);
     assert.equal(native.state.pid,panelPid);assert.deepEqual(native.state.view,panelView);assert.deepEqual((await native.operateTask(taskId,'inspect')).details.messages,panelBaseline.details.messages);
     await writeFile(join(workspace,'native-agent-usage-panel.json'),JSON.stringify({alias:'/cost',openedPanel,closedPanel,sameNativePid:true,sameSelectedView:true,workerTranscriptUnchanged:true},null,2));
     const scopedPanel=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'/cost'});
     assert.equal(scopedPanel.kind,'panel');assert.equal(scopedPanel.commandName,'usage');
     const panelRequest={subtype:'apack_ui_agent_panel',client_id:agentUiClient,panel_id:scopedPanel.id};
     assert.deepEqual(await native.uiTransport.request({...panelRequest,operation:'read'}),{open:true});
     await assert.rejects(native.uiTransport.request({...panelRequest,client_id:'foreign-client',operation:'close'}),/expired/);
     await native.uiTransport.request({...panelRequest,operation:'input',text:'\x1b'});
     await waitFor(async()=>(await native.uiTransport.request({...panelRequest,operation:'read'})).open===false,'Scoped original terminal Escape did not close the panel');
     await assert.rejects(native.uiTransport.request({...panelRequest,operation:'input',text:'MustNotReachWorker'}),/expired/);
     const callbackPanel=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'/usage'});
     assert.equal(callbackPanel.kind,'panel');
     assert.deepEqual(await native.uiTransport.request({...panelRequest,panel_id:callbackPanel.id,operation:'close'}),{open:false});
     await assert.rejects(native.uiTransport.request({...panelRequest,panel_id:callbackPanel.id,operation:'close'}),/expired/);
     assert.equal(native.state.pid,panelPid);assert.deepEqual(native.state.view,panelView);assert.deepEqual((await native.operateTask(taskId,'inspect')).details.messages,panelBaseline.details.messages);
     await writeFile(join(workspace,'native-agent-scoped-panel.json'),JSON.stringify({scopedPanel,callbackPanel,nativeInputEscape:true,originalStoreDismissal:true,foreignClientRefused:true,closedInputRefused:true,closeReplayRefused:true,sameNativePid:true,sameSelectedView:true,workerTranscriptUnchanged:true},null,2));
     const genericPanels=[];
     const contextOutput=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'/context'});
     assert.equal(contextOutput.kind,'command_output');assert.equal(contextOutput.commandName,'context');assert.match(contextOutput.text,/context usage/i);
     await writeFile(join(workspace,'native-agent-context-output.json'),JSON.stringify(contextOutput,null,2));
     for(const text of ['/help']){
       const panel=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text});
       assert.equal(panel.kind,'panel');
       assert.deepEqual(await native.uiTransport.request({...panelRequest,panel_id:panel.id,operation:'read'}),{open:true});
       assert.deepEqual(await native.uiTransport.request({...panelRequest,panel_id:panel.id,operation:'close'}),{open:false});
       const observed=(await readCommandDialogs()).findLast(item=>item.commandName===panel.commandName);
       assert.ok(observed?.closed);assert.equal(observed.closeReason,'dismissed');
       genericPanels.push({text,panel,observed});
       assert.equal(native.state.pid,panelPid);assert.deepEqual(native.state.view,panelView);assert.deepEqual((await native.operateTask(taskId,'inspect')).details.messages,panelBaseline.details.messages);
     }
     const agentsOutput=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'/agents'});
     assert.equal(agentsOutput.kind,'command_output');assert.equal(agentsOutput.commandName,'agents');assert.match(agentsOutput.text,/agent/i);
     await writeFile(join(workspace,'native-agent-agents-output.json'),JSON.stringify(agentsOutput,null,2));
     await writeFile(join(workspace,'native-agent-generic-panels.json'),JSON.stringify({genericPanels,originalStoreDismissal:true,sameNativePid:true,sameSelectedView:true,workerTranscriptUnchanged:true},null,2));
     const dispatchedInput=await native.uiTransport.request({subtype:'apack_ui_agent_dispatch',client_id:agentUiClient,text:'NativeAgentSteerFixture: dispatch through the original native composer.'});
     assert.equal(dispatchedInput.kind,'input');assert.match(dispatchedInput.messageId,/^[a-f0-9-]{36}$/);
     await waitFor(()=>agentModel.calls.filter(call=>call.child&&call.steeringObserved&&call.delivered).length===3&&native.state.tasks.some(task=>task.id===taskId&&task.status==='completed'),'Original native dispatcher worker receipt did not complete');
     const dispatchedDetails=await native.operateTask(taskId,'inspect');assert.ok(dispatchedDetails.details.messages.some(row=>row.uuid===dispatchedInput.messageId&&row.text==='NativeAgentSteerFixture: dispatch through the original native composer.'));
     await writeFile(join(workspace,'native-agent-dispatch-controller.json'),JSON.stringify({dispatchedBlock,dispatchedConfirmation,dispatchedInput,originalUuidMatched:true,originalWorkerObserved:true,foreignClientRefused:true,replayRefused:true},null,2));
     await native.uiTransport.request({...agentAttachment,answers:[]});host();
     assert.equal(native.input(native.state.ownerId,'\x1b'),true);
     await waitFor(()=>native.state.view?.kind==='main'&&native.state.view.revision>selectedView.revision,'Original keyboard return was not observed');
     const submittedDetails=await native.operateTask(taskId,'inspect');assert.ok(submittedDetails.details.messages.some(row=>row.role==='user'&&row.text==='NativeAgentSteerFixture: resume with the original live queue guard.'));
     const keyboardReturnView={...native.state.view};
     await assert.rejects(native.uiTransport.request({subtype:'ui_render',surface:'desktop',client_id:agentUiClient,component:'AbovePrompt',instance_id:'above-prompt',props:{}}),/different selected view/);
     await assert.rejects(native.uiTransport.request(agentAttachment),/selection changed/);
     await native.uiTransport.request({subtype:'ui_detach',client_id:agentUiClient});
     await native.uiTransport.request({subtype:'ui_attach',surface:'desktop',client_id:agentUiClient,answers:[]});
     const mainSite=await native.uiTransport.request({subtype:'ui_render',surface:'desktop',client_id:agentUiClient,component:'AbovePrompt',instance_id:'above-prompt',props:{view:{agentId:taskId}}});
     assert.deepEqual(mainSite.props.view,{});
     await native.uiTransport.request({subtype:'ui_detach',client_id:agentUiClient});
     const background=await native.operateTask(taskId,'background');assert.equal(background.view.taskId,null);
     await waitFor(()=>!native.busy,'Parent notification did not drain before returning to its composer');
     const parentClient='native-parent-command-scope';
     await native.uiTransport.request({subtype:'ui_attach',surface:'desktop',client_id:parentClient,answers:[]});
     const parentCommand=async(client_id,text)=>{
       const prepared=await native.uiTransport.request({subtype:'apack_ui_parent_command',client_id,text,operation:'prepare'});
       if(prepared.kind!=='prepared')return prepared;
       const ticket={subtype:'apack_ui_parent_command',client_id,command_id:prepared.id};
       let startError;try{await native.uiTransport.request({...ticket,operation:'start'})}catch(error){startError=error}
       let outcome,lastError;
       await waitFor(async()=>{try{outcome=await native.uiTransport.request({...ticket,operation:'read'});lastError=undefined;return outcome.kind!=='running'}catch(error){lastError=error;return false}},'Native parent command ticket did not settle');
       if(lastError)throw lastError;
       if(outcome.kind!=='finished')throw Error(outcome.message??startError?.message??'Native parent command did not start');
       return outcome.result;
     };
     const ordinaryParent=await parentCommand(parentClient,'Ordinary parent prompt classification');assert.deepEqual(ordinaryParent,{kind:'not_command'});
     const parentContext=await parentCommand(parentClient,'/context');assert.equal(parentContext.kind,'command_output');assert.equal(parentContext.commandName,'context');assert.match(parentContext.text,/Context Usage/);
     const parentHelp=await parentCommand(parentClient,'/help');assert.equal(parentHelp.kind,'panel');assert.equal(parentHelp.commandName,'help');
     assert.deepEqual(await native.uiTransport.request({subtype:'apack_ui_agent_panel',client_id:parentClient,panel_id:parentHelp.id,operation:'close'}),{open:false});
     const parentUsage=await parentCommand(parentClient,'/cost');assert.equal(parentUsage.kind,'panel');assert.equal(parentUsage.commandName,'usage');
     await native.uiTransport.request({subtype:'apack_ui_agent_panel',client_id:parentClient,panel_id:parentUsage.id,operation:'input',text:'\x1b'});
     await waitFor(async()=>(await native.uiTransport.request({subtype:'apack_ui_agent_panel',client_id:parentClient,panel_id:parentUsage.id,operation:'read'})).open===false,'Parent native Escape did not close Usage');
     assert.equal(native.state.pid,nativePid);assert.equal(native.state.view.kind,'main');assert.equal(native.state.sessionId,sessionId);
     await writeFile(join(workspace,'native-parent-command-controller.json'),JSON.stringify({ordinaryParent,parentContext,parentHelp,parentUsage,originalStoreDismissal:true,nativeEscape:true,sameNativePid:true,sameSession:true,mainViewRetained:true},null,2));
     await native.uiTransport.request({subtype:'ui_detach',surface:'desktop',client_id:parentClient});
     const parentReceipt=await native.submit('AfterNativeViewParentFixture');assert.equal(parentReceipt.sessionId,sessionId);
     assert.ok(!agentModel.requests.some(request=>JSON.stringify(request.messages).includes('ParentMustNotReachAgentFixture')));
     await waitFor(()=>!native.busy,'Parent did not finish after native view return');
     assert.equal(native.state.pid,nativePid);
     const nativeObservation=await observation();assert.ok(Object.values(nativeObservation.gateCases).every(value=>value===true));
     const promptSubmitEvents=JSON.parse(await readFile(join(workspace,'native-prompt-submit-events.json'),'utf8'));
     for(const text of ['NativeSubagentParentFixture: run the disposable status worker.','AfterNativeViewParentFixture'])assert.ok(promptSubmitEvents.some(event=>event.text===text),'Parent prompt.submit control was not observed');
     assert.ok(!promptSubmitEvents.some(event=>event.text.includes('NativeAgentSteerFixture')),'Original Agent Enter unexpectedly entered prompt.submit');
     await writeFile(join(workspace,'native-task-view-proof.json'),JSON.stringify({taskId,focused,queued,resumed,background,parentReceipt,selectedView,keyboardReturnView,promptSubmitEvents,review,agentSiteView:agentSite.props.view,mainSiteView:mainSite.props.view,staleClientRejected:true,focusedObservation,nativeObservation},null,2));
     if(extension==='parent-lifecycle'){
       const lifecycleClient='native-parent-lifecycle-scope';
       await native.uiTransport.request({subtype:'ui_attach',surface:'desktop',client_id:lifecycleClient,answers:[]});
       const lifecycle=async()=>{try{return JSON.parse(await readFile(join(workspace,'native-command-lifecycle.json'),'utf8'))}catch{return []}};
       const priorCompact=new Set((await lifecycle()).filter(value=>value.command==='compact').map(value=>value.startedAt));
       agentModel.delayNextParentResponse(6000);
       let compactReply;
       try{compactReply={result:await parentCommand(lifecycleClient,'/compact')}}catch(error){compactReply={error:error.message}};
       await waitFor(async()=>(await lifecycle()).some(value=>value.command==='compact'&&!priorCompact.has(value.startedAt)&&value.resultType==='compact'),'Original compact module did not return after delayed synthetic reply');
       const compactRun=(await lifecycle()).findLast(value=>value.command==='compact');
       assert.ok(compactRun.returnedAt-compactRun.startedAt>=6000);assert.equal(compactRun.sessionIdBefore,sessionId);assert.equal(compactRun.sessionIdAfter,sessionId);assert.ok(compactRun.boundaries.some(value=>value.trigger==='manual'));
       let compactBoundary;
       await waitFor(async()=>{
         for(const bucket of await readdir(join(configDir,'projects'))){try{const rows=(await readFile(join(configDir,'projects',bucket,sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);compactBoundary=rows.find(row=>compactRun.boundaries.some(value=>value.uuid===row.uuid));if(compactBoundary)return true}catch{}}
         return false;
       },'Returned compact boundary was not persisted by the original command dispatcher');
       assert.equal(compactReply.result?.kind,'command_complete');assert.equal(compactReply.result?.boundaryId,compactBoundary.uuid);
       assert.equal(compactBoundary.subtype,'compact_boundary');assert.equal(compactBoundary.compactMetadata.trigger,'manual');
       const commandSessionBefore=native.state.sessionId;
       let clearReply;
       try{clearReply={result:await parentCommand(lifecycleClient,'/clear')}}catch(error){clearReply={error:error.message}};
       await waitFor(async()=>(await lifecycle()).some(value=>value.command==='clear'&&value.returnedAt&&value.sessionIdAfter!==commandSessionBefore),'Original clear module did not report its new session');
       const clearRun=(await lifecycle()).findLast(value=>value.command==='clear');
       await waitFor(()=>native.state.sessionId===clearRun.sessionIdAfter&&native.state.view?.kind==='main','Native owner did not publish the original clear session and main view');
       assert.ok(clearRun.queryEvents?.some(event=>event.type==='conversation_reset'&&/^[a-f0-9-]{36}$/.test(event.newConversationId)),'Original clear query event did not expose its conversation identity');
       assert.equal(clearReply.result?.kind,'command_complete');assert.equal(clearReply.result?.sessionId,clearRun.sessionIdAfter);assert.equal(clearReply.result?.conversationId,clearRun.queryEvents.find(event=>event.type==='conversation_reset').newConversationId);
       assert.equal(native.state.pid,nativePid);assert.equal(native.state.view.kind,'main');assert.ok(agentModel.calls.some(call=>call.delayedMs===6000&&call.delivered));
       const afterClearReceipt=await native.submit('AfterClearParentTicketFixture');assert.equal(afterClearReceipt.sessionId,clearRun.sessionIdAfter);
       await waitFor(()=>!native.busy,'Ordinary parent input did not finish after native clear');
       const afterClearHooks=JSON.parse(await readFile(join(workspace,'native-prompt-submit-events.json'),'utf8'));assert.ok(afterClearHooks.some(event=>event.text==='AfterClearParentTicketFixture'),'Ordinary post-clear input did not use original prompt hooks');
       await writeFile(join(workspace,'native-parent-lifecycle-proof.json'),JSON.stringify({compactReply,compactRun,compactBoundary,clearReply,clearRun,afterClearReceipt,afterClearPromptHooks:true,ownerSessionId:native.state.sessionId,sameNativePid:true,mainViewRetained:true,delayedSyntheticResponse:true},null,2));
     }
     await native.close();assert.ok(gone(nativePid));assert.ok(gone(oldPid));
     console.log(JSON.stringify({evidence:'apack-native-terminal-view',targetSha256:hash(await readFile(executable)),realProductOwner:true,nativeSelection:true,authoritativeNativeView:true,keyboardReturnObserved:true,explicitAgentUiAttachment:true,authoritativeSiteView:true,staleClientRejected:true,desktopDetachRequired:true,parentDraftRejectedInAgentView:true,nativeRunningInput:true,nativeGuardedResume:true,nativeAgentPromptSubmitBypassed:true,parentPromptSubmitObserved:true,nativeInputReview:true,nativeAgentCommandBlock:true,desktopPromptHostCommandGate:true,nativeAgentCommandConfirmation:true,nativeAgentDispatchController:true,nativeAgentCommandOutput:true,nativeCommandCancellation:true,reviewHasNoTranscriptSideEffects:true,nativeEndTrim:true,nativeGateCases:9,nativeReturn:true,sameNativeTask:true,sameSession:extension!=='parent-lifecycle',nativeParentLifecycle:extension==='parent-lifecycle',ownedShutdown:true,syntheticApiRequests:seedModel.calls.length+agentModel.calls.length,realModelRequests:0,scope:extension==='parent-lifecycle'?'Original view journey precedes compact/clear observation; the lifecycle segment intentionally changes session. Ticket outcomes are source-owner verified; app acceptance is not implied.':'Product source owner and real PTY; default foreground Agent UI and broad queue/lifecycle combinations are not accepted.'}));return;
   }
   if(scenario==='live-main'){
     const changedSub=join(workspace,'sub-live.py');
     await writeFile(changedSub,(await readFile(subHelper,'utf8')).replace('AppOwnedAgent ','AppOwnedAgentLive '));
     await writeFile(join(configDir,'settings.json'),JSON.stringify({...settings,env:{CLAUDE_CODE_SHELL_PREFIX:livePrefix},subagentStatusLine:{type:'command',command:`/usr/bin/python3 '${changedSub}'`}}));
     await waitFor(()=>snapshots.some(state=>state.tasks.some(task=>task.statusText?.startsWith('AppOwnedAgentLive running'))),'Native live subagent command output did not reach the app owner');
   }
   await waitFor(()=>agentModel.calls.some(call=>call.child&&call.delivered)&&agentModel.calls.filter(call=>call.hasAgentResult&&call.delivered).length===2,'Native agent did not finish both continuations');
   await waitFor(()=>snapshots.some(state=>state.tasks.some(task=>task.status==='completed')),'Product native task completion was not observed');
   assert.ok(!snapshots.some(state=>state.tasks.some(task=>task.id==='foreign'||task.statusText?.includes('ForeignMustNotReachApp'))));
   if(livePrefix){
     assert.ok(snapshots.some(state=>state.tasks.some(task=>task.statusText?.includes('AppOwnedAgent running prefix='+livePrefix))),'Subagent helper must inherit the native-applied prefix without invoking it');
     await writeFile(join(configDir,'settings.json'),JSON.stringify(settings));
     await waitFor(()=>native.state.mainStatus?.includes('prefix=original'),'Native-applied prefix restoration was not exported');
   }
   const prefixCalls=(await readFile(prefixLog,'utf8')).trim().split('\n').map(JSON.parse);
   const mainCalls=prefixCalls.filter(call=>call.args.at(-1)===settings.statusLine.command);
   assert.ok(mainCalls.length>0,'Native prefix must receive the original main command');
   for(const call of mainCalls){assert.ok(call.prefix===shellPrefix||livePrefix&&call.prefix===livePrefix);assert.deepEqual(call.args,[call.prefix===shellPrefix?'--fixture-prefix':'--live-prefix',settings.statusLine.command]);}
   if(managedScenario)assert.equal(prefixCalls.some(call=>call.args.at(-1).includes('MustNotExecute')),false,'User status commands reached the native runner under managed-only policy');
   assert.equal(prefixCalls.some(call=>call.args.at(-1).includes('/cc-app-')),false,'Configured prefix must not receive app wrapper commands');
   assert.equal(prefixCalls.some(call=>call.args.at(-1)===settings.subagentStatusLine.command),false,'Native subagent helper does not use main shell prefix');
   const nativePid=native.state.pid;assert.ok(nativePid&&nativePid!==oldPid);
   assert.equal(JSON.parse(await readFile(join(workspace,'helper-bun-options.json'),'utf8')),originalBunOptions,'Helper must inherit the user preload options, not the app observer');
   assert.ok((await readFile(userPreloadCalls,'utf8')).trim().split('\n').map(JSON.parse).some(value=>value.pid===nativePid),'The original user preload must still execute in the native process');
   const metadata=native.state.session;assert.ok(metadata&&metadata.turns>=2&&metadata.totalCostUsd>0);
   const journal=(await native.readJournal()).entries;assert.ok(journal.some(entry=>entry.row.uuid===receipt.uuid&&entry.sessionId===sessionId),'Accepted UUID must occur in the authoritative native journal');
   await writeFile(join(workspace,'product-native-journal.json'),JSON.stringify(journal,null,2));
   assert.equal(native.input('foreign-owner','ignored'),false);assert.equal(native.resize('foreign-owner',80,24),false);
   if(uiTeardown)await uiTeardown();
   if(scenario==='ui-engine'){
    const modelSettingsBefore=await readFile(join(configDir,'settings.json'),'utf8'),modelCallsBefore=agentModel.calls.length;
    const modelCatalog=await native.getModels();assert.ok(modelCatalog.models.some(model=>model.value==='haiku'));
    assert.equal(await native.setModel('haiku'),'haiku');assert.equal(native.modelSelection,'haiku');
    assert.equal(agentModel.calls.length,modelCallsBefore,'Native alias selection/catalog must not create a model turn');
    const png=createNativeTestImage(),imagePath=join(workspace,'native-human-media.png');await writeFile(imagePath,png,{mode:0o600});
    const records=()=>native.records.map(row=>row.record);
    const before=new Set(records().map(record=>record.uuid));
    const mediaReceipt=await native.submit('NativeHumanMediaFixture: inspect this red pixel.',[{mediaType:'image/png',data:png.toString('base64')}]);
    const imageRow=()=>agentModel.requests.flatMap(request=>request.messages??[]).find(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='image'));
    await waitFor(()=>imageRow(),'Native image paste did not deliver image blocks to the model');
    await waitFor(()=>records().some(record=>!before.has(record.uuid)&&record.message.content.some(block=>block.type==='image')),'Native image paste user record was not observed');
    const record=records().find(record=>!before.has(record.uuid)&&record.message.content.some(block=>block.type==='image'));
    assert.equal(record.origin.kind,'composer');assert.equal(mediaReceipt.uuid,record.uuid);
    assert.equal(imageRow().content.find(block=>block.type==='image').source.data,png.toString('base64'));
    await waitFor(()=>!native.busy,'Native image paste turn did not settle');
    await writeFile(join(workspace,'native-human-media.json'),JSON.stringify({imagePath,mediaReceipt,record,modelMessage:imageRow()}));
    const mediaJournal=[];await waitFor(async()=>{const batch=await native.readJournal();assert.deepEqual(batch.problems,[]);mediaJournal.push(...batch.entries);return mediaJournal.some(entry=>entry.row.uuid===record.uuid);},'Native image user UUID did not reach the durable journal');
    await writeFile(join(workspace,'native-human-media.json'),JSON.stringify({imagePath,mediaReceipt,record,modelMessage:imageRow(),journal:mediaJournal}));
    const selectedRequest=agentModel.requests.find(request=>request.messages?.some(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='image')));
    assert.match(selectedRequest.model,/haiku/i,'The next native request ignored the acknowledged model');
    const imageOnly=await native.submit('',[{mediaType:'image/png',data:png.toString('base64')}]);
    await waitFor(()=>records().some(row=>row.uuid===imageOnly.uuid),'Native image-only receipt lacks a user record');
    const imageOnlyRecord=records().find(row=>row.uuid===imageOnly.uuid);assert.equal(imageOnlyRecord.origin.kind,'composer');assert.ok(imageOnlyRecord.message.content.some(block=>block.type==='image'));
    await waitFor(()=>!native.busy,'Native image-only turn did not settle');
    const imageOnlyJournal=[];await waitFor(async()=>{const batch=await native.readJournal();assert.deepEqual(batch.problems,[]);imageOnlyJournal.push(...batch.entries);return imageOnlyJournal.some(entry=>entry.row.uuid===imageOnly.uuid);},'Native image-only UUID did not persist');
    await writeFile(join(workspace,'native-human-image-only.json'),JSON.stringify({receipt:imageOnly,record:imageOnlyRecord,journal:imageOnlyJournal}));
    assert.equal(await native.setModel('default'),'default');
    assert.equal(native.state.sessionId,sessionId);
    assert.equal(await readFile(join(configDir,'settings.json'),'utf8'),modelSettingsBefore,'Thread model control changed user settings');
    await writeFile(join(workspace,'native-model-controls.json'),JSON.stringify({catalog:modelCatalog,selection:'haiku',effectiveRequestModel:selectedRequest.model,restoredSelection:native.modelSelection,settingsUnchanged:true,noSelectionModelTurn:true,sessionId,pid:native.state.pid}));


   }

   if(scenario==='managed'){
    await native.submit('NativePauseFixture');
    await waitFor(async()=>{try{return await readFile(join(workspace,'managed-pause-ready.json'),'utf8')==='ready'&&native.busy;}catch{return false;}},'Native held model request did not keep managed owner busy');
    await writeFile(join(workspace,'managed-held-request.json'),JSON.stringify({busy:native.busy,state:native.state}));
   }
   let finalDrained=false;
   native.beforeRelease(async()=>{
     assert.equal(store.getNativeTerminal('terminal-fixture'),native,'Owner must remain reserved while native history drains');
     let batch;do{batch=await native.readJournal();assert.deepEqual(batch.problems,[])}while(batch.pending);
     finalDrained=true;
   });
   await native.close();assert.equal(finalDrained,true,'close must await final native history');assert.ok(gone(nativePid));assert.equal(store.getNativeTerminal('terminal-fixture'),undefined);
   assert.equal(native.state.mainStatus,undefined);assert.deepEqual(native.state.tasks,[]);
   await writeFile(join(workspace,'product-native-terminal-snapshots.json'),JSON.stringify(snapshots,null,2));
   console.log(JSON.stringify({evidence:'apack-native-terminal-owner',realProductOwner:true,...(managedScenario?{nativeManagedHelpers:true}:{}),...(scenario==='ui-engine'?{nativeDesktopUi:true,nativeFields:true,nativePromptHosts:true,nativeSubmitWithHostAttached:true,nativeFillHooksPreserved:true,reversePromptAcrossTurns:true,staleNativeActionRefused:true}:{}),printExitedBeforeTerminal:true,sameSessionResumed:true,mainStatusDelivered:true,configuredPrefixPreserved:true,nativeLiveMainSettings:scenario==='live-main',nativeLivePrefixSettings:scenario==='live-main',nativeLiveSubagentCommand:scenario==='live-main',originalPreloadPreserved:true,subagentStatusDelivered:true,nativeTaskAttribution:true,productPromptBridge:true,nativeStoredPromptReceipt:true,nativeJournalRead:true,nativeFinalJournalDrained:true,nativeMetadata:true,receipt,metadata,nativeModelProgress:true,ownedShutdown:true,noActiveOwnerAfterClose:true,oldPid,nativePid,sessionId,nativeExit:native.state.exitCode,targetSha256:hash(await readFile(executable)),seedApiRequests:seedModel.calls.length,syntheticApiRequests:seedModel.calls.length+agentModel.calls.length,realModelRequests:0,scope:'Product source owner and broker; no pack build or mounted app renderer acceptance'}));
 }finally{clearTimeout(onboardingStep);clearInterval(timer);unsubscribe()}
}finally{store.killAllHandles();if(native)await native.close();await writeFile(join(workspace,'native-terminal-output.txt'),terminal);await writeFile(join(workspace,'product-native-terminal-snapshots.json'),JSON.stringify(snapshots,null,2));await writeFile(join(workspace,'synthetic-terminal-calls.json'),JSON.stringify({seed:seedModel.calls,agent:agentModel.calls},null,2));await seedModel.close();await agentModel.close()}

})();
