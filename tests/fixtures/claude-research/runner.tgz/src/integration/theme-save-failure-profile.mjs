import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir,readFile,writeFile,rename,lstat,chmod,rmdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';

/** Ordinary private theme plus reversible filesystem refusal; native code still owns every save. */
export async function prepareThemeSaveFailureProfile({setupWorkspace,workspace}) {
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');
 assert.match(workspace,/^\/work\/\.claude-research\/theme-save-failure-app[0-9]+$/);
 const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
 const config=join(setupWorkspace,'app-data/claude-code-profile/config'),settingsPath=join(config,'settings.json'),directory=join(config,'themes');
 const settingsStat=await lstat(settingsPath);assert.ok(settingsStat.isFile()&&settingsStat.uid===1000&&settingsStat.size<=1048576);
 const before=await readFile(settingsPath);assert.equal(sha(before),'5eb7b71763d6c0fc454f048fe69cb174724f161d2f4cdc50a8776c83cbc2e128');
 const directoryExisted=existsSync(directory);if(!directoryExisted)await mkdir(directory,{mode:0o700});
 const directoryStat=await lstat(directory);assert.ok(directoryStat.isDirectory()&&!directoryStat.isSymbolicLink()&&directoryStat.uid===1000&&(directoryStat.mode&0o200));
 const originalMode=directoryStat.mode&0o7777,slug='release-save-'+basename(workspace),themePath=join(directory,slug+'.json'),value='custom:'+slug;
 assert.ok(!existsSync(themePath));
 const bytes=Buffer.from(JSON.stringify({name:'Release persistence review',base:'dark',overrides:{text:'#55ccaa'}},null,2)+'\n');
 await mkdir(join(workspace,'profile-preimages'));
 await writeFile(join(workspace,'profile-preimages/settings.json'),before,{mode:0o600,flag:'wx'});
 const initial={directory,directoryExisted,directoryMode:originalMode,settingsMode:settingsStat.mode&0o7777,themePath,slug,value,settingsSha256:sha(before),themeSha256:sha(bytes),createdThemes:[]};
 await writeFile(join(workspace,'theme-save-profile.json'),JSON.stringify(initial),{mode:0o600,flag:'wx'});
 const declareCreatedTheme=async path=>{
  assert.equal(path,join(directory,basename(path)));assert.match(basename(path),new RegExp('^release-creation-'+basename(workspace)+'(?:-[0-9]+)?\\.json$'));
  assert.ok(!existsSync(path));assert.ok(initial.createdThemes.length<2&&!initial.createdThemes.includes(path));
  initial.createdThemes.push(path);
  const pending=join(workspace,'theme-save-profile.pending.json');await writeFile(pending,JSON.stringify(initial),{mode:0o600,flag:'wx'});await rename(pending,join(workspace,'theme-save-profile.json'));
 };
 const readCreatedTheme=async path=>{assert.ok(initial.createdThemes.includes(path));return existsSync(path)?readFile(path):null;};
 let restored=false,deniedFileMode;
 const allowWrites=async()=>{await chmod(directory,originalMode);if(deniedFileMode!==undefined&&existsSync(themePath))await chmod(themePath,deniedFileMode);deniedFileMode=undefined;assert.equal((await lstat(directory)).mode&0o7777,originalMode);};
 const denyWrites=async()=>{const stat=await lstat(themePath);assert.ok(stat.isFile()&&!stat.isSymbolicLink()&&stat.uid===1000);deniedFileMode=stat.mode&0o7777;await chmod(themePath,deniedFileMode&~0o222);await chmod(directory,originalMode&~0o222);assert.equal((await lstat(directory)).mode&0o222,0);assert.equal((await lstat(themePath)).mode&0o222,0);};
 async function restore() {
  if(restored)return;
  await allowWrites();
  for(const [index,path]of initial.createdThemes.entries())if(existsSync(path))await rename(path,join(workspace,'preserved-created-theme-'+index+'.json'));
  if(existsSync(themePath))await rename(themePath,join(workspace,'preserved-theme-save.json'));
  if(existsSync(settingsPath))await rename(settingsPath,join(workspace,'preserved-theme-save-settings.json'));
  await writeFile(settingsPath,before,{mode:settingsStat.mode&0o7777,flag:'wx'});
  assert.equal(sha(await readFile(settingsPath)),sha(before));assert.ok(!existsSync(themePath));
  if(!directoryExisted)await rmdir(directory);
  await writeFile(join(workspace,'theme-save-profile-restoration.json'),JSON.stringify({restored:true,settingsSha256:sha(before),directoryExisted,directoryMode:originalMode,fixtureThemeRemoved:true,createdThemesRemoved:initial.createdThemes.every(path=>!existsSync(path))}),{mode:0o600,flag:'wx'});
  restored=true;
 }
 try {
  await writeFile(themePath,bytes,{mode:0o600,flag:'wx'});
  await writeFile(settingsPath,JSON.stringify({...JSON.parse(before),theme:value}),{mode:settingsStat.mode&0o7777});
  return {...initial,declareCreatedTheme,readCreatedTheme,readSettings:()=>readFile(settingsPath),denyWrites,allowWrites,readTheme:()=>readFile(themePath),restore};
 } catch(error) {await restore();throw error;}
}
