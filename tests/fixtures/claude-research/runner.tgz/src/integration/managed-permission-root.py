"""Own the fixed managed-policy fixture and one app driver in its dedicated Linux container."""
import hashlib,json,os,re,signal,stat,subprocess,sys,time
from pathlib import Path

POLICY=Path('/etc/claude-code/managed-settings.json')
PERMISSIONS={'permissions':{'disableBypassPermissionsMode':'disable'}}
MCP_ALLOWLIST={'allowManagedMcpServersOnly':True,'allowedMcpServers':[
 {'serverName':name} for name in ('managed-review','user-denied-review')]}
def digest(data):return hashlib.sha256(data).hexdigest()
def main():
 assert sys.platform=='linux' and os.geteuid()==0 and Path('/.dockerenv').is_file()
 assert len(sys.argv)==2
 workspace=Path(sys.argv[1]);prefix='apack-terminal-owner-app-'
 assert re.fullmatch(r'/work/\.claude-research/apack-terminal-owner-app-(?:everyday|command)[0-9]+',str(workspace))
 info=workspace.lstat();assert stat.S_ISDIR(info.st_mode)and info.st_uid==1000 and workspace.resolve()==workspace
 identity=(info.st_dev,info.st_ino)
 boundary=json.loads(Path('/control/offline-verified').read_text());assert boundary['networkDisabled']and boundary['pinnedExecutableReadOnly']
 mcp=boundary.get('requireManagedMcpAdmission') is True
 channel=boundary.get('requireManagedChannelRelay') is True
 assert sum([mcp,channel,boundary.get('requireManagedPermission') is True])==1
 shape='command' if channel else 'everyday';assert re.fullmatch(prefix+shape+r'[0-9]+',workspace.name)
 exhaust=boundary.get('requireManagedMcpReconnectExhaustion') is True
 assert not exhaust or mcp and boundary.get('requireManagedMcpBackgroundTask') is True
 reallow=boundary.get('requireManagedMcpParkedRecovery') is True
 assert not reallow or exhaust and boundary.get('requireManagedMcpBackgroundHttp') is True
 profile,kind,driver,entry=('mcp-allowlist','mcp-admission','apack-managed-mcp-drive','driveManagedMcpApp') if mcp else (
  'permission-restriction','permission','apack-managed-permission-drive','driveManagedPermissionApp')
 if channel:profile,kind,driver,entry='channel-permission','channel-permission','apack-fresh-native-command-drive','driveFreshNativeCommand'
 BODY=(json.dumps({'channelsEnabled':True} if channel else MCP_ALLOWLIST if mcp else PERMISSIONS)+'\n').encode()
 assert any(line.split()[4]==str(POLICY.parent)and' - tmpfs 'in line for line in Path('/proc/self/mountinfo').read_text().splitlines()),'Owned temporary policy mount required'
 assert POLICY.parent.resolve()==POLICY.parent and not POLICY.exists()and not POLICY.is_symlink()
 control=workspace.parent/('policy-transition-'+kind+workspace.name.removeprefix(prefix+shape));assert not control.exists()
 receipt={'workspace':str(workspace),'control':str(control),'initialPolicyAbsent':True,'policyPath':str(POLICY),'initialPolicySha256':digest(BODY),'appStarted':False,'forcedAppCleanup':[]}
 fixture=app=None;code=1;installed=False
 def own_workspace():
  current=workspace.lstat();assert stat.S_ISDIR(current.st_mode)and(current.st_dev,current.st_ino)==identity and workspace.resolve()==workspace
 def owned_children():
  result=[]
  for entry in Path('/proc').iterdir():
   if not entry.name.isdigit():continue
   try:
    if entry.stat().st_uid!=1000:continue
    environment=(entry/'environ').read_bytes().split(b'\0')
    if ('HOME='+str(workspace)).encode()in environment or('APACK_USER_DATA_DIR='+str(workspace/'app-data')).encode()in environment:result.append(int(entry.name))
   except (FileNotFoundError,ProcessLookupError,PermissionError):pass
  return result
 try:
  fd=os.open(POLICY,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o644)
  with os.fdopen(fd,'wb')as output:output.write(BODY)
  installed=True;assert POLICY.stat().st_uid==0 and stat.S_IMODE(POLICY.stat().st_mode)==0o644
  with Path('/control/policy-fixture.log').open('wb')as log:
   fixture=subprocess.Popen(['python3','/research/src/protocol/linux-policy-transition-fixture.py',str(control),'--seconds',str(570 if reallow else 510 if exhaust else 300),'--profile',profile,*(['--mcp-reallow'] if reallow else [])],stdout=log,stderr=subprocess.STDOUT)
   until=time.monotonic()+5
   while not(control/'ready.json').exists():
    assert fixture.poll()is None,'Root fixture exited before readiness'
    assert time.monotonic()<until,'Root fixture readiness timeout'
    time.sleep(.02)
   ready_info=(control/'ready.json').lstat();assert stat.S_ISREG(ready_info.st_mode)and ready_info.st_uid==0
   ready=json.loads((control/'ready.json').read_text());assert ready['initialSha256']==digest(BODY)and ready['profile']==profile
   own_workspace()
   launch=f'import {{{entry}}} from "/research/src/integration/{driver}.mjs";await {entry}({{checkout:"/work",workspace:process.env.HOME,env:process.env}});'
   command=['runuser','-u','node','--','env','HOME='+str(workspace),'ELECTRON_OVERRIDE_DIST_PATH='+str(workspace/'electron-test-host'),'PLAYWRIGHT_VISIBLE=1','APACK_TERMINAL_BINARY=/frozen-broker/apack-terminal','CLAUDE_RESEARCH_STARTUP_RELOAD_ONCE=1','CLAUDE_RESEARCH_POLICY_CONTROL='+str(control),'NODE_COMPILE_CACHE=/tmp/claude-app-bytecode','NODE_OPTIONS=--max-old-space-size=4096 --conditions=@apackdev/source','GIT_CONFIG_COUNT=1','GIT_CONFIG_KEY_0=safe.directory','GIT_CONFIG_VALUE_0=/work','xvfb-run','-a','-s','-screen 0 1280x1024x24','node','--experimental-transform-types','--input-type=module','-e',launch]
   if channel:command[5:5]=['CLAUDE_RESEARCH_MCP_CHANNEL_INGRESS=1','CLAUDE_RESEARCH_MCP_CHANNEL_RELAY=1','CLAUDE_RESEARCH_MCP_CHANNEL_REVOCATION=1']
   receipt['appStarted']=True;app=subprocess.Popen(command,start_new_session=True)
   try:code=app.wait(timeout=540 if reallow else 480 if exhaust else 270)
   except subprocess.TimeoutExpired:receipt['appDeadlineExpired']=True
 finally:
  if app and app.poll()is None:
   os.killpg(app.pid,signal.SIGTERM)
   try:app.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(app.pid,signal.SIGKILL);app.wait(timeout=5)
  until=time.monotonic()+3
  while owned_children()and time.monotonic()<until:time.sleep(.05)
  remaining=owned_children()
  if remaining:
   receipt['forcedAppCleanup']=remaining;code=code or 1
   for sig in [signal.SIGTERM,signal.SIGKILL]:
    for pid in owned_children():
     try:os.kill(pid,sig)
     except ProcessLookupError:pass
    until=time.monotonic()+3
    while owned_children()and time.monotonic()<until:time.sleep(.05)
  receipt['remainingAppProcesses']=owned_children()
  if fixture:
   if fixture.poll()is None and control.is_dir():
    own_workspace();(control/'finish').touch(exist_ok=True)
   try:fixture.wait(timeout=10)
   except subprocess.TimeoutExpired:
    fixture.terminate()
    try:fixture.wait(timeout=5)
    except subprocess.TimeoutExpired:fixture.kill();fixture.wait(timeout=5)
   receipt['fixtureExitCode']=fixture.returncode
   if fixture.returncode!=0:code=code or 1
   if(control/'restored.json').is_file():receipt['fixtureRestoration']=json.loads((control/'restored.json').read_text())
   own_workspace();evidence=workspace/'policy-control-evidence';evidence.mkdir(exist_ok=False)
   for name in ['ready.json','receipt-1.json','receipt-2.json','receipt-3.json','restored.json']:
    path=control/name
    if path.exists():
     observed=path.lstat();assert stat.S_ISREG(observed.st_mode)and observed.st_uid==0 and observed.st_size<=1048576
     (evidence/name).write_bytes(path.read_bytes())
  if installed:
   observed=POLICY.lstat();assert stat.S_ISREG(observed.st_mode)and observed.st_uid==0 and POLICY.read_bytes()==BODY,'Unexpected policy bytes; refusing to remove'
   POLICY.unlink();receipt['initialPolicyAbsenceRestored']=not POLICY.exists()
  receipt['appExitCode']=app.returncode if app else None;receipt['exitCode']=code
  name='managed-channel-root.json' if channel else 'managed-mcp-root.json' if mcp else 'managed-permission-root.json'
  Path('/control',name).write_text(json.dumps(receipt,indent=2)+'\n')
 return code
if __name__=='__main__':raise SystemExit(main())
