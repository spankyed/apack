"""Verify saved original production-worker evidence; never execute Claude or the app."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile


def verify(root, product):
    read = lambda name: json.loads((root / name).read_text())
    stage, post, boundary = map(read, ['receipt.json', 'post-inputs.json', 'boundary.json'])
    assert read('result.json')['exitCode'] == stage['exitCode'] == 0
    assert boundary['network'] == 'none' and boundary['networkDisabled']
    assert boundary['pinnedExecutableReadOnly']
    assert boundary['memoryBytes'] == 6 * 1024 ** 3 and boundary['cpus'] == 2
    assert boundary['productCommit'] == stage['productCommit']
    assert boundary['researchCommit'] == stage['researchCommit']
    assert post['passed'] and post['nativeOnly']
    for name, count in post['counts'].items():
        assert count == len(read(name))
    research = Path(__file__).resolve().parents[2]
    for name, checkout, commit in [
        ('source-inputs.json', product, stage['productCommit']),
        ('authored-inputs.json', research, stage['researchCommit']),
    ]:
        manifest = read(name)
        refs = ''.join(commit + ':' + path + '\n' for path in manifest)
        blobs = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=checkout, input=refs.encode())
        offset = 0
        for path, expected in manifest.items():
            end = blobs.index(b'\n', offset)
            header = blobs[offset:end].split()
            assert len(header) == 3 and header[1] == b'blob', path
            size = int(header[2])
            value = blobs[end + 1:end + 1 + size]
            assert len(value) == size and blobs[end + 1 + size:end + 2 + size] == b'\n'
            assert hashlib.sha256(value).hexdigest() == expected, path
            offset = end + 2 + size
        assert offset == len(blobs)
    assert not any(int(line.split()[1]) for line in (root / 'memory.events').read_text().splitlines()
                   if line.split()[0].startswith('oom'))
    with tarfile.open(root / 'results.tar.gz') as archive:
        member = archive.getmember('results/product-child-desktop.json')
        assert member.isfile() and member.size <= 8 * 1024 ** 2
        proof = json.load(archive.extractfile(member))
    assert proof['status'] == 'complete'
    assert proof['staleActionRefused'] and proof['ownerRetired'] and proof['syntheticAuthSettingsRestored']
    job, stopped = proof['job'], proof['stopped']
    assert job['pid'] > 1 and job['sessionId'] != proof['parentSessionId']
    assert str(proof['processStart']).isdigit()
    assert stopped['id'] == job['id'] and stopped['sessionId'] == job['sessionId'] and stopped['state'] == 'stopped'
    callback = proof['callback']
    assert callback['sessionId'] == job['sessionId'] and callback['callback']
    for name, text in [('before', 'Owned child desktop draft あ🙂'),
                       ('after', 'Owned child desktop replacement あ🙂')]:
        assert callback['prompt'][name] == {'text': text, 'cursor': len(text.encode('utf-16-le')) // 2}
    assert callback['prompt']['filled']['isFilled']
    assert proof['hostCalls'].count('fill') == 1 and proof['hostCalls'][0] == proof['hostCalls'][-1] == 'read'
    assert proof['terminalInputWrites'] == proof['realModelRequests'] == 0
    assert not any(row['foreignKey'] for row in proof['requests'])
    model_requests = sum(row['path'].startswith('/v1/messages') for row in proof['modelRequests'])
    assert 1 <= model_requests <= 6
    return {'passed': True, 'productCommit': stage['productCommit'], 'researchCommit': stage['researchCommit'],
            'counts': post['counts'], 'job': job, 'originalCallback': True, 'unicodeReadFillRead': True,
            'staleActionRefused': True, 'originalStopConfirmed': True, 'ownerRetired': True,
            'syntheticProfileSettingsRestored': True, 'syntheticApiRequests': len(proof['modelRequests']),
            'syntheticModelRequests': model_requests, 'realModelRequests': 0, 'oom': False,
            'scope': 'Original production-worker transport only; no mounted app acceptance.',
            'metadataCorrection': proof['syntheticModelRequests'] != model_requests}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    parser.add_argument('--product', required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.evidence, args.product), indent=2))
