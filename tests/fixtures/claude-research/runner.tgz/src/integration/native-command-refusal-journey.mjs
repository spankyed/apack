import assert from 'node:assert/strict';
import {join} from 'node:path';

/** Original unavailable-command warning, desktop refusal and fresh input on the same owner. */
export async function driveCommandRefusalJourney({page,electronApp,multipleWindows=false,expect,context,composer,send,section,replace,proof,output,birth,save,phase,model}) {
  proof.scope='Original unknown-command refusal in the ordinary desktop composer, retained draft/history/cost and same-worker fresh-input recovery. No scan/task acceptance, feature-gate override or full parity claim.';
  proof.command='/owned-refusal-verification';proof.nativeReason='Unknown command: '+proof.command;
  const errorText='Native prompt refused: '+proof.nativeReason;
  const snapshot=()=>composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
  const sameOwner=async()=>{const value=await context();assert.equal(value.claude.sessionId,proof.sessionId);assert.equal(value.native.state.nativePid,proof.pid);assert.equal(await birth(proof.pid),proof.processStart);return value;};
  const capture=async(stage,text)=>{
    for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
      await page.setViewportSize(viewport);await expect(composer).toHaveText(text);await expect(composer).toBeEditable();await expect(composer).toBeInViewport({ratio:1});await expect(send).toBeEnabled();await expect(send).toBeInViewport({ratio:1});
      const error=page.getByText(errorText,{exact:true});if(stage==='refused')await expect(error).toBeInViewport({ratio:1});else await expect(error).toHaveCount(0);
      const layout=[];for(const item of [composer,send,...(stage==='refused'?[error]:[])]){const box=await item.evaluate(e=>{const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return{x:r.x,y:r.y,width:r.width,height:r.height,reachable:!!hit&&(e===hit||e.contains(hit))}});assert.ok(box.reachable);layout.push(box)}
      proof.layouts.push({stage,size,layout});const file='native-command-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);await save();
    }
  };
  let popout,otherComposer,otherSend;
  const otherContext=()=>popout.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id)}});
  const otherSnapshot=()=>otherComposer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
  if(multipleWindows){
    proof.multipleWindows={draft:'Keep the popout review draft 👋',errors:[]};
    const opened=electronApp.waitForEvent('window');await page.evaluate(()=>window.electronAPI.surfaces.popout('default-setup/threads','Threads'));popout=await opened;
    popout.on('pageerror',error=>proof.multipleWindows.errors.push(error.message));await popout.waitForLoadState('domcontentloaded');
    await expect.poll(()=>popout.evaluate(()=>!!window.applicationState?.system.get('default-setup/threads'))).toBe(true);
    await popout.evaluate(threadId=>window.applicationState.system.get('default-setup/threads').send({type:'OPEN_THREAD_CHAT',threadId}),proof.initial.threadId);
    const otherCard=popout.locator('[data-onboarding-id="agent-chat-input"]');otherComposer=otherCard.locator('[contenteditable="true"]');otherSend=otherCard.getByRole('button',{name:'Send',exact:true});
    await expect(otherComposer).toBeVisible();await otherComposer.fill(proof.multipleWindows.draft);proof.multipleWindows.before=await otherContext();proof.multipleWindows.composerBefore=await otherSnapshot();
    assert.equal(proof.multipleWindows.before.native.state.nativePid,proof.pid);assert.equal(proof.multipleWindows.before.claude.sessionId,proof.sessionId);
  }
  await replace(proof.command);proof.beforeRefusal=await sameOwner();proof.composerBeforeRefusal=await snapshot();proof.requestWindow={before:model.calls.length};proof.submittedAt=Date.now();await send.click();
  await expect(page.getByText(errorText,{exact:true})).toBeVisible({timeout:15000});proof.refusalText=await page.getByText(errorText,{exact:true}).innerText();proof.refusedAt=Date.now();proof.requestWindow.after=model.calls.length;
  proof.afterRefusal=await sameOwner();proof.composerAfterRefusal=await snapshot();assert.deepEqual(proof.composerAfterRefusal,proof.composerBeforeRefusal);
  assert.deepEqual(proof.afterRefusal.messages,proof.beforeRefusal.messages);assert.equal(proof.afterRefusal.claude.turns,proof.beforeRefusal.claude.turns);assert.equal(proof.afterRefusal.claude.totalCostUsd,proof.beforeRefusal.claude.totalCostUsd);
  assert.ok(!model.calls.slice(proof.requestWindow.before,proof.requestWindow.after).some(call=>JSON.stringify(call.messages??[]).includes(proof.command)),'Unknown local command must not become a model request');
  await capture('refused',proof.command);
  if(multipleWindows){
    proof.multipleWindows.after=await otherContext();proof.multipleWindows.composerAfter=await otherSnapshot();assert.deepEqual(proof.multipleWindows.composerAfter,proof.multipleWindows.composerBefore);
    assert.deepEqual(proof.multipleWindows.after.messages,proof.multipleWindows.before.messages);assert.equal(proof.multipleWindows.after.claude.totalCostUsd,proof.beforeRefusal.claude.totalCostUsd);
    for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
      await popout.setViewportSize(viewport);await expect(otherComposer).toHaveText(proof.multipleWindows.draft);await expect(otherComposer).toBeEditable();await expect(otherComposer).toBeInViewport({ratio:1});await expect(otherSend).toBeEnabled();await expect(otherSend).toBeInViewport({ratio:1});
      const layout=[];for(const item of [otherComposer,otherSend])layout.push(await item.evaluate(e=>{const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return{x:r.x,y:r.y,width:r.width,height:r.height,reachable:!!hit&&(e===hit||e.contains(hit))}}));
      proof.layouts.push({stage:'popout-refused',size,layout});const file='native-command-popout-refused-'+size+'.png';await popout.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);await save();
    }
    await popout.close();proof.multipleWindows.closed=true;proof.multipleWindows.mainAfterClose=await sameOwner();await expect(composer).toHaveText(proof.command);assert.deepEqual(proof.multipleWindows.errors,[]);
  }
  proof.followup='Continue the release summary after the unavailable command.';await replace(proof.followup);await send.click();
  await expect.poll(async()=>{const c=await sameOwner();return c.claude.chatState==='success'&&c.native.state.busy===false&&c.messages.filter(m=>m.sender==='user'&&m.text===proof.followup).length===1},{timeout:15000}).toBe(true);
  proof.draft='Keep the release notes for the next review.';await composer.fill(proof.draft);proof.final=await sameOwner();proof.composerFinal=await snapshot();
  assert.equal(proof.final.claude.turns,proof.beforeRefusal.claude.turns+1);assert.equal(proof.final.claude.totalCostUsd,proof.final.native.state.session.totalCostUsd);
  await capture('recovered',proof.draft);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
  proof.stopped=true;proof.status='complete';await save();phase('native-command-refusal-complete');
}
