import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { promisify, stripVTControlCharacters } from 'node:util';
import { record } from '../protocol/record.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { processStart } from './native-process-state.mjs';

const executable = '/frozen-claude/claude';
const pty = new URL('../protocol/pty_bridge.py', import.meta.url).pathname;
const prompt = 'Ask which synthetic fixture should be selected for the release review.';
const reply = 'Fixture completed.';
const question = 'Which synthetic fixture should be selected?';

export async function prepareFleetFooterWorker({ workspace, project, env }) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
  assert.equal(env.CLAUDE_CONFIG_DIR, join(workspace, '.claude'));
  const model = await startSyntheticModel(workspace, 'AskUserQuestion', {
    questionAfterText: prompt, maxRequests: 10, captureMessages: true,
  });
  const workerEnv = { ...env, ANTHROPIC_BASE_URL: model.url, TERM: 'xterm-256color' };
  const output = join(workspace, 'fleet-footer-worker');
  let id, job;
  const execute = promisify(execFile);
  const list = async () => JSON.parse((await execute(executable, ['agents', '--json', '--all', '--cwd', project], {
    env: workerEnv, cwd: project, timeout: 5000, maxBuffer: 1024 * 1024, encoding: 'utf8',
  })).stdout);
  const readJob = async () => (await list()).find(row => row.id === id && row.cwd === project);
  const pending = row => row?.state === 'blocked' && row.status === 'waiting' && row.waitingFor === 'input needed';
  const runPty = (name, args, onStdout) => record({
    executable: '/usr/bin/python3', args: [pty, executable, ...args], env: workerEnv, cwd: project,
    output: join(output, name), timeoutMs: 20000, maxBytes: 1024 * 1024, onStdout,
  });
  return {
    async start() {
      assert.equal(id, undefined);
      const run = await runPty('start', ['--bg', '--name', 'Release review question', '--model', 'claude-sonnet-4-6',
        '--setting-sources', 'user,project,local', '--tools', 'AskUserQuestion', '--strict-mcp-config', prompt]);
      const stdout = stripVTControlCharacters(await readFile(join(run.directory, 'stdout.bin'), 'utf8'));
      id = stdout.match(/backgrounded\s*·\s*([a-f0-9]{8})/u)?.[1];
      assert.equal(run.status, 'complete', stdout);
      assert.ok(id, stdout);
      for (let attempt = 0; attempt < 24; attempt++) {
        job = await readJob();
        if (pending(job)) break;
        await delay(500);
      }
      await writeFile(join(output, 'listed-before-answer.json'), JSON.stringify({ job, calls: model.calls }, null, 2));
      assert.ok(pending(job), 'Original fleet job did not report a waiting input');
      assert.ok(job.sessionId && job.pid && await processStart(job.pid));
      return job;
    },
    async answer() {
      assert.ok(pending(await readJob()));
      let answered = false, terminal = '';
      const normal = value => value.replace(/\s/g, '');
      const run = await runPty('attach', ['attach', id], (bytes, channel) => {
        terminal += bytes.toString('utf8');
        const screen = normal(stripVTControlCharacters(terminal));
        if (!answered && screen.includes(normal(question))) {
          answered = true;
          channel.send('\r');
        } else if (answered && screen.includes(normal(reply))) {
          channel.stop('owned-answer-observed');
        }
      });
      assert.ok(answered);
      assert.equal(run.reason, 'owned-answer-observed');
      const result = model.calls.flatMap(call => call.messages ?? []).flatMap(message =>
        Array.isArray(message.content) ? message.content : []).find(block =>
        block.type === 'tool_result' && block.tool_use_id === 'toolu_research_fixture' && !block.is_error
        && JSON.stringify(block.content).includes('Alpha'));
      assert.ok(result, 'Original question answer did not reach its worker');
      const after = await readJob();
      assert.equal(after?.sessionId, job.sessionId);
      assert.ok(!pending(after));
      return { after, result };
    },
    async close() {
      try {
        if (id && (await readJob())?.state !== 'stopped') await execute(executable, ['stop', id], {
          env: workerEnv, cwd: project, timeout: 10000, maxBuffer: 1024 * 1024,
        });
        await writeFile(join(output, 'model-calls.json'), JSON.stringify(model.calls, null, 2));
      } finally {
        await model.close();
      }
    },
  };
}
