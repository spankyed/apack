const http=require('node:http');
const {syncBuiltinESMExports}=require('node:module');
const {appendFileSync,statSync}=require('node:fs');
// Opt-in owned-API diagnostics: observe lifecycle/status only, never consume requests or log tokens/bodies.
const path=process.env.APACK_NATIVE_POLL_OBSERVER;
if(process.platform==='linux'&&path&&/^\/work\/\.claude-research\/saved-command-app[1-9]\d*\/electron-results\/native-owner-http\.jsonl$/.test(path)){
 const record=value=>{try{let size=0;try{size=statSync(path).size}catch{}if(size<1024*1024)appendFileSync(path,JSON.stringify({at:Date.now(),pid:process.pid,...value})+'\n',{mode:0o600});}catch{}};
 record({kind:'observer-installed',entry:process.argv[1]?.split('/').at(-1),api:process.cwd().endsWith('/packages/api')});
 const create=http.createServer;
 http.createServer=function(...args){const server=Reflect.apply(create,this,args);server.on('request',(request,response)=>{
  if(!['/poll','/ui-ready','/observer-ready','/observer-error'].includes(request.url))return;
  response.once('finish',()=>record({kind:'response',route:request.url,status:response.statusCode}));
 });return server;};syncBuiltinESMExports();
}
