import assert from 'node:assert/strict';
import http from 'node:http';
import {mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const {query}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')));
const entered=Promise.withResolvers(),requests=[];
let native,pendingResponse;
const server=http.createServer(async(req,res)=>{
 try{
  let bytes=0;const chunks=[];for await(const chunk of req){bytes+=chunk.length;assert.ok(bytes<1024*1024);chunks.push(chunk)}
  const body=JSON.parse(Buffer.concat(chunks));assert.ok(req.url.startsWith('/v1/messages'));assert.equal(body.model,'research-pending-control-fixture');
  requests.push({path:req.url,model:body.model});assert.equal(requests.length,1);pendingResponse=res;entered.resolve();
 }catch(error){res.writeHead(400);res.end('{}');entered.reject(error)}
});
server.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));
try{
 const cwd=join(workspace,'project');await mkdir(cwd);
 native=await query({cliPath:executable,cwd,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),ANTHROPIC_BASE_URL:`http://127.0.0.1:${server.address().port}`},tools:[],strictMcpConfig:true,settingSources:[],settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),noSessionPersistence:true,model:'sonnet',keepStdinOpen:true,signal:AbortSignal.timeout(20000)});
 const firstResult=native.result.then(()=>({status:'resolved'}),error=>({status:'rejected',name:error.name}));
 const drain=(async()=>{let count=0;for await(const event of native.events){assert.notEqual(event.type,'__parse_error');count++}return count})();
 await native.initialized;
 let settled=false;
 const control=native.setModel('research-pending-control-fixture').then(()=>({status:'resolved'}),error=>({status:'rejected',name:error.name})).finally(()=>{settled=true});
 await entered.promise;assert.equal(settled,false);assert.equal(pendingResponse.writableEnded,false);
 native.kill();await native.close();
 const receipt=await control;assert.equal(receipt.status,'rejected');assert.equal((await firstResult).status,'rejected');
 await drain;await assert.rejects(native.getModels());assert.throws(()=>native.send('Must never be delivered.'),/stdin is closed/);
 assert.equal(requests.length,1);
 console.log(JSON.stringify({evidence:'apack-native-control-exit',initialized:true,control:'set_model',validationReachedLocalApi:true,controlPendingAtKill:true,controlRejected:true,firstResultRejected:true,streamDrained:true,closeSettled:true,postExitControlRejected:true,postExitSendRejected:true,localModelRequests:requests.length,realModelRequests:0,qualification:'Actual native query and in-flight custom-model validation. Explicit kill only; graceful exit, timeout, every control kind, compiled UI and provider variants are not established.'}));
}finally{native?.kill();await native?.close().catch(()=>{});pendingResponse?.destroy();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
