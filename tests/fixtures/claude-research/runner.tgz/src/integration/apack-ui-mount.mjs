import assert from 'node:assert/strict';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(base,'query.ts')).href);
const {createClaudeConversation}=await import(pathToFileURL(join(base,'conversation.ts')).href);
const {mountClaudeUi}=await import(pathToFileURL(join(base,'ui-mount.ts')).href);
const plugin=join(workspace,'plugin');await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
const pluginSource=`export function register(on) {
 let count=0,draft="",submissions=[];
 on("ui.focus",async($,e,next)=>{await $.fs.write("focus-request.json",JSON.stringify(e));if(e.element==="fixture-button")return next({...e,element:"fixture-select"});return next(e);});
 on("prompt.change",async($,e,next)=>{await $.fs.write("prompt-changes.json",JSON.stringify(e));return next(e);});
 on("prompt.autocomplete",async($,e,next)=>{await $.fs.write("autocomplete-request.json",JSON.stringify(e));const result=await next(e);return {...result,suggestions:[...result.suggestions,{text:"native-token",label:"Native token",description:"Pinned native completion"}]};});
 on("prompt.submit",async($,e,next)=>{submissions.push({text:e.text,origin:e.origin,attachments:e.attachments??[]});await $.fs.write("submissions.json",JSON.stringify(submissions));if(e.text==="Synthetic blocked submission")return {drop:"Native submission fixture refused"};return next({...e,text:e.text+" NATIVE_SUBMIT_REWRITE",context:[...(e.context??[]),"NATIVE_SUBMIT_CONTEXT"]});});
 on("prompt.edit",async($,e,next)=>{const frame=await next(e);return {...frame,text:frame.text.toUpperCase(),decorations:[{start:0,end:frame.text.length,bold:true}]};});
 on("ui.render",{component:"AbovePrompt"},async($,e,next)=>{
  const {Box,Text,Button,Input,Select,Markdown,Code,Link,Svg}=$.ui.resolve(e);
  const capture=async(file,value)=>{await $.fs.write(file,JSON.stringify(value));$.ui.invalidate("ui.render");};
  try { return Box({key:"fixture-scope",hover:{borderColor:"success"},flexDirection:"column",gap:"sm",paddingX:1,borderStyle:"round",borderColor:"warning",borderDimColor:true,backgroundColor:"inverseText",children:[
   Text({children:["Synthetic apack UI count: "+count]}),
   Button({key:"fixture-button",label:"Run fixture",hotkey:"w",variant:"primary",dimColor:true,autoFocus:true,children:["Run ",Text({bold:true,children:["fixture"]})],onPress:async()=>{count++;await $.fs.write("pressed.txt",String(count));$.ui.invalidate("ui.render");}}),
   Input({key:"fixture-input",label:"Native draft",rows:3,value:draft,submitLabel:"send",onInput:async(value)=>{if(value==="PROMPT_HOST"){const before=await $.prompt.read();const filled=await $.prompt.fill({text:" NATIVE_FILL",mode:"insert"});const after=await $.prompt.read();await $.fs.write("prompt-host-result.json",JSON.stringify({before,filled,after}));return;}if(value==="FOCUS_PUSH"){await $.fs.write("focus-push-result.json",JSON.stringify(await $.ui.focus({requestId:e.requestId,key:"fixture-input"})));return;}return capture("changed.json",value);},onSubmit:async(value)=>{draft="Native reset";await capture("submitted.json",value);}}),
   Select({key:"fixture-select",label:"Native choice",options:[{value:"alpha",label:"Alpha"},{value:"beta",label:"Beta"}],value:"alpha",onSelect:async(value)=>capture("selected.json",value)}),
   Markdown({key:"fixture-markdown",text:"**Native document** [Open](https://example.com/)",pressableLinks:["https://example.com/"],onLinkPress:async(value)=>capture("link.json",value)}),
   Text({weight:"medium",dir:"rtl",color:"success",backgroundColor:"#123456",hover:{scope:"fixture-hover",color:"warning",inverse:true},children:["Inline ",Text({italic:true,children:["styled"]}),Link({href:"https://example.com/",label:"Native link"})]}),
   Svg({source:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 20"><rect width="40" height="20" fill="blue"/></svg>',alt:"Native diagram",width:40,height:20,isInteractive:true}),
   Box({position:"absolute",display:"none",hover:{display:"flex",left:2},children:[Text({children:["Hidden hover fixture"]})]}),
   Code({source:"const fixture = 42;",language:"javascript",path:"fixture.js",startLine:7}),
   await next(e)
  ]}); } catch(error) { await $.fs.write("render-error.txt",String(error)); throw error; }
 });
}`;
await writeFile(join(plugin,'.claude-plugin','plugin.json'),JSON.stringify({name:'research-ui-fixture',version:'0.0.1'}));await writeFile(join(plugin,'hooks','hooks.json'),JSON.stringify({modules:['./register.ts']}));await writeFile(join(plugin,'hooks','register.ts'),pluginSource);
const model=await startSyntheticModel(workspace,'TextOnly',{captureMessages:true});
let owner,native,promptBridge,promptEditor;const views=[],states=[[],[],[]];let turns=0;const submissionEvents=[];
const wait=async(predicate,label)=>{const deadline=Date.now()+5000;while(!predicate()){if(Date.now()>deadline){await writeFile(join(workspace,'mount-states.json'),JSON.stringify(states,null,2));throw Error('Timed out: '+label)};await new Promise(resolve=>setTimeout(resolve,10));}};
const action=state=>{if(state?.status!=='live')return;const walk=node=>node.kind==='button'?node.actionId:node.kind==='box'?node.children.map(walk).find(Boolean):undefined;return walk(state.tree)};
const last=index=>states[index].at(-1);
const node=(index,kind)=>{const state=last(index);if(state?.status!=='live')return;const walk=value=>value.kind===kind?value:value.kind==='box'?value.children.map(walk).find(Boolean):undefined;return walk(state.tree)};
const captured=async name=>JSON.parse(await readFile(join(workspace,name),'utf8'));

const count=(index,n)=>last(index)?.status==='live'&&JSON.stringify(last(index).tree).includes('count: '+n);
try{
 native=await query({cliPath:executable,cwd:workspace,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:undefined,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},tools:[],pluginDir:[plugin],strictMcpConfig:true,settingSources:[],noSessionPersistence:true,replayUserMessages:true,keepStdinOpen:true,signal:AbortSignal.timeout(15000),settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})});

 owner=createClaudeConversation(native,async()=>{throw Error('Unexpected autonomous turn')});
 await native.initialized;
 owner.start('Synthetic mounted UI fixture',async turn=>{for await(const event of turn.handle.events){submissionEvents.push(event)};owner.release(turn.handle);turns++});
 await wait(()=>turns===1&&!owner.busy,'host turn');
 const modelText=JSON.stringify(model.calls[0]?.messages);
 assert.ok(modelText.includes('NATIVE_SUBMIT_REWRITE'));assert.ok(modelText.includes('NATIVE_SUBMIT_CONTEXT'));
 owner.start('Synthetic blocked submission',async turn=>{for await(const event of turn.handle.events){submissionEvents.push(event)};owner.release(turn.handle);turns++});
 await wait(()=>turns===2&&!owner.busy,'blocked submission result');
 assert.equal(model.calls.length,1);
 const submissions=await captured('submissions.json');assert.equal(submissions.length,2);assert.equal(submissions[1].text,'Synthetic blocked submission');
 await writeFile(join(workspace,'submission-events.json'),JSON.stringify(submissionEvents,null,2));

 // Focus uses the native band's canonical site, not an arbitrary render-instance UUID.
 const focusClient={client_id:'research-focus',surface:'desktop'};
 const focusSite={...focusClient,component:'AbovePrompt',instance_id:'above-prompt'};
 const focusPushes=[];const unsubscribeFocus=owner.subscribe(event=>{if(event.type==='system'&&event.subtype==='ui_focus')focusPushes.push(event)});
 let hostDraft={text:'Draft🙂',cursor:5};let reverseReads=0,reverseFills=0;
 const stopPromptHost=native.ui.servePrompt(focusClient.client_id,{
  read:async signal=>{assert.equal(signal.aborted,false);reverseReads++;return {...hostDraft};},
  fill:async(input,signal)=>{assert.equal(signal.aborted,false);reverseFills++;assert.equal(input.mode,'insert');hostDraft={text:hostDraft.text.slice(0,hostDraft.cursor)+input.text+hostDraft.text.slice(hostDraft.cursor),cursor:hostDraft.cursor+input.text.length};return true;}
 });
 await native.ui.attach(focusClient);
 try {
  const rendered=await native.ui.render({...focusSite,props:{}});
  const find=(tree,type)=>tree?.type===type?tree:Array.isArray(tree?.children)?tree.children.map(child=>find(child,type)).find(Boolean):undefined;
  const rawButton=find(rendered.tree,'Button'),rawInput=find(rendered.tree,'Input');assert.ok(rawButton?.press&&rawInput?.press);
  const focus={...focusSite,is_held:true,by:'person'};
  const unknown=await native.ui.focus({...focus,instance_id:'not-a-native-site',element:null});
  assert.equal(unknown.moved,false);assert.equal(unknown.deny,'no such site');
  const redirected=await native.ui.focus({...focus,element:{plugin:rawButton.press.plugin,key:rawButton.props.key}});
  assert.equal(redirected.moved,true);assert.deepEqual(redirected.element,{plugin:rawButton.press.plugin,key:'fixture-select'});
  assert.equal((await captured('focus-request.json')).origin.kind,'person');
  const held=await native.ui.focus(focus);assert.deepEqual(held.element,redirected.element);
  assert.equal(focusPushes.length,0);
  await native.ui.input({...focusSite,...rawInput.press,key:rawInput.props.key,kind:'change',value:'FOCUS_PUSH'});
  await wait(()=>focusPushes.length===1,'plugin focus push');
  assert.deepEqual(await captured('focus-push-result.json'),{});
  assert.equal(focusPushes[0].client_id,focusClient.client_id);assert.equal(focusPushes[0].instance_id,'above-prompt');assert.equal(focusPushes[0].key,'fixture-input');
  await native.ui.input({...focusSite,...rawInput.press,key:rawInput.props.key,kind:'change',value:'PROMPT_HOST'});
  const promptHostResult=await captured('prompt-host-result.json');
  assert.deepEqual(promptHostResult.before,{text:'Draft🙂',cursor:5});assert.equal(promptHostResult.filled.isFilled,true);
  assert.deepEqual(promptHostResult.after,hostDraft);assert.equal(hostDraft.text,'Draft NATIVE_FILL🙂');assert.equal(reverseFills,1);assert.ok(reverseReads>=2);
  const released=await native.ui.focus({...focus,is_held:false});assert.equal(released.element,null);
 } finally {stopPromptHost();unsubscribeFocus();await native.ui.detach(focusClient.client_id);}
 const mount=index=>{const view=mountClaudeUi({owner,isCurrent:()=>!owner.closing,publish:state=>states[index].push(state)});views.push(view);return view};
 const first=mount(0),second=mount(1);await Promise.all([first.ready,second.ready]);
 await wait(()=>count(0,0)&&count(1,0),'both mounted views');
 const button=node(0,'button');assert.ok(button);assert.equal(button.hotkey,'w');assert.equal(button.variant,'primary');assert.equal(button.dimColor,true);assert.equal(button.autoFocus,true);assert.ok(button.children.some(child=>child.kind==='text'&&child.text==='fixture'&&child.style?.bold));
 const input=node(0,'input'),select=node(0,'select'),markdown=node(0,'markdown'),code=node(0,'code');
 assert.ok(input&&select&&markdown?.actionId&&code);
 assert.ok(button.focusId&&input.focusId&&select.focusId);
 const focused=await first.focus({revision:1,isHeld:true,by:'person',focusId:button.focusId});
 assert.equal(focused?.moved,true);assert.equal(focused.focusId,select.focusId);
 assert.equal(await second.focus({revision:1,isHeld:true,by:'person',focusId:button.focusId}),undefined);
 await first.focus({revision:2,isHeld:false,by:'person'});

 assert.deepEqual(last(0).tree.layout,{flexDirection:'column',gap:'sm',paddingX:1});
 assert.equal(last(0).tree.boxKey,'fixture-scope');assert.deepEqual(last(0).tree.hover,{paint:{borderColor:'success'}});
 const reveal=last(0).tree.children.find(value=>value.kind==='box'&&value.layout?.display==='none');assert.deepEqual(reveal.hover,{layout:{display:'flex',left:2}});
 assert.deepEqual(last(0).tree.paint,{borderStyle:'round',borderColor:'warning',backgroundColor:'inverseText',borderDimColor:true});
 const inline=last(0).tree.children.find(value=>value.kind==='text'&&value.children?.length);
 assert.ok(inline);assert.equal(inline.style.weight,'medium');assert.equal(inline.style.dir,'rtl');assert.equal(inline.style.color,'success');assert.equal(inline.style.backgroundColor,'#123456');assert.equal(JSON.parse(inline.hover.group)[1],'fixture-hover');assert.deepEqual(inline.hover.text,{color:'warning',inverse:true});
 assert.ok(inline.children.some(value=>value.kind==='text'&&value.style?.italic&&value.text==='styled'));
 assert.ok(inline.children.some(value=>value.kind==='link'&&value.href==='https://example.com/'&&value.children[0]?.text==='Native link'));
 const require=createRequire(join(checkout,'package.json'));
 const {JSDOM}=require('jsdom');const dom=new JSDOM('<!doctype html><html><body></body></html>',{url:'http://localhost/'});
 for(const key of ['window','document','navigator','Node','HTMLElement','Element','Document','DocumentFragment','MutationObserver','getComputedStyle'])Object.defineProperty(globalThis,key,{value:dom.window[key],configurable:true,writable:true});
 const {Editor}=await import(pathToFileURL(require.resolve('@tiptap/core').replace(/\.cjs$/,'.js')).href);
 const {default:StarterKit}=await import(pathToFileURL(require.resolve('@tiptap/starter-kit').replace(/\.cjs$/,'.js')).href);
 const {Markdown}=await import(pathToFileURL(require.resolve('tiptap-markdown').replace('tiptap-markdown.umd.js','tiptap-markdown.es.js')).href);
 const {bindClaudePromptEditor}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/threads/fe/chat/native-prompt-editor.ts')).href);
 promptEditor=new Editor({extensions:[StarterKit,Markdown],content:'seed'});promptEditor.commands.setTextSelection(5);
 const promptRequests=[],promptProblems=[];let completionRows=[],nativeCompletionRevision=0,completionOfferId;
 const promptDiagnostic=()=>writeFile(join(workspace,'prompt-editor-state.json'),JSON.stringify({requests:promptRequests,problems:promptProblems,text:promptEditor?.state.doc.textContent},null,2));
 promptBridge=bindClaudePromptEditor(promptEditor,edit=>{promptRequests.push(edit);void first.editPrompt(edit).then(reply=>{if(reply)promptBridge.receive(reply)});},message=>{if(message)promptProblems.push(message)},0,{request:request=>{nativeCompletionRevision=request.revision;void first.autocompletePrompt(request).then(reply=>{if(reply)promptBridge?.receiveCompletions(reply)})},update:(rows,offerId)=>{completionRows=rows;completionOfferId=offerId}});
 await wait(()=>promptRequests.length===1,'native app draft adoption');
 await new Promise(resolve=>setTimeout(resolve,50));assert.equal(promptEditor.state.doc.textContent,'seed');
 promptEditor.view.dom.dispatchEvent(new dom.window.Event('beforeinput',{bubbles:true}));promptEditor.commands.insertContent('x');
 const settling=promptBridge.settle();let accepted=false;void settling.then(value=>{accepted=value});assert.equal(accepted,false);
 await wait(()=>promptEditor.state.doc.textContent==='SEEDX','native composer rewrite').catch(async error=>{await promptDiagnostic();throw error});
 assert.equal(await settling,true);
 assert.equal(promptEditor.view.dom.querySelector('.claude-prompt-decoration')?.style.fontWeight,'600');assert.equal(promptEditor.state.doc.textContent,'SEEDX');
 assert.equal(promptRequests.at(-1).by,'person');assert.equal(promptEditor.state.selection.head,6);
 promptEditor.view.dom.dispatchEvent(new dom.window.Event('beforeinput',{bubbles:true}));promptEditor.commands.insertContent('a');promptEditor.commands.insertContent('b');
 await wait(()=>promptEditor.state.doc.textContent==='SEEDXAB','latest native composer rewrite').catch(async error=>{await promptDiagnostic();throw error});
 assert.deepEqual(promptProblems,[]);
 await wait(()=>completionRows.some(row=>row.text==="native-token"),'native rows in editor binding');
 assert.equal(promptBridge.selectCompletion(completionRows.findIndex(row=>row.text==="native-token"),completionOfferId),true);
 await wait(()=>promptEditor.state.doc.textContent==="native-token"&&completionRows.length>0,'native token insertion and requery');
 assert.equal(promptRequests.at(-1).by,"app");
 const editRevision=promptBridge.revision;
 const completion=await first.autocompletePrompt({revision:nativeCompletionRevision+1,text:"prefix tok",cursor:10});
 assert.equal(completion.status,"ready");assert.equal(completion.result.start,7);assert.ok(completion.result.suggestions.some(row=>row.text==="native-token"&&row.label==="Native token"));
 const empty=await first.autocompletePrompt({revision:nativeCompletionRevision+2,text:"prefix ",cursor:7});assert.deepEqual(empty.result.suggestions,[]);
 const adoption=await first.editPrompt({revision:editRevision+1,by:"app",text:"history",cursor:7});assert.equal(adoption.frame.text,"history");
 const clearing=await first.editPrompt({revision:editRevision+2,by:"app",text:"",cursor:0});assert.equal(clearing.frame.text,"");
 let changeMissing=false;try{await readFile(join(workspace,"prompt-changes.json"))}catch(error){if(error.code==="ENOENT")changeMissing=true;else throw error}assert.equal(changeMissing,true);
 promptBridge.dispose();promptEditor.destroy();promptBridge=undefined;promptEditor=undefined;dom.window.close();
 const svg=node(0,'svg');assert.ok(svg);assert.equal(svg.alt,'Native diagram');assert.equal(svg.interactive,true);assert.equal(svg.width,40);assert.ok(svg.source.includes('<rect'));
 assert.equal(input.rows,3);assert.equal(code.source,'const fixture = 42;');assert.equal(code.startLine,7);
 const beforeInput=action(last(0));
 assert.deepEqual(await first.field({actionId:input.actionId,revision:1,kind:'change',value:'first\nsecond'}),{handled:true});
 assert.equal(await captured('changed.json'),'first\nsecond');
 await wait(()=>action(last(0))!==beforeInput&&node(0,'input')?.actionId===input.actionId,'keyed input redraw');
 assert.deepEqual(await second.field({actionId:input.actionId,revision:2,kind:'submit',value:'foreign'}),{handled:false});
 assert.deepEqual(await first.field({actionId:input.actionId,revision:2,kind:'submit',value:'first\nsecond'}),{handled:true});
 assert.equal(await captured('submitted.json'),'first\nsecond');
 await wait(()=>node(0,'input')?.value==='Native reset'&&node(0,'input')?.revision===2,'native field replacement');
 assert.equal(node(0,'input').submitLabel,'send');
 assert.deepEqual(await first.field({actionId:select.actionId,revision:1,kind:'select',value:'foreign'}),{handled:false});
 const beforeSelect=action(last(0));
 assert.deepEqual(await first.field({actionId:select.actionId,revision:1,kind:'select',value:'beta'}),{handled:true});
 assert.equal(await captured('selected.json'),'beta');
 await wait(()=>action(last(0))!==beforeSelect&&!!node(0,'markdown')?.actionId,'Markdown authority');
 const link=node(0,'markdown').actionId;
 assert.deepEqual(await first.press(link,'https://foreign.example/'),{handled:false});
 assert.deepEqual(await first.press(link,'https://example.com/'),{handled:true});
 const linkValue=await captured('link.json');assert.ok(JSON.stringify(linkValue).includes('https://example.com/'));
 await wait(()=>!!action(last(0))&&node(0,'markdown')?.actionId!==link,'controls after link');
 const old=action(last(0));assert.ok(old);
 assert.deepEqual(await second.press(old),{handled:false});
 assert.deepEqual(await first.press(old),{handled:true});
 await wait(()=>count(0,1)&&count(1,1),'both invalidated views');
 assert.deepEqual(await first.press(old),{handled:false});
 assert.equal(await readFile(join(workspace,'pressed.txt'),'utf8'),'1');
 assert.deepEqual(await second.press(action(last(1))),{handled:true});
 await wait(()=>count(0,2)&&count(1,2),'second view press');
 await first.dispose();assert.equal(last(0).status,'disconnected');
 assert.deepEqual(await second.press(action(last(1))),{handled:true});
 await wait(()=>count(1,3),'surviving view');
 const third=mount(2);await third.ready;await wait(()=>count(2,3),'remounted view');
 assert.deepEqual(await third.press(old),{handled:false});
 const beforeExit=action(last(2));owner.kill();await owner.done;
 await wait(()=>last(1)?.status==='disconnected'&&last(2)?.status==='disconnected','process exit');
 assert.deepEqual(await third.press(beforeExit),{handled:false});
 await Promise.all(views.map(view=>view.dispose().catch(()=>{})));
 assert.equal(turns,2);assert.equal(model.calls.length,1);
 console.log(JSON.stringify({evidence:'apack-native-ui-mount',targetSha256:hash(await readFile(executable)),pluginSourceSha256:hash(Buffer.from(pluginSource)),concurrentViews:true,multilineInputRoundTrip:true,nativeFieldSubmit:true,nativeFieldReplacement:true,completedFieldRevision:true,submitLabelPreserved:true,nativeSelectRoundTrip:true,foreignFieldRefused:true,invalidOptionRefused:true,markdownLinkRoundTrip:true,foreignLinkRefused:true,codeTreeMapped:true,svgTreeMapped:true,buttonInlineContentMapped:true,buttonPresentationMapped:true,textColorsMapped:true,boxPaintMapped:true,hoverContractsMapped:true,nativePromptHostRead:true,nativePromptHostFill:true,reversePromptNoTurn:true,mountedFocusRedirect:true,mountedForeignFocusRefused:true,nativeFocusRedirect:true,nativeFocusHold:true,nativePluginFocusPush:true,canonicalFocusSite:true,buttonHotkeyMapped:true,nestedTextStylesMapped:true,nativeLinkMapped:true,boxLayoutMapped:true,nativeEditorPromptRewrite:true,latestEditorRewritePreserved:true,nativePromptDecorationRendered:true,nativeEditSettledBeforeCapture:true,nativeCompletionInserted:true,nativeCompletionRequery:true,nativeAutocompleteRows:true,nativeAutocompleteTokenRange:true,emptyTokenNoRows:true,appAdoptionDoesNotRaiseChange:true,nativeSubmitRewrite:true,nativeSubmitContext:true,nativeSubmitDrop:true,foreignActionRefused:true,nativePresses:3,invalidationRedraw:true,staleActionRefused:true,independentDetach:true,remount:true,exitDisconnected:true,hostTurns:turns,syntheticApiRequests:model.calls.length,realModelRequests:0,userPromptsSent:2}));
}finally{promptBridge?.dispose();promptEditor?.destroy();try{await Promise.all(views.map(view=>view.dispose().catch(()=>{})));if(owner){owner.kill();await owner.close().catch(()=>{})}else if(native){native.kill();await native.close().catch(()=>{})}}finally{await model.close()}}
