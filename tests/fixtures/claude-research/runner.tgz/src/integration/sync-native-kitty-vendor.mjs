import {readFile,writeFile,mkdir,stat} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';

const commit='45eb443009edc506e8be8308fa9007740f4bb451';
const files=['overlay.ts','protocol.ts','xterm-adapter.ts','placeholders.ts','placeholder-glyph.ts','placeholder-font.ts','index.ts'];
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
function patchDecodeLifetime(source){
 const changes=[
  ['private readonly decoding = new Set<number>();','private readonly decoding = new Set<number>();\n  private readonly decodeTokens = new Map<number, object>();'],
  ['this.decoding.add(imageId);','const token = {}; this.decodeTokens.set(imageId, token);\n    this.decoding.add(imageId);'],
  ['this.decodeAndStore(imageId, params, fullB64).then(','this.decodeAndStore(imageId, params, fullB64, token).then('],
  ['      () => {\n        this.decoding.delete(imageId);','      () => {\n        if (this.disposed || this.decodeTokens.get(imageId) !== token) return;\n        this.decoding.delete(imageId);'],
  ['      (error) => {\n        this.decoding.delete(imageId);','      (error) => {\n        if (this.disposed || this.decodeTokens.get(imageId) !== token) return;\n        this.decoding.delete(imageId);'],
  ['    b64: string,\n  ): Promise<void> {','    b64: string,\n    token: object,\n  ): Promise<void> {'],
  ['    if (this.disposed) {\n      this.closeBitmap(bitmap);','    if (this.disposed || this.decodeTokens.get(imageId) !== token) {\n      this.closeBitmap(bitmap);'],
  ['this.images.clear();','this.images.clear(); this.decodeTokens.clear(); this.decoding.clear();',2],
  ['this.images.delete(id);','this.images.delete(id); this.decodeTokens.delete(id); this.decoding.delete(id); this.deferredPlacements.delete(id);',2]
 ];
 for(const[before,after,count=1]of changes){if(source.split(before).length!==count+1)throw Error('Reviewed decode patch anchor changed: '+before);source=source.replaceAll(before,after)}
 return source;
}
/** Copy only the pinned MIT graphics module, with deterministic import adaptation and edit protection. */
export async function syncNativeKittyVendor(upstream,checkout,fitTarball){
 upstream=resolve(upstream);checkout=resolve(checkout);
 if(execFileSync('git',['rev-parse','HEAD'],{cwd:upstream,encoding:'utf8'}).trim()!==commit)throw Error('Supply the reviewed pinned Webterm checkout');
 if(!(await stat(join(checkout,'.git'))).isFile())throw Error('Supply the isolated linked product worktree');
 const target=join(checkout,'packages/default-setup/src/features/threads/fe/chat/vendor/webterm-kitty');
 let previous;try{previous=JSON.parse(await readFile(join(target,'provenance.json'),'utf8'))}catch(error){if(error.code!=='ENOENT')throw error}
 const entries=[];
 for(const name of files){
  const original=await readFile(join(upstream,'src/kitty',name));
  let adapted=original.toString().replaceAll("from '@xterm/xterm'","from '@app/claude-terminal-xterm'").replaceAll("from '../types.js'","from './options.ts'").replace(/(from\s+'\.\/[^']+)\.js'/g,"$1.ts'");
  if(name==='overlay.ts'){const before='this.dropPlacements(() => true);\n          this.clearVirtual();';if(adapted.split(before).length!==2)throw Error('Reviewed screen-clear patch anchor changed');adapted=patchDecodeLifetime(adapted.replace(before,'this.dropPlacements(() => true);\n          // Unicode virtual placements are prototypes, not visible screen placements.\n          this.scheduleScan();'));}
  entries.push({name,upstream:'src/kitty/'+name,original,adapted});
 }
 const types=await readFile(join(upstream,'src/types.ts'),'utf8');
 const options=types.match(/export interface KittyOptions \{[\s\S]*?\n\}/)?.[0];if(!options)throw Error('Original KittyOptions interface changed');
 entries.push({name:'options.ts',upstream:'src/types.ts#KittyOptions',original:Buffer.from(options),adapted:options+'\n'});
 const xterm=join(checkout,'node_modules/@app/claude-terminal-xterm');
 const xtermPackage=JSON.parse(await readFile(join(xterm,'package.json'),'utf8'));
 if(xtermPackage.name!=='@xterm/xterm'||xtermPackage.version!=='6.1.0-beta.290')throw Error('Install the reviewed isolated xterm pin first');
 const declarations=await readFile(join(xterm,'typings/xterm.d.ts'));
 entries.push({name:'xterm.d.ts',upstream:'@xterm/xterm@6.1.0-beta.290/typings/xterm.d.ts',original:declarations,adapted:declarations.toString().replace("declare module '@xterm/xterm'","declare module '@app/claude-terminal-xterm'")});
 const xtermLicense=await readFile(join(xterm,'LICENSE'));entries.push({name:'XTERM-LICENSE',upstream:'@xterm/xterm@6.1.0-beta.290/LICENSE',original:xtermLicense,adapted:xtermLicense});
 const fitBytes=await readFile(fitTarball),fitIntegrity='sha512-mJ77s82VhARA8XhuWcUnWYKAZkEDzSnCzgBrT9qjHJlHWr+G5duDZcOBnxnVVNtp21LDKaONr3c7IxuLii1XNg==';
 if('sha512-'+createHash('sha512').update(fitBytes).digest('base64')!==fitIntegrity)throw Error('Supply the reviewed matching sizing addon tarball');
 const fitSource=execFileSync('tar',['-xOf',resolve(fitTarball),'package/src/FitAddon.ts']);
 const fitAdapted=fitSource.toString().replace("from '@xterm/xterm'","from '@app/claude-terminal-xterm'").replace("import type { FitAddon as IFitApi } from '@xterm/addon-fit';\n",'').replace("import { ViewportConstants } from 'browser/shared/Constants';",'// Same default as the published addon bundle; the monorepo-only constants import is absent.\nconst DEFAULT_SCROLL_BAR_WIDTH = 14;').replace('ITerminalAddon, IFitApi','ITerminalAddon').replace('ViewportConstants.DEFAULT_SCROLL_BAR_WIDTH','DEFAULT_SCROLL_BAR_WIDTH');
 entries.push({name:'fit.ts',upstream:'@xterm/addon-fit@0.12.0-beta.290/src/FitAddon.ts',original:fitSource,adapted:fitAdapted});
 const fitLicense=execFileSync('tar',['-xOf',resolve(fitTarball),'package/LICENSE']);entries.push({name:'FIT-LICENSE',upstream:'@xterm/addon-fit@0.12.0-beta.290/LICENSE',original:fitLicense,adapted:fitLicense});
 const license=await readFile(join(upstream,'LICENSE'));entries.push({name:'LICENSE',upstream:'LICENSE',original:license,adapted:license});
 await mkdir(target,{recursive:true});
 for(const entry of entries){
  let current;try{current=await readFile(join(target,entry.name))}catch(error){if(error.code!=='ENOENT')throw error}
  if(current&&hash(current)!==hash(entry.adapted)&&hash(current)!==previous?.files.find(file=>file.name===entry.name)?.adaptedSha256)throw Error('Preserve/review local vendor edits before updating '+entry.name);
 }
 for(const entry of entries)await writeFile(join(target,entry.name),entry.adapted);
 const provenance={repository:'https://github.com/Gaurav-Gosain/webterm',commit,license:'MIT',fit:{version:'0.12.0-beta.290',integrity:fitIntegrity},adaptations:['Only the standalone Kitty graphics module is included.','Imports use explicit .ts paths and the isolated APC-capable Claude terminal xterm dependency.','KittyOptions is copied from the upstream interface without unrelated terminal types.','Pinned xterm ambient declarations use the npm alias module name; no API types are changed.','Per-image decode tokens prevent older asynchronous PNG/RGBA decodes from replacing later transmissions or reviving deleted/reset/evicted images.','Screen erase clears physical placements and placeholder cells but retains Unicode virtual prototypes, as required for native resize redraws.','Matching MIT FitAddon source uses the isolated terminal type and the published bundle default scrollbar width (14); its redundant package API interface is omitted.'],files:entries.map(entry=>({name:entry.name,upstream:entry.upstream,originalSha256:hash(entry.original),adaptedSha256:hash(entry.adapted)}))};
 await writeFile(join(target,'provenance.json'),JSON.stringify(provenance,null,2)+'\n');
 await writeFile(join(target,'README.md'),'# Webterm Kitty graphics\n\nMIT source from https://github.com/Gaurav-Gosain/webterm at '+commit+'.\nOnly the standalone graphics module is included; LICENSE and exact source/adaptation digests are adjacent.\n\nRefresh through the research repository’s `src/integration/sync-native-kitty-vendor.mjs` with the pinned upstream checkout, isolated product worktree and integrity-checked matching FitAddon tarball. The reviewed screen-erase patch preserves virtual prototypes while visible placeholder cells still clear. It refuses modified local vendor files. Review a new upstream pin explicitly; never edit this copy to hide a native protocol failure.\n');
 return {target,commit,files:entries.length};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){if(process.argv.length!==5)throw Error('Usage: sync-native-kitty-vendor.mjs <pinned-upstream> <isolated-product-worktree> <pinned-fit-tarball>');console.log(JSON.stringify(await syncNativeKittyVendor(process.argv[2],process.argv[3],process.argv[4])))}
