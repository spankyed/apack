// Focused source-process diagnostics; this does not initialize or validate a pack runtime.
import {createRequire} from 'node:module';
import {join,isAbsolute} from 'node:path';
import {pathToFileURL} from 'node:url';
const appRoot=process.env.CLAUDE_RESEARCH_APACK_ROOT;
if(!appRoot||!isAbsolute(appRoot))throw Error('Set CLAUDE_RESEARCH_APACK_ROOT to the isolated apack checkout');
const require=createRequire(join(appRoot,'package.json'));
const {defineConfig}=await import(pathToFileURL(require.resolve('vitest/config')).href);
export default defineConfig({
 root:join(appRoot,'packages/default-setup'),
 resolve:{alias:{'#features':join(appRoot,'packages/default-setup/src/features')}},
 test:{globals:true,setupFiles:[],include:['tests/features/code/be/services/claude-code/runner-once.spec.ts']},
});
