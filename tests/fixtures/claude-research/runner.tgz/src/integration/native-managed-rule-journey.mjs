import assert from 'node:assert/strict';
import {lstat,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {join} from 'node:path';

const policyFile='/etc/claude-code/managed-settings.json';
const fileText=['Private checklist for the release review.', 'Managed checklist for the release review.'];

export function managedRuleReads(project, live=false) {
 if(live) return [
  {prompt:'Read the private checklist after the policy was relaxed.',file:join(project,'private-checklist.md')},
  {prompt:'Read the updated private checklist after policy was restored.',file:join(project,'revised-private-checklist.md')},
 ];
 return [
  {prompt:'Read the private checklist for the release review.',file:join(project,'private-checklist.md')},
  {prompt:'Read the managed checklist for the release review.',file:join(project,'managed-checklist.md')},
 ];
}

export async function validateManagedRulePolicy(project, managedOnly=true) {
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
 assert.ok(boundary.requireManagedRuleSources && boundary.networkDisabled && boundary.pinnedExecutableReadOnly);
 const mountLines=(await readFile('/proc/self/mountinfo','utf8')).split('\n');
 assert.ok(mountLines.some(line=>line.split(' ')[4]==='/etc/claude-code'&&line.includes(' - tmpfs ')));
 const info=await lstat(policyFile);
 assert.ok(info.isFile()&&info.uid===0&&(info.mode&0o777)===0o644);
 const data=await readFile(policyFile);
 const policy=JSON.parse(data);
 assert.deepEqual(policy,{...(managedOnly?{allowManagedPermissionRulesOnly:true}:{}),permissions:{ask:['Read(/'+managedRuleReads(project)[1].file+')']}});
 return {sha256:createHash('sha256').update(data).digest('hex'),policy};
}

export async function driveManagedRuleSources({page,expect,context,composer,send,section,replace,proof,output,model,birth,save,phase,project}) {
 const reads=managedRuleReads(project);
 const beforePolicy=await validateManagedRulePolicy(project);
 const approval=page.getByTestId('native-read-approval');
 const result=index=>model.calls.find(call=>call.brokerApprovalResult?.tool_use_id==='native_broker_approval_'+(index+1))?.brokerApprovalResult;
 const sameOwner=async()=>{
  const current=await context();
  assert.equal(current.claude.sessionId,proof.sessionId);
  assert.equal(current.native.state.nativePid,proof.pid);
  assert.equal(await birth(proof.pid),proof.processStart);
  return current;
 };
 const evidence=proof.managedRuleSources={policy:beforePolicy,reads:[],captures:[]};
 proof.scope='One Linux OS-managed file admits only managed permission rules. A private ask rule is ignored, and the managed file-specific ask still requires a desktop answer.';
 await replace(reads[0].prompt);
 await send.click();
 await expect.poll(async()=>await approval.isVisible()?'prompt':result(0)?'result':null,{timeout:15000}).toBe('result');
 assert.notEqual(result(0).is_error,true);
 assert.ok(JSON.stringify(result(0).content).includes(fileText[0]));
 await expect.poll(async()=>(await sameOwner()).native.state.busy,{timeout:15000}).toBe(false);
 evidence.reads.push({source:'private',prompted:false,result:result(0)});
 await save();

 await replace(reads[1].prompt);
 await send.click();
 await expect(approval).toBeVisible({timeout:15000});
 await expect(approval.getByTestId('native-read-path')).toHaveText(reads[1].file);
 assert.equal(result(1),undefined);
 const approve=approval.getByRole('button',{name:'Approve',exact:true});
 for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
  await page.setViewportSize(viewport);
  await expect(approve).toBeInViewport({ratio:1});
  const capture='managed-read-approval-'+size+'.png';
  await page.screenshot({path:join(output,capture),animations:'disabled'});
  evidence.captures.push(capture);
 }
 await approve.click();
 await expect(approval).toBeHidden();
 await expect.poll(()=>result(1),{timeout:15000}).toBeTruthy();
 assert.notEqual(result(1).is_error,true);
 assert.ok(JSON.stringify(result(1).content).includes(fileText[1]));
 await expect.poll(async()=>(await sameOwner()).native.state.busy,{timeout:15000}).toBe(false);
 evidence.reads.push({source:'managed',prompted:true,result:result(1)});
 assert.deepEqual(await validateManagedRulePolicy(project),beforePolicy);
 await replace('Keep the release notes ready for the next review.');
 await expect(send).toBeEnabled();
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await section.getByRole('button',{name:'Stop session',exact:true}).click();
 await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
 proof.stopped=true;
 proof.status='complete';
 await save();
 phase('managed-rule-sources-complete');
}

export async function driveManagedRuleCatalog({page,expect,context,composer,send,section,replace,proof,output,model,birth,save,phase,project}) {
 const beforePolicy=await validateManagedRulePolicy(project);
 const beforeCalls=model.calls.length;
 const evidence=proof.managedRuleCatalog={policy:beforePolicy,captures:[]};
 proof.scope='The desktop original /permissions Ask list and read-only managed rule detail with the managed-only policy loaded. No rule mutations.';
 const panel=page.getByRole('dialog',{name:'Claude Code permissions',exact:true});
 await replace('/permissions');
 await send.click();
 await expect(panel).toBeVisible({timeout:15000});
 const ask=panel.getByRole('tab',{name:'Ask',exact:true});
 await ask.click();
 await expect(ask).toHaveAttribute('aria-selected','true');
 const choices=panel.getByRole('group',{name:'Permission choices',exact:true});
 const managed=choices.getByRole('button',{name:/managed-checklist\.md/});
 const privateRule=choices.getByRole('button',{name:'Read',exact:true});
 await expect(managed).toBeVisible({timeout:10000});
 await expect(privateRule).toHaveCount(0);
 evidence.effectiveRules=await choices.getByRole('button').allTextContents();
 await capture('list',managed);
 await managed.click();
 const notice=panel.getByText(/This rule is configured by managed settings and cannot be modified\./);
 await expect(notice).toBeVisible({timeout:10000});
 evidence.managedRuleNotice=await notice.innerText();
 await capture('detail',notice);
 await panel.getByRole('button',{name:'Back',exact:true}).click();
 await expect(managed).toBeVisible();
 await panel.getByRole('button',{name:'Close permissions',exact:true}).click();
 await expect(panel).toBeHidden();
 assert.equal(model.calls.length,beforeCalls,'Native permission inspection must not query the provider');
 const current=await context();
 assert.equal(current.claude.sessionId,proof.sessionId);
 assert.equal(current.native.state.nativePid,proof.pid);
 assert.deepEqual(await validateManagedRulePolicy(project),beforePolicy);
 await replace('Keep the release notes ready for the next review.');
 await expect(composer).toBeEditable();
 await expect(send).toBeEnabled();
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await section.getByRole('button',{name:'Stop session',exact:true}).click();
 await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
 proof.stopped=true;
 proof.status='complete';
 await save();
 phase('managed-rule-catalog-complete');

 async function capture(stage,control) {
  for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(viewport);
   await control.scrollIntoViewIfNeeded();
   await expect(control).toBeInViewport({ratio:1});
   const file='managed-ask-'+stage+'-'+size+'.png';
   await page.screenshot({path:join(output,file),animations:'disabled'});
   evidence.captures.push(file);
  }
  await save();
 }
}

export async function driveLiveManagedRuleSources({page,expect,context,composer,send,section,replace,proof,output,model,birth,save,phase,project,control}) {
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
 assert.ok(boundary.requireLiveManagedRuleSources);
 assert.match(control,/^\/work\/\.claude-research\/policy-transition-rule-sources[0-9]+$/);
 const initial=await validateManagedRulePolicy(project);
 const evidence=proof.liveManagedRuleSources={initial,transitions:[],captures:[]};
 proof.scope='Same native Linux session follows policy file changes in both directions. The effective Ask list and actual Read outcomes move together.';
 const panel=page.getByRole('dialog',{name:'Claude Code permissions',exact:true});
 const ask=panel.getByRole('tab',{name:'Ask',exact:true});
 const choices=panel.getByRole('group',{name:'Permission choices',exact:true});
 const privateRule=choices.getByRole('button',{name:'Read',exact:true});
 const managedRule=choices.getByRole('button',{name:/managed-checklist\.md/});
 const approval=page.getByTestId('native-read-approval');
 const sameOwner=async()=>{
  const current=await context();
  assert.equal(current.claude.sessionId,proof.sessionId);
  assert.equal(current.native.state.nativePid,proof.pid);
  assert.equal(await birth(proof.pid),proof.processStart);
  return current;
 };
 const readyPath=join(control,'ready.json');
 assert.equal((await lstat(readyPath)).uid,0);
 const ready=JSON.parse(await readFile(readyPath,'utf8'));
 assert.equal(ready.profile,'managed-rule-sources');
 assert.equal(ready.initialSha256,initial.sha256);
 evidence.ready=ready;
 const reads=managedRuleReads(project,true);
 for(const [index,mode] of ['private-rules-enabled','managed-only'].entries()){
  const sequence=index+1;
  const managedOnly=mode==='managed-only';
  const read=reads[index];
  const row={sequence,mode};
  evidence.transitions.push(row);
  await writeFile(join(control,'request-'+sequence+'.json'),JSON.stringify({sequence,mode}),{flag:'wx',mode:0o600});
  const receiptPath=join(control,'receipt-'+sequence+'.json');
  await expect.poll(()=>lstat(receiptPath).then(info=>info.uid===0,()=>false),{timeout:10000}).toBe(true);
  row.receipt=JSON.parse(await readFile(receiptPath,'utf8'));
  assert.equal(row.receipt.sha256,(await validateManagedRulePolicy(project,managedOnly)).sha256);
  assert.equal(row.receipt.sequence,sequence);
  assert.equal(row.receipt.mode,mode);
  await save();

  const requestsBefore=model.calls.length;
  let observed=false;
  for(let attempt=0;attempt<3&&!observed;attempt++){
   await replace('/permissions');
   await send.click();
   await expect(panel).toBeVisible({timeout:15000});
   await ask.click();
   await expect(managedRule).toBeVisible({timeout:10000});
   observed=await expect.poll(async()=>!!await privateRule.count(),{timeout:4000}).toBe(!managedOnly).then(()=>true,()=>false);
   if(observed){
    row.effectiveRules=await choices.getByRole('button').allTextContents();
    for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
     await page.setViewportSize(viewport);
     const control=managedOnly?managedRule:privateRule;
     await control.scrollIntoViewIfNeeded();
     await expect(control).toBeInViewport({ratio:1});
     const file='live-managed-rules-'+mode+'-'+size+'.png';
     await page.screenshot({path:join(output,file),animations:'disabled'});
     evidence.captures.push(file);
    }
   }
   await panel.getByRole('button',{name:'Close permissions',exact:true}).click();
   await expect(panel).toBeHidden();
  }
  assert.ok(observed,'The original Ask rule list did not reach the expected policy state');
  assert.equal(model.calls.length,requestsBefore);
  await sameOwner();
  await save();

  await replace(read.prompt);
  await send.click();
  const toolUseId='native_broker_approval_'+sequence;
  const result=()=>model.calls.find(call=>call.brokerApprovalResult?.tool_use_id===toolUseId)?.brokerApprovalResult;
  const expectedOutcome=managedOnly?'result':'prompt';
  await expect.poll(async()=>await approval.isVisible()?'prompt':result()?'result':null,{timeout:15000}).toBe(expectedOutcome);
  if(!managedOnly){
   await expect(approval.getByTestId('native-read-path')).toHaveText(read.file);
   assert.equal(result(),undefined);
   await approval.getByRole('button',{name:'Approve',exact:true}).click();
   await expect(approval).toBeHidden();
  }
  await expect.poll(result,{timeout:15000}).toBeTruthy();
  assert.notEqual(result().is_error,true);
  const expectedText=managedOnly?'Revised private checklist for the release review.':fileText[0];
  assert.ok(JSON.stringify(result().content).includes(expectedText));
  await expect.poll(async()=>(await sameOwner()).native.state.busy,{timeout:15000}).toBe(false);
  row.read={prompted:!managedOnly,result:result()};
  await save();
 }

 await replace('Keep the release notes ready for the next review.');
 await expect(composer).toBeEditable();
 await expect(send).toBeEnabled();
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await section.getByRole('button',{name:'Stop session',exact:true}).click();
 await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
 proof.stopped=true;
 proof.status='complete';
 await save();
 phase('live-managed-rule-sources-complete');
}

export async function driveMountedManagedRuleRefresh({page,expect,context,composer,send,section,replace,proof,output,model,birth,save,phase,project,control,heldManagedRuleEdit=false,heldManagedRuleAddition=false}) {
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
 assert.ok(boundary.requireMountedManagedRuleRefresh);
 assert.equal(boundary.requireHeldManagedRuleEdit===true,heldManagedRuleEdit);
 assert.equal(boundary.requireHeldManagedRuleAddition===true,heldManagedRuleAddition);
 assert.match(control,/^\/work\/\.claude-research\/policy-transition-rule-sources[0-9]+$/);
 const initial=await validateManagedRulePolicy(project);
 const ready=join(control,'ready.json');
 assert.equal((await lstat(ready)).uid,0);
 assert.equal(JSON.parse(await readFile(ready,'utf8')).initialSha256,initial.sha256);
 const evidence=proof.mountedManagedRuleRefresh={initial,transitions:[],captures:[]};
 const ownSettings=join(project,'..','.claude','settings.json');
 const beforeBytes=heldManagedRuleEdit?await readFile(ownSettings):undefined;
 const watcher=join(project,'..','held-rule-debug-'+proof.pid+'.log');
 const notice='Detected change to '+policyFile;
 const watchEvents=async()=>(await readFile(watcher,'utf8').catch(error=>error.code==='ENOENT'?'':Promise.reject(error))).split('\n').filter(line=>line.includes(notice));
 const stagedRule='Read(held-release-note.md)';
 const confirm=panel=>panel.getByRole('button',{name:'Yes',exact:true});
 proof.scope='Original Linux Permissions stays mounted during two in-place system policy changes. Observe automatic updates and verify the existing Refresh action when needed.';
 const panel=page.getByRole('dialog',{name:'Claude Code permissions',exact:true});
 const ask=panel.getByRole('tab',{name:'Ask',exact:true});
 const choices=panel.getByRole('group',{name:'Permission choices',exact:true});
 const privateRule=choices.getByRole('button',{name:'Read',exact:true});
 const managedRule=choices.getByRole('button',{name:/managed-checklist\.md/});
 const refresh=panel.getByRole('button',{name:'Refresh',exact:true});
 const requestsBefore=model.calls.length;
 await replace('/permissions');
 await send.click();
 await expect(panel).toBeVisible({timeout:15000});
 await ask.click();
 await expect(ask).toHaveAttribute('aria-selected','true');
 await expect(managedRule).toBeVisible();
 await expect(privateRule).toHaveCount(0);
 const mounted=await panel.elementHandle();
 assert.ok(mounted);
 const original=await context();
 assert.equal(original.claude.sessionId,proof.sessionId);
 assert.equal(original.native.state.nativePid,proof.pid);

 const modes=['private-rules-enabled','managed-only'];
 if(heldManagedRuleAddition)modes.push('private-rules-enabled');
 for(const [index,mode] of modes.entries()){
  const sequence=index+1;
  const managedOnly=mode==='managed-only';
  const expected=managedOnly?0:1;
  const row={sequence,mode};
  evidence.transitions.push(row);
  await writeFile(join(control,'request-'+sequence+'.json'),JSON.stringify({sequence,mode}),{flag:'wx',mode:0o600});
  const receiptPath=join(control,'receipt-'+sequence+'.json');
  await expect.poll(()=>lstat(receiptPath).then(info=>info.uid===0,()=>false),{timeout:10000}).toBe(true);
  row.receipt=JSON.parse(await readFile(receiptPath,'utf8'));
  assert.equal(row.receipt.sha256,(await validateManagedRulePolicy(project,managedOnly)).sha256);
  assert.equal(row.receipt.sequence,sequence);
  assert.equal(row.receipt.mode,mode);

  if(heldManagedRuleEdit&&managedOnly){
   const held=evidence.heldDelete;
   const yes=confirm(panel);
   // Probe a potentially still-actionable confirmation only after Claude has applied the policy.
   await expect.poll(async()=>(await watchEvents()).length,{timeout:10000}).toBeGreaterThan(held.watcherEventsBefore);
   held.watcherEvent=(await watchEvents()).at(-1);
   if(await yes.isVisible()){
    await refresh.click();
    await expect(refresh).toBeEnabled({timeout:10000});
   }
   held.stillVisible=await yes.isVisible();
   if(held.stillVisible){
    await expect(yes).toBeDisabled();
    const policyNotice=panel.getByText('Managed policy changed. Go back to review the available rules.',{exact:true});
    await expect(policyNotice).toBeVisible();
    held.disabled=true;
    held.notice=await policyNotice.innerText();
    for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
     await page.setViewportSize(viewport);
     await policyNotice.scrollIntoViewIfNeeded();
     await expect(policyNotice).toBeInViewport({ratio:1});
     const file='held-private-rule-blocked-'+size+'.png';
     await page.screenshot({path:join(output,file),animations:'disabled'});
     evidence.captures.push(file);
    }
   }
   await save();
   assert.deepEqual(await readFile(ownSettings),beforeBytes,'A held private rule must not be deleted after restriction');
   if(await yes.isVisible()){
    const back=panel.getByRole('button',{name:'No',exact:true});
    await expect(back).toBeEnabled();
    await back.click();
    await expect(back).toHaveCount(0);
    held.cancelReturnedToRules=true;
   }
  }
  if(heldManagedRuleAddition&&managedOnly){
   const held=evidence.heldAddition;
   await expect.poll(async()=>(await watchEvents()).length,{timeout:10000}).toBeGreaterThan(held.watcherEventsBefore);
   held.watcherEvent=(await watchEvents()).at(-1);
   const destination=panel.getByRole('button',{name:/^User settings/});
   await expect(destination).toBeVisible();
   await refresh.click();
   await expect(destination).toBeDisabled();
   const notice=panel.getByText('Managed policy changed. Go back to review the available rules.',{exact:true});
   await expect(notice).toBeVisible();
   held.refused=true;
   const file='held-rule-addition-retired-compact.png';
   await page.screenshot({path:join(output,file),animations:'disabled'});
   evidence.captures.push(file);
   assert.deepEqual(JSON.parse(await readFile(ownSettings,'utf8')).permissions.ask,['Read']);
   await panel.getByRole('button',{name:'Back',exact:true}).click();
   await expect(ask).toHaveAttribute('aria-selected','true');
   held.returnedToRules=true;
  }
  row.automatic=await expect.poll(()=>privateRule.count(),{timeout:6000}).toBe(expected).then(()=>true,()=>false);
  await refresh.click();
  await expect(privateRule).toHaveCount(expected,{timeout:10000});
  await expect(managedRule).toBeVisible();
  await expect(ask).toHaveAttribute('aria-selected','true');
  row.samePanel=await panel.evaluate((current,prior)=>current===prior,mounted);
  assert.ok(row.samePanel);
  row.effectiveRules=await choices.getByRole('button').allTextContents();
  if(heldManagedRuleAddition){
   const staged=choices.getByRole('button',{name:stagedRule,exact:true});
   await expect(staged).toHaveCount(0,{timeout:10000});
   row.stagedRuleEffective=false;
   if(sequence===3){
    await panel.getByRole('button',{name:/^Add a new rule/}).click();
    const input=panel.getByPlaceholder(/^Enter permission rule/);
    await input.fill(stagedRule);
    await panel.getByRole('button',{name:'Continue',exact:true}).click();
    const destination=panel.getByRole('button',{name:/^User settings/});
    await expect(destination).toBeEnabled();
    await destination.click();
    await expect.poll(async()=>JSON.parse(await readFile(ownSettings,'utf8')).permissions.ask,{timeout:10000}).toEqual(['Read',stagedRule]);
    await expect(staged).toBeVisible({timeout:10000});
    row.effectiveRules=await choices.getByRole('button').allTextContents();
    row.stagedRuleEffective=true;
    evidence.heldAddition.savedAfterRestore=true;
   }
  }
  await save();

  for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(viewport);
   const rule=managedOnly?managedRule:privateRule;
   await rule.scrollIntoViewIfNeeded();
   await expect(rule).toBeInViewport({ratio:1});
   await expect(refresh).toBeInViewport({ratio:1});
   const file=(heldManagedRuleAddition?'held-rule-addition-'+sequence:'mounted-managed-rules-'+mode)+'-'+size+'.png';
   await page.screenshot({path:join(output,file),animations:'disabled'});
   evidence.captures.push(file);
  }
  if(heldManagedRuleAddition&&sequence===1){
   await panel.getByRole('button',{name:/^Add a new rule/}).click();
   const ruleInput=panel.getByPlaceholder(/^Enter permission rule/);
   await ruleInput.fill(stagedRule);
   await panel.getByRole('button',{name:'Continue',exact:true}).click();
   await expect(panel.getByRole('button',{name:/^User settings/})).toBeVisible();
   evidence.heldAddition={rule:stagedRule,heldBeforePolicy:true,watcherEventsBefore:(await watchEvents()).length};
   const file='held-rule-addition-destination-compact.png';
   await page.screenshot({path:join(output,file),animations:'disabled'});
   evidence.captures.push(file);
   await save();
  }
  if(heldManagedRuleEdit&&!managedOnly){
   await privateRule.click();
   await expect(panel).toContainText('Are you sure you want to delete this permission rule?');
   await expect(confirm(panel)).toBeEnabled();
   assert.deepEqual(await readFile(ownSettings),beforeBytes);
   const file='held-private-rule-confirmation-compact.png';
   await page.screenshot({path:join(output,file),animations:'disabled'});
   evidence.captures.push(file);
   evidence.heldDelete={opened:true,attempted:false,watcherEventsBefore:(await watchEvents()).length};
   await save();
  }
 }

 if(heldManagedRuleEdit){
  assert.deepEqual(await readFile(ownSettings),beforeBytes);
  evidence.heldDelete.userSettingsUntouched=true;
 }
 assert.equal(model.calls.length,requestsBefore);
 const after=await context();
 assert.equal(after.claude.sessionId,proof.sessionId);
 assert.equal(after.native.state.nativePid,proof.pid);
 assert.equal(after.claude.turns,original.claude.turns);
 assert.equal(after.claude.totalCostUsd,original.claude.totalCostUsd);
 assert.equal(await birth(proof.pid),proof.processStart);
 await panel.getByRole('button',{name:'Close permissions',exact:true}).click();
 await expect(panel).toBeHidden();
 await replace('Keep the release notes ready for the next review.');
 await expect(composer).toBeEditable();
 await expect(send).toBeEnabled();
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await section.getByRole('button',{name:'Stop session',exact:true}).click();
 await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
 proof.stopped=true;
 proof.status='complete';
 await save();
 phase('mounted-managed-rule-refresh-complete');
}
