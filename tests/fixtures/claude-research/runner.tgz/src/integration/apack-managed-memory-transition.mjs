import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

export async function driveManagedMemoryTransition({page,electronApp,expect,context,composer,send,section,replace,proof,output,workspace,model,birth,save,phase,autoRefreshMemoryPolicy=false,memoryPolicyPopout=false}) {
  const panel=page.getByRole('dialog',{name:'Claude memory',exact:true});
  const caption=page.getByTestId('composer-native-status');
  const turnOff=panel.getByRole('button',{name:'Turn Auto-memory off',exact:true});
  const locked=panel.getByRole('button',{name:'Turn Auto-memory on',exact:true});
  const status=panel.getByRole('status');
  const refresh=panel.getByRole('button',{name:'Refresh',exact:true});
  const settings=join(workspace,'.claude/settings.json');
  const settingsBefore=await readFile(settings);
  const requestsBefore=model.calls.length;
  const draft='Keep the release checklist draft while memory policy changes.';
  const continuation='Continue reviewing the release checklist after the policy update.';
  proof.scope='Managed Auto-memory activation and rollback while Claude memory is already open.';
  const evidence=proof.memoryPolicy={draft,continuation,autoRefreshMemoryPolicy,stages:[]};
  let popout;
  const otherDraft='Keep the separate popout notes on the release checklist.';
  const card=target=>target.locator('[data-onboarding-id="agent-chat-input"]');
  const focus=async target=>{
    const window=await electronApp.browserWindow(target);
    await window.evaluate(window=>{window.show();window.focus();});
    await expect.poll(()=>target.evaluate(()=>document.hasFocus())).toBe(true);
  };
  const openMemory=async target=>{
    const memory=target.getByRole('button',{name:'Claude memory',exact:true});
    if(await memory.isVisible())await memory.click();
    else {
      await target.getByRole('button',{name:'More actions',exact:true}).click();
      await target.getByRole('menuitem',{name:'Claude memory',exact:true}).click();
    }
  };
  const capture=async (name,target=page)=>{
    const file='managed-memory-'+name+'.png';
    await target.screenshot({path:join(output,file),animations:'disabled'});
    proof.captures.push(file);
    await save();
  };
  const transition=async stage=>{
    await writeFile(join(workspace,'memory-'+stage+'.request'),stage,{flag:'wx'});
    const result=join(workspace,'memory-'+stage+'.root.json');
    await expect.poll(()=>readFile(result,'utf8').catch(error=>{if(error.code==='ENOENT')return '';throw error}),{timeout:10000}).not.toBe('');
    return JSON.parse(await readFile(result,'utf8'));
  };
  async function record(stage) {
    const now=await context();
    assert.equal(now.threadId,proof.initial.threadId);
    assert.equal(now.claude.sessionId,proof.sessionId);
    assert.equal(now.native.state.nativePid,proof.pid);
    assert.equal(now.claude.turns,proof.initial.claude.turns);
    assert.equal(model.calls.length,requestsBefore);
    assert.deepEqual(await readFile(settings),settingsBefore);
    evidence.stages.push({stage,status:await status.innerText(),pid:now.native.state.nativePid,turns:now.claude.turns,requestCount:model.calls.length});
  }

  try {
    await replace(draft);
    await expect(caption).toContainText('Local memory policy fixture',{timeout:15000});
    await page.setViewportSize({width:1100,height:900});
    if(memoryPolicyPopout){
      const opened=electronApp.waitForEvent('window',{timeout:15000});
      await page.evaluate(()=>window.electronAPI.surfaces.popout('default-setup/threads','Threads'));
      popout=await opened;
      popout.setDefaultTimeout(10000);
      await popout.waitForLoadState('domcontentloaded');
      await expect.poll(()=>popout.evaluate(()=>!!window.applicationState?.system.get('default-setup/threads')),{timeout:15000}).toBe(true);
      await popout.evaluate(threadId=>window.applicationState.system.get('default-setup/threads').send({type:'OPEN_THREAD_CHAT',threadId}),proof.initial.threadId);
      await popout.setViewportSize({width:680,height:600});
      await expect.poll(()=>popout.evaluate(()=>{
        const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;
        const threadId=c.currentThread?.id;
        return Object.values(c.nativeUiViews).some(view=>view.threadId===threadId&&view.attachmentId)
          && Object.values(c.nativeTerminalViews).some(view=>view.threadId===threadId&&view.state?.status==='live');
      }),{timeout:15000}).toBe(true);
      await focus(popout);
      const otherComposer=card(popout).locator('[contenteditable="true"]');
      await expect(otherComposer).toBeVisible({timeout:15000});
      await otherComposer.fill(otherDraft);
      await openMemory(popout);
      await focus(page);
    }
    await openMemory(page);
    await expect(turnOff).toBeEnabled({timeout:12000});
    const initialPanel=await panel.elementHandle();
    assert.ok(initialPanel);
    const isOriginalPanel=()=>panel.evaluate((element,original)=>element===original,initialPanel);
    const otherPanel=popout?.getByRole('dialog',{name:'Claude memory',exact:true});
    const otherHandle=await otherPanel?.elementHandle();
    const samplePopout=async (stage,lockedByPolicy)=>{
      if(!popout||!otherPanel||!otherHandle)return;
      const control=otherPanel.getByRole('button',{name:lockedByPolicy?'Turn Auto-memory on':'Turn Auto-memory off',exact:true});
      if(lockedByPolicy)await expect(control).toBeDisabled({timeout:12000});
      else await expect(control).toBeEnabled({timeout:12000});
      await expect(control).toBeInViewport({ratio:1});
      assert.equal(await otherPanel.evaluate((node,original)=>node===original,otherHandle),true);
      const state=await popout.evaluate(()=>{
        const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;
        const native=Object.values(c.nativeTerminalViews).find(view=>view.threadId===c.currentThread?.id)?.state;
        return {threadId:c.currentThread?.id,sessionId:c.currentThread?.context?.claudeCode?.sessionId,pid:native?.nativePid,ownerId:native?.ownerId};
      });
      assert.deepEqual(state,{threadId:proof.initial.threadId,sessionId:proof.sessionId,pid:proof.pid,ownerId:proof.initial.native.state.ownerId});
      (evidence.popout??={draft:otherDraft,samples:[]}).samples.push({stage,...state,status:await otherPanel.getByRole('status').innerText()});
      await capture('popout-'+stage+'-compact',popout);
    };
    if(memoryPolicyPopout)assert.ok(otherPanel&&otherHandle);
    await samplePopout('initial',false);
    await record('initial');
    await capture('initial-normal');

    await page.setViewportSize({width:680,height:600});
    evidence.activate=await transition('lock');
    await expect(caption).toContainText('Enterprise memory policy fixture',{timeout:18000});
    // If the open panel has not refreshed yet, the original owner must still refuse its old control.
    evidence.staleControlVisible=Boolean(await turnOff.count())&&await turnOff.isEnabled();
    if(!autoRefreshMemoryPolicy&&evidence.staleControlVisible){
      await turnOff.click();
      await expect(panel.getByRole('alert')).toContainText('set by enterprise managed settings',{timeout:12000});
      assert.deepEqual(await readFile(settings),settingsBefore);
      await capture('stale-action-refused-compact');
      await refresh.click();
    }
    await expect(locked).toBeDisabled({timeout:12000});
    await expect(status).toContainText('set by enterprise managed settings');
    await expect(locked).toBeInViewport({ratio:1});
    assert.equal(await isOriginalPanel(),true);
    await samplePopout('locked',true);
    await record('locked');
    await capture('locked-compact');
    if(autoRefreshMemoryPolicy){
      await page.setViewportSize({width:1100,height:900});
      await expect(locked).toBeInViewport({ratio:1});
      await capture('locked-normal');
      await page.setViewportSize({width:680,height:600});
    }

    evidence.release=await transition('release');
    await expect(caption).toContainText('Local memory policy fixture',{timeout:18000});
    if(!autoRefreshMemoryPolicy&&await locked.isVisible())await refresh.click();
    await expect(turnOff).toBeEnabled({timeout:12000});
    assert.equal(await isOriginalPanel(),true);
    evidence.originalPanelRetained=true;
    if(autoRefreshMemoryPolicy) await expect(panel.getByRole('alert')).toHaveCount(0);
    await samplePopout('released',false);
    await record('released');
    await capture('released-compact');
    await panel.getByRole('button',{name:'Done',exact:true}).click();
    await expect(composer).toBeFocused();
    await expect(composer).toHaveText(draft);
    await expect(send).toBeInViewport({ratio:1});
    if(popout&&otherPanel){
      await focus(popout);
      await otherPanel.getByRole('button',{name:'Done',exact:true}).click();
      const otherComposer=card(popout).locator('[contenteditable="true"]');
      const otherSend=card(popout).getByRole('button',{name:'Send',exact:true});
      await expect(otherComposer).toBeFocused();
      await expect(otherComposer).toHaveText(otherDraft);
      await expect(otherSend).toBeInViewport({ratio:1});
      await otherComposer.fill(continuation);
      await expect(otherComposer).toHaveText(continuation);
      await otherSend.click();
      evidence.popout.sentFromPopout=true;
    }else{
      await replace(continuation);
      await send.click();
    }
    await expect.poll(async()=>{
      const now=await context();
      return now.claude?.sessionId===proof.sessionId&&now.claude.chatState==='success'
        && now.messages?.find(message=>message.sender==='user'&&message.text===continuation)?.context?.cliUuid;
    },{timeout:20000}).toBeTruthy();
    const after=await context();
    evidence.followup=after.messages.find(message=>message.sender==='user'&&message.text===continuation).context.cliUuid;
    assert.equal(after.native.state.nativePid,proof.pid);
    assert.equal(model.calls.length,requestsBefore+1);
    if(popout){
      await popout.close();
      await focus(page);
      await expect(composer).toHaveText(draft);
      evidence.popout.mainDraftSurvived=true;
    }
    await section.getByRole('button',{name:'Use native interface',exact:true}).click();
    await section.getByRole('button',{name:'Stop session',exact:true}).click();
    await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
    proof.status='complete';
    await save();
    phase('managed-memory-transition-complete');
  } finally {
    if(popout&&!popout.isClosed())await popout.close();
  }
}
