import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {holdOwnedPromptReplies} from './owned-prompt-reply-hold.mjs';

export async function verifyHeldReadClear({page,section,card,composer,send,expect,context,currentUi,output,project,proof,save,phase,sendMain,processStart}){
 const hold=await holdOwnedPromptReplies(page);
 await page.evaluate(()=>{
  const actor=window.applicationState.system.get('default-setup/threads');
  const requests=new Map();
  const subscription=actor.subscribe(({context})=>{
   for(const view of Object.values(context.nativeUiViews)){
    const request=view.promptHostRequest;
    if(request?.kind==='read')requests.set(request.requestId,{requestId:request.requestId,expiresAt:request.expiresAt});
   }
  });
  window.__claudeReadExpiry={requests,subscription};
 });
 const episode=proof.promptReadClear={captures:[],oldText:'Old session draft for the held read.',freshText:'This session starts the revised release checklist.'};
 const read=label=>readFile(join(project,'read-clear-'+label+'.json'),'utf8').then(JSON.parse).catch(error=>{if(error.code!=='ENOENT')throw error});
 const prompt=async text=>{
  await composer.focus();
  await composer.press('ControlOrMeta+a');await composer.press('Backspace');
  await expect(composer).toHaveText('');
  await page.keyboard.insertText(text);await composer.press('Home');
  await expect.poll(async()=>(await currentUi())?.prompt,{timeout:9000}).toMatchObject({status:'applied',frame:{text,cursor:0}});
 };
 const invoke=async(label,index)=>{
  const button=card.getByRole('button',{name:'Read '+label+' draft',exact:true});
  if(!await button.isVisible())await card.getByRole('button',{name:'Session tools',exact:true}).click();
  await expect(button).toBeVisible();
  await composer.focus();
  await hold.arm();
  await button.click();
  await expect.poll(async()=>(await hold.receipts()).length,{timeout:3500,intervals:[25]}).toBe(index+1);
  return (await hold.receipts())[index];
 };
 const snapshot=()=>composer.evaluate(el=>({document:el.editor.state.doc.toJSON(),selection:el.editor.state.selection.toJSON()}));
 try {
  await prompt(episode.oldText);
  episode.before=await context();delete episode.before.ui;
  episode.old=await invoke('old',0);
  assert.deepEqual(episode.old.box,{text:episode.oldText,cursor:0});
  const oldRequest=await page.evaluate(id=>window.__claudeReadExpiry.requests.get(id),episode.old.requestId);
  assert.equal(oldRequest?.requestId,episode.old.requestId);
  assert.ok(Number.isSafeInteger(oldRequest.expiresAt));
  episode.deadline=oldRequest.expiresAt;
  await sendMain('/clear');
  await expect.poll(async()=>{
   const current=await context();
   return Boolean(current.claude?.sessionId&&current.claude.sessionId!==proof.parentSessionId
     &&current.native?.state?.sessionId===current.claude.sessionId&&(await currentUi())?.state.status==='live');
  },{timeout:10000,intervals:[25]}).toBe(true);
  episode.replacement=await context();delete episode.replacement.ui;
  assert.equal(episode.replacement.threadId,episode.before.threadId);
  assert.equal(episode.replacement.native.state.nativePid,proof.pid);
  assert.notEqual(episode.replacement.claude.sessionId,proof.parentSessionId);
  await prompt(episode.freshText);
  episode.fresh=await invoke('fresh',1);
  assert.deepEqual(episode.fresh.box,{text:episode.freshText,cursor:0});
  assert.notEqual(episode.old.requestId,episode.fresh.requestId);
  await save();
  const before=await snapshot();
  await hold.release(0);
  const retired=(await hold.receipts())[0];episode.old=retired;
  await save();
  assert.ok(retired.releasedAt<episode.deadline,'Probe must release the old reply within the original host window');
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  assert.deepEqual(await snapshot(),before);
  assert.equal(await read('fresh'),undefined);
  await hold.release(1);
  episode.fresh=(await hold.receipts())[1];
  await expect.poll(()=>read('fresh'),{timeout:6500}).toMatchObject({session:episode.replacement.claude.sessionId,value:{text:episode.freshText,cursor:0}});
  episode.freshNative=await read('fresh');
  episode.oldNative=(await read('old'))??null;
  assert.notEqual(episode.oldNative?.value?.text,episode.oldText);
  assert.deepEqual(await snapshot(),before);
  for(const [name,width,height] of [['normal',1100,900],['compact',680,600]]){
   await page.setViewportSize({width,height});await expect(composer).toHaveText(episode.freshText);await expect(send).toBeInViewport();
   const file='held-read-clear-'+name+'.png';
   await page.screenshot({path:join(output,file),animations:'disabled'});episode.captures.push(file);
  }
  await send.click();
  try{
   await expect.poll(async()=>{
    const state=await context();
    const sent=state.messages.findIndex(row=>row.sender==='user'&&row.text===episode.freshText);
    return sent>=0&&state.messages.slice(sent+1).some(row=>row.sender==='assistant'&&row.text==='The native draft-read replay is ready.')
     &&state.claude.chatState==='success'&&state.claude.totalCostUsd>0;
   },{timeout:20000}).toBe(true);
  }finally{episode.followupObserved=await context();delete episode.followupObserved.ui;await save();}
  proof.final=await context();assert.equal(proof.final.claude.sessionId,episode.replacement.claude.sessionId);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(()=>processStart(proof.pid),{timeout:15000}).not.toBe(proof.processStart);
  proof.nativeWriterRetired=true;proof.status='complete';
  await save();phase('held-read-clear-complete');
 } finally {await page.evaluate(()=>{window.__claudeReadExpiry?.subscription.unsubscribe();delete window.__claudeReadExpiry;});await hold.close();}
}
