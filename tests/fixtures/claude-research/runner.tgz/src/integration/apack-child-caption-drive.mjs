import {childCaptionStartupDiagnostic,installChildCaptionTransportDiagnostic} from './child-caption-startup-diagnostic.mjs';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {prepareChildCaptionProfile} from './child-caption-profile.mjs';

export async function driveChildCaption(options) {
 const profile=await prepareChildCaptionProfile(options);
 const output=join(options.workspace,'electron-results');await mkdir(output,{recursive:true});
 await writeFile(join(output,'caption-helper.mjs'),await readFile(profile.helper));
 await writeFile(join(output,'caption-settings-before.json'),await readFile(join(options.workspace,'caption-settings-before.json')));
 try {await driveChildComposer({...options,modelTool:'TextOnly',modelOptions:{childCaptionScenario:true},modelRequestLimit:24,journey:args=>captionJourney({...args,profile}),journeyName:'caption'});}
 finally {await writeFile(join(options.workspace,'caption-model-release'),'released');await profile.restore();await writeFile(join(output,'caption-settings-after.json'),await readFile(join(options.workspace,'caption-settings-after.json')));await writeFile(join(output,'caption-settings-restored.json'),await readFile(join(options.setupWorkspace,'app-data/claude-code-profile/config/settings.json')));await writeFile(join(output,'child-caption-profile-restored.json'),JSON.stringify({restored:true,originalSettingsSha256:profile.originalSettingsSha256,helperSha256:profile.helperSha256},null,2));}
}
async function captionJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model,profile}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 // Verify the actual owned profile through Settings before creating a conversation.
 // This also completes surface navigation instead of racing initial chat restoration.
 await app.navigate('host/settings');
 await page.evaluate(()=>{const actor=window.applicationState.system.get('host/settings');actor.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});actor.send({type:'TAB.SELECT',tab:'features'});});
 await expect(page.locator('#claude-profile')).toHaveValue('app');
 await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.tabs.every(tab=>c.tabsRead.includes(tab.id));}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const transportDiagnostic=env.APACK_CAPTION_TRANSPORT_DIAGNOSTIC==='1'?await installChildCaptionTransportDiagnostic({userDataDir,workspace}):undefined;
 const proof={status:'running',parentSessionId,transportDiagnostic,helper:{command:profile.command,sha256:profile.helperSha256,originalSettingsSha256:profile.originalSettingsSha256},parentPid:initial.native.state.nativePid,parentStart:await readFile('/proc/'+initial.native.state.nativePid+'/stat','utf8').then(raw=>raw.slice(raw.lastIndexOf(')')+2).split(' ')[19]),scope:'Original background child configured Agent caption, native helper/task identity, ordinary notes return and Stop; no broader parity claim.',captures:[],sizes:[]};
 const save=()=>writeFile(join(output,'child-caption.json'),JSON.stringify(proof,null,2));
 const sameLive=async(pid,start)=>{try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[19]===start&&fields[0]!=='Z';}catch(error){if(error.code==='ENOENT')return false;throw error;}};
 try {
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill('/background ResearchChildCaptionReview Review the release notes.');await card.getByRole('button',{name:'Send',exact:true}).click();
  const widget=page.getByRole('region',{name:'Background Claude session',exact:true});
  await expect(widget.getByRole('button',{name:'Stop background session',exact:true})).toBeEnabled({timeout:25000});
  await widget.getByRole('button',{name:'Refresh status',exact:true}).click();
  await expect.poll(async()=>(await context()).native?.background?.desktop,{timeout:25000}).toBeTruthy();
  proof.running=await context();proof.target=proof.running.native.background.desktop;assert.notEqual(proof.target.sessionId,parentSessionId);await save();
  await composer.fill('Keep the parent release review draft.');
  let invocations;
  await expect.poll(async()=>{invocations=(await profile.invocations()).filter(row=>row.input.session_id===proof.target.sessionId&&row.input.tasks.some(task=>task.type==='local_agent'&&task.status==='running'));return invocations.length;},{timeout:15000}).toBeGreaterThanOrEqual(2);
  proof.invocations=invocations;assert.ok(invocations.every(row=>row.ancestry?.some(ancestor=>ancestor.pid===proof.target.pid&&ancestor.start===proof.target.processStart)),'Helper ancestry must include the original worker incarnation');
  const first=invocations[0],task=first.input.tasks.find(task=>task.type==='local_agent'&&task.status==='running');
  const line=first.stdout.split('\n').filter(Boolean).map(JSON.parse).find(row=>row.id===task.id);assert.ok(line);proof.task=task;proof.caption=line.content;await save();phase('original-child-helper-observed');
  const caption=widget.getByText(line.content,{exact:true});
  await expect(caption).toBeVisible({timeout:5000});
  for(const [name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(size);await expect(caption).toBeInViewport({ratio:1});await expect(card.getByRole('button',{name:'Send',exact:true})).toBeInViewport({ratio:1});
   await expect(composer).toHaveText('Keep the parent release review draft.');
   const geometry=await caption.evaluate(element=>{const r=element.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,clientWidth:element.clientWidth,scrollWidth:element.scrollWidth};});assert.ok(geometry.scrollWidth<=geometry.clientWidth);proof.sizes.push({name,...geometry});
   const file='child-caption-'+name+'.png';await page.screenshot({path:join(output,file)});proof.captures.push(file);await save();
  }
  await writeFile(join(workspace,'caption-model-release'),'released');
  await expect.poll(()=>model.calls.some(call=>call.childCaptionStage==='review-complete'),{timeout:15000}).toBe(true);
  const before=proof.running.claude,after=(await context()).claude;
  assert.equal(after.sessionId,parentSessionId);assert.equal(after.turns,before.turns);assert.equal(after.totalCostUsd,before.totalCostUsd);
  await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});
  const stopped=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(stopped.sessionId,proof.target.sessionId);assert.equal(stopped.state,'stopped');proof.nativeStopped=stopped;await expect.poll(()=>sameLive(proof.target.pid,proof.target.processStart),{timeout:10000}).toBe(false);await expect.poll(()=>sameLive(proof.parentPid,proof.parentStart),{timeout:10000}).toBe(false);proof.writersRetired=true;proof.final=await context();proof.status='complete';await save();
 }finally{
  await writeFile(join(workspace,'caption-model-release'),'released');
  const state=await context().catch(()=>null),sessionId=proof.target?.sessionId??state?.claude?.nativeContinuation?.continuedInSessionId;
  proof.startupDiagnostic=await childCaptionStartupDiagnostic({userDataDir,sessionId,pid:proof.target?.pid??state?.native?.background?.session?.pid}).catch(error=>({matched:false,error:error.name}));
  if(sessionId){const run=promisify(execFile),cliEnv={...env,CLAUDE_CONFIG_DIR:join(userDataDir,'claude-code-profile/config')};const rows=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024})).stdout);const owned=rows.find(row=>row.sessionId===sessionId&&row.cwd===project);if(owned&&owned.state!=='stopped'){await run('/frozen-claude/claude',['stop',owned.id],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024});proof.cleanupStoppedOwnedJob=true;}}
  if(transportDiagnostic){try{const info=await (await import('node:fs/promises')).lstat(transportDiagnostic.receipt);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1024*1024);await writeFile(join(output,'helper-transport.jsonl'),await readFile(transportDiagnostic.receipt));}catch(error){if(error.code!=='ENOENT')throw error;}}
  proof.allInvocations=await profile.invocations();proof.helperWritersRetired=(await Promise.all(proof.allInvocations.map(row=>sameLive(row.pid,row.start)))).every(live=>!live);if(proof.status==='complete')assert.equal(proof.helperWritersRetired,true);await save();
 }
}
