import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat,mkdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {prepareCombinedEverydayProfile} from './combined-everyday-profile.mjs';
const sha=data=>createHash('sha256').update(data).digest('hex');
async function processStart(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]==='Z'?undefined:fields[19]}catch(error){if(error.code==='ENOENT')return;throw error}}

/** Original /clear through the ordinary composer; no direct reset or local session writer. */
export async function driveNativeParentReset(options){
 const output=join(options.workspace,'electron-results');await mkdir(output,{recursive:true});const profile=await prepareCombinedEverydayProfile(options);
 try{await driveChildComposer({...options,modelRequestLimit:12,modelOptions:{textReply:'The release review is ready. I can check the checklist next.'},journey:args=>resetJourney({...args,profile}),journeyName:'native-parent-reset'});}
 finally{await profile.restore();await writeFile(join(output,'combined-agent-restoration.json'),await readFile(join(options.workspace,'combined-agent-restoration.json')));await writeFile(join(output,'status-helper.mjs'),await readFile(profile.helper));for(const name of ['before','after','restored'])await writeFile(join(output,'combined-settings-'+name+'.json'),await readFile(join(options.workspace,'combined-settings-'+name+'.json')));}
}
async function resetJourney({app,page,electronApp,output,project,userDataDir,expect,phase,profile,model}){
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});a.send({type:'TAB.SELECT',tab:'features'});});await expect(page.locator('#claude-profile')).toHaveValue('app');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.tabs.every(tab=>c.tabsRead.includes(tab.id));}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:Object.values(c.nativeUiViews).find(v=>v.threadId===c.currentThread?.id)};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await composer.fill('Help me review the release notes and checklist.');await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');const initial=await context(),pid=initial.native.state.nativePid,start=await processStart(pid);assert.ok(start);
 await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toBeVisible();
 let initialUiRecovery;
 await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toMatch(/^(live|error)$/);
 if((await context()).ui?.state?.status==='error'){
  const before=await context();initialUiRecovery={before};await writeFile(join(output,'initial-ui-recovery.json'),JSON.stringify(initialUiRecovery,null,2));
  await card.getByRole('button',{name:'Reconnect controls',exact:true}).click({timeout:5000});
  await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toBe('live');
  const after=await context();assert.equal(after.native.state.nativePid,pid);assert.equal(after.native.state.sessionId,initial.native.state.sessionId);assert.equal(after.native.state.ownerId,before.native.state.ownerId);assert.equal(await processStart(pid),start);
  initialUiRecovery.after=after;await writeFile(join(output,'initial-ui-recovery.json'),JSON.stringify(initialUiRecovery,null,2));
 }
 await expect.poll(async()=>(await context()).native?.state?.mainStatus,{timeout:15000}).toContain('Release review');
 const proof={status:'running',scope:'Original parent /clear, session/status retirement and continuation; not naturally gated quota offers or full lifecycle acceptance.',before:await context(),pid,processStart:start,captures:[],initialUiRecovery};
 const save=()=>writeFile(join(output,'native-parent-reset.json'),JSON.stringify(proof,null,2));
 const capture=async stage=>{for(const [size,viewport]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect(send).toBeInViewport({ratio:1});const name='native-parent-reset-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,name)});proof.captures.push(name);}await save();};
 try{
  proof.requestsBeforeClear=model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length;
  await composer.fill('/clear');await send.click();
  await expect.poll(async()=>(await context()).native?.state?.sessionId,{timeout:20000}).not.toBe(initial.native.state.sessionId);
  await expect.poll(async()=>{const c=await context();return c.claude?.sessionId===c.native?.state?.sessionId&&c.ui?.state?.status==='live';},{timeout:20000}).toBe(true);
  proof.afterClear=await context();assert.equal(proof.afterClear.threadId,initial.threadId);assert.equal(proof.afterClear.native.state.nativePid,pid);assert.equal(await processStart(pid),start);assert.notEqual(proof.afterClear.claude.sessionId,initial.claude.sessionId);assert.ok(proof.afterClear.claude.previousSessionIds.includes(initial.claude.sessionId));assert.equal(proof.afterClear.native.state.notice,undefined);
  assert.equal(model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length,proof.requestsBeforeClear);
  await composer.fill('Keep these notes after clearing the conversation.');await expect(send).toBeEnabled();await capture('cleared');
  const followup='Review only the new release checklist.';await composer.fill(followup);await send.click();
  await expect.poll(()=>model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').slice(proof.requestsBeforeClear).some(c=>JSON.stringify(c.messages).includes(followup)),{timeout:20000}).toBe(true);
  await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:20000}).toBe(false);
  await expect.poll(async()=>{const c=await context();return c.claude?.turns>=1&&c.claude?.sessionId===proof.afterClear.claude.sessionId;},{timeout:20000}).toBe(true);
  await expect.poll(async()=>(await profile.invocations()).some(r=>r.kind==='main'&&r.input.session_id===proof.afterClear.claude.sessionId),{timeout:15000}).toBe(true);
  await expect.poll(async()=>(await context()).native?.state?.mainStatus,{timeout:15000}).toContain('Release review');
  proof.afterFollowup=await context();proof.modelRequests=model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages');const newRequests=proof.modelRequests.slice(proof.requestsBeforeClear);assert.ok(newRequests.length);assert.ok(newRequests.some(c=>JSON.stringify(c.messages).includes(followup)));assert.ok(newRequests.every(c=>!JSON.stringify(c.messages).includes('Help me review the release notes and checklist.')));
  await composer.fill('Keep the fresh release notes while returning.');await capture('continued');await expect(composer).toHaveText('Keep the fresh release notes while returning.');
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processStart(pid),{timeout:15000}).not.toBe(start);proof.nativeWriterRetired=true;
  const root=join(userDataDir,'claude-code-profile/config/projects'),names=await readdir(root,{recursive:true});proof.journals=[];
  for(const id of [initial.claude.sessionId,proof.afterClear.claude.sessionId]){const matches=names.filter(n=>basename(n)===id+'.jsonl');assert.equal(matches.length,1);const bytes=await readFile(join(root,matches[0])),name='native-'+id+'.jsonl';await writeFile(join(output,name),bytes);const rows=bytes.toString().split('\n').filter(Boolean).map(JSON.parse),humans=rows.filter(r=>r.type==='user'&&!r.isMeta&&!r.isVirtual&&typeof r.message?.content==='string'&&(r.origin===undefined||r.origin.kind==='human'));proof.journals.push({sessionId:id,name,sha256:sha(bytes),humans,cost:rows.filter(r=>r.type==='cost-state').at(-1)?.totalCostUSD});}
  assert.ok(proof.journals[0].humans.some(r=>r.message.content==='Help me review the release notes and checklist.'));assert.ok(proof.journals[1].humans.some(r=>r.message.content===followup));assert.ok(!proof.journals[1].humans.some(r=>r.message.content==='Help me review the release notes and checklist.'));assert.equal(proof.journals[1].cost,proof.afterFollowup.claude.totalCostUsd);
  proof.helperInvocations=await profile.invocations();assert.ok((await Promise.all(proof.helperInvocations.map(r=>processStart(r.pid)))).every((value,i)=>value!==proof.helperInvocations[i].start));proof.helperWritersRetired=true;proof.status='complete';await save();phase('native-parent-reset-complete');
 }catch(error){proof.error={name:error.name,message:error.message.slice(0,2000)};await page.screenshot({path:join(output,'native-parent-reset-failure.png')}).catch(()=>{});await save();throw error;}
}
