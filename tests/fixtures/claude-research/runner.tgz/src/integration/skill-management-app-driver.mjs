import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
const [checkout,executable,workspace,mode]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const retained=mode==='retained';const model=retained?await startSyntheticModel(workspace,'TextOnly'):undefined;
const requests=[];const server=createServer((request,response)=>{requests.push({method:request.method,path:request.url});request.resume();response.writeHead(503);response.end('No model calls permitted in this fixture');});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
let child,deadline;
try{
 const url=model?.url??`http://127.0.0.1:${server.address().port}`;
 child=spawn(process.execPath,[join(checkout,'node_modules/vitest/vitest.mjs'),'run','tests/features/code/be/services/claude-code/native-skill-management-app.spec.ts','--pool=threads','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--silent'],{cwd:join(checkout,'packages/default-setup'),env:{...process.env,ANTHROPIC_BASE_URL:url,CLAUDE_RESEARCH_EXECUTABLE:executable,CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_RETAINED:retained?'1':'0'},stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);
 deadline=setTimeout(()=>child.kill('SIGTERM'),55000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',resolve)});
 assert.equal(code,0,'Compiled Skill command test failed');assert.equal(requests.length,0,'Unexpected API traffic');if(retained)assert.equal(model.calls.length,1,'Expected one local synthetic turn');
 const evidence=JSON.parse(await readFile(join(workspace,'skill-management-app-evidence.json'),'utf8'));
 console.log(JSON.stringify({evidence:'native-skill-management-app',...evidence,apiRequests:requests.length,syntheticModelRequests:model?.calls.length??0,realModelRequests:0}));
}finally{clearTimeout(deadline);await new Promise(resolve=>server.close(resolve));await model?.close();}
