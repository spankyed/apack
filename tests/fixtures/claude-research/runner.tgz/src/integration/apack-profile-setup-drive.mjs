import assert from 'node:assert/strict';
import {once} from 'node:events';
import {existsSync,appendFileSync,createWriteStream} from 'node:fs';
import {mkdir,readFile,writeFile,readdir,readlink} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {createServer} from 'node:https';
import {prepareNativeCreditTls} from '../protocol/native-credit-billing.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {MANAGED_SECURITY_KEY} from '../protocol/native-managed-security-fixture.mjs';

/** Verify native app-profile setup on real Electron inside the inspected offline Linux boundary. */
export async function driveProfileSetup({checkout,workspace,env}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv'));
 assert.ok(existsSync('/control/offline-verified'));
 assert.ok(!env.NODE_OPTIONS?.includes('linux-electron-launch.mjs'),'Direct launch scopes --no-sandbox to Electron; no global launch patch');
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
 assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
 const executable='/frozen-claude/claude';assert.equal(createHash('sha256').update(await readFile(executable)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 const tls=await prepareNativeCreditTls(join(workspace,'profile-setup-tls'));
 const requests=[];
 const server=createServer({key:await readFile(tls.key),cert:await readFile(tls.cert)},(req,res)=>{
  const path=new URL(req.url,'https://api.anthropic.com').pathname;
  if(requests.length>=200){res.writeHead(429);res.end();return;}
  requests.push({path,method:req.method,foreignKey:!!req.headers['x-api-key']&&req.headers['x-api-key']!==MANAGED_SECURITY_KEY});
  if(req.method==='GET'&&['/api/hello','/v1/oauth/hello'].includes(path)){res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({ok:true}));return;}
  if(req.method==='GET'&&path==='/api/claude_code/settings'){res.writeHead(204);res.end();return;}
  res.writeHead(req.method==='HEAD'&&path==='/api/hello'?200:404,{'content-type':'application/json'});res.end('{}');
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(443,'127.0.0.1',resolve)});server.unref();
 env={...env,ANTHROPIC_API_KEY:MANAGED_SECURITY_KEY,ANTHROPIC_BASE_URL:'https://api.anthropic.com',NODE_EXTRA_CA_CERTS:tls.ca,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH};
 const output=join(workspace,'electron-results');await mkdir(output,{recursive:true});
 const phase=(kind,extra={})=>appendFileSync(join(workspace,'direct-electron-events.jsonl'),JSON.stringify({at:Date.now(),kind,...extra})+'\n');
 const require=createRequire(join(checkout,'package.json'));
 phase('loading-playwright');
 const {_electron}=require('@playwright/test');
 phase('loading-app-environment');
 const {appLaunchEnv}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/launch-env.ts')).href);
 const {waitForApplicationWindow}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/application-window.ts')).href);
 const {expect}=require('@playwright/test');
 const JOURNEY_TIMEOUT_MS=60000;
 let electronApp,appProcess,page,timer,cleanupTimer,log,logBytes=0,quit='not-started',status='failed';
 try {
   // Leave the fresh profile to the app's normal shipped-pack installation.
   phase('preparing-app-helpers');
   const {resolveAppEnvironment}=await import(pathToFileURL(require.resolve('@apackdev/sdk/env')).href);
   const {appDir}=resolveAppEnvironment({env:'test',userDataDir:join(workspace,'app-data')});
   const {createAppDriver,waitForAppReady}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/index.ts')).href);
   phase('launch-requested');
   // Let Playwright install its Electron loader; executablePath bypasses that loader.
   assert.equal(require('electron'),createRequire(require.resolve('playwright-core/package.json'))('electron/index.js'));
   electronApp=await _electron.launch({args:['--no-sandbox',checkout],cwd:checkout,env:appLaunchEnv(env,join(workspace,'app-data')),timeout:60000});
   appProcess=electronApp.process();
   log=createWriteStream(join(output,'app-0.log'));
   const capture=chunk=>{const bytes=Buffer.from(chunk).subarray(0,Math.max(0,4*1048576-logBytes));logBytes+=bytes.length;if(bytes.length)log.write(bytes);};
   appProcess.stdout?.on('data',capture);appProcess.stderr?.on('data',capture);
   phase('process-attached',{pid:appProcess.pid});
   // The app owns its60s API clock. Attachment can precede API startup; a second
   // clock here would shorten that allowance. The enclosing recorder bounds setup.
   let backendReady=false;
   while(!backendReady){
    assert.ok(appProcess.exitCode===null&&appProcess.signalCode===null,'App exited before API readiness');
    const text=await readFile(join(appDir,'logs/main.jsonl'),'utf8').catch(error=>{if(error.code==='ENOENT')return '';throw error});
    assert.ok(!text.includes('[MAIN] API server failed to start'),'App API startup failed; inspect the original main log');
    backendReady=text.includes('[MAIN] API server is running on port ');
    if(!backendReady)await new Promise(resolve=>setTimeout(resolve,200));
   }
   phase('backend-ready');
   // Match the existing standard app fixture's window discovery budget.
   page=await waitForApplicationWindow(electronApp,45000);await page.setViewportSize({width:1400,height:900});
   phase('app-window-ready',{url:page.url()});
   page.setDefaultTimeout(0);
   await waitForAppReady(page);phase('app-connected');
   const app=createAppDriver(page,output);
  await Promise.race([(async()=>{
   phase('shared-ui-journey-started');
   await profileJourney({app,page,output,workspace,env,expect,resolveAppEnvironment,phase});
   assert.ok(!requests.some(row=>row.foreignKey||row.path.startsWith('/v1/messages')),'No real credentials or model turn belongs to this setup journey');
   await writeFile(join(output,'native-requests.json'),JSON.stringify(requests,null,2));
   status='complete';phase('journey-complete');
  })(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Profile setup journey exceeded its existing app-test allowance')),JOURNEY_TIMEOUT_MS)})]);
 }catch(error){
  phase('journey-failed',{message:error.message});
  if(!page&&electronApp)page=electronApp.windows().find(candidate=>!candidate.isClosed());
  if(page&&!page.isClosed()){
   await page.screenshot({path:join(output,'direct-profile-setup-failure.png'),timeout:5000}).catch(()=>{});
   await writeFile(join(output,'direct-profile-setup-failure.txt'),await page.locator('body').innerText({timeout:5000}).catch(()=>''));
   const state=await page.evaluate(()=>{const context=(window).applicationState.system.get('default-setup/code')?.getSnapshot().context;return {baseDirectory:context?.baseDirectory,pendingSetup:context?.pendingClaudeProfileSetup,setupError:context?.claudeProfileSetupError,openFiles:context?.openFiles?.map(file=>({path:file.path,isTerminal:file.isTerminal,title:file.terminalInfo?.title})),terminalEvents:(window).__profileTerminalEvents?.slice(-500)};}).catch(()=>null);
   await writeFile(join(output,'profile-setup-failure-state.json'),JSON.stringify(state,null,2));
  }
  throw error;
 }finally{
  clearTimeout(timer);
  if(electronApp){
   try{await Promise.race([(async()=>{await electronApp.close();if(appProcess.exitCode===null&&appProcess.signalCode===null)await once(appProcess,'exit')})(),new Promise((_,reject)=>{cleanupTimer=setTimeout(()=>reject(Error('Owned Electron close did not finish')),30000)})]);quit='normal';}
   catch{quit='forced';if(appProcess.exitCode===null&&appProcess.signalCode===null)appProcess.kill('SIGKILL');}
   finally{clearTimeout(cleanupTimer);}
  }
  await writeFile(join(output,'native-requests.json'),JSON.stringify(requests,null,2));
  server.closeAllConnections();await new Promise(resolve=>server.close(resolve));
  if(log)await new Promise(resolve=>log.end(resolve));
  await writeFile(join(workspace,'direct-electron-proof.json'),JSON.stringify({route:'real-Electron-native-profile-setup-journey',status,quit,rootExitObserved:!!appProcess&&(appProcess.exitCode!==null||appProcess.signalCode!==null),pageUrl:page?.url(),testRunnerUsed:false,packPreparation:'app-first-boot',preparationIncludedInJourneyBudget:false,startupIncludedInJourneyBudget:false,journeyBudgetMs:JOURNEY_TIMEOUT_MS},null,2));
  if(status==='complete')assert.equal(quit,'normal','Actual-app shutdown must finish without a forced stop');
 }
}


async function profileJourney({app,page,output,workspace,env,expect,resolveAppEnvironment,phase}) {
 const project=join(workspace,'project');await mkdir(project,{recursive:true});
 await writeFile(join(project,'README.md'),'# Workspace review\nKeep the native profile and existing chats separate.\n');
 await app.waitForSurface('default-setup/code');await app.navigate('default-setup/code');
 await page.evaluate(project=>(window).__sendToSystem('default-setup/code',{type:'SET_BASE_DIRECTORY',path:project,fromUserNavigation:true}),project);
 await expect.poll(()=>page.evaluate(()=>(window).applicationState.system.get('default-setup/code').getSnapshot().context.baseDirectory)).toBe(project);
 const settings=async()=>{
  await app.navigate('host/settings');
  await page.evaluate(()=>{const actor=(window).applicationState.system.get('host/settings');actor.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});actor.send({type:'TAB.SELECT',tab:'features'});});
  await expect(page.getByLabel('Default for new chats',{exact:true})).toBeVisible();
 };
 await settings();const choice=page.getByLabel('Default for new chats',{exact:true});
 await expect(choice).toHaveValue('shared');
 await choice.selectOption('app');await expect(page.getByText('Settings saved',{exact:true})).toBeVisible();
 const readings=[];
 for(const viewport of [{width:1100,height:900},{width:680,height:600}]){
  await page.setViewportSize(viewport);
  const button=page.getByRole('button',{name:'Set up app profile…',exact:true});await button.scrollIntoViewIfNeeded();
  await expect(choice).toBeInViewport({ratio:1});await expect(button).toBeInViewport({ratio:1});
  const bounds=await button.evaluate(element=>{const b=element.getBoundingClientRect();return {width:b.width,height:b.height,hit:element.contains(document.elementFromPoint(b.x+b.width/2,b.y+b.height/2))};});
  assert.equal(bounds.hit,true);readings.push({viewport,bounds});
  await page.screenshot({path:join(output,'profile-settings-'+viewport.width+'.png')});
 }
 await page.setViewportSize({width:1100,height:900});
 await page.evaluate(()=>{const win=window;win.__profileTerminalEvents=[];win.applicationState.system.inspect(inspection=>{
  if(inspection.type!=='@xstate.event'||inspection.actorRef?.id!=='default-setup/code')return;
  const event=inspection.event;if(!['terminal.OPENED','terminal.OUTPUT','terminal.INITIAL_OUTPUT','terminal.ERROR'].includes(event.type))return;
  const rows=win.__profileTerminalEvents;if(rows.length>=4000)rows.shift();rows.push({type:event.type,data:event.data});
 });});
 await page.getByRole('button',{name:'Set up app profile…',exact:true}).click();
 await expect.poll(async()=>(await app.getContext()).activeSurfaceId).toBe('default-setup/code');
 const opened=async()=>page.evaluate(()=>(window).__profileTerminalEvents.find(row=>row.type==='terminal.OPENED'&&row.data?.title==='Claude profile setup')?.data);
 await expect.poll(opened).toBeTruthy();const terminal=await opened();phase('setup-terminal-opened',{terminalId:terminal.id,pid:terminal.pid});
 const {userDataDir}=resolveAppEnvironment({env:'test',userDataDir:join(workspace,'app-data')});
 const configDir=join(userDataDir,'claude-code-profile','config'),configPath=join(configDir,'.claude.json');
 const raw=async()=>page.evaluate(id=>(window).__profileTerminalEvents.filter(row=>['terminal.OUTPUT','terminal.INITIAL_OUTPUT'].includes(row.type)&&row.data?.terminalId===id).map(row=>row.data.data).join(''),terminal.id);
 const plain=value=>value.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');
 const focus=async()=>{await page.locator('.xterm-helper-textarea').last().focus();};
 const press=async key=>{await focus();await page.keyboard.press(key);phase('native-key-sent',{key});};
 const actions=[];let exitKeys=0,nativePid,nativeStart,stageOffset=0;
 const childIdentity=async()=>{
  for(const id of await readdir('/proc')){
   if(!/^[0-9]+$/.test(id))continue;
   try{const value=await readFile('/proc/'+id+'/stat','utf8'),fields=value.slice(value.lastIndexOf(')')+2).split(' ');
    if(Number(fields[1])===terminal.pid&&(await readlink('/proc/'+id+'/exe'))==='/frozen-claude/claude')return {pid:Number(id),start:fields[19]};
   }catch{}
  }
 };
 await expect.poll(childIdentity).toBeTruthy();({pid:nativePid,start:nativeStart}=await childIdentity());
 for(;;){
  const identity=await childIdentity();
  assert.ok(identity?.pid===nativePid&&identity.start===nativeStart,'Original Claude exited before profile setup completed; inspect the captured terminal output');
  const complete=await raw(),text=complete.slice(stageOffset),stage=recognizeOnboardingPrompt(text,actions.includes('workspace-trust-selected')?undefined:project,{apiKeySuffix:MANAGED_SECURITY_KEY.slice(-20)});
  if(stage&&!actions.includes(stage)){
   actions.push(stage);phase('onboarding-step',{stage});
   const key=stage==='workspace-trust'?'ArrowDown':stage==='environment-api-key'?'ArrowUp':'Enter';
   // Pinned TrustDialog uses the original 150ms settling/refusal fence.
   if(stage.startsWith('workspace-trust'))await new Promise(resolve=>setTimeout(resolve,200));
   if(key==='Enter')stageOffset=complete.length;
   await press(key);
  }
  const config=await readFile(configPath,'utf8').then(JSON.parse).catch(()=>undefined);
  const approved=config?.customApiKeyResponses?.approved?.includes(MANAGED_SECURITY_KEY.slice(-20));
  const idle=plain(text).includes('APIUsageBilling')&&plain(text).includes('shift+tabtocycle');
  if(approved&&idle){
   await page.screenshot({path:join(output,'profile-native-onboarding.png')});
   // Keep the original double-key interaction within its800ms window.
   // Refocusing/polling between keys adds unrelated renderer round trips.
   await focus();
   await page.keyboard.press('Control+d');exitKeys++;
   await page.keyboard.press('Control+d');exitKeys++;
   phase('native-exit-keys-sent',{exitKeys});break;
  }
  await new Promise(resolve=>setTimeout(resolve,100));
 }
 // Original gY exit confirmation expires after800ms; default poll backoff can miss it.
 await expect.poll(async()=>{
  try{const value=await readFile('/proc/'+nativePid+'/stat','utf8');return value.slice(value.lastIndexOf(')')+2).split(' ')[19]!==nativeStart;}catch(error){if(error.code==='ENOENT')return true;throw error;}
 },{intervals:[50,100,100],timeout:10000}).toBe(true);
 await focus();await page.keyboard.type("printf '__APACK_PROFILE_EXIT_%s__\\n' \"$?\"");await page.keyboard.press('Enter');
 await expect.poll(raw).toContain('__APACK_PROFILE_EXIT_0__');
 const config=JSON.parse(await readFile(configPath,'utf8'));
 assert.equal(config.projects?.[project]?.hasTrustDialogAccepted,true,'Original project trust must persist through normal exit');
 const saved=JSON.parse(await readFile(join(configDir,'settings.json'),'utf8')),prefix=JSON.parse(saved.processWrapper);
 assert.equal(prefix.length,1);assert.ok(prefix[0].endsWith('/claude-code-profile/bin/launch.sh'));
 await settings();await expect(choice).toHaveValue('app');
 await writeFile(join(output,'profile-setup.json'),JSON.stringify({settings:readings,actions,configDir,terminalId:terminal.id,nativePid,nativeStart,nativeExitCode:0,exitKeys,nativeProjectTrust:true,nativeKeyApproval:true,launcherArgv:prefix,modelTurns:0,scope:'Actual settings/terminal onboarding and saved native decisions. Child desktop/composer, warm-spare and broader lifecycle acceptance remain separate.'},null,2));
}
