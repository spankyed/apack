import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';

export function driveChildControls(options) {
 return driveChildComposer({...options,modelTool:'TextOnly',modelOptions:{childControlScenario:true},modelRequestLimit:24,journey:controlsJourney,journeyName:'controls'});
}
async function controlsJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const proof={status:'running',parentSessionId,scope:'One original parent question and owned cold child Bash deny/allow/question flow; no other approval-family or full parity claim.',captures:[],sizes:[]};
 const save=()=>writeFile(join(output,'child-controls.json'),JSON.stringify(proof,null,2));
 const hasResult=stage=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_child_control_'+stage);
 const result=async(stage,error)=>{await expect.poll(()=>hasResult(stage),{timeout:15000}).toBeTruthy();const value=hasResult(stage);assert.equal(value.is_error===true,error);proof['result'+stage]=value;await save();};
 const capture=async(name)=>{await page.screenshot({path:join(output,name+'.png')});proof.captures.push(name+'.png');await save();};
 const sizes=[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]];
 const measure=async(panel,label)=>{
  for(const [name,size]of sizes){await page.setViewportSize(size);const button=panel.getByRole('button',{name:label,exact:true});await expect(button).toBeInViewport({ratio:1});const geometry=await panel.evaluate(element=>{const r=element.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,viewport:{width:innerWidth,height:innerHeight},clientWidth:element.clientWidth,scrollWidth:element.scrollWidth};});assert.ok(geometry.scrollWidth<=geometry.clientWidth);proof.sizes.push({stage:label,name,...geometry});await capture((label==='Deny'?'child-deny':label==='Allow once'?'child-allow':'parent-question')+'-'+name);}
 };
 try {
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill('ResearchChildControl1 Review the release branch before continuing.');await card.getByRole('button',{name:'Send',exact:true}).click();
  const parentQuestion=page.getByRole('region',{name:'Claude Code questions',exact:true});
  await expect(parentQuestion).toBeVisible({timeout:20000});await parentQuestion.locator('input[value="Stable"]').check();await measure(parentQuestion,'Submit answers');
  await parentQuestion.getByRole('button',{name:'Submit answers',exact:true}).click();await expect(parentQuestion).toHaveCount(0);await result(1,false);assert.ok(JSON.stringify(proof.result1).includes('Stable'));proof.mainQuestionAccepted=true;
  await expect.poll(async()=>(await context()).claude?.turns,{timeout:15000}).toBe(2);
  await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:15000}).toBe(false);
  phase('original-parent-question-complete');
  await composer.fill('/background ResearchChildControl2 Review the command before writing the release marker.');await card.getByRole('button',{name:'Send',exact:true}).click();
  const widget=page.getByRole('region',{name:'Background Claude session',exact:true});
  await expect(widget.getByRole('button',{name:'Review request',exact:true})).toBeEnabled({timeout:25000});
  await expect.poll(async()=>(await context()).native?.background?.approval,{timeout:25000}).toBeTruthy();
  proof.running=await context();proof.target=proof.running.native.background.desktop;assert.ok(proof.target);assert.notEqual(proof.target.sessionId,parentSessionId);proof.discoveredWithReplyClosed=true;
  await composer.fill('Keep the parent release review notes here.');const parentDraft=await composer.textContent();
  const approval=widget.getByRole('region',{name:'Bash approval',exact:true});await expect(approval).toHaveCount(0);
  await widget.getByRole('button',{name:'Review request',exact:true}).click();await expect(approval).toBeVisible({timeout:15000});
  const currentApproval=async()=>{const c=await context();const pair=Object.entries(c.ui).find(([,value])=>value.state?.approval?.control?.dialog?.sessionId===proof.target.sessionId);assert.ok(pair);return{mountId:pair[0],frame:pair[1].state.approval};};
  proof.firstApproval=await currentApproval();proof.originalCommand=await approval.locator('[data-testid="native-bash-command"]').textContent();
  const effect=join(workspace,'release-review-approved.txt');await assert.rejects(readFile(effect),error=>error.code==='ENOENT');proof.noEffectBeforeDeny=true;
  assert.ok(proof.originalCommand.includes(effect));await measure(approval,'Deny');
  await approval.getByText('Add a reason for denying',{exact:true}).click();await approval.getByRole('textbox',{name:'Reason for denying',exact:true}).fill('Keep the release file unchanged until review.');
  await approval.getByRole('button',{name:'Back to parent notes',exact:true}).click();await expect(approval).toBeHidden();await expect(composer).toBeFocused();await expect(composer).toHaveText(parentDraft);await capture('child-controls-parent-notes-compact');
  await widget.getByRole('button',{name:'Review request',exact:true}).click();await expect(approval.getByRole('textbox',{name:'Reason for denying',exact:true})).toHaveValue('Keep the release file unchanged until review.');proof.denialDraftRetained=true;
  await approval.getByRole('button',{name:'Deny',exact:true}).click();await expect(approval).toHaveCount(0);await result(2,true);assert.ok(JSON.stringify(proof.result2).includes('Keep the release file unchanged until review.'));await assert.rejects(readFile(effect),error=>error.code==='ENOENT');proof.deniedFileAbsent=true;
  const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');
  await expect(editor).toBeEditable();await editor.fill('ResearchChildControl3 Write the release marker after this review.');await form.getByRole('button',{name:'Send message',exact:true}).click();
  await expect(approval).toBeVisible({timeout:15000});proof.secondApproval=await currentApproval();assert.notEqual(proof.firstApproval.frame.id,proof.secondApproval.frame.id);
  await page.evaluate(({threadId,mountId,frameId})=>window.applicationState.system.get('default-setup/threads').send({type:'CLAUDE_UI_APPROVAL_ANSWER',threadId,mountId,frameId,answer:{approved:false}}),{threadId:proof.running.threadId,mountId:proof.firstApproval.mountId,frameId:proof.firstApproval.frame.id});
  await expect(approval.getByRole('button',{name:'Allow once',exact:true})).toBeEnabled();await assert.rejects(readFile(effect),error=>error.code==='ENOENT');proof.oldDenialReplayed=true;
  await measure(approval,'Allow once');await approval.getByRole('button',{name:'Allow once',exact:true}).click();await expect(approval).toHaveCount(0);await result(3,false);
  const bytes=await readFile(effect);assert.equal(bytes.toString(),'release review approved\n');await writeFile(join(output,'release-review-approved.txt'),bytes);proof.approvedFileSha256=createHash('sha256').update(bytes).digest('hex');
  await expect(editor).toBeEditable();await editor.fill('ResearchChildControl4 Confirm the release branch before wrapping up.');await form.getByRole('button',{name:'Send message',exact:true}).click();
  const question=widget.getByRole('region',{name:'Claude Code questions',exact:true});await expect(question).toBeVisible({timeout:15000});const stable=question.locator('input[value="Stable"]');await stable.check();
  for(const[name,size]of sizes){await page.setViewportSize(size);await expect(stable).toBeInViewport({ratio:1});await expect(question.locator('input[value="Next"]')).toBeInViewport({ratio:1});await expect(question.getByRole('button',{name:'Submit answers',exact:true})).toBeInViewport({ratio:1});await question.locator('.body').hover();await page.mouse.wheel(0,160);await expect(question.locator('textarea').first()).toBeInViewport({ratio:1});await question.locator('.body').hover();await page.mouse.wheel(0,-600);await capture('child-question-'+name);}
  await question.getByRole('button',{name:'Back to parent notes',exact:true}).click();await expect(composer).toBeFocused();await expect(composer).toHaveText(parentDraft);
  await widget.getByRole('button',{name:'Answer question',exact:true}).click();await expect(stable).toBeChecked();proof.childQuestionDraftRetained=true;
  await question.getByRole('button',{name:'Submit answers',exact:true}).click();await expect(question).toHaveCount(0);await result(4,false);assert.ok(JSON.stringify(proof.result4).includes('Stable'));
  await expect.poll(async()=>(await context()).native?.background?.session?.status,{timeout:15000}).not.toBe('waiting');await expect(widget.getByText('input needed',{exact:true})).toHaveCount(0);proof.settled=await context();
  await expect(editor).toBeEditable();await editor.fill('Summarize the approved release check.');await expect(form.getByRole('button',{name:'Send message',exact:true})).toBeInViewport({ratio:1});await capture('child-controls-composer-compact');
  await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(editor).toHaveText('');await expect.poll(()=>model.calls.some(call=>call.messages?.some(message=>message.role==='user'&&message.content==='Summarize the approved release check.')),{timeout:15000}).toBe(true);proof.finalReplyObserved=true;
  const projects=join(userDataDir,'claude-code-profile/config/projects');proof.transcripts={};
  for(const kind of ['parent','child']){const sid=kind==='parent'?parentSessionId:proof.target.sessionId;for(const directory of(await readdir(projects,{withFileTypes:true})).slice(0,64)){if(!directory.isDirectory())continue;const path=join(projects,directory.name,sid+'.jsonl');let info;try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);await writeFile(join(output,'native-'+kind+'-transcript.jsonl'),raw);proof.transcripts[kind]={sessionId:sid,path,sha256:createHash('sha256').update(raw).digest('hex')};break;}assert.ok(proof.transcripts[kind]);}
  await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});
  const stopped=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(stopped.sessionId,proof.target.sessionId);assert.equal(stopped.state,'stopped');proof.nativeStopped={jobId:proof.target.jobId,sessionId:stopped.sessionId,state:stopped.state};proof.final=await context();proof.status='complete';await save();phase('original-child-controls-complete');
 } finally {
  const state=await context().catch(()=>null),sessionId=proof.target?.sessionId??state?.claude?.nativeContinuation?.continuedInSessionId;
  if(sessionId){const run=promisify(execFile),cliEnv={...env,CLAUDE_CONFIG_DIR:join(userDataDir,'claude-code-profile/config')};const rows=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024})).stdout);const owned=rows.find(row=>row.sessionId===sessionId&&row.cwd===project);if(owned&&owned.state!=='stopped'){await run('/frozen-claude/claude',['stop',owned.id],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024});proof.cleanupStoppedOwnedJob=true;}}
  await save();
 }
}
