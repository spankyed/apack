import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';

export function driveChildQuestionRejection(options) {
 return driveChildComposer({...options,modelTool:'TextOnly',modelOptions:{childControlScenario:true},modelRequestLimit:24,journey:rejectionJourney,journeyName:'question-rejection'});
}
async function rejectionJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const proof={status:'running',parentSessionId,scope:'Original owned child question rejection and fresh answer; no lifecycle disposal, rich form or full parity acceptance.',captures:[]};
 const save=()=>writeFile(join(output,'child-question-rejection.json'),JSON.stringify(proof,null,2));
 const capture=async name=>{await page.screenshot({path:join(output,name+'.png')});proof.captures.push(name+'.png');await save();};
 const result=stage=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_child_control_'+stage);
 try {
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill('/background ResearchChildControl1 Ask which release branch to review.');await card.getByRole('button',{name:'Send',exact:true}).click();
  const widget=page.getByRole('region',{name:'Background Claude session',exact:true});
  await expect(widget.getByRole('button',{name:'Answer question',exact:true})).toBeEnabled({timeout:25000});
  proof.running=await context();proof.target=proof.running.native.background.desktop;assert.ok(proof.target);assert.notEqual(proof.target.sessionId,parentSessionId);
  await composer.fill('Keep the release review notes while I reject this question.');const parentDraft=await composer.textContent();
  const panel=widget.getByRole('region',{name:'Claude Code questions',exact:true});await expect(panel).toHaveCount(0);proof.discoveredWithReplyClosed=true;
  await widget.getByRole('button',{name:'Answer question',exact:true}).click();await expect(panel).toBeVisible({timeout:15000});
  await panel.locator('input[value="Stable"]').check();
  for(const[name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(size);await expect(panel.getByRole('button',{name:'Reject question',exact:true})).toBeInViewport({ratio:1});await expect(panel.getByRole('button',{name:'Back to parent notes',exact:true})).toBeInViewport({ratio:1});await expect(panel.getByRole('button',{name:'Submit answers',exact:true})).toBeInViewport({ratio:1});await capture('child-question-rejection-'+name);
  }
  await panel.getByRole('button',{name:'Back to parent notes',exact:true}).click();await expect(composer).toBeFocused();await expect(composer).toHaveText(parentDraft);assert.equal(result(1),undefined);proof.notesReturnDidNotReject=true;
  await widget.getByRole('button',{name:'Answer question',exact:true}).click();await expect(panel.locator('input[value="Stable"]')).toBeChecked();
  const current=await context(),pair=Object.entries(current.ui).find(([,value])=>value.state?.question?.messageId);assert.ok(pair);proof.rejectedFrame={mountId:pair[0],...pair[1].state.question};
  await panel.getByRole('button',{name:'Reject question',exact:true}).click();await expect(panel).toHaveCount(0);
  // Original rejection ends the turn; inspect the persisted native result before new input.
  const journalRoot=join(userDataDir,'claude-code-profile/config/projects');
  const rejectedResult=async()=>{
   for(const directory of(await readdir(journalRoot,{withFileTypes:true})).slice(0,64)){
    if(!directory.isDirectory())continue;
    const path=join(journalRoot,directory.name,proof.target.sessionId+'.jsonl');let info;
    try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}
    assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);
    const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);
    const rows=raw.toString().split('\n').filter(Boolean).map(line=>JSON.parse(line));
    const found=rows.flatMap(row=>Array.isArray(row.message?.content)?row.message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_child_control_1');
    if(found){await writeFile(join(output,'native-rejected-question-transcript.jsonl'),raw);return found;}
   }
  };
  await expect.poll(rejectedResult,{timeout:15000}).toBeTruthy();proof.rejectedResult=await rejectedResult();assert.equal(proof.rejectedResult.is_error,true);assert.ok(proof.rejectedResult.content.includes('STOP what you are doing and wait'));

  const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');await expect(editor).toBeEditable();
  await editor.fill('ResearchChildControl4 Ask a fresh release branch question.');await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(panel).toBeVisible({timeout:15000});
  const fresh=await context(),newPair=Object.entries(fresh.ui).find(([,value])=>value.state?.question?.messageId);assert.ok(newPair);proof.freshFrame={mountId:newPair[0],...newPair[1].state.question};assert.notEqual(proof.freshFrame.messageId,proof.rejectedFrame.messageId);
  await page.evaluate(({threadId,mountId,messageId,token})=>window.applicationState.system.get('default-setup/threads').send({type:'CLAUDE_UI_QUESTION_REJECT',threadId,mountId,messageId,token}),{threadId:proof.running.threadId,mountId:proof.rejectedFrame.mountId,messageId:proof.rejectedFrame.messageId,token:proof.rejectedFrame.token});
  await expect(panel).toBeVisible();await panel.locator('input[value="Stable"]').check();await panel.getByRole('button',{name:'Submit answers',exact:true}).click();await expect(panel).toHaveCount(0);
  await expect.poll(()=>result(4),{timeout:15000}).toBeTruthy();proof.freshResult=result(4);assert.ok(!proof.freshResult.is_error&&JSON.stringify(proof.freshResult).includes('Stable'));proof.staleRejectionRefused=true;
  await expect.poll(async()=>(await context()).native?.background?.session?.status,{timeout:15000}).not.toBe('waiting');
  await expect(editor).toBeEditable();await editor.fill('Continue the release review after the fresh answer.');await capture('child-question-rejection-followup-compact');await form.getByRole('button',{name:'Send message',exact:true}).click();
  await expect.poll(()=>model.calls.some(call=>call.messages?.some(message=>message.role==='user'&&message.content==='Continue the release review after the fresh answer.')),{timeout:15000}).toBe(true);proof.followupObserved=true;
  const projects=join(userDataDir,'claude-code-profile/config/projects');proof.transcripts={};
  for(const kind of ['parent','child']){const sid=kind==='parent'?parentSessionId:proof.target.sessionId;for(const directory of(await readdir(projects,{withFileTypes:true})).slice(0,64)){if(!directory.isDirectory())continue;const path=join(projects,directory.name,sid+'.jsonl');let info;try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);await writeFile(join(output,'native-'+kind+'-transcript.jsonl'),raw);proof.transcripts[kind]={sessionId:sid,path,sha256:createHash('sha256').update(raw).digest('hex')};break;}assert.ok(proof.transcripts[kind]);}
  await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});
  const stopped=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(stopped.sessionId,proof.target.sessionId);assert.equal(stopped.state,'stopped');proof.nativeStopped={jobId:proof.target.jobId,sessionId:stopped.sessionId,state:stopped.state};proof.final=await context();proof.status='complete';await save();phase('original-child-question-rejection-complete');
 } finally {
  const state=await context().catch(()=>null),sessionId=proof.target?.sessionId??state?.claude?.nativeContinuation?.continuedInSessionId;
  if(sessionId){const run=promisify(execFile),cliEnv={...env,CLAUDE_CONFIG_DIR:join(userDataDir,'claude-code-profile/config')};const rows=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024})).stdout);const owned=rows.find(row=>row.sessionId===sessionId&&row.cwd===project);if(owned&&owned.state!=='stopped'){await run('/frozen-claude/claude',['stop',owned.id],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024});proof.cleanupStoppedOwnedJob=true;}}
  await save();
 }
}
