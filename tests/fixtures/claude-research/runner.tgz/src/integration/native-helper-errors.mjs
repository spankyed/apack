/** Diagnostic only: observe caught pack exceptions, resume immediately and change no app responses. */
export async function observeNativeHelperErrors(session,record,{limit=64}={}){
 let count=0;
 const post=(method,params={})=>new Promise((resolve,reject)=>session.post(method,params,(error,value)=>error?reject(error):resolve(value)));
 const paused=message=>{
  try{
   const {reason,data,callFrames=[]}=message.params??{},description=String(data?.description??'');
   const inPack=description.includes('default-setup/runtime/')||callFrames.some(frame=>frame.url?.includes('default-setup/runtime/'));
   if(reason==='exception'&&inPack&&count<limit)record({phase:'caught-pack-error',index:++count,monotonicNs:process.hrtime.bigint().toString(),description:description.slice(0,5000),frames:callFrames.slice(0,10).map(frame=>({functionName:frame.functionName,url:frame.url,lineNumber:frame.location?.lineNumber,columnNumber:frame.location?.columnNumber}))});
  }catch{ /* Diagnostic recording must not replace the app exception. */ }finally{session.post('Debugger.resume')}
 };
 session.connect();session.on('Debugger.paused',paused);
 await post('Debugger.enable');await post('Debugger.setPauseOnExceptions',{state:'all'});
 return async()=>{await post('Debugger.setPauseOnExceptions',{state:'none'});session.off('Debugger.paused',paused);await post('Debugger.disable');session.disconnect()};
}
