import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { probeSessionFork } from '../protocol/session-fork-probe.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { hash } from '../artifacts/runs.mjs';
const [checkout, executable, workspace] = process.argv.slice(2);
const native = await probeSessionFork(executable, workspace, workspace, {compact:true});
const manifest = JSON.parse(await readFile(join(native.initialRun, 'manifest.json')));
const cwd = manifest.inputs.cwd;
const { validateSessionResumeTarget } = await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/session-controls.ts')));
const model = await startSyntheticModel(cwd);
try {
  const options = {sessionId:native.originalId,cwd,cliPath:executable,
    env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),ANTHROPIC_BASE_URL:model.url,
      ANTHROPIC_API_KEY:'research-fixture-key',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',DISABLE_AUTOUPDATER:'1'}};
  await assert.rejects(validateSessionResumeTarget({...options,messageUuid:native.boundary}));
  await validateSessionResumeTarget({...options,messageUuid:native.postCompaction.boundary});
  assert.equal(model.calls.length,0);
  console.log(JSON.stringify({evidence:'apack-native-resume-target',targetSha256:hash(await readFile(executable)),
    oldRejected:true,currentAccepted:true,preflightApiRequests:model.calls.length,realModelRequests:0,native}));
} finally { await model.close(); }
