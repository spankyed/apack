import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {readFile,writeFile,readdir,lstat} from 'node:fs/promises';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';

const marker='ResearchChildQuestionReview';
export function driveChildQuestion(options) {
 return driveChildComposer({...options,modelTool:'AskUserQuestion',modelOptions:{questionAfterText:marker},journey:questionJourney,journeyName:'question'});
}
async function questionJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const proof={status:'running',parentSessionId,scope:'One original child basic question in the actual app; no full child control or parity claim.',sizes:[]};
 const save=()=>writeFile(join(output,'child-question.json'),JSON.stringify(proof,null,2));
 try {
 await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
 await composer.fill('/background '+marker+' Ask which release branch to review.');await card.getByRole('button',{name:'Send',exact:true}).click();
 const widget=page.getByRole('region',{name:'Background Claude session',exact:true});
 await expect(widget.getByRole('button',{name:'Stop background session',exact:true})).toBeEnabled({timeout:25000});
 await widget.getByRole('button',{name:'Refresh status',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.background?.question,{timeout:25000}).toBeTruthy();
 proof.running=await context();proof.target=proof.running.native.background.desktop;proof.pending=proof.running.native.background.question;
 assert.ok(proof.target);assert.notEqual(proof.target.sessionId,parentSessionId);
 const panel=widget.getByRole('region',{name:'Claude Code questions',exact:true});
 await expect(panel).toHaveCount(0);proof.discoveredWithReplyClosed=true;
 await composer.fill('Keep the parent question review notes here.');const parentDraft=await composer.textContent();
 await widget.getByRole('button',{name:'Answer question',exact:true}).click();
 await expect(panel).toBeVisible({timeout:15000});await expect(panel.getByText('Which synthetic fixture should be selected?',{exact:true})).toBeVisible();
 const alpha=panel.getByRole('radio',{name:'Alpha First fixture',exact:true});
 await alpha.check();await expect(alpha).toBeChecked();
 for(const [name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
  await page.setViewportSize(size);await expect(alpha).toBeInViewport({ratio:1});await expect(panel.getByRole('button',{name:'Submit answers',exact:true})).toBeInViewport({ratio:1});
  await panel.locator('.body').hover();await page.mouse.wheel(0,160);
  await expect(panel.locator('textarea').first()).toBeInViewport({ratio:1});
  await panel.locator('.body').hover();await page.mouse.wheel(0,-600);
  await expect(alpha).toBeInViewport({ratio:1});await expect(panel.getByRole('radio',{name:'Beta Second fixture',exact:true})).toBeInViewport({ratio:1});

  const geometry=await panel.evaluate(element=>{const r=element.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,viewport:{width:innerWidth,height:innerHeight},scrollWidth:element.scrollWidth,clientWidth:element.clientWidth,availableWidth:element.closest('.background-native-composer').clientWidth};});
  assert.ok(geometry.scrollWidth<=geometry.clientWidth);assert.ok(geometry.width>=geometry.availableWidth-2,'Question must fill its assigned workspace');proof.sizes.push({name,allChoicesVisible:true,customAnswerReachedByWheel:true,...geometry});await page.screenshot({path:join(output,'child-question-'+name+'.png')});await save();
 }
 await panel.getByRole('button',{name:'Back to parent notes',exact:true}).click();await expect(panel).toBeHidden();
 await expect(composer).toBeVisible();await expect(composer).toBeFocused();await expect(composer).toHaveText(parentDraft);proof.parentNotesReturned=true;
 await page.screenshot({path:join(output,'child-question-parent-notes-compact.png')});
 await widget.getByRole('button',{name:'Answer question',exact:true}).click();await expect(alpha).toBeChecked();proof.answerDraftRetained=true;
 await panel.getByRole('button',{name:'Submit answers',exact:true}).click();
 await expect(panel).toHaveCount(0,{timeout:15000});
 await expect.poll(async()=>(await context()).native?.background?.question,{timeout:15000}).toBeFalsy();proof.questionSettled=true;
 await expect.poll(async()=>(await context()).native?.background?.session?.status,{timeout:15000}).not.toBe('waiting');
 await expect(widget.getByText('input needed',{exact:true})).toHaveCount(0);proof.waitingStateRetired=true;proof.afterQuestion=await context();
 await expect(composer).toHaveText(parentDraft);
 await expect.poll(()=>model.calls.some(call=>call.messages?.some(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_research_fixture'&&!block.is_error&&JSON.stringify(block.content).includes('Alpha')))),{timeout:15000}).toBe(true);
 proof.nativeAnswerObserved=true;
 const form=widget.getByRole('form',{name:'Background session message',exact:true}), editor=form.locator('[contenteditable="true"]');
 await expect(editor).toBeEditable();await expect(editor).toBeInViewport({ratio:1});
 await editor.fill('Follow up after the release decision.');
 await expect(form.getByRole('button',{name:'Send message',exact:true})).toBeInViewport({ratio:1});
 await page.screenshot({path:join(output,'child-question-return-to-composer-compact.png')});
 await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(editor).toHaveText('',{timeout:15000});
 await expect.poll(()=>model.calls.some(call=>call.messages?.some(message=>message.role==='user'&&message.content==='Follow up after the release decision.')),{timeout:15000}).toBe(true);proof.composerReturnedAndReplyObserved=true;
 const projects=join(userDataDir,'claude-code-profile/config/projects');
 for(const directory of (await readdir(projects,{withFileTypes:true})).slice(0,64)){
  if(!directory.isDirectory())continue;
  const path=join(projects,directory.name,proof.target.sessionId+'.jsonl');let info;
  try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}
  assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);
  const source=await readFile(path,'utf8');assert.ok(Buffer.byteLength(source)<=8*1024*1024);
  await writeFile(join(output,'native-child-transcript.jsonl'),source);proof.nativeTranscript={path,sha256:createHash('sha256').update(source).digest('hex')};break;
 }
 assert.ok(proof.nativeTranscript);
 await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});
 const stopped=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(stopped.sessionId,proof.target.sessionId);assert.equal(stopped.state,'stopped');proof.nativeStopped={jobId:proof.target.jobId,sessionId:stopped.sessionId,state:stopped.state};
 proof.final=await context();proof.originalStop=true;proof.status='complete';await save();phase('child-question-journey-complete');
 } finally {
  const state=await context().catch(()=>null), sessionId=proof.target?.sessionId??state?.claude?.nativeContinuation?.continuedInSessionId;
  if(sessionId){
   const run=promisify(execFile),cliEnv={...env,CLAUDE_CONFIG_DIR:join(userDataDir,'claude-code-profile/config')};
   const rows=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024})).stdout);
   const owned=rows.find(row=>row.sessionId===sessionId&&row.cwd===project);
   if(owned&&owned.state!=='stopped'){await run('/frozen-claude/claude',['stop',owned.id],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024});proof.cleanupStoppedOwnedJob=true;}
  }
  await save();
 }
}
