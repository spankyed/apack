import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {prepareForeignNoticeProfile} from './foreign-notice-profile.mjs';
const trigger='Ask the plugin-owned release question.',questionText='Who should receive the release review?',note='Owner release policy remains authoritative.';
export async function driveForeignNotice(options){
 const profile=await prepareForeignNoticeProfile(options);
 try{
  await driveChildComposer({...options,modelRequestLimit:8,journey:foreignNoticeJourney,journeyName:'foreign-notice'});
  const output=join(options.workspace,'electron-results'),proof=JSON.parse(await readFile(join(output,'foreign-notice.json'),'utf8'));
  const root=join(options.setupWorkspace,'app-data/claude-code-profile/config/projects'),names=await readdir(root,{recursive:true}),matches=names.filter(n=>basename(n)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);
  await writeFile(join(output,'foreign-notice-native-transcript.jsonl'),await readFile(join(root,matches[0])));
 }finally{await profile.restore();}
}
async function foreignNoticeJourney({app,page,output,project,userDataDir,expect,phase}){
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.openedThreadId===null&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code')}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);
 await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.pendingThreadCwd)).toBe(project);
 await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id)}});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true}),question=page.getByTestId('native-question-panel');
 const proof={status:'running',captures:[],geometry:[],seed:'Help review the release notes.',trigger,draft:'Keep the release review draft.',followup:'Continue the release review for Operators.',scope:'Original-installed foreign notice ownership with held native ui.ask and same-session actual-app recovery; other owner/policy/lifetime cases remain open.'};
 const save=()=>writeFile(join(output,'foreign-notice.json'),JSON.stringify(proof,null,2));
 const capture=async(stage,controls)=>{for(const[name,size]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(size);for(const control of controls)await expect(control).toBeInViewport({ratio:1});const geometry=await Promise.all(controls.map(control=>control.boundingBox()));proof.geometry.push({stage,name,...size,controls:geometry});const file='foreign-notice-'+stage+'-'+name+'.png';await page.screenshot({path:join(output,file)});proof.captures.push(file);}await save();};
 const identity=async pid=>{const raw=await readFile('/proc/'+pid+'/stat','utf8');return raw.slice(raw.lastIndexOf(')')+2).split(' ')[19]};
 try{
  await composer.fill(proof.seed);await expect.poll(()=>page.evaluate(directory=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.mode==='Claude Code'&&c.phase==='Edit'&&c.pendingThreadCwd===directory;},project)).toBe(true);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
  proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.nativePid=proof.initial.native.state.nativePid;proof.processStart=await identity(proof.nativePid);
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await composer.fill(trigger);await send.click();
  await expect(question).toBeVisible({timeout:15000});await expect(question).toContainText(questionText);await expect(question.getByRole('note')).toContainText(note);await expect(page.getByText('FOREIGN_NOTICE_MUST_NOT_APPEAR',{exact:false})).toHaveCount(0);
  proof.questionBefore=await context();proof.holdStartedAt=Date.now();await save();phase('foreign-question-open');
  await capture('question',[question.getByRole('radio',{name:'Operators',exact:true}),question.getByRole('note'),question.getByRole('button',{name:'Submit answers',exact:true})]);
  await new Promise(resolve=>setTimeout(resolve,6000));proof.holdEndedAt=Date.now();proof.questionHeld=await context();
  await expect(question).toBeVisible();await expect(question.getByRole('note')).toContainText(note);assert.ok(!JSON.stringify(proof.questionHeld).includes('Native prompt bridge timed out'));assert.equal(await identity(proof.nativePid),proof.processStart);
  for(const name of ['owner','peer'])proof[name+'Enqueue']=JSON.parse(await readFile(join(project,'app-foreign-notice-'+name+'-enqueue.json'),'utf8'));assert.equal(proof.ownerEnqueue.toolUseId,proof.peerEnqueue.toolUseId);
  await capture('held',[question.getByRole('radio',{name:'Operators',exact:true}),question.getByRole('button',{name:'Submit answers',exact:true})]);
  await question.getByRole('radio',{name:'Operators',exact:true}).check();await question.getByRole('button',{name:'Submit answers',exact:true}).click();await expect(question).toBeHidden({timeout:15000});await expect(composer).toHaveText('');
  await expect.poll(async()=>(await context()).native?.state?.lastTurn?.reason,{timeout:15000}).toBe('answer');await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:15000}).toBe(false);
  proof.toolResult=JSON.parse(await readFile(join(project,'app-foreign-notice-owner-result.json'),'utf8'));assert.deepEqual(proof.toolResult,{toolUseId:proof.ownerEnqueue.toolUseId,result:'Operators'});
  proof.answered=await context();assert.equal(proof.answered.claude.sessionId,proof.sessionId);assert.equal(proof.answered.native.state.nativePid,proof.nativePid);
  await composer.fill(proof.followup);await send.click();await expect(composer).toHaveText('');await expect.poll(async()=>(await context()).claude?.turns,{timeout:15000}).toBe(3);await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:15000}).toBe(false);await expect.poll(async()=>(await context()).native?.state?.lastTurn?.id,{timeout:15000}).not.toBe(proof.answered.native.state.lastTurn.id);
  await composer.fill(proof.draft);await expect(send).toBeEnabled();await capture('recovered',[composer,send]);proof.final=await context();assert.equal(proof.final.claude.sessionId,proof.sessionId);assert.equal(proof.final.native.state.nativePid,proof.nativePid);assert.equal(await identity(proof.nativePid),proof.processStart);assert.ok(proof.final.claude.totalCostUsd>0);
  proof.retainedDraft=await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(async()=>{try{return await identity(proof.nativePid)!==proof.processStart}catch(e){if(e.code==='ENOENT')return true;throw e}},{timeout:15000}).toBe(true);
  proof.nativeWriterRetired=true;proof.status='complete';await save();phase('foreign-notice-complete');
 }finally{if(proof.status!=='complete'){proof.failure=await context().catch(()=>null);await page.screenshot({path:join(output,'foreign-notice-failure.png')}).catch(()=>{});}await save();}
}
