import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { basename, join } from 'node:path'
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs'
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs'
import { EFFORT_EVAL_ROUTE } from '../protocol/native-effort-rollout.mjs'
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs'
import { GOAL_PROPOSAL_CONDITION, GOAL_PROPOSAL_PROMPT, startSyntheticModel } from '../protocol/synthetic-model.mjs'
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs'
import { prepareNativeAppCliProfile } from './native-app-cli-profile.mjs'

const executable = '/frozen-claude/claude'
const pin = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
const sha = bytes => createHash('sha256').update(bytes).digest('hex')

export async function driveNativeGoalProposal({ checkout, workspace, env, decision }) {
  assert.ok(['accept', 'escape'].includes(decision))
  assert.equal(process.platform, 'linux')
  assert.equal(process.getuid(), 1000)
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-goal[0-9]+$/)
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'))
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly)
  assert.match(await readFile('/etc/hosts', 'utf8'), /^127\.0\.0\.1\s+api\.anthropic\.com(?:\s|$)/m)
  assert.equal(sha(await readFile(executable)), pin)

  const project = join(workspace, 'project')
  await mkdir(project)
  await writeFile(join(project, 'release-notes.md'), '# Release notes\n\nReview the rollback checklist.\n')
  execFileSync('/usr/bin/git', ['init', '--quiet', '-b', 'main'], {
    cwd: project, timeout: 5000,
    env: { PATH: '/usr/bin:/bin', HOME: workspace, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_NOSYSTEM: '1' },
  })
  const account = await configureNativeCreditAccount(workspace, 'oauth', { featureCache: 'native-defaults' })
  const profile = await prepareNativeAppCliProfile({ checkout, workspace, account, owned: true })
  const configFile = join(profile, '.claude.json')
  const config = JSON.parse(await readFile(configFile, 'utf8'))
  assert.equal(config.growthBookOverrides, undefined)
  assert.equal(config.cachedGrowthBookFeatures, undefined)
  await writeFile(configFile, JSON.stringify({ ...config, hasCompletedOnboarding: true }))
  const tls = await prepareNativeCreditTls(join(workspace, 'account-tls'))
  let model, billing
  try {
    model = await startSyntheticModel(workspace, 'ProposeGoal', { captureMessages: true, maxRequests: 12 })
    billing = await startNativeCreditBilling(tls, { goalProposalRollout: true })
    const launch = { ...env, ...account, NODE_EXTRA_CA_CERTS: tls.ca, ANTHROPIC_BASE_URL: model.url,
      DISABLE_AUTOUPDATER: '1', PATH: '/frozen-claude:' + env.PATH, CLAUDE_RESEARCH_PROJECT: project }
    for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'DISABLE_GROWTHBOOK',
      'CLAUDE_INTERNAL_FC_OVERRIDES', 'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC', 'DISABLE_TELEMETRY']) delete launch[key]
    await driveFreshNativeApp({
      checkout, workspace, env: launch, route: 'real-Electron-native-goal-proposal', journeyBudgetMs: 130000,
      journey: args => goalProposal({ ...args, decision, profile, model, billing }),
    })
  } finally {
    try {
      await writeFile(join(workspace, 'goal-proposal-model-calls.json'), JSON.stringify(model?.calls ?? [], null, 2))
      const evaluations = billing?.state.requests.filter(row => row.path === EFFORT_EVAL_ROUTE) ?? []
      await writeFile(join(workspace, 'goal-proposal-evaluation.json'), JSON.stringify(evaluations.map(({ status, syntheticAuth }) => ({ status, syntheticAuth })), null, 2))
    } finally {
      await Promise.all([model?.close(), billing?.close()])
    }
  }
}

async function goalProposal({ app, page, output, project, expect, userDataDir, decision, profile, model, billing }) {
  const installed = join(userDataDir, 'apack/packs/default-setup')
  const frozen = JSON.parse(await readFile('/control/producer-pack-inputs.json', 'utf8'))
  for (const file of ['runtime/fe.js', 'runtime/index.cjs']) assert.equal(sha(await readFile(join(installed, file))), frozen[file])
  const proof = { status: 'running', decision, captures: [] }
  const save = () => writeFile(join(output, 'goal-proposal.json'), JSON.stringify(proof, null, 2))
  const context = () => page.evaluate(() => {
    const data = window.applicationState.system.get('default-setup/threads').getSnapshot().context
    const threadId = data.currentThread?.id
    const view = Object.values(data.nativeTerminalViews).find(entry => entry.threadId === threadId)
    return { threadId, claude: data.currentThread?.context?.claudeCode, state: view?.state }
  })
  const card = page.locator('[data-onboarding-id="agent-chat-input"]')
  const editor = card.locator('[contenteditable="true"]')
  const send = card.getByRole('button', { name: 'Send', exact: true })
  const region = page.getByRole('region', { name: 'Claude native interface', exact: true })
  const offer = page.locator('[data-native-notice="goal_proposal"]')
  const decline = offer.getByRole('button', { name: 'Not now', exact: true })
  const accept = offer.getByRole('button', { name: 'Set this goal', exact: true })
  const editorState = () => editor.evaluate(element => {
    const { doc, selection } = element.editor.state
    return { doc: doc.toJSON(), selection: selection.toJSON() }
  })
  const submit = async text => {
    await editor.fill(text)
    await expect(editor).toHaveText(text)
    await send.click({ timeout: 10000 })
  }
  const nativeHistory = async () => {
    const directory = join(profile, 'projects')
    const paths = await readdir(directory, { recursive: true })
    const match = paths.filter(path => basename(path) === proof.owner.sessionId + '.jsonl')
    assert.equal(match.length, 1, 'Expected the original native journal')
    return readFile(join(directory, match[0]), 'utf8')
  }
  try {
    await app.waitForSurface('default-setup/threads')
    await app.navigate('host/settings')
    await page.evaluate(() => {
      const settings = window.applicationState.system.get('host/settings')
      settings.send({ type: 'TAB.SELECT', tab: 'general' })
      settings.send({ type: 'GENERAL_NAV.SELECT', item: 'secrets' })
    })
    await page.getByText('Claude Code CLI', { exact: true }).locator('..').locator('..').locator('..')
      .getByPlaceholder('Path override (auto-detected if empty)').fill(executable)
    await page.waitForTimeout(700)
    await app.navigate('default-setup/threads')
    await expect.poll(() => page.evaluate(() => window.applicationState.system.get('default-setup/threads')
      .getSnapshot().context.modes.some(mode => mode.name === 'Claude Code')), { timeout: 15000 }).toBe(true)
    await page.evaluate(directory => {
      const threads = window.applicationState.system.get('default-setup/threads')
      threads.send({ type: 'VIEW_DASHBOARD' })
      threads.send({ type: 'NEW_THREAD_IN_PROJECT', directory })
      threads.send({ type: 'SET_MODE', mode: 'Claude Code' })
      threads.send({ type: 'SET_PHASE', phase: 'Edit' })
    }, project)
    await submit('Read the release checklist.')
    await expect.poll(async () => (await context()).claude?.turns, { timeout: 30000 }).toBe(1)
    await region.getByRole('button', { name: 'Use native interface', exact: true }).click({ timeout: 10000 })
    const answered = new Set()
    const terminal = region.getByLabel('Terminal input', { exact: true })
    let trustNavigationAt
    proof.onboardingSteps = []
    for (let attempt = 0; attempt < 100 && (await context()).state?.status !== 'live'; attempt++) {
      const screen = () => region.locator('[data-terminal-text]').innerText({ timeout: 800 }).catch(() => '')
      const step = recognizeOnboardingPrompt(await screen(), project)
      const canNavigateTrust = step === 'workspace-trust'
        && (!trustNavigationAt || Date.now() - trustNavigationAt >= 1200)
        && proof.onboardingSteps.filter(previous => previous === 'workspace-trust').length < 3
      if (canNavigateTrust || step && step !== 'workspace-trust' && !answered.has(step)) {
        await terminal.focus()
        // The original trust picker can ignore input while its first render settles.
        // Recheck the exact workspace and selected choice before sending each key.
        await page.waitForTimeout(250)
        if (recognizeOnboardingPrompt(await screen(), project) === step) {
          await terminal.press(canNavigateTrust ? 'ArrowDown' : 'Enter')
          if (canNavigateTrust) trustNavigationAt = Date.now()
          else answered.add(step)
          proof.onboardingSteps.push(step)
        }
      }
      await page.waitForTimeout(100)
    }
    await expect.poll(async () => (await context()).state?.status, { timeout: 16000 }).toBe('live')
    const initial = await context()
    proof.owner = { threadId: initial.threadId, ownerId: initial.state.ownerId,
      sessionId: initial.state.sessionId, pid: initial.state.nativePid }
    assert.ok(proof.owner.pid)
    await region.getByRole('button', { name: 'Back to conversation', exact: true }).click({ timeout: 10000 })
    await expect.poll(() => billing.state.requests.some(row => row.syntheticAuth && row.path === EFFORT_EVAL_ROUTE && row.status === 200), { timeout: 15000 }).toBe(true)

    await submit(GOAL_PROPOSAL_PROMPT)
    await expect(offer).toBeVisible({ timeout: 20000 })
    await expect(offer).toContainText(GOAL_PROPOSAL_CONDITION)
    await expect.poll(() => model.calls.filter(row => row.goalProposalStep === 'ProposeGoal').length, { timeout: 8000 }).toBe(1)
    proof.notice = (await context()).state.notice
    assert.equal(proof.notice.kind, 'goal_proposal')
    assert.equal(proof.notice.sessionId, proof.owner.sessionId)

    const draft = 'Keep this release review draft.'
    await editor.fill(draft)
    await editor.press('Home')
    await editor.press('Shift+End')
    const before = await editorState()
    assert.notEqual(before.selection.anchor, before.selection.head)
    for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
      await page.setViewportSize(viewport)
      await expect(decline).toBeInViewport({ ratio: 1 })
      await expect(accept).toBeInViewport({ ratio: 1 })
      await expect(editor).toBeInViewport()
      await expect(editor).toBeFocused()
      const name = 'goal-proposal-' + size + '.png'
      await page.screenshot({ path: join(output, name), animations: 'disabled' })
      proof.captures.push(name)
    }
    assert.deepEqual(await editorState(), before)
    if (decision === 'escape') {
      await decline.focus()
      await expect(decline).toBeFocused()
      await decline.press('Escape')
    } else {
      await accept.focus()
      await accept.press('Enter')
    }
    await expect(offer).toBeHidden({ timeout: 15000 })
    await expect(editor).toBeFocused()
    assert.deepEqual(await editorState(), before)
    proof.retainedSelection = before.selection
    const goalSet = 'Goal set: ' + GOAL_PROPOSAL_CONDITION
    if (decision === 'accept') {
      await expect.poll(async () => (await nativeHistory()).includes(goalSet), { timeout: 16000 }).toBe(true)
    }
    await submit('Continue the release review with the existing notes.')
    await expect.poll(() => model.calls.some(row => row.messages?.some(message => JSON.stringify(message.content)
      .includes('Continue the release review with the existing notes.'))), { timeout: 15000 }).toBe(true)
    proof.goalSet = (await nativeHistory()).includes(goalSet)
    assert.equal(proof.goalSet, decision === 'accept')
    const final = await context()
    assert.equal(final.threadId, proof.owner.threadId)
    assert.equal(final.state.ownerId, proof.owner.ownerId)
    assert.equal(final.state.sessionId, proof.owner.sessionId)
    await region.getByRole('button', { name: 'Use native interface', exact: true }).click({ timeout: 10000 })
    await region.getByRole('button', { name: 'Stop session', exact: true }).click({ timeout: 10000 })
    await expect.poll(() => readFile('/proc/' + proof.owner.pid + '/stat', 'utf8').then(text => !text.includes(') Z '),
      error => { if (error.code === 'ENOENT') return false; throw error }), { timeout: 15000 }).toBe(false)
    proof.status = 'complete'
  } catch (error) {
    proof.status = 'failed'
    proof.failure = error.message
    throw error
  } finally {
    await save()
  }
}
