import {startTerminalPluginBridge} from '../protocol/terminal-plugin-bridge.mjs';
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import {StringDecoder} from 'node:string_decoder';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {record} from '../protocol/record.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
const [checkout,executable,workspace,scenario]=process.argv.slice(2);
assert.equal(process.platform,'darwin');assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const observeProcess=scenario==='observe-process';
const observations=join(workspace,'process-observations.jsonl'),preload=join(workspace,'process-observer.mjs');
if(observeProcess)await writeFile(preload,await readFile(new URL('../protocol/native-process-observer.mjs',import.meta.url)));
const marker=join(workspace,'subagent-status.jsonl'),helper=join(workspace,'subagent-status.py');
const helperSource=`import json,sys,time\nvalue=json.load(sys.stdin)\nwith open(${JSON.stringify(marker)},'a') as output:\n    output.write(json.dumps({'input':value,'at':time.time()})+chr(10))\nprint('deliberately non-JSON fixture line')\nprint(json.dumps({'id':'foreign-fixture-task','content':'ForeignRowShouldNotAppear'}))\nfor task in value['tasks']:\n    print(json.dumps({'id':task['id'],'content':'NativeSubagentDecorated '+task['status']}))\n`;
await writeFile(helper,helperSource);
const changedHelper=join(workspace,'subagent-status-changed.py');
if(observeProcess)await writeFile(changedHelper,helperSource.replace('NativeSubagentDecorated','NativeSubagentChanged 中文🙂'));
const settings={apiKeyHelper:'/usr/bin/printf research-fixture-key',subagentStatusLine:{type:'command',command:`/usr/bin/python3 '${helper.replaceAll("'","'\\''")}'`}};
const agents={'status-fixture':{description:'Disposable local status worker',prompt:'NativeStatusChildSystem. Return the requested fixed worker marker without tools.',tools:[],maxTurns:1}};
const mainHelper=join(workspace,'main-status.py');
await writeFile(mainHelper,"import json,sys\npayload=json.load(sys.stdin)\nprint('NativeCombinedStatus '+payload['session_id'])\n");
if(observeProcess)await writeFile(mainHelper,"import json,sys\npayload=json.load(sys.stdin)\nprint('NativeCombinedStatus '+payload['session_id']+' 中文🙂')\n");
const mainCommand=`/usr/bin/python3 '${mainHelper.replaceAll("'","'\\''")}'`;
settings.statusLine={type:'command',command:mainCommand,refreshInterval:1};
const settingsPath=join(workspace,'.claude/settings.json');
if(observeProcess){await mkdir(join(workspace,'.claude'),{recursive:true});await writeFile(settingsPath,JSON.stringify(settings));}
const pluginBridge=await startTerminalPluginBridge(workspace,{tasks:true,statusCommands:{[settings.subagentStatusLine.command]:'subagent',[mainCommand]:'main'}});
const originalStatusCommand=settings.subagentStatusLine.command;
const quote=value=>"'"+value.replaceAll("'","'\"'\"'")+"'";
if(!observeProcess)settings.subagentStatusLine.command=quote(pluginBridge.statusPrefix.path)+' '+quote(originalStatusCommand);
const model=await startSyntheticAgentModel();
const terminalDecoder=new StringDecoder('utf8');
let terminal='',theme=false,security=false,navigated=false,trusted=false,promptTyped=false,promptSubmitted=false,exitKeys=0,bound,changePromise,changed=false,changedObserved=false;const timers=[];
try{
 const bridge=fileURLToPath(new URL('../protocol/pty_bridge.py',import.meta.url));
 const pty=await record({executable:'/usr/bin/python3',cwd:workspace,output:join(workspace,'pty-runs'),timeoutMs:30000,
  args:[bridge,executable,'--plugin-dir',pluginBridge.pluginRoot,'--setting-sources',observeProcess?'user':'','--strict-mcp-config','--permission-mode','acceptEdits','--tools','Agent','--allowedTools','Agent','--agents',JSON.stringify(agents),...(observeProcess?[]:['--settings',JSON.stringify(settings)]),'--debug-file',join(workspace,'native-debug.log')],
  env:{...(observeProcess?{BUN_OPTIONS:'--preload='+preload,APACK_NATIVE_PROCESS_OBSERVER_FILE:observations}:{CLAUDE_CODE_SHELL_PREFIX:pluginBridge.statusPrefix.path}),PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),TERM:'xterm-256color',COLUMNS:'100',LINES:'30',ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
  onStdout(bytes,transport){
   terminal+=terminalDecoder.write(bytes);const screen=recognizeOnboardingPrompt(terminal,workspace);
   if(observeProcess&&changed&&!changedObserved){try{changedObserved=readFileSync(observations,'utf8').trim().split('\n').map(JSON.parse).some(value=>value.kind==='subagent'&&value.command===`/usr/bin/python3 '${changedHelper}'`&&value.stdout.includes('NativeSubagentChanged'));}catch(error){if(error.code!=='ENOENT')throw error;}}
   const compact=terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');let input;
   if(screen==='theme'&&!theme){theme=true;input='\r'}
   else if(screen==='security-notes'&&theme&&!security){security=true;input='\r'}
   else if(screen==='workspace-trust'&&!navigated){navigated=true;input='\x1b[B'}
   else if(screen==='workspace-trust-selected'&&navigated&&!trusted){trusted=true;input='\r'}
   else if(trusted&&!promptTyped&&compact.includes('APIUsageBilling')&&compact.includes('shift+tabtocycle')){promptTyped=true;
    if(observeProcess){const writes=readFileSync(join(workspace,'native-debug.log'),'utf8').split('\n').filter(line=>line.includes('File '+settingsPath+' written atomically'));assert.ok(writes.length);const until=Date.parse(writes.at(-1).slice(0,24))+5200;timers.push(setTimeout(()=>transport.send('NativeSubagentParentFixture: Run the disposable status worker.'),Math.max(0,until-Date.now())));}else input='NativeSubagentParentFixture: Run the disposable status worker.';}
   else if(promptTyped&&!promptSubmitted&&compact.includes('NativeSubagentParentFixture:')){promptSubmitted=true;input='\r'}
   else if(observeProcess&&promptSubmitted&&!changed&&terminal.includes('NativeSubagentDecorated')){changed=true;changePromise=writeFile(settingsPath,JSON.stringify({...settings,subagentStatusLine:{type:'command',command:`/usr/bin/python3 '${changedHelper}'`}}));}
   else if(promptSubmitted&&exitKeys===0&&(!observeProcess||changedObserved)&&compact.includes('ParentSubagentFixtureComplete')&&model.calls.filter(call=>call.hasAgentResult&&call.delivered).length===2&&model.calls.some(call=>call.child&&call.delivered)){exitKeys++;timers.push(setTimeout(()=>transport.send('\x04'),450))}
   else if(exitKeys===1&&/pressctrl[+-]dagaintoexit/i.test(compact)){exitKeys++;input='\x04'}
   if(input!==undefined){timers.push(setTimeout(()=>transport.send(input),150));clearTimeout(bound);bound=setTimeout(()=>transport.stop('subagent-status-step-bound'),16000)}
  }});
 if(changePromise)await changePromise;
 assert.equal(pty.status,'complete');assert.ok(promptSubmitted&&exitKeys>0);
 const payloads=(await readFile(marker,'utf8')).trim().split('\n').map(line=>JSON.parse(line));
 const rows=payloads.flatMap(value=>value.input.tasks);
 assert.ok(rows.some(task=>task.type==='local_agent'&&task.agentType==='status-fixture'&&task.status==='running'));
 assert.ok(rows.every(task=>typeof task.id==='string'&&task.id&&Array.isArray(task.tokenSamples)&&task.tokenSamples.length<=16));
 const snapshots=pluginBridge.agentEvidence;
 const mapped=snapshots.flatMap(snapshot=>snapshot.agents.map(agent=>({...agent,ownerSessionId:snapshot.sessionId})));
 assert.ok(mapped.some(agent=>agent.type==='status-fixture'&&agent.status==='running'&&rows.some(task=>task.id===agent.id)));
 assert.ok(mapped.some(agent=>agent.type==='status-fixture'&&agent.status==='completed'&&rows.some(task=>task.id===agent.id)));
 assert.ok(mapped.every(agent=>payloads.some(value=>value.input.session_id===agent.ownerSessionId)));
 const observed=observeProcess?(await readFile(observations,'utf8')).trim().split('\n').map(JSON.parse):pluginBridge.nativeStatusEvidence;
 const exports=observed.filter(value=>value.kind==='subagent');
 const mainExports=observed.filter(value=>value.kind==='main');
 assert.ok(mainExports.length>=2,'Main status must export and refresh alongside the native agent');
 assert.ok(mainExports.every(value=>value.code===0&&!value.truncated&&value.stdout==='NativeCombinedStatus '+value.sessionId+(observeProcess?' 中文🙂':'')+'\n'&&exports.some(sample=>sample.sessionId===value.sessionId)));
 assert.ok(terminal.includes('NativeCombinedStatus'));
 await writeFile(join(pty.directory,'native-main-status-export.json'),JSON.stringify(mainExports,null,2));
 assert.ok(exports.length>=1,'Native subagent status command must export its stdout');
 assert.ok(exports.every(value=>value.kind==='subagent'&&value.code===0&&!value.truncated&&(value.stdout.includes('NativeSubagentDecorated running')||observeProcess&&value.stdout.includes('NativeSubagentChanged'))&&value.taskIds.every(id=>rows.some(task=>task.id===id))&&payloads.some(sample=>sample.input.session_id===value.sessionId)));
 if(observeProcess){assert.equal(new Set([...mainExports,...exports].map(value=>value.parentPid)).size,1);assert.ok(exports.some(value=>value.stdout.split('\n').some(line=>{try{return JSON.parse(line).content?.includes('NativeSubagentChanged 中文🙂 running')}catch{return false}})));assert.ok(exports.some(value=>value.command===originalStatusCommand&&value.stdout.includes('NativeSubagentDecorated running')));assert.ok(exports.some(value=>value.command===`/usr/bin/python3 '${changedHelper}'`&&value.stdout.includes('NativeSubagentChanged')));assert.ok(exports.every(value=>payloads.some(sample=>JSON.stringify(sample.input)===JSON.stringify(value.input))));}
 await writeFile(join(pty.directory,'native-subagent-status-export.json'),JSON.stringify(exports,null,2));
 await writeFile(join(workspace,'terminal-agent-snapshots.json'),JSON.stringify(snapshots,null,2));
 await writeFile(join(workspace,'native-subagent-status-payloads.json'),JSON.stringify(payloads,null,2));
 assert.equal(model.calls.filter(call=>call.response==='Agent').length,1);assert.equal(model.calls.filter(call=>call.child).length,1);
 assert.ok(model.calls.some(call=>call.hasAgentResult&&!call.agentResultError));assert.equal(model.calls.length,5);assert.equal(model.calls.filter(call=>call.hasAgentResult&&call.delivered).length,2);assert.ok(model.calls.every(call=>call.delivered===true));
 const debug=await readFile(join(workspace,'native-debug.log'),'utf8');
 assert.ok(debug.includes('subagentStatusLine emitted non-JSON line'));
 assert.equal(terminal.includes('ForeignRowShouldNotAppear'),false);
 console.log(JSON.stringify({evidence:observeProcess?'apack-native-process-status':'apack-native-subagent-status',nativeStatusExport:true,nativeCommandSettingsUnchanged:observeProcess&&settings.subagentStatusLine.command===originalStatusCommand,nativeLiveSubagentCommandObserved:observeProcess,unicodeOutputPreserved:observeProcess,nativeStatusTransport:observeProcess?'passive native child-process observation':'native-invoked command wrapper',nativeStatusExports:exports.length,nativeMainStatusExports:mainExports.length,mainStatusOwnerCoexistence:true,statusPrefix:observeProcess?null:pluginBridge.statusPrefix,observerSha256:observeProcess?hash(await readFile(new URL('../protocol/native-process-observer.mjs',import.meta.url))):undefined,targetSha256:hash(await readFile(executable)),helperSha256:hash(Buffer.from(helperSource)),ptyRun:pty.directory,pluginSourceSha256:pluginBridge.pluginSourceSha256,bridgeHostSha256:hash(await readFile(new URL('../protocol/terminal-plugin-bridge.mjs',import.meta.url))),nativeTaskStatusIdentity:true,nativeTaskRunningObserved:true,nativeTaskCompletedObserved:true,nativeAgentSnapshots:snapshots.length,commandInvocations:payloads.length,taskCount:rows.length,taskTypes:[...new Set(rows.map(row=>row.type))],agentTypes:[...new Set(rows.map(row=>row.agentType))],statuses:[...new Set(rows.map(row=>row.status))],taskIds:[...new Set(rows.map(row=>row.id))],payloadKeys:Object.keys(payloads[0].input).sort(),rowKeys:[...new Set(rows.flatMap(row=>Object.keys(row)))].sort(),invalidLineLogged:true,foreignDecorationAbsent:true,decorationVisible:terminal.includes('NativeSubagentDecorated'),parentToolSucceeded:true,childResponseCompleted:true,parentResultReplies:2,syntheticApiRequests:model.calls.length,realModelRequests:0,userPromptsSent:1}));
}finally{await writeFile(join(workspace,'synthetic-agent-requests.json'),JSON.stringify(model.requests,null,2));clearTimeout(bound);for(const timer of timers)clearTimeout(timer);console.log(JSON.stringify({diagnostic:'synthetic-agent-calls',calls:model.calls}));await model.close();await pluginBridge.close()}
