import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {join} from 'node:path';

// /clear may trigger one original title-generation request before the first human turn.
function isResetTitleRequest(call, prompt) {
  if (call.toolNames?.length!==0||call.messages?.length!==1) return false;
  const [message]=call.messages;
  if(message.role!=='user'||!Array.isArray(message.content)||message.content.length!==1) return false;
  const [block]=message.content;
  const prefix='<session>\n'+prompt+'\n</session>\n\n';
  return block.type==='text'&&block.text?.startsWith(prefix)
    &&createHash('sha256').update(block.text.slice(prefix.length)).digest('hex')==='30704b4d05983bebf62600d91882d0f6c98a0748dc7ae578cece46864bb0f515';
}

/** Launch the original wizard as producer scaffolding; accept only the desktop activity Stop. */
export async function driveManagedScanJourney({app,page,expect,context,composer,send,section,replace,proof,workspace,userDataDir,output,model,birth,save,phase,clearBeforeStop=false,holdTaskPointerAcrossReset=false}) {
  proof.scope='Original auto-mode setup background scan desktop Stop and same-owner recovery; wizard terminal interactions are producer scaffolding, not desktop wizard acceptance. Uses an owned model provider and, when requested, an original hosted evaluation response on loopback. No task injection, patched native gates or real provider calls.';
  proof.draft='Keep the release notes while stopping the environment scan.';
  let expectedSessionId=proof.sessionId;
  const snapshot=()=>composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
  const sameOwner=async()=>{
    const value=await context();
    assert.equal(value.claude.sessionId,expectedSessionId);assert.equal(value.native.state.sessionId,expectedSessionId);
    assert.equal(value.native.state.ownerId,proof.initial.native.state.ownerId);
    assert.equal(value.native.state.nativePid,proof.pid);assert.equal(await birth(proof.pid),proof.processStart);return value;
  };
  const layout=async(stage,taskId)=>{
    for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
      await page.setViewportSize(viewport);await expect(composer).toHaveText(proof.draft);await expect(composer).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});
      const elements=[composer,send];
      if(taskId){
        const row=page.locator('[data-native-managed-task-id="'+taskId+'"]'),button=row.getByRole('button',{name:/^Stop /});
        if(size==='compact'){
          const transcript=page.getByTestId('chat-transcript');
          // The card follows the messages. Use the transcript's ordinary wheel path in the smaller split.
          await transcript.hover();
          await page.mouse.wheel(0,viewport.height);
        }
        await expect(button).toBeEnabled();await expect(button).toBeInViewport({ratio:1});elements.push(row,button);
      }
      const measure=()=>Promise.all(elements.map(element=>element.evaluate(e=>{
        const box=e.getBoundingClientRect();
        const hit=document.elementFromPoint(box.left+box.width/2,box.top+box.height/2);
        return {x:box.x,y:box.y,width:box.width,height:box.height,reachable:!!hit&&(e===hit||e.contains(hit)),
          hit:hit&&{tag:hit.tagName,testId:hit.getAttribute('data-testid'),label:hit.getAttribute('aria-label')}};
      })));
      let boxes;
      try {
        await expect.poll(async()=>{boxes=await measure();return boxes.every(box=>box.reachable)}).toBe(true);
      } catch(error) {
        const capture='native-managed-scan-'+stage+'-'+size+'-hit-target-failure.png';
        proof.layoutFailure={stage,size,boxes,capture};
        await page.screenshot({path:join(output,capture),animations:'disabled'});
        await save();
        throw error;
      }
      proof.layouts.push({stage,size,boxes});const file='native-managed-scan-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);await save();
    }
  };
  await replace('/auto-mode-setup');await send.click();
  const panel=page.getByRole('dialog',{name:'Native /auto-mode-setup panel',exact:true});
  await expect(panel).toBeVisible({timeout:15000});
  const input=panel.locator('[aria-label="Terminal input"]'),drawing=panel.locator('[data-terminal-text]');
  await expect.poll(()=>drawing.innerText(),{timeout:15000}).toContain('Teach auto mode about your environment?');
  proof.wizardBefore=await drawing.innerText();await input.focus();
  // Original normal-mode focus begins on the shell-history toggle. Disable it, leave repos
  // disabled, and advance to Continue. Respect the native fresh-keypress guard.
  for(const key of ['Space','ArrowDown','ArrowDown','Enter']){await page.waitForTimeout(300);await page.keyboard.press(key)}
  proof.wizardAfter=await drawing.innerText().catch(()=>'closed');await save();
  await expect.poll(async()=>(await sameOwner()).native.state.tasks.find(task=>task.kind==='managed'&&task.nativeTaskType==='auto_mode_scan'&&task.status==='running'&&task.canStop===true),{timeout:15000}).toBeTruthy();
  const state=await sameOwner(),task=state.native.state.tasks.find(task=>task.kind==='managed'&&task.nativeTaskType==='auto_mode_scan');
  proof.task=task;assert.ok(task.id);await expect(panel).toBeHidden({timeout:15000});
  await expect.poll(()=>model.calls.some(call=>call.managedScanHeld),{timeout:15000}).toBe(true);
  const held=model.calls.find(call=>call.managedScanHeld);assert.ok(held.proposalSchema.required.includes('remove_from_permissions_allow'));
  // The task registry can arrive ahead of the two original command journal rows.
  await expect.poll(async()=>{
    const {messages}=await sameOwner();
    return messages.map(message=>message.context?.claudeNativeCommand)
      .filter(command=>command?.name==='/auto-mode-setup'
        || command?.kind==='output'&&command.text==='Gathering data and drafting your auto-mode setup; back soon')
      .map(command=>command.kind);
  },{timeout:15000}).toEqual(['invocation','output']);
  if(clearBeforeStop){
    proof.scope='Original /clear preserves a held background scan while rotating the main conversation. Addressed previous-session Stop must be ignored; current desktop Stop and fresh native work must succeed.';
    proof.reset=await clearWithHeldScan({app,page,expect,context,send,replace,proof,task,held,model,userDataDir,holdTaskPointerAcrossReset,save});
    expectedSessionId=proof.reset.newSessionId;
    await sameOwner();await save();
  }
  await composer.fill(proof.draft);await composer.press('Home');for(let n=0;n<5;n++)await composer.press('ArrowRight');for(let n=0;n<12;n++)await composer.press('Shift+ArrowRight');
  await expect.poll(async()=> (await snapshot()).selection).toEqual({type:'text',anchor:6,head:18});
  proof.beforeStop=await sameOwner();proof.composerBeforeStop=await snapshot();const requestsBeforeStop=model.calls.length;
  await layout('running',task.id);
  assert.deepEqual(await snapshot(),proof.composerBeforeStop);
  const row=page.locator('[data-native-managed-task-id="'+task.id+'"]');
  const beforeStopDelivery=clearBeforeStop?(await taskDeliveries(userDataDir)).length:undefined;
  proof.stopClickedAt=Date.now();await row.getByRole('button',{name:/^Stop /}).click();
  if(beforeStopDelivery!==undefined)proof.stopDelivery=await nextTaskDelivery(userDataDir,beforeStopDelivery,expect);
  await expect.poll(()=>!!held.managedScanClosedAt,{timeout:15000}).toBe(true);
  await expect.poll(async()=>!(await sameOwner()).native.state.tasks.some(item=>item.id===task.id),{timeout:15000}).toBe(true);
  proof.afterStop=await sameOwner();assert.deepEqual(proof.afterStop.messages,proof.beforeStop.messages);assert.equal(proof.afterStop.claude.totalCostUsd,proof.beforeStop.claude.totalCostUsd);
  proof.composerAfterStop=await snapshot();assert.deepEqual(proof.composerAfterStop,proof.composerBeforeStop);
  await writeFile(join(workspace,'managed-scan-model-release'),'release');
  const releaseReceipt=join(workspace,'managed-scan-model-release-observed.json');
  await expect.poll(async()=>{
    const data=await readFile(releaseReceipt,'utf8').catch(error=>{
      if(error.code==='ENOENT')return undefined;
      throw error;
    });
    return data===undefined?false:JSON.parse(data).managedScanClosedBeforeRelease;
  },{timeout:5000}).toBe(true);
  proof.modelHold={...held};assert.equal(model.calls.length,requestsBeforeStop);await layout('stopped');
  proof.followup='Continue the release summary after stopping the environment scan.';await replace(proof.followup);await send.click();
  await expect.poll(async()=>{const c=await sameOwner();return c.claude.chatState==='success'&&c.native.state.busy===false&&c.messages.filter(m=>m.sender==='user'&&m.text===proof.followup).length===1},{timeout:15000}).toBe(true);
  if(clearBeforeStop){
    const fresh=model.calls.slice(requestsBeforeStop);
    const titles=fresh.filter(call=>isResetTitleRequest(call,proof.followup));
    const conversation=fresh.filter(call=>!titles.includes(call));
    assert.equal(conversation.length,1);
    assert.ok(titles.length<=1);
    assert.ok(JSON.stringify(conversation[0].messages).includes(proof.followup));
    assert.ok(fresh.every(call=>!JSON.stringify(call.messages).includes(proof.seed)));
    proof.resetRequests={conversational:conversation.length,title:titles.length};
  }
  await composer.fill(proof.draft);proof.final=await sameOwner();assert.equal(proof.final.claude.totalCostUsd,proof.final.native.state.session.totalCostUsd);await layout('recovered');
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
  proof.stopped=true;proof.status='complete';await save();phase('native-managed-scan-complete');
}

async function clearWithHeldScan({app,page,expect,context,send,replace,proof,task,held,model,userDataDir,holdTaskPointerAcrossReset,save}) {
  const original=await context();
  const requestCount=model.calls.length;
  const awaitRotation=()=>expect.poll(async()=>{
    const current=await context();
    const nextSession=current.claude?.sessionId;
    const clearInvocations=current.messages.filter(message=>{
      const command=message.context?.claudeNativeCommand;
      return command?.kind==='invocation'&&command.name==='/clear';
    });
    // /clear can replace the submission view while retaining the writer and managed task.
    return !!nextSession&&nextSession!==proof.sessionId
      && current.claude.previousSessionIds?.includes(proof.sessionId)
      && current.native?.state?.sessionId===nextSession&&current.native.state.status==='live'
      && clearInvocations.length===1;
  },{timeout:15000}).toBe(true);
  await replace('/clear');
  const taskArrivalsBeforePointer=holdTaskPointerAcrossReset?(await taskDeliveries(userDataDir)).length:undefined;
  const pointer=holdTaskPointerAcrossReset
    ? await holdManagedStopThroughClear({page,expect,send,task,awaitRotation,record:async result=>{
      proof.resetPointer={...result,taskArrivalsBeforePointer,taskArrivalsAfterPointer:(await taskDeliveries(userDataDir)).length};
      await save();
    }})
    : undefined;
  if(!pointer){await send.click();await awaitRotation();}
  const afterClear=await context();
  const newSessionId=afterClear.claude.sessionId;
  assert.equal(afterClear.threadId,original.threadId);
  assert.equal(afterClear.native.state.ownerId,original.native.state.ownerId);
  assert.equal(afterClear.native.state.nativePid,proof.pid);
  assert.ok(afterClear.claude.previousSessionIds.includes(proof.sessionId));
  assert.deepEqual(afterClear.native.state.tasks.find(item=>item.id===task.id),task);
  assert.equal(model.calls.length,requestCount);
  assert.equal(held.managedScanClosedAt,undefined);

  const lease=await page.evaluate(({threadId,sessionId})=>{
    const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    const mounted=Object.entries(c.nativeTerminalViews).find(([,view])=>view.threadId===threadId&&view.state?.sessionId===sessionId);
    if(!mounted)throw new Error('Native task view is missing for the current session');
    return {mountId:mounted[0],revision:(mounted[1].task?.revision??0)+1};
  },{threadId:afterClear.threadId,sessionId:newSessionId});
  const stale={type:'CLAUDE_TERMINAL_TASK',threadId:afterClear.threadId,...lease,ownerId:original.native.state.ownerId,
    sessionId:proof.sessionId,taskId:task.id,operation:'stop'};
  const beforeDelivery=(await taskDeliveries(userDataDir)).length;
  await app.sendEvent({type:'SEND_TO_SURFACE',surface:'default-setup/threads',events:[stale]});
  const delivery=await nextTaskDelivery(userDataDir,beforeDelivery,expect);
  const afterStale=await context();
  assert.deepEqual(afterStale.native.task,afterClear.native.task);
  assert.deepEqual(afterStale.native.state.tasks.find(item=>item.id===task.id),task);
  assert.equal(held.managedScanClosedAt,undefined);
  assert.equal(model.calls.length,requestCount);
  return {newSessionId,afterClear,stale,delivery,backendDelivered:true,staleTaskUnchanged:true,requestCount,...(pointer&&{pointer:proof.resetPointer})};
}


async function holdManagedStopThroughClear({page,expect,send,task,awaitRotation,record}){
  const stop=page.locator('[data-native-managed-task-id="'+task.id+'"]').getByRole('button',{name:/^Stop /});
  const position=async()=>{
    await stop.scrollIntoViewIfNeeded();
    await expect(stop).toBeEnabled();
    const box=await stop.boundingBox();
    assert.ok(box);
    const point={x:box.x+box.width/2,y:box.y+box.height/2};
    assert.ok(await stop.evaluate((button,point)=>button.contains(document.elementFromPoint(point.x,point.y)),point));
    return point;
  };
  const previous=await position();
  await stop.evaluate(button=>{
    const receipt={button,events:[],stop:null};
    const observer=event=>{
      if(event.target instanceof Element&&event.target.closest('[data-native-managed-task-id] button')?.getAttribute('aria-label')===button.getAttribute('aria-label')){
        receipt.events.push({type:event.type,trusted:event.isTrusted,oldTarget:button.contains(event.target)});
      }
    };
    for(const type of ['pointerdown','pointerup','click'])document.addEventListener(type,observer,true);
    receipt.stop=()=>{for(const type of ['pointerdown','pointerup','click'])document.removeEventListener(type,observer,true)};
    window.__managedResetPointer=receipt;
  });

  await page.mouse.move(previous.x,previous.y);
  await page.mouse.down();
  let released=false;
  try{
    // Activating the composer button with Enter leaves the real pointer gesture on the activity row.
    await send.press('Enter');
    await awaitRotation();
    const next=await position();
    const retired=await stop.evaluate(button=>{
      const previous=window.__managedResetPointer.button;
      return previous!==button&&!previous.isConnected;
    });
    await page.mouse.move(next.x,next.y);
    await page.mouse.up();
    released=true;
    const events=await page.evaluate(()=>window.__managedResetPointer.events);
    const result={previous,next,retired,events};
    await record(result);
    assert.equal(retired,true,'Pre-reset Stop remained the current DOM target');
    assert.deepEqual(events,[
      {type:'pointerdown',trusted:true,oldTarget:true},
      {type:'pointerup',trusted:true,oldTarget:false},
    ]);
    return result;
  }finally{
    try{
      if(!released){await page.mouse.move(1,1);await page.mouse.up()}
    }finally{
      await page.evaluate(()=>{window.__managedResetPointer?.stop();delete window.__managedResetPointer});
    }
  }
}

async function taskDeliveries(userDataDir) {
  const raw=await readFile(join(userDataDir,'apack/logs/app-events.log'),'utf8');
  assert.ok(raw.length<16*1024*1024);
  const rows=raw.slice(0,raw.lastIndexOf('\n')).split('\n').filter(Boolean).map(JSON.parse);
  return rows.filter(row=>row.source==='app-events'&&row.message==='→ Incoming: "CLAUDE_TERMINAL_TASK"'
    &&row.meta?.from==='default-setup'&&row.meta?.to==='default-setup/threads');
}

async function nextTaskDelivery(userDataDir,before,expect) {
  // The host records the event type and endpoints, intentionally omitting the payload.
  // This private app drives one task request between the two log observations.
  await expect.poll(async()=>(await taskDeliveries(userDataDir)).length-before).toBe(1);
  const [row]= (await taskDeliveries(userDataDir)).slice(before);
  return {index:before,timestamp:row.timestamp,startupId:row.startupId,source:row.source,message:row.message,meta:row.meta};
}
