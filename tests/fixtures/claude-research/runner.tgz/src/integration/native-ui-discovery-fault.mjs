import assert from 'node:assert/strict';
import {watch} from 'node:fs';
import {readdir,readFile,rename,stat,writeFile} from 'node:fs/promises';
import {createServer,request as httpRequest} from 'node:http';
import {join} from 'node:path';

/** Owned Linux acceptance fixture: lose one successful native metadata reply, never an action. */
export async function prepareNativeUiDiscoveryFault({output,directory='/tmp'}) {
 assert.equal(process.platform,'linux','Native transport fault fixtures execute only in offline Linux');
 const baseline=new Set(await readdir(directory)),watchers=new Map(),servers=new Set(),rows=[];
 let stopped=false,claimed,failed=false,faultPending=false,work=Promise.resolve();
 const receipt=()=>writeFile(join(output,'native-ui-discovery-fault.json'),JSON.stringify({failed,claimed,rows},null,2));
 const missing=error=>error.code==='ENOENT';
 async function install(name){
  if(stopped||claimed||baseline.has(name)||!name.startsWith('cc-app-'))return;
  const root=join(directory,name),socket=join(root,'ui.sock'),upstream=join(root,'ui-discovery-upstream.sock');
  let config;
  try{config=JSON.parse(await readFile(join(root,'observer.json'),'utf8'));if(!(await stat(socket)).isSocket())return;}
  catch(error){if(missing(error)||error instanceof SyntaxError)return;throw error;}
  assert.equal(config.uiSocketPath,socket);assert.equal(typeof config.token,'string');
  claimed=root;
  await rename(socket,upstream);
  const server=createServer(async(req,res)=>{
   let active;
   try{
    const chunks=[];for await(const chunk of req)chunks.push(chunk);const body=Buffer.concat(chunks);
    const value=JSON.parse(body.toString());
    assert.equal(req.headers['x-apack-native-token'],config.token);
    const subtype=value.request?.subtype;
    active=httpRequest({socketPath:upstream,path:req.url,method:req.method,headers:req.headers},reply=>{
     if(subtype!=='apack_ui_capabilities'||failed||faultPending){res.writeHead(reply.statusCode,reply.headers);reply.pipe(res);return;}
     faultPending=true;
     const parts=[];reply.on('data',chunk=>parts.push(chunk));reply.on('error',error=>res.destroy(error));
     reply.on('end',()=>{
      try{
       const original=JSON.parse(Buffer.concat(parts).toString());
       assert.equal(reply.statusCode,200);assert.equal(original.id,value.id);assert.equal(original.pid,value.ownerPid);assert.equal(original.sessionId,value.sessionId);
       assert.ok(Array.isArray(original.result?.capabilities));
       failed=true;rows.push({subtype,sequence:value.sequence,pid:original.pid,sessionId:original.sessionId,nativeStatus:reply.statusCode,outcome:'one-native-success-reply-withheld'});
       void receipt().catch(error=>server.emit('error',error));
       res.writeHead(400,{'content-type':'application/json'});res.end(JSON.stringify({id:original.id,pid:original.pid,sessionId:original.sessionId,error:'Owned acceptance fixture withheld the first native capability reply'}));
      }catch(error){res.destroy(error);}
     });
    });
    active.on('error',error=>res.destroy(error));res.once('close',()=>{if(!res.writableFinished)active.destroy();});
    if(subtype==='apack_ui_capabilities'&&failed){rows.push({subtype,sequence:value.sequence,pid:value.ownerPid,sessionId:value.sessionId,outcome:'forwarded-fresh-native-discovery'});void receipt().catch(error=>server.emit('error',error));}
    active.end(body);
   }catch(error){active?.destroy();res.destroy(error);}
  });
  servers.add(server);
  // Record asynchronous fixture failures for the journey without uncaught-error process exits.
  server.on('error',error=>{rows.push({outcome:'fixture-error',message:error.message});});
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(socket,resolve);});
  await receipt();
 }
 const enqueue=name=>{work=work.then(()=>install(name));work.catch(()=>{});};
 const rootWatcher=watch(directory,(_event,file)=>{
  const name=String(file??'');if(stopped||baseline.has(name)||!name.startsWith('cc-app-'))return;
  if(!watchers.has(name)){
   try{const observer=watch(join(directory,name),()=>enqueue(name));observer.on('error',error=>{if(!missing(error))rows.push({outcome:'watch-error',message:error.message});});watchers.set(name,observer);}
   catch(error){if(!missing(error))rows.push({outcome:'watch-error',message:error.message});}
  }
  enqueue(name);
 });
 return {
  async inspect(){await work;await receipt();return{failed,claimed,rows:[...rows]};},
  async close(){
   stopped=true;rootWatcher.close();for(const watcher of watchers.values())watcher.close();await work;
   for(const server of servers)await new Promise(resolve=>server.close(resolve));
   if(claimed){try{await rename(join(claimed,'ui-discovery-upstream.sock'),join(claimed,'ui.sock'));}catch(error){if(!missing(error))throw error;}}
   await receipt();
  },
 };
}
