import assert from 'node:assert/strict';
import {readFile,rename,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {channelEchoTool,channelRelayPrompts,channelRelayRequest,channelRelayReply} from '../protocol/owned-channel-relay.mjs';
import {channelSelector,channelServer} from './owned-channel-installation.mjs';

export async function driveOwnedChannelReplacement({page,expect,context,composer,send,section,replace,proof,output,debug,debugPrefix,receipts,relayDirectory,model,birth,save,phase}) {
  proof.scope='A reply addressed to a stopped CLI must not authorize a fresh approval after same-session reopen.';
  const registration='MCP server "'+channelServer+'": Channel notifications registered';
  const readLog=path=>readFile(path,'utf8').catch(error=>{if(error.code==='ENOENT')return '';throw error;});
  const waitForRegistration=path=>expect.poll(async()=>(await readLog(path)).includes(registration),{timeout:18000}).toBe(true);
  const frames=async()=> {
    const text=await readLog(receipts);
    return text.slice(0,text.lastIndexOf('\n')+1).split('\n').filter(Boolean).map(JSON.parse);
  };
  const calls=async()=> (await frames()).filter(frame=>frame.direction==='in'&&frame.value.method==='tools/call');
  const approval=page.getByRole('region',{name:channelEchoTool+' approval',exact:true});
  const show=section.getByRole('button',{name:'Use native interface',exact:true});
  const back=section.getByRole('button',{name:'Back to conversation',exact:true});
  const stop=section.getByRole('button',{name:'Stop session',exact:true});
  const originalToolResult=(id)=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>
    Array.isArray(message.content)?message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id===id);
  const takeOffer=async(prompt,ownerId,number)=>{
    await replace(prompt);
    await send.click();
    await expect(approval).toBeVisible();
    const offers=async()=> (await frames()).filter(frame=>frame.direction==='in'&&frame.value.method===channelRelayRequest);
    await expect.poll(async()=> (await offers()).length,{timeout:12000}).toBe(number);
    const frame=(await offers()).at(-1);
    const pending=(await context()).claude.pendingControlRequest;
    assert.equal(pending.nativeTerminal.ownerId,ownerId);
    assert.equal(pending.toolName,channelEchoTool);
    assert.equal(frame.value.params.tool_name,channelEchoTool);
    assert.equal((await calls()).length,0);
    return {peerPid:frame.pid,peerStart:await birth(frame.pid),requestId:frame.value.params.request_id,approvalId:pending.approvalMessageId};
  };
  await waitForRegistration(debug);
  const initialOwner=proof.initial.native.state.ownerId;
  proof.retiredOffer=await takeOffer(channelRelayPrompts[0],initialOwner,1);
  assert.ok(proof.retiredOffer.peerStart);
  await save();
  await show.click();
  await stop.click();
  await expect.poll(()=>birth(proof.pid),{timeout:15000}).not.toBe(proof.processStart);
  await expect.poll(()=>birth(proof.retiredOffer.peerPid),{timeout:15000}).not.toBe(proof.retiredOffer.peerStart);
  if(await back.isVisible())await back.click();
  await expect(approval).toHaveCount(0);
  await expect.poll(async()=> (await context()).claude.pendingControlRequest??null).toBe(null);

  await replace(proof.draft);
  await show.click();
  await expect.poll(async()=> (await context()).native?.state?.status,{timeout:24000}).toBe('live');
  const reopened=await context(), native=reopened.native.state;
  const start=await birth(native.nativePid);
  proof.resumedWriter={pid:native.nativePid,start,ownerId:native.ownerId};
  assert.ok(start);
  assert.notEqual(native.ownerId,initialOwner);
  assert.notEqual(native.nativePid,proof.pid);
  assert.equal(reopened.threadId,proof.initial.threadId);
  assert.equal(reopened.claude.sessionId,proof.sessionId);
  assert.deepEqual(reopened.claude.nativeLaunch.channels,[channelSelector]);
  const freshLog=debugPrefix+'.'+native.nativePid+'.log';
  await waitForRegistration(freshLog);
  await back.click();
  await expect(composer).toHaveText(proof.draft);
  phase('native-channel-replacement-owner-live');

  proof.freshOffer=await takeOffer(channelRelayPrompts[2],native.ownerId,2);
  assert.ok(proof.freshOffer.peerStart);
  assert.notEqual(proof.freshOffer.peerPid,proof.retiredOffer.peerPid);
  assert.notEqual(proof.freshOffer.requestId,proof.retiredOffer.requestId);
  assert.notEqual(proof.freshOffer.approvalId,proof.retiredOffer.approvalId);
  const answer=async(slot,requestId)=>{
    const path=join(relayDirectory,'replacement-'+proof.freshOffer.peerPid+'-'+slot+'.json');
    await writeFile(path+'.pending',JSON.stringify({requestId}),{flag:'wx'});
    await rename(path+'.pending',path);
  };
  const verdict=(id,label)=>expect.poll(async()=>(await readLog(freshLog)).includes(
    'notifications/claude/channel/permission: '+id+' → allow ('+label),{timeout:8000}).toBe(true);

  await answer(1,proof.retiredOffer.requestId);
  await verdict(proof.retiredOffer.requestId,'no pending entry');
  assert.equal((await context()).claude.pendingControlRequest.approvalMessageId,proof.freshOffer.approvalId);
  assert.equal((await calls()).length,0);
  for(const [name,width,height] of [['normal',1100,900],['compact',680,600]]){
    await page.setViewportSize({width,height});
    await expect(approval.getByRole('button',{name:'Deny',exact:true})).toBeInViewport({ratio:1});
    const capture='native-channel-replacement-'+name+'.png';
    await page.screenshot({path:join(output,capture),animations:'disabled'});
    proof.captures.push(capture);
  }
  proof.staleRefused=true;
  await save();
  await answer(2,proof.freshOffer.requestId);
  await verdict(proof.freshOffer.requestId,'matched pending');
  await expect(approval).toHaveCount(0);
  await expect.poll(()=>!!originalToolResult('toolu_owned_relay_3'),{timeout:15000}).toBe(true);
  assert.ok(JSON.stringify(originalToolResult('toolu_owned_relay_3').content).includes(channelRelayReply));
  const executed=await calls();
  assert.equal(executed.length,1);
  assert.equal(executed[0].pid,proof.freshOffer.peerPid);
  assert.deepEqual(executed[0].value.params.arguments,{message:'Owned release echo 3'});
  await expect.poll(async()=>{
    const state=await context();
    return !state.native.state.busy&&!state.claude.pendingControlRequest&&state.claude.chatState==='success';
  },{timeout:15000}).toBe(true);
  await replace(proof.draft);
  const final=await context();
  assert.equal(final.claude.sessionId,proof.sessionId);
  assert.equal(final.native.state.ownerId,native.ownerId);
  await show.click();
  await stop.click();
  await expect.poll(()=>birth(native.nativePid),{timeout:15000}).not.toBe(start);
  await expect.poll(()=>birth(proof.freshOffer.peerPid),{timeout:15000}).not.toBe(proof.freshOffer.peerStart);
  proof.freshExecuted=executed[0];
  proof.writersRetired=true;
  proof.status='complete';
  await save();
  phase('native-channel-replacement-complete');
}
