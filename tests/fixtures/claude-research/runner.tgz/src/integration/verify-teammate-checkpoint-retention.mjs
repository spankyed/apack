import assert from 'node:assert/strict'
import { execFile, spawn } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { once } from 'node:events'
import { mkdtemp, rm } from 'node:fs/promises'
import { createRequire, registerHooks } from 'node:module'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { promisify } from 'node:util'

assert.equal(process.platform, 'linux')
assert.ok(process.getuid() !== 0, 'Use an unprivileged disposable fixture user')
const require = createRequire('/work/packages/default-setup/package.json')
const zod = pathToFileURL(require.resolve('zod')).href
const prior = import.meta.resolve('./before.ts')
const next = import.meta.resolve('./candidate.ts')
registerHooks({
  resolve(specifier, context, resolve) {
    if (context.parentURL === prior || context.parentURL === next) {
      if (specifier === 'zod') return resolve(zod, context)
      if (specifier === './background-attachment.ts') return resolve('data:text/javascript,export function openClaudeTerminalAttachment(){throw Error("The checkpoint test must not open a client")}', context)
    }
    return resolve(specifier, context)
  },
})
const old = await import(prior)
const fixed = await import(next)
const session = randomUUID()
const owner = randomUUID()
const nextOwner = randomUUID()
const workspace = await mkdtemp(join(tmpdir(), 'apack-cc-recovery-'))
const socket = join(workspace, 'tmux')
const executable = '/fixture/bin/tmux'
const env = { PATH: '/usr/bin:/bin', HOME: workspace, TERM: 'xterm-256color' }
const execute = promisify(execFile)
const tmux = (...args) => execute(executable, ['-f', '/dev/null', '-S', socket, ...args], { env, cwd: workspace, timeout: 5000 }).then(({ stdout }) => stdout.trim())
const check = AbortSignal.timeout(4000)
const scope = () => ({ profile: workspace, threadId: randomUUID(), sessionId: session })
const startWriter = async () => {
  const child = spawn('/bin/sleep', ['25'], { env, stdio: 'ignore' })
  await once(child, 'spawn')
  return child
}
async function stopWriter(child) {
  if (child.exitCode !== null || child.signalCode !== null) return
  const done = once(child, 'exit')
  child.kill()
  await done
}

const scopes = []
let activeWriter
let retiredWriter
try {
  const firstPane = await tmux('new-session', '-d', '-P', '-F', '#{pane_id}', '-s', 'claude-swarm', 'sleep 25')
  const sessionId = await tmux('display-message', '-p', '-t', 'claude-swarm', '#{session_id}')
  const firstWindow = await tmux('display-message', '-p', '-t', firstPane, '#{window_id}')
  const secondPane = await tmux('new-window', '-P', '-F', '#{pane_id}', '-t', sessionId, 'sleep 25')
  const secondWindow = await tmux('display-message', '-p', '-t', secondPane, '#{window_id}')
  const activeWindow = () => tmux('display-message', '-p', '-t', 'claude-swarm', '#{window_id}')
  assert.equal(await activeWindow(), secondWindow)
  activeWriter = await startWriter()
  retiredWriter = await startWriter()
  const identify = (taskId, paneId, writer) => fixed.identifyClaudeRecoveryPane({
    ownerId: owner, sessionId: session, taskId, name: taskId, executable, cwd: workspace, tmuxSession: sessionId, paneId,
  }, writer.pid, ['-S', socket], env, check)
  const inactive = await identify('inactive', firstPane, retiredWriter)
  const waitingForWriter = await identify('waiting-for-writer', secondPane, activeWriter)
  const newAttachment = { ...waitingForWriter, ownerId: nextOwner, taskId: 'new-attachment' }
  await stopWriter(retiredWriter)
  const inactiveRecovery = fixed.createClaudeTeammateRecovery(inactive, env)
  const writerRecovery = fixed.createClaudeTeammateRecovery(waitingForWriter, env)
  assert.equal(await inactiveRecovery.canReconnect(check), false, 'A live worker in an inactive window is not yet reconnectable')
  assert.equal(await writerRecovery.canReconnect(check), false, 'A live writer still owns the worker')

  async function recordsAfterSave(module) {
    const target = scope()
    scopes.push(target)
    const stale = { ...inactive, taskId: 'stale-process', worker: [inactive.worker[0], String(BigInt(inactive.worker[1]) + 1n)] }
    const oldBoot = { ...inactive, taskId: 'stale-boot', bootId: randomUUID() }
    await module.saveClaudeTeammateCheckpoint(target, [inactive, waitingForWriter, stale, oldBoot], env)
    await module.saveClaudeTeammateCheckpoint(target, [newAttachment], env)
    return (await module.readClaudeTeammateCheckpoint(target)).map(record => record.taskId)
  }

  assert.deepEqual(await recordsAfterSave(old), ['new-attachment'])
  assert.deepEqual(await recordsAfterSave(fixed), ['inactive', 'waiting-for-writer', 'new-attachment'])
  await tmux('select-window', '-t', firstWindow)
  assert.equal(await inactiveRecovery.canReconnect(AbortSignal.timeout(4000)), true)
  await tmux('select-window', '-t', secondWindow)
  await stopWriter(activeWriter)
  assert.equal(await writerRecovery.canReconnect(AbortSignal.timeout(4000)), true)
  console.log(JSON.stringify({ before: 'both recoverable records lost', after: 'both retained and reconnectable later', removed: ['stale-process', 'stale-boot'], usedRealTmux: true }))
} finally {
  for (const child of [activeWriter, retiredWriter]) if (child) await stopWriter(child)
  await Promise.all(scopes.map(async target => {
    await fixed.clearClaudeTeammateCheckpoint(target, owner)
    await fixed.clearClaudeTeammateCheckpoint(target, nextOwner)
  }))
  await tmux('kill-server').catch(() => {})
  await rm(workspace, { recursive: true, force: true })
}
