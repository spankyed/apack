import assert from 'node:assert/strict';
import {readFile,writeFile,mkdtemp,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {configureNativeCreditAccount,nativeCreditAdmissionObserver} from '../protocol/native-credit-account.mjs';

const [executable,root,hashFile,billingMode]=process.argv.slice(2);
assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000,'Run the original CLI as the owned normal user');assert.ok(executable&&root&&hashFile);
const hash=value=>createHash('sha256').update(value).digest('hex');
assert.equal(hash(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
const expected=JSON.parse(await readFile(hashFile,'utf8')),pty=createRequire('/work/package.json')('node-pty');
await mkdir(root,{recursive:true});
const tls=['billing','admin'].includes(billingMode)?await prepareNativeCreditTls(join(root,'tls')):undefined,server=tls?await startNativeCreditBilling(tls,{accountType:billingMode==='admin'?'team':'pro'}):undefined;
try{
for(const profile of billingMode==='admin'?['oauth-team']:['oauth','api-key']){
 const workspace=await mkdtemp(join(root,'native-credit-admission-'+profile+'-')),proof=join(workspace,'admission.json'),preload=join(workspace,'observe.mjs');
 const input=await configureNativeCreditAccount(workspace,profile);await writeFile(preload,nativeCreditAdmissionObserver(proof,expected,{billingReads:!!server&&billingMode!=='admin',adminReads:billingMode==='admin'}));
 const env={...process.env};for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN','CLAUDE_CODE_SUBSCRIPTION_TYPE','CLAUDE_CODE_OAUTH_SCOPES','CLAUDE_INTERNAL_FC_OVERRIDES','CLAUDE_CODE_CUSTOM_OAUTH_URL','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC','DISABLE_TELEMETRY','DISABLE_GROWTHBOOK','BUN_OPTIONS'])delete env[key];
 Object.assign(env,input,...tls?[{NODE_EXTRA_CA_CERTS:tls.ca}]:[],{BUN_OPTIONS:'--preload='+preload,TERM:'xterm-256color',ANTHROPIC_BASE_URL:'http://127.0.0.1:9',CLAUDE_CODE_DISABLE_TERMINAL_TITLE:'1'});
 const child=pty.spawn(executable,[],{cwd:workspace,env,name:'xterm-256color',cols:100,rows:28});let terminal='',exit;
 child.onData(data=>{terminal=(terminal+data).slice(-65536)});const stopped=new Promise(resolve=>child.onExit(event=>{exit=event;resolve(event)}));
 let receipt;
 try{
  const deadline=Date.now()+11000;
  while(Date.now()<deadline&&!exit){try{receipt=JSON.parse(await readFile(proof,'utf8'));break}catch(error){if(error.code!=='ENOENT')throw error;}await new Promise(resolve=>setTimeout(resolve,50));}
  if(!receipt){let error;try{error=await readFile(proof+'.error','utf8')}catch{}throw Error('Original admission not observed: '+(error??terminal.slice(-1200)));}
  assert.equal(receipt.pid,child.pid);assert.equal(receipt.featureInputs.latch,true);assert.deepEqual(receipt.featureInputs.billing,{enabled:true,overageConsentRequired:true});
  if(server&&profile==='oauth'){
   assert.equal(receipt.billingReads.balance.amount,0);assert.equal(receipt.billingReads.bundles.stripe_product_id,'prod_owned_credit');assert.equal(receipt.billingReads.paymentMethod.last4,'4242');assert.equal(receipt.billingReads.tax.tax_minor_units,750);assert.equal(server.state.purchases.length,0);assert.equal(server.state.adminRequests.length,0);
  }
  assert.equal(receipt.inlinePurchaseEligible,profile==='oauth');assert.equal(receipt.accountEligible,profile!=='api-key');assert.equal(receipt.oauthPresent,profile!=='api-key');
  if(billingMode==='admin'){assert.equal(receipt.subscriptionType,'team');assert.equal(receipt.adminRequestDecision.type,'confirm-admin-request');assert.equal(receipt.adminRequestDecision.checked,true);assert.equal(receipt.adminRequestDecision.extraUsage.is_enabled,false);assert.equal(server.state.adminRequests.length,0);assert.equal(server.state.purchases.length,0);}
  await writeFile(join(workspace,'verified.json'),JSON.stringify({profile,receipt,scope:server?'Original admission and read-only billing transport using synthetic inputs. No model turns, UI acceptance, billing mutation, predicate override or real account claim.':'Original admission from isolated supported inputs only. No model turns, UI acceptance, billing request, predicate override or real account claim.'},null,2)+'\n');
  console.log(JSON.stringify({profile,workspace,pid:child.pid,accountEligible:receipt.accountEligible,inlinePurchaseEligible:receipt.inlinePurchaseEligible,requiresCreditConsent:receipt.requiresCreditConsent}));
 }finally{
  if(!exit)child.kill('SIGTERM');await Promise.race([stopped,new Promise(resolve=>setTimeout(resolve,2000))]);if(!exit){child.kill('SIGKILL');await stopped;}
  await writeFile(join(workspace,'terminal.txt'),terminal);await writeFile(join(workspace,'exit.json'),JSON.stringify({pid:child.pid,...exit}));
 }
}

}finally{if(server){await writeFile(join(root,'billing-requests.json'),JSON.stringify(server.state,null,2)+'\n');await server.close();}}
