import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,readdir,rm,writeFile} from 'node:fs/promises';
import {join,isAbsolute,basename} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash,randomBytes,randomUUID} from 'node:crypto';
import {createServer} from 'node:http';

/** Original corporate launcher, confined to a fresh research-owned Claude config and daemon. */
export async function prepareNativeOwnedLauncherAudit(workspace,{checkout,observeHelpers=false,observeDesktop=false}={}){
 assert.equal(process.platform,'linux');assert.ok(isAbsolute(workspace)&&basename(workspace).startsWith('apack-terminal-owner-app-'));
 const configDirectory=join(workspace,'.claude');
 assert.ok(!(await readdir(configDirectory)).some(name=>name.startsWith('daemon')),'Existing daemon/profile must not be wrapped');
 const directory=join(workspace,'owned-launcher');assert.match(directory,/^[A-Za-z0-9_/.:-]+$/u);
 await mkdir(directory,{mode:0o700});await mkdir(join(directory,'invocations'),{mode:0o700});
 const quote=value=>"'"+value.replaceAll("'","'\\''")+"'";
 const logger=join(directory,'record.py'),marker=join(directory,'worker-marker.mjs'),path=join(directory,'launcher.sh');
 const helperEvents=[],desktopBridges=new Map();let server,socketDirectory,runtime,desktopRuntime,uiTextLimit=65536;
 const observer={};
 if(observeHelpers||observeDesktop){
  assert.ok(isAbsolute(checkout));
  if(observeHelpers){
   ({claudeTerminalStatusRuntime:runtime}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-status-runtime.ts')).href));
   assert.equal(typeof runtime,'string');await writeFile(join(directory,'status-template.mjs'),runtime,{mode:0o600});
  }
  if(observeDesktop){
   ({CLAUDE_UI_TEXT_MESSAGE_MAX_BYTES:uiTextLimit}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/ui-text-limits.ts')).href));
   ({claudeTerminalUiRuntime:desktopRuntime}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-ui-runtime.ts')).href));
   assert.equal(typeof desktopRuntime,'string');
   // Read only the original host's registration state; never trigger or bypass registration.
   const controlEntry='const n=await initialize();';assert.equal(desktopRuntime.split(controlEntry).length,2);
   desktopRuntime=desktopRuntime.replace(controlEntry,controlEntry+`
 if(request.subtype==='apack_research_hook_snapshot'){const registry=n.nativeHost.Le();return {registrationEpoch:registry.hookRegistrationEpoch,swapEpoch:registry.hookSwapEpoch,owed:registry.hookRegistrationOwed,inFlight:registry.hookRegistrationInFlight!==undefined,registered:registry.hookRegistration!==undefined,awaitTrust:registry.hookModulesAwaitTrust,unknown:registry.hooksUnknownCause===undefined?null:String(registry.hooksUnknownCause),loadedModules:registry.loadedModules.map(value=>({name:value.name})),pluginsWithHooks:[...registry.pluginsWithHooks],leftOut:registry.hooksLeftOutByName,abovePrompt:{terminal:n.gate.n5r('AbovePrompt','terminal'),desktop:n.gate.n5r('AbovePrompt','desktop')}};}
`);
   await writeFile(join(directory,'ui-template.mjs'),desktopRuntime,{mode:0o600});
  }
  socketDirectory=await mkdtemp('/tmp/cc-owned-startup-');observer.socketPath=join(socketDirectory,'observer.sock');observer.token=randomBytes(32).toString('hex');observer.generations={main:randomUUID(),subagent:randomUUID()};
  server=createServer(async(req,res)=>{const finish=code=>{res.writeHead(code);res.end('{}');};try{
   if(req.method!=='POST'||!['/observer-ready','/observer-error','/native-status',...(observeDesktop?['/ui-event','/ui-host']:[])].includes(req.url)||req.headers['x-apack-native-token']!==observer.token)return finish(403);
   const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>(req.url==='/ui-host'?uiTextLimit:65536))return finish(413);chunks.push(chunk);}
   const value=JSON.parse(Buffer.concat(chunks).toString('utf8'));
   if(req.url==='/ui-host'){
    const held=desktopBridges.get(value.pid);
    if(!held||value.sessionId!==held.sessionId)return finish(409);
    const stat=await readFile('/proc/'+value.pid+'/stat','utf8');
    if(stat.slice(stat.lastIndexOf(')')+2).split(' ')[19]!==held.processStart)return finish(409);
    if(!held.bridge.receiveHost(value,(result,current)=>{if(res.destroyed||res.writableEnded)return;res.writeHead(current?200:409,{'content-type':'application/json'});res.end(JSON.stringify({request_id:value.request_id,pid:value.pid,sessionId:value.sessionId,result}));}))return finish(409);
    res.once('close',()=>held.bridge.cancelHost(String(value.request_id)));return;
   }
   if(helperEvents.length>=256)return finish(429);
   helperEvents.push({at:Date.now(),path:req.url,value});finish(200);
  }catch{if(!res.headersSent)finish(400);else res.destroy();}});
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(observer.socketPath,resolve);});
 }
 await writeFile(join(directory,'base-config.json'),JSON.stringify({observeHelpers,observeDesktop,...observer}),{mode:0o600});
 const loggerSource=`import hashlib,json,os,pathlib,re,shutil,sys,time
workspace=pathlib.Path(${JSON.stringify(workspace)})
directory=workspace/'owned-launcher'
if os.environ.get('HOME')!=str(workspace) or os.environ.get('CLAUDE_CONFIG_DIR',str(workspace/'.claude'))!=str(workspace/'.claude'): raise SystemExit('Owned profile required')
wrapper_pid=int(sys.argv[1]);argv=sys.argv[2:]
if not argv or hashlib.sha256(pathlib.Path(argv[0]).read_bytes()).hexdigest()!='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10': raise SystemExit('Pinned native launch required')
kind=os.environ.get('CLAUDE_CODE_SESSION_KIND')
is_worker=kind=='bg' and '--bg-pty-host' not in argv and any(flag in argv for flag in ['--session-id','--resume']) and os.environ.get('CLAUDE_BG_RENDEZVOUS_SOCK')
record={'at':int(time.time()*1000),'pid':wrapper_pid,'argv':argv,'sessionKind':kind,'mode':'worker' if is_worker else 'pass','originalBunOptions':os.environ.get('BUN_OPTIONS'),'configDirectory':str(workspace/'.claude'),'rendezvousSocketPresent':bool(os.environ.get('CLAUDE_BG_RENDEZVOUS_SOCK'))}
base=json.loads((directory/'base-config.json').read_text())
if is_worker and (base['observeHelpers'] or base['observeDesktop']):
 session_id=next((argv[argv.index(flag)+1] for flag in ['--session-id','--resume'] if flag in argv and argv.index(flag)+1<len(argv) and re.fullmatch('[a-f0-9-]{36}',argv[argv.index(flag)+1])),None)
 if session_id is None: raise SystemExit('Explicit original worker session required')
 worker_dir=directory/'workers'/str(wrapper_pid)
 worker_dir.mkdir(mode=0o700,parents=True)
 observer={key:base[key] for key in ['socketPath','token','generations']}
 observer['sessionId']=session_id
 if record['originalBunOptions'] is not None: observer['originalBunOptions']=record['originalBunOptions']
 (worker_dir/'observer.json').write_text(json.dumps(observer));(worker_dir/'observer.json').chmod(0o600)
 if base['observeHelpers']:
  shutil.copyfile(directory/'status-template.mjs',worker_dir/'status.mjs');(worker_dir/'status.mjs').chmod(0o600)
  record['observerPath']=str(worker_dir/'status.mjs')
 if base['observeDesktop']:
  observer['uiSocketPath']=str(pathlib.Path(base['socketPath']).parent/('ui-'+str(wrapper_pid)+'.sock'))
  (worker_dir/'observer.json').write_text(json.dumps(observer));(worker_dir/'observer.json').chmod(0o600)
  shutil.copyfile(directory/'ui-template.mjs',worker_dir/'ui.mjs');(worker_dir/'ui.mjs').chmod(0o600)
  record['uiObserverPath']=str(worker_dir/'ui.mjs')
record_path=directory/'invocations'/(str(wrapper_pid)+'.json')
with record_path.open('x') as out: json.dump(record,out)
record_path.chmod(0o600)
print(record['mode'])
`;
 const markerSource=`import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';import {pathToFileURL} from 'node:url';
const directory=${JSON.stringify(directory)};
const invocation=JSON.parse(readFileSync(directory+'/invocations/'+process.pid+'.json','utf8'));
if(invocation.pid!==process.pid||invocation.mode!=='worker'||process.env.HOME!==${JSON.stringify(workspace)})throw Error('Unowned worker startup');
const binarySha256=createHash('sha256').update(readFileSync(process.execPath)).digest('hex');
if(binarySha256!=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10')throw Error('Unreviewed native worker');
if(invocation.originalBunOptions===null)delete process.env.BUN_OPTIONS;else process.env.BUN_OPTIONS=invocation.originalBunOptions;
const stat=readFileSync('/proc/self/stat','utf8'),fields=stat.slice(stat.lastIndexOf(')')+2).split(' ');
writeFileSync(directory+'/worker-'+process.pid+'.json',JSON.stringify({pid:process.pid,parentPid:process.ppid,processStart:fields[19],argv:process.argv,binarySha256,restoredBunOptions:(process.env.BUN_OPTIONS??null)===invocation.originalBunOptions,source:'original corporate launcher in a fresh owned research profile'}),{mode:0o600,flag:'wx'});
if(invocation.observerPath){if(invocation.observerPath!==directory+'/workers/'+process.pid+'/status.mjs')throw Error('Unowned observer path');await import(pathToFileURL(invocation.observerPath).href);}
if(invocation.uiObserverPath){if(invocation.uiObserverPath!==directory+'/workers/'+process.pid+'/ui.mjs')throw Error('Unowned UI observer path');await import(pathToFileURL(invocation.uiObserverPath).href);}
`;
 const wrapperSource='#!/bin/sh\nset -eu\nmode=$(/usr/bin/python3 -I '+quote(logger)+' "$$" "$@")\ncase "$mode" in\n worker) BUN_OPTIONS="${BUN_OPTIONS:+$BUN_OPTIONS }--preload='+marker+'"; export BUN_OPTIONS ;;\n pass) ;;\n *) exit 64 ;;\nesac\nexec "$@"\n';
 await writeFile(logger,loggerSource,{mode:0o600});await writeFile(marker,markerSource,{mode:0o600});await writeFile(path,wrapperSource,{mode:0o700});
 const sources=Object.fromEntries([[logger,loggerSource],[marker,markerSource],[path,wrapperSource],...(runtime?[[join(directory,'status-template.mjs'),runtime]]:[]),...(desktopRuntime?[[join(directory,'ui-template.mjs'),desktopRuntime]]:[])].map(([name,text])=>[name,createHash('sha256').update(text).digest('hex')]));
 return{path,sources,async bindDesktopTransport(job,bridge){
  const scope=await this.desktopScope(job);assert.ok(!desktopBridges.has(job.pid),'Desktop worker already bound');
  const held={sessionId:job.sessionId,processStart:scope.processStart,bridge};desktopBridges.set(job.pid,held);
  return()=>{if(desktopBridges.get(job.pid)===held)desktopBridges.delete(job.pid);};
 },async desktopScope(job){
  assert.equal(observeDesktop,true,'Desktop bootstrap was not requested');
  assert.ok(Number.isSafeInteger(job.pid)&&job.pid>1,'Native worker PID required');assert.match(job.sessionId,/^[a-f0-9-]{36}$/u);
  const proof=await this.snapshot(job);
  const config=JSON.parse(await readFile(join(directory,'workers',String(job.pid),'observer.json'),'utf8'));
  assert.equal(config.sessionId,job.sessionId);assert.equal(config.uiSocketPath,join(socketDirectory,'ui-'+job.pid+'.sock'));
  return{socketPath:config.uiSocketPath,token:config.token,pid:proof.worker.pid,sessionId:job.sessionId,processStart:proof.worker.processStart};
 },async close(){desktopBridges.clear();if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}if(socketDirectory)await rm(socketDirectory,{recursive:true});},async snapshot(job){
  const names=await readdir(join(directory,'invocations'));assert.ok(names.length<=64);
  const invocations=await Promise.all(names.filter(name=>/^\d+\.json$/.test(name)).map(async name=>JSON.parse(await readFile(join(directory,'invocations',name),'utf8'))));
  const worker=JSON.parse(await readFile(join(directory,'worker-'+job.pid+'.json'),'utf8'));
  const invocation=invocations.find(row=>row.pid===job.pid);assert.equal(invocation?.mode,'worker');assert.ok(invocation.argv.includes(job.sessionId));assert.equal(worker.pid,job.pid);assert.ok(worker.argv.includes(job.sessionId));assert.equal(worker.restoredBunOptions,true);
  const stat=await readFile('/proc/'+job.pid+'/stat','utf8');assert.equal(worker.processStart,stat.slice(stat.lastIndexOf(')')+2).split(' ')[19]);
  return{job,worker,invocations,sources,helperEvents:[...helperEvents],scope:'Startup bootstrap/observation in one fresh fully owned research profile/daemon only. No shared production daemon, policy-epoch admission or settings/auth/session compatibility claim.'};
 }};
}
