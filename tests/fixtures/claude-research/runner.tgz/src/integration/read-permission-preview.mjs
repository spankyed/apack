import assert from 'node:assert/strict';

/** Read each rendered text fragment by physical wheel; a long preview need not fit at once. */
export async function readPermissionPreview({page,details,preview,expect,regionSelector='.details'}) {
 const measure=()=>preview.evaluate((element,regionSelector)=>{
  const region=element.closest(regionSelector).getBoundingClientRect(),walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT),fragments=[];
  while(walker.nextNode()){const range=document.createRange();range.selectNodeContents(walker.currentNode);for(const rect of range.getClientRects())if(rect.width>0&&rect.height>0)fragments.push({top:rect.top,bottom:rect.bottom,left:rect.left,right:rect.right});}
  return {region:{top:region.top,bottom:region.bottom,left:region.left,right:region.right,height:region.height},fragments,scrollTop:element.closest(regionSelector).scrollTop};
 },regionSelector);
 const hoverGutter=async()=>{const box=await details.boundingBox();assert.ok(box&&box.width>8&&box.height>0);await page.mouse.move(box.x+box.width-4,box.y+box.height/2);};
 await hoverGutter();await page.mouse.wheel(0,-100000);await expect.poll(async()=>(await measure()).scrollTop).toBe(0);
 let snapshot=await measure();assert.ok(snapshot.fragments.length>0&&snapshot.fragments.length<=256);
 const seen=new Set(),steps=[];
 for(let attempt=0;attempt<32;attempt++){
  const next=snapshot.fragments.findIndex((_,index)=>!seen.has(index));if(next<0)break;
  const fragment=snapshot.fragments[next],delta=Math.max(-snapshot.region.height*.7,Math.min(snapshot.region.height*.7,fragment.top-snapshot.region.top-8));
  if(Math.abs(delta)>1){const prior=snapshot.scrollTop;await hoverGutter();await page.mouse.wheel(0,Math.round(delta));await expect.poll(async()=>(await measure()).scrollTop).not.toBe(prior);}
  snapshot=await measure();const visible=[];
  snapshot.fragments.forEach((rect,index)=>{if(rect.top>=snapshot.region.top-.5&&rect.bottom<=snapshot.region.bottom+.5&&rect.left>=snapshot.region.left-.5&&rect.right<=snapshot.region.right+.5){seen.add(index);visible.push(index)}});
  steps.push({scrollTop:snapshot.scrollTop,visible});
  if(seen.size===snapshot.fragments.length)break;
 }
 assert.equal(seen.size,snapshot.fragments.length,'Every original preview fragment must be physically readable: '+JSON.stringify({region:snapshot.region,fragments:snapshot.fragments,seen:[...seen],lastSteps:steps.slice(-3)}));
 return {fragmentCount:snapshot.fragments.length,readFragments:[...seen].sort((a,b)=>a-b),steps};
}
