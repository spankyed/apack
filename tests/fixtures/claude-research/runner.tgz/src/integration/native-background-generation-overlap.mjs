import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile, rename, lstat } from 'node:fs/promises';
import { join } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { childCaptionStartupDiagnostic } from './child-caption-startup-diagnostic.mjs';
const sha = value => createHash('sha256').update(value).digest('hex');

export async function prepareBackgroundGenerationOverlap(workspace, env) {
  assert.equal(process.platform, 'linux');assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+$/);
  const directory = join(workspace, 'helper-read-hold');await mkdir(directory, { mode: 0o700 });
  return { ...env, CLAUDE_RESEARCH_HELPER_READ_HOLD_DIR: directory,
    CLAUDE_RESEARCH_HELPER_API_NODE_OPTIONS: env.NODE_OPTIONS ?? '--max-old-space-size=4096' };
}

/** Let a real native report lose its connection during one adapter read; accept a newer epoch before resuming it. */
export async function observeBackgroundGenerationOverlap({ workspace, userDataDir, settingsPath, worker, workerStart, context, expect, sameParent, readDrawing }) {
  const directory = join(workspace, 'helper-read-hold'), id = randomUUID();
  const before = await readFile(settingsPath), settings = JSON.parse(before);assert.notEqual(settings.disableAllHooks, true);
  const diagnostic = await childCaptionStartupDiagnostic({ userDataDir, sessionId: worker.sessionId, pid: worker.pid });
  const matches = diagnostic.results.filter(row => row.pid === worker.pid && row.sessionId === worker.sessionId && row.start === workerStart);assert.equal(matches.length, 1);
  const marker = JSON.parse(await readFile(join(matches[0].directory, 'worker-' + worker.pid + '.json'), 'utf8'));
  assert.match(marker.configPath, new RegExp('^' + matches[0].directory + '/workers/w-' + worker.pid + '-[A-Za-z0-9]+/observer\\.json$'));
  const info = await lstat(marker.configPath);assert.ok(info.isFile() && info.uid === process.getuid() && (info.mode & 0o077) === 0);
  const events = async () => { try { return (await readFile(join(directory, 'events.jsonl'), 'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse); } catch (error) { if (error.code === 'ENOENT') return [];throw error; } };
  const configSnapshot = async () => { const bytes = await readFile(marker.configPath), value = JSON.parse(bytes);return { sha256: sha(bytes), mainGenerationSha256: sha(value.generations.main), subagentGenerationSha256: sha(value.generations.subagent) }; };
  const snapshot = async () => { const current = await sameParent();assert.equal(current.native.backgroundInfo.pid, worker.pid);assert.equal(current.native.backgroundInfo.sessionId, worker.sessionId);return { info: current.native.backgroundInfo, config: await configSnapshot(), drawing: await readDrawing() }; };
  const update = async bytes => { const temporary = settingsPath + '.overlap.tmp';await writeFile(temporary, bytes, { mode: 0o600, flag: 'wx' });await rename(temporary, settingsPath); };
  const baseline = await snapshot();assert.ok(baseline.info.statusLine);
  await writeFile(join(directory, 'arm.json'), JSON.stringify({ id, path: marker.configPath, disconnect: true }), { mode: 0o600, flag: 'wx' });
  let released = false;
  try {
    await update(Buffer.from(JSON.stringify({ ...settings, disableAllHooks: true })));
    await expect.poll(async () => (await events()).some(row => row.id === id && row.event === 'held'), { timeout: 15000 }).toBe(true);
    const held = (await events()).find(row => row.id === id && row.event === 'held');assert.notEqual(held.pid, worker.pid);
    // The original plugin, not the fixture, must reconnect and configure the newer native restriction.
    await expect.poll(async () => {
      const audit = await events(), current = await context();
      const registration = audit.find(row => row.pid === held.pid && row.event === 'reply' && row.route === '/background-register' && row.statusCode === 200 && row.requestId > held.requestId);
      return !!registration && audit.some(row => row.pid === held.pid && row.event === 'reply' && row.route === '/background-status' && row.statusCode === 200 && row.requestId > registration.requestId)
        && current.native?.backgroundInfo?.pid === worker.pid && current.native.backgroundInfo.statusLine === undefined && (await configSnapshot()).sha256 !== held.bytesSha256;
    }, { timeout: 15000 }).toBe(true);
    const restricted = await snapshot();
    await writeFile(join(directory, 'release'), id, { mode: 0o600, flag: 'wx' });released = true;
    await expect.poll(async () => (await events()).some(row => row.id === id && row.event === 'continuation-settled'), { timeout: 5000 }).toBe(true);
    const settled = (await events()).find(row => row.id === id && row.event === 'continuation-settled');
    assert.equal(settled.configSha256, restricted.config.sha256, 'Superseded report must not rewrite the newer worker configuration');
    assert.equal((await snapshot()).info.statusLine, undefined);
    await update(before);
    await expect.poll(async () => { const info = (await context()).native?.backgroundInfo;return info?.pid === worker.pid && typeof info.totalCostUsd === 'number' && info.statusLine === 'Release review\nSession cost $' + info.totalCostUsd.toFixed(6); }, { timeout: 15000 }).toBe(true);
    const restored = await snapshot(), audit = await events();
    assert.ok(!audit.some(row => row.id === id && row.event === 'expired'));
    const proof = { id, worker, workerStart, baseline, held, restricted, settled, restored, audit,
      scope: 'One authentic native report disconnect during an adapter config read; newer registration/policy wins before unchanged old bytes resume. No forged native requests or helper execution. Separate policy visual acceptance is preserved.' };
    await writeFile(join(workspace, 'electron-results/helper-generation-overlap.json'), JSON.stringify(proof, null, 2));return proof;
  } finally {
    if (!released) await writeFile(join(directory, 'release'), id, { mode: 0o600 });
    if (!(await readFile(settingsPath)).equals(before)) await update(before);
    assert.deepEqual(await readFile(settingsPath), before);
  }
}
