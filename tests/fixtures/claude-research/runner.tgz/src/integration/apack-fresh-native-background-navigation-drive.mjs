import {prepareNativeWarmSpare} from './native-warm-spare.mjs';
import {observeBackgroundHelperPolicy} from './native-background-helper-policy.mjs';
import {prepareNativeAppCliProfile} from './native-app-cli-profile.mjs';
import {nativeBackgroundMetadataFixture} from '../protocol/native-background-metadata-fixture.mjs';
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {execFile,execFileSync} from 'node:child_process';
import {promisify} from 'node:util';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {prepareBackgroundStatusProfile} from './native-background-status-profile.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function birth(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),f=raw.slice(raw.lastIndexOf(')')+2).split(' ');return f[0]==='Z'?null:f[19]}catch(error){if(error.code==='ENOENT')return null;throw error}}

/** Original background attach through the normal app controls and shared broker drawing. */
export async function driveFreshNativeBackgroundNavigation({checkout,workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+$/);
 const project=join(workspace,'project');await mkdir(project);await writeFile(join(project,'release-notes.md'),'# Release notes\n\nReview local permissions before continuing.\n');execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),ownedProfile=env.CLAUDE_RESEARCH_OWNED_BACKGROUND_PROFILE==='1',profileDir=await prepareNativeAppCliProfile({checkout,workspace,account,owned:ownedProfile}),configPath=join(profileDir,'.claude.json'),settingsPath=join(profileDir,'settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({...JSON.parse(await readFile(settingsPath,'utf8')),theme:'dark',model:'opus'}));const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath);
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,defaultProfile:'shared',cliProfileMode:ownedProfile?'app-owned':'external',cliConfigRelative:ownedProfile?'app-data/claude-code-profile/config':'.claude',config,settings:JSON.parse(settingsBefore)},null,2));
 const statusProfile=await prepareBackgroundStatusProfile(workspace,{configDir:profileDir});const output=join(workspace,'electron-results');let model,billing,proof,launchEnv,warmSpare;
 try{
  model=await startSyntheticModel(workspace,'TextOnly',{textReply:'The background release review is complete.',captureMessages:true,nativeBackgroundMetadata:true,maxRequests:16});
  const tls=await prepareNativeCreditTls(join(workspace,'account-tls'));billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
  launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  if(env.CLAUDE_RESEARCH_HELPER_TIMING){const directory=join(workspace,'helper-timing');assert.equal(env.CLAUDE_RESEARCH_HELPER_TIMING,directory);await mkdir(directory,{mode:0o700});}
  if(env.CLAUDE_RESEARCH_REQUIRE_WARM_SPARE==='1')warmSpare=await prepareNativeWarmSpare({workspace,profileDir,project,env:launchEnv});
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-fresh-native-background-navigation',journeyBudgetMs:120000,journey:async({app,page,expect,phase,userDataDir})=>{
   proof={status:'running',scope:'Original attached-background toolbar navigation at normal/compact sizes, same worker/client and unsent draft, explicit compact expansion; existing close/reopen/reply/Stop and parent history/accounting recovery are retained. Not all owners/policy/lifecycle or parity acceptance.',captures:[],layouts:[]};const save=()=>writeFile(join(output,'native-background-navigation.json'),JSON.stringify(proof,null,2));
   const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews}});
   const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
   const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await composer.pressSequentially(text);await expect(composer).toHaveText(text)};
   try{
    await app.waitForSurface('default-setup/threads');await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');await page.waitForTimeout(700);
    await app.navigate('default-setup/threads');await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return!!c.currentThread?.id&&c.openedThreadId===null&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code')}),{timeout:15000}).toBe(true);
    await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
    proof.seed='Review the local release notes before checking permissions.';await replace(proof.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);await section.getByRole('button',{name:'Use native interface',exact:true}).click();
    const seen=new Set();for(let i=0;i<100;i++){const native=(await context()).native?.state;if(native?.nativePid&&native.status==='live')break;const text=await section.locator('[data-terminal-text]').innerText().catch(()=>''),stage=recognizeOnboardingPrompt(text,project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100);}
    await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.pid=proof.initial.native.state.nativePid;proof.processStart=await birth(proof.pid);assert.ok(proof.processStart);await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
    proof.backgroundCommand='/background Continue reviewing the release notes.';await replace(proof.backgroundCommand);await send.click();
    const widget=page.getByRole('region',{name:'Background Claude session',exact:true});await expect(widget.getByRole('button',{name:'Open session',exact:true})).toBeEnabled({timeout:25000});await expect.poll(async()=>(await context()).native?.background?.session?.pid,{timeout:25000}).toBeTruthy();
    await page.evaluate(()=>{
     if(window.__claudeResearchCostEvidence)throw Error('Cost observer already installed');
     const state={observations:[],truncated:false,last:'',observer:null};
     const record=()=>{
      const widget=document.querySelector('[aria-label="Background Claude session"]');
      const usageText=widget?.querySelector('[aria-label="Background session usage"]')?.innerText??'';
      const statusText=widget?.querySelector('[aria-label="Background Claude configured status"]')?.innerText??'';
      const key=JSON.stringify([usageText,statusText]);if(key===state.last)return;state.last=key;
      if(state.observations.length>=1000){state.truncated=true;return}
      const total=usageText.match(/Session total \$([0-9.]+)/),helper=statusText.match(/Session cost \$([0-9.]+)/);
      state.observations.push({usageText,statusText,totalCostUsd:total?Number(total[1]):null,statusCostUsd:helper?Number(helper[1]):null});
     };
     state.observer=new MutationObserver(record);state.observer.observe(document.body,{childList:true,characterData:true,subtree:true});window.__claudeResearchCostEvidence=state;record();
    });
    proof.running=await context();proof.worker=proof.running.native.background.session;proof.workerStart=await birth(proof.worker.pid);assert.ok(proof.workerStart);if(warmSpare){await warmSpare.requireClaim(proof.worker);proof.warmSpare=warmSpare.receipt;}assert.notEqual(proof.worker.sessionId,proof.sessionId);assert.equal(proof.worker.cwd,project);
    proof.parentDraft='Keep the parent release notes while I review the background session.';await replace(proof.parentDraft);proof.parentDocument=await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));proof.parentBeforeAttach=await context();
    const panel=page.getByRole('region',{name:'Background Claude terminal',exact:true}),input=panel.locator('[aria-label="Terminal input"]'),text=()=>panel.locator('[data-terminal-text]').innerText();
    const normalized=value=>value.replace(/\s+/g,'');
    const sameParent=async()=>{const c=await context();assert.equal(c.claude.sessionId,proof.sessionId);assert.deepEqual(c.messages,proof.parentBeforeAttach.messages);assert.equal(c.claude.totalCostUsd,proof.parentBeforeAttach.claude.totalCostUsd);assert.deepEqual(await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()})),proof.parentDocument);return c};
    // Actor/DOM state can settle before Chromium has painted a resized or restored surface.
    const settlePaint=()=>page.evaluate(async()=>{await document.fonts.ready;await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))});
    proof.paneLayouts=[];
    const paneLayout=async(stage,size)=>{
     const bounds=await panel.evaluate(e=>{
      const root=e.closest('[aria-label="Claude native interface"]'),card=root.querySelector('[aria-label="Background Claude session"]'),body=card.querySelector('.background-session__body'),controls=card.querySelector('.background-session__controls'),hint=e.querySelector('.child-terminal__hint'),viewport=e.querySelector('.child-terminal__viewport');
      const box=n=>{const r=n.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom}};
      return{root:box(root),card:box(card),body:box(body),controls:box(controls),hint:box(hint),viewport:box(viewport),window:{width:innerWidth,height:innerHeight},buttons:[...root.querySelectorAll('button')].filter(b=>!b.disabled&&b.getBoundingClientRect().width>0).map(b=>{const r=b.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return{label:b.getAttribute('aria-label')||b.textContent.trim(),box:box(b),reachable:!!hit&&b.contains(hit)}})};
     });
     assert.ok(bounds.body.width>=159,'Status description must not be squeezed beside controls');
     assert.ok(bounds.controls.right<=bounds.card.right+1);
     assert.ok(bounds.hint.bottom<=bounds.root.bottom+1,'Connection hint must stay above the pane footer');
     assert.ok(bounds.viewport.bottom<=bounds.hint.y+1);
     assert.ok(bounds.root.bottom<=bounds.window.height+1);
     assert.ok(bounds.buttons.every(b=>b.reachable),'Every enabled background control must remain reachable');
     proof.paneLayouts.push({stage,size,...bounds});
    };
    const capture=async(stage,expected)=>{
     for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
      await page.setViewportSize(viewport);await expect(panel).toBeInViewport({ratio:1});
      await expect(panel.getByRole('button',{name:'Close connection',exact:true})).toBeInViewport({ratio:1});
      const measure=()=>panel.evaluate(e=>{
       const terminal=e.querySelector('[data-native-terminal]'),canvas=terminal?.querySelector('canvas'),host=terminal?.parentElement;
       if(!terminal||!canvas||!host)return null;
       const box=n=>{const r=n.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height}};
       // Geometry and semantic text can settle while resize has cleared the actual canvas.
       // A lone cursor must not qualify as the multiword terminal content captured here.
       const pixels=canvas.width&&canvas.height?canvas.getContext('2d')?.getImageData(0,0,canvas.width,canvas.height):null,inkColumns=new Set();
       if(pixels){const rgba=pixels.data,columns=Number(terminal.dataset.nativeTerminalColumns),cell=canvas.width/columns;
        // The caret can occupy a corner; choose the majority corner colour rather than its pixel.
        const corners=[0,(canvas.width-1)*4,(canvas.height-1)*canvas.width*4,(canvas.width*canvas.height-1)*4],counts=new Map();
        for(const i of corners){const color=Array.from(rgba.slice(i,i+4)).join(',');counts.set(color,(counts.get(color)??0)+1)}
        const background=[...counts].sort((a,b)=>b[1]-a[1])[0][0].split(',').map(Number);
        for(let y=0;y<canvas.height;y++)for(let x=0;x<canvas.width;x++){
         const i=(y*canvas.width+x)*4;if(rgba[i+3]&&(rgba[i]!==background[0]||rgba[i+1]!==background[1]||rgba[i+2]!==background[2]))inkColumns.add(Math.floor(x/cell));
        }
       }
       return{text:terminal.querySelector('[data-terminal-text]')?.innerText??'',paintedColumns:inkColumns.size,box:box(e),drawing:{columns:terminal.dataset.nativeTerminalColumns,rows:terminal.dataset.nativeTerminalRows,canvas:box(canvas),host:box(host)}};
      });
      const fits=current=>{
       if(!current||current.paintedColumns<4||!normalized(current.text).includes(normalized(expected)))return false;
       const c=current.drawing.canvas,h=current.drawing.host,rulers=current.text.split('\n').filter(line=>/^─{10,}$/.test(line.trim()));
       return c.width<=h.width+1&&c.height<=h.height+1&&h.width-c.width<16&&h.height-c.height<30&&rulers.at(-1)?.trim().length===Number(current.drawing.columns);
      };
      const geometry=current=>JSON.stringify({box:current.box,drawing:current.drawing});
      const file='native-background-'+stage+'-'+size+'.png';let settled,attempt=0;
      proof.captureAttempts??=[];
      await expect.poll(async()=>{
       await settlePaint();const before=await measure();if(!fits(before))return false;
       const candidate=file.replace('.png','-attempt'+(attempt++)+'.png');await page.screenshot({path:join(output,candidate),animations:'disabled'});
       const after=await measure(),stable=fits(after)&&geometry(before)===geometry(after);
       proof.captureAttempts.push({stage,size,file:candidate,stable,beforePaintedColumns:before.paintedColumns,afterPaintedColumns:after?.paintedColumns??0,beforeGeometry:geometry(before),afterGeometry:after?geometry(after):null});
       if(!stable)return false;
       settled=after;await writeFile(join(output,file),await readFile(join(output,candidate)));return true;
      },{timeout:15000}).toBe(true);
      proof.layouts.push({stage,size,...settled});await paneLayout(stage,size);proof.captures.push(file);await sameParent();await save();
     }
    };
    proof.childDraft='Keep this child release draft.';proof.attachments=[];proof.navigation=[];proof.requestWindows=[];
    const noSubmission=(operation,before)=>{
     const added=model.calls.slice(before).filter(c=>c.path.split('?')[0]==='/v1/messages');
     for(const call of added){const metadata=nativeBackgroundMetadataFixture({messages:call.messages,tools:call.toolNames});assert.ok(metadata,'Unsolicited conversation request during '+operation);assert.equal(call.nativeMetadataKind,metadata.kind)}
     proof.requestWindows.push({operation,before,after:model.calls.length,nativeMetadata:added.map(c=>c.nativeMetadataKind)});
    };
    const childJournal=async()=>{const root=join(profileDir,'projects'),paths=(await readdir(root,{recursive:true})).filter(n=>basename(n)===proof.worker.sessionId+'.jsonl');assert.ok(paths.length<=1);return paths.length?readFile(join(root,paths[0])):Buffer.alloc(0)};
    const repliedTo=async prompt=>{const rows=(await childJournal()).toString().split('\n').filter(Boolean).map(JSON.parse),human=rows.find(r=>r.type==='user'&&r.origin?.kind==='human'&&r.message?.content===prompt);if(!human)return false;const byId=new Map(rows.map(r=>[r.uuid,r]));return rows.some(r=>{if(r.type!=='assistant'||!Array.isArray(r.message?.content)||!r.message.content.some(b=>b.type==='text'&&b.text==='The background release review is complete.'))return false;let id=r.parentUuid;for(let i=0;id&&i<rows.length;i++){if(id===human.uuid)return true;id=byId.get(id)?.parentUuid}return false})};
    await expect.poll(()=>repliedTo('Continue reviewing the release notes.'),{timeout:20000}).toBe(true);await writeFile(join(output,'native-child-initial-transcript.jsonl'),await childJournal());
    if(env.CLAUDE_RESEARCH_REQUIRE_INITIAL_HELPER==='1'){
     const before=model.calls.length;
     await expect.poll(async()=>{const info=(await context()).native?.backgroundInfo;if(!info?.statusLine||typeof info.totalCostUsd!=='number')return false;return info.statusLine==='Release review\nSession cost $'+info.totalCostUsd.toFixed(6)},{timeout:15000}).toBe(true);
     const info=(await context()).native.backgroundInfo,invocations=await statusProfile.invocations();
     const helper=invocations.find(row=>row.input.session_id===proof.worker.sessionId&&row.input.cost.total_cost_usd===info.totalCostUsd&&row.ancestry.some(a=>a.pid===proof.worker.pid&&a.start===proof.workerStart));assert.ok(helper);
     await expect(widget.locator('[aria-label="Background Claude configured status"]')).toHaveText(info.statusLine);
     noSubmission('initial-helper',before);proof.initialHelperAcceptance={info,helper,modelCallIndex:model.calls.length,beforeExplicitChildFollowup:true};await save();
    }

    for(const cycle of ['first','reopened']){
     const before=model.calls.length;await widget.getByRole('button',{name:'Open session',exact:true}).click();await expect(panel).toBeVisible({timeout:15000});await expect.poll(async()=>(await context()).native?.attachment?.state?.status,{timeout:15000}).toBe('live');const current=(await context()).native.attachment.state;assert.equal(current.sessionId,proof.worker.sessionId);assert.equal(current.jobId,proof.worker.id);assert.notEqual(current.terminalSession.id,proof.initial.native.state.terminalSession.id);proof.attachments.push({...current,output:undefined,workerStart:await birth(proof.worker.pid),clientStart:current.clientPid?await birth(current.clientPid):null});assert.equal(proof.attachments.at(-1).workerStart,proof.workerStart);
     await expect(input).toBeFocused();if(cycle==='first')await input.pressSequentially(proof.childDraft);await capture(cycle,proof.childDraft);noSubmission(cycle+'-open',before);
     if(cycle==='first'&&env.CLAUDE_RESEARCH_HELPER_POLICY_TRANSITIONS==='1'){
      assert.ok(ownedProfile);const before=model.calls.length;
      proof.helperPolicyTransitions=await observeBackgroundHelperPolicy({workspace,userDataDir,settingsPath,worker:proof.worker,workerStart:proof.workerStart,context,statusProfile,expect,capture:stage=>capture(stage,proof.childDraft),sameParent,readDrawing:text});
      noSubmission('helper-policy',before);await save();
     }
     if(cycle==='first'){
      proof.navigationRequestsBefore=model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length;const navigationStart=model.calls.length;
      const select=async id=>{await page.locator('[data-onboarding-id="surface-'+id+'"]').click({timeout:10000});await expect(page.locator('[data-active-surface="'+id+'"]')).toBeVisible()};
      const expanded=()=>section.evaluate(e=>e.classList.contains('native-session--child-expanded'));
      for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
       await page.setViewportSize(viewport);if(size==='compact'&&!await expanded())await panel.getByRole('button',{name:'Expand',exact:true}).click();
       await select('default-setup/code');await expect.poll(expanded).toBe(false);const canvas=page.getByText('Open a file from the explorer to start editing',{exact:true});await expect(canvas).toBeInViewport({ratio:1});await canvas.click({trial:true});
       const onCode=await sameParent(),codeExpanded=await expanded(),canvasBox=await canvas.boundingBox(),attached=onCode.native.attachment.state;
       assert.equal(attached.id,current.id);assert.equal(attached.terminalSession.id,current.terminalSession.id);assert.equal(attached.sessionId,proof.worker.sessionId);assert.equal(await birth(proof.worker.pid),proof.workerStart);if(current.clientPid)assert.equal(await birth(current.clientPid),proof.attachments.at(-1).clientStart);
       await paneLayout('navigation-code',size);const file='native-background-navigation-code-'+size+'.png';await settlePaint();await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);
       await select('default-setup/threads');await expect.poll(expanded).toBe(false);if(size==='compact'){await panel.getByRole('button',{name:'Expand',exact:true}).click();await expect.poll(expanded).toBe(true)}
       await expect.poll(async()=>normalized(await text()),{timeout:10000}).toContain(normalized(proof.childDraft));const returned=await sameParent();assert.equal(returned.native.attachment.state.id,current.id);await paneLayout('navigation-returned',size);const recovered='native-background-navigation-returned-'+size+'.png';await settlePaint();await page.screenshot({path:join(output,recovered),animations:'disabled'});proof.captures.push(recovered);proof.navigation.push({size,onCode,returned,codeExpanded,canvasBox,expandedOnReturn:await expanded(),reading:await text()});await save();
      }
      proof.navigationRequestsAfter=model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length;noSubmission('navigation',navigationStart);await save();
     }
     if(cycle==='reopened'){
      proof.childFollowup='Continue the background release review with these notes.';await input.press('Control+u');await input.pressSequentially(proof.childFollowup);await input.press('Enter');
      const journal=childJournal;await expect.poll(()=>repliedTo(proof.childFollowup),{timeout:20000}).toBe(true);await writeFile(join(output,'native-child-transcript.jsonl'),await journal());await widget.getByRole('button',{name:'Refresh status',exact:true}).click();await expect.poll(async()=>(await context()).native?.backgroundInfo?.sessionId,{timeout:15000}).toBe(proof.worker.sessionId);proof.childInfo=(await context()).native.backgroundInfo;await expect.poll(async()=>{const rows=await statusProfile.invocations();return rows.some(r=>r.input.session_id===proof.worker.sessionId&&r.input.cost.total_cost_usd===proof.childInfo.totalCostUsd)},{timeout:15000}).toBe(true);const repliedAt=Math.max(...(await journal()).toString().split('\n').filter(Boolean).map(JSON.parse).filter(r=>r.type==='assistant').map(r=>Date.parse(r.timestamp)));
      let latestHelper;await expect.poll(async()=>{latestHelper=(await statusProfile.invocations()).filter(r=>r.input.session_id===proof.worker.sessionId&&r.at>=repliedAt).at(-1);return!!latestHelper},{timeout:15000}).toBe(true);proof.expectedFinalChildCost=latestHelper.input.cost.total_cost_usd;
      await expect.poll(async()=>{const info=(await context()).native?.backgroundInfo;return info?.totalCostUsd===proof.expectedFinalChildCost&&info.statusLine==='Release review\nSession cost $'+proof.expectedFinalChildCost.toFixed(6)},{timeout:15000}).toBe(true);
      proof.statusInvocations=await statusProfile.invocations();await capture('answered','The background release review is complete.');proof.parentAfterChild=await sameParent();
     }
     await panel.getByRole('button',{name:'Close connection',exact:true}).click();await expect(panel).toBeHidden({timeout:15000});await expect.poll(async()=>(await context()).native?.attachment,{timeout:15000}).toBeUndefined();const saved=proof.attachments.at(-1);if(saved.clientPid)await expect.poll(()=>birth(saved.clientPid),{timeout:15000}).toBe(null);assert.equal(await birth(proof.worker.pid),proof.workerStart);await sameParent();await expect(composer).toBeEditable();
    }
    assert.notEqual(proof.attachments[0].id,proof.attachments[1].id);assert.notEqual(proof.attachments[0].terminalSession.id,proof.attachments[1].terminalSession.id);proof.closePreservedWorker=true;
    await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});await expect.poll(()=>birth(proof.worker.pid),{timeout:15000}).toBe(null);proof.nativeStopped=JSON.parse(await readFile(join(profileDir,'jobs',proof.worker.id,'state.json'),'utf8'));assert.equal(proof.nativeStopped.sessionId,proof.worker.sessionId);assert.equal(proof.nativeStopped.state,'stopped');proof.parentAfterStop=await sameParent();proof.stopped=true;
    await expect(composer).toHaveText(proof.parentDraft);await expect(send).toBeDisabled();await expect(card.getByText('This conversation moved to the background. Your notes stay here.',{exact:true})).toBeVisible();proof.notesOnly=true;proof.final=await sameParent();proof.finalDocument=await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
    for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect(composer).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});await expect(send).toBeDisabled();const file='native-background-recovered-'+size+'.png';await settlePaint();await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file)}
    if((await context()).native?.state?.status==='live'){await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null)}proof.costEvidence=await page.evaluate(()=>{const state=window.__claudeResearchCostEvidence;state.observer.disconnect();return{truncated:state.truncated,observations:state.observations}});assert.equal(proof.costEvidence.truncated,false);
    const visible=proof.costEvidence.observations.filter(r=>r.statusText);assert.ok(visible.length>=1);assert.ok(new Set(proof.costEvidence.observations.filter(r=>r.totalCostUsd!==null).map(r=>r.totalCostUsd)).size>=2,'Both original numeric cost states must be observed');assert.ok(visible.every(r=>r.totalCostUsd!==null&&r.statusCostUsd!==null&&r.totalCostUsd===r.statusCostUsd),'Numeric total and original formatter text must never disagree');
    proof.status='complete';await save();phase('native-background-navigation-complete');
   }catch(error){proof.status='failed';proof.error=error.message;proof.failureContext=await context().catch(()=>null);await save();throw error}
  }});
 }finally{
  try{
  await mkdir(output,{recursive:true});
  // The public native listing owns process identity; state.json owns task state.
  const cleanup=[],run=promisify(execFile),listed=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:launchEnv??{...env,...account},timeout:20000,maxBuffer:2*1024**2})).stdout);assert.ok(Array.isArray(listed)&&listed.length<=64);
  const owned=listed.filter(job=>job.kind==='background'&&/^[a-f0-9]{8}$/.test(job.id??'')&&job.cwd===project&&Number.isSafeInteger(job.pid)&&job.state!=='stopped');
  for(const job of owned){const state=JSON.parse(await readFile(join(profileDir,'jobs',job.id,'state.json'),'utf8'));assert.equal(state.cwd,project);assert.equal(state.sessionId,job.sessionId);const start=await birth(job.pid);if(!start)continue;if(proof?.worker?.id===job.id)assert.equal(start,proof.workerStart);await run('/frozen-claude/claude',['stop',job.id],{cwd:project,env:launchEnv??{...env,...account},timeout:20000,maxBuffer:2*1024**2});cleanup.push({id:job.id,sessionId:job.sessionId,pid:job.pid,start});}
  await writeFile(join(output,'cleanup-owned-workers.json'),JSON.stringify(cleanup));
  await warmSpare?.stop();await model?.close();await billing?.close();if(model)await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2));if(billing)await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2));
  const retirementStarted=Date.now();let retired=false;for(let attempt=0;attempt<100;attempt++){retired=(!proof?.pid||await birth(proof.pid)!==proof.processStart)&&(!proof?.worker||await birth(proof.worker.pid)!==proof.workerStart)&&(await Promise.all(cleanup.map(async job=>await birth(job.pid)!==job.start))).every(Boolean)&&(await Promise.all((await statusProfile.invocations()).map(async row=>await birth(row.pid)!==row.start))).every(Boolean);if(retired)break;await new Promise(resolve=>setTimeout(resolve,50));}await writeFile(join(output,'writer-retirement.json'),JSON.stringify({retired,elapsedMs:Date.now()-retirementStarted,pid:proof?.pid,processStart:proof?.processStart,worker:proof?.worker,workerStart:proof?.workerStart,cleanup}));assert.ok(retired,'Native writer must retire before profile restoration');await writeFile(join(output,'background-status-receipts.json'),JSON.stringify(await statusProfile.invocations()));await statusProfile.restore();await writeFile(join(output,'native-config-after.json'),await readFile(configPath));await writeFile(configPath,configBefore);await writeFile(settingsPath,settingsBefore);assert.deepEqual(await readFile(configPath),configBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configSha256:sha(configBefore),settingsSha256:sha(settingsBefore)}));
  if(proof?.sessionId){const root=join(profileDir,'projects'),files=await readdir(root,{recursive:true}),matches=files.filter(name=>basename(name)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);await writeFile(join(output,'native-parent-transcript.jsonl'),await readFile(join(root,matches[0])))}
  }finally{await warmSpare?.stop()}
 }
}
