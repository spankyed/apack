import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const[checkout,executable,workspace,mode]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const deletion=mode==='deletion';
const model=await startSyntheticModel(workspace,deletion?'TaskDeletion':'TaskLifecycle',{maxRequests:16});let child,exited=false,deadline,escalation;
try{
 child=spawn(process.execPath,[join(checkout,'node_modules/vitest/vitest.mjs'),'run','tests/content/actions/claude-code/task-list-native.spec.ts','--pool=threads','--maxWorkers=1','--minWorkers=1','--no-file-parallelism'],{cwd:join(checkout,'packages/default-setup'),env:{...process.env,CLAUDE_RESEARCH_EXECUTABLE:executable,CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_MODEL_URL:model.url,CLAUDE_RESEARCH_TASK_DELETION:deletion?'1':'0'},stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);
 deadline=setTimeout(()=>{child.kill('SIGTERM');escalation=setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000)},45000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',code=>{exited=true;resolve(code)})});
 assert.equal(code,0,'Native task list app test failed');assert.equal(model.calls.length,deletion?13:10);
 const evidence=JSON.parse(await readFile(join(workspace,'task-list-app-evidence.json'),'utf8'));
 console.log(JSON.stringify({evidence:'apack-native-task-list',...evidence,localModelRequests:model.calls.length,realModelRequests:0}));
}finally{clearTimeout(deadline);clearTimeout(escalation);if(child&&!exited){child.kill('SIGTERM');setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000).unref()}await model.close();}
