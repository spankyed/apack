/** Explicit first-party source-frontend verification, never a sealed-build fallback. */
export function resolveSourceFrontendEnvironment(raw, profile) {
  if (raw === undefined) return {};
  const url = new URL(raw);
  if (profile !== 'background-composer' || url.protocol !== 'http:' || url.hostname !== '127.0.0.1' || !url.port || url.pathname !== '/' || url.search || url.hash || url.username || url.password) throw Error('Explicit background-composer source frontend on a dedicated loopback port required');
  return { CLAUDE_RESEARCH_SOURCE_FRONTEND_URL: url.href, MODE: 'development', VITE_DEV_SERVER_URL: url.href };
}

export function isSourceFrontendReceipt(value, requested) {
  if (requested === undefined) return value.nativeBackgroundSourceFrontend !== true;
  if (value.nativeBackgroundSourceFrontend !== true || !value.sourceFrontendProof) return false;
  try {
    const expected = new URL(requested), proof = value.sourceFrontendProof;
    const page = new URL(proof.pageUrl), module = new URL(proof.inputModuleUrl);
    return page.origin === expected.origin && page.pathname === expected.pathname && module.origin === expected.origin && module.pathname.endsWith('/features/threads/fe/chat/input.vue') && /^[a-f0-9]{64}$/.test(proof.rawSha256) && proof.rawSha256 === proof.expectedSha256;
  } catch { return false; }
}
