import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {readFile,writeFile,readdir,lstat,mkdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {startCombinedEverydayModel} from '../protocol/combined-everyday-model.mjs';
import {prepareCombinedEverydayProfile} from './combined-everyday-profile.mjs';

const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function processStart(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]==='Z'?undefined:fields[19]}catch(error){if(error.code==='ENOENT')return;throw error}}
export async function readCombinedEverydayJournal(userDataDir,sessionId,taskId,configDir){
 const root=join(configDir??join(userDataDir,'claude-code-profile/config'),'projects'),names=await readdir(root,{recursive:true});assert.ok(names.length<=4096);
 const selected=names.filter(name=>basename(name)===(taskId?'agent-'+taskId+'.jsonl':sessionId+'.jsonl'));assert.equal(selected.length,1,'Expected one original journal');
 const path=join(root,selected[0]),info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=16*1048576);return readFile(path);
}
export async function driveCombinedEveryday(options){
 const verifyAttachmentRecovery=options.verifyAttachmentRecovery??false;assert.equal(typeof verifyAttachmentRecovery,'boolean');
 const agentReadingProbe=options.agentReadingProbe??false;assert.equal(typeof agentReadingProbe,'boolean');
 const agentFormattingProbe=options.agentFormattingProbe??false;assert.equal(typeof agentFormattingProbe,'boolean');
 const output=join(options.workspace,'electron-results');await mkdir(output,{recursive:true});const profile=await prepareCombinedEverydayProfile(options);let provider;
 try{
  await driveChildComposer({...options,modelRequestLimit:32,modelFactory:async args=>(provider=await startCombinedEverydayModel({...args,agentReadingProbe})),journey:args=>combinedJourney({...args,profile,verifyAttachmentRecovery,agentReadingProbe,agentFormattingProbe}),journeyName:'combined-everyday'});
  const p=JSON.parse(await readFile(join(output,'combined-everyday.json'),'utf8')),userDataDir=join(options.setupWorkspace,'app-data');
  const main=await readCombinedEverydayJournal(userDataDir,p.parentSessionId,undefined,profile.configDir),worker=await readCombinedEverydayJournal(userDataDir,p.parentSessionId,p.taskId,profile.configDir);await writeFile(join(output,'native-parent-transcript.jsonl'),main);await writeFile(join(output,'native-agent-transcript.jsonl'),worker);
  const ledger=main.toString().split('\n').filter(Boolean).map(JSON.parse).filter(row=>row.type==='cost-state').at(-1);assert.equal(ledger?.totalCostUSD,p.final.claude.totalCostUsd);
  p.persistedCost=ledger.totalCostUSD;p.journals={parentSha256:sha(main),agentSha256:sha(worker)};p.allInvocations=await profile.invocations();p.helperWritersRetired=(await Promise.all(p.allInvocations.map(row=>processStart(row.pid)))).every((value,index)=>value!==p.allInvocations[index].start);assert.ok(p.helperWritersRetired);await writeFile(join(output,'combined-everyday.json'),JSON.stringify(p,null,2));
 }finally{
  if(provider){await writeFile(join(output,'everyday-agent-calls.json'),JSON.stringify(provider.agentCalls,null,2));await writeFile(join(output,'everyday-seed-calls.json'),JSON.stringify(provider.seedCalls,null,2))}
  await profile.restore();await writeFile(join(output,'combined-agent-restoration.json'),await readFile(join(options.workspace,'combined-agent-restoration.json')));for(const name of ['before','after','restored'])await writeFile(join(output,'combined-settings-'+name+'.json'),await readFile(join(options.workspace,'combined-settings-'+name+'.json')));
 }
}
export async function combinedJourney({app,page,electronApp,output,project,userDataDir,expect,phase,model,profile,verifyAttachmentRecovery,agentReadingProbe,agentFormattingProbe,freshProfile=false,verifyPermissionOwnership=false}){
 const producer=JSON.parse(await readFile('/control/producer-pack-inputs.json','utf8')),installed=join(userDataDir,'apack/packs/default-setup'),files={};for(const name of ['runtime/fe.js','runtime/index.cjs']){files[name]=sha(await readFile(join(installed,name)));assert.equal(files[name],producer[name],'Installed candidate mismatch: '+name)}await writeFile(join(output,'installed-candidate-before-journey.json'),JSON.stringify({passed:true,files}));
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 // Verify the actual owned profile through Settings before creating a conversation.
 // This also completes surface navigation instead of racing initial chat restoration.
 await app.navigate('host/settings');
 await page.evaluate(()=>{const actor=window.applicationState.system.get('host/settings');actor.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});actor.send({type:'TAB.SELECT',tab:'features'});});
 await expect(page.locator('#claude-profile')).toHaveValue(freshProfile?'shared':'app');
 if(freshProfile){await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');await page.waitForTimeout(700);}
 await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.tabs.every(tab=>c.tabsRead.includes(tab.id));}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,phase:c.phase,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.entries(c.nativeTerminalViews).filter(([,v])=>v.threadId===c.currentThread?.id).map(([mountId,v])=>({...v,mountId}))[0],ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Help me review the release notes and checklist.');await card.getByRole('button',{name:'Send',exact:true}).click();
 // Respect the runtime's 30s initialization allowance before checking its first completed reply.
 await expect.poll(async()=>typeof (await context()).claude?.model,{timeout:30000}).toBe('string');phase('native-print-initialized');
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 if(freshProfile){const {recognizeOnboardingPrompt}=await import('../protocol/pty-onboarding.mjs'),seen=new Set();for(let i=0;i<100;i++){const native=(await context()).native?.state;if(native?.nativePid&&native.status==='live')break;const text=await section.locator('[data-terminal-text]').innerText().catch(()=>''),stage=recognizeOnboardingPrompt(text,project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100);}}
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const proof={status:'running',parentSessionId,pid:initial.native.state.nativePid,captures:[],geometry:[],helperSha256:profile.helperSha256,scope:'One ordinary main-owner composing/status, Agent, Read approval, question, Pause and same-session recovery journey. Not all remaining contracts or combined F1–F5 acceptance.'};proof.processStart=await processStart(proof.pid);assert.ok(proof.processStart);
 const save=()=>writeFile(join(output,'combined-everyday.json'),JSON.stringify(proof,null,2));
 const send=card.getByRole('button',{name:'Send',exact:true});
 let verifyAgentReading,verifyAgentFormatting;
 const permissionLabels={default:'Default',acceptEdits:'Accept edits',plan:'Plan',auto:'Auto',dontAsk:"Don’t ask",bypassPermissions:'Bypass'};
 const verifyPermission=async(stage,size)=>{
  if(!verifyPermissionOwnership)return;
  const label=card.getByRole('status',{name:'Claude permission mode',exact:true}),state=await context();
  if(stage==='composer'){
   assert.equal(state.claude.sessionId,parentSessionId);assert.equal(state.native.state.status,'live');
   const owner=state.native?.threadId===state.threadId&&state.native.state.view?.kind==='main'?state.native.state:undefined;
   assert.ok(owner);assert.equal(owner.sessionId,parentSessionId);const mode=owner.session.permissionMode;assert.equal(mode,state.claude.permissionMode);assert.ok(Object.hasOwn(permissionLabels,mode),'Native main permission mode must be known');
   await expect(label).toHaveText('Permissions: '+permissionLabels[mode]);await expect(label).toBeInViewport({ratio:1});
   (proof.permissionOwnership??=[]).push({stage,size,sessionId:state.claude.sessionId,mode,ownerId:owner.ownerId,nativeSession:owner.session,text:await label.innerText()});
  }else if(stage==='agent'||stage==='agent-result'){
   const focused=page.getByRole('region',{name:'Focused Agent conversation',exact:true});
   await expect(focused.getByRole('status',{name:'Claude permission mode',exact:true})).toHaveCount(0);
   (proof.permissionOwnership??=[]).push({stage,size,sessionId:state.claude.sessionId,taskId:proof.taskId,inheritedParentLabels:0});
  }else if(stage==='recovered'){
   await expect(label).toHaveCount(0);
   (proof.permissionOwnership??=[]).push({stage,size,sessionId:state.claude.sessionId,retiredNativeLabels:0});
  }
 };
 const capture=async(stage,controls)=>{for(const [name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(size);if(stage==='agent-result'&&verifyAgentReading)await verifyAgentReading(name,size);if(stage==='agent-result'&&verifyAgentFormatting)await verifyAgentFormatting(name,size);for(const control of controls)await expect(control).toBeInViewport({ratio:1});await verifyPermission(stage,name);if(stage==='composer'){const hint=await card.locator('[aria-label="Native keyboard hint"]').boundingBox(),toolbar=await card.locator('[data-composer-toolbar]').boundingBox();assert.ok(hint&&toolbar&&hint.y+hint.height<=toolbar.y+1,'Native keyboard hint must remain above the sticky actions');(proof.composerBounds??=[]).push({name,hint,toolbar})}const file='combined-everyday-'+stage+'-'+name+'.png';await page.screenshot({path:join(output,file)});proof.captures.push(file);proof.geometry.push({stage,name,...size,sessionId:(await context()).claude.sessionId});await save()}phase('captured-'+stage)};
 const sendMain=async text=>{await composer.focus();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await expect(composer).toHaveText('');await composer.fill(text);await expect(composer).toHaveText(text);await send.click()};
 let pausedWriter;
 try{
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  const status=card.getByRole('status',{name:'Claude session status',exact:true});
  const currentUi=async()=>{const c=await context();const entry=Object.entries(c.ui).filter(([,view])=>view.threadId===c.threadId&&view.state.status!=='disconnected').at(-1);return entry?{mountId:entry[0],...entry[1]}:undefined};
  if(verifyAttachmentRecovery){
   await expect.poll(async()=>(await currentUi())?.state.status,{timeout:15000}).toBe('live');
   await expect(status).toContainText('Release review',{timeout:15000});
   const draft='Keep this release-review note while controls reconnect.';await composer.focus();await composer.fill(draft);await expect(composer).toHaveText(draft);
   proof.recoveryTransition={previousMountId:(await currentUi()).mountId,threadId:initial.threadId,phase:(await context()).phase};await save();
   await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
   await expect.poll(async()=>(await context()).threadId,{timeout:15000}).toBeUndefined();
   await page.evaluate(phase=>window.applicationState.system.get('default-setup/threads').send({type:'SET_PHASE',phase}),proof.recoveryTransition.phase);
   await expect.poll(async()=>(await context()).phase).toBe(proof.recoveryTransition.phase);
   pausedWriter=await pauseOwnedWriter(proof.pid,proof.processStart,output);phase('native-writer-paused',{pid:proof.pid,start:proof.processStart});
   await page.evaluate(threadId=>window.applicationState.system.get('default-setup/threads').send({type:'OPEN_THREAD_CHAT',threadId}),initial.threadId);
   await expect.poll(async()=>(await context()).threadId,{timeout:15000}).toBe(initial.threadId);await expect(composer).toHaveText(draft);
   await expect.poll(async()=>{const ui=await currentUi();return !!ui&&ui.mountId!==proof.recoveryTransition.previousMountId},{timeout:15000}).toBe(true);
  }
  await expect.poll(async()=>['live','error'].includes((await currentUi())?.state.status),{timeout:15000}).toBe(true);
  const beforeUi=await currentUi();
  if(beforeUi.state.status==='error'){
   proof.initialUiFailure={mountId:beforeUi.mountId,attachmentId:beforeUi.attachmentId,message:beforeUi.state.message};await save();
   const retry=card.getByRole('button',{name:'Reconnect controls',exact:true});
   if(await retry.isVisible()){
    const draft='Keep this release-review note while controls reconnect.';await composer.focus();await composer.fill(draft);await expect(composer).toHaveText(draft);
    if(pausedWriter){proof.attachmentPause=await pausedWriter.resume();assert.ok(proof.attachmentPause.resumed);await save();phase('native-writer-resumed',proof.attachmentPause)}
    const recoveryCaptures=[];
    for(const [size,viewport]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect(retry).toBeInViewport({ratio:1});await expect(composer).toBeInViewport({ratio:1});const file='combined-everyday-reconnect-before-'+size+'.png';await page.screenshot({path:join(output,file)});recoveryCaptures.push(file)}
    const clickedAtSize=page.viewportSize();phase('composer-reconnect-requested',{viewport:clickedAtSize});await retry.click({timeout:15000});
    await expect.poll(async()=>{const ui=await currentUi();return ui?.mountId!==beforeUi.mountId&&ui?.state.status==='live'},{timeout:15000}).toBe(true);
    await expect(composer).toHaveText(draft);const afterUi=await currentUi(),after=await context();assert.equal(after.native.state.nativePid,proof.pid);assert.equal(after.claude.sessionId,parentSessionId);assert.equal(await processStart(proof.pid),proof.processStart);
    for(const [size,viewport]of [['compact',{width:680,height:600}],['normal',{width:1100,height:900}]]){await page.setViewportSize(viewport);await expect(composer).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});const file='combined-everyday-reconnect-after-'+size+'.png';await page.screenshot({path:join(output,file)});recoveryCaptures.push(file)}
    proof.reconnect={previousMountId:beforeUi.mountId,mountId:afterUi.mountId,attachmentId:afterUi.attachmentId,status:afterUi.state.status,retainedDraft:draft,nativePid:after.native.state.nativePid,processStart:await processStart(proof.pid),sessionId:after.claude.sessionId,clickedAtSize,captures:recoveryCaptures};await save();phase('composer-reconnected');
   }
  }
  if(verifyAttachmentRecovery)assert.ok(proof.reconnect&&proof.attachmentPause?.resumed,'The requested real failed-attachment recovery must actually occur');
  await expect.poll(async()=>(await currentUi())?.state.status,{timeout:15000}).toBe('live');
  await expect(status).toContainText('Release review',{timeout:15000});await expect(status).toContainText('Checklist and migration notes');
  await sendMain('Review the release notes with a worker.');await expect.poll(async()=>(await context()).native.state.tasks.some(task=>task.status==='running'),{timeout:15000}).toBe(true);
  const tools=page.getByRole('button',{name:/^Native tools/}).first();await expect(tools).toBeVisible({timeout:10000});if(await tools.getAttribute('aria-expanded')!=='true')await tools.click({timeout:10000});const row=page.locator('[data-native-agent-id]').first();await expect(row).toBeVisible({timeout:15000});proof.taskId=await row.getAttribute('data-native-agent-id',{timeout:1000});assert.ok(proof.taskId);
  await expect(row.getByTestId('native-agent-status-text')).toContainText('Reviewing release notes',{timeout:15000});proof.statusInvocations=await profile.invocations();assert.ok(proof.statusInvocations.some(item=>item.kind==='main'&&item.input.session_id===parentSessionId));assert.ok(proof.statusInvocations.some(item=>item.kind==='agent'&&item.input.tasks.some(task=>task.id===proof.taskId)));
  const parentDraft='Keep the release checklist wording unchanged.',agentDraft='Please also note the migration steps.';proof.parentDraft=parentDraft;proof.agentDraft=agentDraft;await composer.fill(parentDraft);await row.getByRole('button',{name:'Open Agent',exact:true}).click();
  const focused=page.getByRole('region',{name:'Focused Agent conversation',exact:true}),agentForm=focused.getByRole('form',{name:'Agent message',exact:true}),agentEditor=agentForm.locator('[contenteditable="true"]'),agentStatus=focused.getByRole('status',{name:'Claude session status',exact:true});if(agentReadingProbe)verifyAgentReading=async(name,size)=>{
   const transcript=focused.getByRole('region',{name:'Agent transcript',exact:true}),latest=focused.getByRole('button',{name:'Jump to latest Agent message',exact:true});
   if(await latest.isVisible())await latest.click();
   const measure=()=>transcript.evaluate(el=>{const style=getComputedStyle(el.querySelector('article p')??el),lineHeight=parseFloat(style.lineHeight)||parseFloat(style.fontSize)*1.5;return{top:el.scrollTop,max:el.scrollHeight-el.clientHeight,height:el.clientHeight,lineHeight};});
   await expect.poll(async()=>{const p=await measure();return p.max>40&&Math.abs(p.max-p.top)<=1;}).toBe(true);
   const bounds=await transcript.boundingBox();assert.ok(bounds&&bounds.height>40);await page.mouse.move(bounds.x+bounds.width/2,bounds.y+bounds.height/2);await page.mouse.wheel(0,-12);
   await expect.poll(async()=>{const p=await measure();return p.max-p.top>1&&p.max-p.top<=24;}).toBe(true);
   const before=await measure();assert.ok(before.height>=104,'Agent history must show at least four text lines beside the draft');await expect(latest).toBeVisible();await page.setViewportSize({...size,height:size.height-2});await page.setViewportSize(size);
   await transcript.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))));
   const after=await measure();assert.ok(Math.abs(after.top-before.top)<=1,'A short Agent history read must survive reflow');await expect(latest).toBeVisible();await expect(agentEditor).toHaveText(agentDraft);
   (proof.agentReading??=[]).push({name,before,after,draft:await agentEditor.textContent(),sessionId:(await context()).claude.sessionId});await save();
  };
  if(agentFormattingProbe)verifyAgentFormatting=async(name,size)=>{
   const selectionKeys={name,steps:[]};(proof.agentSelectionKeys??=[]).push(selectionKeys);
   const press=async key=>{await agentEditor.press(key);selectionKeys.steps.push(await agentEditor.evaluate((el,key)=>{const s=getSelection(),state=el.editor?.state;return{key,selected:s?.toString(),anchor:s?.anchorOffset,head:s?.focusOffset,focused:document.activeElement===el,model:state?.selection.toJSON()};},key));};
   await electronApp.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0]?.focus());await agentEditor.focus();await press('Home');
   for(let i=0;i<5;i++)await press('ArrowRight');
   await page.keyboard.down('Shift');try{for(let i=0;i<12;i++)await press('ArrowRight');}finally{await page.keyboard.up('Shift');}await save();
   const selected=agentDraft.slice(5,17);await expect.poll(()=>page.evaluate(()=>getSelection()?.toString())).toBe(selected);
   const toolbar=page.locator('.bubble-menu:visible');await expect(toolbar).toHaveCount(1);
   await expect.poll(()=>toolbar.evaluate(el=>{const r=el.getBoundingClientRect(),selection=getSelection();if(!selection?.rangeCount)return false;const t=selection.getRangeAt(0).getBoundingClientRect();return r.right<=t.x||r.x>=t.right||r.bottom<=t.y||r.y>=t.bottom;}),{timeout:5000}).toBe(true);
   const menu=await toolbar.evaluate(el=>{const r=el.getBoundingClientRect(),selection=getSelection(),t=selection?.rangeCount?selection.getRangeAt(0).getBoundingClientRect():null;return {selection:t?{x:t.x,y:t.y,right:t.right,bottom:t.bottom}:null,x:r.x,y:r.y,right:r.right,bottom:r.bottom,controls:[...el.querySelectorAll('button')].filter(b=>b.getBoundingClientRect().width).map(b=>{const r=b.getBoundingClientRect();return {label:b.title||b.textContent,reachable:b.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))};})};});
   assert.equal(menu.controls.length,6);assert.ok(menu.controls.every(c=>c.reachable));
   const readText=element=>{const characters=[],walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT);let node;while(node=walker.nextNode())for(let i=0;i<node.textContent.length;i++){if(!node.textContent[i].trim())continue;const range=document.createRange();range.setStart(node,i);range.setEnd(node,i+1);for(const r of range.getClientRects())if(r.width&&r.height)characters.push({x:r.x,y:r.y,right:r.right,bottom:r.bottom,reachable:element.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))});}return{text:element.textContent,characters};};
   const status=await agentStatus.evaluate(readText),hint=await agentForm.getByText('Enter to send · Shift+Enter for a new line',{exact:true}).evaluate(readText);
   for(const text of [status,hint]){assert.ok(text.characters.length);assert.ok(text.characters.every(c=>c.reachable&&(menu.right<=c.x||menu.x>=c.right||menu.bottom<=c.y||menu.y>=c.bottom)));}
   const historyHeight=await focused.getByRole('region',{name:'Agent transcript',exact:true}).evaluate(el=>el.clientHeight);assert.ok(historyHeight>=104);await expect(agentEditor).toHaveText(agentDraft);
   const actualSelected=await page.evaluate(()=>getSelection()?.toString());assert.equal(actualSelected,selected);
   (proof.agentFormatting??=[]).push({name,viewport:size,menu,status,hint,historyHeight,selected:actualSelected,draft:await agentEditor.textContent(),sessionId:(await context()).claude.sessionId,taskId:proof.taskId});await save();
  };
  await agentEditor.fill(agentDraft);await expect(agentStatus).toContainText('Reviewing release notes');await capture('agent',[agentStatus,agentEditor,agentForm.getByRole('button',{name:'Send to Agent',exact:true}),focused.getByRole('button',{name:'Back to conversation',exact:true})]);
  await focused.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toHaveText(parentDraft);proof.parentAfterReturn=await context();await save();phase('agent-parent-returned');await expect.poll(async()=>(await context()).native.state.tasks.find(task=>task.id===proof.taskId)?.status,{timeout:20000}).toBe('completed');proof.agentCompleted=await context();await save();phase('agent-task-completed');
  if(!await row.isVisible())await page.getByRole('button',{name:/^Native tools/}).first().click({timeout:15000});const reopen=row.getByRole('button',{name:'Open Agent',exact:true});proof.reopenControl={count:await reopen.count(),visible:await reopen.isVisible()};await save();phase('agent-reopen-requested',proof.reopenControl);await reopen.click({timeout:15000});await expect(agentEditor).toHaveText(agentDraft);await expect(focused.getByRole('region',{name:'Agent transcript',exact:true})).toContainText('The release notes cover behavior changes and migration guidance.');await expect(agentStatus).toContainText('Reviewing release notes',{timeout:15000});await capture('agent-result',[agentStatus,agentEditor,focused.getByRole('button',{name:'Back to conversation',exact:true})]);await focused.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toHaveText(parentDraft);
  await expect.poll(async()=>(await context()).native.state.busy,{timeout:15000}).toBe(false);await expect(send).toBeEnabled();const keyboardHint=card.locator('[aria-label="Native keyboard hint"]');await expect(keyboardHint).toBeVisible();await capture('composer',[composer,send,status,keyboardHint]);
  await sendMain('Read the release checklist before proposing changes.');await expect.poll(()=>model.decision?.tool,{timeout:15000}).toBe('Read');await composer.fill('Keep my review draft while I approve this read.');model.releaseDecision('Read');
  const approval=page.getByTestId('native-read-approval');await expect(approval).toBeVisible();await expect(approval.getByTestId('native-read-path')).toHaveText(model.referenceFile);await expect(composer).toBeHidden();await capture('approval',[approval.getByTestId('native-read-path'),approval.getByRole('button',{name:'Approve',exact:true})]);await approval.getByRole('button',{name:'Approve',exact:true}).click();await expect(approval).toBeHidden();await expect.poll(()=>model.agentCalls.some(call=>call.referenceReadResult!==undefined&&!call.referenceReadError&&JSON.stringify(call.referenceReadResult).includes('Keep migration guidance')),{timeout:15000}).toBe(true);await expect(composer).toHaveText('Keep my review draft while I approve this read.');
  await sendMain('Ask me which release audience to target.');await expect.poll(()=>model.decision?.tool,{timeout:15000}).toBe('AskUserQuestion');await composer.fill('Use a direct, concise tone in the summary.');model.releaseDecision('AskUserQuestion');
  const question=page.getByTestId('native-question-panel');await expect(question).toBeVisible();await expect(question).toContainText('Who should the release summary address?');await expect(composer).toBeHidden();await capture('question',[question.getByRole('button',{name:'Submit answers',exact:true})]);await question.getByRole('radio',{name:'Developers People integrating the updated behavior',exact:true}).check();await question.getByRole('button',{name:'Submit answers',exact:true}).click();await expect(question).toBeHidden();await expect.poll(()=>model.agentCalls.some(call=>call.nativeQuestionResult!==undefined&&!call.nativeQuestionError&&JSON.stringify(call.nativeQuestionResult).includes('Developers')),{timeout:15000}).toBe(true);await expect(composer).toHaveText('Use a direct, concise tone in the summary.');
  await sendMain('Draft the release summary while I review the checklist.');await expect.poll(()=>model.agentCalls.some(call=>call.pauseWaiting),{timeout:15000}).toBe(true);await composer.fill('Keep this note after interruption.');await card.getByTitle('Pause agent work',{exact:true}).click();await expect.poll(async()=>(await context()).native.state.busy,{timeout:15000}).toBe(false);proof.paused=await context();assert.equal(proof.paused.native.state.nativePid,proof.pid);assert.equal(proof.paused.native.state.status,'live');await expect(composer).toHaveText('Keep this note after interruption.');await expect.poll(()=>model.agentCalls.some(call=>call.pauseCancelled),{timeout:10000}).toBe(true);
  const taskBeforeStop=(await context()).native?.task;
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processStart(proof.pid),{timeout:15000}).not.toBe(proof.processStart);proof.nativeWriterRetired=true;const back=section.getByRole('button',{name:'Back to conversation',exact:true});if(await back.isVisible())await back.click();await expect(composer).toBeVisible();await expect(composer).toBeEditable();await expect(composer).toHaveText('Keep this note after interruption.');
  if(agentFormattingProbe){
   await expect.poll(async()=>(await context()).native?.stop?.status,{timeout:5000}).toBe('done');
   const returned=await context();assert.equal(returned.native.stop.ownerId,proof.paused.native.state.ownerId);assert.ok(returned.native.task?.operation!=='background'||returned.native.task.revision<=(taskBeforeStop?.revision??0));
   proof.stopReturn={stop:returned.native.stop,taskBefore:taskBeforeStop,taskAfter:returned.native.task,composerVisible:true,composerEditable:true,draft:await composer.textContent(),sessionId:returned.claude.sessionId,nativeOwnerId:proof.paused.native.state.ownerId};await save();
  }
  const stoppedJournal=await readCombinedEverydayJournal(userDataDir,parentSessionId,undefined,profile.configDir);await writeFile(join(output,'native-before-resume-transcript.jsonl'),stoppedJournal);proof.nativeCost=JSON.parse(stoppedJournal.toString().trim().split('\n').filter(Boolean).filter(line=>JSON.parse(line).type==='cost-state').at(-1)).totalCostUSD;await expect.poll(async()=>(await context()).claude.totalCostUsd).toBe(proof.nativeCost);
  await sendMain('Continue the same release review after the interruption.');await expect.poll(async()=>(await context()).claude.chatState,{timeout:15000}).toBe('success');assert.equal((await context()).claude.sessionId,parentSessionId);await composer.fill('Ready for the next release-review step.');await expect(send).toBeEnabled();await capture('recovered',[composer,send]);proof.final=await context();assert.ok(proof.final.claude.totalCostUsd>proof.nativeCost);proof.status='complete';await save();phase('combined-everyday-complete');
 }catch(error){proof.error={name:error.name,message:error.message.slice(0,2000)};proof.observed=await context().catch(()=>null);await page.screenshot({path:join(output,'combined-everyday-failure.png')}).catch(()=>{});throw error}finally{await pausedWriter?.resume();await save()}
}

/** Bound a real unresponsive-owner fault to this fixture's own native descendant. */
async function pauseOwnedWriter(pid,start,output){
 assert.equal(process.platform,'linux');assert.match(output,/^\/work\/\.claude-research\/combined-everyday-app[0-9]+\/electron-results$/);
 assert.ok(Number.isSafeInteger(pid)&&pid>1&&pid!==process.pid);assert.equal(await processStart(pid),start);
 assert.equal((await lstat('/proc/'+pid)).uid,process.getuid());
 let ancestor=pid,owned=false;for(let i=0;i<24&&ancestor>1;i++){const raw=await readFile('/proc/'+ancestor+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');ancestor=Number(fields[1]);if(ancestor===process.pid){owned=true;break}}assert.ok(owned,'Only the current fixture native descendant may be paused');
 const receipt=join(output,'native-pause-watchdog.json');
 const source=`const fs=require('node:fs');const [pid,start,file]=process.argv.slice(1),began=Date.now();function current(){try{const raw=fs.readFileSync('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[19]===start&&fs.statSync('/proc/'+pid).uid===process.getuid()?fields[0]:undefined}catch{return undefined}}setTimeout(()=>{const before=current(),result={pid:Number(pid),start,delayMs:10000,elapsedMs:Date.now()-began,stateBeforeResume:before,resumed:false};if(before){process.kill(Number(pid),'SIGCONT');result.resumed=true}fs.writeFileSync(file,JSON.stringify(result),{flag:'wx',mode:0o600});process.exit(result.resumed?0:1)},10000);process.stdout.write('armed\\n');`;
 const watcher=spawn(process.execPath,['--max-old-space-size=64','-e',source,String(pid),start,receipt],{stdio:['ignore','pipe','pipe']});let stderr='';watcher.stderr.on('data',bytes=>{stderr=(stderr+bytes).slice(0,4096)});
 const done=new Promise((resolve,reject)=>{watcher.once('error',reject);watcher.once('exit',(code,signal)=>code===0?resolve():reject(Error('Native pause watchdog failed: '+code+'/'+signal+' '+stderr)))});done.catch(()=>{});
 try{
  await Promise.race([once(watcher.stdout,'data'),done.then(()=>{throw Error('Watchdog exited before pause')})]);assert.equal(watcher.exitCode,null);assert.equal(await processStart(pid),start);process.kill(pid,'SIGSTOP');
  const raw=await readFile('/proc/'+pid+'/stat','utf8');assert.equal(raw.slice(raw.lastIndexOf(')')+2).split(' ')[0],'T');
 }catch(error){if(await processStart(pid)===start)process.kill(pid,'SIGCONT');await done.catch(()=>{});throw error}
 return {async resume(){if(await processStart(pid)===start)process.kill(pid,'SIGCONT');await done;return JSON.parse(await readFile(receipt,'utf8'))}};
}
