import { verifyReadImageFormats as readImageFormatJourney } from './native-read-image-formats-journey.mjs';
import {createEverydayWindowControls} from './everyday-window-controls.mjs';
import assert from 'node:assert/strict';
import {verifyHeldReadClear} from './held-read-clear-journey.mjs';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {readFile,writeFile,readdir,lstat,mkdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {startCombinedEverydayModel} from '../protocol/combined-everyday-model.mjs';
import {prepareCombinedEverydayProfile} from './combined-everyday-profile.mjs';
import {verifyPromptControlsReplacement} from './prompt-controls-replacement-journey.mjs';
import {verifyPromptCompletionLayout} from './prompt-completion-layout-journey.mjs';
import {createNativeTestImage} from '../protocol/native-test-image.mjs';
import {readNativeTranscriptRow} from './native-transcript-evidence.mjs';

const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function processStart(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]==='Z'?undefined:fields[19]}catch(error){if(error.code==='ENOENT')return;throw error}}
export async function readCombinedEverydayJournal(userDataDir,sessionId,taskId,configDir){
 const root=join(configDir??join(userDataDir,'claude-code-profile/config'),'projects'),names=await readdir(root,{recursive:true});assert.ok(names.length<=4096);
 const selected=names.filter(name=>basename(name)===(taskId?'agent-'+taskId+'.jsonl':sessionId+'.jsonl'));assert.equal(selected.length,1,'Expected one original journal');
 const path=join(root,selected[0]),info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=16*1048576);return readFile(path);
}
export async function driveCombinedEveryday(options){
 const verifyAttachmentRecovery=options.verifyAttachmentRecovery??false;assert.equal(typeof verifyAttachmentRecovery,'boolean');
 const agentReadingProbe=options.agentReadingProbe??false;assert.equal(typeof agentReadingProbe,'boolean');
 const agentFormattingProbe=options.agentFormattingProbe??false;assert.equal(typeof agentFormattingProbe,'boolean');
 const output=join(options.workspace,'electron-results');await mkdir(output,{recursive:true});const profile=await prepareCombinedEverydayProfile(options);let provider;
 try{
  await driveChildComposer({...options,modelRequestLimit:32,modelFactory:async args=>(provider=await startCombinedEverydayModel({...args,agentReadingProbe})),journey:args=>combinedJourney({...args,profile,verifyAttachmentRecovery,agentReadingProbe,agentFormattingProbe}),journeyName:'combined-everyday'});
  const p=JSON.parse(await readFile(join(output,'combined-everyday.json'),'utf8')),userDataDir=join(options.setupWorkspace,'app-data');
  const main=await readCombinedEverydayJournal(userDataDir,p.parentSessionId,undefined,profile.configDir),worker=await readCombinedEverydayJournal(userDataDir,p.parentSessionId,p.taskId,profile.configDir);await writeFile(join(output,'native-parent-transcript.jsonl'),main);await writeFile(join(output,'native-agent-transcript.jsonl'),worker);
  const ledger=main.toString().split('\n').filter(Boolean).map(JSON.parse).filter(row=>row.type==='cost-state').at(-1);assert.equal(ledger?.totalCostUSD,p.final.claude.totalCostUsd);
  p.persistedCost=ledger.totalCostUSD;p.journals={parentSha256:sha(main),agentSha256:sha(worker)};p.allInvocations=await profile.invocations();p.helperWritersRetired=(await Promise.all(p.allInvocations.map(row=>processStart(row.pid)))).every((value,index)=>value!==p.allInvocations[index].start);assert.ok(p.helperWritersRetired);await writeFile(join(output,'combined-everyday.json'),JSON.stringify(p,null,2));
 }finally{
  if(provider){await writeFile(join(output,'everyday-agent-calls.json'),JSON.stringify(provider.agentCalls,null,2));await writeFile(join(output,'everyday-seed-calls.json'),JSON.stringify(provider.seedCalls,null,2))}
  await profile.restore();await writeFile(join(output,'combined-agent-restoration.json'),await readFile(join(options.workspace,'combined-agent-restoration.json')));for(const name of ['before','after','restored'])await writeFile(join(output,'combined-settings-'+name+'.json'),await readFile(join(options.workspace,'combined-settings-'+name+'.json')));
 }
}
export async function combinedJourney({app,page,electronApp,output,project,userDataDir,expect,phase,model,profile,verifyAttachmentRecovery,agentReadingProbe,agentFormattingProbe,agentRapidSelectionProbe=false,agentStatusTransitions=false,verifyAgentStatusFocus=false,keepLongAgentStatus=false,freshProfile=false,verifyPermissionOwnership=false,verifyWindowControls=false,verifyStaleWindowResponses=false,verifyStableToolDisclosure=false,verifySessionReset=false,verifyResetImage=false,verifyWorkspaceHeader=false,verifyMemoryRoundTrip=false,verifyCompactAgentWorkspace=false,verifyQuestionAttachment=false,measureResetFooter=false,promptEditHold,verifyPromptControlReplacement=false,promptRetiredBeforeExpiry=false,measurePromptCompletionLayout=false,measureAgentFooter=false,verifyCompletionWindowFocus=false,verifyRestingAgentHint=false,fleetFooterWorker,readImageCases,verifyReadClear=false}){
 const producer=JSON.parse(await readFile('/control/producer-pack-inputs.json','utf8')),installed=join(userDataDir,'apack/packs/default-setup'),files={};for(const name of ['runtime/fe.js','runtime/index.cjs']){files[name]=sha(await readFile(join(installed,name)));assert.equal(files[name],producer[name],'Installed candidate mismatch: '+name)}await writeFile(join(output,'installed-candidate-before-journey.json'),JSON.stringify({passed:true,files}));
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 // Verify the actual owned profile through Settings before creating a conversation.
 // This also completes surface navigation instead of racing initial chat restoration.
 await app.navigate('host/settings');
 await page.evaluate(()=>{const actor=window.applicationState.system.get('host/settings');actor.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});actor.send({type:'TAB.SELECT',tab:'features'});});
 await expect(page.locator('#claude-profile')).toHaveValue(freshProfile?'shared':'app');
 if(freshProfile){await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');await page.waitForTimeout(700);}
 await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.tabs.every(tab=>c.tabsRead.includes(tab.id));}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,phase:c.phase,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.entries(c.nativeTerminalViews).filter(([,v])=>v.threadId===c.currentThread?.id).map(([mountId,v])=>({...v,mountId}))[0],ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Help me review the release notes and checklist.');await card.getByRole('button',{name:'Send',exact:true}).click();
 // Respect the runtime's 30s initialization allowance before checking its first completed reply.
 await expect.poll(async()=>typeof (await context()).claude?.model,{timeout:30000}).toBe('string');phase('native-print-initialized');
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const fleetJob=await fleetFooterWorker?.start();
 if(fleetJob)phase('native-fleet-job-blocked',{id:fleetJob.id,sessionId:fleetJob.sessionId});
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 if(freshProfile){const {recognizeOnboardingPrompt}=await import('../protocol/pty-onboarding.mjs'),seen=new Set();for(let i=0;i<100;i++){const native=(await context()).native?.state;if(native?.nativePid&&native.status==='live')break;const text=await section.locator('[data-terminal-text]').innerText().catch(()=>''),stage=recognizeOnboardingPrompt(text,project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100);}}
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId,readyAt=Date.now();phase('native-parent-ready');

 const proof={status:'running',parentSessionId,pid:initial.native.state.nativePid,captures:[],geometry:[],helperSha256:profile.helperSha256,scope:'One ordinary main-owner composing/status, Agent, Read approval, question, Pause and same-session recovery journey. Not all remaining contracts or combined F1–F5 acceptance.'};proof.processStart=await processStart(proof.pid);assert.ok(proof.processStart);
 const save=()=>writeFile(join(output,'combined-everyday.json'),JSON.stringify(proof,null,2));
 const send=card.getByRole('button',{name:'Send',exact:true});
 let verifyAgentReading,verifyAgentFormatting;
 const permissionLabels={default:'Default',acceptEdits:'Accept edits',plan:'Plan',auto:'Auto',dontAsk:"Don’t ask",bypassPermissions:'Bypass'};
 const verifyPermission=async(stage,size)=>{
  if(!verifyPermissionOwnership)return;
  const label=card.getByRole('status',{name:'Claude permission mode',exact:true}),state=await context();
  if(stage==='composer'){
   assert.equal(state.claude.sessionId,parentSessionId);assert.equal(state.native.state.status,'live');
   const owner=state.native?.threadId===state.threadId&&state.native.state.view?.kind==='main'?state.native.state:undefined;
   assert.ok(owner);assert.equal(owner.sessionId,parentSessionId);const mode=owner.session.permissionMode;assert.equal(mode,state.claude.permissionMode);assert.ok(Object.hasOwn(permissionLabels,mode),'Native main permission mode must be known');
   await expect(label).toHaveText('Permissions: '+permissionLabels[mode]);await expect(label).toBeInViewport({ratio:1});
   (proof.permissionOwnership??=[]).push({stage,size,sessionId:state.claude.sessionId,mode,ownerId:owner.ownerId,nativeSession:owner.session,text:await label.innerText()});
  }else if(stage==='agent'||stage==='agent-result'){
   const focused=page.getByRole('region',{name:'Focused Agent conversation',exact:true});
   await expect(focused.getByRole('status',{name:'Claude permission mode',exact:true})).toHaveCount(0);
   (proof.permissionOwnership??=[]).push({stage,size,sessionId:state.claude.sessionId,taskId:proof.taskId,inheritedParentLabels:0});
  }else if(stage==='recovered'){
   await expect(label).toHaveCount(0);
   (proof.permissionOwnership??=[]).push({stage,size,sessionId:state.claude.sessionId,retiredNativeLabels:0});
  }
 };
 const recordWorkspaceHeader=async(stage,size)=>{
  const canvas=page.locator('[data-onboarding-id="canvas-area"]');
  const controls={
   dashboard:canvas.getByTitle('Dashboard',{exact:true}),
   filter:canvas.getByRole('button',{name:'Filter',exact:true}),
   search:canvas.getByPlaceholder('Search threads...',{exact:true}),
   newThread:canvas.getByRole('button',{name:'New Thread',exact:true}),
  };
  const reachable=Object.fromEntries(await Promise.all(Object.entries(controls).map(async ([key,control])=>[key,await control.evaluate(element=>{
   const rect=element.getBoundingClientRect();
   return [0.2,0.5,0.8].every(fraction=>element.contains(document.elementFromPoint(rect.x+rect.width*fraction,rect.y+rect.height/2)));
  })])));
  (proof.workspaceHeader??=[]).push({stage,size,reachable});
  await save();
  assert.deepEqual(reachable,{dashboard:true,filter:true,search:true,newThread:true});
 };

 async function captureCompactAgentWorkspace(stage,size) {
  const canvas=page.locator('[data-onboarding-id="canvas-area"]');
  const details=canvas.getByRole('button',{name:'Open Claude session details',exact:true});
  const transcript=page.getByRole('region',{name:'Agent transcript',exact:true});
  const measure=()=>details.evaluate(el=>{
   const r=el.getBoundingClientRect();
   const inset=2;
   const reachable=[r.x+12,r.x+r.width-12].every(x=>[r.y+inset,r.bottom-inset].every(y=>el.contains(document.elementFromPoint(x,y))));
   return {top:r.top,bottom:r.bottom,height:r.height,reachable};
  });
  const sample={stage,viewport:size,row:await measure(),historyHeight:await transcript.evaluate(el=>el.clientHeight)};
  (proof.compactAgentWorkspace??=[]).push(sample);
  await save();
  assert.ok(sample.row.reachable&&sample.row.height>=24,'The Claude session details row must be fully visible before any scroll or click');
  assert.ok(sample.historyHeight>=104,'The compact Agent transcript must retain at least four text lines');
  if(stage==='agent'){
   await details.click();
   const popup=page.locator('[aria-label="Claude session details"]');
   await expect(popup.getByRole('heading',{name:'Session details',exact:true})).toBeVisible();
   await expect(popup).toContainText((await context()).claude.model);
   const disclosureCapture='combined-everyday-agent-workspace-details-compact.png';
   await page.screenshot({path:join(output,disclosureCapture)});
   proof.captures.push(disclosureCapture);
   await popup.getByRole('button',{name:'Close Claude session details',exact:true}).click();
   await expect(popup).toBeHidden();
   await expect(details).toBeFocused();
   await expect(page.getByRole('region',{name:'Focused Agent conversation',exact:true})).toBeVisible();
   sample.openedAndClosed=true;
  }
 }
 const capture=async(stage,controls)=>{for(const [name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(size);if(stage==='agent-result'&&verifyAgentReading)await verifyAgentReading(name,size);if(stage==='agent-result'&&verifyAgentFormatting)await verifyAgentFormatting(name,size);for(const control of controls)await expect(control).toBeInViewport({ratio:1});await verifyPermission(stage,name);if(verifyCompactAgentWorkspace&&name==='compact'&&(stage==='agent'||stage==='agent-result'))await captureCompactAgentWorkspace(stage,size);if(verifyWorkspaceHeader&&(stage==='composer'||stage==='agent-result'))await recordWorkspaceHeader(stage,name);if(stage==='composer'){const hint=await card.locator('[aria-label="Native keyboard hint"]').boundingBox(),toolbar=await card.locator('[data-composer-toolbar]').boundingBox();assert.ok(hint&&toolbar&&hint.y+hint.height<=toolbar.y+1,'Native keyboard hint must remain above the sticky actions');(proof.composerBounds??=[]).push({name,hint,toolbar})}const file='combined-everyday-'+stage+'-'+name+'.png';await page.screenshot({path:join(output,file)});proof.captures.push(file);proof.geometry.push({stage,name,...size,sessionId:(await context()).claude.sessionId});await save()}phase('captured-'+stage)};
 const typeNextMainDraft=async text=>{
  await expect.poll(()=>composer.evaluate(element=>element.editor?.state.doc.textContent??null),{message:'Original acceptance clears the sent prompt before typing the next draft'}).toBe('');
  await composer.focus();
  await page.keyboard.insertText(text);
  await expect(composer).toHaveText(text);
 };
 const sendMain=async text=>{await composer.focus();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await expect(composer).toHaveText('');await composer.fill(text);await expect(composer).toHaveText(text);await send.click()};
 let pausedWriter;
 try{
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  const status=card.getByRole('status',{name:'Claude session status',exact:true});
  const currentUi=async()=>{const c=await context();const entry=Object.entries(c.ui).filter(([,view])=>view.threadId===c.threadId&&view.state.status!=='disconnected').at(-1);return entry?{mountId:entry[0],...entry[1]}:undefined};
  if(verifyAttachmentRecovery){
   await expect.poll(async()=>(await currentUi())?.state.status,{timeout:15000}).toBe('live');
   await expect(status).toContainText('Release review',{timeout:15000});
   const draft='Keep this release-review note while controls reconnect.';await composer.focus();await composer.fill(draft);await expect(composer).toHaveText(draft);
   proof.recoveryTransition={previousMountId:(await currentUi()).mountId,threadId:initial.threadId,phase:(await context()).phase};await save();
   await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
   await expect.poll(async()=>(await context()).threadId,{timeout:15000}).toBeUndefined();
   await page.evaluate(phase=>window.applicationState.system.get('default-setup/threads').send({type:'SET_PHASE',phase}),proof.recoveryTransition.phase);
   await expect.poll(async()=>(await context()).phase).toBe(proof.recoveryTransition.phase);
   pausedWriter=await pauseOwnedWriter(proof.pid,proof.processStart,output,freshProfile);phase('native-writer-paused',{pid:proof.pid,start:proof.processStart});
   await page.evaluate(threadId=>window.applicationState.system.get('default-setup/threads').send({type:'OPEN_THREAD_CHAT',threadId}),initial.threadId);
   await expect.poll(async()=>(await context()).threadId,{timeout:15000}).toBe(initial.threadId);await expect(composer).toHaveText(draft);
   await expect.poll(async()=>{const ui=await currentUi();return !!ui&&ui.mountId!==proof.recoveryTransition.previousMountId},{timeout:15000}).toBe(true);
  }
  await expect.poll(async()=>['live','error'].includes((await currentUi())?.state.status),{timeout:15000}).toBe(true);
  const beforeUi=await currentUi();
  if(beforeUi.state.status==='error'){
   proof.initialUiFailure={mountId:beforeUi.mountId,attachmentId:beforeUi.attachmentId,message:beforeUi.state.message};await save();
   const retry=card.getByRole('button',{name:'Reconnect controls',exact:true});
   if(await retry.isVisible()){
    const draft='Keep this release-review note while controls reconnect.';await composer.focus();await composer.fill(draft);await expect(composer).toHaveText(draft);
    if(pausedWriter){proof.attachmentPause=await pausedWriter.resume();assert.ok(proof.attachmentPause.resumed);await save();phase('native-writer-resumed',proof.attachmentPause)}
    const recoveryCaptures=[];
    for(const [size,viewport]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect(retry).toBeInViewport({ratio:1});await expect(composer).toBeInViewport({ratio:1});const file='combined-everyday-reconnect-before-'+size+'.png';await page.screenshot({path:join(output,file)});recoveryCaptures.push(file)}
    const clickedAtSize=page.viewportSize();phase('composer-reconnect-requested',{viewport:clickedAtSize});await retry.click({timeout:15000});
    await expect.poll(async()=>{const ui=await currentUi();return ui?.mountId!==beforeUi.mountId&&ui?.state.status==='live'},{timeout:15000}).toBe(true);
    await expect(composer).toHaveText(draft);const afterUi=await currentUi(),after=await context();assert.equal(after.native.state.nativePid,proof.pid);assert.equal(after.claude.sessionId,parentSessionId);assert.equal(await processStart(proof.pid),proof.processStart);
    for(const [size,viewport]of [['compact',{width:680,height:600}],['normal',{width:1100,height:900}]]){await page.setViewportSize(viewport);await expect(composer).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});const file='combined-everyday-reconnect-after-'+size+'.png';await page.screenshot({path:join(output,file)});recoveryCaptures.push(file)}
    proof.reconnect={previousMountId:beforeUi.mountId,mountId:afterUi.mountId,attachmentId:afterUi.attachmentId,status:afterUi.state.status,retainedDraft:draft,nativePid:after.native.state.nativePid,processStart:await processStart(proof.pid),sessionId:after.claude.sessionId,clickedAtSize,captures:recoveryCaptures};await save();phase('composer-reconnected');
   }
  }
  if(verifyAttachmentRecovery)assert.ok(proof.reconnect&&proof.attachmentPause?.resumed,'The requested real failed-attachment recovery must actually occur');
  await expect.poll(async()=>(await currentUi())?.state.status,{timeout:15000}).toBe('live');
  await expect(status).toContainText('Release review',{timeout:15000});await expect(status).toContainText('Checklist and migration notes');
  if (readImageCases) {
   await readImageFormatJourney({page,electronApp,section,composer,send,status,expect,context,output,project,proof,save,sendMain,processStart,model,cases:readImageCases,
    readJournal:()=>readCombinedEverydayJournal(userDataDir,parentSessionId,undefined,profile.configDir)});
   return;
  }
  if (verifyRestingAgentHint || fleetJob) {
   const hints=card.locator('[aria-label="Native keyboard hint"]'),arrow=/← for agents/,count=/\b1 agent\b/;
   const footer=proof[fleetJob?"fleetWaitingHint":"restingAgentHint"]={captures:[]};
   const captureHint=async (state, pattern, present)=>{
    for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
     await page.setViewportSize(viewport);
     await expect(hints).toContainText('shift+tab to cycle');
     if(present)await expect(hints).toContainText(pattern,{timeout:2500});
     else await expect(hints).not.toContainText(pattern,{timeout:2500});
     await expect(hints).toBeInViewport({ratio:1});
     const name='resting-agent-hint-'+state+'-'+size+'.png';
     await page.screenshot({path:join(output,name),animations:'disabled'});
     footer.captures.push({state,size,name,text:await hints.innerText(),elapsedMs:Date.now()-readyAt});
    }
   };
   let draft='';
   if(fleetJob){
    proof.scope='One different native fleet session waits for a real question and the main composer reflects its count.';
    assert.notEqual(fleetJob.sessionId,parentSessionId);
    footer.job=fleetJob;
    await save();
    draft='Keep the release review notes in this conversation.';
    await composer.fill(draft);
    await expect(hints).toContainText(count,{timeout:15000});
    await page.waitForTimeout(Math.max(0,11000-(Date.now()-readyAt)));
    await captureHint('waiting',count,true);
    footer.answer=await fleetFooterWorker.answer();
    await save();
    try {
     await expect(hints).not.toContainText(count,{timeout:20000});
    } catch(error) {
     footer.staleDesktop=await hints.innerText();
     await section.getByRole('button',{name:'Use native interface',exact:true}).click({timeout:5000});
     const terminal=section.locator('[data-terminal-text]').first();
     footer.reopenedTerminal={first:await terminal.innerText({timeout:5000})};
     await expect.poll(async()=>await terminal.innerText({timeout:1000}),{timeout:12500}).not.toMatch(count).catch(()=>{});
     footer.reopenedTerminal.last=await terminal.innerText({timeout:5000});
     await page.screenshot({path:join(output,'fleet-waiting-native-diagnostic.png')});
     await section.getByRole('button',{name:'Back to conversation',exact:true}).click({timeout:5000});
     await expect(hints).toContainText('shift+tab to cycle',{timeout:5000});
     footer.reopenedDesktop=await hints.innerText();
     await save();
     throw error;
    }
    await captureHint('answered',count,false);
   }else{
    proof.scope='Same native main composer before and after the original resting Agent hint expires.';
    await captureHint('early',arrow,true);
    await expect(hints).not.toContainText(arrow,{timeout:16000});
    footer.observedExpiryMs=Date.now()-readyAt;
    await captureHint('expired',arrow,false);
   }
   const final=await context();
   assert.equal(final.claude.sessionId,parentSessionId);
   assert.equal(final.native.state.nativePid,proof.pid);
   assert.equal(final.native.state.ownerId,initial.native.state.ownerId);
   await expect(composer).toHaveText(draft);
   await section.getByRole('button',{name:'Use native interface',exact:true}).click({timeout:5000});
   await section.getByRole('button',{name:'Stop session',exact:true}).click({timeout:5000});
   await expect.poll(()=>processStart(proof.pid),{timeout:15000}).not.toBe(proof.processStart);
   proof.nativeWriterRetired=true;
   proof.status='complete';
   await save();
   return;
  }
  if (measurePromptCompletionLayout) {
   await verifyPromptCompletionLayout({page,electronApp,section,card,composer,send,expect,context,output,proof,save,phase,sendMain,processStart,measureAgentFooter,verifyCompletionWindowFocus,promptEditHold});
   return;
  }
  if (verifyReadClear) {
   await verifyHeldReadClear({page,section,card,composer,send,expect,context,currentUi,output,project,proof,save,phase,sendMain,processStart});
   return;
  }
  if (verifyPromptControlReplacement) {
   await verifyPromptControlsReplacement({page,section,card,composer,send,expect,context,currentUi,
    output,project,proof,save,phase,sendMain,processStart,hold:promptEditHold,retiredBeforeExpiry:promptRetiredBeforeExpiry});
   return;
  }
  if (promptEditHold) {
   await verifyPromptEditOwnerReplacement({page, section, composer, send, expect, context, currentUi,
    output, proof, save, phase, sendMain, promptEditHold});
   return;
  }
  await sendMain('Review the release notes with a worker.');await expect.poll(async()=>(await context()).native.state.tasks.some(task=>task.status==='running'),{timeout:15000}).toBe(true);
  const tools=page.getByRole('button',{name:/^Native tools/}).first();await expect(tools).toBeVisible({timeout:10000});if(await tools.getAttribute('aria-expanded')!=='true')await tools.click({timeout:10000});const row=page.locator('[data-native-agent-id]').first();proof.agentGroupReopens=[];await expect.poll(async()=>{if(await row.isVisible())return true;if(!verifyStableToolDisclosure&&proof.agentGroupReopens.length<3&&await tools.isVisible()&&await tools.getAttribute('aria-expanded')!=='true'){proof.agentGroupReopens.push({at:Date.now(),nativePid:(await context()).native.state.nativePid});await tools.click({timeout:1000});await save()}return row.isVisible()},{timeout:15000}).toBe(true);proof.taskId=await row.getAttribute('data-native-agent-id',{timeout:1000});assert.ok(proof.taskId);if(verifyStableToolDisclosure){assert.equal(proof.agentGroupReopens.length,0);proof.toolDisclosure={required:true,initialOpen:true,initialTaskId:proof.taskId,returnedOpen:false};await save();}
  await expect(row.getByTestId('native-agent-status-text')).toContainText('Reviewing release notes',{timeout:15000});proof.statusInvocations=await profile.invocations();assert.ok(proof.statusInvocations.some(item=>item.kind==='main'&&item.input.session_id===parentSessionId));assert.ok(proof.statusInvocations.some(item=>item.kind==='agent'&&item.input.tasks.some(task=>task.id===proof.taskId)));
  const parentDraft='Keep the release checklist wording unchanged.',agentDraft='Please also note the migration steps.';proof.parentDraft=parentDraft;proof.agentDraft=agentDraft;await composer.fill(parentDraft);await row.getByRole('button',{name:'Open Agent',exact:true}).click();
  const focused=page.getByRole('region',{name:'Focused Agent conversation',exact:true}),agentForm=focused.getByRole('form',{name:'Agent message',exact:true}),agentEditor=agentForm.locator('[contenteditable="true"]'),agentStatus=focused.getByRole('status',{name:'Claude session status',exact:true});if(agentReadingProbe)verifyAgentReading=async(name,size)=>{
   const transcript=focused.getByRole('region',{name:'Agent transcript',exact:true}),latest=focused.getByRole('button',{name:'Jump to latest Agent message',exact:true});
   if(await latest.isVisible())await latest.click();
   const measure=()=>transcript.evaluate(el=>{const style=getComputedStyle(el.querySelector('article p')??el),lineHeight=parseFloat(style.lineHeight)||parseFloat(style.fontSize)*1.5;return{top:el.scrollTop,max:el.scrollHeight-el.clientHeight,height:el.clientHeight,lineHeight};});
   await expect.poll(async()=>{const p=await measure();return p.max>40&&Math.abs(p.max-p.top)<=1;}).toBe(true);
   const bounds=await transcript.boundingBox();assert.ok(bounds&&bounds.height>40);await page.mouse.move(bounds.x+bounds.width/2,bounds.y+bounds.height/2);await page.mouse.wheel(0,-12);
   await expect.poll(async()=>{const p=await measure();return p.max-p.top>1&&p.max-p.top<=24;}).toBe(true);
   const before=await measure();
   const reading={name,before,draft:await agentEditor.textContent(),sessionId:(await context()).claude.sessionId};
   if(keepLongAgentStatus){
    await expect(agentStatus).toContainText('Migration checklist');
    const sendToAgent=agentForm.getByRole('button',{name:'Send to Agent',exact:true});
    await expect(sendToAgent).toBeInViewport({ratio:1});
    await expect(sendToAgent).toBeEnabled();
    const target=await sendToAgent.evaluate(el=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2));});
    assert.ok(target,'Send to Agent must stay clickable under the long status');
    const caption=await agentStatus.evaluate(el=>{
     const range=el.ownerDocument.createRange();range.selectNodeContents(el);
     const rowTops=new Set([...range.getClientRects()].filter(r=>r.width>0&&r.height>0).map(r=>Math.round(r.top)));
     return {text:el.textContent,rows:rowTops.size,clientHeight:el.clientHeight,scrollHeight:el.scrollHeight};
    });
    assert.ok(caption.scrollHeight<=caption.clientHeight+1,'The long status should be readable in full');
    if(name==='compact')assert.ok(caption.rows>=2,'The long caption must wrap in compact view');
    reading.longStatus={...caption,sendReachable:target};
   }
   (proof.agentReading??=[]).push(reading);await save();
   assert.ok(before.height>=104,`Agent history must show at least four text lines beside the draft (${before.height}px at ${size.width}×${size.height})`);await expect(latest).toBeVisible();await page.setViewportSize({...size,height:size.height-2});await page.setViewportSize(size);
   await transcript.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))));
   const after=await measure();assert.ok(Math.abs(after.top-before.top)<=1,'A short Agent history read must survive reflow');await expect(latest).toBeVisible();await expect(agentEditor).toHaveText(agentDraft);
   reading.after=after;await save();
  };
  if(agentFormattingProbe)verifyAgentFormatting=async(name,size)=>{
   const selectionKeys={name,steps:[]};(proof.agentSelectionKeys??=[]).push(selectionKeys);
   const measure=key=>agentEditor.evaluate((el,key)=>{
    const s=getSelection(),view=el.editor?.view;
    const model=view?.state.selection;
    const position=(node,offset)=>node&&el.contains(node)&&view?view.state.doc.resolve(view.posAtDOM(node,offset)):null;
    const anchor=position(s?.anchorNode,s?.anchorOffset),head=position(s?.focusNode,s?.focusOffset);
    const browser=anchor&&head&&model?.constructor.between(anchor,head);
    return{key,selected:s?.toString(),anchor:browser?.anchor,head:browser?.head,focused:document.activeElement===el,model:model?.toJSON()};
   },key);
   const press=async(key,anchor,head=anchor)=>{
    await page.keyboard.press(key);
    try{
     await expect.poll(()=>measure(key)).toMatchObject({focused:true,anchor,head,model:{anchor,head}});
    }finally{selectionKeys.steps.push(await measure(key));await save();}
   };
   await electronApp.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0]?.focus());await agentEditor.focus();
   if(agentRapidSelectionProbe){
    // Send a continuous sequence to the focused window without waiting for renderer events between keys.
    await agentEditor.evaluate(el=>{
     const events=[],doc=el.ownerDocument,editor=el.editor;
     const record=(type,event,transaction)=>{
      if(events.length>=300)return;
      const selection=doc.getSelection(),state=editor.state.selection;
      events.push({type,key:event?.key,shift:event?.shiftKey,selection:selection?.toString(),anchor:selection?.anchorOffset,head:selection?.focusOffset,model:state.toJSON(),transaction:transaction&&{by:transaction.getMeta('claude-prompt-by'),selectionSet:transaction.selectionSet,docChanged:transaction.docChanged,meta:Object.keys(transaction.meta),stack:new Error().stack?.split('\n').slice(2,14)},focused:doc.activeElement===el});
     };
     const key=e=>record(e.type,e), change=()=>record('selectionchange'), transaction=({transaction})=>record('transaction',undefined,transaction);
     el.addEventListener('keydown',key,true);el.addEventListener('keyup',key,true);doc.addEventListener('selectionchange',change,true);editor.on('transaction',transaction);
     el.finishRapidSelectionProbe=()=>{
      el.removeEventListener('keydown',key,true);el.removeEventListener('keyup',key,true);doc.removeEventListener('selectionchange',change,true);editor.off('transaction',transaction);
      delete el.finishRapidSelectionProbe;
      return events;
     };
    });
    const rapid={name,before:await measure('initial')};
    (proof.agentRapidSelection??=[]).push(rapid);
    try{
     await page.keyboard.press('Home');
     for(let i=0;i<5;i++)await page.keyboard.press('ArrowRight');
     await page.keyboard.down('Shift');
     try{for(let i=0;i<12;i++)await page.keyboard.press('ArrowRight');}finally{await page.keyboard.up('Shift');}
     await expect.poll(()=>measure('settled')).toMatchObject({focused:true,anchor:6,head:18,model:{anchor:6,head:18},selected:agentDraft.slice(5,17)});
    }finally{
     rapid.final=await measure('final');
     rapid.events=await agentEditor.evaluate(el=>el.finishRapidSelectionProbe());
     await save();
    }
   }
   await press('Home',1);
   for(let i=1;i<=5;i++)await press('ArrowRight',i+1);
   await page.keyboard.down('Shift');try{for(let i=1;i<=12;i++)await press('ArrowRight',6,6+i);}finally{await page.keyboard.up('Shift');}
   const selected=agentDraft.slice(5,17);await expect.poll(()=>page.evaluate(()=>getSelection()?.toString())).toBe(selected);
   const toolbar=page.locator('.bubble-menu:visible');await expect(toolbar).toHaveCount(1);
   await expect.poll(()=>toolbar.evaluate(el=>{const r=el.getBoundingClientRect(),selection=getSelection();if(!selection?.rangeCount)return false;const t=selection.getRangeAt(0).getBoundingClientRect();return r.right<=t.x||r.x>=t.right||r.bottom<=t.y||r.y>=t.bottom;}),{timeout:5000}).toBe(true);
   const menu=await toolbar.evaluate(el=>{const r=el.getBoundingClientRect(),selection=getSelection(),t=selection?.rangeCount?selection.getRangeAt(0).getBoundingClientRect():null;return {selection:t?{x:t.x,y:t.y,right:t.right,bottom:t.bottom}:null,x:r.x,y:r.y,right:r.right,bottom:r.bottom,controls:[...el.querySelectorAll('button')].filter(b=>b.getBoundingClientRect().width).map(b=>{const r=b.getBoundingClientRect();return {label:b.title||b.textContent,reachable:b.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))};})};});
   assert.equal(menu.controls.length,6);assert.ok(menu.controls.every(c=>c.reachable));
   const readText=element=>{const characters=[],walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT);let node;while(node=walker.nextNode())for(let i=0;i<node.textContent.length;i++){if(!node.textContent[i].trim())continue;const range=document.createRange();range.setStart(node,i);range.setEnd(node,i+1);for(const r of range.getClientRects())if(r.width&&r.height)characters.push({x:r.x,y:r.y,right:r.right,bottom:r.bottom,reachable:element.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))});}return{text:element.textContent,characters};};
   const status=await agentStatus.evaluate(readText),hint=await agentForm.getByText('Enter to send · Shift+Enter for a new line',{exact:true}).evaluate(readText);
   for(const text of [status,hint]){assert.ok(text.characters.length);assert.ok(text.characters.every(c=>c.reachable&&(menu.right<=c.x||menu.x>=c.right||menu.bottom<=c.y||menu.y>=c.bottom)));}
   const historyHeight=await focused.getByRole('region',{name:'Agent transcript',exact:true}).evaluate(el=>el.clientHeight);assert.ok(historyHeight>=104);await expect(agentEditor).toHaveText(agentDraft);
   const actualSelected=await page.evaluate(()=>getSelection()?.toString());assert.equal(actualSelected,selected);
   (proof.agentFormatting??=[]).push({name,viewport:size,menu,status,hint,historyHeight,selected:actualSelected,draft:await agentEditor.textContent(),sessionId:(await context()).claude.sessionId,taskId:proof.taskId});await save();
  };
  await agentEditor.fill(agentDraft);await expect(agentStatus).toContainText('Reviewing release notes');await capture('agent',[agentStatus,agentEditor,agentForm.getByRole('button',{name:'Send to Agent',exact:true}),focused.getByRole('button',{name:'Back to conversation',exact:true})]);
  if(agentStatusTransitions){
   const before=await context(),foregroundRequests=()=>model.calls.filter(call=>call.route!=='agent-action-summary').length,requestCount=foregroundRequests(),results=[];
   assert.equal(model.agentCalls.filter(call=>call.child&&!call.grandchild).length,1);
   const snapshotAgentEditor=()=>agentEditor.evaluate(element=>({
    document:element.editor.state.doc.toJSON(),selection:element.editor.state.selection.toJSON(),
   }));
   let statusSelection;
   if(verifyAgentStatusFocus){
    await expect.poll(()=>page.evaluate(()=>document.hasFocus())).toBe(true);
    await agentEditor.evaluate(element=>element.editor.commands.setTextSelection({from:3,to:8}));
    statusSelection=await snapshotAgentEditor();
    assert.notEqual(statusSelection.selection.anchor,statusSelection.selection.head);
    proof.agentStatusFocus={document:statusSelection,withdrawals:[],decorations:[]};
   }
   for(const mode of ['empty','restore','failure',verifyAgentStatusFocus?'decorated':'recovered']){
    const cleared=mode==='empty'||mode==='failure';
    if(verifyAgentStatusFocus&&cleared){
     const compact=mode==='failure';
     await page.setViewportSize(compact?{width:680,height:600}:{width:1100,height:900});
     await expect(agentStatus).toBeInViewport({ratio:1});
     await agentStatus.focus();
     await expect(agentStatus).toBeFocused();
    }
    await profile.setAgentStatusMode(mode);
    let receipt;
    await expect.poll(async()=>{
     receipt=(await profile.invocations()).find(row=>row.kind==='agent'&&row.mode===mode&&row.input.session_id===proof.parentSessionId
      &&row.input.tasks.some(task=>task.id===proof.taskId&&task.status==='running'));
     return !!receipt;
    },{timeout:12000}).toBe(true);
    assert.ok(receipt.ancestry.some(ancestor=>ancestor.pid===proof.pid&&ancestor.start===proof.processStart));
    if(cleared)await expect(agentStatus).toHaveCount(0,{timeout:9000});
    else await expect(agentStatus).toContainText(mode==='restore'?'Reviewing release notes':'Reviewing release notes · refreshed',{timeout:9000});
    if(verifyAgentStatusFocus){
     await expect(agentEditor).toBeFocused();
     assert.deepEqual(await snapshotAgentEditor(),statusSelection);
     if(cleared)proof.agentStatusFocus.withdrawals.push({mode,viewport:page.viewportSize(),selection:statusSelection.selection});
     if(mode==='decorated'){
      const expected=[
       {text:'Migration checklist',lines:'underline line-through'},
       {text:' deferred',lines:'line-through'},
      ];
      for(const viewport of [{width:1100,height:900},{width:680,height:600}]){
       await page.setViewportSize(viewport);
       await expect(agentStatus).toBeInViewport({ratio:1});
       const painted=await agentStatus.locator('span > span').evaluateAll(nodes=>nodes.map(node=>({
        text:node.textContent,lines:getComputedStyle(node).textDecorationLine,
       })).filter(node=>/^(Migration checklist| deferred)$/.test(node.text)));
       assert.deepEqual(painted,expected);
       proof.agentStatusFocus.decorations.push({viewport,painted});
      }
     }
    }
    assert.equal(receipt.exitCode,mode==='failure'?7:0);
    if(mode==='empty')assert.equal(receipt.stdout,'');
    if(mode==='failure')assert.match(receipt.stdout,/Rejected Agent decoration/);
    await expect(agentEditor).toHaveText(agentDraft);
    const current=await context();
    assert.equal(current.claude.sessionId,proof.parentSessionId);assert.equal(current.native.state.nativePid,proof.pid);
    assert.equal(current.native.state.view.taskId,proof.taskId);
    assert.deepEqual(current.native.state.mainStatus,before.native.state.mainStatus);
    assert.equal(current.claude.totalCostUsd,before.claude.totalCostUsd);
    assert.equal(foregroundRequests(),requestCount);
    results.push({mode,receipt,caption:cleared?null:await agentStatus.innerText()});proof.agentStatusTransitions=results;
    if(mode!=='restore')await capture('agent-status-'+mode,[agentEditor,agentForm.getByRole('button',{name:'Send to Agent',exact:true}),...(cleared?[]:[agentStatus])]);
    await save();phase('agent-status-'+mode);
   }
   if(verifyAgentStatusFocus&&!keepLongAgentStatus){
    await profile.setAgentStatusMode('recovered');
    await expect(agentStatus).not.toContainText('Migration checklist',{timeout:12000});
    await expect(agentStatus).toContainText('Reviewing release notes · refreshed');
    await expect(agentEditor).toBeFocused();
    assert.deepEqual(await snapshotAgentEditor(),statusSelection);
    proof.agentStatusFocus.ordinaryCaptionRestored=true;
    await save();
   }
   model.releaseWorker();
  }
  await focused.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toHaveText(parentDraft);proof.parentAfterReturn=await context();await save();phase('agent-parent-returned');await expect.poll(async()=>(await context()).native.state.tasks.find(task=>task.id===proof.taskId)?.status,{timeout:20000}).toBe('completed');proof.agentCompleted=await context();await save();phase('agent-task-completed');
  if(verifyStableToolDisclosure){await expect(row).toBeVisible({timeout:15000});assert.equal(await row.getAttribute('data-native-agent-id'),proof.taskId);proof.toolDisclosure.returnedOpen=true;await save();}else if(!await row.isVisible())await page.getByRole('button',{name:/^Native tools/}).first().click({timeout:15000});const reopen=row.getByRole('button',{name:'Open Agent',exact:true});proof.reopenControl={count:await reopen.count(),visible:await reopen.isVisible()};await save();phase('agent-reopen-requested',proof.reopenControl);await reopen.click({timeout:15000});await expect(agentEditor).toHaveText(agentDraft);await expect(focused.getByRole('region',{name:'Agent transcript',exact:true})).toContainText('The release notes cover behavior changes and migration guidance.');await expect(agentStatus).toContainText('Reviewing release notes',{timeout:15000});await capture('agent-result',[agentStatus,agentEditor,focused.getByRole('button',{name:'Back to conversation',exact:true})]);await focused.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toHaveText(parentDraft);
  await expect.poll(async()=>(await context()).native.state.busy,{timeout:15000}).toBe(false);await expect(send).toBeEnabled();const keyboardHint=card.locator('[aria-label="Native keyboard hint"]');await expect(keyboardHint).toBeVisible();await capture('composer',[composer,send,status,keyboardHint]);
  if(verifyMemoryRoundTrip) {
   const prior=await context(),draft=await composer.innerText(),modelCount=model.agentCalls.length;
   assert.ok(draft.trim(),'The release-review draft must exist before opening memory');
   const panel=page.getByRole('dialog',{name:'Claude memory',exact:true});
   const memory=proof.memoryPanel={draft,samples:[],captures:[]};
   const memoryButton=page.getByRole('button',{name:'Claude memory',exact:true});
   for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]) {
    await page.setViewportSize({width,height});
    if(await memoryButton.isVisible())await memoryButton.click();
    else{
     await card.getByRole('button',{name:'More actions',exact:true}).click();
     await page.getByRole('menuitem',{name:'Claude memory',exact:true}).click();
    }
    await expect(panel.getByText('Instruction files',{exact:true})).toBeVisible();
    await expect(panel.getByRole('button',{name:'Done',exact:true})).toBeInViewport({ratio:1});
    await expect(panel.getByRole('status')).toHaveText('on');
    const current=await context();
    assert.equal(current.native.state.nativePid,proof.pid);
    assert.equal(current.claude.sessionId,proof.parentSessionId);
    assert.equal(current.claude.totalCostUsd,prior.claude.totalCostUsd);
    const screenshot='combined-everyday-memory-'+size+'.png';
    await page.screenshot({path:join(output,screenshot),animations:'disabled'});
    memory.captures.push(screenshot);
    await panel.getByRole('button',{name:'Done',exact:true}).click();
    await expect(composer).toBeFocused();
    await expect(composer).toHaveText(draft);
    memory.samples.push({size,sessionId:current.claude.sessionId,nativePid:current.native.state.nativePid,cost:current.claude.totalCostUsd,draft:await composer.innerText()});
    assert.equal(model.agentCalls.length,modelCount);
    await save();
   }
  }

  const windows=verifyWindowControls?await createEverydayWindowControls({
   page,electronApp,expect,context,proof,output,userDataDir,
   readParentJournal:()=>readCombinedEverydayJournal(userDataDir,parentSessionId,undefined,profile.configDir),
   verifyStaleResponses:verifyStaleWindowResponses, verifyQuestionAttachment,
  }):undefined;
  await sendMain('Read the release checklist before proposing changes.');await expect.poll(()=>model.decision?.tool,{timeout:15000}).toBe('Read');await typeNextMainDraft('Keep my review draft while I approve this read.');model.releaseDecision('Read');
  const approval=page.getByTestId('native-read-approval');await expect(approval).toBeVisible();await expect(approval.getByTestId('native-read-path')).toHaveText(model.referenceFile);await expect(composer).toBeHidden();await capture('approval',[approval.getByTestId('native-read-path'),approval.getByRole('button',{name:'Deny',exact:true}),approval.getByRole('button',{name:'Approve',exact:true})]);await windows?.approvalReady();await approval.getByRole('button',{name:'Approve',exact:true}).click();await expect(approval).toBeHidden();await expect.poll(()=>model.agentCalls.some(call=>call.referenceReadResult!==undefined&&!call.referenceReadError&&JSON.stringify(call.referenceReadResult).includes('Keep migration guidance')),{timeout:15000}).toBe(true);await expect(composer).toHaveText('Keep my review draft while I approve this read.');await windows?.afterApproval();
  if(verifyQuestionAttachment) assert.ok(windows,'The combined question attachment requires the popout journey');
  await sendMain('Ask me which release audience to target.');await expect.poll(()=>model.decision?.tool,{timeout:15000}).toBe('AskUserQuestion');await typeNextMainDraft('Use a direct, concise tone in the summary.');model.releaseDecision('AskUserQuestion');
  const question=page.getByTestId('native-question-panel');await expect(question).toBeVisible();await expect(question).toContainText('Who should the release summary address?');await expect(composer).toBeHidden();await capture('question',[question.getByRole('button',{name:'Submit answers',exact:true})]);if(windows)await windows.questionReady();else{ await question.getByRole('radio',{name:'Developers People integrating the updated behavior',exact:true}).check();await question.getByRole('button',{name:'Submit answers',exact:true}).click(); }await expect(question).toBeHidden();await expect.poll(()=>model.agentCalls.some(call=>call.nativeQuestionResult!==undefined&&!call.nativeQuestionError&&JSON.stringify(call.nativeQuestionResult).includes('Developers')),{timeout:15000}).toBe(true);await expect(composer).toHaveText('Use a direct, concise tone in the summary.');await windows?.afterQuestion();
  if(verifyQuestionAttachment) {
   const rows = model.agentCalls.flatMap(call => (call.messages ?? []).map(message=>message.content).filter(Array.isArray));
   const blocks = rows.find(content=>content.some(block=>block.type==='tool_result'&&block.tool_use_id==='native_question_fixture'));
   assert.ok(blocks);
   const index = blocks.findIndex(block=>block.type==='tool_result'&&block.tool_use_id==='native_question_fixture');
   const image = blocks[index+1];
   assert.equal(image?.type,'image');
   assert.equal(image.source.media_type,'image/png');
   const digest=sha(Buffer.from(image.source.data,'base64'));
   assert.equal(digest,proof.windowControls.question.attachment.sha256);
   proof.windowControls.question.attachment.providerSha256=digest;
  }
  await sendMain('Draft the release summary while I review the checklist.');await expect.poll(()=>model.agentCalls.some(call=>call.pauseWaiting),{timeout:15000}).toBe(true);await typeNextMainDraft('Keep this note after interruption.');await expect.poll(async()=>(await context()).native.state.activeTurnId,{timeout:10000}).toBeTruthy();proof.pauseAddressedTurnId=(await context()).native.state.activeTurnId;await card.getByTitle('Pause agent work',{exact:true}).click();await expect.poll(async()=>(await context()).native.state.busy,{timeout:15000}).toBe(false);proof.paused=await context();assert.equal(proof.paused.native.state.nativePid,proof.pid);assert.deepEqual(proof.paused.native.state.lastTurn,{id:proof.pauseAddressedTurnId,reason:'aborted'});assert.equal(proof.paused.native.state.status,'live');await expect(composer).toHaveText('Keep this note after interruption.');await expect.poll(()=>model.agentCalls.some(call=>call.pauseCancelled),{timeout:10000}).toBe(true);
  const taskBeforeStop=(await context()).native?.task;
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processStart(proof.pid),{timeout:15000}).not.toBe(proof.processStart);proof.nativeWriterRetired=true;const back=section.getByRole('button',{name:'Back to conversation',exact:true});if(await back.isVisible())await back.click();await expect(composer).toBeVisible();await expect(composer).toBeEditable();await expect(composer).toHaveText('Keep this note after interruption.');
  if(agentFormattingProbe){
   await expect.poll(async()=>(await context()).native?.stop?.status,{timeout:5000}).toBe('done');
   const returned=await context();assert.equal(returned.native.stop.ownerId,proof.paused.native.state.ownerId);assert.ok(returned.native.task?.operation!=='background'||returned.native.task.revision<=(taskBeforeStop?.revision??0));
   proof.stopReturn={stop:returned.native.stop,taskBefore:taskBeforeStop,taskAfter:returned.native.task,composerVisible:true,composerEditable:true,draft:await composer.textContent(),sessionId:returned.claude.sessionId,nativeOwnerId:proof.paused.native.state.ownerId};await save();
  }
  const stoppedJournal=await readCombinedEverydayJournal(userDataDir,parentSessionId,undefined,profile.configDir);await writeFile(join(output,'native-before-resume-transcript.jsonl'),stoppedJournal);proof.nativeCost=JSON.parse(stoppedJournal.toString().trim().split('\n').filter(Boolean).filter(line=>JSON.parse(line).type==='cost-state').at(-1)).totalCostUSD;await expect.poll(async()=>(await context()).claude.totalCostUsd).toBe(proof.nativeCost);
  await sendMain('Continue the same release review after the interruption.');await expect.poll(async()=>(await context()).claude.chatState,{timeout:15000}).toBe('success');assert.equal((await context()).claude.sessionId,parentSessionId);await typeNextMainDraft('Ready for the next release-review step.');await expect(send).toBeEnabled();await capture('recovered',[composer,send]);proof.final=await context();assert.ok(proof.final.claude.totalCostUsd>proof.nativeCost);
  if(verifySessionReset){
   await section.getByRole('button',{name:'Use native interface',exact:true}).click();
   await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
   const reopened=await context(),pid=reopened.native.state.nativePid,start=await processStart(pid);
   assert.ok(start);
   assert.equal(reopened.native.state.sessionId,parentSessionId);
   await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
   await expect.poll(async()=>(await currentUi())?.state.status,{timeout:15000}).toBe('live');
   await expect(composer).toHaveText('Ready for the next release-review step.');
   const modelRequests=()=>model.calls.filter(call=>call.path.split('?')[0]==='/v1/messages');
   const requestsBeforeClear=modelRequests().length;
   proof.reset={pid,start,requestsBeforeClear,captures:[]};
   await save();
   await sendMain('/clear');
   await expect.poll(async()=>{
    const current=await context(),sessionId=current.claude?.sessionId;
    return Boolean(sessionId&&sessionId!==parentSessionId&&sessionId===current.native?.state?.sessionId&&(await currentUi())?.state.status==='live');
   },{timeout:20000}).toBe(true);
   const cleared=await context(),sessionId=cleared.claude.sessionId;
   assert.equal(cleared.threadId,proof.final.threadId);
   assert.equal(cleared.native.state.nativePid,pid);
   assert.equal(await processStart(pid),start);
   assert.ok(cleared.claude.previousSessionIds.includes(parentSessionId));
   const requestsAfterClear=modelRequests().length;
   assert.equal(requestsAfterClear,requestsBeforeClear);
   Object.assign(proof.reset,{sessionId,cleared,requestsAfterClear});
   await save();
   phase('combined-everyday-session-cleared');

   const prompt='Review only the new release checklist.';
   const sizes=[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]];
   const thumbnail=card.locator('img[src^="data:image/png"]');
   let submittedText=prompt, imagePromptPrefix;
   if(verifyResetImage){
    const image=createNativeTestImage([50,145,231,255]);
    await electronApp.evaluate(async({clipboard,nativeImage,ClipboardItem},bytes)=>{
     const data=nativeImage.createFromBuffer(Buffer.from(bytes));
     if(data.isEmpty())throw Error('Owned PNG did not decode');
     await clipboard.write([new ClipboardItem({'image/png':new Blob([Uint8Array.from(data.toPNG())],{type:'image/png'})})]);
    },[...image]);
    try{
     await composer.fill(prompt);
     await composer.press('Control+v');
     await expect(thumbnail).toHaveCount(1);
     const dataUrl=await thumbnail.getAttribute('src'),name=await thumbnail.getAttribute('alt');
     assert.ok(dataUrl?.startsWith('data:image/png;base64,')&&name);
     imagePromptPrefix=`${prompt}\n\n[Image: ${name}][Image #`;
     proof.reset.image={dataUrl,name,captures:[]};
     assert.equal(modelRequests().length,requestsAfterClear);
     for(const [size,viewport] of sizes){
      await page.setViewportSize(viewport);
      await expect(composer).toHaveText(prompt);
      for(const control of [composer,thumbnail,send,status])await expect(control).toBeInViewport({ratio:1});
      const file='combined-everyday-reset-image-draft-'+size+'.png';
      await page.screenshot({path:join(output,file)});
      proof.reset.image.captures.push(file);
     }
     await send.click();
    }finally{
     await electronApp.evaluate(({clipboard})=>clipboard.clear());
    }
   }else await sendMain(prompt);
   await expect.poll(async()=>{
    const current=await context();
    if(current.claude.sessionId!==sessionId||current.claude.turns<1||current.native.state.busy!==false)return false;
    const inputIndex=current.messages.findIndex(message=>{
     if(message.sender!=='user'||!message.context?.cliUuid||typeof message.text!=='string')return false;
     if(!imagePromptPrefix)return message.text===prompt;
     return message.text.startsWith(imagePromptPrefix)&&/^[1-9][0-9]*\]$/.test(message.text.slice(imagePromptPrefix.length));
    });
    if(inputIndex<0)return false;
    const reply=current.messages.slice(inputIndex+1).find(message=>message.sender==='assistant'&&message.text&&message.context?.cliUuid);
    if(!reply)return false;
    const journal=(await readCombinedEverydayJournal(userDataDir,sessionId,undefined,profile.configDir)).toString();
    const rows=journal.slice(0,journal.lastIndexOf('\n')+1).split('\n').filter(Boolean).map(JSON.parse);
    const replyIndex=rows.findIndex(row=>row.type==='assistant'&&row.uuid===reply.context.cliUuid);
    const cost=replyIndex<0?undefined:rows.slice(replyIndex+1).filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;
    if(!(cost>0&&cost===current.claude.totalCostUsd))return false;
    if(imagePromptPrefix){
     const input=current.messages[inputIndex];
     const nativeInput=rows.find(row=>row.type==='user'&&row.uuid===input.context.cliUuid);
     if(!Array.isArray(nativeInput?.message?.content)||nativeInput.message.content[0]?.text!==input.text)return false;
     submittedText=input.text;
     Object.assign(proof.reset.image,{submittedText,nativeImageNumber:Number(submittedText.slice(imagePromptPrefix.length,-1))});
    }
    return true;
   },{timeout:20000}).toBe(true);
   const followup=await context(),newRequests=modelRequests().slice(requestsBeforeClear);
   assert.ok(newRequests.some(call=>JSON.stringify(call.messages).includes(prompt)));
   const oldPrompts=proof.final.messages.filter(message=>message.sender==='user'&&message.context?.cliUuid).map(message=>message.text);
   assert.ok(oldPrompts.length>0);
   assert.ok(newRequests.every(call=>oldPrompts.every(text=>!JSON.stringify(call.messages).includes(text))));
   await expect(status).toContainText('Release review',{timeout:15000});
   await expect.poll(async()=>(await profile.invocations()).some(row=>row.kind==='main'&&row.input.session_id===sessionId&&
    row.ancestry.some(parent=>parent.pid===pid&&parent.start===start)),{timeout:15000}).toBe(true);
   Object.assign(proof.reset,{prompt,followup});
   const draft='Ready to review the new release checklist.';
   await expect(thumbnail).toHaveCount(0);
   await composer.fill(draft);
   if(verifyResetImage){
    const submitted=followup.messages.find(message=>message.sender==='user'&&message.text===submittedText);
    assert.equal(submitted?.references?.images?.length,1);
    assert.equal(submitted.references.images[0].name,proof.reset.image.name);
    const row=page.locator('[data-chat-message="'+submitted.id+'"]');
    const preview=row.getByRole('img',{name:proof.reset.image.name,exact:true});
    const body=row.locator('[data-chat-message-content]');
    for(const [size,viewport] of sizes){
     await page.setViewportSize(viewport);
     await expect(composer).toHaveText(draft);
     await expect(body).toHaveText(prompt);
     await expect(send).toBeInViewport({ratio:1});
     const geometry=await readNativeTranscriptRow(page,expect,body,{checkTextHit:true,companion:preview});
     (proof.reset.image.presentation??=[]).push({size,picture:geometry.adjacent,view:geometry.viewport});
     const file='combined-everyday-reset-image-sent-'+size+'.png';
     await page.screenshot({path:join(output,file)});
     proof.reset.image.captures.push(file);
    }
    await save();
   }


   for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
    await page.setViewportSize(viewport);
    await expect(composer).toHaveText(draft);
    for(const control of [composer,send,status])await expect(control).toBeInViewport({ratio:1});
    if(measureResetFooter){
     const viewport=page.getByTestId('chat-transcript').locator(':scope > div').first();
     const footer=viewport.locator('[data-native-placement="TurnDuration"]:visible').last();
     await expect(footer).toContainText(/done/i);
     const layout=()=>viewport.evaluate(element=>{
      const r=node=>{const box=node.getBoundingClientRect();return {top:box.top,bottom:box.bottom,height:box.height}};
      const rows=[...element.querySelectorAll('[data-message-id]')].filter(node=>node.getBoundingClientRect().height);
      const latest=rows.at(-1);
      const duration=[...element.querySelectorAll('[data-native-placement="TurnDuration"]')].filter(node=>node.getBoundingClientRect().height).at(-1);
      const box=r(element), row=r(latest), body=r(latest.querySelector('[data-chat-message-content]')??latest), footer=r(duration);
      return {viewport:box,row,body,footer,scrollTop:element.scrollTop,maxScroll:element.scrollHeight-element.clientHeight,
       footerText:duration.textContent,latest:latest.textContent.slice(0,240)};
     });
     await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
     (proof.reset.footerGeometry??=[]).push({size,...await layout()});
    }
    const file='combined-everyday-reset-'+size+'.png';
    await page.screenshot({path:join(output,file)});
    proof.reset.captures.push(file);
   }
   await section.getByRole('button',{name:'Use native interface',exact:true}).click();
   await section.getByRole('button',{name:'Stop session',exact:true}).click();
   await expect.poll(()=>processStart(pid),{timeout:15000}).not.toBe(start);
   proof.reset.writerRetired=true;
   await save();
  }
  proof.status='complete';await save();phase('combined-everyday-complete');
 }catch(error){proof.error={name:error.name,message:error.message.slice(0,2000)};proof.observed=await context().catch(()=>null);await page.screenshot({path:join(output,'combined-everyday-failure.png')}).catch(()=>{});throw error}finally{await pausedWriter?.resume();await save()}
}

/** Bound a real unresponsive-owner fault to this fixture's own native descendant. */
async function pauseOwnedWriter(pid,start,output,freshProfile){
 assert.equal(process.platform,'linux');
 if(freshProfile){
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(boundary.networkDisabled&&boundary.pinnedExecutableReadOnly&&boundary.requireAttachmentRecovery);
  assert.match(output,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+\/electron-results$/);
 }else assert.match(output,/^\/work\/\.claude-research\/combined-everyday-app[0-9]+\/electron-results$/);
 assert.ok(Number.isSafeInteger(pid)&&pid>1&&pid!==process.pid);assert.equal(await processStart(pid),start);
 assert.equal((await lstat('/proc/'+pid)).uid,process.getuid());
 let ancestor=pid,owned=false;for(let i=0;i<24&&ancestor>1;i++){const raw=await readFile('/proc/'+ancestor+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');ancestor=Number(fields[1]);if(ancestor===process.pid){owned=true;break}}assert.ok(owned,'Only the current fixture native descendant may be paused');
 const receipt=join(output,'native-pause-watchdog.json');
 const source=`const fs=require('node:fs');const [pid,start,file]=process.argv.slice(1),began=Date.now();function current(){try{const raw=fs.readFileSync('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[19]===start&&fs.statSync('/proc/'+pid).uid===process.getuid()?fields[0]:undefined}catch{return undefined}}setTimeout(()=>{const before=current(),result={pid:Number(pid),start,delayMs:10000,elapsedMs:Date.now()-began,stateBeforeResume:before,resumed:false};if(before){process.kill(Number(pid),'SIGCONT');result.resumed=true}fs.writeFileSync(file,JSON.stringify(result),{flag:'wx',mode:0o600});process.exit(result.resumed?0:1)},10000);process.stdout.write('armed\\n');`;
 const watcher=spawn(process.execPath,['--max-old-space-size=64','-e',source,String(pid),start,receipt],{stdio:['ignore','pipe','pipe']});let stderr='';watcher.stderr.on('data',bytes=>{stderr=(stderr+bytes).slice(0,4096)});
 const done=new Promise((resolve,reject)=>{watcher.once('error',reject);watcher.once('exit',(code,signal)=>code===0?resolve():reject(Error('Native pause watchdog failed: '+code+'/'+signal+' '+stderr)))});done.catch(()=>{});
 try{
  await Promise.race([once(watcher.stdout,'data'),done.then(()=>{throw Error('Watchdog exited before pause')})]);assert.equal(watcher.exitCode,null);assert.equal(await processStart(pid),start);process.kill(pid,'SIGSTOP');
  // The signal syscall can return before the stopped process next reaches the scheduler.
  const until=Date.now()+1000;
  for(;;){
   const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');
   assert.equal(fields[19],start);
   if(fields[0]==='T')break;
   assert.ok(Date.now()<until,'Owned native writer did not enter stopped state');
   await new Promise(resolve=>setTimeout(resolve,10));
  }
 }catch(error){if(await processStart(pid)===start)process.kill(pid,'SIGCONT');await done.catch(()=>{});throw error}
 return {async resume(){if(await processStart(pid)===start)process.kill(pid,'SIGCONT');await done;return JSON.parse(await readFile(receipt,'utf8'))}};
}

/** Exercise an addressed edit reply across two original owners in one saved conversation. */
async function verifyPromptEditOwnerReplacement({page, section, composer, send, expect, context,
 currentUi, output, proof, save, phase, sendMain, promptEditHold}) {
 const parent = await context();
 const oldDraft = 'Keep this release review draft.';
 await composer.fill(oldDraft);
 await expect.poll(async () => (await currentUi())?.prompt, {timeout:12000})
  .toMatchObject({status:'applied', frame:{text:oldDraft}});
 await composer.focus();
 await composer.press('End');
 const prior = await currentUi();
 const heldDraft = oldDraft + ' Review later.';
 await promptEditHold.arm({type:'CLAUDE_PROMPT_STATE', threadId:prior.threadId, mountId:prior.mountId, text:heldDraft});
 await composer.pressSequentially(' Review later.');
 await expect.poll(async () => (await promptEditHold.receipts())[0], {timeout:12000})
  .toMatchObject({status:'applied', text:heldDraft});
 const held = (await promptEditHold.receipts())[0];
 const active = await currentUi();
 assert.equal(active.mountId, held.mountId);
 assert.equal(active.promptRevision, held.revision);
 assert.notEqual(active.prompt?.revision, held.revision);
 const outcome = proof.promptEditReplacement = {held, heldDraft, oldDraft, oldPid:proof.pid,
  oldStart:proof.processStart, threadId:parent.threadId, sessionId:proof.parentSessionId, captures:[]};
 await save();

 const show = section.getByRole('button',{name:'Use native interface',exact:true});
 const back = section.getByRole('button',{name:'Back to conversation',exact:true});
 const stop = section.getByRole('button',{name:'Stop session',exact:true});
 await show.click();
 await stop.click();
 await expect.poll(() => processStart(proof.pid), {timeout:15000}).not.toBe(proof.processStart);
 proof.nativeWriterRetired = true;
 if (await back.isVisible()) await back.click();
 await expect(composer).toHaveText(heldDraft);
 await show.click();
 await expect.poll(async () => {
  const state = (await context()).native?.state;
  return state?.status === 'live' && state.nativePid !== proof.pid && state.sessionId === proof.parentSessionId;
 }, {timeout:25000}).toBe(true);
 const replacement = (await context()).native.state;
 const newStart = await processStart(replacement.nativePid);
 assert.ok(newStart);
 Object.assign(outcome,{newPid:replacement.nativePid,newStart});
 await back.click();
 await expect.poll(async () => (await currentUi())?.state.status,{timeout:15000}).toBe('live');
 assert.equal((await context()).threadId,parent.threadId);
 const freshDraft = 'Keep this draft after Claude restarts.';
 await composer.focus();
 await composer.press('ControlOrMeta+a');
 await composer.press('Backspace');
 await expect(composer).toHaveText('');
 await composer.pressSequentially(freshDraft);
 await expect.poll(async () => (await currentUi())?.prompt, {timeout:12000})
  .toMatchObject({status:'applied', frame:{text:freshDraft}});
 const snapshot = async () => ({view:await currentUi(), composer:await composer.evaluate(element => {
  const selection=window.getSelection();
  return {html:element.innerHTML, anchor:selection?.anchorOffset, focus:selection?.focusOffset, active:document.activeElement===element};
 }), history:(await context()).messages});
 const before = await snapshot();
 assert.notEqual(before.view.mountId, held.mountId);
 const delivery = await promptEditHold.release(0);
 assert.equal(delivery.outcome,'delivered-on-original-socket');
 await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
 const after = await snapshot();
 assert.deepEqual(after.composer,before.composer);
 assert.deepEqual(after.history,before.history);
 assert.deepEqual(after.view.prompt,before.view.prompt);
 Object.assign(outcome,{delivery, freshDraft, newMountId:after.view.mountId, freshFrame:after.view.prompt,
  composerBefore:before.composer, composerAfter:after.composer, stableHistory:true});
 await save();
 phase('retired-prompt-edit-delivered');

 for (const [size, viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
  await page.setViewportSize(viewport);
  await expect(composer).toHaveText(freshDraft);
  await expect(composer).toBeInViewport({ratio:1});
  await expect(send).toBeInViewport({ratio:1});
  const name = `prompt-edit-replacement-${size}.png`;
  await page.screenshot({path:join(output,name),animations:'disabled'});
  outcome.captures.push(name);
 }
 await show.click();
 await stop.click();
 await expect.poll(() => processStart(outcome.newPid), {timeout:15000}).not.toBe(outcome.newStart);
 outcome.replacementRetired = true;
 if (await back.isVisible()) await back.click();
 await expect(composer).toHaveText(freshDraft);
 outcome.followup = 'Continue the same release review after the interruption.';
 await sendMain(outcome.followup);
 await expect.poll(async () => (await context()).claude?.turns, {timeout:20000}).toBe(2);
 await expect.poll(async () => (await context()).claude?.chatState, {timeout:20000}).toBe('success');
 proof.final = await context();
 assert.equal(proof.final.claude.sessionId, proof.parentSessionId);
 assert.equal(proof.final.threadId, parent.threadId);
 proof.status = 'complete';
 await save();
}
