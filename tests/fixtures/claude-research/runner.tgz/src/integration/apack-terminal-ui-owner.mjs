// Same-owner native desktop UI, field and status transport acceptance.
process.argv[5]=process.env.CLAUDE_RESEARCH_TERMINAL_CLIENTS==='1'?'terminal-client':'ui-engine';
await import('./apack-terminal-owner.mjs');
