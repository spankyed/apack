import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {record} from '../protocol/record.mjs';

/** Native attachments may sit between the exact human row and its assistant reply. */
export function findIndependentBackgroundReply(rows,text) {
 const humans=rows.filter(row=>row.type==='user'&&row.message?.role==='user'&&(row.message.content===text||Array.isArray(row.message.content)&&row.message.content.some(block=>block.type==='text'&&block.text===text)));
 if(humans.length!==1)return;
 const human=humans[0],byId=new Map(rows.filter(row=>row.uuid).map(row=>[row.uuid,row]));
 const assistant=rows.find(row=>{
  if(row.type!=='assistant'||row.sessionId!==human.sessionId)return false;
  const seen=new Set();let id=row.parentUuid;
  while(id&&seen.size<512&&!seen.has(id)){if(id===human.uuid)return true;seen.add(id);const parent=byId.get(id);if(parent?.type==='user')return false;id=parent?.parentUuid;}
  return false;
 });
 return assistant?{human,assistant}:undefined;
}

/** Probe the original authenticated sender from a fresh CLI, never a second --resume writer. */
export async function observeIndependentBackgroundReply({executable,workspace,project,env,job,output,runtime,processState,model}) {
 assert.equal(process.platform,'linux');assert.ok(basename(workspace).startsWith('apack-terminal-owner-app-'));
 assert.match(job.id,/^[a-f0-9]{8}$/u);assert.match(job.sessionId,/^[a-f0-9-]{36}$/iu);
 assert.ok(Number.isSafeInteger(job.pid)&&job.pid>1);
 const authored=await readFile(runtime,'utf8');assert.ok(authored.includes('async function replyNativeBackground('));
 const text='Continue the independent background review with the release checklist.';
 const before=await processState(job.pid);assert.ok(before&&before.state!=='Z');
 const projects=join(workspace,'.claude/projects');
 const journal=async()=>{
  const dirs=await readdir(projects,{withFileTypes:true});assert.ok(dirs.length<=20);
  const matches=[];
  for(const dir of dirs.filter(d=>d.isDirectory())){try{const file=join(projects,dir.name,job.sessionId+'.jsonl'),bytes=await readFile(file);assert.ok(bytes.length<4*1024*1024);matches.push({file,rows:bytes.toString('utf8').split('\n').filter(Boolean).map(line=>JSON.parse(line))});}catch(error){if(error.code!=='ENOENT')throw error;}}
  assert.equal(matches.length,1);return matches[0];
 };
 await writeFile(join(workspace,'native-held-model-release'),'release');
 let initial;
 for(let i=0;i<120;i++){initial=await journal();if(initial.rows.some(row=>row.type==='assistant'))break;await delay(100);}
 assert.ok(initial.rows.some(row=>row.type==='assistant'),'Initial native turn must complete');
 const request={parent_session_id:'00000000-0000-4000-8000-000000000001',child_session_id:job.sessionId,job_id:job.id,pid:job.pid,cwd:project,text};
 const resultPath=join(output,'independent-reply-result.json'),preload=join(workspace,'independent-reply.mjs');
 const source=`import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';\nconst config={sessionId:${JSON.stringify(request.parent_session_id)}};\n${authored}\ntry{const result=await replyNativeBackground(${JSON.stringify(request)});writeFileSync(${JSON.stringify(resultPath)},JSON.stringify({pid:process.pid,result}));process.exit(0);}catch(error){writeFileSync(${JSON.stringify(resultPath)},JSON.stringify({pid:process.pid,error:String(error)}));process.exit(1);}`;
 await writeFile(preload,source,{mode:0o600});
 const run=await record({executable,args:['--version'],cwd:project,env:{...env,BUN_OPTIONS:'--preload='+preload},output:join(output,'independent-reply-cli'),timeoutMs:25000,maxBytes:1024*1024});
 let result;try{result=JSON.parse(await readFile(resultPath,'utf8'));}catch(error){if(error.code!=='ENOENT')throw error;}
 const report={run,result,job,processBefore:before,authoredRuntimeSha256:createHash('sha256').update(authored).digest('hex'),preloadSha256:createHash('sha256').update(source).digest('hex'),accepted:false,scope:'Original standalone background worker and fresh authenticated sender only; no app restart or structured child ownership claim.'};
 const save=()=>writeFile(join(output,'independent-reply-observation.json'),JSON.stringify(report,null,2)+'\n');await save();
 assert.equal(run.status,'complete');assert.equal(result?.result?.queued,true,JSON.stringify(result));assert.notEqual(result.pid,job.pid);
 let after;
 for(let i=0;i<150;i++){after=await journal();if(findIndependentBackgroundReply(after.rows,text))break;await delay(100);}
 const reply=findIndependentBackgroundReply(after.rows,text);assert.ok(reply,'Original child must answer the independent reply');
 const {human,assistant}=reply;assert.equal(human.sessionId,job.sessionId);assert.equal(human.version,'2.1.302');assert.ok(model.calls.some(call=>JSON.stringify(call.messages).includes(text)),'Original model request must contain the exact follow-up');
 const processAfter=await processState(job.pid);assert.equal(processAfter?.startTime,before.startTime);assert.notEqual(processAfter.state,'Z');
 Object.assign(report,{accepted:true,processAfter,humanUuid:human.uuid,assistantUuid:assistant.uuid,journal:after.file,syntheticRequests:model.calls.length,realModelRequests:0});await save();return report;
}
