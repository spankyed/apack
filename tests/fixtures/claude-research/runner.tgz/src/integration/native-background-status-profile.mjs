import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,readdir,lstat} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';

/** Configure a real status-line command; only the original CLI executes the helper. */
export async function prepareBackgroundStatusProfile(workspace,{configDir=join(workspace,'.claude')}={}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+$/);
 assert.ok(configDir===join(workspace,'.claude')||configDir===join(workspace,'app-data/claude-code-profile/config'));
 const path=join(configDir,'settings.json'),before=await readFile(path),directory=join(workspace,'background-status-receipts'),helper=join(workspace,'background-status.mjs');await mkdir(directory,{mode:0o700});
 const source=`import {readFileSync,writeFileSync}from'node:fs';import{randomUUID}from'node:crypto';const entryMonotonicNs=process.hrtime.bigint().toString();
let raw='';for await(const bytes of process.stdin){raw+=bytes;if(Buffer.byteLength(raw)>1048576)process.exit(65)}const input=JSON.parse(raw);if(typeof input.session_id!=='string'||!Number.isFinite(input.cost?.total_cost_usd))process.exit(66);
const stdout='Release review\\nSession cost $'+input.cost.total_cost_usd.toFixed(6)+'\\n',stat=readFileSync('/proc/self/stat','utf8'),start=stat.slice(stat.lastIndexOf(')')+2).split(' ')[19],ancestry=[];let parent=process.ppid;for(let i=0;parent>1&&i<16;i++){try{const raw=readFileSync('/proc/'+parent+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');ancestry.push({pid:parent,start:fields[19]});const next=Number(fields[1]);if(!Number.isSafeInteger(next)||next===parent)break;parent=next}catch{break}}writeFileSync(${JSON.stringify(directory)}+'/'+randomUUID()+'.json',JSON.stringify({at:Date.now(),entryMonotonicNs,receiptMonotonicNs:process.hrtime.bigint().toString(),hasShellPrefix:typeof process.env.CLAUDE_CODE_SHELL_PREFIX==='string',pid:process.pid,start,ancestry,input,stdout}),{mode:0o600,flag:'wx'});process.stdout.write(stdout);
`;
 await writeFile(helper,source,{mode:0o600,flag:'wx'});const quote=s=>"'"+s.replaceAll("'","'\\''")+"'",settings={...JSON.parse(before),statusLine:{type:'command',command:quote(process.execPath)+' '+quote(helper)}};await writeFile(path,JSON.stringify(settings));await writeFile(join(workspace,'background-status-settings.json'),JSON.stringify({settings,helperSha256:createHash('sha256').update(source).digest('hex')}));
 return{async invocations(){const names=await readdir(directory);assert.ok(names.length<=128);return Promise.all(names.map(async name=>{assert.match(name,/^[a-f0-9-]+\.json$/);const p=join(directory,name),s=await lstat(p);assert.ok(s.isFile()&&s.uid===process.getuid()&&s.size<=2*1048576);return JSON.parse(await readFile(p,'utf8'))}))},async restore(){await writeFile(join(workspace,'background-status-settings-after.json'),await readFile(path));await writeFile(path,before);assert.deepEqual(await readFile(path),before)}};
}
