"""Own one temporary Linux managed-policy file for the held-main app journey."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile
import time

POLICY = Path('/etc/claude-code/managed-settings.json')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic(path, data, mode=0o644):
    fd, temporary = tempfile.mkstemp(prefix='.held-policy-', dir=path.parent)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def main():
    assert sys.platform == 'linux' and os.geteuid() == 0 and Path('/.dockerenv').exists()
    assert len(sys.argv) == 2
    workspace = Path(sys.argv[1])
    assert re.fullmatch(r'/work/\.claude-research/policy-zero-app[0-9]+', str(workspace))
    info = workspace.lstat()
    assert stat.S_ISDIR(info.st_mode) and info.st_uid == 1000 and workspace.resolve() == workspace
    identity = (info.st_dev, info.st_ino)
    assert Path('/control/offline-verified').is_file()
    boundary = json.loads(Path('/control/offline-verified').read_text())
    assert boundary['networkDisabled'] and boundary['pinnedExecutableReadOnly']
    receipt = Path('/control/policy-root-receipt.json')
    assert not receipt.exists()
    POLICY.parent.mkdir(exist_ok=True)
    assert POLICY.parent.resolve() == POLICY.parent
    before_info = POLICY.lstat() if POLICY.exists() or POLICY.is_symlink() else None
    if before_info:
        assert stat.S_ISREG(before_info.st_mode) and before_info.st_size <= 1048576
    before = POLICY.read_bytes() if before_info else None
    if before is not None:
        atomic(Path('/control/policy-root-before.json'), before, 0o600)
    command = "trap '' TERM; exec /usr/bin/python3 '" + str(workspace / 'held-status.py') + "'"
    events, hashes = [], set()
    nonce = 0
    completed = False
    started = time.monotonic()
    def own_workspace():
        current = workspace.lstat()
        assert stat.S_ISDIR(current.st_mode) and (current.st_dev, current.st_ino) == identity
        assert workspace.resolve() == workspace
    def install(phase, restricted):
        own_workspace()
        policy = {'allowManagedHooksOnly': restricted, 'statusLine': {'type': 'command', 'command': command, 'refreshInterval': 1}}
        body = json.dumps(policy, sort_keys=True).encode()
        atomic(workspace / 'held-status-state.json', json.dumps({'phase': phase}).encode())
        # Register the intended bytes before replacing: a post-write assertion must
        # still permit restoration of the file this controller just installed.
        hashes.add(digest(body))
        atomic(POLICY, body)
        observed = POLICY.lstat()
        assert observed.st_uid == 0 and stat.S_IMODE(observed.st_mode) == 0o644
        actual = POLICY.read_bytes()
        assert actual == body
        result = {'ok': True, 'phase': phase, 'nonce': nonce, 'path': str(POLICY), 'uid': 0, 'mode': 0o644, 'sha256': digest(actual)}
        events.append(result)
        atomic(workspace / ('policy-control-ready.json' if phase == 'allowed' else 'policy-control-response.json'), json.dumps(result).encode())
    try:
        install('allowed', False)
        while not Path('/control/policy-stop').exists():
            if time.monotonic() - started > 300:
                raise TimeoutError('Owned root policy controller exceeded its app boundary')
            own_workspace()
            request = workspace / 'policy-control-request.json'
            if request.exists() or request.is_symlink():
                current = request.lstat()
                assert stat.S_ISREG(current.st_mode) and current.st_uid == 1000 and current.st_size <= 1024 and current.st_nlink == 1
                value = json.loads(request.read_text())
                assert set(value) == {'nonce', 'phase'} and type(value['nonce']) is int
                if value['nonce'] != nonce:
                    assert value['nonce'] == nonce + 1 and nonce < 2
                    phase = ['restricted', 'restored'][nonce]
                    assert value['phase'] == phase
                    nonce += 1
                    install(phase, phase == 'restricted')
            time.sleep(.05)
        completed = nonce == 2
    finally:
        current = POLICY.lstat() if POLICY.exists() or POLICY.is_symlink() else None
        if current is not None:
            assert stat.S_ISREG(current.st_mode), 'Policy replaced externally; refusing to overwrite'
            actual = POLICY.read_bytes()
            assert digest(actual) in hashes or actual == before, 'Policy changed externally; refusing to overwrite'
        else:
            assert before is None, 'Original policy removed externally; refusing to overwrite'
        if before is None:
            POLICY.unlink()
            restored = not POLICY.exists()
        else:
            atomic(POLICY, before, stat.S_IMODE(before_info.st_mode))
            os.chown(POLICY, before_info.st_uid, before_info.st_gid)
            restored = POLICY.read_bytes() == before
        atomic(receipt, json.dumps({'restored': restored, 'completedTransitions': completed, 'events': events, 'originalSha256': None if before is None else digest(before), 'filesystemMapping': False, 'platformEmulation': False}).encode(), 0o600)
        assert restored


if __name__ == '__main__':
    main()
