import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(base,'query.ts')).href);
const {getSessionPlan}=await import(pathToFileURL(join(base,'plan.ts')).href);
const model=await startSyntheticModel(workspace,'TuiPlan');
const env={HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:undefined,ANTHROPIC_BASE_URL:model.url,ENABLE_TOOL_SEARCH:'0',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
const content='# Synthetic native plan\n\nImplement the isolated fixture only.\n';
let handle,permissionCount=0,pendingPlan;
try{
 handle=await query({cliPath:executable,cwd:workspace,env,tools:['Write','ExitPlanMode'],permissionMode:'plan',strictMcpConfig:true,settingSources:[],maxTurns:4,signal:AbortSignal.timeout(20000),settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),onPermissionRequest:async request=>{
  permissionCount++;assert.equal(request.tool_name,'ExitPlanMode');pendingPlan=await handle.getPlan();assert.equal(pendingPlan.exists,true);assert.equal(pendingPlan.content,content);return{behavior:'allow',updatedInput:request.input};
 }});
 assert.deepEqual(await handle.getPlan(),{exists:false});
 handle.send('NativePlanFixtureSeedAlpha: Create the synthetic plan and request approval.');
 for await(const event of handle.events)if(event.type==='result')break;
 const result=await handle.result;
 const afterPlan=await handle.getPlan();assert.deepEqual(afterPlan,pendingPlan);
 await handle.close();handle=undefined;
 const config=join(workspace,'.claude');
 const snapshot=async()=>{const files=(await readdir(config,{recursive:true})).filter(file=>file.startsWith('projects/')&&file.endsWith('.jsonl')).sort();return Promise.all(files.map(async file=>[file,createHash('sha256').update(await readFile(join(config,file))).digest('hex')]))};
 const before=await snapshot();assert.ok(before.length>0);
 const apiBefore=model.calls.length;
 const saved=await getSessionPlan({sessionId:result.sessionId,cwd:workspace,cliPath:executable,env,signal:AbortSignal.timeout(10000)});
 assert.deepEqual(saved,pendingPlan);assert.deepEqual(await snapshot(),before);assert.equal(model.calls.length,apiBefore);assert.equal(permissionCount,1);
 console.log(JSON.stringify({evidence:'apack-native-plan',targetSha256:createHash('sha256').update(await readFile(executable)).digest('hex'),emptyBefore:true,populatedDuringApproval:true,retainedAfterApproval:true,savedPlanMatches:true,transcriptUnchanged:true,permissionCount,userPromptsSent:1,syntheticApiRequests:model.calls.length,resumeApiRequests:model.calls.length-apiBefore,realModelRequests:0}));
}finally{try{if(handle)await handle.close()}finally{await model.close()}}
