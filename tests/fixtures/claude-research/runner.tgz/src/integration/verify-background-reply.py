"""Verify saved app/native background-reply evidence without running the original CLI."""
from pathlib import Path
import argparse, hashlib, json, re, subprocess, tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence', type=Path)
parser.add_argument('product_checkout', type=Path)
parser.add_argument('--commit', help='Tested product commit; defaults to HEAD')
parser.add_argument('--research-commit', help='Verify recorded research inputs against this commit')
parser.add_argument('--capture-profile', choices=['reply','lifecycle','owner-loss'], default='reply')
args = parser.parse_args()
evidence = args.evidence.resolve()
product = args.product_checkout.resolve()
research = Path(__file__).resolve().parents[2]

def load(path):
    assert path.stat().st_size < 32 * 1024**2, path
    return json.loads(path.read_text())

def git_input(repo, commit, path):
    assert not Path(path).is_absolute() and '..' not in Path(path).parts
    return subprocess.check_output(['git', 'show', commit + ':' + path], cwd=repo)

commit = subprocess.check_output(['git', 'rev-parse', args.commit or 'HEAD'], cwd=product, text=True).strip()
inputs = load(evidence / 'source-inputs.json')
assert inputs, 'Expected the complete implementation delta, not an empty dirty-file list'
for path, digest in inputs.items():
    assert hashlib.sha256(git_input(product, commit, path)).hexdigest() == digest, path
research_inputs = load(evidence / 'authored-inputs.json')
if args.research_commit:
    for path, digest in research_inputs.items():
        assert hashlib.sha256(git_input(research, args.research_commit, path)).hexdigest() == digest, path
compiled = load(evidence / 'compiled-before.json')
assert compiled == load(evidence / 'compiled-after.json')
boundary = load(evidence / 'offline-boundary.json')
assert boundary['networkDisabled'] and boundary['pinnedExecutableReadOnly']
assert set(boundary['networks']) == {'none'}
assert boundary['memory'] == boundary['memorySwap'] == 6 * 1024**3
assert boundary['nanoCpus'] == 2 * 10**9
observations = list((evidence / 'records/workspaces').glob('*/native-background-app-observation.json'))
assert len(observations) == 1
workspace = observations[0].parent
state = load(observations[0])
reply = state['childReply']
assert not state['errors'] and state['uiStop'] and state['childPidRetired'] and not state.get('cleanupStop')
assert reply['queued'] and reply['remountDraftPreserved']
assert reply['parentBefore']['messages'] == reply['parentAfter']['messages']
assert reply['parentBefore']['claude']['totalCostUsd'] == reply['parentAfter']['claude']['totalCostUsd']
assert reply['workerBefore']['start'] == reply['workerAfter']['start']
assert reply['workerAfter']['state'] != 'Z'
after = state['childProcessAfterStop']
assert after.get('state') in ['gone', 'Z'] or after.get('start') != reply['workerBefore']['start']
parent_id = state['parentSessionId']
child_id = state['job']['sessionId']
assert parent_id != child_id

def rows(session_id):
    files = list((workspace / '.claude/projects').glob('*/' + session_id + '.jsonl'))
    assert len(files) == 1
    return [json.loads(line) for line in files[0].read_text().splitlines() if line]

parent, child = rows(parent_id), rows(child_id)
calls = load(workspace / 'model-calls.json')

def text(content):
    if isinstance(content, str):
        return content
    return ''.join(block.get('text', '') for block in content or [] if block.get('type') == 'text')

by_id = {row['uuid']: row for row in child if row.get('uuid')}
def descends(row, target):
    parent = row.get('parentUuid')
    seen = set()
    while parent and parent not in seen and len(seen) < 128:
        if parent == target:
            return True
        seen.add(parent)
        prior = by_id.get(parent, {})
        if prior.get('type') == 'user' and (prior.get('origin') or {}).get('kind') == 'human':
            return False
        parent = prior.get('parentUuid')
    return False

receipts = []
for content in [reply['replyText'], reply['retainedReply']]:
    humans = [row for row in child if row.get('type') == 'user' and (row.get('origin') or {}).get('kind') == 'human' and (row.get('message') or {}).get('content') == content]
    assert len(humans) == 1
    human = humans[0]
    assert human['sessionId'] == child_id and human['version'] == '2.1.302'
    assert not any((row.get('message') or {}).get('content') == content for row in parent)
    matching_calls = []
    for call in calls['agent']:
        latest = next((message for message in reversed(call.get('messages', [])) if message.get('role') == 'user'), {})
        if text(latest.get('content')) == content and call.get('delivered'):
            matching_calls.append(call)
    assert len(matching_calls) == 1, 'Expected one delivered native model request for each reply'
    call = matching_calls[0]
    assert call.get('responseMessageId'), 'A queued receipt alone does not prove the native response'
    answers = [row for row in child if row.get('type') == 'assistant' and (row.get('message') or {}).get('id') == call['responseMessageId'] and text(row['message']['content']) == call['response'] and descends(row, human['uuid'])]
    assert len(answers) == 1
    receipts.append({'humanUuid': human['uuid'], 'assistantUuid': answers[0]['uuid'], 'responseMessageId': call['responseMessageId']})
child_uuids = {item['humanUuid'] for item in receipts} | {item['assistantUuid'] for item in receipts}
for message in state['current']['messages']:
    native = (message.get('context') or {}).get('claudeTerminalMessage') or {}
    assert native.get('sessionId', parent_id) == parent_id and native.get('uuid') not in child_uuids
costs = [row['totalCostUSD'] for row in parent if row.get('type') == 'cost-state']
assert costs and state['current']['claude']['totalCostUsd'] == costs[-1]
assert next(row for row in state['after'] if row['id'] == state['job']['id'])['state'] == 'stopped'
screens = sorted((evidence / 'records').rglob('apack-native-*.png'))
stages = ['review','handoff','running','reply-draft','reply-queued','stopped']
if args.capture_profile == 'lifecycle': stages += ['reload','broker-unavailable','broker-recovered']
if args.capture_profile == 'owner-loss':
    stages += ['parent-disconnected']
    loss = state['parentOwnerLoss']
    assert all(loss.get(key) is True for key in ['parentProcessRetired','remountedWithoutOwner','parentPreserved'])
    assert loss['removed']['pid'] == state['parentNativePid'] and loss['removed']['pid'] != state['job']['pid']
    assert loss['beforeWorker']['start'] == loss['afterWorker']['start'] == reply['workerBefore']['start']
    assert loss['afterWorker']['state'] != 'Z'
    assert loss['removed'].get('via') == 'native-ui-stop'
    assert loss['retainedParentState']['status'] in ['exited', 'error']
    assert loss['retainedParentState']['ownerId'] == loss['removed']['ownerId']
    children = [json.loads(line) for line in (workspace / 'native-children.jsonl').read_text().splitlines() if line]
    exits = [json.loads(line) for line in (workspace / 'native-exits.jsonl').read_text().splitlines() if line]
    assert any(row['pid'] == loss['removed']['pid'] and row['at'] <= loss['closedAt'] for row in exits)
    helpers = [row for row in children if row['args'] == ['--version'] and row['at'] >= loss['closedAt']]
    assert len(helpers) == 2, 'Both replies must use fresh native helpers after parent exit'
    assert all(any(exit['pid'] == helper['pid'] and exit['code'] == 0 and exit['at'] >= helper['at'] for exit in exits) for helper in helpers)
expected = {'apack-native-background-' + stage + '-' + size + '.png' for stage in stages for size in ['normal','compact']}
assert len(screens) == len(expected) and {path.name for path in screens} == expected, 'Expected every named normal/compact capture for the selected journey'
route = next(line for line in (workspace / '.claude/daemon.log').read_text().splitlines() if ('bg claimed-spare ' + state['job']['id'] + ' ') in line or ('bg spawned ' + state['job']['id'] + ' ') in line)
guards = []
with tarfile.open(evidence / 'raw-evidence.tgz') as archive:
    for member in archive:
        if member.isfile() and member.name.endswith('/native-app-launcher.cjs') and member.size < 256000:
            match = re.search(rb"const timeout=setTimeout\(\(\)=>child.kill\('SIGKILL'\),(\d+)\)", archive.extractfile(member).read())
            assert match
            guards.append(int(match[1]))
assert guards == [180000]
report = {'status':'passed', 'runtimeCommit':commit, 'committedProductInputsVerified':len(inputs), 'committedResearchInputsVerified':len(research_inputs) if args.research_commit else 0, 'researchCommit':args.research_commit, 'compiledFilesUnchanged':len(compiled['files']), 'parentSessionId':parent_id, 'childSessionId':child_id, 'jobId':state['job']['id'], 'workerPid':state['job']['pid'], 'nativeDispatchRoute':route, 'workerStart':reply['workerBefore']['start'], 'workerAfterStop':after, 'receipts':receipts, 'parentFinalCost':costs[-1], 'parentHistoryAndCostPreserved':True, 'draftNavigationRecovery':True, 'fallbackStop':False, 'pageErrors':[], 'syntheticRequests':sum(len(items) for items in calls.values()), 'realModelRequests':0, 'nativeChildGuardMs':guards[0], 'captures':len(screens), 'scope':'Original next-turn text replies while the parent broker and a listed child worker are live. No resolved child desktop drawing/action, rich/media prompt, broker-loss/restart or full F1–F5 acceptance.'}
if args.capture_profile == 'owner-loss':
    report['scope'] = 'Original next-turn text replies after actual parent-owner disposal and Settings navigation/return, on the unchanged native child. Full API/app restart, independent child status broker, structured drawing/actions, rich/media and combined F1–F5 remain unaccepted.'
    report['parentOwnerLoss'] = loss
    report['parentProcessExitVerified'] = True
    report['navigationReturnVerified'] = True
    report['rendererUnmountVerified'] = False
    report['appRestartVerified'] = False
(evidence / 'saved-record-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
