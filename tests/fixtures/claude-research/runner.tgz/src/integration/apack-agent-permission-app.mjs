import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const hashes=async()=>Object.fromEntries(await Promise.all(['actions.content.json','flows.content.json'].map(async name=>[name,hash(await readFile(join(checkout,'packages/default-setup/dist/runtime/content',name)))])));
const before=await hashes(),model=await startSyntheticAgentModel({childTool:{name:'Bash',input:{command:'/usr/bin/printf NativeChildPermissionApproved > child-permission-marker.txt',description:'Write only the disposable child permission marker'}}});let child,exited=false,deadline,escalation;
try{
 child=spawn(process.execPath,[join(checkout,'node_modules/vitest/vitest.mjs'),'run','tests/features/code/be/services/claude-code/native-agent-permission-app.spec.ts','--pool=threads','--maxWorkers=1','--minWorkers=1','--no-file-parallelism'],{cwd:join(checkout,'packages/default-setup'),env:{...process.env,CLAUDE_RESEARCH_EXECUTABLE:executable,CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_MODEL_URL:model.url},stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);
 deadline=setTimeout(()=>{child.kill('SIGTERM');escalation=setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000)},110000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',code=>{exited=true;resolve(code)})});
 assert.equal(code,0,'Native Agent app flow test failed');assert.deepEqual(await hashes(),before);
 assert.equal(model.calls.filter(call=>call.response==='Agent').length,2);assert.equal(model.calls.filter(call=>call.response==='Bash').length,2);
 assert.deepEqual(model.calls.filter(call=>call.childToolResult).map(call=>call.childToolError).sort(),[false,true]);
 assert.ok(model.calls.every(call=>call.delivered===true));
 const cases=await Promise.all(['allow','deny'].map(async decision=>JSON.parse(await readFile(join(workspace,`child-${decision}-evidence.json`),'utf8'))));
 console.log(JSON.stringify({evidence:'apack-native-agent-permission-app',cases,targetSha256:hash(await readFile(executable)),compiledContentHashes:before,syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{
 clearTimeout(deadline);clearTimeout(escalation);if(child&&!exited){child.kill('SIGTERM');setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000).unref()}
 await writeFile(join(workspace,'agent-app-requests.json'),JSON.stringify(model.requests,null,2));
 console.log(JSON.stringify({diagnostic:'agent-app-calls',calls:model.calls}));await model.close();
}
