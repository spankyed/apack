import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs';
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs';
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs';
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';

const offlineKey = 'research-fixture-key';
const draft = 'Keep my release note edits.';
const firstTurn = 'Review the release notes.';
const bindings = JSON.stringify({ bindings: [{ context: 'Global', bindings: {
  'ctrl+o': null, 'ctrl+alt+p': 'app:toggleTranscript',
} }] });
const reboundBindings = bindings.replace('ctrl+alt+p', 'ctrl+alt+r');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
async function birth(pid) {
  try {
    const value = await readFile('/proc/' + pid + '/stat', 'utf8');
    const fields = value.slice(value.lastIndexOf(')') + 2).split(' ');
    return fields[0] === 'Z' ? null : fields[19];
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw error;
  }
}

/** Replay compatible normal, safe and bare owners against separate copies of one ordinary keybindings file. */
export async function driveKeybindingMode({ checkout, workspace, env, mode, reload = false }) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-keybindings-(normal|safe|bare)-[0-9]+$/);
  assert.ok(['normal', 'safe', 'bare'].includes(mode));
  assert.ok(!reload || mode === 'normal');
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.requireDesktopKeybindingPolicy && boundary.networkDisabled && boundary.pinnedExecutableReadOnly);
  const project = join(workspace, 'project');
  await mkdir(project);
  execFileSync('/usr/bin/git', ['init', '--quiet', project], { env: { PATH: '/usr/bin:/bin', HOME: workspace, GIT_CONFIG_NOSYSTEM: '1' }, timeout: 5000 });
  const account = await configureNativeCreditAccount(workspace, 'oauth', { featureCache: 'native-defaults' });
  const configDir = join(workspace, '.claude');
  const configPath = join(configDir, '.claude.json');
  const config = JSON.parse(await readFile(configPath, 'utf8'));
  await writeFile(configPath, JSON.stringify({ ...config, hasCompletedOnboarding: true }));
  await writeFile(join(configDir, 'settings.json'), JSON.stringify({ theme: 'dark', model: 'opus' }));
  const bindingPath = join(configDir, 'keybindings.json');
  await writeFile(bindingPath, bindings, { mode: 0o600, flag: 'wx' });
  let executable = '/frozen-claude/claude';
  if (mode === 'bare') {
    executable = join(workspace, 'launch-bare-claude');
    await writeFile(executable, [
      '#!/bin/sh',
      'for arg do',
      '  case "$arg" in',
      '    --print|--version) exec /frozen-claude/claude "$@" ;;',
      '  esac',
      'done',
      'export ANTHROPIC_API_KEY=' + offlineKey,
      'exec /frozen-claude/claude "$@" --bare',
      '',
    ].join('\n'), { mode: 0o700, flag: 'wx' });
  }
  const tls = await prepareNativeCreditTls(join(workspace, 'account-tls'));
  const billing = await startNativeCreditBilling(tls, { allowMutations: false, evidencePath: join(workspace, 'account-live.json') });
  const model = await startSyntheticModel(workspace, 'TextOnly', { textReply: 'The release summary is ready.', maxRequests: 6 });
  const launchEnv = {
    ...env, ...account, NODE_EXTRA_CA_CERTS: tls.ca, ANTHROPIC_BASE_URL: model.url,
    PATH: '/frozen-claude:' + env.PATH, CLAUDE_RESEARCH_PROJECT: project, DISABLE_AUTOUPDATER: '1',
  };
  delete launchEnv.ANTHROPIC_API_KEY;
  delete launchEnv.CLAUDE_CODE_SAFE_MODE;
  if (mode === 'safe') launchEnv.CLAUDE_CODE_SAFE_MODE = '1';
  try {
    await driveFreshNativeApp({ checkout, workspace, env: launchEnv, route: 'real-Electron-keybinding-mode', journeyBudgetMs: 110000,
      journey: args => keybindingJourney({ ...args, mode, model, bindingPath, executable, reload }),
    });
  } finally {
    await model.close();
    await billing.close();
    if (reload) {
      await writeFile(join(workspace, 'keybindings-observed.json'), await readFile(bindingPath));
      await writeFile(bindingPath, bindings);
    }
    assert.equal(await readFile(bindingPath, 'utf8'), bindings);
    await writeFile(join(workspace, 'model-calls.json'), JSON.stringify(model.calls));
  }
}

async function keybindingJourney({ app, page, project, output, expect, mode, model, bindingPath, executable, reload }) {
  page.setDefaultTimeout(8000);
  const proof = { mode, keybindingsSha256: sha(bindings), cases: [], status: 'running' };
  const save = () => writeFile(join(output, 'desktop-keybinding-mode.json'), JSON.stringify(proof, null, 2));
  const context = () => page.evaluate(() => {
    const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    return {
      claude: c.currentThread?.context?.claudeCode,
      native: Object.values(c.nativeTerminalViews).find(view => view.threadId === c.currentThread?.id)?.state,
    };
  });
  const section = page.getByRole('region', { name: 'Claude native interface', exact: true });
  const card = page.locator('[data-onboarding-id="agent-chat-input"]');
  const composer = card.locator('[contenteditable="true"]');
  const send = card.getByRole('button', { name: 'Send', exact: true });
  const input = section.getByLabel('Terminal input', { exact: true });
  const screen = section.locator('[data-terminal-text]');
  const transcript = async () => (await screen.innerText()).replace(/\s+/g, ' ').includes('Showing detailed transcript');
  const requests = () => model.calls.filter(call => call.path.split('?')[0] === '/v1/messages').length;
  const replace = async text => {
    await composer.click();
    await composer.press('ControlOrMeta+a');
    await composer.press('Backspace');
    await composer.pressSequentially(text);
    await expect(composer).toHaveText(text);
  };
  try {
    await app.waitForSurface('default-setup/threads');
    await app.navigate('host/settings');
    await page.evaluate(() => {
      const actor = window.applicationState.system.get('host/settings');
      actor.send({ type: 'TAB.SELECT', tab: 'general' });
      actor.send({ type: 'GENERAL_NAV.SELECT', item: 'secrets' });
    });
    const provider = page.getByText('Claude Code CLI', { exact: true }).locator('..').locator('..').locator('..');
    await provider.getByPlaceholder('Path override (auto-detected if empty)').fill(executable);
    await page.waitForTimeout(700);
    await app.navigate('default-setup/threads');
    await expect.poll(() => page.evaluate(() => {
      const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
      return !!c.currentThread?.id && c.openedThreadId === null && c.tabs.every(tab => c.tabsRead.includes(tab.id)) && c.modes.some(m => m.name === 'Claude Code');
    }), { timeout: 15000 }).toBe(true);
    await page.evaluate(directory => {
      const actor = window.applicationState.system.get('default-setup/threads');
      actor.send({ type: 'VIEW_DASHBOARD' });
      actor.send({ type: 'NEW_THREAD_IN_PROJECT', directory });
      actor.send({ type: 'SET_MODE', mode: 'Claude Code' });
      actor.send({ type: 'SET_PHASE', phase: 'Edit' });
    }, project);
    await replace(firstTurn);
    await send.click();
    await expect.poll(async () => (await context()).claude?.turns, { timeout: 30000 }).toBe(1);
    await replace(draft);
    await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
    const seen = new Set();
    const onboarding = mode === 'bare' ? { apiKeySuffix: offlineKey } : undefined;
    for (let attempt = 0; attempt < 150; attempt++) {
      if ((await context()).native?.status === 'live' && (mode !== 'bare' || seen.has('environment-api-key-selected'))) break;
      const action = recognizeOnboardingPrompt(await screen.innerText({ timeout: 500 }).catch(() => ''), project, onboarding);
      if (action && !seen.has(action)) {
        seen.add(action);
        await input.focus();
        if (action.startsWith('workspace-trust')) await page.waitForTimeout(200);
        await page.keyboard.press(action === 'workspace-trust' ? 'ArrowDown' : action === 'environment-api-key' ? 'ArrowUp' : 'Enter');
      }
      await page.waitForTimeout(100);
    }
    await expect.poll(async () => (await context()).native?.status, { timeout: 25000 }).toBe('live');
    const initial = await context();
    const pid = initial.native.nativePid;
    const started = await birth(pid);
    assert.ok(started);
    proof.owner = { pid, started, sessionId: initial.claude.sessionId };
    const nativeEnv = (await readFile('/proc/' + pid + '/environ', 'utf8')).split('\0');
    assert.equal(nativeEnv.includes('CLAUDE_CODE_SAFE_MODE=1'), mode === 'safe');
    assert.ok(nativeEnv.includes('CLAUDE_CONFIG_DIR=' + dirname(bindingPath)));
    if (mode === 'bare') {
      const args = (await readFile('/proc/' + pid + '/cmdline', 'utf8')).split('\0');
      assert.ok(args.includes('--bare') && args[0] === '/frozen-claude/claude');
      assert.ok(seen.has('environment-api-key') && seen.has('environment-api-key-selected'));
      proof.originalBareFlag = true;
      proof.ownedKeyConsent = true;
    }
    const expand = section.getByRole('button', { name: 'Expand', exact: true });
    if (await expand.isVisible()) await expand.click();
    await expect(section.getByRole('button', { name: 'Minimize', exact: true })).toBeVisible();
    const before = requests();
    let denied = mode === 'safe' ? 'Control+Alt+p' : 'Control+o';
    let admitted = mode === 'safe' ? 'Control+o' : 'Control+Alt+p';
    if (reload) {
      await input.focus();
      await page.keyboard.press(admitted);
      const footer = async () => (await screen.innerText()).replace(/\s+/g, ' ');
      await expect.poll(footer, { timeout: 5000 }).toContain('ctrl+alt+p to toggle');
      const replacedAt = Date.now();
      await writeFile(bindingPath + '.next', reboundBindings, { mode: 0o600, flag: 'wx' });
      await rename(bindingPath + '.next', bindingPath);
      await expect.poll(footer, { timeout: 10000 }).toContain('ctrl+alt+r to toggle');
      proof.reload = {
        elapsedMs: Date.now() - replacedAt,
        originalSha256: sha(bindings),
        replacementSha256: sha(reboundBindings),
        footerUpdatedWhileOpen: await transcript(),
      };
      assert.ok(proof.reload.footerUpdatedWhileOpen);
      denied = admitted;
      admitted = 'Control+Alt+r';
      await page.keyboard.press(admitted);
      await expect.poll(transcript, { timeout: 5000 }).toBe(false);
    }
    for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
      await page.setViewportSize(viewport);
      await input.focus();
      await expect.poll(transcript).toBe(false);
      await page.keyboard.press(denied);
      await page.waitForTimeout(400);
      assert.equal(await transcript(), false);
      await page.keyboard.press(admitted);
      await expect.poll(transcript, { timeout: 5000 }).toBe(true);
      const name = 'keybinding-transcript-' + mode + '-' + size + '.png';
      await page.screenshot({ path: join(output, name), animations: 'disabled' });
      await page.keyboard.press(admitted);
      await expect.poll(transcript, { timeout: 5000 }).toBe(false);
      proof.cases.push({ size, denied, admitted, openedAndClosed: true, screenshot: name });
      await save();
    }
    assert.equal(requests(), before);
    assert.equal(await birth(pid), started);
    await section.getByRole('button', { name: 'Back to conversation', exact: true }).click();
    await expect(composer).toHaveText(draft);
    assert.equal((await context()).claude.sessionId, proof.owner.sessionId);
    await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
    await section.getByRole('button', { name: 'Stop session', exact: true }).click();
    await expect.poll(() => birth(pid), { timeout: 15000 }).toBe(null);
    assert.equal(await readFile(bindingPath, 'utf8'), reload ? reboundBindings : bindings);
    proof.noModelCallFromShortcuts = true;
    proof.draftRetained = true;
    proof.nativeWriterRetired = true;
    proof.status = 'complete';
  } catch (error) {
    proof.status = 'failed';
    proof.error = error.message;
    proof.nativeScreen = await screen.innerText({ timeout: 1000 }).catch(() => null);
    throw error;
  } finally {
    await save();
  }
}
