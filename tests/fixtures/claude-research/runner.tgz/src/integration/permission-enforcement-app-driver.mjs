import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const model=await startSyntheticModel(workspace,'Bash',{forceBash:true,bashPerInput:true});let deadline;
try{
 const child=spawn(process.execPath,[join(checkout,'node_modules/vitest/vitest.mjs'),'run','tests/features/code/be/services/claude-code/native-permission-enforcement-app.spec.ts','--pool=threads','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--silent'],{cwd:join(checkout,'packages/default-setup'),env:{...process.env,ANTHROPIC_BASE_URL:model.url,CLAUDE_RESEARCH_MODEL_URL:model.url,CLAUDE_RESEARCH_EXECUTABLE:executable,CLAUDE_RESEARCH_WORKSPACE:workspace},stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);deadline=setTimeout(()=>child.kill('SIGTERM'),65000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',resolve)});assert.equal(code,0,'Compiled permission enforcement test failed');
 assert.deepEqual(model.calls.map(call=>call.fixtureTurn),[1,1,2,2,3,3]);assert.ok(model.calls.every(call=>call.path.startsWith('/v1/messages')&&!call.path.includes('count_tokens')));
 const evidence=JSON.parse(await readFile(join(workspace,'permission-enforcement-app-evidence.json'),'utf8'));
 console.log(JSON.stringify({evidence:'native-permission-enforcement-app',...evidence,syntheticModelRequests:model.calls.length,realModelRequests:0}));
}finally{clearTimeout(deadline);await model.close()}
