import assert from 'node:assert/strict';
import {access,mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {setTimeout as delay} from 'node:timers/promises';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
import {createNativeTestImage} from '../protocol/native-test-image.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {nativeAgentMediaRouteObserver} from '../protocol/native-agent-media-route.mjs';
const [checkout,executable,root]=process.argv.slice(2),sha=value=>createHash('sha256').update(value).digest('hex');
assert.equal(process.platform,'linux');await access('/.dockerenv');assert.equal(process.getuid(),1000);assert.ok(isAbsolute(root));assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
for(const name of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[name],undefined);
await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'native-agent-media-route-')),config=join(workspace,'.claude'),observation=join(workspace,'native-drafts.jsonl'),preload=join(workspace,'observe.mjs');
await mkdir(join(config,'agents'),{recursive:true});await writeFile(join(config,'agents/status-fixture.md'),'---\nname: status-fixture\ndescription: Disposable image-delivery worker\ntools: []\n---\nNativeStatusChildSystem. Return the fixed worker response without tools.\n');
await writeFile(join(config,'settings.json'),JSON.stringify({theme:'dark',apiKeyHelper:'/usr/bin/printf research-fixture-key'})+'\n');await writeFile(preload,nativeAgentMediaRouteObserver(observation));
const service=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(service,'query.ts')).href),store=await import(pathToFileURL(join(service,'handle-store.ts')).href),{prepareClaudeNativeTerminal}=await import(pathToFileURL(join(service,'terminal-owner.ts')).href);
const seed=await startSyntheticModel(workspace,'TextOnly'),model=await startSyntheticAgentModel({steeringProbe:true,holdChildUntilRelease:true,parentLaunchOnce:true,requestLimit:12,captureMessages:true});
const env={HOME:workspace,CLAUDE_CONFIG_DIR:config,BUN_OPTIONS:'--preload='+preload};
let owner,native,seedResult,unsubscribe,timer,screen,sequence=0,lastAction=0,theme=false,security=false,selected=false,trusted=false,trustAt=0,terminal='';const receipts=[];
const wait=async(check,message,ms=20000)=>{const until=Date.now()+ms;while(Date.now()<until){if(await check())return;await delay(50)}throw Error(message)};
const observed=async()=>{try{return(await readFile(observation,'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse).at(-1)}catch(error){if(error.code==='ENOENT')return;throw error}};
try{
 owner=await store.openConversation('agent-media-route',JSON.stringify({cwd:workspace,allowedTools:['Agent']}),()=>query({cliPath:executable,cwd:workspace,env:{...env,ANTHROPIC_BASE_URL:seed.url},tools:[],keepStdinOpen:true,replayUserMessages:true}),async turn=>{for await(const line of turn.handle.events){}seedResult=await turn.handle.result;owner.release(turn.handle)});
 await owner.handle.initialized;owner.start('Seed the owned Agent media review.',async turn=>{for await(const line of turn.handle.events){}seedResult=await turn.handle.result;owner.release(turn.handle)});await wait(()=>seedResult&&!owner.busy,'Print seed did not settle');
 const sessionId=owner.sessionId,oldPid=owner.handle.pid;native=await store.openNativeTerminal('agent-media-route',{cliPath:executable,env:{...env,ANTHROPIC_BASE_URL:model.url}},prepareClaudeNativeTerminal);
 globalThis.self??=globalThis;const {Terminal}=createRequire(join(checkout,'packages/default-setup/package.json'))('@app/claude-terminal-xterm');screen=new Terminal({cols:100,rows:30,allowProposedApi:true});let updating=false;
 const observe=async()=>{if(updating)return;updating=true;try{const chunks=native.output.filter(row=>row.sequence>sequence);if(chunks.length){terminal=(terminal+chunks.map(row=>row.text).join('')).slice(-131072);await new Promise(resolve=>screen.write(chunks.map(row=>row.text).join(''),resolve));sequence=chunks.at(-1).sequence;}if(Date.now()-lastAction<250||native.state.status==='live')return;const b=screen.buffer.active,text=Array.from({length:screen.rows},(_,i)=>b.getLine(b.baseY+i)?.translateToString(true)??'').join('\n'),prompt=recognizeOnboardingPrompt(text,workspace);let input;if(prompt==='theme'&&!theme){theme=true;input='\r'}else if(prompt==='security-notes'&&!security){security=true;input='\r'}else if(prompt==='workspace-trust'&&!selected){selected=true;trustAt=Date.now();input='\x1b[B'}else if(prompt==='workspace-trust-selected'){selected=true;if(!trustAt)trustAt=Date.now();if(!trusted&&Date.now()-trustAt>1200){trusted=true;input='\r'}}if(input){lastAction=Date.now();native.input(native.state.ownerId,input);}}finally{updating=false}};
 unsubscribe=native.subscribe(()=>void observe());timer=setInterval(()=>void observe(),100);await observe();await wait(()=>native.state.status==='live','Original native onboarding did not finish',25000);
 await native.submit('NativeSubagentParentFixture: run the disposable status worker.');await wait(()=>native.state.tasks.some(task=>task.status==='running')&&model.calls.some(call=>call.child),'Original worker did not start');
 const taskId=native.state.tasks.find(task=>task.status==='running').id;await native.operateTask(taskId,'foreground');await wait(()=>native.state.view?.kind==='agent'&&native.state.view.taskId===taskId,'Original Agent selection not acknowledged');
 for(const[stage,rgba]of [['running',[255,0,0,255]],['resumed',[0,0,255,255]]]){
  assert.equal(native.state.view.taskId,taskId);const image=createNativeTestImage(rgba),path=join(workspace,stage+'.png'),text='NativeAgentSteerFixture: inspect the '+stage+' attachment. ';await writeFile(path,image);
  assert.equal(native.input(native.state.ownerId,'\x1b[200~'+text+'\x1b[201~'),true);await wait(async()=>(await observed())?.draft===text,'Original Agent did not accept text for '+stage);
  assert.equal(native.input(native.state.ownerId,'\x1b[200~'+path+'\x1b[201~'),true);await wait(async()=>{const row=await observed();return row?.taskId===taskId&&row.draft.includes('[Image #')&&row.images.some(item=>item.sha256===sha(image))},'Original Agent did not admit image paste for '+stage);
  const before=await observed(),requestIndex=model.requests.length;assert.equal(native.input(native.state.ownerId,'\r'),true);if(stage==='running')model.releaseChild();
  await wait(()=>model.calls.some(call=>call.child&&call.steeringObserved&&call.delivered&&call.requestIndex>=requestIndex)&&native.state.tasks.some(task=>task.id===taskId&&task.status==='completed')&&!native.busy,'Original Agent did not finish '+stage+' delivery',25000);
  const inspected=await native.operateTask(taskId,'inspect'),requests=model.calls.filter(call=>call.child&&call.requestIndex>=requestIndex).map(call=>({call,request:model.requests[call.requestIndex]}));
  const images=requests.flatMap(row=>row.request.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='image'):[]);
  receipts.push({stage,taskId,before,imageSha256:sha(image),requestIndex,requests,imageBlocks:images.length,exactImageDelivered:images.some(block=>block.source?.type==='base64'&&sha(Buffer.from(block.source.data,'base64'))===sha(image)),transcript:inspected.details.messages});
  await writeFile(join(workspace,'route-progress.json'),JSON.stringify({sessionId,oldPid,nativePid:native.state.pid,receipts},null,2)+'\n');
 }
 await writeFile(join(workspace,'route.json'),JSON.stringify({targetSha256:sha(await readFile(executable)),sessionId,oldPid,nativePid:native.state.pid,taskId,receipts,modelRequests:model.requests,modelCalls:model.calls,realModelRequests:0,scope:'Original native file-paste and Enter to selected local Agent only; no mounted app image UI or generic attachment support claim.'},null,2)+'\n');console.log(JSON.stringify({workspace,stages:receipts.map(row=>({stage:row.stage,imageBlocks:row.imageBlocks,exactImageDelivered:row.exactImageDelivered})),realModelRequests:0}));
}finally{
 clearInterval(timer);unsubscribe?.();screen?.dispose();model.releaseChild();store.killAllHandles();if(native)await native.close();
 await writeFile(join(workspace,'terminal.txt'),terminal);await writeFile(join(workspace,'model-calls.json'),JSON.stringify({seed:seed.calls,agent:model.calls,requests:model.requests},null,2)+'\n');await writeFile(join(workspace,'shutdown.json'),JSON.stringify({nativePid:native?.state.pid,nativeExit:native?.state.exitCode,ownerReleased:store.getNativeTerminal('agent-media-route')===undefined})+'\n');await seed.close();await model.close();
}
