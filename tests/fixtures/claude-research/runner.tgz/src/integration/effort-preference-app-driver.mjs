import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const[checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const model=await startSyntheticModel(workspace,'TextOnly',{captureEffort:true});let child,exited=false,deadline,escalation;
try{
 child=spawn(process.execPath,[join(checkout,'node_modules/vitest/vitest.mjs'),'run','tests/content/actions/claude-code/effort-preference-native.spec.ts','--pool=threads','--maxWorkers=1','--minWorkers=1','--no-file-parallelism'],{cwd:join(checkout,'packages/default-setup'),env:{...process.env,CLAUDE_RESEARCH_EXECUTABLE:executable,CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_MODEL_URL:model.url},stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);
 deadline=setTimeout(()=>{child.kill('SIGTERM');escalation=setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000)},45000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',code=>{exited=true;resolve(code)})});
 assert.equal(code,0,'Native effort preference app test failed');assert.equal(model.calls.length,2);assert.ok(model.calls.every(call=>call.effort==='medium'));
 const evidence=JSON.parse(await readFile(join(workspace,'effort-preference-app-evidence.json'),'utf8'));
 console.log(JSON.stringify({evidence:'apack-native-effort-preference',...evidence,localModelRequests:model.calls.length,realModelRequests:0}));
}finally{clearTimeout(deadline);clearTimeout(escalation);if(child&&!exited){child.kill('SIGTERM');setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000).unref()}await model.close();}
