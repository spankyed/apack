import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';

const TOOL = 'mcp__research__echo';
const SELECTOR = 'server:research';
const NOTIFICATION = 'OWNED_CHANNEL_NOTIFICATION';
export const channelPrompt = 'Run the owned channel echo once.';

export async function selectOwnedChannel({page,card,composer,replace,expect,context,proof,output,save,selector=SELECTOR}) {
  proof.draft = 'Keep this note while configuring release notifications.';
  await replace(proof.draft);
  const button = card.getByRole('button',{name:'Claude channels',exact:true});
  if(await button.isVisible()) await button.click();
  else {
    await card.getByRole('button',{name:'More actions',exact:true}).click();
    await page.getByRole('menuitem',{name:'Claude channels',exact:true}).click();
  }
  const dialog=page.getByRole('dialog',{name:'Claude channels',exact:true});
  const field=dialog.getByRole('textbox');
  const submit=dialog.getByRole('button',{name:'Save channels',exact:true});
  await field.fill(selector);
  for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]) {
    await page.setViewportSize({width,height});
    await expect(field).toBeInViewport({ratio:1});
    await expect(submit).toBeInViewport({ratio:1});
    const name='native-channel-selection-'+size+'.png';
    await page.screenshot({path:join(output,name),animations:'disabled'});
    proof.captures.push(name);
    await save();
  }
  await submit.click();
  await expect(dialog).toBeHidden();
  await expect.poll(async()=> (await context()).claude.channelSelection).toEqual([selector]);
  await expect(composer).toHaveText(proof.draft);
  proof.channelSelection=(await context()).claude.channelSelection;
  await save();
}

export async function driveOwnedChannelRefusal({page,expect,context,composer,send,section,replace,proof,output,debug,receipts,model,birth,save,phase}) {
  proof.scope='Original native eligibility refusal of a selected legacy channel alongside an ordinary MCP call.';
  await expect(composer).toHaveText(proof.draft);
  await expect.poll(async()=> (await context()).claude.nativeLaunch?.channels).toEqual([SELECTOR]);
  proof.channelLaunch=(await context()).claude.nativeLaunch.channels;
  const args=(await readFile('/proc/'+proof.pid+'/cmdline','utf8')).split('\0');
  const channelArg=args.indexOf('--channels');
  assert.ok(channelArg>0&&args[channelArg+1]===SELECTOR);
  assert.ok(!args.includes('--dangerously-load-development-channels'));
  proof.nativeArgvChannel=args.slice(channelArg,channelArg+2);

  const diagnostics=async()=> (await readFile(debug,'utf8')).split('\n').filter(line=>line.includes('Channel notifications skipped'));
  const refusal='MCP server "research": Channel notifications skipped: channels feature is not currently available';
  await expect.poll(async()=> (await diagnostics()).some(line=>line.endsWith(refusal)),{timeout:15000}).toBe(true);
  proof.channelDiagnostics=await diagnostics();

  await replace(channelPrompt);
  await send.click();
  const approval=page.getByRole('region',{name:TOOL+' approval',exact:true});
  await approval.getByRole('button',{name:'Yes',exact:true}).click();
  const result=()=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>
    Array.isArray(message.content)?message.content:[]).find(block=>
      block.type==='tool_result'&&block.tool_use_id==='toolu_research_fixture'&&JSON.stringify(block.content).includes('Owned echo finished.'));
  await expect.poll(()=>!!result(),{timeout:20000}).toBe(true);
  await expect.poll(async()=> (await context()).claude.chatState).toBe('success');
  const wire=(await readFile(receipts,'utf8')).trim().split('\n').map(JSON.parse);
  assert.equal(wire.filter(frame=>frame.direction==='in'&&frame.value.method==='tools/call').length,1);
  assert.equal(wire.filter(frame=>frame.direction==='out'&&frame.value.method==='notifications/claude/channel').length,1);
  assert.ok(!JSON.stringify(model.calls).includes(NOTIFICATION));
  proof.final=await context();
  assert.equal(proof.initial.threadId,proof.final.threadId);
  assert.equal(proof.sessionId,proof.final.claude.sessionId);
  assert.equal(proof.pid,proof.final.native.state.nativePid);
  assert.ok(!JSON.stringify(proof.final.messages).includes(NOTIFICATION));
  assert.equal(await birth(proof.pid),proof.processStart);
  const name='native-channel-refusal-composer-compact.png';
  await page.screenshot({path:join(output,name),animations:'disabled'});
  proof.captures.push(name);
  await save();
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
  proof.status='complete';
  await save();
  phase('native-channel-refusal-complete');
}
