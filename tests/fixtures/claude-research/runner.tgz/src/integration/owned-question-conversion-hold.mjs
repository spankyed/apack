import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { lstatSync, writeFileSync } from 'node:fs';
import promises from 'node:fs/promises';
import { syncBuiltinESMExports } from 'node:module';
import { join } from 'node:path';

const directory = process.env.CLAUDE_RESEARCH_QUESTION_CONVERSION_HOLD;
const originalWrite = promises.writeFile;
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const line = 'const blocks=await Promise.all(images.map(image=>n.questionImage.jS({...image,limits})));';

if (directory && !process.versions.bun && typeof process.env.API_PORT === 'string') {
  assert.match(directory, /^\/work\/\.claude-research\/apack-terminal-owner-app-question[0-9]+\/conversion-hold$/);
  const owner = lstatSync(directory);
  assert.ok(owner.isDirectory() && owner.uid === process.getuid() && (owner.mode & 0o077) === 0);
  writeFileSync(join(directory, 'api.json'), JSON.stringify({ pid: process.pid, at: Date.now() }), { mode: 0o600, flag: 'wx' });
  promises.writeFile = async function (file, data, ...options) {
    // Instrument only the generated parent adapter in this disposable Linux profile.
    if (typeof file !== 'string' || !/^\/tmp\/cc-app-[A-Za-z0-9]+\/ui\.mjs$/.test(file)) {
      return Reflect.apply(originalWrite, this, [file, data, ...options]);
    }
    assert.equal(typeof data, 'string');
    assert.equal(data.split(line).length, 2);
    const held = `import { existsSync as fixtureExists, writeFileSync as fixtureWrite } from 'node:fs';
async function holdOriginalQuestionConversion(blocks, images) {
 const directory = ${JSON.stringify(directory)};
 if (!fixtureExists(directory + '/arm') || fixtureExists(directory + '/held.json')) return blocks;
 fixtureWrite(directory + '/held.json', JSON.stringify({
   pid: process.pid, at: Date.now(),
   inputs: images.map(image => createHash('sha256').update(image.data).digest('hex')),
   outputs: blocks.map(image => image.block?.type ?? null),
 }), { mode: 0o600, flag: 'wx' });
 // Keep the real decoder output pending until Cancel retires the process. Bound a failure.
 await new Promise(resolve => setTimeout(resolve, 10000));
 fixtureWrite(directory + '/escaped.json', JSON.stringify({ pid: process.pid, at: Date.now() }), { mode: 0o600, flag: 'wx' });
 return blocks;
}
` + data.replace(line, line + '\n await holdOriginalQuestionConversion(blocks,images);');
    await Reflect.apply(originalWrite, this, [file, held, ...options]);
    writeFileSync(join(directory, 'injected.jsonl'), JSON.stringify({
      file, originalSha256: digest(data), instrumentedSha256: digest(held),
    }) + '\n', { mode: 0o600, flag: 'a' });
  };
  syncBuiltinESMExports();
}
