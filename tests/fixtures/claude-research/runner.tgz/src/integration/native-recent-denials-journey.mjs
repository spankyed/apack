import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';

async function chooseOriginalPermissionMode(page, expect, sameOwner, label, mode) {
 const popup=page.getByRole('dialog').filter({has:page.getByRole('button',{name:'Ask',exact:true})}),openDetails=page.getByRole('button',{name:'Open Claude session details',exact:true}),closeDetails=page.getByRole('button',{name:'Close Claude session details',exact:true});
  if(!await page.getByRole('button',{name:/^Permissions:/}).isVisible()){
   if(await openDetails.isVisible())await openDetails.click({timeout:10000});
   const details=page.locator('summary').filter({hasText:'Details'}).first();
   if(!await page.getByRole('button',{name:/^Permissions:/}).isVisible())await details.click({timeout:10000});
  }
  if(!await popup.isVisible())await page.getByRole('button',{name:/^Permissions:/}).click({timeout:10000});
  await popup.getByRole('button',{name:label,exact:true}).click({timeout:10000});
  await expect.poll(async()=>{const c=await sameOwner();return[c.claude.permissionMode,c.native.state.session.permissionMode]},{timeout:15000}).toEqual([mode,mode]);
  await page.keyboard.press('Escape');if(await closeDetails.isVisible())await closeDetails.click({timeout:10000});
}

/** Original classifier history and decisions through the real app, never private provider writes. */
export async function driveRecentDenialsJourney({page,panel,expect,context,composer,send,replace,proof,workspace,model,sameOwner,capture,save}) {
 const recent=proof.recentDenials={humans:[],modes:[]};await save();
 const choose=async(label,mode)=>{
  await chooseOriginalPermissionMode(page,expect,sameOwner,label,mode);
  recent.modes.push({label,mode});await save();
 };
 const result=id=>model.calls.flatMap(c=>c.messages??[]).flatMap(m=>Array.isArray(m.content)?m.content:[]).find(b=>b.type==='tool_result'&&b.tool_use_id===id);
 const file=async leaf=>{try{return await readFile(join(workspace,'native-recent-'+leaf+'.txt'),'utf8')}catch(error){if(error.code==='ENOENT')return null;throw error}};
 const state=async()=>{const c=await sameOwner(),panels=Object.values(c.ui).map(v=>v.state?.agentInput?.settings?.snapshot?.permissions).filter(p=>p?.tabs?.some(t=>t.selected&&t.label==='Recently denied'));assert.equal(panels.length,1);return panels[0]};
 const row=key=>panel.locator('[data-native-permission-choice="'+key+'"]');
 const open=async()=>{recent.humans.push('/permissions');await replace('/permissions');await send.click();await expect(panel).toBeVisible({timeout:15000});await panel.getByRole('tab',{name:'Recently denied',exact:true}).click();await expect(panel.getByRole('tab',{name:'Recently denied',exact:true})).toHaveAttribute('aria-selected','true')};
 await choose('Auto','auto');recent.admittedMode=await sameOwner();
 for(const marker of ['Alpha','Beta']){
  const text='ResearchRecentDenied'+marker+' Review this owned local marker command.';recent.humans.push(text);await replace(text);await send.click();const id='native_recent_denied_'+marker.toLowerCase();
  await expect.poll(()=>result(id),{timeout:20000}).toBeTruthy();assert.equal(result(id).is_error,true);
  await expect.poll(async()=>(await sameOwner()).native.state.busy,{timeout:15000}).toBe(false);assert.equal(await file(marker.toLowerCase()),null);
  recent[marker.toLowerCase()+'Result']=result(id);await save();
 }
 await open();await expect.poll(async()=>(await state()).choices.length).toBe(2);recent.populated=await state();
 const alpha=recent.populated.choices.find(c=>c.label.includes('native-recent-alpha.txt')),beta=recent.populated.choices.find(c=>c.label.includes('native-recent-beta.txt'));assert.ok(alpha&&beta&&alpha.value!==beta.value);recent.keys={alpha:alpha.value,beta:beta.value};assert.equal(alpha.approved,false);assert.equal(beta.approved,false);
 await capture('recent-populated-beta',[row(beta.value)]);await capture('recent-populated-alpha',[row(alpha.value)]);
 await row(alpha.value).click();await expect.poll(async()=>(await state()).decisions).toEqual({approved:1,retry:0});
 const retryBeta=()=>panel.getByRole('button',{name:'Approve and retry '+(recent.populated.choices.find(c=>c.value===beta.value).label),exact:true});
 await retryBeta().click();await expect.poll(async()=>(await state()).choices.find(c=>c.value===beta.value)?.retryScheduled).toBe(true);
 await capture('recent-scheduled',[row(beta.value),panel.getByRole('button',{name:/^Cancel retry for /}),panel.getByRole('button',{name:'Apply and close',exact:true})]);
 await panel.getByRole('button',{name:/^Cancel retry for /}).click();await expect.poll(async()=>(await state()).decisions).toEqual({approved:2,retry:0});recent.cancelRetry=await state();
 await row(beta.value).click();await expect.poll(async()=>(await state()).decisions).toEqual({approved:1,retry:0});
 await panel.getByRole('tab',{name:'Ask',exact:true}).click();await expect(panel.getByRole('tab',{name:'Ask',exact:true})).toHaveAttribute('aria-selected','true');await expect(panel.getByRole('button',{name:'Apply and close',exact:true})).toBeVisible();recent.awayDecision=await context();await panel.getByRole('tab',{name:'Recently denied',exact:true}).click();await expect(panel.getByRole('tab',{name:'Recently denied',exact:true})).toHaveAttribute('aria-selected','true');
 // The original rl tab body unmounts Kr. Re-entering initializes fresh native selection sets.
 await expect.poll(async()=>(await state()).decisions).toEqual({approved:0,retry:0});recent.returnReset=await state();assert.ok(recent.returnReset.choices.every(c=>!c.approved&&!c.retryScheduled));await capture('recent-reset',[row(alpha.value),panel.getByRole('button',{name:'Close permissions',exact:true})]);
 await row(alpha.value).click();await expect.poll(async()=>(await state()).decisions).toEqual({approved:1,retry:0});recent.beforeApprovalClose=await state();await capture('recent-approval',[row(alpha.value),panel.getByRole('button',{name:'Apply and close',exact:true})]);
 await panel.getByRole('tab',{name:'Ask',exact:true}).click();await expect(panel.getByRole('tab',{name:'Ask',exact:true})).toHaveAttribute('aria-selected','true');recent.approvalCloseTab='Ask';await panel.getByRole('button',{name:'Apply and close',exact:true}).click();await expect(panel).toBeHidden();recent.afterApprovalFiles={alpha:await file('alpha'),beta:await file('beta')};assert.deepEqual(recent.afterApprovalFiles,{alpha:null,beta:null});
 await open();await expect.poll(async()=>(await state()).choices.length).toBe(1);recent.afterApproval=await state();assert.ok(recent.afterApproval.choices[0].label.includes('native-recent-beta.txt'));
 const remaining=recent.afterApproval.choices[0];await panel.getByRole('button',{name:'Approve and retry '+remaining.label,exact:true}).click();await expect.poll(async()=>(await state()).decisions).toEqual({approved:1,retry:1});recent.beforeRetryClose=await state();
 await capture('recent-retry',[row(remaining.value),panel.getByRole('button',{name:'Apply and close',exact:true})]);
 await panel.getByRole('button',{name:'Apply and close',exact:true}).click();await expect(panel).toBeHidden();
 await expect.poll(()=>result('native_recent_retry_beta'),{timeout:20000}).toBeTruthy();assert.notEqual(result('native_recent_retry_beta').is_error,true);
 await expect.poll(async()=>(await sameOwner()).native.state.busy,{timeout:15000}).toBe(false);recent.retryResult=result('native_recent_retry_beta');recent.afterRetryFiles={alpha:await file('alpha'),beta:await file('beta')};assert.deepEqual(recent.afterRetryFiles,{alpha:null,beta:'NATIVE_RECENT_BETA'});
 await choose('Ask','default');recent.beforeFollowupTurns=(await sameOwner()).claude.turns;recent.status='complete';await save();
}

/** Observe a first-attempt native Auto verdict without an existing approval or a retry. */
export async function driveDirectAutoVerdict({ page, expect, context, composer, send, section, replace, proof,
  project, output, model, birth, save, phase }) {
  const own = async () => {
    const state = await context();
    assert.equal(state.claude.sessionId, proof.sessionId);
    assert.equal(state.native.state.nativePid, proof.pid);
    assert.equal(state.native.state.session.cwd, project);
    assert.equal(await birth(proof.pid), proof.processStart);
    return state;
  };
  const draft = 'Keep these notes while Claude reviews the release.';
  const prompt = 'ResearchAutoReviewedGamma Review and write the owned release marker.';
  const file = join(project, 'native-recent-gamma.txt');
  const result = () => model.calls.flatMap(call => call.messages ?? [])
    .flatMap(message => Array.isArray(message.content) ? message.content : [])
    .find(block => block.type === 'tool_result' && block.tool_use_id === 'native_auto_reviewed_gamma');
  proof.scope = 'First-attempt native Auto approval of a harmless owned command from an original requested loopback verdict. No user grant, retry, managed or external-provider claim.';
  proof.directAuto = { prompt, modes: [] };
  await chooseOriginalPermissionMode(page, expect, own, 'Auto', 'auto');
  proof.directAuto.modes.push('auto');
  await assert.rejects(readFile(file), { code: 'ENOENT' });
  await replace(prompt);
  await send.click();
  await expect.poll(result, { timeout: 20_000 }).toBeTruthy();
  assert.notEqual(result().is_error, true);
  await expect.poll(async () => (await own()).native.state.busy, { timeout: 15_000 }).toBe(false);
  const calls = model.calls.filter(call => call.recentDenial?.toolUseId === 'native_auto_reviewed_gamma' && call.recentDenial.useTool);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].recentDenial.classifierRequested, true);
  assert.equal(calls[0].recentDenial.retry, false);
  assert.ok(!model.calls.some(call => JSON.stringify(call.messages ?? []).includes('Permission granted for:')));
  proof.directAuto.file = await readFile(file, 'utf8');
  assert.equal(proof.directAuto.file, 'NATIVE_RECENT_GAMMA');
  proof.directAuto.result = result();
  await composer.fill(draft);
  for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
    await page.setViewportSize(viewport);
    await expect(composer).toHaveText(draft);
    await expect(composer).toBeInViewport();
    await expect(send).toBeInViewport();
    const capture = 'native-auto-direct-' + size + '.png';
    await page.screenshot({ path: join(output, capture), animations: 'disabled' });
    proof.captures.push(capture);
  }
  await chooseOriginalPermissionMode(page, expect, own, 'Ask', 'default');
  proof.directAuto.modes.push('default');
  await expect(composer).toHaveText(draft);
  proof.followup = 'Continue the release summary with Ask restored.';
  await replace(proof.followup);
  await send.click();
  await expect.poll(async () => {
    const current = await own();
    return current.claude.chatState === 'success' && !current.native.state.busy
      && current.messages.filter(message => message.sender === 'user' && message.text === proof.followup).length === 1;
  }, { timeout: 20_000 }).toBe(true);
  proof.final = await own();
  await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
  await section.getByRole('button', { name: 'Stop session', exact: true }).click();
  await expect.poll(() => birth(proof.pid), { timeout: 15_000 }).toBe(null);
  proof.stopped = true;
  proof.status = 'complete';
  await save();
  phase('native-auto-direct-verdict-complete');
}
