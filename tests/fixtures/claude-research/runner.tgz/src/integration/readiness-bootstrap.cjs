const { readFileSync } = require('node:fs');
const { pathToFileURL } = require('node:url');

const boundary = JSON.parse(readFileSync('/control/offline-verified', 'utf8'));
if (!boundary.moduleReadiness || !boundary.networkDisabled || !boundary.profileTmpfs)
  throw Error('Readiness observer requires an isolated desktop run');
process.env.NODE_OPTIONS = (process.env.CLAUDE_RESEARCH_API_NODE_OPTIONS ?? '') +
  ' --import=' + pathToFileURL(require.resolve('./observe-module-readiness.cjs')).href;
