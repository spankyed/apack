import assert from 'node:assert/strict';
import {mkdir,realpath} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const[checkout,executable,workspace]=process.argv.slice(2);
assert.notEqual(await realpath(checkout),await realpath('/Users/spankyed/Develop/Projects/AgentBuddy'));assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const{query}=await import(pathToFileURL(join(base,'query.ts'))),{createClaudeConversation}=await import(pathToFileURL(join(base,'conversation.ts')));
const cases=[];
for(const kind of ['query','owner']){
 const cwd=join(workspace,kind),home=join(cwd,'home');await mkdir(join(home,'.claude'),{recursive:true});
 const model=await startSyntheticModel(cwd,'Refusal');let native,owner;const events=[];let resultError;
 try{
  native=await query({cliPath:executable,cwd,env:{HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url},tools:[],strictMcpConfig:true,settingSources:[],settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',switchModelsOnFlag:false}),noSessionPersistence:true,model:'claude-opus-4-8',maxTurns:1,replayUserMessages:true,keepStdinOpen:true,signal:AbortSignal.timeout(15000)});
  await native.initialized;
  const resultOutcome=native.result.then(()=>null,error=>error);
  if(kind==='query'){
   const drained=(async()=>{try{for await(const event of native.events)events.push(event);}catch{}})();
   native.send('Return the fixed local refusal fixture.');await drained;resultError=await resultOutcome;
  }else{
   const consume=async turn=>{const outcome=turn.handle.result.then(()=>null,error=>error);try{for await(const event of turn.handle.events)events.push(event);}finally{resultError=await outcome;owner.release(turn.handle);}};
   owner=createClaudeConversation(native,consume);owner.start('Return the fixed local refusal fixture.',consume);await owner.done.catch(()=>{});assert.equal(owner.busy,false);
  }
  assert.equal(resultError?.name,'ClaudeResultError');assert.equal(resultError?.subtype,'success');assert.match(resultError?.message??'',/API Error:/);
  const raw=events.findLast(value=>value.type==='result');assert.equal(raw?.subtype,'success');assert.equal(raw?.is_error,true);assert.equal(raw?.terminal_reason,'api_error');assert.equal(raw?.safety_stops,2);assert.ok(raw.total_cost_usd>0);assert.equal(model.calls.length,2);
  cases.push({kind,resultRejected:true,errorType:resultError.name,errorSubtype:resultError.subtype,refusalDetailRetained:true,rawResultRetained:true,costRetained:true,terminal:{subtype:raw.subtype,is_error:raw.is_error,terminal_reason:raw.terminal_reason,safety_stops:raw.safety_stops},localModelRequests:model.calls.length});
 }finally{owner?.kill();native?.kill();await native?.close().catch(()=>{});await model.close();}
}
console.log(JSON.stringify({evidence:'native-refusal-result',cases,realModelRequests:0}));
