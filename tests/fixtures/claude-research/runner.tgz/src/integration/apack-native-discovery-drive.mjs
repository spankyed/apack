import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {prepareClientRichThemeProfile} from './client-rich-theme-profile.mjs';
import {prepareNativeUiDiscoveryFault} from './native-ui-discovery-fault.mjs';

export async function driveNativeDiscoveryRecovery(options){
 const profile=await prepareClientRichThemeProfile(options);
 try{await driveChildComposer({...options,modelRequestLimit:10,journey:discoveryJourney,journeyName:'native-discovery-recovery'});}
 finally{await profile.restore();}
}
async function discoveryJourney({page,electronApp,output,project,userDataDir,expect,phase,model}){
 const proof={status:'running',captures:[],seed:'Help me inspect a release draft.',draft:'Keep my release notes while reconnecting controls.',finalText:'Continue after reconnecting the release controls.'};
 const save=()=>writeFile(join(output,'native-discovery-recovery.json'),JSON.stringify(proof,null,2));
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:Object.values(c.nativeUiViews).find(v=>v.threadId===c.currentThread?.id)};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 const start=async pid=>(await readFile('/proc/'+pid+'/stat','utf8')).split(') ').at(-1).split(' ')[19];
 const fault=await prepareNativeUiDiscoveryFault({output});
 const capture=async stage=>{
  for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(viewport);await expect(composer).toHaveText(proof.draft);await expect(composer).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});
   if(stage==='unavailable')await expect(card.getByRole('button',{name:'Reconnect controls',exact:true})).toBeInViewport({ratio:1});
   else{await expect(send).toBeEnabled();const action=card.getByRole('button',{name:'Save review',exact:true});await action.scrollIntoViewIfNeeded();await expect(action).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});}
   const file='native-discovery-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);await save();
  }
 };
 try{
  await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads')?.getSnapshot().context.modes.some(m=>m.name==='Claude Code')??false),{timeout:15000}).toBe(true);
  await page.evaluate(project=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'VIEW_DASHBOARD'});a.send({type:'NEW_THREAD_IN_PROJECT',directory:project});},project);
  await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.pendingThreadCwd)).toBe(project);
  await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
  await composer.fill(proof.seed);await send.click();
  await expect.poll(async()=>{const c=await context();return c.claude?.turns===1&&c.claude?.isRunning===false&&c.messages.some(m=>m.sender==='assistant'&&m.text?.trim()==='The release review outline is ready.');},{timeout:120000}).toBe(true);
  await composer.fill(proof.draft);await composer.press('Home');for(let n=0;n<5;n++)await composer.press('ArrowRight');for(let n=0;n<12;n++)await composer.press('Shift+ArrowRight');
  const selection=()=>composer.evaluate(el=>{const s=getSelection();return s?.rangeCount&&el.contains(s.anchorNode)&&el.contains(s.focusNode)?[s.anchorOffset,s.focusOffset]:null;});
  proof.selectionBefore=await selection();assert.deepEqual(proof.selectionBefore,[5,17]);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
  proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.nativePid=proof.initial.native.state.nativePid;proof.processStart=await start(proof.nativePid);
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toBe('error');
  proof.failed=await context();assert.match(proof.failed.ui.state.message,/Owned acceptance fixture withheld/);proof.faultBefore=await fault.inspect();assert.equal(proof.faultBefore.failed,true);await save();await capture('unavailable');
  await composer.focus();proof.selectionAfterFailure=await selection();assert.deepEqual(proof.selectionAfterFailure,proof.selectionBefore);
  await card.getByRole('button',{name:'Reconnect controls',exact:true}).click();
  await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toBe('live');
  const action=card.getByRole('button',{name:'Save review',exact:true});if(!await action.isVisible())await card.getByRole('button',{name:'Session tools',exact:true}).click();await expect(action).toBeVisible();
  proof.reconnected=await context();assert.notEqual(proof.reconnected.ui.attachmentId,proof.failed.ui.attachmentId);assert.deepEqual(proof.reconnected.messages,proof.initial.messages);assert.equal(proof.reconnected.native.state.nativePid,proof.nativePid);assert.equal(proof.reconnected.native.state.ownerId,proof.initial.native.state.ownerId);assert.equal(await start(proof.nativePid),proof.processStart);
  await composer.focus();proof.selectionAfterReconnect=await selection();assert.deepEqual(proof.selectionAfterReconnect,proof.selectionBefore);await capture('reconnected');
  await action.click();await expect.poll(async()=>{try{return JSON.parse(await readFile(join(project,'native-client-rich-theme-receipts.json'),'utf8')).filter(r=>r.operation==='save').length;}catch(e){if(e.code==='ENOENT')return 0;throw e;}}).toBe(1);
  proof.receipts=JSON.parse(await readFile(join(project,'native-client-rich-theme-receipts.json'),'utf8'));assert.equal(proof.receipts.filter(r=>r.operation==='save')[0].saves,1);
  proof.beforeSend=await context();assert.deepEqual(proof.beforeSend.messages,proof.initial.messages);assert.equal(model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length,1);
  await composer.click();await composer.press('ControlOrMeta+a');await composer.pressSequentially(proof.finalText);await send.click();
  await expect.poll(async()=>{const c=await context();return c.native.state.busy===false&&c.messages.filter(m=>m.sender==='user').at(-1)?.text===proof.finalText;},{timeout:15000}).toBe(true);
  await composer.fill(proof.draft);proof.final=await context();assert.equal(proof.final.claude.sessionId,proof.sessionId);assert.equal(proof.final.native.state.nativePid,proof.nativePid);assert.equal(await start(proof.nativePid),proof.processStart);await capture('continued');
  proof.faultFinal=await fault.inspect();assert.equal(proof.faultFinal.rows.filter(r=>r.outcome==='one-native-success-reply-withheld').length,1);assert.ok(proof.faultFinal.rows.some(r=>r.outcome==='forwarded-fresh-native-discovery'));
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(async()=>{try{return(await readFile('/proc/'+proof.nativePid+'/stat','utf8')).split(') ').at(-1).split(' ')[0]==='Z'||await start(proof.nativePid)!==proof.processStart;}catch(e){if(e.code==='ENOENT')return true;throw e;}},{timeout:15000}).toBe(true);proof.nativeWriterRetired=true;
  const root=join(userDataDir,'claude-code-profile/config/projects'),names=await readdir(root,{recursive:true});assert.ok(names.length<=20000);const name=names.find(p=>basename(p)===proof.sessionId+'.jsonl');assert.ok(name);const bytes=await readFile(join(root,name));assert.ok(bytes.length<=8388608);await writeFile(join(output,'native-transcript.jsonl'),bytes);proof.persistedCost=bytes.toString().split('\n').filter(Boolean).map(JSON.parse).filter(r=>r.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(proof.persistedCost,proof.final.claude.totalCostUsd);
  proof.status='complete';phase('native-discovery-recovery-complete');
 }finally{
  if(proof.status!=='complete'){proof.status='failed';proof.failureContext=await context().catch(()=>null);await page.screenshot({path:join(output,'native-discovery-failure.png')}).catch(()=>{});}
  await fault.close();await save();
 }
}
