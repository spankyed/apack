import assert from 'node:assert/strict';
import {open,readFile,readdir,lstat,writeFile,readlink} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import {connect} from 'node:net';

async function birth(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]==='Z'?null:fields[19]}catch(error){if(error.code==='ENOENT')return null;throw error}}

/** A logged PID is insufficient authority to signal a process after its parent exits. */
export function matchesNativeSpareHost(value,{profileDir,start,parentPid}){
 return !!value&&value.start===start&&value.uid===1000&&value.executable==='/frozen-claude/claude'
  &&value.profileDir===profileDir&&Array.isArray(value.argv)&&value.argv.includes('--bg-pty-host')
  &&(parentPid===undefined||value.parentPid===parentPid)
}
async function spareHostIdentity(pid){
 try{
  const start=await birth(pid);if(start===null)return null;
  const [stat,executable,argv,environment,raw]=await Promise.all([lstat('/proc/'+pid),readlink('/proc/'+pid+'/exe'),readFile('/proc/'+pid+'/cmdline','utf8'),readFile('/proc/'+pid+'/environ','utf8'),readFile('/proc/'+pid+'/stat','utf8')]);
  if(await birth(pid)!==start)return null;
  const fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');
  return {start,uid:stat.uid,executable,argv:argv.split('\0').filter(Boolean),profileDir:environment.split('\0').find(entry=>entry.startsWith('CLAUDE_CONFIG_DIR='))?.slice('CLAUDE_CONFIG_DIR='.length),parentPid:Number(fields[1])};
 }catch(error){if(['ENOENT','ESRCH'].includes(error.code))return null;throw error}
}

/** The original control server accepts a same-user lease independently of dispatch/claim authority.
 * chunk-fb57bfcx.js/Mn: lease -> addLease; chunk-r7n83d94.js: first lease permits spare refill.
 */
function openPreparationLease(path,project,timeoutMs){return new Promise((resolve,reject)=>{
 const socket=connect(path);let settled=false,bytes=Buffer.alloc(0);
 const fail=error=>{if(settled)return;settled=true;clearTimeout(timer);socket.destroy();reject(error)};
 const timer=setTimeout(()=>fail(Error('Native preparation lease acknowledgement timed out')),timeoutMs);
 socket.on('error',fail);socket.once('close',()=>fail(Error('Native preparation lease closed before acknowledgement')));
 socket.once('connect',()=>socket.write(JSON.stringify({op:'lease',client:{label:'claude-research-warm-spare',pid:process.pid,cwd:project}})+'\n'));
 socket.on('data',chunk=>{
  if(settled)return;bytes=Buffer.concat([bytes,chunk]);if(bytes.length>4096)return fail(Error('Native preparation lease reply exceeds bound'));
  const end=bytes.indexOf(10);if(end<0)return;
  try{const reply=JSON.parse(bytes.subarray(0,end));assert.deepEqual(reply,{ok:true,op:'lease'});settled=true;clearTimeout(timer);resolve(socket)}catch(error){fail(error)}
 });
})}

/** Prepare an original spare without connecting to or rewriting its authenticated claim protocol.
 * Pinned Linux source: daemonMain/run in chunk-r7n83d94.js; Iie/Zxs in chunk-3a3k912g.js.
 * This fixture covers a prewarmed disposable app-owned or external profile, not general cold startup.
 */
export async function prepareNativeWarmSpare({workspace,profileDir,project,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+$/);
 assert.ok([join(workspace,'app-data/claude-code-profile/config'),join(workspace,'.claude')].includes(profileDir),'Warm preparation requires this run’s disposable profile');
 assert.equal(env.CLAUDE_CONFIG_DIR,profileDir);
 const daemonRoot=join('/tmp','cc-daemon-'+process.getuid(),createHash('sha256').update(resolve(profileDir)).digest('hex').slice(0,8)),socketRoot=join(daemonRoot,'spare');
 const log=await open(join(workspace,'warm-daemon-output.log'),'wx',0o600);
 let child,closed,ended=false,exit,error;
 try{
  child=spawn('/frozen-claude/claude',['daemon','run','--origin','foreground'],{cwd:project,env,stdio:['ignore',log.fd,log.fd]});
  closed=new Promise(resolve=>{child.once('error',value=>{error=value;ended=true;resolve()});child.once('close',(code,signal)=>{exit={code,signal};ended=true;resolve()})});
 }finally{await log.close()}
 const receipt={scope:'Original foreground daemon and explicit same-user preparation lease for a real app warm claim; no claim socket connection or injected dispatch/claim.',pid:child.pid,readySockets:[],claim:null,leaseAcknowledged:false,leaseReleasedAfterClaim:false};
 let lease,stopping;
 const save=()=>writeFile(join(workspace,'native-warm-spare.json'),JSON.stringify(receipt,null,2),{mode:0o600});
 const stop=()=>stopping??=(async()=>{
  let timer;
  try{
   let nativeLog='';try{nativeLog=await readFile(join(profileDir,'daemon.log'),'utf8')}catch(error){if(error.code!=='ENOENT')throw error}
   const pids=[...new Set([...nativeLog.matchAll(/bg spare spawned host pid=([0-9]+)/g)].map(match=>Number(match[1])))];
   assert.ok(pids.length<=64&&pids.every(pid=>Number.isSafeInteger(pid)&&pid>1));
   // Capture birth and parent authority while the owned daemon still exists. After shutdown a
   // spare may be reparented; only that captured incarnation can receive our cleanup signal.
   receipt.spareHosts=await Promise.all(pids.map(async pid=>{
    const identity=await spareHostIdentity(pid),start=identity?.start??null;
    const owned=identity!==null&&matchesNativeSpareHost(identity,{profileDir,start,parentPid:child.pid});
    return {pid,start,owned};
   }));
   lease?.destroy();if(!ended)child.kill('SIGTERM');
   await Promise.race([closed,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Owned warm daemon did not exit after SIGTERM')),10000)})]);clearTimeout(timer);
   const signalOwnedSpare=async(host,signal)=>{
    if(host.start===null||await birth(host.pid)!==host.start)return;
    assert.ok(host.owned,'Refusing cleanup signal without pre-shutdown native spare ownership');
    const current=await spareHostIdentity(host.pid);
    if(current===null||current.start!==host.start)return;
    assert.ok(matchesNativeSpareHost(current,{profileDir,start:host.start}),'Refusing cleanup signal after native spare identity changed');
    if(await birth(host.pid)!==host.start)return;
    try{
     process.kill(host.pid,signal);
     (host.cleanupSignals??=[]).push({signal,at:Date.now()});
    }catch(error){if(error.code!=='ESRCH')throw error}
   };
   const awaitRetirement=async(maxAttempts)=>{
    for(let attempt=0;attempt<maxAttempts;attempt++){
     for(const host of receipt.spareHosts)host.retired=host.start===null||await birth(host.pid)!==host.start;
     receipt.spareHostsRetired=receipt.spareHosts.every(host=>host.retired);
     if(receipt.spareHostsRetired)return;
     await new Promise(resolve=>setTimeout(resolve,50));
    }
   };
   for(const host of receipt.spareHosts)await signalOwnedSpare(host,'SIGTERM');
   await awaitRetirement(100);
   if(!receipt.spareHostsRetired){
    for(const host of receipt.spareHosts){
     if(host.retired)continue;
     assert.equal(host.cleanupSignals?.[0]?.signal,'SIGTERM','Escalation requires a verified graceful stop attempt');
     await signalOwnedSpare(host,'SIGKILL');
    }
    await awaitRetirement(50);
   }
   assert.ok(receipt.spareHostsRetired,'Original spare hosts must retire before profile restoration');
  }finally{clearTimeout(timer);lease?.destroy();if(!ended)child.kill('SIGTERM');receipt.exit=exit;receipt.error=error?.message;await save()}
 })();
 try{
  const deadline=Date.now()+10000;
  while(Date.now()<deadline){
   if(ended)throw error??Error('Original warm daemon exited before spare readiness: '+JSON.stringify(exit));
   if(!lease){
    try{lease=await openPreparationLease(join(daemonRoot,'control.sock'),project,Math.min(2000,Math.max(1,deadline-Date.now())));receipt.leaseAcknowledged=true}
    catch(error){if(!['ENOENT','ECONNREFUSED'].includes(error.code))throw error;await new Promise(resolve=>setTimeout(resolve,100));continue}
   }
   assert.ok(!lease.destroyed,'Native preparation lease must remain live until the app claim');
   let names;try{names=await readdir(socketRoot)}catch(error){if(error.code!=='ENOENT')throw error;names=[]}
   for(const name of names)if(/^[a-f0-9]{8}\.claim\.sock$/.test(name)){
    try{if((await lstat(join(socketRoot,name))).isSocket())receipt.readySockets.push(name)}catch(error){if(error.code!=='ENOENT')throw error}
   }
   if(receipt.readySockets.length){await save();return{receipt,stop,async requireClaim(worker){
     assert.match(worker.id,/^[a-f0-9]{8}$/);
     for(let attempt=0;attempt<100;attempt++){
      let nativeLog='';try{nativeLog=await readFile(join(profileDir,'daemon.log'),'utf8')}catch(error){if(error.code!=='ENOENT')throw error}
      if(nativeLog.includes('bg claimed-spare '+worker.id+' ')){receipt.claim={id:worker.id,pid:worker.pid,sessionId:worker.sessionId};lease.destroy();receipt.leaseReleasedAfterClaim=lease.destroyed;await save();return}
      await new Promise(resolve=>setTimeout(resolve,50));
     }
     assert.fail('App worker must be an original warm-spare claim');
    }}}
   await new Promise(resolve=>setTimeout(resolve,100));
  }
  throw Error('Original spare claim socket was not ready within the preparation budget');
 }catch(error){try{await stop()}catch(cleanup){throw new AggregateError([error,cleanup],'Warm preparation and owned daemon shutdown failed')}throw error}
}
