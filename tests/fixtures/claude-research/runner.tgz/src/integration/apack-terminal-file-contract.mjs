import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {setTimeout as delay} from 'node:timers/promises';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticFileModel} from '../protocol/synthetic-file-model.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {nativeDialogInspector} from '../protocol/native-dialog-inspector.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
const targetSha256=hash(await readFile(executable));assert.equal(targetSha256,'5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');assert.equal(process.env.HOME,workspace);
for(const name of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[name],undefined);
const root=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(root,'query.ts')).href),store=await import(pathToFileURL(join(root,'handle-store.ts')).href),{prepareClaudeNativeTerminal}=await import(pathToFileURL(join(root,'terminal-owner.ts')).href);
const fileStanding=process.env.CLAUDE_RESEARCH_FILE_STANDING==='1';
const configDir=join(workspace,'.claude');await mkdir(configDir,{recursive:true});
await writeFile(join(configDir,'settings.json'),JSON.stringify({permissions:{ask:fileStanding?[]:['Write','Edit']},apiKeyHelper:'/usr/bin/printf research-fixture-key',statusLine:{type:'command',command:'/usr/bin/printf NativeBashOwner',refreshInterval:1}}));
const fileChoices=fileStanding||process.env.CLAUDE_RESEARCH_FILE_CHOICES==='1';
const inspector=join(workspace,'bash-inspector.mjs'),reportPath=join(workspace,'native-dialog-shapes.json');await writeFile(inspector,nativeDialogInspector(reportPath,{fileChoices,maxSnapshotBytes:1000000})+`
const decisionPath=${JSON.stringify(join(workspace,'file-decision.json'))};
const decisionTimer=setInterval(async()=>{try{
 const {readFileSync,unlinkSync,writeFileSync}=await import('node:fs');
 let decision;try{decision=JSON.parse(readFileSync(decisionPath,'utf8'))}catch(error){if(error.code==='ENOENT')return;throw error}
 unlinkSync(decisionPath);
 const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),binding=runtime.ey(),store=binding.toolContext(new AbortController()).dialogStore;
 const open=store.getState().open;if(open.length!==1||open[0].id!==decision.id||open[0].kind!=='permission_file'||!['Write','Edit'].includes(open[0].payload.toolName))throw Error('Fixture dialog changed');
 const payload=open[0].payload;
 if(JSON.stringify(payload.input)!==JSON.stringify(decision.input))throw Error('Fixture input changed');
 if(!['allow','deny','cancelled'].includes(decision.behavior))throw Error('Unsupported fixture decision');
 store.answer(open[0].id,decision.behavior==='allow'?{behavior:'allow',updatedInput:payload.input}:{behavior:decision.behavior});
}catch(error){const {writeFileSync}=await import('node:fs');writeFileSync(${JSON.stringify(join(workspace,'file-decision-error.txt'))},String(error))}},100);decisionTimer.unref();
`);
const env={HOME:workspace,CLAUDE_CONFIG_DIR:configDir,BUN_OPTIONS:'--preload='+inspector,CLAUDE_CODE_SIMPLE:undefined,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
const seed=await startSyntheticModel(workspace,'TextOnly'),model=await startSyntheticFileModel(workspace);
let native,owner,seeded,terminal='',seen=0,timer,unsubscribe,theme=false,security=false,navigated=false,trusted=false,lastInput=0,trustRetries=0;
const waitFor=async(check,label,ms=20000)=>{const deadline=Date.now()+ms;while(Date.now()<deadline){if(await check())return;await delay(50)}throw Error(label)};
const report=async()=>{try{return JSON.parse(await readFile(reportPath,'utf8'))}catch(error){if(error.code!=='ENOENT')throw error;return{events:[]}}};
try{
 owner=await store.openConversation('bash-contract',JSON.stringify({cwd:workspace}),()=>query({cliPath:executable,cwd:workspace,permissionMode:'default',env:{...env,ANTHROPIC_BASE_URL:seed.url},tools:[],keepStdinOpen:true}),async turn=>{for await(const line of turn.handle.events){}seeded=await turn.handle.result;owner.release(turn.handle)});
 await owner.handle.initialized;owner.start('Seed native file contract.',async turn=>{for await(const line of turn.handle.events){}seeded=await turn.handle.result;owner.release(turn.handle)});await waitFor(()=>seeded&&!owner.busy,'Seed did not settle');
 const sessionId=owner.sessionId;native=await store.openNativeTerminal('bash-contract',{cliPath:executable,env:{...env,ANTHROPIC_BASE_URL:model.url}},prepareClaudeNativeTerminal);
 const observe=()=>{for(const chunk of native.output)if(chunk.sequence>seen){terminal+=chunk.text;seen=chunk.sequence;}if(native.state.status==='live'||Date.now()-lastInput<200)return;const screen=recognizeOnboardingPrompt(terminal,workspace);let input;if(screen==='theme'&&!theme){theme=true;input='\r'}else if(screen==='security-notes'&&theme&&!security){security=true;input='\r'}else if(screen==='workspace-trust'&&!navigated){navigated=true;input='\x1b[B'}else if((screen==='workspace-trust-selected'||screen==='workspace-trust')&&Date.now()-lastInput>1200&&navigated&&!trusted){trusted=true;input='\r'}if(input===undefined&&trusted&&trustRetries<3&&Date.now()-lastInput>1000){if(screen==='workspace-trust'){input='\x1b[B';navigated=true}else if(screen==='workspace-trust-selected'){input='\r';trustRetries++}}if(input!==undefined){lastInput=Date.now();native.input(native.state.ownerId,input)}};
 unsubscribe=native.subscribe(observe);timer=setInterval(observe,100);observe();await waitFor(()=>native.state.status==='live','Native file owner not ready');
 const decisions=[];
 if(fileStanding){
  const paths={1:'created\n',2:'overwrite\n',3:'edited\n'};
  let offered;
  for(const turn of [1,2,3]){
   await native.submit('ResearchFileTurn'+turn);
   if(turn===1){
    let descriptor;
    await waitFor(async()=>{descriptor=(await native.getFileDialogs())[0];return descriptor?.approval?.ready===true},'Natural Write approval not ready');
    offered=descriptor.approval.choices;
    const choice=offered.find(choice=>choice.value==='yes-session');assert.ok(choice,'Original session grant not offered');
    await native.answerFileDialog({id:descriptor.id,revision:descriptor.revision,sessionId:descriptor.sessionId,decision:choice.decision,choice:choice.value,choiceToken:descriptor.approval.token});
    await waitFor(async()=>(await native.uiTransport.request({subtype:'apack_get_permission_mode'})).mode==='acceptEdits','Original session mode not applied');
   }
   await waitFor(async()=>{try{return await readFile(join(workspace,'file-fixture.txt'),'utf8')===paths[turn]}catch(error){if(error.code==='ENOENT')return false;throw error}},'Remembered permission did not permit file operation '+turn);
   await waitFor(()=>!native.busy,'Remembered file operation did not settle');
   assert.equal((await native.getFileDialogs()).length,0);
  }
  const rows=(await report()).events.flatMap(event=>event.value?.open??[]).filter(item=>item.kind==='permission_file');
  assert.ok(rows.length>0&&rows.every(item=>item.payload.requestId==='file_fixture_1'),'A matching operation asked for permission again');
  await native.close();await writeFile(join(workspace,'native-file-standing-contract.json'),JSON.stringify({sessionId,offered,events:(await report()).events},null,2));
  console.log(JSON.stringify({evidence:'apack-native-terminal-file-contract',targetSha256,nativeFileStanding:true,nativeFileMatchingRepeat:true,nativeWriteCreate:true,nativeWriteOverwrite:true,nativeEdit:true,sameSession:true,ownedShutdown:true,syntheticApiRequests:seed.calls.length+model.calls.length,realModelRequests:0,scope:'Original native callback applies session mode and subsequent matching Write/Edit run without another dialog; no actual app acceptance'}));
 }else{
 for(const turn of [1,2,3,4,5,6,7]){
  await native.submit('ResearchFileTurn'+turn);
  let item;
  await waitFor(async()=>{item=(await report()).events.flatMap(event=>event.value?.open??[]).find(item=>item.kind==='permission_file'&&item.payload.requestId==='file_fixture_'+turn);return !!item},'Original file dialog missing for '+turn);
  if(fileChoices)await waitFor(async()=>(await report()).events.some(event=>event.type==='file-mounted-choices'&&event.value.some(row=>row.requestId===item.payload.requestId)),'Mounted native file controls missing for '+turn);
  const payload=item.payload;assert.equal(payload.operationType,'write');assert.equal(payload.filePath,join(workspace,'file-fixture.txt'));
  assert.equal(payload.toolName,[3,5,7].includes(turn)?'Edit':'Write');
  assert.equal(payload.content.kind,turn===6?'no-changes':[3,5,7].includes(turn)?'file-edit-diff':'file-write-diff');
  if(turn===1)assert.equal(payload.content.fileExists,false);
  if(turn===2){assert.equal(payload.content.fileExists,true);assert.equal(payload.content.oldContent,'created\n')}
  if(turn===3)assert.equal(payload.content.edits[0].old_string,'overwrite\n');
  const behavior=turn<=3?'allow':turn===7?'cancelled':'deny';
  if(fileChoices)await waitFor(async()=>(await native.getFileDialogs())[0]?.approval?.ready===true,'Native file answer readiness missing for '+turn);
  const descriptor=(await native.getFileDialogs())[0];assert.equal(descriptor.toolName,payload.toolName);assert.equal(descriptor.review.withheld,turn===6);if(turn===6){assert.match(descriptor.review.notice,/too large/);assert.equal(descriptor.review.after,undefined)}else assert.equal(descriptor.review.after,turn===1?'created\n':turn===2?'overwrite\n':turn===3?'edited\n':'Must not be applied\n');
  if(behavior==='cancelled')await writeFile(join(workspace,'file-decision.json'),JSON.stringify({id:item.id,input:payload.input,behavior}));
  else await native.answerFileDialog({id:descriptor.id,revision:descriptor.revision,sessionId:descriptor.sessionId,decision:behavior,...(fileChoices&&turn===4?{choice:'no',choiceToken:descriptor.approval.token,feedback:'Keep the existing file unchanged.'}:{})});
  await waitFor(async()=>(await report()).events.some(event=>event.type==='closed'&&event.value.id===item.id),'Native file decision did not close for '+turn);
  if(fileChoices&&turn===4)assert.equal((await report()).events.find(event=>event.type==='closed'&&event.value.id===item.id)?.value.result?.feedback,'Keep the existing file unchanged.');
  await waitFor(()=>!native.busy,'Native file decision did not settle for '+turn);
  const expected=turn===1?'created\n':turn===2?'overwrite\n':'edited\n';
  await waitFor(async()=>await readFile(join(workspace,'file-fixture.txt'),'utf8')===expected,'Unexpected file effect for '+turn);
  decisions.push({turn,behavior,item});
 }
 await native.close();
 await writeFile(join(workspace,'native-file-contract.json'),JSON.stringify({sessionId,decisions,closed:(await report()).events.filter(event=>event.type==='closed')},null,2));
 console.log(JSON.stringify({evidence:'apack-native-terminal-file-contract',targetSha256,nativeWriteCreate:true,nativeWriteOverwrite:true,nativeEdit:true,nativeWriteDeny:true,nativeEditDeny:true,nativeFileCancel:true,nativeFileWithholding:true,originalDialogCaptured:true,sameSession:native.state.sessionId===sessionId,ownedShutdown:true,syntheticApiRequests:seed.calls.length+model.calls.length,realModelRequests:0}));
}
}finally{clearInterval(timer);unsubscribe?.();store.killAllHandles();await native?.close();await writeFile(join(workspace,'native-file-terminal.txt'),terminal);await writeFile(join(workspace,'native-file-model-calls.json'),JSON.stringify(model.calls,null,2));await seed.close();await model.close();}
