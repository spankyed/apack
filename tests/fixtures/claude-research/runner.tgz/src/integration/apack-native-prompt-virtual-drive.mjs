import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { hash } from '../artifacts/runs.mjs';
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs';
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs';
import { virtualDraft, virtualHint, virtualHintHook, desktopVirtualFillHook, desktopVirtualFillSteps, desktopVirtualFillTrigger } from '../protocol/native-prompt-virtual-fixture.mjs';
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs';
import { record } from '../protocol/record.mjs';
import { startCombinedEverydayModel } from '../protocol/combined-everyday-model.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { readCombinedEverydayJournal } from './apack-combined-everyday-drive.mjs';
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs';
import { prepareFreshCombinedEverydayProfile } from './combined-everyday-profile.mjs';
import { processStart } from './native-process-state.mjs';

const executable = '/frozen-claude/claude';
const seed = 'Prepare a release note for review.';
const reply = 'The release checklist is ready.';
const agentSeed = 'Review the release notes with a worker.';
const parentDraft = 'Keep the release checklist wording unchanged.';
const journalRows = journal => journal.toString().split('\n').filter(Boolean).map(JSON.parse);

async function installFixture(workspace, project, config, env, source) {
  const market = basename(workspace), marketplace = join(workspace, 'marketplace');
  const pluginName = 'virtual-prompt-review', plugin = join(marketplace, 'plugins', pluginName);
  for (const directory of [join(marketplace, '.claude-plugin'), join(plugin, '.claude-plugin'), join(plugin, 'hooks')]) {
    await mkdir(directory, { recursive: true });
  }
  await writeFile(join(marketplace, '.claude-plugin/marketplace.json'), JSON.stringify({
    name: market, owner: { name: 'Local release review' }, plugins: [{ name: pluginName, source: './plugins/' + pluginName }],
  }));
  await writeFile(join(plugin, '.claude-plugin/plugin.json'), JSON.stringify({ name: pluginName, version: '0.0.1' }));
  await writeFile(join(plugin, 'hooks/hooks.json'), JSON.stringify({ modules: ['./register.ts'] }));
  await writeFile(join(plugin, 'hooks/register.ts'), source);
  const name = pluginName + '@' + market;
  for (const args of [['validate', plugin], ['marketplace', 'add', marketplace], ['install', name]]) {
    const run = await record({ executable, cwd: project, env, output: join(workspace, 'installation'),
      args: ['--setting-sources', '', 'plugin', ...args], timeoutMs: 15000, maxBytes: 1024 * 1024 });
    assert.equal(run.status, 'complete');
  }
  const registry = JSON.parse(await readFile(join(config, 'plugins/installed_plugins.json'), 'utf8'));
  const [installed] = registry.plugins[name];
  assert.equal(installed.scope, 'user');
  assert.equal(await readFile(join(installed.installPath, 'hooks/register.ts'), 'utf8'), source);
}

export async function driveNativePromptVirtual({ checkout, workspace, env, expectVirtual, selectedAgent = false, reverseFill = false }) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly);
  assert.equal(expectVirtual, boundary.requireVirtualPrompt);
  assert.equal(selectedAgent, boundary.requireSelectedAgentVirtualPrompt ?? false);
  assert.equal(reverseFill, boundary.requireReverseFillVirtualPrompt ?? false);
  assert.equal(typeof expectVirtual, 'boolean');
  assert.equal(hash(await readFile(executable)), '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');

  const project = join(workspace, 'project');
  await mkdir(project);
  execFileSync('/usr/bin/git', ['init', '--quiet', project], {
    env: { PATH: '/usr/bin:/bin', HOME: workspace, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_NOSYSTEM: '1' }, timeout: 5000,
  });
  const account = await configureNativeCreditAccount(workspace, 'oauth', { featureCache: 'native-defaults' });
  const config = join(workspace, '.claude');
  await writeFile(join(config, 'settings.json'), JSON.stringify({ theme: 'dark', model: 'sonnet' }));
  const configFile = join(config, '.claude.json');
  const originalConfig = JSON.parse(await readFile(configFile, 'utf8'));
  await writeFile(configFile, JSON.stringify({ ...originalConfig, hasCompletedOnboarding: true,
    projects: { ...originalConfig.projects, [project]: { ...originalConfig.projects?.[project], hasTrustDialogAccepted: true } } }));
  const model = selectedAgent
    ? await startCombinedEverydayModel({ workspace, project, maxRequests: 24, holdWorker: true })
    : await startSyntheticModel(workspace, 'TextOnly', { captureMessages: true, maxRequests: 8, textReply: reply });
  const tls = await prepareNativeCreditTls(join(workspace, 'account-tls'));
  const provider = await startNativeCreditBilling(tls, { evidencePath: join(workspace, 'provider.json') });
  const launchEnv = { ...env, ...account, NODE_EXTRA_CA_CERTS: tls.ca, ANTHROPIC_BASE_URL: model.url,
    DISABLE_AUTOUPDATER: '1', PATH: '/frozen-claude:' + env.PATH, CLAUDE_RESEARCH_PROJECT: project };
  delete launchEnv.ANTHROPIC_API_KEY;
  const source = reverseFill ? desktopVirtualFillHook : virtualHintHook;
  let profile;
  try {
    if (selectedAgent) profile = await prepareFreshCombinedEverydayProfile({ workspace });
    await installFixture(workspace, project, config, launchEnv, source);
    await driveFreshNativeApp({ checkout, workspace, env: launchEnv, route: 'real-Electron-original-virtual-prompt', journeyBudgetMs: selectedAgent || reverseFill ? 160000 : 130000,
      journey: args => verifyVirtualPrompt({ ...args, model, config, expectVirtual, selectedAgent, reverseFill, source }) });
  } finally {
    await model.close();
    await provider.close();
    await profile?.restore();
    await writeFile(join(workspace, 'model-calls.json'), JSON.stringify(model.calls, null, 2));
  }
}

async function verifyVirtualPrompt({ app, page, electronApp, expect, project, output, model, userDataDir, config, expectVirtual, selectedAgent, reverseFill, source }) {
  const result = { status: 'running', expectVirtual, selectedAgent, reverseFill, captures: [], virtualHookSha256: hash(Buffer.from(source)) };
  let outgoing = virtualDraft, hintText = virtualHint;
  const allHints = reverseFill ? desktopVirtualFillSteps.map(step => step.hint.trim()) : [virtualHint.trim()];
  const hasHint = text => allHints.some(hint => text.includes(hint));
  const save = () => writeFile(join(output, 'virtual-prompt.json'), JSON.stringify(result, null, 2));
  const context = () => page.evaluate(() => {
    const state = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    return { claude: state.currentThread?.context?.claudeCode, messages: state.currentThread?.messages ?? [],
      ui: Object.values(state.nativeUiViews).filter(view => view.threadId === state.currentThread?.id)
        .map(view => ({ attachmentId: view.attachmentId, status: view.state.status, prompt: view.prompt, agentInput: view.state.agentInput })),
      native: Object.values(state.nativeTerminalViews).find(view => view.threadId === state.currentThread?.id)?.state };
  });
  const card = page.locator('[data-onboarding-id="agent-chat-input"]');
  const composer = card.locator('[contenteditable="true"]');
  const send = card.getByRole('button', { name: 'Send', exact: true });
  const section = page.getByRole('region', { name: 'Claude native interface', exact: true });
  const open = section.getByRole('button', { name: 'Use native interface', exact: true });
  const back = section.getByRole('button', { name: 'Back to conversation', exact: true });
  try {
    await app.waitForSurface('default-setup/threads');
    await app.navigate('host/settings');
    await page.evaluate(() => {
      const host = window.applicationState.system.get('host/settings');
      host.send({ type: 'TAB.SELECT', tab: 'general' });
      host.send({ type: 'GENERAL_NAV.SELECT', item: 'secrets' });
    });
    await page.getByText('Claude Code CLI', { exact: true }).locator('..').locator('..').locator('..')
      .getByPlaceholder('Path override (auto-detected if empty)').fill(executable);
    await app.navigate('default-setup/threads');
    await expect.poll(() => page.evaluate(() => {
      const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
      return !!c.currentThread?.id && c.tabs.every(tab => c.tabsRead.includes(tab.id));
    }), { timeout: 15000 }).toBe(true);
    await page.evaluate(directory => {
      const threads = window.applicationState.system.get('default-setup/threads');
      threads.send({ type: 'NEW_THREAD_IN_PROJECT', directory });
      threads.send({ type: 'SET_MODE', mode: 'Claude Code' });
      threads.send({ type: 'SET_PHASE', phase: 'Edit' });
    }, project);
    await composer.fill(seed);
    await send.click();
    await expect.poll(async () => (await context()).messages.some(row => row.sender === 'assistant' && row.text === (selectedAgent ? 'Ready to review the release notes. Your session is saved.' : reply)),
      { timeout: 25000 }).toBe(true);
    result.sessionId = (await context()).claude.sessionId;
    await open.click();
    const terminal = section.locator('[data-terminal-text]').first();
    const input = section.getByLabel('Terminal input', { exact: true });
    const lastSent = new Map();
    for (let attempt = 0; attempt < 120 && (await context()).native?.status !== 'live'; attempt++) {
      const screen = await terminal.textContent({ timeout: 1000 }).catch(() => '');
      const prompt = recognizeOnboardingPrompt(screen ?? '', project);
      if (prompt && Date.now() - (lastSent.get(prompt) ?? 0) >= 1000) {
        await electronApp.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0]?.focus());
        await input.focus();
        await input.press(prompt === 'workspace-trust' ? 'ArrowDown' : 'Enter');
        lastSent.set(prompt, Date.now());
      }
      await page.waitForTimeout(100);
    }
    await expect.poll(async () => (await context()).native?.status, { timeout: 15000 }).toBe('live');
    const original = (await context()).native;
    assert.equal(original.sessionId, result.sessionId);
    result.pid = original.nativePid;
    result.start = await processStart(result.pid);
    assert.ok(result.start);
    await back.click();
    await expect.poll(async () => (await context()).ui.some(view => !!view.attachmentId), { timeout: 15000 }).toBe(true);
    let editor = composer, submit = send, agent;
    if (selectedAgent) {
      await composer.fill(agentSeed);
      await send.click();
      await expect.poll(async () => (await context()).native?.tasks?.some(task => task.status === 'running'),
        { timeout: 15000 }).toBe(true);
      const tools = page.getByRole('button', { name: /^Native tools/ }).first();
      await expect(tools).toBeVisible({ timeout: 15000 });
      const row = page.locator('[data-native-agent-id]').first();
      await expect.poll(async () => {
        if (await row.isVisible()) return true;
        if (await tools.getAttribute('aria-expanded') !== 'true') await tools.click();
        return row.isVisible();
      }, { timeout: 15000 }).toBe(true);
      result.taskId = await row.getAttribute('data-native-agent-id');
      assert.ok(result.taskId);
      await composer.fill(parentDraft);
      await row.getByRole('button', { name: 'Open Agent', exact: true }).click();
      agent = page.getByRole('region', { name: 'Focused Agent conversation', exact: true });
      const form = agent.getByRole('form', { name: 'Agent message', exact: true });
      editor = form.locator('[contenteditable="true"]');
      submit = form.getByRole('button', { name: 'Send to Agent', exact: true });
    }
    await expect(editor).toBeEditable();
    if (reverseFill) {
      if (selectedAgent) await expect.poll(async () => (await context()).native?.view?.taskId,
        { timeout: 15000 }).toBe(result.taskId);
      const state = await applyVirtualFills({ editor, expect, project, expectVirtual });
      result.fills = state.receipts;
      outgoing = state.text;
      hintText = desktopVirtualFillSteps.at(-1).hint;
    } else {
      await editor.click();
      await editor.pressSequentially(virtualDraft);
      await expect.poll(() => editor.evaluate(el => el.editor.state.doc.textContent)).toBe(virtualDraft);
      const hook = async () => readFile(join(project, 'virtual-edit.json'), 'utf8').then(JSON.parse).catch(error => {
        if (error.code !== 'ENOENT') throw error;
        return null;
      });
      await expect.poll(hook, { timeout: 15000 }).toMatchObject({ text: virtualDraft, decorations: [
        { start: 0, end: virtualDraft.length, bold: true },
        { start: virtualDraft.indexOf('checklist'), end: virtualDraft.indexOf('checklist'), virtualText: virtualHint },
      ] });
      result.edit = await hook();
    }
    const widget = editor.locator('.claude-prompt-virtual');
    const paint = editor.locator('.claude-prompt-decoration');
    await expect(paint.first()).toBeVisible({ timeout: 10000 });
    await expect(widget).toHaveCount(expectVirtual ? 1 : 0);
    for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
      await page.setViewportSize(viewport);
      if (expectVirtual) {
        await expect(widget).toHaveText(hintText.trim());
        await expect(widget).toHaveAttribute('contenteditable', 'false');
        await expect(widget).toBeInViewport({ ratio: 1 });
      }
      await expect(submit).toBeInViewport({ ratio: 1 });
      const name = 'virtual-prompt-' + size + '.png';
      await page.screenshot({ path: join(output, name), animations: 'disabled' });
      result.captures.push(name);
    }
    result.editorText = await editor.evaluate(el => el.editor.state.doc.textContent);
    assert.equal(result.editorText, outgoing);
    await editor.press('Control+a');
    await editor.press('Control+c');
    const readClipboard = () => electronApp.evaluate(({ clipboard }) => clipboard.readText());
    await expect.poll(readClipboard).toBe(outgoing);
    result.clipboardText = await readClipboard();
    await editor.press('ArrowRight');
    await submit.click();
    const journal = () => readCombinedEverydayJournal(userDataDir, result.sessionId, result.taskId, config);
    if (selectedAgent) {
      await expect.poll(async () => {
        result.agentReceipt = (await context()).ui.find(view => view.agentInput?.status === 'done')?.agentInput.receipt?.messageId;
        return !!result.agentReceipt;
      }, { timeout: 15000 }).toBe(true);
      model.releaseWorker();
      const isDraftText = text => text === outgoing || (typeof text === 'string' &&
        text.startsWith('The user sent a new message while you were working:\n' + outgoing + '\n\n'));
      const isDraft = value => Array.isArray(value) ? value.some(block => isDraftText(block.text)) : isDraftText(value);
      const submitted = async () => journalRows(await journal()).filter(row =>
        row.type === 'user' && row.origin?.kind === 'human' && isDraft(row.message?.content));
      await expect.poll(async () => (await submitted()).length, { timeout: 20000 }).toBe(1);
      await expect.poll(() => model.agentCalls.some(call => call.child && !call.grandchild &&
        call.messages?.some(row => row.role === 'user' && isDraft(row.content))), { timeout: 20000 }).toBe(true);
      if (await agent.isVisible()) await agent.getByRole('button', { name: 'Back to conversation', exact: true }).click();
      await expect(composer).toHaveText(parentDraft);
      result.restoredParentDraft = parentDraft;
      const parentJournal = await readCombinedEverydayJournal(userDataDir, result.sessionId, undefined, config);
      assert.ok(!parentJournal.includes(outgoing) && !hasHint(parentJournal.toString()));
      await writeFile(join(output, 'native-parent-transcript.jsonl'), parentJournal);
    } else {
      await expect.poll(async () => (await context()).messages.filter(row => row.sender === 'assistant' && row.text === reply).length,
        { timeout: 25000 }).toBe(2);
      const humans = journalRows(await journal()).filter(row =>
        row.type === 'user' && ['sdk', 'human'].includes(row.turnOrigin)).map(row => row.message.content);
      assert.deepEqual(humans, [seed, outgoing]);
    }
    const calls = model.calls.filter(call => call.path.split('?')[0] === '/v1/messages');
    assert.ok(calls.some(call => call.messages?.some(row => row.role === 'user' && JSON.stringify(row.content).includes(outgoing))));
    assert.ok(calls.every(call => !hasHint(JSON.stringify(call.messages))));
    const transcript = await journal();
    assert.ok(!hasHint(transcript.toString()));
    await writeFile(join(output, 'native-transcript.jsonl'), transcript);
    const final = await context();
    assert.equal(final.claude.sessionId, result.sessionId);
    assert.equal(final.native.ownerId, original.ownerId);
    result.status = 'complete';
  } catch (error) {
    result.status = 'failed';
    result.error = error.message;
    result.promptState = (await context().catch(() => ({}))).ui;
    throw error;
  } finally {
    if (result.pid && await processStart(result.pid) === result.start) {
      if (await open.isVisible()) await open.click();
      await section.getByRole('button', { name: 'Stop session', exact: true }).click();
      await expect.poll(() => processStart(result.pid), { timeout: 15000 }).not.toBe(result.start);
      result.writerRetired = true;
    }
    await save();
  }
}


async function applyVirtualFills({ editor, expect, project, expectVirtual }) {
  const receiptPath = join(project, 'virtual-desktop-fill.json');
  const readReceipts = () => readFile(receiptPath, 'utf8').then(JSON.parse).catch(error => {
    if (error.code !== 'ENOENT') throw error;
    return [];
  });
  let text = '', cursor = 0;
  const widget = editor.locator('.claude-prompt-virtual');
  for (const [index, step] of desktopVirtualFillSteps.entries()) {
    if (step.mode === 'insert') {
      cursor = text.indexOf('release');
      assert.ok(cursor > 0);
      await editor.press('Control+Home');
      for (let offset = 0; offset < cursor; offset++) await editor.press('ArrowRight');
      await expect.poll(() => editor.evaluate(el => el.editor.state.selection.head - 1)).toBe(cursor);
    }
    const before = { text, cursor };
    const offset = step.mode === 'replace' ? 0 : step.mode === 'append' ? text.length : cursor;
    text = step.mode === 'replace' ? step.text : text.slice(0, offset) + step.text + text.slice(offset);
    cursor = offset + step.text.length;
    await writeFile(join(project, desktopVirtualFillTrigger), String(index + 1));
    await expect.poll(async () => (await readReceipts()).length, { timeout: 15000 }).toBe(index + 1);
    const receipt = (await readReceipts()).at(-1);
    assert.deepEqual(receipt.before, before);
    assert.equal(receipt.result.isFilled, true);
    assert.deepEqual(receipt.after, { text, cursor });
    await expect.poll(() => editor.evaluate(el => el.editor.state.doc.textContent)).toBe(text);
    await expect(widget).toHaveCount(expectVirtual ? 1 : 0);
    if (expectVirtual) await expect(widget).toHaveText(step.hint.trim());
  }
  return { receipts: await readReceipts(), text };
}
