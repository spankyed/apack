import {nativeManagedFiles} from '../protocol/native-managed-files.mjs';
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {setTimeout as delay} from 'node:timers/promises';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {nativeDialogInspector} from '../protocol/native-dialog-inspector.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
const [checkout,executable,workspace,scenarioArg='keep']=process.argv.slice(2);const useAdapter=scenarioArg.endsWith('-adapter'),editedPlan=scenarioArg.includes('-edited'),managed=scenarioArg.includes('-managed'),scenario=scenarioArg.replace('-edited','').replace('-managed','').replace(/-adapter$/,'');assert.ok(['keep','clear','enter'].includes(scenario));const clearContext=scenario==='clear',enterPlan=scenario==='enter';
const targetSha256=hash(await readFile(executable));assert.equal(targetSha256,'5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');assert.equal(process.env.HOME,workspace);
for(const name of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[name],undefined);
const root=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(root,'query.ts')).href),store=await import(pathToFileURL(join(root,'handle-store.ts')).href),{prepareClaudeNativeTerminal}=await import(pathToFileURL(join(root,'terminal-owner.ts')).href);
const configDir=join(workspace,'.claude');await mkdir(configDir,{recursive:true});
await writeFile(join(configDir,'settings.json'),JSON.stringify({...enterPlan?{permissions:{ask:['EnterPlanMode']}}:{},showClearContextOnPlanAccept:clearContext,apiKeyHelper:'/usr/bin/printf research-fixture-key',statusLine:{type:'command',command:'/usr/bin/printf NativePlanOwner',refreshInterval:1}}));
let policyPreload='';if(managed){const directory=join(workspace,'policy');await mkdir(directory);await writeFile(join(directory,'managed-settings.json'),JSON.stringify({allowManagedHooksOnly:true,disableAllHooks:true}));policyPreload=nativeManagedFiles({directory,receipt:join(workspace,'managed-file-reads.jsonl')});}
const inspector=join(workspace,'plan-inspector.mjs'),reportPath=join(workspace,'native-dialog-shapes.json');await writeFile(inspector,policyPreload+nativeDialogInspector(reportPath)+`
const planStateTimer=setInterval(async()=>{try{
 const {writeFileSync}=await import('node:fs'),runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),globals=await import('/$bunfs/root/chunk-hdxpvbx1.js'),binding=runtime.ey();if(binding?.surface!=='terminal')return;
 const context=binding.toolContext(new AbortController()),state=context.getAppState();
 writeFileSync(${JSON.stringify(join(workspace,'native-plan-state.json'))},JSON.stringify({sessionId:String(globals.q()),permission:state.toolPermissionContext,initialMessage:state.initialMessage??null}),{mode:0o600});
}catch{}},100);planStateTimer.unref();
`);
const env={ENABLE_TOOL_SEARCH:'0',HOME:workspace,CLAUDE_CONFIG_DIR:configDir,BUN_OPTIONS:'--preload='+inspector,CLAUDE_CODE_SIMPLE:undefined,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
const seed=await startSyntheticModel(workspace,'TextOnly'),model=await startSyntheticModel(workspace,enterPlan?'EnterPlanMode':'TuiPlan',{captureMessages:true,maxRequests:8});
let native,owner,seeded,terminal='',seen=0,timer,unsubscribe,theme=false,security=false,navigated=false,trusted=false,lastInput=0;
const waitFor=async(check,label,ms=20000)=>{const deadline=Date.now()+ms;while(Date.now()<deadline){if(await check())return;await delay(50)}throw Error(label)};
const report=async()=>{try{return JSON.parse(await readFile(reportPath,'utf8'))}catch(error){if(error.code!=='ENOENT')throw error;return{events:[]}}};
try{
 owner=await store.openConversation('plan-contract',JSON.stringify({cwd:workspace}),()=>query({cliPath:executable,cwd:workspace,env:{...env,ANTHROPIC_BASE_URL:seed.url},tools:[],keepStdinOpen:true}),async turn=>{for await(const line of turn.handle.events){}seeded=await turn.handle.result;owner.release(turn.handle)});
 await owner.handle.initialized;owner.start('Seed native plan contract.',async turn=>{for await(const line of turn.handle.events){}seeded=await turn.handle.result;owner.release(turn.handle)});await waitFor(()=>seeded&&!owner.busy,'Seed did not settle');
 const sessionId=owner.sessionId;native=await store.openNativeTerminal('plan-contract',{cliPath:executable,env:{...env,ANTHROPIC_BASE_URL:model.url}},prepareClaudeNativeTerminal);
 const observe=()=>{for(const chunk of native.output)if(chunk.sequence>seen){terminal+=chunk.text;seen=chunk.sequence;}if(Date.now()-lastInput<200)return;const screen=recognizeOnboardingPrompt(terminal,workspace);let input;if(screen==='theme'&&!theme){theme=true;input='\r'}else if(screen==='security-notes'&&theme&&!security){security=true;input='\r'}else if(screen==='workspace-trust'&&!navigated){navigated=true;input='\x1b[B'}else if((screen==='workspace-trust-selected'||screen==='workspace-trust'&&Date.now()-lastInput>350)&&navigated&&!trusted){trusted=true;input='\r'}if(input!==undefined){lastInput=Date.now();native.input(native.state.ownerId,input)}};
 unsubscribe=native.subscribe(observe);timer=setInterval(observe,100);observe();await waitFor(()=>native.state.status==='live','Native file owner not ready');
 if(!enterPlan)assert.equal(await native.setPermissionMode('plan'),'plan');
 await native.submit('NativePlanFixtureSeedAlpha: Create the synthetic plan and request approval.');
 let item;
 await waitFor(async()=>{item=(await report()).events.flatMap(event=>event.value?.open??[]).find(item=>item.kind===(enterPlan?'permission_enter_plan_mode':'permission_exit_plan_mode_v2'));return !!item},'Native populated plan dialog missing');
 if(!enterPlan)assert.equal(item.payload.plan,'# Synthetic native plan\n\nImplement the isolated fixture only.\n');
 const compact=()=>terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');
 await waitFor(()=>enterPlan?compact().includes('Enterplanmode?'):compact().includes('Yes,manuallyapproveedits'),'Original manual plan approval not shown');
 await writeFile(join(workspace,'native-plan-before-answer.txt'),terminal);
 if(useAdapter){
  const descriptor=(await native.getPlanDialogs())[0];assert.equal(descriptor.toolName,item.payload.toolName);
  const choice=enterPlan?'yes':clearContext?descriptor.presentation.choices.find(option=>option.clearContext)?.value:'yes-default-keep-context';assert.ok(choice);
  const answer={id:descriptor.id,revision:descriptor.revision,sessionId:descriptor.sessionId,choice,...(editedPlan?{plan:'# Synthetic native plan\n\nReviewed before continuing.\n'}:{})};
  await assert.rejects(native.answerPlanDialog({...answer,choice:'forged'}));
  await assert.rejects(native.answerPlanDialog({...answer,sessionId:'11111111-1111-4111-8111-111111111111'}));
  await native.answerPlanDialog(answer);await assert.rejects(native.answerPlanDialog(answer));
 }else{
  if(clearContext||enterPlan)await delay(300);
  if(!clearContext&&!enterPlan){native.input(native.state.ownerId,'\x1b[B');await delay(300)}
  native.input(native.state.ownerId,'\r');
 }
 await waitFor(async()=>(await report()).events.some(event=>event.type==='closed'&&event.value.id===item.id),'Original plan choice did not close');
 await waitFor(()=>(enterPlan?model.calls.length>=2:model.calls.some(call=>call.fixtureResponse==='text'))&&!native.busy,'Native plan continuation did not settle');
 let state;await waitFor(async()=>{state=JSON.parse(await readFile(join(workspace,'native-plan-state.json'),'utf8'));return clearContext?state.sessionId!==sessionId&&state.permission.mode==='auto'&&model.calls.some(call=>call.hasSyntheticPlan&&!call.hasTuiSeed):state.permission.mode===(enterPlan?'plan':'default')},'Native plan transition did not settle');
 await waitFor(async()=>{await native.readJournal();return native.state.session?.permissionMode===state.permission.mode},'Native journal mode projection did not settle');const ownerAfterTransition={...native.state};
 let controlProblem;try{await native.getFileDialogs()}catch(error){controlProblem=String(error)}
 if(clearContext){assert.notEqual(state.sessionId,sessionId);assert.equal(state.permission.mode,'auto');assert.ok(model.calls.some(call=>call.hasSyntheticPlan&&!call.hasTuiSeed));assert.equal(ownerAfterTransition.sessionId,state.sessionId);assert.equal(controlProblem,undefined)}else{assert.equal(state.sessionId,sessionId);assert.equal(state.permission.mode,enterPlan?'plan':'default')}
 const closed=(await report()).events.filter(event=>event.type==='closed');
 if(clearContext)assert.ok(closed.some(event=>event.value.id===item.id&&event.value.result?.behavior==='deny'));else assert.ok(closed.some(event=>event.value.id===item.id&&event.value.result?.behavior==='allow'&&event.value.result.permissionUpdates?.some(update=>update.type==='setMode'&&update.mode===(enterPlan?'plan':'default'))));
 await writeFile(join(workspace,'native-plan-contract.json'),JSON.stringify({item,closed,state,ownerAfterTransition,controlProblem},null,2));
 if(editedPlan){assert.equal(await readFile(item.payload.planFilePath,'utf8'),'# Synthetic native plan\n\nReviewed before continuing.\n');assert.ok(JSON.stringify(model.calls).includes('Reviewed before continuing.'));}
 await native.close();
 console.log(JSON.stringify({evidence:'apack-native-terminal-plan-contract',targetSha256,nativePlanAdapter:useAdapter,nativePlanEdited:editedPlan,nativeManagedReset:managed,nativePopulatedPlan:!enterPlan,nativeEnterPlan:enterPlan,nativeManualKeepContext:!clearContext&&!enterPlan,nativeClearContext:clearContext,ownerFollowsNativeSession:true,originalModeUpdate:true,sameSession:!clearContext,ownedShutdown:true,syntheticApiRequests:seed.calls.length+model.calls.length,realModelRequests:0}));
}finally{clearInterval(timer);unsubscribe?.();store.killAllHandles();await native?.close();await writeFile(join(workspace,'native-plan-terminal.txt'),terminal);await writeFile(join(workspace,'native-plan-model-calls.json'),JSON.stringify(model.calls,null,2));await seed.close();await model.close();}
