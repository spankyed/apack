import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fillLabel,fillText,suggestLabel,suggestText} from './prompt-replacement-plugin.mjs';

/** Check each retired operation against a distinct replacement of the original CLI writer. */
export async function verifyPromptControlsReplacement({page,section,card,composer,send,expect,context,currentUi,
 output,project,proof,save,phase,sendMain,processStart,hold,retiredBeforeExpiry}) {
  const original = await context();
  const result = proof.promptControlsReplacement = {threadId:original.threadId,sessionId:proof.parentSessionId,
    cases:[],writers:[{pid:proof.pid,start:proof.processStart}],captures:[],retiredBeforeExpiry};
  const show = section.getByRole('button',{name:'Use native interface',exact:true});
  const back = section.getByRole('button',{name:'Back to conversation',exact:true});
  const stop = section.getByRole('button',{name:'Stop session',exact:true});
  const ghost = composer.locator('.claude-prompt-suggestion');
  const completion = token => page.getByRole('group',{name:'Claude suggestions',exact:true})
    .getByRole('button',{name:`Complete ${token}`,exact:true});
  const replace = async text => {
    await composer.focus();
    if (!text && (await composer.textContent())==='') await composer.pressSequentially('x');
    await composer.press('ControlOrMeta+a');
    await composer.press('Backspace');
    await expect(composer).toHaveText('');
    if (text) await composer.pressSequentially(text);
    await expect.poll(async () => (await currentUi())?.prompt,{timeout:12000})
      .toMatchObject({status:'applied',frame:{text}});
  };
  const invoke = async name => {
    const button = card.getByRole('button',{name,exact:true});
    if (!(await button.isVisible())) await card.getByRole('button',{name:'Session tools',exact:true}).click();
    await button.click();
  };
  const readResult = name => readFile(join(project,`prompt-replacement-${name}.json`),'utf8')
    .then(JSON.parse).catch(error => { if (error.code!=='ENOENT') throw error; });
  const stopWriter = async writer => {
    await show.click();
    await stop.click();
    await expect.poll(() => processStart(writer.pid),{timeout:15000}).not.toBe(writer.start);
    writer.retired = true;
    writer.retiredAt = Date.now();
    if (await back.isVisible()) await back.click();
    await save();
  };
  const startReplacement = async () => {
    await show.click();
    await expect.poll(async () => {
      const state = (await context()).native?.state;
      return state?.status==='live' && state.sessionId===result.sessionId
        && !result.writers.some(writer => writer.pid===state.nativePid);
    },{timeout:25000}).toBe(true);
    const pid = (await context()).native.state.nativePid;
    const start = await processStart(pid);
    assert.ok(start);
    const writer = {pid,start,liveAt:Date.now()};
    result.writers.push(writer);
    await save();
    await back.click();
    await expect.poll(async () => (await currentUi())?.state.status,{timeout:15000}).toBe('live');
    assert.equal((await context()).threadId,result.threadId);
    return writer;
  };
  const snapshot = async retiredMountId => {
    const {messages,ui} = await context();
    const view = retiredMountId ? ui[retiredMountId] : await currentUi();
    const document = await composer.evaluate(element => {
      const selection = window.getSelection();
      return {html:element.innerHTML,anchor:selection?.anchorOffset,focus:selection?.focusOffset};
    });
    return {messages,document,mountId:view?.mountId,retiredMountStatus:retiredMountId?view?.state.status??'absent':undefined};
  };
  const capture = async name => {
    for (const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
      await page.setViewportSize(viewport);
      await expect(composer).toBeInViewport({ratio:1});
      await expect(send).toBeInViewport({ratio:1});
      const file = `prompt-${name}-replacement-${size}.png`;
      await page.screenshot({path:join(output,file),animations:'disabled'});
      result.captures.push(file);
    }
    await save();
  };

  for (const name of retiredBeforeExpiry?['fill','suggest']:['autocomplete','fill','suggest']) {
    const entry = {name};
    result.cases.push(entry);
    const writer = result.writers.at(-1);
    await page.setViewportSize({width:1100,height:900});
    await replace(name==='fill'?'Keep this draft before Claude restarts.':'');
    const {mountId,threadId} = await currentUi();
    const selector = name==='autocomplete' ? {type:'CLAUDE_PROMPT_COMPLETIONS',label:'Complete #retired'}
      : {type:'CLAUDE_PROMPT_HOST_REQUEST',kind:name,text:name==='fill'?fillText:suggestText};
    const index = (await hold.receipts()).length;
    await hold.arm({mountId,threadId,...selector});
    if (name==='autocomplete') await composer.pressSequentially('Review #retired');
    else await invoke(name==='fill'?fillLabel:suggestLabel);
    await expect.poll(async () => (await hold.receipts()).length,{timeout:12000}).toBe(index+1);
    entry.held = (await hold.receipts())[index];
    entry.oldPid = writer.pid;
    if (name==='autocomplete') await expect(completion('#retired')).toHaveCount(0);
    if (name==='fill') await expect(composer).toHaveText('Keep this draft before Claude restarts.');
    if (name==='suggest') await expect(ghost).toHaveCount(0);
    await save();

    await stopWriter(writer);
    if (retiredBeforeExpiry) {
      const before = await snapshot(entry.held.mountId);
      assert.ok(['absent','disconnected'].includes(before.retiredMountStatus));
      entry.delivery = await hold.release(index);
      await save();
      assert.equal(entry.delivery.outcome,'delivered-on-original-socket');
      assert.ok(entry.delivery.releasedAt<entry.held.expiresAt,'The retired request must arrive before its original deadline');
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
      const after = await snapshot(entry.held.mountId);
      assert.deepEqual(after,before);
      Object.assign(entry,{retiredMountStatus:after.retiredMountStatus,unchangedDocument:after.document,unchangedHistory:true});
      await save();
    }
    const next = await startReplacement();
    entry.newPid = next.pid;
    if (name==='autocomplete') {
      await replace('Review #fresh');
      await expect(completion('#fresh')).toBeVisible();
    } else if (name==='fill') await replace('Keep the replacement draft until I request a fill.');
    else await replace('');
    const before = await snapshot();
    assert.notEqual(before.mountId,entry.held.mountId);
    if (!retiredBeforeExpiry) {
      entry.delivery = await hold.release(index);
      assert.equal(entry.delivery.outcome,'delivered-on-original-socket');
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
      const after = await snapshot();
      assert.deepEqual(after,before);
      Object.assign(entry,{unchangedDocument:after.document,unchangedHistory:true});
    }
    if (name==='autocomplete') await expect(completion('#retired')).toHaveCount(0);
    if (name==='suggest') await expect(ghost).toHaveCount(0);
    entry.newMountId = before.mountId;
    await save();

    if (name==='autocomplete') {
      await completion('#fresh').click();
      await expect(composer).toHaveText('Review #fresh-complete');
      entry.fresh = {text:await composer.textContent()};
    } else if (name==='fill') {
      await invoke(fillLabel);
      await expect(composer).toHaveText(fillText);
      await expect.poll(() => readResult(name),{timeout:12000}).toMatchObject({isFilled:true});
      entry.fresh = {text:await composer.textContent(),result:await readResult(name)};
    } else {
      await invoke(suggestLabel);
      await expect.poll(() => readResult(name),{timeout:12000}).toMatchObject({isShown:true});
      await expect(ghost).toHaveText(suggestText);
      await composer.focus();
      await composer.press('Tab');
      await expect(composer).toHaveText(suggestText);
      entry.fresh = {text:await composer.textContent(),result:await readResult(name)};
    }
    await capture(name);
    phase('retired-prompt-control-delivered',{name});
  }

  await stopWriter(result.writers.at(-1));
  result.followup = 'Continue the same release review after the interruption.';
  await sendMain(result.followup);
  await expect.poll(async () => (await context()).claude?.turns,{timeout:20000}).toBe(2);
  await expect.poll(async () => (await context()).claude?.chatState,{timeout:20000}).toBe('success');
  proof.final = await context();
  assert.equal(proof.final.claude.sessionId,result.sessionId);
  assert.equal(proof.final.threadId,result.threadId);
  proof.status = 'complete';
  await save();
}
