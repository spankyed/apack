import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,realpath,stat,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createRun,hash} from '../artifacts/runs.mjs';
import {record} from '../protocol/record.mjs';

export async function probeMetadataLifecycleApp(checkout,executable,root,output){
 checkout=await realpath(checkout);assert.ok((await stat(join(checkout,'.git'))).isFile(),'Use the isolated linked worktree');
 assert.equal(await realpath(join(checkout,'node_modules')),join(checkout,'node_modules'),'Do not share node_modules');
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'metadata-lifecycle-'));await mkdir(join(workspace,'.claude'));
 const driver=fileURLToPath(new URL('./metadata-lifecycle-driver.mjs',import.meta.url)),sourceHashes={};
 const sourceRoot=join(checkout,'packages/default-setup');
 for(const name of ['src/content/actions/claude-code/cc-command.ts','src/content/actions/claude-code/cc-plan.ts','src/content/actions/claude-code/cc-context.ts','src/content/actions/claude-code/_helpers/context-usage.ts','src/features/code/be/services/claude-code/memory.ts','src/features/code/be/services/claude-code/skills.ts','src/features/code/be/services/claude-code/permissions.ts','src/features/code/be/services/claude-code/query.ts','src/features/code/be/services/claude-code/runner.ts','src/features/code/be/services/claude-code/host-controls.ts','tests/content/actions/claude-code/metadata-lifecycle-native.spec.ts'])sourceHashes[name]=hash(await readFile(join(sourceRoot,name)));
 const run=await createRun(output,'apack-metadata-lifecycle',{targetSha256:hash(await readFile(executable)),baseCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:checkout,encoding:'utf8'}).trim(),sourceHashes,driverSha256:hash(await readFile(driver)),orchestratorSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('../protocol/synthetic-model.mjs',import.meta.url)))});
 try{
  const transport=await record({executable:process.execPath,cwd:checkout,args:['--import',join(checkout,'node_modules/tsx/dist/loader.mjs'),driver,checkout,executable,workspace],env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},output,timeoutMs:65000});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);
  const stdout=await readFile(join(transport.directory,'stdout.bin'),'utf8'),evidence=stdout.split('\n').filter(line=>line.startsWith('{')).map(line=>JSON.parse(line)).find(value=>value.evidence==='apack-native-metadata-lifecycle');
  assert.ok(evidence);assert.equal(evidence.sourceCommands,true);assert.equal(evidence.defaultCommandStarts,0);assert.equal(evidence.automaticRefreshStarts,0);assert.equal(evidence.defaultWriterCalls,0);assert.equal(evidence.explicitCatalogStarts,3);assert.equal(evidence.localModelRequests,0);assert.equal(evidence.realModelRequests,0);assert.equal(evidence.settingsUnchanged,true);assert.deepEqual(evidence.hookEvents,['SessionStart','SessionEnd','SessionStart','SessionEnd','SessionStart','SessionEnd']);
  for(const[name,sha]of Object.entries(sourceHashes))assert.equal(hash(await readFile(join(sourceRoot,name))),sha);
  await writeFile(join(run.directory,'metadata-lifecycle.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
