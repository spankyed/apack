import assert from 'node:assert/strict';
import {readFile,readdir,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {readNativeTranscriptRow} from './native-transcript-evidence.mjs';

export const mcpTaskPrompt = 'Start the release review task on the MCP server.';

async function readFrames(path) {
  const text = await readFile(path,'utf8').catch(error=>{
    if (error.code==='ENOENT') return '';
    throw error;
  });
  return text.slice(0,text.lastIndexOf('\n')+1).split('\n').filter(Boolean).map(JSON.parse);
}

/** Inspect and stop a legitimately admitted task through the captured desktop controls. */
export async function driveMcpTaskJourney({page,expect,context,composer,send,section,replace,proof,output,receipts,scenario,taskInputAction,staleTaskInput,mcpTaskCompletionNotice,taskTransportDrop,taskPark,taskFinish,taskAdvanceRelease,changeTaskTransport,changedTaskPeerReceipts,settledTaskState,workspace,model,birth,save,phase}) {
  let owner=proof.initial.native.state, activePid=proof.pid, activeStart=proof.processStart;
  const sameOwner = async () => {
    const current=await context(), native=current.native?.state;
    assert.equal(current.threadId,proof.initial.threadId);
    assert.equal(current.claude.sessionId,proof.sessionId);
    assert.equal(native?.sessionId,proof.sessionId);
    assert.equal(native?.ownerId,owner.ownerId);
    assert.equal(native?.nativePid,activePid);
    assert.equal(await birth(activePid),activeStart);
    return current;
  };
  const visibleOutcome=async summary=>{
    const storedNotices=async()=> (await sameOwner()).messages.filter(message=>message.text===summary);
    await expect.poll(async()=> (await storedNotices()).map(message=>message.sender),{timeout:15000}).toEqual(['system']);
    const [storedNotice]=await storedNotices();
    const messageRow=page.locator('[data-message-id="'+storedNotice.id+'"]');
    const notice=messageRow.getByText(summary,{exact:true}).and(page.locator(':visible'));
    await expect(notice).toHaveCount(1);
    await expect(page.getByText(/calling the tool again may repeat the work/i)).toHaveCount(0);
    return notice;
  };
  const taskState=async()=> (await sameOwner()).native.state.tasks.find(task=>task.kind==='mcp');
  async function captureSettledOutcome(notice,draft){
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      await expect(composer).toBeInViewport({ratio:1});
      await expect(send).toBeInViewport({ratio:1});
      await expect(composer).toHaveText(draft);
      const geometry=await readNativeTranscriptRow(page,expect,notice,{checkTextHit:true});
      const name='native-mcp-task-settled-resume-'+size+'.png';
      await page.screenshot({path:join(output,name)});
      (proof.settledNoticeGeometry??=[]).push({size,geometry});
      proof.captures.push(name);
      await save();
    }
  }

  proof.mcpTaskScenario=scenario;
  proof.scope='Original MCP background task, desktop details and local Stop. Server cancellation is reported from the original wire.';
  await replace(mcpTaskPrompt);
  await send.click();

  const approval=page.getByRole('region',{name:'mcp__research__review approval',exact:true});
  const allow=approval.getByRole('button',{name:'Yes',exact:true});
  await expect(allow).toBeEnabled();
  const pending=(await sameOwner()).claude.pendingControlRequest;
  assert.equal(pending.toolName,'mcp__research__review');
  assert.equal(pending.nativeTerminal.ownerId,owner.ownerId);
  assert.deepEqual(pending.originalInput,{scenario});
  assert.ok(!(await readFrames(receipts)).some(row=>row.direction==='in'&&row.value.method==='tools/call'));
  proof.approval={messageId:pending.approvalMessageId,ownerId:owner.ownerId,sessionId:proof.sessionId};
  await page.setViewportSize({width:680,height:600});
  await expect(allow).toBeInViewport({ratio:1});
  await page.screenshot({path:join(output,'native-mcp-task-approval-compact.png'),animations:'disabled'});
  proof.captures.push('native-mcp-task-approval-compact.png');
  await allow.click();
  await expect(approval).toHaveCount(0);
  await save();

  await expect.poll(taskState,{timeout:20000}).toMatchObject({mcp:{serverName:'research',serverTaskId:'owned-review-1'}});
  proof.mcpTask=await taskState();
  assert.notEqual(proof.mcpTask.id,proof.mcpTask.mcp.serverTaskId);
  const activity=page.getByRole('region',{name:'MCP tasks',exact:true});
  const row=activity.locator('[data-native-mcp-task-id="'+proof.mcpTask.id+'"]');
  const taskDetails=row.getByRole('button',{name:'Task details',exact:true});
  const details=page.getByRole('dialog',{name:'MCP task details',exact:true});
  const stop=details.getByRole('button',{name:'Stop task',exact:true});
  proof.draft='Keep these release notes while I check the task.';
  await replace(proof.draft);
  if(scenario==='input'){
    proof.taskInputAction=taskInputAction;
    if(staleTaskInput) proof.scope='Original mounted form submitted after the peer forgot its task.';
    else proof.scope='Original MCP background task form '+taskInputAction+', task retirement and same-session continuation.';
    const form=page.getByTestId('native-mcp-form');
    const field=form.getByRole('combobox',{name:'confirmed',exact:false});
    const submit=form.getByRole('button',{name:'Submit',exact:true});
    await writeFile(taskAdvanceRelease,'Allow the owned MCP server to ask for input.',{flag:'wx'});
    await expect(form).toContainText('Confirm the owned task review.',{timeout:20000});
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      await expect(field).toBeInViewport({ratio:1});
      await expect(submit).toBeInViewport({ratio:1});
      const name='native-mcp-task-input-'+size+'.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
    if(taskInputAction==='accept'){
      await field.selectOption('true');
      await submit.click();
    }else{
      const label=taskInputAction==='decline'?'Decline':'Cancel';
      const action=form.getByRole('button',{name:label,exact:true});
      await expect(action).toBeInViewport({ratio:1});
      await action.click();
    }
    await expect(form).toHaveCount(0);
    if(staleTaskInput){
      await expect(row).toHaveCount(0,{timeout:25000});
    }else{
      await expect(row).toHaveCount(0);
    }
    await expect(composer).toHaveText(proof.draft);
    proof.afterInput=await sameOwner();
    proof.framesAfterInput=await readFrames(receipts);
    const updates=proof.framesAfterInput.filter(row=>row.direction==='in'&&row.value.method==='tasks/update');
    assert.equal(updates.length,1);
    const answer=taskInputAction==='accept'?{action:'accept',content:{confirmed:true}}:{action:taskInputAction};
    assert.deepEqual(updates[0].value.params.inputResponses,{'review-input':answer});
    assert.equal(updates[0].value.params.taskId,proof.mcpTask.mcp.serverTaskId);
    if(staleTaskInput){
      const reply=proof.framesAfterInput.find(frame=>frame.direction==='out'&&frame.value.id===updates[0].value.id);
      assert.equal(reply?.value.error?.code,-32602);
      assert.equal(reply.value.result,undefined);
      const summary='MCP task '+proof.mcpTask.mcp.serverTaskId+' (research/review) expired on the server: outcome unknown.';
      const notice=await visibleOutcome(summary);
      await notice.scrollIntoViewIfNeeded();
      await expect(notice).toBeInViewport({ratio:1});
      await expect(composer).toBeInViewport();
      proof.visibleUnknown=summary;
      const name='native-mcp-task-stale-result-compact.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
    if(mcpTaskCompletionNotice){
      const summary='MCP task '+proof.mcpTask.mcp.serverTaskId+' (research/review) completed.';
      const notice=await visibleOutcome(summary);
      proof.visibleCompletion=summary;
      await expect.poll(async()=>{
        const state=await sameOwner();
        const index=state.messages.findIndex(message=>message.sender==='system'&&message.text===summary);
        return index>=0&&!state.native.state.busy&&state.claude.chatState==='success'&&state.messages.slice(index+1)
          .some(message=>message.sender==='assistant'&&message.text==='Fixture completed.'&&message.context?.cliUuid);
      },{timeout:20000}).toBe(true);
      proof.afterCompletion=await sameOwner();
      for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
        await page.setViewportSize({width,height});
        await readNativeTranscriptRow(page,expect,notice);
        await expect(composer).toBeInViewport();
        await expect(composer).toHaveText(proof.draft);
        const name='native-mcp-task-completed-'+size+'.png';
        await page.screenshot({path:join(output,name),animations:'disabled'});
        proof.captures.push(name);
        await save();
      }
    }
  }else if(scenario==='expired'){
    proof.scope='Original MCP task expiry and outcome-unknown reporting without a replacement tool call.';
    await expect(row).toBeVisible();
    await writeFile(taskAdvanceRelease,'Allow the owned MCP server to expire the task.',{flag:'wx'});
    const unknown=()=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>
      Array.isArray(message.content)?message.content:[]).find(block=>
        block.type==='text'&&block.text.includes('<task-id>'+proof.mcpTask.id+'</task-id>')
          &&block.text.includes('Task outcome unknown:'));
    await expect.poll(()=>!!unknown(),{timeout:25000}).toBe(true);
    await expect(row).toHaveCount(0);
    proof.unknownNotification=unknown().text;
    await expect(composer).toHaveText(proof.draft);
    proof.framesAfterExpiry=await readFrames(receipts);
    const summary=/<summary>([^<]+)<\/summary>/.exec(proof.unknownNotification)?.[1];
    assert.ok(summary?.endsWith(': outcome unknown.'));
    const notice=await visibleOutcome(summary);
    proof.visibleUnknown=summary;
    proof.afterExpiry=await sameOwner();
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      await expect(composer).toHaveText(proof.draft);
      await expect(composer).toBeInViewport();
      await notice.scrollIntoViewIfNeeded();
      await expect(notice).toBeInViewport({ratio:1});
      const name='native-mcp-task-expired-'+size+'.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
  }else if(taskPark){
    proof.scope='Park an original running MCP task across a native process exit and resume the same conversation.';
    await expect(row).toBeVisible();
    await expect.poll(async()=> (await readFrames(receipts)).some(frame=>
      frame.direction==='out'&&frame.value.result?.taskId===proof.mcpTask.mcp.serverTaskId
        &&frame.value.result.status==='working'&&!frame.value.result.resultType)).toBe(true);
    proof.beforePark=await sameOwner();
    await section.getByRole('button',{name:'Use native interface',exact:true}).click();
    await section.getByRole('button',{name:'Stop session',exact:true}).click();
    await expect.poll(()=>birth(activePid),{timeout:15000}).toBe(null);
    const projects=join(workspace,'.claude/projects');
    const paths=(await readdir(projects,{recursive:true})).filter(path=>
      path.endsWith('/'+proof.sessionId+'/mcp-tasks/mcp-task-'+proof.mcpTask.id+'.meta.json'));
    assert.equal(paths.length,1,'Native MCP task metadata must survive owner exit');
    proof.parkedNativeSidecar=JSON.parse(await readFile(join(projects,paths[0]),'utf8'));
    assert.equal(proof.parkedNativeSidecar.taskId,proof.mcpTask.id);
    assert.equal(proof.parkedNativeSidecar.mcpTaskId,proof.mcpTask.mcp.serverTaskId);
    proof.framesAfterPark=await readFrames(receipts);
    await save();
    if(changeTaskTransport){proof.changedTransport=await changeTaskTransport();await save();}
    if(settledTaskState){
      const working=JSON.parse(await readFile(settledTaskState.path,'utf8'));
      assert.equal(working.status,'working');
      assert.equal(working.taskId,proof.mcpTask.mcp.serverTaskId);
      // Persist the simulated server result while the original writer is retired.
      assert.equal(await birth(activePid),null);
      const settled={...working,status:settledTaskState.outcome,lastUpdatedAt:new Date().toISOString()};
      await writeFile(settledTaskState.path,JSON.stringify(settled));
      proof.settledWhileStopped={working,settled,ownerRetired:true};
      await save();
    }
    const back=section.getByRole('button',{name:'Back to conversation',exact:true});
    if(await back.isVisible())await back.click();
    await expect(composer).toHaveText(proof.draft);
    if(settledTaskState){proof.reopenRequestedAt=new Date().toISOString();await save();}
    await section.getByRole('button',{name:'Use native interface',exact:true}).click();
    await expect.poll(async()=>{
      const candidate=(await context()).native?.state;
      return candidate?.status==='live'&&!!candidate.nativePid&&candidate.nativePid!==proof.pid;
    },{timeout:25000}).toBe(true);
    const resumed=await context();
    owner=resumed.native.state;
    activePid=owner.nativePid;
    activeStart=await birth(activePid);
    proof.resumedWriter={pid:activePid,start:activeStart,ownerId:owner.ownerId};
    await save();
    assert.ok(activeStart);
    assert.notEqual(activePid,proof.pid);
    assert.notEqual(owner.ownerId,proof.initial.native.state.ownerId);
    await back.click();
    await expect(composer).toHaveText(proof.draft);
    if(settledTaskState){
      proof.settledSummary=`MCP task ${proof.mcpTask.mcp.serverTaskId} (research/review) ${settledTaskState.outcome}.`;
      await expect.poll(async()=> (await readFrames(receipts)).slice(proof.framesAfterPark.length).some(frame=>
        frame.direction==='out'&&frame.value.result?.taskId===proof.mcpTask.mcp.serverTaskId
          &&frame.value.result.status===settledTaskState.outcome),{timeout:20000}).toBe(true);
      await expect(row).toHaveCount(0);
      await expect(composer).toHaveText(proof.draft);
      const notice=await visibleOutcome(proof.settledSummary);
      await expect.poll(async()=> (await sameOwner()).claude.chatState,{timeout:15000}).toBe('success');
      proof.afterReattachment=await sameOwner();
      assert.ok(proof.afterReattachment.messages.some(message=>message.text===proof.settledSummary));
      await save();
      await captureSettledOutcome(notice,proof.draft);
    }else if(changeTaskTransport){
      await expect(row).toBeVisible({timeout:20000});
      const refusal="server 'research' was reconfigured to a different transport since this task was created; refusing to re-bind so its task id cannot leak to the wrong server";
      await expect.poll(taskState,{timeout:20000}).toMatchObject({
        id:proof.mcpTask.id,status:'running',
        mcp:{serverTaskId:proof.mcpTask.mcp.serverTaskId,parked:true,statusMessage:refusal}
      });
      await expect.poll(async()=> (await readFrames(changedTaskPeerReceipts)).some(frame=>
        frame.direction==='in'&&frame.value.method==='server/discover'),{timeout:10000}).toBe(true);
      proof.afterTransportMismatch=await sameOwner();
      proof.transportMismatch=refusal;
      await taskDetails.click();
      for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
        await page.setViewportSize({width,height});
        await expect(details.getByText('Outcome unknown',{exact:true})).toBeInViewport({ratio:1});
        await expect(details.getByText(proof.mcpTask.mcp.serverTaskId,{exact:true})).toBeInViewport({ratio:1});
        await expect(details.getByText(refusal,{exact:true})).toBeVisible();
        await expect(stop).toBeInViewport({ratio:1});
        await expect(composer).toHaveText(proof.draft);
        const name='native-mcp-task-changed-transport-'+size+'.png';
        await page.screenshot({path:join(output,name),animations:'disabled'});
        proof.captures.push(name);
        await save();
      }
      await details.getByRole('button',{name:'Close',exact:true}).click();
    }else{
      await expect(row).toBeVisible({timeout:20000});
      proof.reattached=await sameOwner();
      const restored=proof.reattached.native.state.tasks.find(task=>task.id===proof.mcpTask.id);
      assert.equal(restored?.mcp.serverTaskId,proof.mcpTask.mcp.serverTaskId);
      await expect.poll(async()=> (await readFrames(receipts)).slice(proof.framesAfterPark.length).some(frame=>
        frame.direction==='out'&&frame.value.result?.taskId===proof.mcpTask.mcp.serverTaskId
          &&frame.value.result.status==='working'),{timeout:20000}).toBe(true);
      await taskDetails.click();
      const originalId=details.getByText(proof.mcpTask.mcp.serverTaskId,{exact:true});
      for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
        await page.setViewportSize({width,height});
        await expect(originalId).toBeInViewport({ratio:1});
        const name='native-mcp-task-resumed-'+size+'.png';
        await page.screenshot({path:join(output,name),animations:'disabled'});
        proof.captures.push(name);
        await save();
      }
      await details.getByRole('button',{name:'Close',exact:true}).click();
      await writeFile(taskFinish,'Allow the original parked task to finish.',{flag:'wx'});
      await expect(row).toHaveCount(0,{timeout:20000});
      await expect(composer).toHaveText(proof.draft);
      await expect.poll(async()=> (await sameOwner()).claude.chatState).toBe('success');
      proof.afterReattachment=await sameOwner();
      await save();
    }
  }else if(taskTransportDrop){
    proof.scope='A dropped MCP connection during an original working task; observe native disposition and desktop recovery.';
    await expect(row).toBeVisible();
    proof.beforeTransportDrop=await sameOwner();
    await expect.poll(async()=> (await readFrames(receipts)).some(frame=>frame.direction==='out'
      &&frame.value.result?.status==='working'&&!frame.value.result.resultType)).toBe(true);
    await writeFile(taskAdvanceRelease,'Disconnect the owned MCP stdio peer at its next status request.',{flag:'wx'});
    await expect.poll(async()=> (await readFrames(receipts)).some(frame=>frame.direction==='event'
      &&frame.value.event==='transport-disconnected')).toBe(true);
    proof.framesAfterTransportDrop=await readFrames(receipts);
    await expect.poll(taskState,{timeout:20000}).toMatchObject({
      id:proof.mcpTask.id,status:'running',mcp:{serverTaskId:proof.mcpTask.mcp.serverTaskId,statusMessage:'reconnecting…'}
    });
    proof.afterTransportDrop=await sameOwner();
    await taskDetails.click();
    const reconnecting=details.getByText('reconnecting…',{exact:true});
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      await expect(reconnecting).toBeInViewport({ratio:1});
      const name='native-mcp-task-disconnected-'+size+'.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
    await details.getByRole('button',{name:'Close',exact:true}).click();
    await expect(details).toHaveCount(0);
    await expect(taskDetails).toBeFocused();
    await expect(composer).toHaveText(proof.draft);
    await expect(composer).toBeInViewport();
    if(taskFinish){
      const oldTask=proof.mcpTask;
      const card=page.locator('[data-onboarding-id="agent-chat-input"]');
      const open=card.getByRole('button',{name:'Claude MCP servers',exact:true});
      if(await open.isVisible())await open.click();
      else{
        await card.getByRole('button',{name:'More actions',exact:true}).click();
        await page.getByRole('menuitem',{name:'Claude MCP servers',exact:true}).click();
      }
      const panel=page.getByRole('dialog',{name:'Native /mcp panel',exact:true});
      await expect(panel).toBeVisible();
      const terminal=panel.locator('[data-terminal-text]');
      const keyboard=panel.getByRole('textbox',{name:'Terminal input',exact:true});
      await expect(terminal).toContainText(/research/i);
      await keyboard.press('Enter');
      await expect(terminal).toContainText(/Research MCP Server/i);
      await expect(terminal).toContainText('Reconnect');
      proof.reconnectMenu=await terminal.innerText();
      const retryCapture='native-mcp-task-reconnect-menu-compact.png';
      await page.screenshot({path:join(output,retryCapture),animations:'disabled'});
      proof.captures.push(retryCapture);
      await save();
      if(proof.reconnectMenu.indexOf('View tools')>=0&&proof.reconnectMenu.indexOf('View tools')<proof.reconnectMenu.indexOf('Reconnect')){
        await keyboard.press('ArrowDown');
      }
      await keyboard.press('Enter');
      const resumedPoll=async()=> (await readFrames(receipts)).slice(proof.framesAfterTransportDrop.length)
        .some(frame=>frame.direction==='out'&&frame.value.result?.taskId===oldTask.mcp.serverTaskId
          &&frame.value.result.status==='working'&&!frame.value.result.resultType);
      await expect.poll(resumedPoll,{timeout:20000}).toBe(true);
      if(await panel.isVisible())await panel.getByRole('button',{name:'Close panel',exact:true}).click();
      await expect(panel).toBeHidden();
      await expect(composer).toHaveText(proof.draft);
      proof.reattached=await sameOwner();
      assert.ok(proof.reattached.native.state.tasks.some(task=>task.id===oldTask.id&&task.mcp.serverTaskId===oldTask.mcp.serverTaskId));
      await writeFile(taskFinish,'Allow the original recovered task to finish.',{flag:'wx'});
      await expect(row).toHaveCount(0,{timeout:20000});
      await expect(composer).toHaveText(proof.draft);
      await expect.poll(async()=> (await sameOwner()).claude.chatState).toBe('success');
      proof.afterReattachment=await sameOwner();
      await save();
    }
  }else{
    await taskDetails.click();
    await expect(details).toContainText('owned-review-1');
    await expect(details).toContainText('research');
    await expect(details).toContainText('review');
    await expect(details).toHaveText(/runs on the server/);
    proof.inspected=await details.innerText();
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      const serverId=details.getByText('owned-review-1',{exact:true});
      try{
        await expect(serverId).toBeInViewport({ratio:1});
        await expect(stop).toBeInViewport({ratio:1});
      }catch(error){
        const name='native-mcp-task-detail-failure-'+size+'.png';
        proof.detailFailure={size,name,details:await details.boundingBox(),serverId:await serverId.boundingBox(),
          stop:await stop.boundingBox(),composer:await composer.boundingBox()};
        await page.screenshot({path:join(output,name),animations:'disabled'});
        await save();
        throw error;
      }
      await expect(composer).toHaveText(proof.draft);
      await expect(composer).toBeInViewport();
      await expect(stop).toBeEnabled();
      const name='native-mcp-task-'+size+'.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
    await details.getByRole('button',{name:'Close',exact:true}).click();
    await expect(details).toHaveCount(0);
    await expect(taskDetails).toBeFocused();
    await expect(composer).toHaveText(proof.draft);
    await taskDetails.click();
    await expect(stop).toBeEnabled();
    proof.beforeStop=await sameOwner();
    await stop.click();
    await expect(row).toHaveCount(0);
    await expect(composer).toHaveText(proof.draft);
    proof.afterStop=await sameOwner();
    proof.framesAfterStop=await readFrames(receipts);
  }
  const calls=(proof.framesAfterInput??proof.framesAfterExpiry??proof.framesAfterTransportDrop??proof.framesAfterPark??proof.framesAfterStop).filter(row=>row.direction==='in'&&row.value.method==='tools/call');
  assert.equal(calls.length,1);
  assert.deepEqual(calls[0].value.params.arguments,{scenario});
  proof.followup=changeTaskTransport?'Continue the release notes without retrying the task on the replacement server.':taskPark?'Continue the release notes after reopening the same conversation.':taskFinish?'Continue the release notes after the original task reconnects.':taskTransportDrop?'Continue the release notes without the disconnected tool.':staleTaskInput?'Continue the release notes after the task disappeared.':scenario==='input'?(taskInputAction==='accept'?'Continue the release notes with the confirmed MCP task.'
    :'Continue the release notes without answering the MCP task.')
    :scenario==='expired'?'Continue checking the release notes without rerunning the MCP task.'
    :'Continue the release notes after I stop the MCP task.';
  await replace(proof.followup);
  await send.click();
  await expect.poll(async()=>{
    const current=await sameOwner();
    const isFollowup=message=>
      message.sender==='user'&&message.text===proof.followup&&message.context?.cliUuid;
    if(current.messages.filter(isFollowup).length!==1)return false;
    if(changeTaskTransport||taskTransportDrop&&!taskFinish){
      if(changeTaskTransport&&current.claude.totalCostUsd<=proof.afterTransportMismatch.claude.totalCostUsd)return false;
      return current.messages.slice(current.messages.findIndex(isFollowup)+1).some(message=>
        message.sender==='assistant'&&message.text==='Fixture completed.'&&message.context?.cliUuid);
    }
    const priorCost=proof.afterCompletion?.claude.totalCostUsd??proof.afterReattachment?.claude.totalCostUsd;
    return current.claude.chatState==='success'&&(priorCost===undefined||current.claude.totalCostUsd>priorCost);
  },{timeout:20000}).toBe(true);
  proof.final=await sameOwner();
  if(taskTransportDrop&&!taskFinish){
    await expect(row).toBeVisible();
    assert.ok(proof.final.native.state.tasks.some(task=>task.id===proof.mcpTask.id&&task.status==='running'));
    assert.match(proof.final.claude.chatState,/^(working|success)$/);
  }
  if(scenario==='expired'||staleTaskInput){
    const notices=proof.final.messages.filter(message=>message.text===proof.visibleUnknown);
    assert.equal(notices.length,1);
    assert.equal(notices[0].sender,'system');
  }
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(()=>birth(activePid),{timeout:15000}).toBe(null);
  proof.status='complete';
  await save();
  phase('native-mcp-task-desktop-complete');
}
