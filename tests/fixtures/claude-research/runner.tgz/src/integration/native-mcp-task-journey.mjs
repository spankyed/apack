import assert from 'node:assert/strict';
import {readFile,readdir,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {findOwnedBroker} from './native-terminal-broker-loss-journey.mjs';
import {readNativeTranscriptRow} from './native-transcript-evidence.mjs';

export const mcpTaskPrompt = 'Start the release review task on the MCP server.';

async function readFrames(path) {
  const text = await readFile(path,'utf8').catch(error=>{
    if (error.code==='ENOENT') return '';
    throw error;
  });
  return text.slice(0,text.lastIndexOf('\n')+1).split('\n').filter(Boolean).map(JSON.parse);
}

/** Inspect and stop a legitimately admitted task through the captured desktop controls. */
export async function driveMcpTaskJourney({page,expect,context,composer,send,section,replace,proof,output,receipts,scenario,mcpTaskDetailsDuringInput,mcpTaskUrlInput,taskInputAction,staleTaskInput,mcpTaskSecondInput,mcpTaskLongFollowup,mcpTaskUpdateExhaustion,mcpTaskCompletionNotice,taskTransportDrop,taskAutoReattach,taskPark,taskFinish,taskAdvanceRelease,lateTaskReplyPath,taskBrokerLoss,changeTaskTransport,changedTaskPeerReceipts,settledTaskState,workspace,model,birth,save,phase}) {
  let owner=proof.initial.native.state, activePid=proof.pid, activeStart=proof.processStart;
  const sameOwner = async () => {
    const current=await context(), native=current.native?.state;
    assert.equal(current.threadId,proof.initial.threadId);
    assert.equal(current.claude.sessionId,proof.sessionId);
    assert.equal(native?.sessionId,proof.sessionId);
    assert.equal(native?.ownerId,owner.ownerId);
    assert.equal(native?.nativePid,activePid);
    assert.equal(await birth(activePid),activeStart);
    return current;
  };
  const visibleOutcome=async summary=>{
    const storedNotices=async()=> (await sameOwner()).messages.filter(message=>message.text===summary);
    await expect.poll(async()=> (await storedNotices()).map(message=>message.sender),{timeout:15000}).toEqual(['system']);
    const [storedNotice]=await storedNotices();
    const messageRow=page.locator('[data-message-id="'+storedNotice.id+'"]');
    const notice=messageRow.getByText(summary,{exact:true}).and(page.locator(':visible'));
    await expect(notice).toHaveCount(1);
    await expect(page.getByText(/calling the tool again may repeat the work/i)).toHaveCount(0);
    return notice;
  };
  const taskState=async()=> (await sameOwner()).native.state.tasks.find(task=>task.kind==='mcp');
  async function captureSettledOutcome(notice,draft){
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      await expect(composer).toBeInViewport({ratio:1});
      await expect(send).toBeInViewport({ratio:1});
      await expect(composer).toHaveText(draft);
      const geometry=await readNativeTranscriptRow(page,expect,notice,{checkTextHit:true});
      const name='native-mcp-task-settled-resume-'+size+'.png';
      await page.screenshot({path:join(output,name)});
      (proof.settledNoticeGeometry??=[]).push({size,geometry});
      proof.captures.push(name);
      await save();
    }
  }

  proof.mcpTaskScenario=scenario;
  proof.scope='Original MCP background task, desktop details and local Stop. Server cancellation is reported from the original wire.';
  await replace(mcpTaskPrompt);
  await send.click();

  const approval=page.getByRole('region',{name:'mcp__research__review approval',exact:true});
  const allow=approval.getByRole('button',{name:'Yes',exact:true});
  await expect(allow).toBeEnabled();
  const pending=(await sameOwner()).claude.pendingControlRequest;
  assert.equal(pending.toolName,'mcp__research__review');
  assert.equal(pending.nativeTerminal.ownerId,owner.ownerId);
  assert.deepEqual(pending.originalInput,{scenario});
  assert.ok(!(await readFrames(receipts)).some(row=>row.direction==='in'&&row.value.method==='tools/call'));
  proof.approval={messageId:pending.approvalMessageId,ownerId:owner.ownerId,sessionId:proof.sessionId};
  await page.setViewportSize({width:680,height:600});
  await expect(allow).toBeInViewport({ratio:1});
  await page.screenshot({path:join(output,'native-mcp-task-approval-compact.png'),animations:'disabled'});
  proof.captures.push('native-mcp-task-approval-compact.png');
  await allow.click();
  await expect(approval).toHaveCount(0);
  await save();

  await expect.poll(taskState,{timeout:20000}).toMatchObject({mcp:{serverName:'research',serverTaskId:'owned-review-1'}});
  proof.mcpTask=await taskState();
  assert.notEqual(proof.mcpTask.id,proof.mcpTask.mcp.serverTaskId);
  const activity=page.getByRole('region',{name:'MCP tasks',exact:true});
  const row=activity.locator('[data-native-mcp-task-id="'+proof.mcpTask.id+'"]');
  const taskDetails=row.getByRole('button',{name:'Task details',exact:true});
  const details=page.getByRole('dialog',{name:'MCP task details',exact:true});
  const stop=details.getByRole('button',{name:'Stop task',exact:true});
  proof.draft='Keep these release notes while I check the task.';
  await replace(proof.draft);
  if(scenario==='input'){
    proof.taskInputAction=taskInputAction;
    if(staleTaskInput) proof.scope='Original mounted form submitted after the peer forgot its task.';
    else proof.scope='Original MCP background task form '+taskInputAction+', task retirement and same-session continuation.';
    const form=page.getByTestId(mcpTaskUrlInput?'native-mcp-url':'native-mcp-form');
    const submit=form.getByRole('button',{name:mcpTaskUrlInput?'Decline':'Submit',exact:true});
    const field=mcpTaskUrlInput?submit:form.getByRole('combobox',{name:'confirmed',exact:false});
    if(mcpTaskDetailsDuringInput){
      proof.scope='Open MCP task details when the original task asks for input.';
      await taskDetails.click();
      await expect(details).toBeVisible();
    }
    await writeFile(taskAdvanceRelease,'Allow the owned MCP server to ask for input.',{flag:'wx'});
    await expect(form).toContainText(mcpTaskUrlInput?'Review the task in the browser.':'Confirm the owned task review.',{timeout:20000});
    if(mcpTaskDetailsDuringInput){
      const modal=page.locator('dialog[aria-label="MCP task details"]:modal');
      await expect(modal).toHaveCount(0);
      await expect(form).toBeFocused();
      await expect(taskDetails).toBeDisabled();
      await page.keyboard.press('Tab');
      if(mcpTaskUrlInput)await expect(form.getByRole('button').and(page.locator(':focus'))).toHaveCount(1);
      else await expect(field).toBeFocused();
      proof.focusMovedToForm=true;
      if(mcpTaskUrlInput){
        await expect(form).toContainText('https://example.invalid/release-review');
        proof.taskUrlRequest=(await sameOwner()).native.state.mcpUrl;
        assert.equal(proof.taskUrlRequest.sessionId,proof.sessionId);
      }
      for(const [width,height] of [[1100,900],[680,600]]){
        await page.setViewportSize({width,height});
        await expect(composer).toHaveText(proof.draft);
        await submit.click({trial:true,timeout:5000});
      }
    }
    const formGeometry=()=>form.evaluate(element=>{
      const region=element.querySelector('.content'),footer=element.querySelector('footer');
      const rect=element.getBoundingClientRect(),actions=footer.getBoundingClientRect();
      return {height:rect.height,bodyHeight:region.clientHeight,scrollHeight:region.scrollHeight,
        scrollTop:region.scrollTop,footerTop:actions.top,footerBottom:actions.bottom,gapBelowFooter:rect.bottom-actions.bottom};
    });
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      await expect(field).toBeInViewport({ratio:1});
      await expect(submit).toBeInViewport({ratio:1});
      if(mcpTaskLongFollowup){
        await expect(composer).toBeInViewport({ratio:1});
        const geometry=await formGeometry();
        assert.ok(geometry.height<220&&geometry.gapBelowFooter<3);
        assert.equal(geometry.scrollHeight,geometry.bodyHeight);
        (proof.shortFormGeometry??=[]).push({size,...geometry});
      }
      const name=(mcpTaskUrlInput?'native-mcp-task-url-input-':'native-mcp-task-input-')+size+'.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
    if(mcpTaskSecondInput){
      proof.scope='Two native MCP forms for the same task with a stale accept from the first form.';
      await page.evaluate(()=>{
        const system=window.applicationState.system;
        const capture={events:[],stop:()=>{}};
        const sub=system.inspect(event=>{
          if(event.type==='@xstate.event'&&event.event?.type==='CLAUDE_TERMINAL_MCP_FORM'&&event.event.request?.action.operation==='accept')
            capture.events.push(event.event);
        });
        capture.stop=()=>sub.unsubscribe();
        window.__ownedMcpFormEvents=capture;
      });
    }
    const firstRevision=mcpTaskUpdateExhaustion?(await sameOwner()).native.state.mcpForm?.revision:undefined;
    if(taskInputAction==='accept'){
      await field.selectOption('true');
      await submit.click();
    }else{
      const label=taskInputAction==='decline'?'Decline':'Cancel';
      const action=form.getByRole('button',{name:label,exact:true});
      await expect(action).toBeInViewport({ratio:1});
      await action.click();
    }
    if(mcpTaskSecondInput){
      await expect(form).toContainText('Confirm the follow-up review.',{timeout:20000});
      const firstAction=await page.evaluate(()=>{
        const capture=window.__ownedMcpFormEvents;capture.stop();
        delete window.__ownedMcpFormEvents;
        return capture.events.at(0);
      });
      assert.equal(firstAction?.request.action.operation,'accept');
      const replacement=(await sameOwner()).native.state.mcpForm;
      assert.ok(replacement&&replacement.revision!==firstAction.request.revision);
      proof.replacementForm={oldRevision:firstAction.request.revision,newRevision:replacement.revision};
      await page.evaluate(event=>{
        window.applicationState.system.get('default-setup/threads').send({...event,sequence:event.sequence+1});
      },firstAction);
      await expect(submit).toBeEnabled();
      await expect(form.getByRole('alert')).toHaveCount(0);
      for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
        await page.setViewportSize({width,height});
        await expect(field).toBeInViewport({ratio:1});
        await expect(submit).toBeInViewport({ratio:1});
        if(mcpTaskLongFollowup){
          const last=form.getByRole('textbox',{name:'Review note 12',exact:true});
          await expect(last).toBeVisible();
          const scroll=form.locator('.content');
          const before=await formGeometry();
          assert.ok(before.scrollHeight>before.bodyHeight&&before.scrollTop===0);
          await scroll.hover();
          await page.mouse.wheel(0,1600);
          await expect(last).toBeInViewport({ratio:1});
          await expect(submit).toBeInViewport({ratio:1});
          await expect(composer).toBeInViewport({ratio:1});
          const after=await formGeometry();
          assert.ok(after.scrollTop>0);
          assert.equal(after.footerTop,before.footerTop);
          assert.equal(after.footerBottom,before.footerBottom);
          (proof.longFormGeometry??=[]).push({size,before,after});
          const scrolled='native-mcp-task-long-form-scrolled-'+size+'.png';
          await page.screenshot({path:join(output,scrolled),animations:'disabled'});
          proof.captures.push(scrolled);
          await page.mouse.wheel(0,-1600);
          await expect(field).toBeInViewport({ratio:1});
          await expect.poll(async()=> (await formGeometry()).scrollTop).toBe(0);
        }
        const name='native-mcp-task-followup-input-'+size+'.png';
        await page.screenshot({path:join(output,name),animations:'disabled'});
        proof.captures.push(name);
      }
      assert.equal((await readFrames(receipts)).filter(frame=>frame.direction==='in'&&frame.value.method==='tasks/update').length,1);
      const beforeFreshEdit=await sameOwner();
      assert.equal(beforeFreshEdit.native.mcpOperation,undefined);
      proof.replacementForm.staleReplayLeftNoOperation=true;
      await field.selectOption('false');
      await submit.click();
    }
    if(mcpTaskUpdateExhaustion){
      proof.scope='Native retries of an MCP task answer exhaust while its status requests still succeed.';
      assert.ok(firstRevision);
      await expect.poll(async()=>{
        const shown=(await sameOwner()).native.state.mcpForm;
        return Boolean(shown&&shown.revision!==firstRevision&&shown.ready);
      },{timeout:25000}).toBe(true);
      await field.selectOption('true');
      await submit.click();
      await expect(form).toHaveCount(0);
      await expect.poll(async()=> (await taskState())?.mcp,{timeout:25000}).toMatchObject({
        parked:true,serverTaskId:proof.mcpTask.mcp.serverTaskId,
        statusMessage:expect.stringContaining('the answer was never delivered'),
      });
      const parked=await taskState();
      proof.unreachableTaskAnswer=parked.mcp.statusMessage;
      await taskDetails.click();
      const explanation=details.getByText(proof.unreachableTaskAnswer,{exact:true});
      for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
        await page.setViewportSize({width,height});
        await expect(details.getByText('Outcome unknown',{exact:true})).toBeVisible();
        await expect(details.getByText('Polling',{exact:true})).toHaveCount(0);
        await explanation.scrollIntoViewIfNeeded();
        await expect(explanation).toBeInViewport();
        const name='native-mcp-task-undelivered-answer-'+size+'.png';
        await page.screenshot({path:join(output,name),animations:'disabled'});
        proof.captures.push(name);
      }
      await details.getByRole('button',{name:'Close',exact:true}).click();
      await save();
    }else{
      await expect(form).toHaveCount(0);
    }
    if(staleTaskInput){
      await expect(row).toHaveCount(0,{timeout:25000});
    }else if(!mcpTaskUpdateExhaustion){
      await expect(row).toHaveCount(0);
    }
    await expect(composer).toHaveText(proof.draft);
    proof.afterInput=await sameOwner();
    proof.framesAfterInput=await readFrames(receipts);
    const updates=proof.framesAfterInput.filter(row=>row.direction==='in'&&row.value.method==='tasks/update');
    assert.equal(updates.length,mcpTaskUpdateExhaustion?10:mcpTaskSecondInput?2:1);
    const answer=taskInputAction==='accept'?{action:'accept',content:{confirmed:true}}:{action:taskInputAction};
    assert.deepEqual(updates[0].value.params.inputResponses,{'review-input':answer});
    assert.equal(updates[0].value.params.taskId,proof.mcpTask.mcp.serverTaskId);
    if(mcpTaskUpdateExhaustion){
      for(const {value} of updates){
        assert.deepEqual(value.params.inputResponses,{'review-input':answer});
        assert.equal(value.params.taskId,proof.mcpTask.mcp.serverTaskId);
        assert.equal(proof.framesAfterInput.find(frame=>frame.direction==='out'&&frame.value.id===value.id)?.value.error?.code,-32603);
      }
    }
    if(mcpTaskSecondInput){
      assert.deepEqual(updates[1].value.params.inputResponses,{'review-followup':{action:'accept',content:{confirmed:false}}});
      assert.equal(updates[1].value.params.taskId,proof.mcpTask.mcp.serverTaskId);
    }
    if(staleTaskInput){
      const reply=proof.framesAfterInput.find(frame=>frame.direction==='out'&&frame.value.id===updates[0].value.id);
      assert.equal(reply?.value.error?.code,-32602);
      assert.equal(reply.value.result,undefined);
      const summary='MCP task '+proof.mcpTask.mcp.serverTaskId+' (research/review) expired on the server: outcome unknown.';
      const notice=await visibleOutcome(summary);
      await notice.scrollIntoViewIfNeeded();
      await expect(notice).toBeInViewport({ratio:1});
      await expect(composer).toBeInViewport();
      proof.visibleUnknown=summary;
      const name='native-mcp-task-stale-result-compact.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
    if(mcpTaskCompletionNotice){
      const summary='MCP task '+proof.mcpTask.mcp.serverTaskId+' (research/review) completed.';
      const notice=await visibleOutcome(summary);
      proof.visibleCompletion=summary;
      await expect.poll(async()=>{
        const state=await sameOwner();
        const index=state.messages.findIndex(message=>message.sender==='system'&&message.text===summary);
        return index>=0&&!state.native.state.busy&&state.claude.chatState==='success'&&state.messages.slice(index+1)
          .some(message=>message.sender==='assistant'&&message.text==='Fixture completed.'&&message.context?.cliUuid);
      },{timeout:20000}).toBe(true);
      proof.afterCompletion=await sameOwner();
      for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
        await page.setViewportSize({width,height});
        await readNativeTranscriptRow(page,expect,notice,{checkTextHit:mcpTaskLongFollowup});
        await expect(composer).toBeInViewport();
        await expect(composer).toHaveText(proof.draft);
        const name='native-mcp-task-completed-'+size+'.png';
        await page.screenshot({path:join(output,name),animations:'disabled'});
        proof.captures.push(name);
        await save();
      }
    }
  }else if(scenario==='expired'){
    proof.scope='Original MCP task expiry and outcome-unknown reporting without a replacement tool call.';
    await expect(row).toBeVisible();
    await writeFile(taskAdvanceRelease,'Allow the owned MCP server to expire the task.',{flag:'wx'});
    const unknown=()=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>
      Array.isArray(message.content)?message.content:[]).find(block=>
        block.type==='text'&&block.text.includes('<task-id>'+proof.mcpTask.id+'</task-id>')
          &&block.text.includes('Task outcome unknown:'));
    await expect.poll(()=>!!unknown(),{timeout:25000}).toBe(true);
    await expect(row).toHaveCount(0);
    proof.unknownNotification=unknown().text;
    await expect(composer).toHaveText(proof.draft);
    proof.framesAfterExpiry=await readFrames(receipts);
    const summary=/<summary>([^<]+)<\/summary>/.exec(proof.unknownNotification)?.[1];
    assert.ok(summary?.endsWith(': outcome unknown.'));
    const notice=await visibleOutcome(summary);
    proof.visibleUnknown=summary;
    proof.afterExpiry=await sameOwner();
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      await expect(composer).toHaveText(proof.draft);
      await expect(composer).toBeInViewport();
      await notice.scrollIntoViewIfNeeded();
      await expect(notice).toBeInViewport({ratio:1});
      const name='native-mcp-task-expired-'+size+'.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
  }else if(taskPark){
    proof.scope='Park an original running MCP task across a native process exit and resume the same conversation.';
    await expect(row).toBeVisible();
    await expect.poll(async()=> (await readFrames(receipts)).some(frame=>
      frame.direction==='out'&&frame.value.result?.taskId===proof.mcpTask.mcp.serverTaskId
        &&frame.value.result.status==='working'&&!frame.value.result.resultType)).toBe(true);
    if(lateTaskReplyPath){
      proof.scope='Retire a native owner during an HTTP task poll, then reject its delayed result after owner replacement.';
      await writeFile(taskAdvanceRelease,'Hold the next original HTTP poll across owner retirement.',{flag:'wx'});
      const held=async()=> (await readFrames(receipts)).find(frame=>frame.value.event==='retired-poll-held')?.value;
      await expect.poll(held,{timeout:15000}).toMatchObject({taskId:proof.mcpTask.mcp.serverTaskId});
      proof.retiredPoll={held:await held()};
      await save();
    }
    proof.beforePark=await sameOwner();
    const useNative=section.getByRole('button',{name:'Use native interface',exact:true});
    const snapshotDraft=()=>composer.evaluate(element=>{
      const {doc,selection}=element.editor.state;
      return {doc:doc.toJSON(),selection:selection.toJSON()};
    });
    if(taskBrokerLoss){
      proof.scope='Abrupt loss of the private apack-terminal broker during a held HTTP poll, followed by same-session task recovery.';
      await composer.press('Home');
      await composer.press('Shift+ArrowRight');
      const draft=await snapshotDraft();
      assert.notEqual(draft.selection.anchor,draft.selection.head);
      const broker=await findOwnedBroker(activePid);
      assert.equal(await birth(activePid),activeStart);
      assert.equal(await birth(broker.pid),broker.start);
      proof.taskBrokerLoss={broker,draft};
      await save();
      process.kill(broker.pid,'SIGKILL');
      await expect.poll(()=>birth(broker.pid),{timeout:15000}).toBe(null);
      await expect.poll(async()=> (await context()).native.state.status,{timeout:15000}).toBe('error');
    }else{
      await useNative.click();
      await section.getByRole('button',{name:'Stop session',exact:true}).click();
    }
    await expect.poll(()=>birth(activePid),{timeout:15000}).toBe(null);
    if(taskBrokerLoss){
      await expect(section.getByRole('status')).toContainText('disconnected unexpectedly');
      const disconnected=await context();
      assert.equal(disconnected.threadId,proof.beforePark.threadId);
      assert.equal(disconnected.claude.sessionId,proof.sessionId);
      assert.deepEqual(disconnected.messages,proof.beforePark.messages);
      assert.equal(disconnected.claude.totalCostUsd,proof.beforePark.claude.totalCostUsd);
      assert.deepEqual(await snapshotDraft(),proof.taskBrokerLoss.draft);
      proof.taskBrokerLoss.retired=true;
      for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
        await page.setViewportSize({width,height});
        await expect(composer).toBeInViewport();
        await expect(useNative).toBeInViewport({ratio:1});
        const name='native-mcp-task-broker-loss-'+size+'.png';
        await page.screenshot({path:join(output,name),animations:'disabled'});
        proof.captures.push(name);
      }
    }
    const projects=join(workspace,'.claude/projects');
    const paths=(await readdir(projects,{recursive:true})).filter(path=>
      path.endsWith('/'+proof.sessionId+'/mcp-tasks/mcp-task-'+proof.mcpTask.id+'.meta.json'));
    assert.equal(paths.length,1,'Native MCP task metadata must survive owner exit');
    proof.parkedNativeSidecar=JSON.parse(await readFile(join(projects,paths[0]),'utf8'));
    assert.equal(proof.parkedNativeSidecar.taskId,proof.mcpTask.id);
    assert.equal(proof.parkedNativeSidecar.mcpTaskId,proof.mcpTask.mcp.serverTaskId);
    if(lateTaskReplyPath){
      const closed=async()=> (await readFrames(receipts)).find(frame=>frame.value.event==='retired-poll-closed')?.value;
      await expect.poll(closed).toMatchObject({id:proof.retiredPoll.held.id,taskId:proof.retiredPoll.held.taskId});
      proof.retiredPoll.closed=await closed();
    }
    proof.framesAfterPark=await readFrames(receipts);
    await save();
    if(changeTaskTransport){proof.changedTransport=await changeTaskTransport();await save();}
    if(settledTaskState){
      const working=JSON.parse(await readFile(settledTaskState.path,'utf8'));
      assert.equal(working.status,'working');
      assert.equal(working.taskId,proof.mcpTask.mcp.serverTaskId);
      // Persist the simulated server result while the original writer is retired.
      assert.equal(await birth(activePid),null);
      const settled={...working,status:settledTaskState.outcome,lastUpdatedAt:new Date().toISOString()};
      await writeFile(settledTaskState.path,JSON.stringify(settled));
      proof.settledWhileStopped={working,settled,ownerRetired:true};
      await save();
    }
    const back=section.getByRole('button',{name:'Back to conversation',exact:true});
    if(await back.isVisible())await back.click();
    await expect(composer).toHaveText(proof.draft);
    if(settledTaskState){proof.reopenRequestedAt=new Date().toISOString();await save();}
    await section.getByRole('button',{name:'Use native interface',exact:true}).click();
    await expect.poll(async()=>{
      const candidate=(await context()).native?.state;
      return candidate?.status==='live'&&!!candidate.nativePid&&candidate.nativePid!==proof.pid;
    },{timeout:25000}).toBe(true);
    const resumed=await context();
    owner=resumed.native.state;
    activePid=owner.nativePid;
    activeStart=await birth(activePid);
    proof.resumedWriter={pid:activePid,start:activeStart,ownerId:owner.ownerId};
    await save();
    assert.ok(activeStart);
    assert.notEqual(activePid,proof.pid);
    assert.notEqual(owner.ownerId,proof.initial.native.state.ownerId);
    if(taskBrokerLoss){
      const freshBroker=await findOwnedBroker(activePid);
      assert.equal(freshBroker.socket,proof.taskBrokerLoss.broker.socket);
      assert.notDeepEqual(freshBroker,proof.taskBrokerLoss.broker);
      proof.taskBrokerLoss.freshBroker=freshBroker;
    }
    await back.click();
    await expect(composer).toHaveText(proof.draft);
    if(taskBrokerLoss)assert.deepEqual(await snapshotDraft(),proof.taskBrokerLoss.draft);
    if(lateTaskReplyPath){
      await writeFile(lateTaskReplyPath,'Release the retired request after the replacement owner is live.',{flag:'wx'});
      const discarded=async()=> (await readFrames(receipts)).find(frame=>frame.value.event==='late-poll-reply-discarded')?.value;
      await expect.poll(discarded,{timeout:16000}).toMatchObject({id:proof.retiredPoll.held.id,taskId:proof.retiredPoll.held.taskId});
      proof.retiredPoll.discarded=await discarded();
      await save();
    }
    if(settledTaskState){
      proof.settledSummary=`MCP task ${proof.mcpTask.mcp.serverTaskId} (research/review) ${settledTaskState.outcome}.`;
      await expect.poll(async()=> (await readFrames(receipts)).slice(proof.framesAfterPark.length).some(frame=>
        frame.direction==='out'&&frame.value.result?.taskId===proof.mcpTask.mcp.serverTaskId
          &&frame.value.result.status===settledTaskState.outcome),{timeout:20000}).toBe(true);
      await expect(row).toHaveCount(0);
      await expect(composer).toHaveText(proof.draft);
      const notice=await visibleOutcome(proof.settledSummary);
      await expect.poll(async()=> (await sameOwner()).claude.chatState,{timeout:15000}).toBe('success');
      proof.afterReattachment=await sameOwner();
      assert.ok(proof.afterReattachment.messages.some(message=>message.text===proof.settledSummary));
      await save();
      await captureSettledOutcome(notice,proof.draft);
    }else if(changeTaskTransport){
      await expect(row).toBeVisible({timeout:20000});
      const refusal="server 'research' was reconfigured to a different transport since this task was created; refusing to re-bind so its task id cannot leak to the wrong server";
      await expect.poll(taskState,{timeout:20000}).toMatchObject({
        id:proof.mcpTask.id,status:'running',
        mcp:{serverTaskId:proof.mcpTask.mcp.serverTaskId,parked:true,statusMessage:refusal}
      });
      await expect.poll(async()=> (await readFrames(changedTaskPeerReceipts)).some(frame=>
        frame.direction==='in'&&frame.value.method==='server/discover'),{timeout:10000}).toBe(true);
      proof.afterTransportMismatch=await sameOwner();
      proof.transportMismatch=refusal;
      await taskDetails.click();
      for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
        await page.setViewportSize({width,height});
        await expect(details.getByText('Outcome unknown',{exact:true})).toBeInViewport({ratio:1});
        await expect(details.getByText(proof.mcpTask.mcp.serverTaskId,{exact:true})).toBeInViewport({ratio:1});
        await expect(details.getByText(refusal,{exact:true})).toBeVisible();
        await expect(stop).toBeInViewport({ratio:1});
        await expect(composer).toHaveText(proof.draft);
        const name='native-mcp-task-changed-transport-'+size+'.png';
        await page.screenshot({path:join(output,name),animations:'disabled'});
        proof.captures.push(name);
        await save();
      }
      await details.getByRole('button',{name:'Close',exact:true}).click();
    }else{
      await expect(row).toBeVisible({timeout:20000});
      proof.reattached=await sameOwner();
      const restored=proof.reattached.native.state.tasks.find(task=>task.id===proof.mcpTask.id);
      assert.equal(restored?.mcp.serverTaskId,proof.mcpTask.mcp.serverTaskId);
      await expect.poll(async()=> (await readFrames(receipts)).slice(proof.framesAfterPark.length).some(frame=>
        frame.direction==='out'&&frame.value.result?.taskId===proof.mcpTask.mcp.serverTaskId
          &&frame.value.result.status==='working'),{timeout:20000}).toBe(true);
      await taskDetails.click();
      const originalId=details.getByText(proof.mcpTask.mcp.serverTaskId,{exact:true});
      for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
        await page.setViewportSize({width,height});
        await expect(originalId).toBeInViewport({ratio:1});
        const name='native-mcp-task-resumed-'+size+'.png';
        await page.screenshot({path:join(output,name),animations:'disabled'});
        proof.captures.push(name);
        await save();
      }
      await details.getByRole('button',{name:'Close',exact:true}).click();
      await writeFile(taskFinish,'Allow the original parked task to finish.',{flag:'wx'});
      await expect(row).toHaveCount(0,{timeout:20000});
      await expect(composer).toHaveText(proof.draft);
      if(lateTaskReplyPath){
        const summary='MCP task '+proof.mcpTask.mcp.serverTaskId+' (research/review) completed.';
        proof.visibleCompletion=summary;
        await captureSettledOutcome(await visibleOutcome(summary),proof.draft);
        await expect.poll(async()=>{
          const state=await sameOwner();
          const index=state.messages.findIndex(message=>message.sender==='system'&&message.text===summary);
          return index>=0&&!state.native.state.busy&&state.claude.chatState==='success'&&state.messages.slice(index+1)
            .some(message=>message.sender==='assistant'&&message.text==='Fixture completed.'&&message.context?.cliUuid);
        },{timeout:20000}).toBe(true);
      }
      await expect.poll(async()=> (await sameOwner()).claude.chatState).toBe('success');
      proof.afterReattachment=await sameOwner();
      await save();
    }
  }else if(taskAutoReattach){
    proof.scope='Original automatic HTTP reconnection during a background MCP task.';
    const taskId=proof.mcpTask.mcp.serverTaskId;
    const frames=()=>readFrames(receipts);
    const working=frame=>frame.direction==='out'&&frame.value.result?.taskId===taskId
      &&frame.value.result.status==='working'&&!frame.value.result.resultType;
    await expect.poll(async()=> (await frames()).some(working)).toBe(true);
    await writeFile(taskAdvanceRelease,'Interrupt the next original HTTP task poll.',{flag:'wx'});
    const recovered=async()=>{
      const rows=await frames();
      const failure=rows.findIndex(frame=>frame.value.event==='malformed-poll-response'&&frame.value.taskId===taskId);
      if(failure<0)return false;
      const next=rows.slice(failure+1);
      const discovery=next.findIndex(frame=>frame.direction==='in'&&frame.value.method==='server/discover');
      return discovery>=0&&next.slice(discovery+1).some(working);
    };
    await expect.poll(recovered,{timeout:40000}).toBe(true);
    proof.framesAfterTransportDrop=await frames();
    proof.reattached=await sameOwner();
    assert.ok(proof.reattached.native.state.tasks.some(task=>task.id===proof.mcpTask.id&&task.mcp.serverTaskId===taskId));
    await expect(composer).toHaveText(proof.draft);
    await writeFile(taskFinish,'Allow the original HTTP task to finish.',{flag:'wx'});
    const summary='MCP task '+taskId+' (research/review) completed.';
    await expect(row).toHaveCount(0,{timeout:20000});
    proof.visibleCompletion=summary;
    await captureSettledOutcome(await visibleOutcome(summary),proof.draft);
    await expect.poll(async()=>{
      const state=await sameOwner();
      const index=state.messages.findIndex(message=>message.sender==='system'&&message.text===summary);
      return index>=0&&!state.native.state.busy&&state.claude.chatState==='success'&&state.messages.slice(index+1)
        .some(message=>message.sender==='assistant'&&message.text==='Fixture completed.'&&message.context?.cliUuid);
    },{timeout:20000}).toBe(true);
    proof.afterReattachment=await sameOwner();
    proof.autoReattachFrames=await frames();
    assert.equal(proof.autoReattachFrames.filter(frame=>frame.direction==='in'&&frame.value.method==='tools/call').length,1);
    assert.equal(proof.autoReattachFrames.filter(frame=>frame.direction==='in'&&frame.value.method==='tasks/cancel').length,0);
    assert.equal(proof.autoReattachFrames.filter(frame=>frame.direction==='out'&&frame.value.result?.taskId===taskId&&frame.value.result.status==='completed').length,1);
    await save();
  }else if(taskTransportDrop){
    proof.scope='A dropped MCP connection during an original working task; observe native disposition and desktop recovery.';
    await expect(row).toBeVisible();
    proof.beforeTransportDrop=await sameOwner();
    await expect.poll(async()=> (await readFrames(receipts)).some(frame=>frame.direction==='out'
      &&frame.value.result?.status==='working'&&!frame.value.result.resultType)).toBe(true);
    await writeFile(taskAdvanceRelease,'Disconnect the owned MCP stdio peer at its next status request.',{flag:'wx'});
    await expect.poll(async()=> (await readFrames(receipts)).some(frame=>frame.direction==='event'
      &&frame.value.event==='transport-disconnected')).toBe(true);
    proof.framesAfterTransportDrop=await readFrames(receipts);
    await expect.poll(taskState,{timeout:20000}).toMatchObject({
      id:proof.mcpTask.id,status:'running',mcp:{serverTaskId:proof.mcpTask.mcp.serverTaskId,statusMessage:'reconnecting…'}
    });
    proof.afterTransportDrop=await sameOwner();
    await taskDetails.click();
    const reconnecting=details.getByText('reconnecting…',{exact:true});
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      await expect(reconnecting).toBeInViewport({ratio:1});
      const name='native-mcp-task-disconnected-'+size+'.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
    await details.getByRole('button',{name:'Close',exact:true}).click();
    await expect(details).toHaveCount(0);
    await expect(taskDetails).toBeFocused();
    await expect(composer).toHaveText(proof.draft);
    await expect(composer).toBeInViewport();
    if(taskFinish){
      const oldTask=proof.mcpTask;
      const card=page.locator('[data-onboarding-id="agent-chat-input"]');
      const open=card.getByRole('button',{name:'Claude MCP servers',exact:true});
      if(await open.isVisible())await open.click();
      else{
        await card.getByRole('button',{name:'More actions',exact:true}).click();
        await page.getByRole('menuitem',{name:'Claude MCP servers',exact:true}).click();
      }
      const panel=page.getByRole('dialog',{name:'Native /mcp panel',exact:true});
      await expect(panel).toBeVisible();
      const terminal=panel.locator('[data-terminal-text]');
      const keyboard=panel.getByRole('textbox',{name:'Terminal input',exact:true});
      await expect(terminal).toContainText(/research/i);
      await keyboard.press('Enter');
      await expect(terminal).toContainText(/Research MCP Server/i);
      await expect(terminal).toContainText('Reconnect');
      proof.reconnectMenu=await terminal.innerText();
      const retryCapture='native-mcp-task-reconnect-menu-compact.png';
      await page.screenshot({path:join(output,retryCapture),animations:'disabled'});
      proof.captures.push(retryCapture);
      await save();
      if(proof.reconnectMenu.indexOf('View tools')>=0&&proof.reconnectMenu.indexOf('View tools')<proof.reconnectMenu.indexOf('Reconnect')){
        await keyboard.press('ArrowDown');
      }
      await keyboard.press('Enter');
      const resumedPoll=async()=> (await readFrames(receipts)).slice(proof.framesAfterTransportDrop.length)
        .some(frame=>frame.direction==='out'&&frame.value.result?.taskId===oldTask.mcp.serverTaskId
          &&frame.value.result.status==='working'&&!frame.value.result.resultType);
      await expect.poll(resumedPoll,{timeout:20000}).toBe(true);
      if(await panel.isVisible())await panel.getByRole('button',{name:'Close panel',exact:true}).click();
      await expect(panel).toBeHidden();
      await expect(composer).toHaveText(proof.draft);
      proof.reattached=await sameOwner();
      assert.ok(proof.reattached.native.state.tasks.some(task=>task.id===oldTask.id&&task.mcp.serverTaskId===oldTask.mcp.serverTaskId));
      await writeFile(taskFinish,'Allow the original recovered task to finish.',{flag:'wx'});
      await expect(row).toHaveCount(0,{timeout:20000});
      await expect(composer).toHaveText(proof.draft);
      await expect.poll(async()=> (await sameOwner()).claude.chatState).toBe('success');
      proof.afterReattachment=await sameOwner();
      await save();
    }
  }else{
    await taskDetails.click();
    await expect(details).toContainText('owned-review-1');
    await expect(details).toContainText('research');
    await expect(details).toContainText('review');
    await expect(details).toHaveText(/runs on the server/);
    proof.inspected=await details.innerText();
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600]]){
      await page.setViewportSize({width,height});
      const serverId=details.getByText('owned-review-1',{exact:true});
      try{
        await expect(serverId).toBeInViewport({ratio:1});
        await expect(stop).toBeInViewport({ratio:1});
      }catch(error){
        const name='native-mcp-task-detail-failure-'+size+'.png';
        proof.detailFailure={size,name,details:await details.boundingBox(),serverId:await serverId.boundingBox(),
          stop:await stop.boundingBox(),composer:await composer.boundingBox()};
        await page.screenshot({path:join(output,name),animations:'disabled'});
        await save();
        throw error;
      }
      await expect(composer).toHaveText(proof.draft);
      await expect(composer).toBeInViewport();
      await expect(stop).toBeEnabled();
      const name='native-mcp-task-'+size+'.png';
      await page.screenshot({path:join(output,name),animations:'disabled'});
      proof.captures.push(name);
      await save();
    }
    await details.getByRole('button',{name:'Close',exact:true}).click();
    await expect(details).toHaveCount(0);
    await expect(taskDetails).toBeFocused();
    await expect(composer).toHaveText(proof.draft);
    await taskDetails.click();
    await expect(stop).toBeEnabled();
    proof.beforeStop=await sameOwner();
    await stop.click();
    await expect(row).toHaveCount(0);
    await expect(composer).toHaveText(proof.draft);
    proof.afterStop=await sameOwner();
    proof.framesAfterStop=await readFrames(receipts);
  }
  const calls=(proof.framesAfterInput??proof.framesAfterExpiry??proof.framesAfterTransportDrop??proof.framesAfterPark??proof.framesAfterStop).filter(row=>row.direction==='in'&&row.value.method==='tools/call');
  assert.equal(calls.length,1);
  assert.deepEqual(calls[0].value.params.arguments,{scenario});
  proof.followup=changeTaskTransport?'Continue the release notes without retrying the task on the replacement server.':taskPark?'Continue the release notes after reopening the same conversation.':taskFinish?'Continue the release notes after the original task reconnects.':mcpTaskUpdateExhaustion?'Continue the release notes without rerunning the task whose answer was not delivered.':taskTransportDrop?'Continue the release notes without the disconnected tool.':staleTaskInput?'Continue the release notes after the task disappeared.':scenario==='input'?(taskInputAction==='accept'?'Continue the release notes with the confirmed MCP task.'
    :'Continue the release notes without answering the MCP task.')
    :scenario==='expired'?'Continue checking the release notes without rerunning the MCP task.'
    :'Continue the release notes after I stop the MCP task.';
  await replace(proof.followup);
  await send.click();
  await expect.poll(async()=>{
    const current=await sameOwner();
    const isFollowup=message=>
      message.sender==='user'&&message.text===proof.followup&&message.context?.cliUuid;
    if(current.messages.filter(isFollowup).length!==1)return false;
    if(changeTaskTransport||mcpTaskUpdateExhaustion||taskTransportDrop&&!taskFinish){
      if(changeTaskTransport&&current.claude.totalCostUsd<=proof.afterTransportMismatch.claude.totalCostUsd)return false;
      return current.messages.slice(current.messages.findIndex(isFollowup)+1).some(message=>
        message.sender==='assistant'&&message.text==='Fixture completed.'&&message.context?.cliUuid);
    }
    const priorCost=proof.afterCompletion?.claude.totalCostUsd??proof.afterReattachment?.claude.totalCostUsd;
    return current.claude.chatState==='success'&&(priorCost===undefined||current.claude.totalCostUsd>priorCost);
  },{timeout:20000}).toBe(true);
  proof.final=await sameOwner();
  if(taskTransportDrop&&!taskFinish){
    await expect(row).toBeVisible();
    assert.ok(proof.final.native.state.tasks.some(task=>task.id===proof.mcpTask.id&&task.status==='running'));
    assert.match(proof.final.claude.chatState,/^(working|success)$/);
  }
  if(scenario==='expired'||staleTaskInput){
    const notices=proof.final.messages.filter(message=>message.text===proof.visibleUnknown);
    assert.equal(notices.length,1);
    assert.equal(notices[0].sender,'system');
  }
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(()=>birth(activePid),{timeout:15000}).toBe(null);
  proof.status='complete';
  await save();
  phase('native-mcp-task-desktop-complete');
}
