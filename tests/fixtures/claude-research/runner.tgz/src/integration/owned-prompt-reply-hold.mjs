/** Hold only genuine, already-addressed composer read replies on an owned app page. */
export async function holdOwnedPromptReplies(page) {
  await page.evaluate(() => {
    const key = '__claudeResearchPromptReplyHold';
    if (window[key]) throw new Error('prompt reply hold already installed');
    const original = WebSocket.prototype.send;
    const held = [], receipts = [];
    let armed = false;
    function send(data) {
      if (!armed || typeof data !== 'string') return original.call(this, data);
      let frame;
      try { frame = JSON.parse(data); } catch { return original.call(this, data); }
      const messages = Array.isArray(frame) ? frame : [frame];
      const reads = messages.filter(message => message?.params?.path === 'bus.send'
        && message.params.input?.event?.type === 'CLAUDE_PROMPT_HOST_RESPONSE'
        && message.params.input.event.kind === 'read');
      if (!reads.length) return original.call(this, data);
      if (reads.length !== 1) throw new Error('multiple addressed read replies; cannot choose an owner');
      // tRPC batches independent operations. Forward all other operations now; preserve the
      // addressed operation (including its request id) and its original socket for later release.
      const forwarded = messages.filter(message => message !== reads[0]);
      const releaseData = forwarded.length ? JSON.stringify([reads[0]]) : data;
      if (forwarded.length) original.call(this, JSON.stringify(forwarded));
      armed = false;
      const event = reads[0].params.input.event;
      const receipt = { requestId: event.requestId, mountId: event.mountId, threadId: event.threadId,
        box: event.box, heldAt: Date.now(), releasedAt: undefined,
        transport: { originalFrame: data, releaseFrame: releaseData, forwardedOperations: forwarded.length } };
      receipts.push(receipt);
      held.push({ socket: this, data: releaseData, receipt });
    }
    WebSocket.prototype.send = send;
    window[key] = {
      arm() { if (armed) throw new Error('reply hold already armed'); armed = true; },
      receipts() { return receipts.map(receipt => ({ ...receipt })); },
      release(index) {
        const item = held[index];
        if (!item || item.receipt.releasedAt) throw new Error('no unreleased addressed reply');
        if (item.socket.readyState !== WebSocket.OPEN) throw new Error('original reply socket retired');
        original.call(item.socket, item.data);
        item.receipt.releasedAt = Date.now();
      },
      close() {
        if (WebSocket.prototype.send !== send) throw new Error('reply transport was replaced');
        WebSocket.prototype.send = original;
        delete window[key];
      },
    };
  });
  const call = (method, argument) => page.evaluate(({ method, argument }) => {
    const control = window.__claudeResearchPromptReplyHold;
    if (!control) throw new Error('prompt reply hold missing');
    return control[method](argument);
  }, { method, argument });
  return { arm: () => call('arm'), receipts: () => call('receipts'),
    release: index => call('release', index), close: () => call('close') };
}
