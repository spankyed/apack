"""Verify pinned ordinary background-composer evidence without executing the native target."""
import argparse, hashlib, json, subprocess, tarfile
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence', type=Path)
for name in ('product', 'research'):
    parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--' + name + '-commit', required=True)
a = parser.parse_args(); root = a.evidence.resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
def read(path):
    return json.loads(path.read_text())
def one(name):
    paths = list((root / 'records').rglob(name)); assert len(paths) == 1, (name, len(paths))
    return paths[0]
def inputs(file, repository, revision):
    commit = subprocess.check_output(['git', 'rev-parse', '--verify', '--end-of-options', revision + '^{commit}'], cwd=repository, text=True).strip()
    values = read(root / file); assert values
    for name, digest in values.items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        assert sha(subprocess.check_output(['git', 'show', commit + ':' + name], cwd=repository)) == digest, name
    return commit, len(values)
product, product_count = inputs('source-inputs.json', a.product, a.product_commit)
research, research_count = inputs('authored-inputs.json', a.research, a.research_commit)
before = read(root / 'compiled-before.json'); assert before == read(root / 'compiled-after.json')
boundary = read(root / 'offline-boundary.json')
assert boundary['networkDisabled'] and boundary['pinnedExecutableReadOnly'] and set(boundary['networks']) == {'none'}
assert boundary['memory'] == boundary['memorySwap'] == 6 * 1024**3 and boundary['nanoCpus'] == 2 * 10**9
manifest = read(one('manifest.json')); assert manifest['status'] == 'complete' and manifest['code'] == 0 and manifest['signal'] is None
frames = []
for line in one('stdout.bin').read_text().splitlines():
    try:
        value = json.loads(line)
    except json.JSONDecodeError:
        continue
    if value.get('evidence') == 'apack-native-terminal-owner-app':
        frames.append(value)
assert len(frames) == 1
frame = frames[0]
assert frame['nativeBackgroundComposerLayout'] and frame['nativeBackgroundSettledHandoff'] and not frame['nativeBackgroundConfirmation']
assert frame['realModelRequests'] == 0 and frame['targetSha256'] == '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
x = read(one('native-background-app-observation.json')); job = x['job']
measurements = x['backgroundCombinedLayout']
assert len(measurements) == 6 and {(m['stage'], m['size']) for m in measurements} == {(stage, size) for stage in ['live-parent-draft', 'draft', 'queued'] for size in ['normal', 'compact']}
def contained(box, clip):
    return box['left'] >= clip['left'] - 1 and box['right'] <= clip['right'] + 1 and box['top'] >= clip['top'] - 1 and box['bottom'] <= clip['bottom'] + 1
for m in measurements:
    viewport = {'left': 0, 'top': 0, 'right': m['viewport']['width'], 'bottom': m['viewport']['height']}
    assert m['text'] == x['retainedDraft'] and m['editor']['height'] >= 39 and m['textRects']
    for rect in m['textRects']:
        assert rect['hit'] and all(contained(rect, clip) for clip in [viewport] + m['clippingRects'])
    bg = m['background']
    assert bg['scrollHeight'] <= bg['clientHeight'] + 1 and bg['scrollTop'] == 0 and bg['title'] == bg['titleHint']
    assert contained(bg['card'], bg['panel'])
    names = {control['name'] for control in bg['controls']}
    assert {'Reply', 'Open session', 'Refresh status', 'Stop background session', 'Background session usage', 'Background Claude configured status', 'Send message', ''} <= names
    for control in bg['controls']:
        assert control['hit'] and contained(control, viewport) and contained(control, bg['panel'])
reply = x['childReply']; assert reply['workerBefore']['start'] == reply['workerAfter']['start'] == x['parentOwnerLoss']['beforeWorker']['start']
for snapshot in [reply['parentAfter'], x['current'], x['stopped']]:
    assert snapshot['sessionId'] == reply['parentBefore']['sessionId']
    assert snapshot['messages'] == reply['parentBefore']['messages']
    assert snapshot['claude']['totalCostUsd'] == reply['parentBefore']['claude']['totalCostUsd']
assert x['parentOwnerLoss']['parentProcessRetired'] and x['parentOwnerLoss']['parentPreserved'] and reply['remountDraftPreserved']
rows = [json.loads(line) for line in one(job['sessionId'] + '.jsonl').read_text().splitlines() if line]
assert rows[:len(reply['rows'])] == reply['rows']; by_id = {row['uuid']: row for row in rows if row.get('uuid')}
for text in [reply['replyText'], reply['retainedReply']]:
    humans = [row for row in rows if row.get('origin', {}).get('kind') == 'human' and row.get('message', {}).get('content') == text]
    assert len(humans) == 1
    def answered(row):
        if row.get('type') != 'assistant' or not any(block.get('type') == 'text' and block.get('text') for block in row.get('message', {}).get('content', [])):
            return False
        parent = row.get('parentUuid'); seen = set()
        while parent and parent not in seen:
            if parent == humans[0]['uuid']:
                return True
            seen.add(parent); previous = by_id.get(parent, {})
            if previous.get('origin', {}).get('kind') == 'human':
                return False
            parent = previous.get('parentUuid')
        return False
    assert any(answered(row) for row in rows)
assert x['childPidRetired'] and x['childStatus']['retiredAfterStop'] and x['independentStatusAuthority']['retiredAfterChildStop']
assert any(row['id'] == job['id'] and row['state'] == 'stopped' for row in x['after'])
info = x['childFormatter']['afterReturn']; normalize = lambda text: '\n'.join(line.strip() for line in text.strip().split('\n') if line.strip())
helpers = [json.loads(line) for line in one('background-formatter-helper.jsonl').read_text().splitlines()]
assert info['sessionId'] == job['sessionId'] and info['pid'] == job['pid'] and info['observedAt'] > x['parentOwnerLoss']['closedAt']
assert any(row['sessionId'] == job['sessionId'] and row['at'] > x['parentOwnerLoss']['closedAt'] and normalize(row['stdout']) == info['statusLine'] for row in helpers)
compiled = {name.split('/packages/default-setup/dist/')[1]: digest for name, digest in before['files'].items() if '/packages/default-setup/dist/runtime/' in name}; installed = set()
with tarfile.open(root / 'raw-evidence.tgz') as archive:
    for member in archive:
        if member.isfile() and '/packs/default-setup/runtime/' in member.name:
            name = member.name.split('/packs/default-setup/')[1]; assert sha(archive.extractfile(member).read()) == compiled[name]; installed.add(name)
assert {name for name in compiled if not name.endswith('.map')} <= installed
review = read(root / 'visual-review.json'); assert len(review['captures']) == 8
for stage in ['live-parent-draft', 'reply-draft', 'reply-queued', 'stopped']:
    for size in ['normal', 'compact']:
        matches = [item for item in review['captures'] if Path(item['path']).name == 'apack-native-background-' + stage + '-' + size + '.png']
        assert len(matches) == 1 and matches[0]['opened']
        path = (root / matches[0]['path']).resolve(); assert path.is_relative_to(root) and sha(path.read_bytes()) == matches[0]['sha256']
telemetry = [json.loads(line) for line in (root / 'memory-telemetry.jsonl').read_text().splitlines()]; assert telemetry
for row in telemetry:
    events = dict(line.split() for line in row['memory.events'].splitlines()); assert int(events['oom']) == int(events['oom_kill']) == 0
models = read(one('model-calls.json')); count = len(models['seed']) + len(models['agent']); assert count == 14
report = {'status': 'scoped-ordinary-composer-layout-accepted', 'verifierSha256': sha(Path(__file__).read_bytes()), 'productCommit': product, 'researchCommit': research, 'productInputsVerified': product_count, 'researchInputsVerified': research_count, 'compiledFilesUnchanged': len(before['files']), 'installedRuntimeFilesVerified': len(installed), 'noScrollReadings': 6, 'hitTestedControlsPerReading': 9, 'bothNativeRepliesAndResponses': True, 'parentDraftHistoryCostAndWorkerPreserved': True, 'uiStopAndAuthorityRetirement': True, 'reviewedCaptures': 8, 'syntheticModelRequests': count, 'realModelRequests': 0, 'memoryPeakBytes': max(int(row['memory.peak']) for row in telemetry), 'oom': False, 'limits': ['Ordinary settled handoff only. The separate busy-warning journey timed out and is not claimed reaccepted.', 'Long/rich notes, manual resize extremes, other owners/policy/media and original combined F1–F5 remain open.']}
(root / 'layout-verification.json').write_text(json.dumps(report, indent=2) + '\n'); print(json.dumps(report))
