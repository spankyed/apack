import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from '../protocol/record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';
export async function probeSkillManagementApp(checkout,executable,root,output,{retained=false}={}){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'skill-management-app-'));
 await mkdir(join(workspace,'.claude'),{recursive:true});
 const driver=fileURLToPath(new URL('./skill-management-app-driver.mjs',import.meta.url));
 const files=['src/content/actions/claude-code/cc-command.ts','src/features/code/be/services/claude-code/skills.ts','src/features/code/be/services/claude-code/memory.ts','src/features/code/be/services/claude-code/permissions.ts','src/features/code/be/services/claude-code/host-controls.ts','src/features/code/be/services/claude-code/query.ts','src/features/code/be/services/cli.ts','tests/features/code/be/services/claude-code/native-skill-management-app.spec.ts'];
 const sourceHashes={};for(const file of files)sourceHashes[file]=hash(await readFile(join(checkout,'packages/default-setup',file)));
 const contentHashes={};for(const name of ['actions.content.json','flows.content.json'])contentHashes[name]=hash(await readFile(join(checkout,'packages/default-setup/dist/runtime/content',name)));
 const run=await createRun(output,'skill-management-app',{targetSha256:hash(await readFile(executable)),retained,sourceHashes,contentHashes,modelSha256:hash(await readFile(new URL('../protocol/synthetic-model.mjs',import.meta.url))),driverSha256:hash(await readFile(driver)),orchestratorSha256:hash(await readFile(new URL(import.meta.url)))});
 try{
  const transport=await record({executable:process.execPath,args:[driver,checkout,executable,workspace,retained?'retained':'fresh'],cwd:checkout,output,timeoutMs:65000,env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);
  for(const [name,sha] of Object.entries(contentHashes))assert.equal(hash(await readFile(join(checkout,'packages/default-setup/dist/runtime/content',name))),sha);
  const stdout=await readFile(join(transport.directory,'stdout.bin'),'utf8');
  const result=stdout.split('\n').filter(line=>line.startsWith('{')).map(line=>JSON.parse(line)).find(value=>value.evidence==='native-skill-management-app');
  assert.ok(result);assert.equal(result.apiRequests,0);assert.equal(result.commandReplies,11);assert.equal(result.nativePermissionEdits,true);assert.equal(result.rejectedPermissionEditUnchanged,true);assert.equal(result.permissionCanonicalizationWarning,true);assert.equal(result.nativePermissionCatalog,true);assert.equal(result.nativeMemorySettings,true);assert.equal(result.nativeMemoryCatalog,true);assert.equal(result.hiddenDreamOmitted,true);assert.equal(result.syntheticModelRequests,retained?1:0);assert.equal(result.retainedProcess,retained);
  await writeFile(join(run.directory,'skill-management-app.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});
  return{directory:run.directory,status:'complete',...result};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
