import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from '../protocol/record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';
/** Actual post-command tool attempts through the compiled production conversation. */
export async function probePermissionEnforcementApp(checkout,executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'permission-enforcement-app-'));await mkdir(join(workspace,'.claude'),{recursive:true});
 const driver=fileURLToPath(new URL('./permission-enforcement-app-driver.mjs',import.meta.url));
 const sourceHashes={};for(const file of ['src/content/actions/claude-code/cc-command.ts','src/content/actions/claude-code/chat.ts','src/features/code/be/services/claude-code/permissions.ts','src/features/code/be/services/claude-code/query.ts','src/features/code/be/services/claude-code/conversation.ts','src/features/code/be/services/claude-code/handle-store.ts','src/features/code/be/services/cli.ts','tests/features/code/be/services/claude-code/native-permission-enforcement-app.spec.ts'])sourceHashes[file]=hash(await readFile(join(checkout,'packages/default-setup',file)));
 const contentHashes={};for(const file of ['actions.content.json','flows.content.json'])contentHashes[file]=hash(await readFile(join(checkout,'packages/default-setup/dist/runtime/content',file)));
 const run=await createRun(output,'permission-enforcement-app',{targetSha256:hash(await readFile(executable)),sourceHashes,contentHashes,driverSha256:hash(await readFile(driver)),orchestratorSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('../protocol/synthetic-model.mjs',import.meta.url)))});
 try{
  const transport=await record({executable:process.execPath,args:[driver,checkout,executable,workspace],cwd:checkout,output,timeoutMs:75000,env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);
  for(const [file,sha] of Object.entries(contentHashes))assert.equal(hash(await readFile(join(checkout,'packages/default-setup/dist/runtime/content',file))),sha);
  const stdout=await readFile(join(transport.directory,'stdout.bin'),'utf8');const evidence=stdout.split('\n').filter(line=>line.startsWith('{')).map(line=>JSON.parse(line)).find(value=>value.evidence==='native-permission-enforcement-app');
  assert.ok(evidence);for(const key of ['compiledFlow','productionLaunchService','sameNativeOwner','unrelatedUserSettingsPreserved','originalAllowPreserved','closed'])assert.equal(evidence[key],true);
  assert.deepEqual(evidence.markerWritten,[true,false,true]);assert.deepEqual(evidence.toolResultErrors,[false,true,false]);
  for(const [key,value] of Object.entries({nativeProcesses:1,nativeWriters:2,hostInputs:3,commandReplies:2,nativeResults:3,hostPermissionRequests:0,syntheticModelRequests:6,realModelRequests:0,permissionMode:'default'}))assert.equal(evidence[key],value);
  await writeFile(join(run.directory,'permission-enforcement-app.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
