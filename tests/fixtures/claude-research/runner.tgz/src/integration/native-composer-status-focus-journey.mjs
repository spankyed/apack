import assert from 'node:assert/strict'
import { readdir, readFile, writeFile } from 'node:fs/promises'
import { basename, join } from 'node:path'

export async function verifyStatusKeyboardFocus({ page, electronApp, expect, context, composer, send, section, model, proof, output, profileDir, statusProfile, birth, save, statusDecorations }) {
  const normalCaption = 'Release review'
  const draft = 'Keep the release checklist draft while I read its status.'
  const status = page.getByTestId('composer-native-status')
  const window = await electronApp.browserWindow(page)
  await window.evaluate(window => { window.show(); window.focus() })
  await expect.poll(() => page.evaluate(() => document.hasFocus())).toBe(true)
  await expect(status).toContainText(normalCaption, { timeout: 15000 })
  await composer.fill(draft)
  await composer.evaluate(element => element.editor.commands.setTextSelection({ from: 10, to: 17 }))
  const snapshot = () => composer.evaluate(element => ({
    document: element.editor.state.doc.toJSON(),
    selection: element.editor.state.selection.toJSON(),
  }))
  const baseline = await context()
  const document = await snapshot()
  const requests = () => model.calls.filter(row => row.path.split('?')[0] === '/v1/messages').length
  const before = requests()
  proof.keyboardFocus = { draft, document, transitions: [] }
  assert.ok(statusProfile.modePath)
  for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
    await page.setViewportSize(viewport)
    await expect(status).toBeInViewport({ ratio: 1 })
    await status.focus()
    await expect(status).toBeFocused()
    await capture('reading', size)
    await writeFile(statusProfile.modePath, 'empty')
    await expect(status).toHaveCount(0, { timeout: 15000 })
    await expect(composer).toBeFocused()
    await expect(composer).toHaveText(draft)
    await expect(send).toBeInViewport({ ratio: 1 })
    await expect(send).toBeEnabled()
    assert.deepEqual(await snapshot(), document)
    const withdrawn = await context()
    assert.equal(withdrawn.native.state.mainStatus, undefined)
    assert.equal(withdrawn.native.state.nativePid, proof.pid)
    assert.equal(await birth(proof.pid), proof.processStart)
    assert.equal(withdrawn.native.state.ownerId, baseline.native.state.ownerId)
    assert.equal(withdrawn.claude.sessionId, proof.sessionId)
    assert.equal(withdrawn.claude.totalCostUsd, baseline.claude.totalCostUsd)
    assert.deepEqual(withdrawn.messages, baseline.messages)
    assert.equal(requests(), before)
    await capture('returned', size)
    await writeFile(statusProfile.modePath, 'normal')
    await expect(status).toContainText(normalCaption, { timeout: 15000 })
    await expect(composer).toBeFocused()
    assert.deepEqual(await snapshot(), document)
    proof.keyboardFocus.transitions.push({ size, returnedToEditor: true, restoredWithoutStealingFocus: true, sameOwner: true })
    await save()
  }

  if (statusDecorations) {
    const painted = [
      { text: 'Release review\nMigration checklist', lines: 'underline line-through' },
      { text: ' deferred', lines: 'line-through' },
      { text: ' soon', lines: 'underline line-through' },
      { text: ' now', lines: 'underline' },
      { text: ' complete', lines: 'none' },
    ]
    await writeFile(statusProfile.modePath, 'decorated')
    await expect(status).toContainText('Migration checklist', { timeout: 15000 })
    proof.keyboardFocus.decorations = []
    for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
      await page.setViewportSize(viewport)
      await expect(status).toBeInViewport({ ratio: 1 })
      await expect(composer).toBeFocused()
      await expect(send).toBeInViewport({ ratio: 1 })
      assert.deepEqual(await snapshot(), document)
      const spans = await status.locator('span > span').evaluateAll(nodes => nodes.map(node => ({
        text: node.textContent, lines: getComputedStyle(node).textDecorationLine,
      })))
      assert.deepEqual(spans, painted)
      proof.keyboardFocus.decorations.push({ size, spans })
      await capture('decorations', size)
    }
  }

  const helpers = (await statusProfile.invocations()).filter(row => row.input.session_id === proof.sessionId)
  const empty = helpers.filter(row => row.stdout === '')
  assert.ok(empty.length >= 2)
  assert.ok(empty.every(row => row.ancestry.some(parent => parent.pid === proof.pid && parent.start === proof.processStart)))
  proof.keyboardFocus.emptyHelpers = empty
  if (statusDecorations) {
    const decorated = helpers.filter(row => row.stdout.startsWith('\x1b[4;9mRelease review'))
    assert.ok(decorated.length)
    assert.ok(decorated.every(row => row.ancestry.some(parent => parent.pid === proof.pid && parent.start === proof.processStart)))
    proof.keyboardFocus.decorationHelpers = decorated
  }
  assert.equal(requests(), before)

  // Type at the restored selection using the keyboard, then send once to the original session.
  const typed = 'deployment'
  await page.keyboard.type(typed)
  const revised = await composer.textContent()
  const from = document.selection.anchor - 1, to = document.selection.head - 1
  assert.equal(revised, draft.slice(0, from) + typed + draft.slice(to))
  await send.click()
  const userText = call => call.messages?.some(message => message.role === 'user' &&
    (message.content === revised || Array.isArray(message.content) && message.content.some(block => block.type === 'text' && block.text === revised)))
  await expect.poll(() => model.calls.some(userText), { timeout: 20000 }).toBe(true)
  await expect.poll(async () => (await context()).messages.filter(row => row.sender === 'user' && row.text === revised).length, { timeout: 15000 }).toBe(1)
  await expect.poll(async () => (await context()).native.state.busy, { timeout: 15000 }).toBe(false)
  assert.equal((await context()).claude.sessionId, proof.sessionId)
  proof.keyboardFocus.submitted = revised
  await section.getByRole('button', { name: 'Use native interface', exact: true }).click()
  await section.getByRole('button', { name: 'Stop session', exact: true }).click()
  await expect.poll(() => birth(proof.pid), { timeout: 15000 }).not.toBe(proof.processStart)
  const root = join(profileDir, 'projects')
  const files = (await readdir(root, { recursive: true })).filter(name => basename(name) === proof.sessionId + '.jsonl')
  assert.equal(files.length, 1)
  const journal = (await readFile(join(root, files[0]), 'utf8')).trim().split('\n').map(JSON.parse)
  assert.equal(journal.filter(row => row.type === 'user' && row.message?.content === revised).length, 1)
  proof.keyboardFocus.sameNativeSubmission = true
  proof.status = 'complete'
  await save()

  async function capture(stage, size) {
    const filename = 'main-status-focus-' + stage + '-' + size + '.png'
    await page.screenshot({ path: join(output, filename), animations: 'disabled' })
    proof.captures.push(filename)
    await save()
  }
}
