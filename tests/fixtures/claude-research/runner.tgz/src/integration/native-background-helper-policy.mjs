import assert from 'node:assert/strict';
import {readFile,writeFile,rename} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {childCaptionStartupDiagnostic} from './child-caption-startup-diagnostic.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');

/** Change only disposable user settings; native Claude still admits and executes every helper. */
export async function observeBackgroundHelperPolicy({workspace,userDataDir,settingsPath,worker,workerStart,context,statusProfile,expect,capture,sameParent,readDrawing}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+$/);
 assert.equal(settingsPath,join(userDataDir,'claude-code-profile/config/settings.json'));
 const before=await readFile(settingsPath),settings=JSON.parse(before);assert.notEqual(settings.disableAllHooks,true);
 const update=async bytes=>{const temporary=settingsPath+'.research-policy.tmp';await writeFile(temporary,bytes,{mode:0o600,flag:'wx'});await rename(temporary,settingsPath)};
 const generation=async()=>{
  const diagnostic=await childCaptionStartupDiagnostic({userDataDir,sessionId:worker.sessionId,pid:worker.pid});
  const matches=diagnostic.results.filter(row=>row.pid===worker.pid&&row.sessionId===worker.sessionId&&row.start===workerStart);
  assert.equal(matches.length,1);assert.match(matches[0].subagentGenerationSha256,/^[a-f0-9]{64}$/);return matches[0].subagentGenerationSha256;
 };
 const snapshot=async stage=>{
  const current=await sameParent(),info=current.native.backgroundInfo;
  assert.equal(current.native.background.session.pid,worker.pid);assert.equal(current.native.background.session.sessionId,worker.sessionId);
  assert.equal(info.pid,worker.pid);assert.equal(info.sessionId,worker.sessionId);
  const stat=await readFile('/proc/'+worker.pid+'/stat','utf8');assert.equal(stat.slice(stat.lastIndexOf(')')+2).split(' ')[19],workerStart);
  const bytes=await readFile(settingsPath);await writeFile(join(workspace,'helper-policy-settings-'+stage+'.json'),bytes,{mode:0o600,flag:'wx'});
  return{stage,observedMonotonicNs:process.hrtime.bigint().toString(),sessionId:worker.sessionId,pid:worker.pid,start:workerStart,generationSha256:await generation(),settingsSha256:sha(bytes),nativeDrawingText:await readDrawing(),info};
 };
 const baseline=await snapshot('baseline');assert.ok(typeof baseline.info.statusLine==='string'&&baseline.info.statusLine);let restricted,restored,restoreStartedNs,helper;
 try{
  await update(Buffer.from(JSON.stringify({...settings,disableAllHooks:true})));
  await expect.poll(generation,{timeout:15000}).not.toBe(baseline.generationSha256);
  await expect.poll(async()=>{const info=(await context()).native?.backgroundInfo;return info?.pid===worker.pid&&info.statusLine===undefined},{timeout:15000}).toBe(true);
  await expect.poll(async()=>(await readDrawing()).replace(/\s+/g,'').includes(baseline.info.statusLine.replace(/\s+/g,'')),{timeout:15000}).toBe(false);
  restricted=await snapshot('restricted');await capture('policy-restricted');
  restoreStartedNs=process.hrtime.bigint().toString();await update(before);
  await expect.poll(generation,{timeout:15000}).not.toBe(restricted.generationSha256);
  await expect.poll(async()=>{const info=(await context()).native?.backgroundInfo;return info?.pid===worker.pid&&typeof info.totalCostUsd==='number'&&info.statusLine==='Release review\nSession cost $'+info.totalCostUsd.toFixed(6)},{timeout:15000}).toBe(true);
  await expect.poll(async()=>{const info=(await context()).native.backgroundInfo;helper=(await statusProfile.invocations()).find(row=>row.input.session_id===worker.sessionId&&row.input.cost.total_cost_usd===info.totalCostUsd&&(BigInt(row.receiptMonotonicNs)<=BigInt(baseline.observedMonotonicNs)||BigInt(row.entryMonotonicNs)>=BigInt(restoreStartedNs))&&row.ancestry.some(owner=>owner.pid===worker.pid&&owner.start===workerStart));return!!helper},{timeout:15000}).toBe(true);
  await expect.poll(async()=>{const info=(await context()).native.backgroundInfo;return(await readDrawing()).replace(/\s+/g,'').includes(info.statusLine.replace(/\s+/g,''))},{timeout:15000}).toBe(true);
  restored=await snapshot('restored');assert.notEqual(restored.generationSha256,baseline.generationSha256);assert.equal(restored.settingsSha256,sha(before));
  await capture('policy-restored');
  return{baseline,restricted,restored,restoreStartedNs,helper,helperReuse:BigInt(helper.entryMonotonicNs)<BigInt(restoreStartedNs)?'native-cached-result':'native-fresh-execution',scope:'Real original-worker user disableAllHooks transition and restoration. Not installed MDM, a held file-read overlap or complete policy/lifecycle acceptance.'};
 }finally{if(!(await readFile(settingsPath)).equals(before))await update(before);assert.deepEqual(await readFile(settingsPath),before)}
}
