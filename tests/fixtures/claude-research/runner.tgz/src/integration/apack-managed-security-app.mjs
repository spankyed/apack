import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile,readdir,realpath,chmod} from 'node:fs/promises';
import {join,isAbsolute,basename} from 'node:path';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {prepareNativeManagedSecurity} from '../protocol/native-managed-security-fixture.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {assertIsolatedCheckout} from './checkout-isolation.mjs';

const [checkout,executable,workspace,decision]=process.argv.slice(2);
assert.equal(process.platform,'linux','Original native app checks require the inspected Linux container');
assert.ok([checkout,executable,workspace].every(isAbsolute));assert.ok(['trust','reject'].includes(decision));
assert.ok(basename(workspace).startsWith('apack-terminal-owner-app-'));
await assertIsolatedCheckout(checkout);
assert.equal(await realpath(join(checkout,'node_modules')),join(checkout,'node_modules'),'Do not share checkout dependencies');
assert.equal((await readdir(workspace)).length,0,'Supply a fresh empty owned fixture directory');
const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
assert.equal(createHash('sha256').update(await readFile(executable)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
await mkdir(join(workspace,'.claude'),{recursive:true});
await writeFile(join(workspace,'.claude/.claude.json'),JSON.stringify({hasCompletedOnboarding:true}));
await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify({theme:'dark'}));
const researchSourceHashes={};for(const name of ['../protocol/native-managed-security-fixture.mjs','../protocol/native-credit-billing.mjs','../protocol/record.mjs','./apack-managed-security-app.mjs'])researchSourceHashes[name]=createHash('sha256').update(await readFile(new URL(name,import.meta.url))).digest('hex');
await writeFile(join(workspace,'managed-security-inputs.json'),JSON.stringify({binarySha256:'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10',researchSourceHashes,node:process.version,platform:process.platform,decision,boundary},null,2));
const seed=await startSyntheticModel(workspace,'TextOnly');let policy,child;
try{
 policy=await prepareNativeManagedSecurity(workspace,executable);
 const launcher=join(workspace,'managed-security-launcher.cjs');
 await writeFile(launcher,`#!/usr/bin/env node
const{spawn}=require('node:child_process'),{appendFileSync}=require('node:fs');
const args=process.argv.slice(2),print=args.includes('--print');
const env={...process.env,...${JSON.stringify(policy.env)},ANTHROPIC_BASE_URL:print?${JSON.stringify(seed.url)}:'https://api.anthropic.com'};
for(const key of ['ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN','CLAUDE_CODE_SUBSCRIPTION_TYPE','CLAUDE_CODE_OAUTH_SCOPES','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC','DISABLE_TELEMETRY','DISABLE_GROWTHBOOK','CLAUDE_INTERNAL_FC_OVERRIDES','CLAUDE_CODE_CUSTOM_OAUTH_URL'])delete env[key];
if(process.platform==='linux')delete env.NODE_OPTIONS;
const child=spawn(${JSON.stringify(executable)},args,{env,stdio:print?['inherit','pipe','inherit']:'inherit'});
appendFileSync(${JSON.stringify(join(workspace,'managed-security-children.jsonl'))},JSON.stringify({event:'start',pid:child.pid,print,args})+'\\n');
let pending='';if(child.stdout){child.stdout.pipe(process.stdout);child.stdout.setEncoding('utf8');child.stdout.on('data',chunk=>{if(!print)return;pending+=chunk;let end;while((end=pending.indexOf('\\n'))>=0){const line=pending.slice(0,end);pending=pending.slice(end+1);try{const row=JSON.parse(line);if(row.type==='result')appendFileSync(${JSON.stringify(join(workspace,'native-print-results.jsonl'))},JSON.stringify({pid:child.pid,sessionId:row.session_id,totalCostUsd:row.total_cost_usd,subtype:row.subtype})+'\\n')}catch{}}});}
child.on('close',(code,signal)=>{appendFileSync(${JSON.stringify(join(workspace,'managed-security-children.jsonl'))},JSON.stringify({event:'exit',pid:child.pid,print,code,signal})+'\\n');process.exit(code??1)});
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>child.kill(signal));
`);await chmod(launcher,0o755);
 child=spawn(process.execPath,[join(checkout,'scripts/with-source.mjs'),process.execPath,join(checkout,'node_modules/@playwright/test/cli.js'),'test','tests/e2e/ui/claude-native-managed-security.spec.ts','--reporter=line'],{cwd:checkout,env:{...process.env,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_LAUNCHER:launcher,CLAUDE_RESEARCH_ONBOARDING:new URL('../protocol/pty-onboarding.mjs',import.meta.url).pathname,CLAUDE_RESEARCH_MANAGED_SECURITY_DECISION:decision,E2E_KEEP_DATA:'1',E2E_DATA_DIR:join(workspace,'app-data')},stdio:'inherit'});
 const timeout=setTimeout(()=>child.kill('SIGTERM'),170000);let code;
 try{code=await new Promise((done,reject)=>{child.once('error',reject);child.once('close',done)})}finally{clearTimeout(timeout)}
 await writeFile(join(workspace,'managed-security-requests.json'),JSON.stringify(policy.state,null,2)+'\n');
 await writeFile(join(workspace,'managed-security-model-requests.json'),JSON.stringify(seed.calls,null,2)+'\n');
 assert.equal(code,0,'Actual app managed-settings journey failed');
 assert.equal(policy.state.requests.some(row=>row.path.startsWith('/v1/messages')),false,'Native review sent a provider request');
 const proof=JSON.parse(await readFile(join(workspace,'managed-security-app-proof.json'),'utf8'));
 assert.equal(proof.decision,decision);assert.equal(proof.actualAppGui,true);assert.equal(proof.resumedPrintSameSession,true);
 assert.equal(seed.calls.filter(row=>row.path.startsWith('/v1/messages')).length,2);
 const prints=(await readFile(join(workspace,'native-print-results.jsonl'),'utf8')).trim().split('\n').map(row=>JSON.parse(row));
 assert.equal(prints.length,2);assert.ok(prints.every(row=>row.sessionId===proof.sessionId&&row.totalCostUsd>0));assert.ok(prints[1].totalCostUsd>prints[0].totalCostUsd);
 let journal;
 for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{journal=(await readFile(join(workspace,'.claude/projects',bucket,proof.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(row=>JSON.parse(row));break;}catch(error){if(error.code!=='ENOENT')throw error;}}
 assert.ok(journal,'Original same-session native journal missing');
 const humans=journal.filter(row=>row.type==='user'&&(typeof row.message?.content==='string'||Array.isArray(row.message?.content)&&row.message.content.some(block=>block.type==='text'))).map(row=>({uuid:row.uuid,text:typeof row.message.content==='string'?row.message.content:row.message.content.filter(block=>block.type==='text').map(block=>block.text).join('')}));
 assert.deepEqual(humans.map(row=>row.text),['Review the project before applying organization settings.','Continue reviewing after organization settings consent.']);
 assert.equal(new Set(humans.map(row=>row.uuid)).size,2);
 const cost=journal.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,prints[1].totalCostUsd);
 await writeFile(join(workspace,'managed-security-native-verification.json'),JSON.stringify({sessionId:proof.sessionId,humans,prints,nativeCost:cost,noNativeReviewProviderRequest:true},null,2));

 const records=(await readFile(join(workspace,'managed-security-children.jsonl'),'utf8')).trim().split('\n').map(row=>JSON.parse(row));
 for(const start of records.filter(row=>row.event==='start')){
  assert.ok(records.some(row=>row.event==='exit'&&row.pid===start.pid),'Owned native child has no exit receipt');
  try{process.kill(start.pid,0);assert.fail('Owned native process remains alive')}catch(error){if(error.code!=='ESRCH')throw error;}
 }
 console.log(JSON.stringify({status:'complete',decision,workspace,sessionId:proof.sessionId,actualAppGui:true,nativeProcessesExited:true,realModelRequests:0}));
}finally{if(child?.exitCode===null)child.kill('SIGTERM');await policy?.close();await seed.close();}
