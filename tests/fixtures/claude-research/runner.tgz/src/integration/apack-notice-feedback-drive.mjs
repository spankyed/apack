import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,mkdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createServer,request} from 'node:http';
import {createHash} from 'node:crypto';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function identity(pid){
 assert.ok(Number.isSafeInteger(pid)&&pid>1);
 const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');
 return {pid,start:fields[19],state:fields[0],args:(await readFile('/proc/'+pid+'/cmdline','utf8')).split('\0').filter(Boolean)};
}
/** Original refusal decision with a bounded owned-process transport interruption, never an injected notice. */
export async function driveNoticeFeedback(options){
 assert.equal(process.platform,'linux');
 const path=join(options.setupWorkspace,'app-data/claude-code-profile/config/settings.json'),before=await readFile(path);
 const output=join(options.workspace,'electron-results');let provider;
 await mkdir(output,{recursive:true});await writeFile(join(output,'notice-settings-before.json'),before,{flag:'wx',mode:0o600});
 await writeFile(path,JSON.stringify({...JSON.parse(before),model:'claude-opus-5',switchModelsOnFlag:false}));
 try{
  await driveChildComposer({...options,env:{...options.env,ANTHROPIC_DEFAULT_OPUS_MODEL:'claude-opus-4-8'},modelRequestLimit:8,modelFactory:async args=>(provider=await modelRouter(args)),journey:noticeJourney,journeyName:'notice-feedback'});
  const proof=JSON.parse(await readFile(join(output,'notice-feedback.json'),'utf8')),journalRoot=join(options.setupWorkspace,'app-data/claude-code-profile/config/projects');
  const names=await readdir(journalRoot,{recursive:true}),matches=names.filter(n=>basename(n)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);
  const finalJournal=await readFile(join(journalRoot,matches[0])),inflight=await readFile(join(output,'notice-native-transcript-inflight.jsonl'));assert.ok(finalJournal.subarray(0,inflight.length).equals(inflight));
  const cost=finalJournal.toString().split('\n').filter(Boolean).map(JSON.parse).filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,proof.final.claude.totalCostUsd);
  await writeFile(join(output,'notice-native-transcript.jsonl'),finalJournal);
 }finally{
  await writeFile(path,before);assert.deepEqual(await readFile(path),before);
  await writeFile(join(output,'notice-settings-restored.json'),await readFile(path));
  await writeFile(join(output,'notice-settings-restoration.json'),JSON.stringify({beforeSha256:sha(before),restoredSha256:sha(await readFile(path))}));
  if(provider)await writeFile(join(output,'notice-model-calls.json'),JSON.stringify({seed:provider.seed.calls,refusal:provider.refusal.calls,requests:provider.calls},null,2));
 }
}
async function modelRouter({workspace}){
 const seed=await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:3,textReply:'The release review is ready.'});
 const refusal=await startSyntheticModel(workspace,'Refusal',{captureMessages:true,maxRequests:5,refusalCategory:'cyber',refusalCount:2});
 const calls=[],pending=new Set();let seeded=false;
 const server=createServer(async(req,res)=>{try{
  const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;assert.ok(size<=4*1048576);chunks.push(chunk)}
  const bytes=Buffer.concat(chunks),body=JSON.parse(bytes.toString()),path=req.url??'/';assert.ok(calls.length<8);
  const route=seeded?'refusal':'seed';if(path.split('?')[0]==='/v1/messages')seeded=true;calls.push({path,route,model:body.model,messages:body.messages});
  const upstream=request(new URL(path,route==='seed'?seed.url:refusal.url),{method:'POST',headers:{'content-type':'application/json'}},reply=>{res.writeHead(reply.statusCode??502,reply.headers);reply.pipe(res)});
  pending.add(upstream);upstream.once('close',()=>pending.delete(upstream));upstream.once('error',()=>{if(!res.headersSent)res.writeHead(502);res.end('{}')});res.once('close',()=>upstream.destroy());upstream.end(bytes);
 }catch{if(!res.headersSent)res.writeHead(400);res.end('{}')}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 return {url:`http://127.0.0.1:${server.address().port}`,calls,seed,refusal,async close(){for(const child of pending)child.destroy();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await Promise.all([seed.close(),refusal.close()])}};
}
async function noticeJourney({app,page,output,project,userDataDir,expect,phase}){
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(m=>m.name==='Claude Code')}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);
 await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.pendingThreadCwd)).toBe(project);
 await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'})});
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id)}});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 const proof={status:'pending',captures:[],seed:'Help review the release notes.',prompt:'Review the migration example.',draft:'Keep the release review draft.',followup:'Continue the same release review after transport recovery.'};let paused,resumeTimer;
 const save=()=>writeFile(join(output,'notice-feedback.json'),JSON.stringify(proof,null,2));
 const capture=async stage=>{for(const [name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(size);await expect(composer).toHaveText(proof.draft);const file='notice-feedback-'+stage+'-'+name+'.png';await page.screenshot({path:join(output,file)});proof.captures.push(file)}await save()};
 try{
  await composer.fill(proof.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
  proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.process=await identity(proof.initial.native.state.nativePid);assert.ok(proof.process.args.includes(proof.sessionId));
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await composer.fill(proof.prompt);await send.click();
  const notice=section.getByRole('region',{name:'Claude model fallback',exact:true});await expect(notice).toBeVisible({timeout:15000});proof.shown=(await context()).native.state.notice;assert.equal(proof.shown.kind,'refusal_fallback_prompt');assert.equal(proof.shown.originalModel,'claude-opus-5');
  await composer.fill(proof.draft);proof.retained=await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));await capture('ready');
  assert.equal((await identity(proof.process.pid)).start,proof.process.start);process.kill(proof.process.pid,'SIGSTOP');paused=true;
  resumeTimer=setTimeout(()=>{void identity(proof.process.pid).then(current=>{if(paused&&current.start===proof.process.start){process.kill(current.pid,'SIGCONT');paused=false;proof.safetyResume=true}}).catch(()=>{})},20000);resumeTimer.unref();
  await expect.poll(async()=>(await identity(proof.process.pid)).state).toBe('T');phase('owned-native-paused',proof.process);
  await notice.getByRole('button',{name:'Cancel',exact:true}).click();await expect.poll(async()=>(await context()).native.noticeAnswer?.status).toBe('pending');proof.pending=await context();
  for(const choice of proof.shown.choices)await expect(notice.getByRole('button',{name:choice.label,exact:true})).toBeDisabled();await expect(notice.getByRole('button',{name:'Cancel',exact:true})).toBeDisabled();await capture('pending');
  await expect.poll(async()=>(await context()).native.noticeAnswer?.status,{timeout:15000}).toBe('error');proof.failed=await context();assert.match(proof.failed.native.noticeAnswer.problem,/timed out/);await expect(notice).toContainText(proof.failed.native.noticeAnswer.problem);await expect(notice.getByRole('button',{name:'Cancel',exact:true})).toBeEnabled();await capture('error');
  assert.equal((await identity(proof.process.pid)).start,proof.process.start);process.kill(proof.process.pid,'SIGCONT');paused=false;clearTimeout(resumeTimer);assert.ok(!proof.safetyResume,'Safety resumption is failure evidence, not accepted timing');phase('owned-native-resumed',proof.process);
  // Original control checks the disconnected request before deciding. If it was refused,
  // exercise the now-enabled explicit user retry; never infer an effect from timeout.
  try{await expect(notice).toBeHidden({timeout:2000});proof.settlement='late-native-decision'}catch{
   const current=(await context()).native.state.notice;assert.equal(current.id,proof.shown.id);assert.equal(current.revision,proof.shown.revision);proof.retryNotice=current;
   await notice.getByRole('button',{name:'Cancel',exact:true}).click();await expect(notice).toBeHidden({timeout:15000});proof.settlement='explicit-user-retry';
  }proof.recovered=await context();assert.equal(proof.recovered.claude.sessionId,proof.sessionId);assert.equal(proof.recovered.native.state.nativePid,proof.process.pid);
  assert.deepEqual(await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()})),proof.retained);await capture('recovered');
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(async()=>(await context()).native.state.status,{timeout:15000}).toMatch(/^(exited|error)$/);
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toBeVisible();await expect.poll(async()=>{try{return (await identity(proof.process.pid)).start!==proof.process.start}catch(e){if(e.code==='ENOENT')return true;throw e}},{timeout:15000}).toBe(true);proof.nativeWriterRetired=true;
  await composer.focus();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await expect(composer).toHaveText('');await composer.fill(proof.followup);await expect(composer).toHaveText(proof.followup);await send.click();await expect.poll(async()=>(await context()).claude.chatState,{timeout:15000}).toBe('success');proof.final=await context();assert.equal(proof.final.claude.sessionId,proof.sessionId);await composer.fill(proof.draft);await capture('continued');proof.status='complete';
  const journalRoot=join(userDataDir,'claude-code-profile/config/projects'),names=await readdir(journalRoot,{recursive:true}),matches=names.filter(n=>basename(n)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);await writeFile(join(output,'notice-native-transcript-inflight.jsonl'),await readFile(join(journalRoot,matches[0])));
 }finally{clearTimeout(resumeTimer);if(paused){assert.equal((await identity(proof.process.pid)).start,proof.process.start);process.kill(proof.process.pid,'SIGCONT')}if(proof.status!=='complete'){proof.failure=await context().catch(()=>null);await page.screenshot({path:join(output,'notice-feedback-failure.png')}).catch(()=>{})}await save()}
}
