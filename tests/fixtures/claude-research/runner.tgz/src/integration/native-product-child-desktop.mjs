import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createServer} from 'node:https';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {prepareNativeCreditTls} from '../protocol/native-credit-billing.mjs';
import {MANAGED_SECURITY_KEY} from '../protocol/native-managed-security-fixture.mjs';
import {nativeBackgroundDrawingAuditSource} from './native-background-drawing-audit.mjs';

/** Production launcher/transport proof; intentionally separate from mounted app acceptance. */
export async function probeProductChildDesktop({checkout, workspace, setupWorkspace}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv'));
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
 assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
 assert.ok(setupWorkspace.startsWith('/work/.claude-research/profile-setup-app'));
 const executable='/frozen-claude/claude';
 assert.equal(createHash('sha256').update(await readFile(executable)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 const userDataDir=join(setupWorkspace,'app-data'),configDir=join(userDataDir,'claude-code-profile/config'),project=join(setupWorkspace,'project');
 assert.equal(process.env.APACK_USER_DATA_DIR,userDataDir);assert.equal(process.env.APACK_ENV,'test');
 const saved=JSON.parse(await readFile(join(configDir,'.claude.json'),'utf8'));
 assert.equal(saved.projects?.[project]?.hasTrustDialogAccepted,true,'Use original app setup decisions, not synthesized trust');
 assert.ok(saved.customApiKeyResponses?.approved?.includes(MANAGED_SECURITY_KEY.slice(-20)));
 const settingsPath=join(configDir,'settings.json'),originalSettings=await readFile(settingsPath);
 const output=join(workspace,'results');await mkdir(output,{recursive:true});
 const proof={status:'running',scope:'Production original cold-worker desktop only; mounted app UI, warm-spare and other owners remain separate.',steps:[],requests:[]};
 const save=()=>writeFile(join(output,'product-child-desktop.json'),JSON.stringify(proof,null,2));
 const phase=async(name,value)=>{proof.steps.push({at:Date.now(),name,...(value?{value}:{})});await save();};
 const load=name=>import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code',name+'.ts')).href);
 let model,server,seed,prepared,parent,observer,continuation,job,childUi,childAttached=false,deadline,journalTimer;
 const abort=new AbortController();
 const until=async(read,description)=>{for(;;){abort.signal.throwIfAborted();const value=await read();if(value)return value;await new Promise(resolve=>setTimeout(resolve,100));}};
 const tls=await prepareNativeCreditTls(join(workspace,'tls'));
 try {
  deadline=setTimeout(()=>abort.abort(Error('Production child desktop exceeded its existing120s native journey allowance')),120000);
  server=createServer({key:await readFile(tls.key),cert:await readFile(tls.cert)},(req,res)=>{
   req.resume();const path=new URL(req.url,'https://api.anthropic.com').pathname;
   if(proof.requests.length>=200){res.writeHead(429);res.end();return;}
   proof.requests.push({method:req.method,path,foreignKey:!!req.headers['x-api-key']&&req.headers['x-api-key']!==MANAGED_SECURITY_KEY});
   const ok=(req.method==='GET'&&['/api/hello','/v1/oauth/hello'].includes(path))||(req.method==='HEAD'&&path==='/api/hello');
   res.writeHead(req.method==='GET'&&path==='/api/claude_code/settings'?204:ok?200:404,{'content-type':'application/json'});res.end(ok?'{}':'');
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(443,'127.0.0.1',resolve)});
  model=await startSyntheticModel(workspace,'TextOnly',{textReply:'The owned release review is ready.',captureMessages:true,maxRequests:6});
  const env={...process.env,HOME:join(setupWorkspace,'home'),CLAUDE_CONFIG_DIR:configDir,CLAUDE_SECURESTORAGE_CONFIG_DIR:undefined,ANTHROPIC_API_KEY:MANAGED_SECURITY_KEY,ANTHROPIC_BASE_URL:model.url,NODE_EXTRA_CA_CERTS:tls.ca,DISABLE_AUTOUPDATER:'1'};
  const plugin=join(workspace,'drawing-plugin');await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
  await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'owned-child-desktop-proof',version:'0.0.1'}));
  await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
  await writeFile(join(plugin,'hooks/register.ts'),'export function register(on){'+nativeBackgroundDrawingAuditSource+'}');
  // The app deliberately scrubs inherited API keys. Use the established native helper
  // contract in this disposable synthetic profile, and restore its exact bytes afterward.
  await writeFile(settingsPath,JSON.stringify({...JSON.parse(originalSettings),apiKeyHelper:'/usr/bin/printf '+MANAGED_SECURITY_KEY}));
  proof.syntheticAuth='Original native apiKeyHelper in the disposable owned profile; no real login acceptance.';
  const {query}=await load('query');
  seed=await query({cliPath:executable,cwd:project,env,permissionMode:'default',pluginDir:[plugin],tools:[],strictMcpConfig:true,keepStdinOpen:true,signal:abort.signal});
  await seed.initialized;const settings=await seed.getSettings();
  seed.send('Review these owned release notes.');let sessionId;
  for await(const event of seed.events){if(event.type==='result'){proof.seedResult=event;await save();assert.equal(event.is_error,false,event.result||event.errors?.join('; '));sessionId=event.session_id;break;}}
  assert.ok(sessionId);await seed.close();seed=undefined;proof.parentSessionId=sessionId;await phase('native-seed');
  const {prepareClaudeNativeTerminal}=await load('terminal-owner');
  prepared=await prepareClaudeNativeTerminal({cliPath:executable,sessionId,cwd:project,settings,permissionMode:'default',env,pluginDir:[plugin],signal:abort.signal});
  parent=await prepared.start();observer=parent.backgroundObserver;
  await until(()=>parent.state.status==='live'&&parent.state.view?.kind==='main','native main view');
  proof.parentPid=parent.state.nativePid;await phase('parent-ready');
  // Match the app's journal consumer: the canonical continued-in row owns handoff.
  let journalPending;
  const readJournal=()=>journalPending??=(parent.readJournal().finally(()=>{journalPending=undefined;}));
  journalTimer=setInterval(()=>{void readJournal().catch(error=>{proof.journalError=String(error.message);});},100);
  journalTimer.unref();
  const {createClaudeUiControls}=await load('ui-controls');
  const caps=await parent.uiTransport.request({subtype:'apack_ui_capabilities'});
  parent.uiTransport.promptHosts.register('parent-desktop',{read:async()=>({text:'',cursor:0}),fill:async()=>true});
  const main=createClaudeUiControls(Promise.resolve(caps),parent.uiTransport,parent.uiTransport.promptHosts);
  await main.attach({client_id:'parent-desktop',surface:'desktop'});
  const command=await main.prepareParentCommand({client_id:'parent-desktop',text:'/background Continue the owned release review.'});proof.command=command;await save();
  assert.equal(command.kind,'prepared','Original background command must be admitted');
  await main.startParentCommand({client_id:'parent-desktop',command_id:command.id}).catch(error=>{proof.commandStartError=String(error.message);});
  continuation=await until(async()=>{await readJournal();return parent.state.continuation;},'original background continuation');proof.continuation=continuation;
  const {backgroundSession}=await load('background-sessions');
  job=await until(async()=>{const value=await backgroundSession(continuation,{operation:'refresh'},{cwd:project,cliPath:executable,env,timeoutMs:5000});return value?.pid?value:undefined;},'original worker');
  proof.job=job;assert.notEqual(job.sessionId,sessionId);await phase('original-worker');
  await until(()=>observer?.value?.pid===job.pid&&observer.value.sessionId===job.sessionId,'original child status registration');
  const transport=await observer.desktopTransport();assert.ok(transport,'Production child desktop transport required');
  const desktop=observer.desktopOwner;assert.ok(desktop);assert.equal(desktop.identity.pid,job.pid);proof.processStart=desktop.identity.start;proof.desktopOwnerId=desktop.id;await phase('production-child-owner');
  let draft='Owned child desktop draft あ🙂';const calls=[];
  transport.promptHosts.register('child-desktop',{read:async()=>{calls.push('read');return{text:draft,cursor:draft.length};},fill:async value=>{calls.push('fill');draft=value.text;return true;}});
  const capabilities=await transport.request({subtype:'apack_ui_capabilities'});proof.capabilities=capabilities;
  childUi=createClaudeUiControls(Promise.resolve(capabilities),transport,transport.promptHosts);
  await childUi.attach({client_id:'child-desktop',surface:'desktop',viewport:{columns:100,rows:24}});childAttached=true;
  const instance={client_id:'child-desktop',component:'AbovePrompt',instance_id:'child-desktop:above',instance_revision:1};
  const frame=await childUi.render({...instance,surface:'desktop',props:{},viewport:{columns:100,rows:24}});proof.frame=frame;
  const {createClaudeUiDrawing}=await load('ui-tree');const drawing=createClaudeUiDrawing(frame.tree);
  const action=[...drawing.actions.values()].find(value=>value.key==='child-drawing-proof');assert.ok(action?.plugin,'Original stamped drawing action required');
  assert.equal((await childUi.press({...instance,surface:'desktop',...action})).handled,true);
  const callback=JSON.parse(await readFile(join(project,'native-child-drawing-press-'+job.sessionId+'.json'),'utf8'));
  assert.equal(callback.sessionId,job.sessionId);assert.equal(callback.callback,true);assert.equal(callback.prompt.before.text,'Owned child desktop draft あ🙂');assert.equal(callback.prompt.after.text,'Owned child desktop replacement あ🙂');assert.equal(draft,callback.prompt.after.text);assert.equal(calls.filter(value=>value==='fill').length,1);
  proof.callback=callback;proof.hostCalls=calls;await phase('native-callback-and-reverse-prompt');
  assert.equal((await childUi.releaseInstance(instance)).released,true);assert.equal((await childUi.press({...instance,surface:'desktop',...action})).handled,false);proof.staleActionRefused=true;
  const stopped=await backgroundSession(continuation,{operation:'stop',id:job.id,pid:job.pid},{cwd:project,cliPath:executable,env,timeoutMs:10000});assert.equal(stopped.state,'stopped');proof.stopped=stopped;job=undefined;
  await observer.close();await desktop.done;proof.ownerRetired=true;
  assert.ok(!proof.requests.some(row=>row.foreignKey));proof.syntheticApiRequests=model.calls.length;proof.syntheticModelRequests=model.calls.filter(row=>row.path.startsWith('/v1/messages')).length;proof.realModelRequests=0;proof.terminalInputWrites=0;proof.status='complete';await save();
 }catch(error){proof.status='failed';proof.error=String(error.message).slice(0,2048);if(parent)proof.parentState=parent.state;await save();throw error;}
 finally {
  clearTimeout(deadline);clearInterval(journalTimer);abort.abort(Error('Owned probe cleanup'));
  if(childAttached)await childUi.detach({client_id:'child-desktop',surface:'desktop'}).catch(()=>{});
  if(job&&continuation&&model){const{backgroundSession}=await load('background-sessions');await backgroundSession(continuation,{operation:'stop',id:job.id,pid:job.pid},{cwd:project,cliPath:executable,env:{...process.env,HOME:join(setupWorkspace,'home'),CLAUDE_CONFIG_DIR:configDir,ANTHROPIC_API_KEY:MANAGED_SECURITY_KEY,ANTHROPIC_BASE_URL:model.url},timeoutMs:5000}).catch(()=>{});}
  await seed?.close().catch(()=>{});await parent?.close().catch(()=>{});await observer?.close().catch(()=>{});await prepared?.dispose().catch(()=>{});
  proof.modelRequests=model?.calls.map(row=>({path:row.path,model:row.model}));
  await writeFile(settingsPath,originalSettings);proof.syntheticAuthSettingsRestored=true;
  await model?.close();if(server){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  await save();
 }
}
