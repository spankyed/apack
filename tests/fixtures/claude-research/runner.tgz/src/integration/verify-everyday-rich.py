from pathlib import Path
import argparse,json,hashlib,struct,subprocess
parser=argparse.ArgumentParser(description='Verify saved ordinary rich composer app evidence without starting Claude or the app.')
parser.add_argument('evidence',type=Path);parser.add_argument('checkout',type=Path);parser.add_argument('--commit',required=True);parser.add_argument('--research-commit',required=True);args=parser.parse_args()
root=args.evidence; workspace=next((root/'records/workspaces').glob('apack-terminal-owner-app-*'))
p=json.loads((workspace/'native-rich-everyday-proof.json').read_text());e=json.loads((workspace/'native-terminal-app-evidence.json').read_text())
assert e['actualAppGui'] and e['nativeEverydayRich'] and e['sameNativeOwner'] and e['resumedPrintSameSession'];assert not e['browserErrors'];assert p['sessionId']==e['sessionId']==e['finalSessionId']

for owner in ['parent','agent']:
 assert p[owner+'Draft']['doc']==p[owner+'Before']['doc'];assert p[owner+'Draft']['canonical']==p[owner+'Before']['canonical'];assert p[owner+'Before']['selection']['head']-p[owner+'Before']['selection']['anchor']==3
assert p['parentBefore']!=p['agentBefore']
def text(content):
 return content if isinstance(content,str) else '\n'.join(b.get('text','') for b in content or [] if b.get('type')=='text')
def rows(paths):
 out={}
 for path in paths:
  for line in path.read_text().splitlines():
   r=json.loads(line)
   if r.get('uuid'):out[r['uuid']]=r
 return list(out.values())
paths=list((workspace/'.claude/projects').rglob('*.jsonl'))
main=rows([x for x in paths if x.name==p['sessionId']+'.jsonl']);worker=rows([x for x in paths if 'agent-'+p['taskId'] in str(x)])
parent=p['parentBefore']['canonical'];agent=p['agentBefore']['canonical'].rstrip()
parents=[r for r in main if r.get('type')=='user' and not r.get('isMeta') and parent in text(r.get('message',{}).get('content'))];assert len(parents)==1
workers=[r for r in worker if r.get('type')=='user' and r.get('isMeta') and r.get('origin',{}).get('kind')=='human' and agent in text(r.get('message',{}).get('content'))];assert len(workers)==1
assert text(parents[0]['message']['content']).count(parent)==1;assert text(workers[0]['message']['content']).count(agent)==1
assert any(r.get('uuid')==p['agentReplyUuid'] and r.get('type')=='assistant' for r in worker)
assert len([r for r in main if r.get('type')=='user' and not r.get('isMeta') and text(r.get('message',{}).get('content'))==p['recovery']])==1
calls=json.loads((workspace/'model-calls.json').read_text());payloads=[]
for call in calls['agent']:
 users=[m for m in call.get('messages',[]) if m.get('role')=='user'];payloads.append(text(users[-1].get('content')) if users else '')
assert len([x for x in payloads if parent in x])==1;assert len([x for x in payloads if agent in x and parent not in x])==1
assert [(r['owner'],r['width'],r['height']) for r in p['observations']]==[('parent',1100,900),('parent',680,600),('agent',1100,900),('agent',680,600)]
for r in p['observations']:
 assert r['metrics']['height']>=(88 if r['width']==680 else 112);assert r['sessionId']==p['sessionId'];assert r['nativePid']==p['boundNativePid']
 assert [x['edge'] for x in r['reading']]==['top','bottom']
 for x in r['reading']:assert x['hit'] and x['rect']['top']>=x['viewport']['top']-1 and x['rect']['bottom']<=x['viewport']['bottom']+1
 for edge in ['before','top','bottom']:
  matches=list(workspace.glob('electron-results/*/native-rich-everyday-'+r['owner']+'-'+str(r['width'])+'-'+edge+'.png'));assert len(matches)==1
  data=matches[0].read_bytes();assert data[:8]==bytes.fromhex('89504e470d0a1a0a');assert struct.unpack('>II',data[16:24])==(r['width'],r['height'])
assert json.loads((root/'compiled-before.json').read_text())==json.loads((root/'compiled-after.json').read_text())
b=json.loads((root/'offline-boundary.json').read_text());assert b['networkDisabled'] and b['pinnedExecutableReadOnly'] and b['memory']==b['memorySwap']==6*1024**3 and b['nanoCpus']==2*10**9
for name,repository,commit in [('source-inputs.json',args.checkout,args.commit),('authored-inputs.json',Path(__file__).resolve().parents[2],args.research_commit)]:
 for path,digest in json.loads((root/name).read_text()).items():
  data=subprocess.check_output(['git','show',commit+':'+path],cwd=repository)
  assert hashlib.sha256(data).hexdigest()==digest,path
exits=[json.loads(line) for line in (workspace/'native-exits.jsonl').read_text().splitlines()];assert len(exits)==3 and all(row['code'] in [0,143] for row in exits)
for r in p['observations']:
 if r['owner']=='agent':assert r['transcriptHeight']>=80
print(json.dumps({'sessionId':p['sessionId'],'taskId':p['taskId'],'parentUuid':parents[0]['uuid'],'workerUuid':workers[0]['uuid'],'replyUuid':p['agentReplyUuid'],'captures':12,'readingHeights':[(r['owner'],r['width'],r['metrics']['height']) for r in p['observations']],'journalAndModel':True},indent=2))
