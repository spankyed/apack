import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,symlink,lstat}from'node:fs/promises';
import {execFileSync}from'node:child_process';
import {join}from'node:path';
import {createHash}from'node:crypto';

/** Read-only upstream fonts in one disposable HOME; never installs into the image or app. */
export async function prepareNativeGlyphFonts(workspace,env){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-(?:glyph|clipboard|navigation)[0-9]+$/);
 const root='/verification-fonts',raw=await readFile(join(root,'provenance.json')),manifest=JSON.parse(raw);assert.equal(manifest.assets.length,4);
 for(const a of manifest.assets){assert.match(a.file,/^[A-Za-z0-9.-]+$/);const bytes=await readFile(join(root,a.file));assert.equal(bytes.length,a.bytes);assert.equal(createHash('sha256').update(bytes).digest('hex'),a.sha256);assert.equal(createHash('sha1').update(Buffer.concat([Buffer.from('blob '+bytes.length+'\0'),bytes])).digest('hex'),a.gitBlobSha1)}
 const fontEnv={...env,HOME:workspace,XDG_DATA_HOME:join(workspace,'.local/share'),XDG_CACHE_HOME:join(workspace,'.cache')};
 const inspect=()=>Object.fromEntries([['ASCII','0041'],['HIRAGANA_A','3042'],['JAPANESE_DAY','65e5'],['JAPANESE_BOOK','672c'],['JAPANESE_LANGUAGE','8a9e'],['SMILE','1f642']].map(([name,point])=>[name,execFileSync('fc-list',[':charset='+point,'--format=%{family}\t%{file}\n'],{env:fontEnv,timeout:20000,maxBuffer:1048576}).toString().trim().split('\n').filter(Boolean)]));
 const before=inspect();assert.ok(before.ASCII.length);for(const key of Object.keys(before).filter(k=>k!=='ASCII'))assert.equal(before[key].length,0,'The original empty-font negative changed: '+key);
 await mkdir(join(workspace,'.local/share'),{recursive:true});const path=join(workspace,'.local/share/fonts');await symlink(root,path);assert.ok((await lstat(path)).isSymbolicLink());execFileSync('fc-cache',['-f',path],{env:fontEnv,timeout:20000,maxBuffer:1048576});const after=inspect();for(const[key,fonts]of Object.entries(after))assert.ok(fonts.length,'Overlay lacks '+key);
 const evidence={scope:'Verification-only read-only font overlay; no system/image/product installation.',manifestSha256:createHash('sha256').update(raw).digest('hex'),assets:manifest.assets,before,after,path,target:root};await writeFile(join(workspace,'font-overlay.json'),JSON.stringify(evidence,null,2));return fontEnv;
}
