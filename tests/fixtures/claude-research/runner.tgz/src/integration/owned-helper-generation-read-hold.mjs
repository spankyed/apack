/** One explicit fault at the app adapter's async worker-config read; never touches native helper execution. */
import fs from 'node:fs';
import promises from 'node:fs/promises';
import { syncBuiltinESMExports } from 'node:module';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import http from 'node:http';
import { AsyncLocalStorage } from 'node:async_hooks';

const directory = process.env.CLAUDE_RESEARCH_HELPER_READ_HOLD_DIR;
if (directory && !process.versions.bun && typeof process.env.API_PORT === 'string') {
  if (process.platform !== 'linux' || process.getuid() !== 1000 || !/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+\/helper-read-hold$/.test(directory)) throw Error('Unowned helper read fault directory');
  const info = fs.lstatSync(directory);
  if (!info.isDirectory() || info.uid !== process.getuid() || (info.mode & 0o077)) throw Error('Helper read fault directory is not private');
  const original = promises.readFile;
  const requests = new AsyncLocalStorage();
  let requestId = 0, records = 0;
  const digest = bytes => createHash('sha256').update(bytes).digest('hex');
  const record = value => { if (++records > 512) return;return fs.appendFileSync(join(directory, 'events.jsonl'), JSON.stringify({ pid: process.pid, at: Date.now(), ...value }) + '\n', { mode: 0o600 }); };
  record({ event: 'installed', apiProcess: true });
  const emit = http.Server.prototype.emit;
  http.Server.prototype.emit = function(...args) {
    const [event, request, response] = args;
    if (event !== 'request' || !['/background-status', '/background-register'].includes(request?.url)) return Reflect.apply(emit, this, args);
    const id = ++requestId, end = response.end;
    response.end = function(...values) { record({ event: 'reply', route: request.url, requestId: id, statusCode: this.statusCode });return Reflect.apply(end, this, values); };
    return requests.run({ id, route: request.url, socket: request.socket }, () => Reflect.apply(emit, this, args));
  };
  promises.readFile = async function(path, ...args) {
    const bytes = await Reflect.apply(original, this, [path, ...args]);
    const request = requests.getStore();
    if (!request || request.route !== '/background-status' || typeof path !== 'string' || !/^\/tmp\/cc-child-[A-Za-z0-9]+\/workers\/w-[0-9]+-[A-Za-z0-9]+\/observer\.json$/.test(path)) return bytes;
    let arm;
    try {
      const info = fs.lstatSync(join(directory, 'arm.json'));
      if (!info.isFile() || info.uid !== process.getuid() || (info.mode & 0o077) || info.size > 4096) throw Error('Unowned helper read fault arm');
      arm = JSON.parse(fs.readFileSync(join(directory, 'arm.json'), 'utf8'));
      if (arm.path !== path) return bytes;
      if (!/^[a-f0-9-]{36}$/.test(arm.id)) throw Error('Invalid helper read fault identity');
      const claim = fs.openSync(join(directory, arm.id + '.claimed'), 'wx', 0o600);fs.closeSync(claim);
    } catch (error) { if (['ENOENT', 'EEXIST'].includes(error.code)) return bytes; throw error; }
    const witness = { id: arm.id, requestId: request.id, path, bytesSha256: digest(bytes), bytes: Buffer.byteLength(bytes) };
    record({ ...witness, event: 'held' });
    if (arm.disconnect !== true) throw Error('Helper read overlap requires the declared single-report disconnect');
    request.socket.destroy();record({ ...witness, event: 'report-disconnected' });
    await new Promise((resolve, reject) => {
      const interval = setInterval(() => {
        try {
          if (fs.readFileSync(join(directory, 'release'), 'utf8') !== arm.id) return;
          clearInterval(interval);clearTimeout(deadline);record({ ...witness, event: 'released' });resolve();
        } catch (error) { if (error.code !== 'ENOENT') { clearInterval(interval);clearTimeout(deadline);reject(error); } }
      }, 25);
      const deadline = setTimeout(() => { clearInterval(interval);record({ ...witness, event: 'expired' });reject(Error('Owned helper generation read was not explicitly released')); }, 20000);
    });
    setImmediate(() => { try { record({ ...witness, event: 'continuation-settled', configSha256: digest(fs.readFileSync(path)) }); } catch (error) { record({ ...witness, event: 'continuation-settled', error: error.code ?? error.message }); } });
    return bytes;
  };
  syncBuiltinESMExports();
}
