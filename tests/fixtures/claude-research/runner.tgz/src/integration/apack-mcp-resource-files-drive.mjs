import assert from 'node:assert/strict';
import {readFile,writeFile,lstat,readdir} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {observeChildGenericShutdown} from './child-generic-profile.mjs';
import {resourceImageUri,resourceImage} from '../protocol/mcp-resource-files-fixture.mjs';
import {resourceUris,resourceBlob} from '../protocol/mcp-resource-fixture.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export async function driveMcpResourceFiles(options){
 assert.equal(process.platform,'linux');assert.ok(existsSync('/control/offline-verified'));assert.match(options.workspace,/^\/work\/\.claude-research\/mcp-resource-files-app[0-9]+$/);assert.equal(options.setupWorkspace,'/work/.claude-research/profile-setup-app10');
 const path=join(options.setupWorkspace,'app-data/claude-code-profile/config/.claude.json'),info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1048576);const original=await readFile(path),config=JSON.parse(original);assert.ok(!Object.hasOwn(config.mcpServers??{},'research'));
 const receipts=join(options.workspace,'mcp-receipts.jsonl'),exits=join(options.workspace,'mcp-exits.jsonl');
 await writeFile(join(options.workspace,'mcp-profile-preimage.json'),original,{mode:0o600,flag:'wx'});
 await writeFile(path,JSON.stringify({...config,mcpServers:{...config.mcpServers,research:{type:'stdio',command:process.execPath,args:[new URL('../protocol/synthetic-mcp-resource-server.mjs',import.meta.url).pathname],env:{APACK_MCP_RECEIPT:receipts,APACK_MCP_EXITS:exits,APACK_MCP_RESOURCE_FILES:'1'}}}}));
 try{await driveChildComposer({...options,modelTool:'ListMcpResourcesTool',modelOptions:{mcpResources:true,mcpResourceFiles:true},modelRequestLimit:12,journey:filesJourney,journeyName:'mcp-resource-files'});}
 finally{try{const shutdown=await observeChildGenericShutdown({children:receipts,exits});await writeFile(join(options.workspace,'electron-results/mcp-shutdown.json'),JSON.stringify(shutdown,null,2));assert.ok(shutdown.passed);}finally{await writeFile(path,original);assert.deepEqual(await readFile(path),original);await writeFile(join(options.workspace,'electron-results/mcp-profile-restoration.json'),JSON.stringify({restored:true,sha256:sha(original)}));}}
}
async function filesJourney({app,page,output,userDataDir,project,expect,phase,model}){
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads')?.getSnapshot().context;return !!c?.currentThread?.id&&c.tabs.every(t=>c.tabsRead.includes(t.id));}),{timeout:15000}).toBe(true);phase('resource-tabs-restored');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:Object.values(c.nativeUiViews).find(v=>v.threadId===c.currentThread?.id)};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 const proof={status:'running',captures:[],seed:'Help me inspect a release draft.',request:'Review saved MCP resource files.',draft:'Keep my release notes while inspecting resource files.',finalText:'Continue after viewing the saved release resources.'};
 const save=()=>writeFile(join(output,'mcp-resource-files.json'),JSON.stringify(proof,null,2));
 const start=async pid=>(await readFile('/proc/'+pid+'/stat','utf8')).split(') ').at(-1).split(' ')[19];
 const result=id=>model.calls.flatMap(c=>c.messages??[]).flatMap(m=>Array.isArray(m.content)?m.content:[]).find(b=>b.type==='tool_result'&&b.tool_use_id===id);
 const decoded=id=>{const r=result(id);assert.ok(r&&!r.is_error);return JSON.parse(typeof r.content==='string'?r.content:r.content.filter(b=>b.type==='text').map(b=>b.text).join('\n'));};
 const action=uri=>page.getByRole('button',{name:'Open resource '+uri,exact:true});
 const codeState=()=>page.evaluate(()=>{const s=window.applicationState.system.get('default-setup/code').getSnapshot(),c=s.context,e=s.children.explorer?.getSnapshot().context;return{baseDirectory:c.baseDirectory,activeFilePath:c.activeFilePath,error:c.error,rootFiles:e?.rootFiles,expandedDirs:e?[...e.expandedDirs]:[],loadingDirs:e?[...e.loadingDirs]:[],selectedPaths:e?.selectedPaths};});
 const verifyExplorer=async(kind,size)=>{await expect(page.getByText('Directory not found',{exact:true})).toHaveCount(0);const c=await codeState();assert.equal(c.error,null);assert.equal(c.activeFilePath,proof.resources[kind].path);assert.ok(c.baseDirectory&& !c.activeFilePath.startsWith(c.baseDirectory.replace(/\/+$/,'')+'/'));assert.ok(c.expandedDirs.every(p=>p===c.baseDirectory||p.startsWith(c.baseDirectory.replace(/\/+$/,'')+'/')));(proof.explorerReadings??=[]).push({kind,size,...c});};

 const readAction=async(uri,size)=>{
  const button=action(uri);await button.scrollIntoViewIfNeeded();
  const measure=()=>button.evaluate(el=>{
   const b=el.getBoundingClientRect();let top=0,bottom=innerHeight,left=0,right=innerWidth;const scrolls=[];
   for(let p=el.parentElement;p;p=p.parentElement){const style=getComputedStyle(p),r=p.getBoundingClientRect();
    if(/auto|scroll|hidden|clip/.test(style.overflowY)){top=Math.max(top,r.top+p.clientTop);bottom=Math.min(bottom,r.top+p.clientTop+p.clientHeight);}
    if(/auto|scroll|hidden|clip/.test(style.overflowX)){left=Math.max(left,r.left+p.clientLeft);right=Math.min(right,r.left+p.clientLeft+p.clientWidth);}
    if(/auto|scroll/.test(style.overflowY)&&p.scrollHeight>p.clientHeight){
     const visible={top:Math.max(0,r.top+p.clientTop),bottom:Math.min(innerHeight,r.top+p.clientTop+p.clientHeight),left:Math.max(0,r.left+p.clientLeft),right:Math.min(innerWidth,r.left+p.clientLeft+p.clientWidth)};
     for(let q=p.parentElement;q;q=q.parentElement){const style=getComputedStyle(q),rect=q.getBoundingClientRect();if(/auto|scroll|hidden|clip/.test(style.overflowY)){visible.top=Math.max(visible.top,rect.top+q.clientTop);visible.bottom=Math.min(visible.bottom,rect.top+q.clientTop+q.clientHeight);}if(/auto|scroll|hidden|clip/.test(style.overflowX)){visible.left=Math.max(visible.left,rect.left+q.clientLeft);visible.right=Math.min(visible.right,rect.left+q.clientLeft+q.clientWidth);}}
     scrolls.push({top:r.top+p.clientTop,bottom:r.top+p.clientTop+p.clientHeight,left:r.left,right:r.right,scrollTop:p.scrollTop,maxScrollTop:p.scrollHeight-p.clientHeight,visible});
    }
   }
   return {button:{top:b.top,bottom:b.bottom,left:b.left,right:b.right},visible:{top,bottom,left,right},scrolls};
  });
  const settle=()=>button.evaluate(el=>new Promise((resolve,reject)=>{
   const started=performance.now();let prior='',stable=0;
   const sample=()=>{const r=el.getBoundingClientRect();const parts=[r.top,r.bottom,r.left,r.right];for(let p=el.parentElement;p;p=p.parentElement)parts.push(p.scrollTop,p.clientHeight);const next=JSON.stringify(parts);stable=next===prior?stable+1:0;prior=next;if(stable>=8)return resolve(true);if(performance.now()-started>1500)return reject(Error('Resource reading did not settle after the actual scroll'));requestAnimationFrame(sample);};sample();
  }));
  const frames=async()=>((await context()).ui?.state?.transcriptMessages??[]).filter(r=>r.component==='ToolResult'&&['resource-files-image','resource-files-binary'].includes(r.uuid));
  await expect.poll(async()=>{const rows=await frames();return rows.length===2&&rows.every(r=>r.body.status==='live');},{timeout:15000}).toBe(true);
  await settle();
  for(let attempt=0;attempt<8;attempt++){
   const m=await measure();(proof.actionAttempts??=[]).push({uri,size,attempt,...m});await save();const b=m.button,v=m.visible;if(b.top>=v.top+1&&b.bottom<=v.bottom-1&&b.left>=v.left&&b.right<=v.right)break;
   const candidates=m.scrolls.filter(r=>{const v=r.visible,delta=(b.top+b.bottom-v.top-v.bottom)/2;return v.bottom-v.top>=b.bottom-b.top+8&&v.right-v.left>16&&(delta<0?r.scrollTop>0:r.scrollTop<r.maxScrollTop);});
   const scroller=candidates.find(r=>b.top<r.visible.top+4||b.bottom>r.visible.bottom-4)??candidates.at(-1);
   assert.ok(scroller,'Resource action must have a visible physical reading route');
   const visible=scroller.visible;
   await page.mouse.move(visible.right-8,(visible.top+visible.bottom)/2);
   const delta=(b.top+b.bottom-visible.top-visible.bottom)/2;await page.mouse.wheel(0,Math.abs(delta)<4?(delta<0?-4:4):Math.round(delta));
   await expect.poll(async()=>{const next=await measure();return Math.abs(next.button.top-b.top)>.1;}).toBe(true);await settle();
  }
  const m=await measure();assert.ok(m.button.top>=m.visible.top&&m.button.bottom<=m.visible.bottom&&m.button.left>=m.visible.left&&m.button.right<=m.visible.right,'Complete action must be physically readable: '+JSON.stringify(m));
  try{await expect(button).toBeInViewport({ratio:1});}catch(error){proof.readingFailure={uri,size,before:m,after:await measure(),frames:await frames()};await save();throw error;}(proof.actionReadings??=[]).push({uri,size,...m});
 };
 const capture=async(stage,check)=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await check(size);const name='mcp-resource-files-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,name),animations:'disabled'});proof.captures.push(name);await save();}};
 try{
  await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads')?.getSnapshot().context.modes.some(m=>m.name==='Claude Code')??false),{timeout:15000}).toBe(true);
  await page.evaluate(project=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'VIEW_DASHBOARD'});a.send({type:'NEW_THREAD_IN_PROJECT',directory:project});},project);
  await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.pendingThreadCwd)).toBe(project);
  await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
  await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return[c.mode,c.phase];})).toEqual(['Claude Code','Edit']);phase('resource-new-thread-ready');
  await composer.fill(proof.seed);await send.click();await expect.poll(async()=>{const c=await context();return c.claude?.turns===1&&!c.claude.isRunning&&c.messages.some(m=>m.sender==='assistant'&&m.text==='The release review outline is ready.');},{timeout:120000}).toBe(true);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
  phase('resource-native-ready');proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.nativePid=proof.initial.native.state.nativePid;proof.processStart=await start(proof.nativePid);await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill(proof.request);await send.click();await expect.poll(()=>!!result('resource-files-binary'),{timeout:25000}).toBe(true);await expect.poll(async()=>(await context()).native.state.busy,{timeout:15000}).toBe(false);
  await expect.poll(async()=>(await context()).messages.some(m=>m.sender==='assistant'&&m.text==='Resources inspected.')).toBe(true);
  phase('resource-results-delivered');proof.resources={image:decoded('resource-files-image'),binary:decoded('resource-files-binary')};
  for(const[kind,uri,bytes]of[['image',resourceImageUri,resourceImage],['binary',resourceUris.binary,resourceBlob]]){const value=proof.resources[kind].contents.find(c=>c.uri===uri);assert.ok(value);assert.ok(value.blobSavedTo.startsWith(join(userDataDir,'claude-code-profile/config/projects')+'/'));assert.ok(value.blobSavedTo.includes('/'+proof.sessionId+'/tool-results/'));const persisted=await readFile(value.blobSavedTo);assert.deepEqual(persisted,bytes);await writeFile(join(output,kind==='image'?'resource-image.png':'resource-binary.bin'),persisted);proof.resources[kind].sha256=sha(persisted);proof.resources[kind].path=value.blobSavedTo;}
  const expand=page.getByRole('button',{name:'Expand tool activity',exact:true});for(let n=0;n<8&&await expand.count();n++)await expand.first().click();const fallback=page.locator('[data-native-tool-activity] > button[aria-expanded="false"]');for(let n=0;n<8&&await fallback.count();n++)await fallback.first().click();
  await expect(action(resourceImageUri)).toBeVisible();await expect(action(resourceUris.binary)).toBeVisible();
  await composer.fill(proof.draft);await composer.press('Home');for(let n=0;n<5;n++)await composer.press('ArrowRight');for(let n=0;n<12;n++)await composer.press('Shift+ArrowRight');
  const selection=()=>composer.evaluate(el=>{const s=getSelection();return s?.rangeCount&&el.contains(s.anchorNode)&&el.contains(s.focusNode)?[s.anchorOffset,s.focusOffset]:null;});proof.selectionBefore=await selection();assert.deepEqual(proof.selectionBefore,[5,17]);proof.beforeViews=await context();proof.modelRequestsBeforeViews=model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length;
  for(const[kind,uri]of[['image',resourceImageUri],['binary',resourceUris.binary]])await capture(kind+'-action',async size=>{await readAction(uri,size);await expect(composer).toHaveText(proof.draft);await expect(send).toBeEnabled();await expect(send).toBeInViewport({ratio:1});});
  for(const[kind,uri]of[['image',resourceImageUri],['binary',resourceUris.binary]]){
   phase('resource-opening-'+kind);await action(uri).click();await app.waitForSurface('default-setup/code');await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/code').getSnapshot().context.activeFilePath)).toBe(proof.resources[kind].path);
   if(kind==='image'){
    const image=page.getByRole('img',{name:basename(proof.resources.image.path),exact:true});await expect(image).toBeVisible();await expect.poll(()=>image.evaluate(el=>el.complete&&el.naturalWidth===512&&el.naturalHeight===256)).toBe(true);
    const src=await image.getAttribute('src');assert.ok(src.startsWith('data:image/png;base64,'));proof.viewerImageSha256=sha(Buffer.from(src.split(',')[1],'base64'));assert.equal(proof.viewerImageSha256,proof.resources.image.sha256);
    await capture('image',async size=>{await expect(image).toBeInViewport({ratio:1});await verifyExplorer(kind,size);});
   }else await capture('binary',async size=>{await expect(page.getByText('This is a binary file and cannot be displayed',{exact:true})).toBeInViewport({ratio:1});await verifyExplorer(kind,size);});
   await app.navigate('default-setup/threads');await expect(composer).toHaveText(proof.draft);await composer.focus();(proof.returnSelections??=[]).push(await selection());assert.deepEqual(proof.returnSelections.at(-1),proof.selectionBefore);const c=await context();assert.equal(c.native.state.nativePid,proof.nativePid);assert.equal(c.native.state.ownerId,proof.initial.native.state.ownerId);assert.equal(c.claude.sessionId,proof.sessionId);assert.equal(await start(proof.nativePid),proof.processStart);
  }
  proof.afterViews=await context();assert.deepEqual(proof.afterViews.messages,proof.beforeViews.messages);assert.equal(model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length,proof.modelRequestsBeforeViews);assert.equal(proof.afterViews.claude.totalCostUsd,proof.beforeViews.claude.totalCostUsd);
  await composer.click();await composer.press('ControlOrMeta+a');await composer.pressSequentially(proof.finalText);await send.click();await expect.poll(async()=>{const c=await context();return !c.native.state.busy&&c.claude.turns===3&&c.messages.filter(m=>m.sender==='user').at(-1)?.text===proof.finalText&&c.messages.at(-1)?.sender==='assistant'&&c.messages.at(-1)?.text==='Resources inspected.';},{timeout:15000}).toBe(true);await composer.fill(proof.draft);proof.final=await context();await capture('returned',async()=>{await expect(composer).toHaveText(proof.draft);await expect(send).toBeEnabled();await expect(send).toBeInViewport({ratio:1});});
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(async()=>{try{return(await readFile('/proc/'+proof.nativePid+'/stat','utf8')).split(') ').at(-1).split(' ')[0]==='Z'||await start(proof.nativePid)!==proof.processStart;}catch(e){if(e.code==='ENOENT')return true;throw e;}},{timeout:15000}).toBe(true);proof.nativeWriterRetired=true;
  const root=join(userDataDir,'claude-code-profile/config/projects'),names=await readdir(root,{recursive:true}),journal=names.find(p=>basename(p)===proof.sessionId+'.jsonl');assert.ok(journal);const transcript=await readFile(join(root,journal));await writeFile(join(output,'native-transcript.jsonl'),transcript);proof.persistedCost=transcript.toString().split('\n').filter(Boolean).map(JSON.parse).filter(r=>r.type==='cost-state').at(-1).totalCostUSD;assert.equal(proof.persistedCost,proof.final.claude.totalCostUsd);proof.status='complete';phase('mcp-resource-files-complete');
 }finally{if(proof.status!=='complete'){proof.status='failed';proof.failureContext=await context().catch(()=>null);await page.screenshot({path:join(output,'mcp-resource-files-failure.png')}).catch(()=>{});}await save();}
}
