import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const pack=join(checkout,'packages/default-setup');
const contentHashes=async()=>Object.fromEntries(await Promise.all(['actions.content.json','flows.content.json'].map(async name=>[name,hash(await readFile(join(pack,'dist/runtime/content',name)))])));
const compiledContentHashes=await contentHashes();
const target=new Date(Date.now()+95000);
const cronExpression=`${target.getUTCMinutes()} ${target.getUTCHours()} ${target.getUTCDate()} ${target.getUTCMonth()+1} *`;
const model=await startSyntheticModel(workspace,'CronFire',{cronExpression,questionFirst:true});
let child,exited=false,deadline,escalation;
try{
 child=spawn(process.execPath,[join(checkout,'node_modules/vitest/vitest.mjs'),'run','tests/features/code/be/services/claude-code/native-app-owner.spec.ts','--pool=threads','--maxWorkers=1','--minWorkers=1','--no-file-parallelism'],{cwd:pack,env:{...process.env,CLAUDE_RESEARCH_EXECUTABLE:executable,CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_MODEL_URL:model.url},stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);
 deadline=setTimeout(()=>{child.kill('SIGTERM');escalation=setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000)},165000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',code=>{exited=true;resolve(code)})});
 assert.equal(code,0,'Native compiled app-flow test failed');
 assert.deepEqual(await contentHashes(),compiledContentHashes,'Compiled content changed during the probe');
 const evidence=JSON.parse(await readFile(join(workspace,'app-owner-evidence.json'),'utf8'));
 assert.equal(model.calls.filter(call=>call.fixtureResponse==='AskUserQuestion').length,1);
 assert.ok(model.calls.some(call=>call.questionAnsweredAlpha===true));
 assert.equal(model.calls.filter(call=>call.scheduledPromptInLatestUser).length,1);
 assert.equal(model.calls.length,6);
 const nativeToolNames=model.calls.find(call=>call.fixtureResponse==='AskUserQuestion').toolNames;assert.ok(nativeToolNames.length>3);for(const name of ['AskUserQuestion','CronCreate','CronList','Bash','Read'])assert.ok(nativeToolNames.includes(name),`Missing default native tool ${name}`);
 console.log(JSON.stringify({evidence:'apack-native-app-owner',...evidence,nativeToolNames,targetSha256:hash(await readFile(executable)),compiledContentHashes,syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{
 clearTimeout(deadline);clearTimeout(escalation);
 if(child&&!exited){child.kill('SIGTERM');setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000).unref()}
 console.log(JSON.stringify({diagnostic:'synthetic-calls',calls:model.calls}));
 await model.close();
}
