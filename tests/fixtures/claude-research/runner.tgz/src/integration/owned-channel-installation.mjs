import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from '../protocol/record.mjs';

export const channelPlugin='owned-release-channel';
export const channelMarketplace='owned-release-market';
export const channelSelector='plugin:'+channelPlugin+'@'+channelMarketplace;
export const channelServer='plugin:'+channelPlugin+':review';

export async function installOwnedChannel({workspace,project,account,receipts,release,relayDirectory,channelRevocation,channelReplacement}) {
  assert.equal(process.platform,'linux');
  assert.equal(process.getuid(),1000);
  assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-command[0-9]+$/);
  assert.equal(account.HOME,workspace);
  assert.equal(account.CLAUDE_CONFIG_DIR,join(workspace,'.claude'));
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(boundary.requireMcpChannelIngress&&boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
  const marketplace=join(workspace,'owned-channel-marketplace');
  const plugin=join(marketplace,'plugins',channelPlugin);
  await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});
  await mkdir(join(plugin,'.claude-plugin'),{recursive:true});
  await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({
    name:channelMarketplace,owner:{name:'Owned release fixtures'},
    plugins:[{name:channelPlugin,source:'./plugins/'+channelPlugin}],
  }),{flag:'wx'});
  await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({
    name:channelPlugin,version:'0.0.1',
  }),{flag:'wx'});
  await writeFile(join(plugin,'.mcp.json'),JSON.stringify({mcpServers:{review:{
    type:'stdio',command:process.execPath,
    args:[fileURLToPath(new URL('../protocol/owned-mcp-channel-server.mjs',import.meta.url))],
    env:{APACK_MCP_TASK_RECEIPT:receipts,APACK_MCP_CHANNEL_RELEASE:release,APACK_MCP_CHANNEL_RELAY:relayDirectory,APACK_MCP_CHANNEL_RELAY_REVOCATION:channelRevocation?'1':undefined,APACK_MCP_CHANNEL_RELAY_REPLACEMENT:channelReplacement?'1':undefined},
  }}}),{flag:'wx'});
  const executable='/frozen-claude/claude';
  const runs=[];
  for(const args of [['plugin','marketplace','add',marketplace],['plugin','install',channelPlugin+'@'+channelMarketplace]]){
    const run=await record({executable,args:['--setting-sources','',...args],cwd:project,
      env:{HOME:account.HOME,CLAUDE_CONFIG_DIR:account.CLAUDE_CONFIG_DIR,DISABLE_AUTOUPDATER:'1',
        CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',PATH:process.env.PATH},
      output:join(workspace,'owned-channel-installation'),timeoutMs:20000,maxBytes:1048576});
    runs.push(run);
    assert.equal(run.status,'complete');
    assert.equal(run.code,0,'Original local channel plugin setup failed');
  }
  const registry=JSON.parse(await readFile(join(account.CLAUDE_CONFIG_DIR,'plugins/installed_plugins.json'),'utf8'));
  const [installation]=registry.plugins?.[channelPlugin+'@'+channelMarketplace]??[];
  assert.equal(installation?.scope,'user');
  assert.deepEqual(JSON.parse(await readFile(join(installation.installPath,'.mcp.json'),'utf8')),
    JSON.parse(await readFile(join(plugin,'.mcp.json'),'utf8')));
  await writeFile(join(workspace,'owned-channel-install.json'),JSON.stringify({
    runs,installation,selector:channelSelector,server:channelServer,
  },null,2));
}
