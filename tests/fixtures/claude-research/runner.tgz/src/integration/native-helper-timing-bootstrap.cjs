const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
const directory=process.env.CLAUDE_RESEARCH_HELPER_TIMING;
assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
assert.match(directory,/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+\/helper-timing$/);
const boundary=JSON.parse(fs.readFileSync('/control/offline-verified','utf8'));
assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
// Playwright removes NODE_OPTIONS before Electron starts. The explicit -r entry runs before main
// and supplies only the disposable API child's observer; it does not intercept process spawning.
process.env.NODE_OPTIONS=(process.env.NODE_OPTIONS??'')+' --import='+pathToFileURL(path.join(__dirname,'native-helper-timing-preload.mjs')).href;
fs.writeFileSync(path.join(directory,'main-bootstrap-'+process.pid+'.json'),JSON.stringify({phase:'main-bootstrap',pid:process.pid,monotonicNs:process.hrtime.bigint().toString()}),{mode:0o600,flag:'wx'});
