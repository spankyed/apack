import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,writeFile,lstat,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {holdOwnedSessionHandoff} from './owned-session-handoff-hold.mjs';
const settings='/work/.claude-research/profile-setup-app10/app-data/claude-code-profile/config/settings.json';
const baseline='5eb7b71763d6c0fc454f048fe69cb174724f161d2f4cdc50a8776c83cbc2e128';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
function boundary(workspace){assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));assert.match(workspace,/^\/work\/\.claude-research\/session-handoff-app[0-9]+$/);}
export async function restoreSessionHandoffProfile(workspace){
 boundary(workspace);const before=await readFile(join(workspace,'handoff-settings-before.json'));assert.equal(sha(before),baseline);
 const stat=await lstat(settings);assert.ok(stat.isFile()&&!stat.isSymbolicLink()&&stat.uid===1000&&stat.size<=1048576);
 const current=await readFile(settings);if(!current.equals(before)){await writeFile(join(workspace,'preserved-handoff-settings.json'),current,{mode:0o600,flag:'wx'});await writeFile(settings,before,{mode:0o600});}
 assert.deepEqual(await readFile(settings),before);const result={restored:true,sha256:sha(before)};
 await writeFile(join(workspace,'handoff-settings-restoration.json'),JSON.stringify(result));return result;
}
export async function driveSessionHandoff(options){
 boundary(options.workspace);const before=await readFile(settings);assert.equal(sha(before),baseline);await writeFile(join(options.workspace,'handoff-settings-before.json'),before,{mode:0o600,flag:'wx'});
 try{await driveChildComposer({...options,modelRequestLimit:6,journey:args=>handoffJourney({...args,requireReturnReading:options.requireReturnReading===true}),journeyName:'session-handoff'});}finally{await restoreSessionHandoffProfile(options.workspace);}
}
async function processStart(pid){try{const bytes=await readFile('/proc/'+pid+'/stat','utf8'),parts=bytes.slice(bytes.lastIndexOf(')')+2).split(' ');return parts[0]==='Z'?undefined:parts[19];}catch(error){if(error.code==='ENOENT')return;throw error;}}
async function handoffJourney({app,page,electronApp,checkout,workspace,output,project,userDataDir,expect,phase,model,requireReturnReading=false}){
 // Refuse stale installed code before any native interaction, even if boot preserves an older pack.
 const producer=JSON.parse(await readFile('/control/producer-pack-inputs.json','utf8'));
 const installed=join(userDataDir,'apack/packs/default-setup');
 const installedInputs={};
 for(const name of ['runtime/fe.js','runtime/index.cjs']){
  const actual=sha(await readFile(join(installed,name)));assert.equal(actual,producer[name],'Installed candidate mismatch: '+name);installedInputs[name]=actual;
 }
 await writeFile(join(workspace,'installed-candidate-before-journey.json'),JSON.stringify({passed:true,files:installedInputs}));
 page.setDefaultTimeout(5000);const proof={status:'running',requireReturnReading,returnReadings:[],readerReturns:[],seed:'Review the release before changing sessions.',draft:'Keep the fresh release notes during session recovery.',followup:'Review only the new release after changing sessions.',captures:[]};
 const save=()=>writeFile(join(output,'session-handoff.json'),JSON.stringify(proof,null,2));
 const modelRequests=()=>{
  const all=model.calls.filter(call=>call.path.split('?')[0]==='/v1/messages'),main=[],titles=[];assert.ok(proof.before?.claude.model&&proof.before.claude.model!=='claude-haiku-5-5');
  for(const call of all){if(call.model===proof.before.claude.model){main.push(call);continue;}
   const message=call.messages?.[0],blocks=message?.content,prefix=[proof.terminalFollowup,proof.followup].map(text=>'<session>\n'+text+'\n</session>\n\n').find(prefix=>blocks?.[0]?.text?.startsWith(prefix));
   assert.equal(call.model,'claude-haiku-5-5');assert.deepEqual(call.toolNames,[]);assert.equal(call.messageCount,1);assert.equal(message?.role,'user');assert.ok(prefix&&Array.isArray(blocks)&&blocks.length===1&&blocks[0].type==='text');
   assert.equal(sha(blocks[0].text.slice(prefix.length)),'30704b4d05983bebf62600d91882d0f6c98a0748dc7ae578cece46864bb0f515');titles.push(call);
  }return {all,main,titles};
 };

 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:Object.values(c.nativeUiViews).find(v=>v.threadId===c.currentThread?.id)};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('.ProseMirror[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await composer.pressSequentially(text);await expect(composer).toHaveText(text);};
 const viewport=()=>page.getByTestId('chat-transcript').locator(':scope > div').first();
 const latestReply=async()=>{
  const message=(await context()).messages.findLast(m=>m.sender==='assistant'&&m.text==='The release review outline is ready.');assert.ok(message?.context?.cliUuid);
  const row=page.getByTestId('chat-transcript').locator('[data-message-id]').filter({hasText:message.text}).last();assert.equal(await row.getAttribute('data-message-id'),message.id);
  return {message,body:row.locator('[data-chat-message-content]').first()};
 };
 const readGeometry=async()=>{
  const {message,body}=await latestReply();await expect(body).toBeInViewport({ratio:1});
  const geometry=await body.evaluate(element=>{const viewport=element.closest('[data-testid="chat-transcript"]').firstElementChild,rect=element.getBoundingClientRect(),bounds=viewport.getBoundingClientRect();return {body:{top:rect.top,bottom:rect.bottom,height:rect.height},viewport:{top:bounds.top,bottom:bounds.bottom,height:bounds.height},scrollTop:viewport.scrollTop,scrollHeight:viewport.scrollHeight,clientHeight:viewport.clientHeight};});
  assert.ok(geometry.body.height>0&&geometry.body.top>=geometry.viewport.top-1&&geometry.body.bottom<=geometry.viewport.bottom+1);return {messageId:message.id,cliUuid:message.context.cliUuid,...geometry};
 };
 const capture=async stage=>{for(const [size,bounds]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(bounds);await expect(send).toBeInViewport({ratio:1});if(requireReturnReading)proof.returnReadings.push({stage,size,...await readGeometry()});const name='session-handoff-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,name)});proof.captures.push(name);}await save();};
 const readerPosition=()=>viewport().evaluate(element=>{const bounds=element.getBoundingClientRect(),first=[...element.querySelectorAll('[data-message-id]')].find(row=>{const r=row.getBoundingClientRect();return r.height>0&&r.bottom>bounds.top+1&&r.top<bounds.bottom-1});return {top:element.scrollTop,scrollHeight:element.scrollHeight,height:element.clientHeight,firstMessageId:first?.getAttribute('data-message-id'),offset:first?first.getBoundingClientRect().top-bounds.top:null};});
 const verifyReaderReturn=async()=>{for(const[size,bounds]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
  await page.setViewportSize(bounds);await readGeometry();const atLatest=await readerPosition();
  if(atLatest.top<=1){assert.ok(atLatest.scrollHeight<=atLatest.height+1);proof.readerReturns.push({size,overflow:false,atLatest});continue;}
  const box=await viewport().boundingBox();assert.ok(box?.height>0);await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.wheel(0,-Math.min(48,atLatest.top/2));
  await expect.poll(async()=>{const position=await readerPosition();return position.top>0&&position.top<atLatest.top-1;},{timeout:5000}).toBe(true);const before=await readerPosition();assert.ok(before.firstMessageId);proof.pendingReaderReturn={size,before};await save();const name='session-handoff-reader-before-'+size+'.png';await page.screenshot({path:join(output,name)});
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect(page.locator('[aria-label="Terminal input"]').last()).toBeVisible({timeout:10000});await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:15000}).toBe('live');
  await expect.poll(async()=>{const p=await readerPosition();return Math.abs(p.top-before.top)<=1&&p.firstMessageId===before.firstMessageId&&Math.abs(p.offset-before.offset)<=1;},{timeout:5000}).toBe(true);const after=await readerPosition();assert.equal(after.firstMessageId,before.firstMessageId);assert.ok(Math.abs(after.offset-before.offset)<=1);
  assert.deepEqual(await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()})),proof.draftDocument);const afterName='session-handoff-reader-returned-'+size+'.png';await page.screenshot({path:join(output,afterName)});proof.readerReturns.push({size,overflow:true,before,after,captures:[name,afterName],state:await context()});
  await page.getByRole('button',{name:'Scroll to latest message',exact:true}).click();await page.mouse.move(20,300);await readGeometry();await save();
 }};

 let relay;const cancellation=new AbortController();
 try{
  await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
  await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.openedThreadId===null&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code');}),{timeout:15000}).toBe(true);
  await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);
  await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
  await expect.poll(()=>page.evaluate(()=>!window.applicationState.system.get('default-setup/threads').getSnapshot().context.currentThread?.id)).toBe(true);
  await replace(proof.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
  const startingSession=(await context()).claude.sessionId,existing=new Set(await readdir('/tmp'));
  let installFailure;const install=(async()=>{const until=Date.now()+25000;while(Date.now()<until){cancellation.signal.throwIfAborted();const names=await readdir('/tmp');assert.ok(names.length<=2048);for(const name of names){if(existing.has(name)||!/^cc-app-[A-Za-z0-9_-]+$/.test(name))continue;const directory=join('/tmp',name);try{const meta=await lstat(join(directory,'observer.json'));if(!meta.isFile()||meta.uid!==1000||meta.size>65536)continue;const config=JSON.parse(await readFile(join(directory,'observer.json'),'utf8'));if(config.sessionId!==startingSession)continue;relay=await holdOwnedSessionHandoff({directory,sessionId:startingSession,signal:cancellation.signal});proof.bridgeDirectory=directory;proof.relayInstalledAt=Date.now();return;}catch(error){if(!['ENOENT'].includes(error.code))throw error;}}await new Promise(resolve=>setTimeout(resolve,10));}throw Error('Original bridge did not become available before native attachment');})().catch(error=>{installFailure=error;});
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');await install;if(installFailure)throw installFailure;assert.ok(relay);await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toMatch(/^(live|error)$/);
  if((await context()).ui.state.status==='error'){proof.initialUiRecovery={before:await context()};await card.getByRole('button',{name:'Reconnect controls',exact:true}).click();await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toBe('live');proof.initialUiRecovery.after=await context();}
  if(requireReturnReading)await page.evaluate(()=>{
   const viewport=document.querySelector('[data-testid="chat-transcript"]')?.firstElementChild;
   if(!(viewport instanceof HTMLElement))throw Error('Missing owned transcript viewport');
   const area=viewport.closest('[data-testid="chat-composer-area"]'),shell=viewport.closest('.native-chat-shell');
   const samples=[],listeners=[],started=performance.now();
   const record=event=>{
    if(samples.length>=256)return;
    const bounds=viewport.getBoundingClientRect();
    samples.push({reason:typeof event==='string'?event:event.type,elapsedMs:performance.now()-started,top:viewport.scrollTop,height:viewport.clientHeight,total:viewport.scrollHeight,width:viewport.clientWidth,connected:viewport.isConnected,viewportTop:bounds.top,navigationReserve:shell?getComputedStyle(shell).getPropertyValue('--composer-navigation-height'):null,...(event instanceof WheelEvent?{deltaY:event.deltaY}:{}),rows:[...viewport.querySelectorAll('[data-message-id]')].slice(-6).map(row=>{const rect=row.getBoundingClientRect(),body=row.querySelector('[data-chat-message-content]')?.getBoundingClientRect();return{id:row.getAttribute('data-message-id'),top:rect.top,height:rect.height,body:body?{top:body.top,bottom:body.bottom,height:body.height}:null}})});
   };
   for(const name of ['scroll','wheel','pointerdown','keydown']){viewport.addEventListener(name,record,{passive:true});listeners.push(name)}
   const resize=new ResizeObserver(()=>record('resize'));resize.observe(viewport);if(viewport.firstElementChild)resize.observe(viewport.firstElementChild);
   const visibility=new MutationObserver(()=>record('visibility'));if(area)visibility.observe(area,{attributes:true,attributeFilter:['style','class']});
   window.__claudeResearchViewportTrace=()=>{record('final');resize.disconnect();visibility.disconnect();for(const name of listeners)viewport.removeEventListener(name,record);delete window.__claudeResearchViewportTrace;return{samples,maxSamples:256,readOnly:true}};
   record('installed');
  });
  proof.before=await context();const old=proof.before.native.state.sessionId,pid=proof.before.native.state.nativePid;proof.pid=pid;proof.processStart=await processStart(pid);assert.ok(proof.processStart);
  const environment=await readFile('/proc/'+pid+'/environ');assert.ok(environment.length<=1048576);assert.ok(environment.toString().includes(proof.bridgeDirectory+'/status.mjs'));assert.equal(proof.before.claude.sessionId,startingSession);
  const argv=(await readFile('/proc/'+pid+'/cmdline')).toString().split('\0');const pluginIndex=argv.indexOf('--plugin-dir');assert.ok(pluginIndex>=0);const pluginPath=join(argv[pluginIndex+1],'hooks/register.ts'),plugin=await readFile(pluginPath);assert.ok(plugin.length<=262144);const actualProgram=plugin.toString().slice(plugin.indexOf(10)+1);
  const expectedProgram=(await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/native-plugin/program.generated.ts')).href)).CLAUDE_NATIVE_PLUGIN_PROGRAM;
  assert.equal(actualProgram,expectedProgram);proof.plugin={moduleSha256:sha(plugin),programSha256:sha(actualProgram)};
  // Native keyboard input remains available while the plugin command channel is held.
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  const tty=page.locator('[aria-label="Terminal input"]').last();await expect(tty).toBeVisible({timeout:10000});await electronApp.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0]?.focus());await tty.focus();
  relay.arm();phase('session-handoff-relay-armed');
  await expect.poll(()=>relay.receipts().some(r=>r.kind==='old-poll'),{timeout:10000}).toBe(true);proof.oldPollAdmitted=true;await save();
  proof.clearInputRoute='visible native terminal keyboard';proof.terminalBefore=await context();await tty.focus();await page.keyboard.type('/clear');await page.keyboard.press('Enter');await expect.poll(async()=>(await context()).native?.state?.sessionId,{timeout:15000}).not.toBe(old);
  const fresh=(await context()).native.state.sessionId;assert.ok(fresh);assert.notEqual(fresh,old);proof.newSessionId=fresh;
  proof.terminalFollowup='Review the fresh release after clearing.';await tty.focus();await page.keyboard.type(proof.terminalFollowup);await page.keyboard.press('Enter');await expect.poll(()=>relay.receipts().some(r=>r.kind==='new-turn'),{timeout:15000}).toBe(true);
  // Module startup is cached across /clear. The next genuine turn invokes begin() before its notification.
  await expect.poll(()=>relay.traffic().some(r=>r.path==='/poll'&&!r.directOwner&&r.sessionId===fresh),{timeout:10000}).toBe(true);proof.freshPollBeforeOldRelease=true;proof.beforeOldRelease=await context();
  relay.release('old-poll');proof.oldReleasedAt=Date.now();await expect.poll(()=>relay.receipts().find(r=>r.kind==='old-poll').deliveredAt,{timeout:5000}).toBeTruthy();relay.release('new-turn');proof.turnNotificationReleasedAt=Date.now();
  await expect.poll(async()=>{const c=await context();return !c.native.state.busy&&modelRequests().main.length===2;},{timeout:20000}).toBe(true);proof.afterTerminalFollowup=await context();
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await expect.poll(async()=>{const c=await context();return c.claude?.sessionId===fresh&&c.native?.state?.sessionId===fresh&&c.ui?.state?.status==='live';},{timeout:15000}).toBe(true);
  assert.equal((await context()).native.state.nativePid,pid);assert.equal(await processStart(pid),proof.processStart);assert.equal(sha(await readFile(pluginPath)),proof.plugin.moduleSha256);
  proof.socketRestoration=await relay.close();proof.receipts=relay.receipts();proof.traffic=relay.traffic();proof.relayErrors=relay.errors();assert.deepEqual(proof.relayErrors,[]);relay=undefined;
  await replace(proof.draft);proof.afterHandoff=await context();proof.draftDocument=await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));await capture('recovered');
  await replace(proof.followup);await send.click();await expect.poll(async()=>{const c=await context();return !c.native.state.busy&&c.claude.sessionId===fresh&&c.claude.totalCostUsd>proof.afterHandoff.claude.totalCostUsd&&c.messages.some(m=>m.sender==='user'&&m.text===proof.followup&&m.context?.cliUuid);},{timeout:20000}).toBe(true);proof.afterFollowup=await context();
  await replace(proof.draft);assert.deepEqual(await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()})),proof.draftDocument);await capture('continued');
  if(requireReturnReading)await verifyReaderReturn();
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processStart(pid),{timeout:15000}).not.toBe(proof.processStart);proof.nativeWriterRetired=true;
  const folder=join(userDataDir,'claude-code-profile/config/projects'),names=await readdir(folder,{recursive:true});assert.ok(names.length<=20000);proof.journals=[];
  for(const id of [old,fresh]){const matches=names.filter(n=>basename(n)===id+'.jsonl');assert.equal(matches.length,1);const bytes=await readFile(join(folder,matches[0]));assert.ok(bytes.length<=8388608);const name='handoff-native-'+id+'.jsonl';await writeFile(join(output,name),bytes);proof.journals.push({sessionId:id,name,sha256:sha(bytes)});}
  const requests=modelRequests();proof.modelRequests=requests.main;proof.titleRequests=requests.titles;proof.allModelRequestCount=requests.all.length;assert.equal(proof.allModelRequestCount,5);assert.equal(proof.titleRequests.length,2);assert.equal(proof.modelRequests.length,3);assert.ok(JSON.stringify(proof.modelRequests[1]).includes(proof.terminalFollowup));assert.ok(JSON.stringify(proof.modelRequests[2]).includes(proof.followup));assert.ok(!JSON.stringify(proof.modelRequests[1].messages).includes(proof.seed));assert.ok(!JSON.stringify(proof.modelRequests[2].messages).includes(proof.seed));proof.status='complete';phase('session-handoff-complete');
 }catch(error){if(proof.pendingReaderReturn)proof.pendingReaderReturn.after=await readerPosition().catch(()=>null);proof.error={name:error.name,message:error.message.slice(0,2000)};proof.failure=await context().catch(()=>null);await page.screenshot({path:join(output,'session-handoff-failure.png')}).catch(()=>{});throw error;}
 finally{if(requireReturnReading)proof.viewportTrace=await page.evaluate(()=>window.__claudeResearchViewportTrace?.()).catch(()=>null);if(relay){proof.receipts=relay.receipts();proof.traffic=relay.traffic();proof.relayErrors=relay.errors();proof.socketRestoration=await relay.close();}cancellation.abort();await save();}
}
if(process.argv[1]===fileURLToPath(import.meta.url)){assert.equal(process.argv.length,3);console.log(JSON.stringify(await restoreSessionHandoffProfile(process.argv[2])));}
