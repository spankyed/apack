import assert from 'node:assert/strict';
import {readFile,readdir,readlink} from 'node:fs/promises';
export async function processStart(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),f=raw.slice(raw.lastIndexOf(')')+2).split(' ');return f[0]==='Z'?undefined:f[19]}catch(e){if(e.code==='ENOENT')return;throw e}}


export async function liveOriginals(){
 const entries=(await readdir('/proc')).filter(n=>/^[0-9]+$/.test(n));assert.ok(entries.length<=4096);const live=[];
 for(const id of entries){try{const raw=await readFile('/proc/'+id+'/stat','utf8'),name=raw.slice(raw.indexOf('(')+1,raw.lastIndexOf(')')),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');if(fields[0]==='Z')continue;let executable;try{executable=await readlink('/proc/'+id+'/exe')}catch(error){if(!['EACCES','ENOENT','ESRCH'].includes(error.code))throw error}if(executable==='/frozen-claude/claude'||name==='claude')live.push({pid:Number(id),processStart:fields[19],executable,name})}catch(error){if(!['ENOENT','ESRCH'].includes(error.code))throw error}}
 return live;
}

