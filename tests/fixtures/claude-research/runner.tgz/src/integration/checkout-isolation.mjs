import assert from 'node:assert/strict';
import { realpath, stat } from 'node:fs/promises';
import { join, relative, isAbsolute } from 'node:path';

// Hosted Actions checkouts own their dependencies and builds but have a .git directory.
// Local primary checkouts remain forbidden, even when a generic CI flag is present.
export async function assertIsolatedCheckout(checkout, env = process.env) {
  checkout = await realpath(checkout);
  if ((await stat(join(checkout, '.git'))).isFile()) return;
  const hosted = env.GITHUB_ACTIONS === 'true' && env.RUNNER_ENVIRONMENT === 'github-hosted';
  let owned = false;
  if (hosted && env.GITHUB_WORKSPACE && env.RUNNER_WORKSPACE) {
    const workspace = await realpath(env.GITHUB_WORKSPACE);
    const runner = await realpath(env.RUNNER_WORKSPACE);
    const child = relative(runner, workspace);
    owned = checkout === workspace && child !== '' && child !== '..'
      && !child.startsWith('../') && !isAbsolute(child);
  }
  assert.ok(owned, 'Supply a linked worktree, not the shared primary checkout (or the exact disposable GitHub-hosted workspace)');
}
