import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,stat} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {createNativeTestImage} from '../protocol/native-test-image.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function processStart(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]==='Z'?undefined:fields[19]}catch(error){if(error.code==='ENOENT')return;throw error}}

/** Original native decisions in everyday conversation, including delivery receipts for retired Cancels. */
export async function decisionCancellationJourney({app,page,output,project,userDataDir,workspace,expect,phase,model,cancelQuestionImage=false,conversionHold}) {
 const proof={status:'running',scope:'Original main Question, Read and EnterPlanMode process Cancel, same-session reopen, retired/repeated delivery through the current backend mount, fresh native resolution and composing recovery. Synthetic model/account, no private feature gates; not all lifecycle or F1–F5 acceptance.',owners:[],decisions:[],captures:[]};
 const image=cancelQuestionImage?createNativeTestImage([250,190,24,255]):undefined;
 if(image)proof.scope='Cancel an original main question with an attached PNG, refuse retired cancels and answer a fresh question in the same session.';
 if(conversionHold)proof.scope='Cancel a submitted main question after the original native image decoder returns and before its result is delivered, then resume the same session.';
 const save=()=>writeFile(join(output,'decision-cancellation.json'),JSON.stringify(proof,null,2));
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews}});
 const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await composer.pressSequentially(text);await expect(composer).toHaveText(text)};
 const document=()=>composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
 const logs=async()=>{const bytes=await readFile(join(userDataDir,'apack/logs/app-events.log'),'utf8');assert.ok(bytes.length<16*1048576);return bytes.trim().split('\n').map(line=>JSON.parse(line))};
 const capture=async(tag,panel)=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await page.evaluate(()=>document.fonts.ready.then(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))));await expect(panel??composer).toBeInViewport({ratio:1});if(panel)await expect(panel.getByRole('button',{name:'Cancel',exact:true})).toBeInViewport({ratio:1});const name='decision-cancel-'+tag+'-'+size+'.png';await page.screenshot({path:join(output,name),animations:'disabled'});proof.captures.push(name);await save()}};
 const frame=async tool=>{const c=await context(),pending=c.claude.pendingControlRequest;assert.equal(pending.toolName,tool);const native=pending.nativeTerminal;assert.ok(native&&native.requestId);const rows=Object.entries(c.ui).filter(([,view])=>!view.mountRequest?.nativeView&&!view.mountRequest?.backgroundView&&view.state?.actionKeys?.revision);assert.equal(rows.length,1);const [mountId,view]=rows[0],scope={ownerId:native.ownerId,sessionId:native.sessionId,messageId:pending.approvalMessageId,id:native.dialogId,revision:native.revision,requestId:native.requestId,toolName:tool};if(tool==='AskUserQuestion')assert.equal(view.state.question.messageId,scope.messageId);return{threadId:c.threadId,mountId,scope,...(tool==='AskUserQuestion'?{messageId:scope.messageId,token:view.state.question.token}:{})}};
 const event=target=>target.scope.toolName==='AskUserQuestion'?{type:'CLAUDE_UI_QUESTION_PAUSE',threadId:target.threadId,mountId:target.mountId,messageId:target.messageId,token:target.token}:{type:'CLAUDE_UI_DECISION_PAUSE',threadId:target.threadId,mountId:target.mountId,scope:target.scope};
 const receipt=async(target,handled,after=0)=>{const message=(target.scope.toolName==='AskUserQuestion'?'Native question':'Native decision')+' Pause completed';let rows;await expect.poll(async()=>{rows=(await logs()).slice(after).filter(row=>row.message===message&&row.meta?.mountId===target.mountId&&row.meta?.messageId===target.scope.messageId&&row.meta?.handled===handled);return rows.length},{timeout:10000}).toBeGreaterThan(0);return rows};
 const open=async()=>{await section.getByRole('button',{name:'Use native interface',exact:true}).click();const seen=new Set();for(let i=0;i<100;i++){if((await context()).native?.state?.status==='live')break;const text=await section.locator('[data-terminal-text]').innerText().catch(()=>''),stage=recognizeOnboardingPrompt(text,project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100)}await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');const c=await context(),owner={pid:c.native.state.nativePid,processStart:await processStart(c.native.state.nativePid),ownerId:c.native.state.ownerId,sessionId:c.claude.sessionId};assert.ok(owner.processStart);if(proof.sessionId)assert.equal(owner.sessionId,proof.sessionId);else proof.sessionId=owner.sessionId;proof.owners.push(owner);await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await save();return owner};
 try {
  const producer=JSON.parse(await readFile('/control/producer-pack-inputs.json','utf8')),files={};for(const name of ['runtime/fe.js','runtime/index.cjs']){files[name]=sha(await readFile(join(userDataDir,'apack/packs/default-setup',name)));assert.equal(files[name],producer[name])}await writeFile(join(output,'installed-candidate-before-journey.json'),JSON.stringify({passed:true,files}));
  await app.waitForSurface('default-setup/threads');await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');await page.waitForTimeout(700);await app.navigate('default-setup/threads');
  await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return!!c.currentThread?.id&&c.openedThreadId===null&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code')}),{timeout:15000}).toBe(true);
  await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'})});
  await replace('Review the release summary before we choose the next step.');await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);
  for(const[tool,prompt,freshPrompt,testId]of[
   ['Read','Read the release checklist before continuing.','Read the release checklist after recovery.','native-read-approval'],
   ['AskUserQuestion','Ask me which release audience to target.','Ask me which release audience to target after recovering the question.','native-question-panel'],
   ['EnterPlanMode','Explore the release implementation before making changes.','Explore the release implementation after recovery.','native-plan-panel'],
  ]) {
   if(image&&tool!=='AskUserQuestion')continue;
   phase('decision-cancellation-start',{tool});let owner=proof.owners.at(-1);if(!owner||await processStart(owner.pid)!==owner.processStart)owner=await open();
   const row={tool,prompt,freshPrompt,owner};proof.decisions.push(row);const panel=page.getByTestId(testId);
   await replace(prompt);await send.click();await expect.poll(()=>model.waiting,{timeout:15000}).toBe(tool);row.draft='Keep my release summary draft while reviewing '+(tool==='AskUserQuestion'?'the audience':tool==='Read'?'the checklist':'the plan')+'.';await replace(row.draft);row.retained=await document();model.releaseDecision(tool);
   await expect(panel).toBeVisible();row.original=await frame(tool);if(tool==='AskUserQuestion'){await panel.getByRole('radio',{name:'Developers People integrating the updated behavior',exact:true}).check();row.original=await frame(tool)}
   if(image){
    await panel.getByRole('button',{name:'Write your own answer',exact:true}).click();
    await panel.getByLabel('Attach image',{exact:true}).setInputFiles({name:'Unsent-summary.png',mimeType:'image/png',buffer:image});
    const attached=panel.getByRole('button',{name:'Remove Unsent-summary.png',exact:true});
    await expect(attached).toBeVisible();
    await attached.scrollIntoViewIfNeeded();
    row.original=await frame(tool);
   }
   await capture(tool+'-pending',panel);assert.deepEqual(await document(),row.retained);
   if(conversionHold){
    const api=JSON.parse(await readFile(join(conversionHold,'api.json'),'utf8'));
    assert.ok(Number.isInteger(api.pid)&&api.pid!==owner.pid);
    await writeFile(join(conversionHold,'arm'),'1',{mode:0o600,flag:'wx'});
    const submit=panel.getByRole('button',{name:'Submit answers',exact:true});
    await submit.click();
    let held;
    await expect.poll(async()=>{held=await readFile(join(conversionHold,'held.json'),'utf8').then(JSON.parse).catch(error=>{if(error.code==='ENOENT')return;throw error});return held?.pid},{timeout:4000}).toBe(owner.pid);
    assert.deepEqual(held.inputs,[sha(image)]);assert.deepEqual(held.outputs,['image']);
    await expect(panel.getByText('Waiting for Claude…',{exact:true})).toBeVisible({timeout:1500});
    await expect(submit).toBeDisabled();
    await expect(panel.getByRole('button',{name:'Cancel',exact:true})).toBeEnabled({timeout:1500});
    row.heldConversion={...held,apiPid:api.pid,atCancel:0};
    await capture(tool+'-converting',panel);
    row.heldConversion.atCancel=Date.now();
    assert.ok(row.heldConversion.atCancel-held.at<4500,'The click must precede the native request deadline');
   }
   const before=(await logs()).length;await panel.getByRole('button',{name:'Cancel',exact:true}).click();await expect(panel).toBeHidden();await receipt(row.original,true,before);await expect.poll(()=>processStart(owner.pid),{timeout:15000}).not.toBe(owner.processStart);row.cancelled=await context();assert.equal(row.cancelled.claude.pendingControlRequest,undefined);assert.deepEqual(await document(),row.retained);row.validCancelReceipts=await receipt(row.original,true,before);
   if(conversionHold){
    await assert.rejects(stat(join(conversionHold,'escaped.json')),{code:'ENOENT'});
    row.heldConversion.retiredWithoutDelivery=true;
   }
   row.reopened=await open();assert.notEqual(row.reopened.ownerId,owner.ownerId);await replace(freshPrompt);await send.click();await expect.poll(()=>model.waiting,{timeout:15000}).toBe(tool);await replace(row.draft);row.freshRetained=await document();model.releaseDecision(tool);await expect(panel).toBeVisible();row.fresh=await frame(tool);assert.notEqual(row.fresh.scope.messageId,row.original.scope.messageId);
   const retired={...row.original,threadId:row.fresh.threadId,mountId:row.fresh.mountId},stale=event(retired),start=(await logs()).length;await app.sendEvent({type:'SEND_TO_SURFACE',surface:'default-setup/threads',events:[stale,stale]});
   await expect.poll(async()=>{const message=(tool==='AskUserQuestion'?'Native question':'Native decision')+' Pause completed';return(await logs()).slice(start).filter(log=>log.message===message&&log.meta?.messageId===retired.scope.messageId&&log.meta?.mountId===retired.mountId&&log.meta?.handled===false).length},{timeout:10000}).toBe(2);
   row.staleDelivery={event:stale,receipts:await receipt(retired,false,start)};assert.equal(await processStart(row.reopened.pid),row.reopened.processStart);assert.deepEqual((await frame(tool)).scope,row.fresh.scope);assert.deepEqual(await document(),row.freshRetained);await capture(tool+'-fresh',panel);
   if(tool==='AskUserQuestion'){if(image)await expect(panel.getByRole('list',{name:'Question images'})).toHaveCount(0);await panel.getByRole('radio',{name:'Developers People integrating the updated behavior',exact:true}).check();await panel.getByRole('button',{name:'Submit answers',exact:true}).click();await expect.poll(()=>model.calls.some(call=>call.nativeQuestionResult&&!call.nativeQuestionError&&JSON.stringify(call.nativeQuestionResult).includes('Developers')),{timeout:15000}).toBe(true)}
   else if(tool==='Read'){await panel.getByRole('button',{name:'Approve',exact:true}).click();await expect.poll(()=>model.calls.some(call=>call.referenceReadId==='native_reference_retry'&&call.referenceReadResult&&!call.referenceReadError),{timeout:15000}).toBe(true)}
   else {
    await panel.getByRole('button',{name:'Decline',exact:true}).click();
    // Original rejection journals the denial and waits for a person; it does not request a model continuation.
    await expect.poll(async()=>{const root=join(workspace,'.claude/projects'),files=await readdir(root,{recursive:true});assert.ok(files.length<=4096);const matches=files.filter(name=>basename(name)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);const bytes=await readFile(join(root,matches[0]),'utf8');assert.ok(bytes.length<=16*1048576);const results=bytes.trim().split('\n').map(JSON.parse).flatMap(entry=>Array.isArray(entry.message?.content)?entry.message.content:[]);row.planDecline=results.find(block=>block.type==='tool_result'&&block.tool_use_id==='native_plan_recovery');return row.planDecline?.is_error===true},{timeout:15000}).toBe(true);
   }
   await expect(panel).toBeHidden();await expect.poll(async()=>(await context()).native?.state?.busy,{timeout:15000}).toBe(false);assert.deepEqual(await document(),row.freshRetained);row.resolved=await context();assert.equal(row.resolved.claude.sessionId,proof.sessionId);assert.equal(await processStart(row.reopened.pid),row.reopened.processStart);row.status='complete';await save();
  }
  proof.followup='Continue the release summary with the confirmed decisions.';const beforeFollowup=await context();await replace(proof.followup);await send.click();await expect.poll(async()=>{const c=await context();return c.claude?.chatState==='success'&&c.native?.state?.busy===false&&c.messages.filter(message=>message.sender==='user'&&message.text===proof.followup&&message.context?.cliUuid).length===1&&c.claude.turns===beforeFollowup.claude.turns+1&&c.native.state.session.turns===c.claude.turns&&c.claude.totalCostUsd>beforeFollowup.claude.totalCostUsd&&c.claude.totalCostUsd===c.native.state.session.totalCostUsd},{timeout:15000}).toBe(true);await replace('Ready to continue the release review.');await expect(send).toBeEnabled();proof.final=await context();await capture('recovered');
  if(image) {
   const encoded=image.toString('base64');
   assert.ok(!JSON.stringify(model.calls).includes(encoded));
   const root=join(workspace,'.claude/projects'),files=await readdir(root,{recursive:true});
   const journal=files.find(name=>basename(name)===proof.sessionId+'.jsonl');
   assert.ok(journal);
   assert.ok(!(await readFile(join(root,journal),'utf8')).includes(encoded));
   proof.imageCancellation={sha256:sha(image),noProviderImage:true,noNativeJournalImage:true,noFreshQuestionImage:true};
  }
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();for(const owner of proof.owners)await expect.poll(()=>processStart(owner.pid),{timeout:15000}).not.toBe(owner.processStart);proof.writerRetired=true;proof.diagnostics=(await logs()).filter(row=>row.message?.includes(' Pause ')||row.message?.includes('[killTurn]'));await writeFile(join(output,'decision-cancellation-diagnostics.json'),JSON.stringify(proof.diagnostics,null,2));proof.status='complete';phase('decision-cancellation-complete');
 } catch(error){proof.error={name:error.name,message:error.message};proof.observed=await context().catch(()=>null);await page.screenshot({path:join(output,'decision-cancellation-failure.png')}).catch(()=>{});throw error}finally{await save()}
}
