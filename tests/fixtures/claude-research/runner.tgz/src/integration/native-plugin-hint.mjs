import assert from 'node:assert/strict';
import {access,mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {setTimeout as delay} from 'node:timers/promises';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {record} from '../protocol/record.mjs';

import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {nativeAgentMediaRouteObserver} from '../protocol/native-agent-media-route.mjs';
const [checkout,executable,root,officialSnapshot]=process.argv.slice(2),sha=value=>createHash('sha256').update(value).digest('hex');
assert.equal(process.platform,'linux');await access('/.dockerenv');assert.equal(process.getuid(),1000);assert.ok(isAbsolute(root));assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
for(const name of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[name],undefined);
await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'native-plugin-hint-')),config=join(workspace,'.claude'),observation=join(workspace,'native-drafts.jsonl'),preload=join(workspace,'observe.mjs');
await mkdir(config,{recursive:true});
const plugin=join(workspace,'plugin');
for(const path of [join(plugin,'.claude-plugin'),join(plugin,'hooks')])await mkdir(path,{recursive:true});
await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'document-paste-review',version:'0.0.1'}));
await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
let marketplaceSource,marketplaceArgs=[],hintValue='release-hint-review@agent-skills',officialProvenance;
const gitEnv={PATH:'/usr/local/bin:/usr/bin:/bin'};
if(officialSnapshot){
 assert.ok(isAbsolute(officialSnapshot));officialProvenance=JSON.parse(await readFile(join(officialSnapshot,'provenance.json'),'utf8'));
 assert.equal(officialProvenance.repository,'https://github.com/anthropics/skills.git');assert.equal(officialProvenance.commit,'dbd4588f9e1033efb41dad4bef2f7947c8993d44');
 const repository=join(officialSnapshot,'repository'),manifest=await readFile(join(repository,'.claude-plugin/marketplace.json'));assert.equal(sha(manifest),officialProvenance.manifestSha256);
 const metadata=JSON.parse(manifest);assert.equal(metadata.name,'anthropic-agent-skills');assert.ok(metadata.plugins.some(item=>item.name==='document-skills'));
 const gitConfig=join(workspace,'offline-gitconfig');await writeFile(gitConfig,'[url '+JSON.stringify('file://'+repository)+']\n\tinsteadOf = https://github.com/anthropics/skills.git\n\tinsteadOf = https://github.com/anthropics/skills\n[protocol "file"]\n\tallow = always\n');
 Object.assign(gitEnv,{GIT_CONFIG_GLOBAL:gitConfig,GIT_CONFIG_NOSYSTEM:'1',GIT_ALLOW_PROTOCOL:'file:https',GIT_TERMINAL_PROMPT:'0'});
 marketplaceSource='anthropics/skills';marketplaceArgs=[];assert.equal(officialProvenance.completeGitObjectClosure,true);hintValue='document-skills@anthropic-agent-skills';
 await writeFile(join(workspace,'official-provenance.json'),JSON.stringify(officialProvenance,null,2)+'\n');
}else{
const marketplace=join(workspace,'marketplace'),candidate=join(marketplace,'plugins/release-hint-review');
for(const path of [join(marketplace,'.claude-plugin'),join(candidate,'.claude-plugin'),join(candidate,'commands')])await mkdir(path,{recursive:true});
await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:'agent-skills',owner:{name:'Private synthetic fixture'},plugins:[{name:'release-hint-review',source:'./plugins/release-hint-review',description:'Private release-review recommendation fixture'}]}));
await writeFile(join(candidate,'.claude-plugin/plugin.json'),JSON.stringify({name:'release-hint-review',version:'0.0.1',description:'Private release-review recommendation fixture'}));
await writeFile(join(candidate,'commands/review-release.md'),'Review the release notes without changing files.\n');
marketplaceSource=marketplace;
}
await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('prompt.submit',async($,e,next)=>{await $.fs.write('native-document-submit.json',JSON.stringify({text:e.text,attachments:e.attachments??[]}));return next(e)});}`);
await writeFile(join(config,'settings.json'),JSON.stringify({theme:'dark',apiKeyHelper:'/usr/bin/printf research-fixture-key'})+'\n');await writeFile(preload,nativeAgentMediaRouteObserver(observation));
const service=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(service,'query.ts')).href),store=await import(pathToFileURL(join(service,'handle-store.ts')).href),{prepareClaudeNativeTerminal}=await import(pathToFileURL(join(service,'terminal-owner.ts')).href);
const command="/usr/bin/printf '%s\\n' 'Release check complete.' '<claude-code-hint v=1 type=plugin value="+hintValue+" />'";
const env={...gitEnv,HOME:workspace,CLAUDE_CONFIG_DIR:config,BUN_OPTIONS:'--preload='+preload};
const registration=await record({executable,cwd:workspace,output:join(workspace,'registration'),env:{...gitEnv,HOME:workspace,CLAUDE_CONFIG_DIR:config},args:['--setting-sources','','plugin','marketplace','add',marketplaceSource,...marketplaceArgs],timeoutMs:20000,maxBytes:1024*1024});await writeFile(join(workspace,'registration-result.json'),JSON.stringify({registration,driverSha256:sha(await readFile(new URL(import.meta.url))),syntheticModelSha256:sha(await readFile(new URL('../protocol/synthetic-model.mjs',import.meta.url))),scope:'Native marketplace registration only; a refusal does not prove recommendation or app support.'},null,2)+'\n');assert.equal(registration.code,0,'Original private marketplace registration refused');
const seed=await startSyntheticModel(workspace,'TextOnly',{captureMessages:true}),model=await startSyntheticModel(workspace,'Bash',{captureMessages:true,forceBash:true,bashCommand:command,maxRequests:4});
await writeFile(preload,(await readFile(preload,'utf8'))+`{const fs=await import('node:fs'),runtime=await import('/$bunfs/root/chunk-a7b8k0bt.js');let previous='',count=0;const timer=setInterval(()=>{if(count>=200)return;try{const b=runtime.Zh();if(b?.surface!=='terminal')return;const c=b.toolContext(new AbortController()),value={pid:process.pid,hint:c.session.pendingHint.getSnapshot(),dialogs:c.dialogStore.getState().open.map(item=>({id:item.id,kind:item.kind,...item.kind==='plugin_hint'?{payload:item.payload}:{}}))},encoded=JSON.stringify(value);if(encoded!==previous){previous=encoded;count++;fs.appendFileSync(${JSON.stringify(join(workspace,'hint-state.jsonl'))},encoded+'\\n')}}catch(error){fs.writeFileSync(${JSON.stringify(join(workspace,'hint-observer-error.txt'))},String(error))}},25);timer.unref();}`);
let owner,native,seedResult,unsubscribe,timer,screen,sequence=0,lastAction=0,theme=false,security=false,selected=false,trusted=false,trustAt=0,terminal='';const receipts=[];
const wait=async(check,message,ms=20000)=>{const until=Date.now()+ms;while(Date.now()<until){if(await check())return;await delay(50)}throw Error(message)};
const observed=async()=>{try{return(await readFile(observation,'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse).at(-1)}catch(error){if(error.code==='ENOENT')return;throw error}};
try{
 owner=await store.openConversation('plugin-hint-review',JSON.stringify({cwd:workspace,allowedTools:['Bash'],pluginDir:[plugin]}),()=>query({cliPath:executable,cwd:workspace,env:{...env,ANTHROPIC_BASE_URL:seed.url},pluginDir:[plugin],tools:[],keepStdinOpen:true,replayUserMessages:true}),async turn=>{for await(const line of turn.handle.events){}seedResult=await turn.handle.result;owner.release(turn.handle)});
 await owner.handle.initialized;owner.start('Seed the owned plugin recommendation review.',async turn=>{for await(const line of turn.handle.events){}seedResult=await turn.handle.result;owner.release(turn.handle)});await wait(()=>seedResult&&!owner.busy,'Print seed did not settle');
 const sessionId=owner.sessionId,oldPid=owner.handle.pid;native=await store.openNativeTerminal('plugin-hint-review',{cliPath:executable,env:{...env,ANTHROPIC_BASE_URL:model.url}},async options=>{assert.deepEqual(options.pluginDir,[plugin]);return prepareClaudeNativeTerminal(options)});
 globalThis.self??=globalThis;const {Terminal}=createRequire(join(checkout,'packages/default-setup/package.json'))('@app/claude-terminal-xterm');screen=new Terminal({cols:100,rows:30,allowProposedApi:true});let updating=false;
 const observe=async()=>{if(updating)return;updating=true;try{const chunks=native.output.filter(row=>row.sequence>sequence);if(chunks.length){terminal=(terminal+chunks.map(row=>row.text).join('')).slice(-131072);await new Promise(resolve=>screen.write(chunks.map(row=>row.text).join(''),resolve));sequence=chunks.at(-1).sequence;}if(Date.now()-lastAction<250||native.state.status==='live')return;const b=screen.buffer.active,text=Array.from({length:screen.rows},(_,i)=>b.getLine(b.baseY+i)?.translateToString(true)??'').join('\n'),prompt=recognizeOnboardingPrompt(text,workspace);let input;if(prompt==='theme'&&!theme){theme=true;input='\r'}else if(prompt==='security-notes'&&!security){security=true;input='\r'}else if(prompt==='workspace-trust'&&!selected){selected=true;trustAt=Date.now();input='\x1b[B'}else if(prompt==='workspace-trust-selected'){selected=true;if(!trustAt)trustAt=Date.now();if(!trusted&&Date.now()-trustAt>1200){trusted=true;input='\r'}}if(input){lastAction=Date.now();native.input(native.state.ownerId,input);}}finally{updating=false}};
 unsubscribe=native.subscribe(()=>void observe());timer=setInterval(()=>void observe(),100);await observe();await wait(()=>native.state.status==='live','Original native onboarding did not finish',25000);
 await native.submit('Run the private release check and report its result.');
 const states=async()=>{try{return(await readFile(join(workspace,'hint-state.jsonl'),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse)}catch(error){if(error.code==='ENOENT')return [];throw error}};
 let admitted;
 await wait(async()=>{admitted=(await states()).find(row=>row.dialogs.some(item=>item.kind==='plugin_hint'));return !!admitted},'Original plugin hint was not admitted',12000);
 let projected;await wait(async()=>{await native.refreshNotice();projected=native.state.notice;return projected?.kind==='plugin_hint'},'Original source-ready recommendation was not projected');
 assert.deepEqual(projected.choices.map(choice=>choice.value),['yes','no','disable']);await native.answerNotice({...projected,decision:'no'});
 await wait(async()=>!(await states()).at(-1)?.dialogs.some(item=>item.kind==='plugin_hint'),'Original recommendation did not acknowledge defer');
 await assert.rejects(native.answerNotice({...projected,decision:'no'}),/expired/);
 await writeFile(join(workspace,'route.json'),JSON.stringify({targetSha256:sha(await readFile(executable)),sessionId,oldPid,nativePid:native.state.pid,registration,officialProvenance,command,admitted,projected,decision:'no',states:await states(),modelCalls:model.calls,realModelRequests:0,scope:'Original harmless Bash hint, typed original recommendation projection/defer and stale replay rejection only. Optional official metadata is an immutable sparse Git snapshot mirrored through private Git configuration; no plugin installation/execution or app host acceptance.'},null,2)+'\n');console.log(JSON.stringify({workspace,admitted,realModelRequests:0}));

}finally{
 clearInterval(timer);unsubscribe?.();screen?.dispose();store.killAllHandles();if(native)await native.close();
 await writeFile(join(workspace,'terminal.txt'),terminal);await writeFile(join(workspace,'model-calls.json'),JSON.stringify({seed:seed.calls,native:model.calls},null,2)+'\n');await writeFile(join(workspace,'shutdown.json'),JSON.stringify({nativePid:native?.state.pid,nativeExit:native?.state.exitCode,ownerReleased:store.getNativeTerminal('plugin-hint-review')===undefined,driverSha256:sha(await readFile(new URL(import.meta.url))),syntheticModelSha256:sha(await readFile(new URL('../protocol/synthetic-model.mjs',import.meta.url)))})+'\n');await seed.close();await model.close();
}
