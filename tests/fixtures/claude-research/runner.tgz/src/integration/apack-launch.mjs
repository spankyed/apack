import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, realpath, mkdir, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// Launch this script with the isolated worktree's tsx loader and a minimal environment.
const [checkoutArg, executableArg, workspaceArg] = process.argv.slice(2);
if (!checkoutArg || !executableArg || !workspaceArg) {
  throw new Error('Expected isolated-apack-worktree, pinned-Claude-executable, disposable-workspace');
}
const checkout = await realpath(checkoutArg);
const primary = await realpath('/Users/spankyed/Develop/Projects/apack/monorepo');
assert.notEqual(checkout, primary, 'Refusing to load product code from the shared primary checkout');
const executable = resolve(executableArg);
const workspace = resolve(workspaceArg);
assert.equal(process.env.HOME, workspace, 'Use an isolated HOME for the probe');
assert.equal(process.env.CLAUDE_CODE_SIMPLE, '1', 'Bare-mode environment is required for this probe');
for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN']) {
  assert.equal(process.env[key], undefined, `Do not supply credentials: ${key}`);
}
const { query } = await import(pathToFileURL(join(checkout,
  'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href);
await mkdir(join(workspace, '.claude'), { recursive: true });
const settingsPath = join(workspace, '.claude', 'settings.json');
const policy = JSON.stringify({ permissions: { disableBypassPermissionsMode: 'disable' } });
await writeFile(settingsPath, policy, { flag: 'wx' });
const cases = [];
for (const settingSources of [[], ['user']]) {
  const handle = await query({ cliPath: executable, cwd: workspace, env: {
    PATH: process.env.PATH, HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'),
    CLAUDE_CODE_SIMPLE: undefined, ANTHROPIC_BASE_URL: 'http://127.0.0.1:9',
    DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1',
  }, settingSources, tools: [], strictMcpConfig: true, noSessionPersistence: true,
  permissionMode: 'default', allowDangerouslySkipPermissions: true, effort: 'xhigh' });
  try {
    const initialized = await handle.initialized;
    assert.equal(initialized.current_permission_mode, 'default');
    let bypass;
    if (settingSources.length === 0) {
      assert.equal(await handle.setPermissionMode('bypassPermissions'), 'bypassPermissions');
      assert.equal(await handle.setPermissionMode('default'), 'default');
      bypass = 'accepted';
    } else {
      await assert.rejects(handle.setPermissionMode('bypassPermissions'), /disabled by settings or configuration/);
      assert.equal(await handle.setPermissionMode('default'), 'default');
      bypass = 'rejected';
    }
    cases.push({ settingSources, initialMode: initialized.current_permission_mode, bypass });
  } finally { await handle.close(); }
}
assert.equal(await readFile(settingsPath, 'utf8'), policy);
console.log(JSON.stringify({ evidence: 'apack-launch-contracts', checkout,
  targetSha256: createHash('sha256').update(await readFile(executable)).digest('hex'),
  cases, policyFileUnchanged: true, userPromptsSent: 0,
  qualification: 'Actual CLI launch/settings selection and in-memory mode controls; no model prompt or user credentials.' }));
