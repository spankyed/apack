import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { findOwnedBroker } from './native-terminal-broker-loss-journey.mjs';

export const brokerApprovalPrompts = [
  'Read the first release checklist before summarizing it.',
  'Read the revised release checklist after reconnecting.',
];

export async function driveBrokerApprovalLoss({ page, expect, context, composer, section, replace, openNative, proof, output, birth, save, model, phase, userDataDir, readFiles }) {
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.requireBrokerApprovalLoss && boundary.networkDisabled && boundary.pinnedExecutableReadOnly && boundary.profileTmpfs);
  proof.scope = 'Loss of the private terminal broker while an original Claude Read approval is pending.';
  const approval = page.getByTestId('native-read-approval');
  const show = section.getByRole('button', { name: 'Use native interface', exact: true });
  const back = section.getByRole('button', { name: 'Back to conversation', exact: true });
  const terminalInput = section.getByRole('textbox', { name: 'Terminal input', exact: true });
  const draft = 'Keep my unsent release summary through this interruption.';
  const captures = async (label, controls) => {
    for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
      await page.setViewportSize(viewport);
      for (const control of controls) await expect(control).toBeInViewport({ ratio: 1 });
      const file = 'terminal-broker-approval-' + label + '-' + size + '.png';
      await page.screenshot({ path: join(output, file), animations: 'disabled' });
      proof.captures.push(file);
    }
  };
  const submitRead = async (index, owner) => {
    await expect.poll(async () => (await context()).native.state.busy).toBe(false);
    await terminalInput.pressSequentially(brokerApprovalPrompts[index]);
    await terminalInput.press('Enter');
    await expect.poll(async () => (await context()).claude.pendingControlRequest?.nativeTerminal?.ownerId, { timeout: 15000 }).toBe(owner);
    await back.click();
    await expect(approval.getByTestId('native-read-path')).toHaveText(readFiles[index]);
    await expect(composer).toBeHidden();
    return (await context()).claude.pendingControlRequest;
  };

  await replace(draft);
  await show.click();
  const oldOwner = proof.initial.native.state.ownerId;
  const old = await submitRead(0, oldOwner);
  const before = await context();
  assert.ok(old.approvalMessageId);
  const oldToolId = 'native_broker_approval_1';
  const newToolId = 'native_broker_approval_2';
  const broker = await findOwnedBroker(proof.pid);
  proof.approvalLoss = { old, broker, draft, before };
  const approve = approval.getByRole('button', { name: 'Approve', exact: true });
  await captures('pending', [approve]);
  await save();
  assert.deepEqual(await findOwnedBroker(proof.pid), broker);
  assert.equal(await birth(broker.pid), broker.start);
  process.kill(broker.pid, 'SIGKILL');
  await expect.poll(() => birth(broker.pid)).toBe(null);
  await expect.poll(() => birth(proof.pid), { timeout: 15000 }).toBe(null);
  await expect.poll(async () => (await context()).claude.pendingControlRequest ?? null).toBe(null);
  await expect(approval).toBeHidden();
  await expect(composer).toHaveText(draft);
  await expect(section.getByRole('status')).toContainText('disconnected unexpectedly');
  const interrupted = await context();
  const cancelled = interrupted.messages.find(message => message.id === old.approvalMessageId);
  assert.equal(cancelled?.blockResponse?.cancelled, true);
  assert.equal(interrupted.claude.sessionId, before.claude.sessionId);
  assert.equal(interrupted.claude.totalCostUsd, before.claude.totalCostUsd);
  Object.assign(proof.approvalLoss, { retired: true, cancelled });
  await captures('cancelled', [composer, show]);
  await save();

  await page.setViewportSize({ width: 1100, height: 900 });
  await openNative();
  const reopened = await context();
  const pid = reopened.native.state.nativePid;
  const start = await birth(pid);
  assert.ok(start);
  proof.resumedWriter = { pid, start };
  assert.equal(reopened.threadId, interrupted.threadId);
  assert.equal(reopened.native.state.sessionId, before.claude.sessionId);
  assert.notEqual(reopened.native.state.ownerId, oldOwner);
  const freshBroker = await findOwnedBroker(pid);
  assert.equal(freshBroker.socket, broker.socket);
  assert.notDeepEqual(freshBroker, broker);
  proof.approvalLoss.freshBroker = freshBroker;
  const fresh = await submitRead(1, reopened.native.state.ownerId);
  assert.notEqual(fresh.requestId, old.requestId);
  assert.notEqual(fresh.approvalMessageId, old.approvalMessageId);
  proof.approvalLoss.fresh = fresh;
  await save();

  const arrivals = async () => {
    const log = await readFile(join(userDataDir, 'apack/logs/main.log'), 'utf8');
    return [...log.matchAll(/Incoming: "INTERACTIVE_MSG_RESPONSE"/g)].length;
  };
  const count = await arrivals();
  const transport = await page.context().newCDPSession(page);
  const sent = [];
  transport.on('Network.webSocketFrameSent', ({ response }) => {
    if (response.opcode !== 1 || !response.payloadData.includes('INTERACTIVE_MSG_RESPONSE')) return;
    const frame = JSON.parse(response.payloadData);
    for (const operation of Array.isArray(frame) ? frame : [frame]) {
      if (operation.params?.path === 'bus.send' && operation.params.input?.event?.type === 'INTERACTIVE_MSG_RESPONSE') {
        sent.push(operation.params.input.event);
      }
    }
  });
  try {
    await transport.send('Network.enable');
    await page.evaluate(messageId => window.applicationState.system.get('default-setup/threads')
      .send({ type: 'RESPOND_TO_BLOCK_INTERACTION', messageId, response: { approved: true } }), old.approvalMessageId);
    await expect.poll(() => sent.length).toBe(1);
    assert.deepEqual(sent[0], {
      type: 'INTERACTIVE_MSG_RESPONSE', messageId: old.approvalMessageId, threadId: reopened.threadId, response: { approved: true },
    });
    await expect.poll(arrivals).toBe(count + 1);
  } finally {
    await transport.detach();
  }
  proof.approvalLoss.staleOutbound = sent[0];
  const afterStale = await context();
  assert.deepEqual(afterStale.claude.pendingControlRequest, fresh);
  assert.deepEqual(afterStale.messages.find(message => message.id === old.approvalMessageId), cancelled);
  assert.ok(!model.calls.some(call => call.brokerApprovalResult?.tool_use_id === newToolId));
  proof.approvalLoss.staleBackendArrivals = (await arrivals()) - count;
  await captures('fresh', [approve]);
  await approve.click();
  await expect(approval).toBeHidden();
  await expect(composer).toHaveText(draft);
  await expect.poll(async () => {
    const current = await context();
    return current.claude.chatState === 'success' && !current.native.state.busy
      && current.messages.some(message => message.sender === 'assistant' && message.text === 'Revised release checklist reviewed.');
  }, { timeout: 15000 }).toBe(true);

  const results = model.calls.flatMap(call => call.brokerApprovalResults ?? []);
  const freshResults = results.filter(result => result.tool_use_id === newToolId);
  assert.equal(freshResults.length, 1);
  assert.ok(!freshResults[0].is_error && JSON.stringify(freshResults[0]).includes('Owned revised release checklist'));
  assert.ok(!results.some(result => result.tool_use_id === oldToolId && !result.is_error));
  proof.final = await context();
  assert.equal(proof.final.claude.sessionId, before.claude.sessionId);
  assert.equal(proof.final.claude.totalCostUsd, proof.final.native.state.session.totalCostUsd);
  for (const message of before.messages.filter(message => message.sender === 'user' && message.context?.cliUuid)) {
    assert.equal(proof.final.messages.filter(row => row.id === message.id && row.context?.cliUuid === message.context.cliUuid).length, 1);
  }
  proof.approvalLoss.modelResults = results;
  await captures('recovered', [composer]);
  await show.click();
  await section.getByRole('button', { name: 'Stop session', exact: true }).click();
  await expect.poll(() => birth(pid), { timeout: 15000 }).toBe(null);
  Object.assign(proof, { stopped: true, status: 'complete' });
  await save();
  phase('terminal-broker-approval-loss-complete');
}
