import { existsSync } from 'node:fs';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { hash } from '../artifacts/runs.mjs';

const macBinary = '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37';
async function platformTools(checkout) {
  const directory = join(checkout, 'packages/default-setup/src/features/code/be/services/claude-code');
  const [tools, bindings] = await Promise.all([
    import(pathToFileURL(join(directory, 'native-platform-runtime.ts')).href),
    import(pathToFileURL(join(directory, 'native-platform-bindings.ts')).href),
  ]);
  return { ...tools, linux: bindings.claudeNativeLinuxBindings };
}

/** Admit the actual platform/bytes before any target process starts; hosted flags never permit Mac-local runs. */
export async function requireReviewedNativeAppTarget(checkout, executable) {
  const linuxHost = process.platform === 'linux' && process.arch === 'arm64' && existsSync('/.dockerenv');
  const macHost = process.platform === 'darwin' && process.arch === 'arm64'
    && process.env.GITHUB_ACTIONS === 'true' && process.env.RUNNER_ENVIRONMENT === 'github-hosted';
  if (!linuxHost && !macHost) throw Error('Native app acceptance requires the Linux arm64 container or an actual hosted Mac runner');
  const { linux } = await platformTools(checkout);
  const actual = hash(await readFile(executable)), expected = linuxHost ? linux.binarySha256 : macBinary;
  if (actual !== expected) throw Error('Native app acceptance target differs from the reviewed platform binary');
  return { platform: process.platform, arch: process.arch, binarySha256: actual };
}

/** Our observers use the same original namespaces/fingerprints as the shipped adapter. */
export async function adaptNativeResearchPreload(checkout, source) {
  const { claudeNativePlatformRuntime, rewriteClaudeNativePlatformSelectors } = await platformTools(checkout);
  const adapted = rewriteClaudeNativePlatformSelectors(source)
    .replaceAll("'" + macBinary + "'", 'requireClaudeNativePlatform().binarySha256');
  return claudeNativePlatformRuntime + adapted;
}
