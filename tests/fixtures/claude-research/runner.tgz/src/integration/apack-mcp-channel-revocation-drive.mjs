import assert from 'node:assert/strict';
import {lstat,readFile,rename,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {channelEchoTool,channelRelayPrompts,channelRelayRequest,channelRelayVerdict} from '../protocol/owned-channel-relay.mjs';
import {channelServer} from './owned-channel-installation.mjs';

/** Check whether the original native owner continues to accept denials from a revoked channel. */
export async function driveOwnedChannelRevocation({page,expect,context,composer,send,section,replace,proof,output,
  debug,receipts,relayDirectory,control,birth,save,phase}) {
  assert.match(control,/^\/work\/\.claude-research\/policy-transition-channel-permission[0-9]+$/);
  const ready=JSON.parse(await readFile(join(control,'ready.json'),'utf8'));
  assert.equal(ready.profile,'channel-permission');
  assert.equal((await lstat(join(control,'ready.json'))).uid,0);
  const readLog=()=>readFile(debug,'utf8');
  const registration='MCP server "'+channelServer+'": Channel notifications registered';
  await expect.poll(async()=> (await readLog()).includes(registration),{timeout:18000}).toBe(true);
  const wire=async()=>{
    const text=await readFile(receipts,'utf8');
    return text.slice(0,text.lastIndexOf('\n')+1).split('\n').filter(Boolean).map(JSON.parse);
  };
  const approval=page.getByRole('region',{name:channelEchoTool+' approval',exact:true});
  await replace(channelRelayPrompts[0]);await send.click();
  await expect(approval).toBeVisible();
  const offer=async()=> (await wire()).find(row=>row.direction==='in'&&row.value.method===channelRelayRequest)?.value.params;
  await expect.poll(offer,{timeout:12000}).toBeDefined();
  const original=await offer();
  assert.equal(original.tool_name,channelEchoTool);
  const pending=()=>context().then(state=>state.claude.pendingControlRequest);
  const id=(await pending()).approvalMessageId;
  proof.channelRevocation={original,approvalMessageId:id,ready};await save();
  const previous=(await readLog()).length;
  const receiptPath=join(control,'receipt-1.json');
  await writeFile(join(control,'request-1.json'),JSON.stringify({sequence:1,mode:'restricted'}),{flag:'wx'});
  await expect.poll(async()=>lstat(receiptPath).then(info=>info.uid===0,error=>error.code==='ENOENT'?false:Promise.reject(error)),{timeout:9000}).toBe(true);
  const receipt=JSON.parse(await readFile(receiptPath,'utf8'));
  assert.equal(receipt.uid,0);
  assert.deepEqual(JSON.parse(await readFile(receipt.path,'utf8')),{channelsEnabled:false});
  await expect.poll(async()=> (await readLog()).slice(previous).includes('Detected change to '+receipt.path),{timeout:12000}).toBe(true);
  proof.channelRevocation.policyReceipt=receipt;
  const deniedByPolicy=async()=> (await readLog()).slice(previous).split('\n').find(line=>
    line.includes('Channel notifications skipped: channels not enabled by org policy'));
  const current=(await pending())?.approvalMessageId;
  assert.equal(current,id);
  const request=join(relayDirectory,'reply-1.json');
  await writeFile(request+'.pending',JSON.stringify({requestId:original.request_id,behavior:'deny'}),{flag:'wx'});
  await rename(request+'.pending',request);
  await expect.poll(async()=> (await wire()).some(row=>row.direction==='out'&&row.value.method===channelRelayVerdict
    &&row.value.params.request_id===original.request_id),{timeout:8000}).toBe(true);
  const disposition=async()=> (await readLog()).slice(previous).split('\n').find(line=>
    line.includes('notifications/claude/channel/permission: '+original.request_id+' → deny'));
  let marked;
  const quietUntil=Date.now()+1250;
  await expect.poll(async()=>{
    marked=await disposition();
    return !!marked||!(await pending())||Date.now()>=quietUntil;
  },{timeout:4000}).toBe(true);
  const result={beforeVerdict:current,afterVerdict:(await pending())?.approvalMessageId,
    disposition:marked??await disposition()??null,policyDiagnostic:await deniedByPolicy()??null,
    toolCalls:(await wire()).filter(row=>row.direction==='in'&&row.value.method==='tools/call').length};
  proof.channelRevocation.result=result;await save();
  assert.equal(result.toolCalls,0);
  assert.ok(!result.disposition?.includes('matched pending'),'A channel denial matched after native managed revocation');
  assert.equal(result.afterVerdict,id);
  await approval.getByRole('button',{name:'Deny',exact:true}).click();
  await expect(approval).toHaveCount(0);
  await expect.poll(async()=> !(await pending()),{timeout:10000}).toBe(true);
  await replace(proof.draft);
  await expect(composer).toHaveText(proof.draft);
  const file='native-channel-managed-revocation-compact.png';
  await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);
  proof.final=await context();
  assert.equal(proof.final.claude.sessionId,proof.sessionId);
  assert.equal(await birth(proof.pid),proof.processStart);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
  proof.status='complete';await save();phase('native-channel-managed-revocation-complete');
}
