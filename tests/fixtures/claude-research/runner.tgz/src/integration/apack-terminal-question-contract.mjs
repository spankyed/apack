import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';
import { hash } from '../artifacts/runs.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { nativeDialogInspector } from '../protocol/native-dialog-inspector.mjs';
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs';

const [checkout, executable, workspace, scenario = 'terminal-question-contract'] = process.argv.slice(2);
const renderScenario=scenario.startsWith('terminal-question-render'),productAnswer=scenario==='terminal-question-owner'||scenario==='terminal-question-render-owner';
assert.ok(['terminal-question-contract','terminal-question-owner','terminal-question-render','terminal-question-render-owner'].includes(scenario));
assert.equal(process.env.HOME, workspace);
assert.equal(hash(await readFile(executable)), '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');
for (const name of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN']) assert.equal(process.env[name], undefined);
const root = join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const { query } = await import(pathToFileURL(join(root,'query.ts')).href);
const store = await import(pathToFileURL(join(root,'handle-store.ts')).href);
const { prepareClaudeNativeTerminal } = await import(pathToFileURL(join(root,'terminal-owner.ts')).href);
const configDir = join(workspace,'.claude'); await mkdir(configDir,{recursive:true});
await writeFile(join(configDir,'settings.json'),JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',statusLine:{type:'command',command:'/usr/bin/printf NativeQuestionOwner',refreshInterval:1}}));
const pluginDir = renderScenario ? join(workspace,'question-render-plugin') : undefined;
if(pluginDir){
 await mkdir(join(pluginDir,'.claude-plugin'),{recursive:true});await mkdir(join(pluginDir,'hooks'));
 await writeFile(join(pluginDir,'.claude-plugin/plugin.json'),JSON.stringify({name:'question-render-contract',version:'0.0.1'}));
 await writeFile(join(pluginDir,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
 await writeFile(join(pluginDir,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'AskUserQuestion'},async($,e,next)=>{if(e.surface!=='desktop')return next({...e,props:{...e.props,questions:e.props.questions.map(q=>({...q,question:'Native display: '+q.question}))}});const{Box,Text,Button}=$.ui.resolve(e);await $.fs.write('native-question-render-input.json',JSON.stringify({surface:e.surface,id:e.requestId,...e.props}));return Box({children:[Text({children:['Native question tools']}),Button({key:'inspect-question',label:'Inspect native question',onPress:async()=>$.fs.write('native-question-render-pressed.json',JSON.stringify({surface:e.surface,id:e.requestId}))}),await next({...e,props:{...e.props,questions:e.props.questions.map(q=>({...q,...(e.viewport?.columns===101?{options:[...q.options,{label:'Injected',description:'Must not be displayed'}]}:{question:(e.viewport?.columns===102?'Later display: ':'Native display: ')+q.question})}))}})]});});}`);
}
const inspector = join(workspace,'question-inspector.mjs'), evidencePath = join(workspace,'native-dialog-shapes.json');
await writeFile(inspector,nativeDialogInspector(evidencePath,{questionContracts:true}));
const env = { HOME: workspace, CLAUDE_CONFIG_DIR: configDir, BUN_OPTIONS:'--preload='+inspector, CLAUDE_CODE_SIMPLE:undefined, DISABLE_AUTOUPDATER:'1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1' };
const seed = await startSyntheticModel(workspace,'TextOnly'), model = await startSyntheticModel(workspace,'AskUserQuestion',{captureMessages:true});
let native, owner, seeded, terminal='', seen=0, theme=false, security=false, navigated=false, trusted=false, lastInput=0, timer, unsubscribe;
async function waitFor(check, label, ms=20000) { const deadline=Date.now()+ms; while(Date.now()<deadline){if(await check())return;await delay(50)} throw Error(label) }
async function evidence() { try{return JSON.parse(await readFile(evidencePath,'utf8'))}catch(error){if(error.code!=='ENOENT')throw error;return {events:[]}} }
try {
 owner=await store.openConversation('question-contract',JSON.stringify({cwd:workspace,allowedTools:['AskUserQuestion'],...(pluginDir?{pluginDir:[pluginDir]}:{})}),()=>query({cliPath:executable,cwd:workspace,env:{...env,ANTHROPIC_BASE_URL:seed.url},tools:[],keepStdinOpen:true,replayUserMessages:true,...(pluginDir?{pluginDir:[pluginDir]}:{})}),async turn=>{for await(const line of turn.handle.events){}seeded=await turn.handle.result;owner.release(turn.handle)});
 await owner.handle.initialized;
 owner.start('Seed the private native question contract.',async turn=>{for await(const line of turn.handle.events){}seeded=await turn.handle.result;owner.release(turn.handle)});
 await waitFor(()=>seeded&&!owner.busy,'Seed did not become idle');
 const sessionId=owner.sessionId;
 native=await store.openNativeTerminal('question-contract',{cliPath:executable,env:{...env,ANTHROPIC_BASE_URL:model.url}},prepareClaudeNativeTerminal);
 const observe=()=>{
  for(const chunk of native.output)if(chunk.sequence>seen){terminal+=chunk.text;seen=chunk.sequence;}
  if(Date.now()-lastInput<200)return;
  const screen=recognizeOnboardingPrompt(terminal,workspace);let input;
  if(screen==='theme'&&!theme){theme=true;input='\r'}
  else if(screen==='security-notes'&&theme&&!security){security=true;input='\r'}
  else if(screen==='workspace-trust'&&!navigated){navigated=true;input='\x1b[B'}
  else if(screen==='workspace-trust-selected'&&navigated&&!trusted){trusted=true;input='\r'}
  if(input!==undefined){lastInput=Date.now();native.input(native.state.ownerId,input)}
 };
 unsubscribe=native.subscribe(observe);timer=setInterval(observe,100);observe();
 await waitFor(()=>native.state.status==='live'&&native.state.mainStatus?.includes('NativeQuestionOwner'),'Native question owner not ready');
 const receipt=await native.submit('Ask the fixed synthetic question.');
 await waitFor(async()=> (await evidence()).events.some(event=>event.value?.open?.some(dialog=>dialog.kind==='permission_ask_user_question')),'Native question descriptor was not observed');
 await writeFile(join(workspace,'native-question-before-answer.txt'),terminal);
 if(renderScenario)assert.ok(terminal.includes('Native display:'),'Original terminal did not display the rewritten question');
 const [dialog]=await native.getQuestionDialogs();
 assert.equal(dialog.toolName,'AskUserQuestion');
 assert.equal(dialog.shownInput.questions[0].question,'Which synthetic fixture should be selected?');
 let renderedFrame;
 if(renderScenario){
  const ui=native.uiTransport,client='native-question-render-contract';
  await ui.request({subtype:'ui_attach',surface:'desktop',client_id:client,answers:[],viewport:{columns:100,rows:30}});
  const frame=scenario==='terminal-question-render-owner'?await native.renderQuestionDialog({id:dialog.id,revision:dialog.revision,sessionId:dialog.sessionId,clientId:client}):await ui.request({subtype:'ui_render',surface:'desktop',client_id:client,component:'AskUserQuestion',instance_id:dialog.requestId,props:{tool:'AskUserQuestion',questions:dialog.shownInput.questions}});
  renderedFrame=frame;
  await writeFile(join(workspace,'native-question-render-frame.json'),JSON.stringify(frame,null,2));
  assert.equal(frame.hooked,true);assert.equal(frame.props.questions[0].question,'Native display: Which synthetic fixture should be selected?');
  const nodes=[];const visit=value=>{if(!value||typeof value!=='object')return;if(value.type)nodes.push(value);for(const child of Object.values(value))visit(child)};visit(frame.tree);
  const button=nodes.find(node=>node.type==='Button'&&node.props.key==='inspect-question');assert.ok(button,'Original question hook button missing');
  assert.equal((await ui.request({subtype:'ui_press',surface:'desktop',...button.press,key:button.props.key})).handled,true);
  await waitFor(async()=>{try{return JSON.parse(await readFile(join(workspace,'native-question-render-pressed.json'),'utf8')).id===dialog.requestId}catch(error){if(error.code!=='ENOENT')throw error;return false}},'Native question callback did not run');
 }
 let response={id:dialog.id,revision:dialog.revision,sessionId:dialog.sessionId,answer:{answers:{'Which synthetic fixture should be selected?':'Beta'},annotations:{}}};
 if(scenario==='terminal-question-render-owner'){
  const ui=native.uiTransport,client='native-question-render-contract';
  const render=columns=>native.renderQuestionDialog({id:dialog.id,revision:dialog.revision,sessionId:dialog.sessionId,clientId:client,viewport:{columns,rows:30}});
  const standalone=await ui.request({subtype:'ui_render',surface:'desktop',client_id:client,component:'AskUserQuestion',instance_id:'standalone-preview',props:{tool:'AskUserQuestion',questions:dialog.shownInput.questions}});
  assert.equal(standalone.hooked,true);assert.equal(standalone.question,undefined,'Generic UI rendering must not acquire native question reply authority');
  const rejected=await render(101);
  assert.equal(rejected.question.shownInput.questions[0].question,dialog.shownInput.questions[0].question,'Invalid option rewrite must fall back to original card');
  assert.equal(rejected.question.shownInput.questions[0].options.length,2);
  const current=await render(100);
  const answer={answers:{[current.question.shownInput.questions[0].question]:'Beta'},annotations:{}};
  await assert.rejects(native.answerQuestionDialog({...response,answer,renderToken:renderedFrame.question.token}),/drawing changed or expired/);
  await native.holdQuestionDialog({id:dialog.id,revision:dialog.revision,sessionId:dialog.sessionId,clientId:client,renderToken:renderedFrame.question.token});
  const held=await render(102);
  assert.equal(held.question.shownInput.questions[0].question,current.question.shownInput.questions[0].question,'Started question labels changed after a redraw');
  assert.equal(held.question.token,renderedFrame.question.token);
  response={...response,answer,renderToken:held.question.token,draftStarted:true};
  await writeFile(join(workspace,'native-question-guarded-render.json'),JSON.stringify({rejected,current,staleTokenRefused:true},null,2));
 }
 for(const answer of [{answers:{foreign:'No'}},{questions:[]},{afkTimeoutMs:1000}])await assert.rejects(native.answerQuestionDialog({...response,answer}),/Native question answer refused/);
 assert.equal((await native.getQuestionDialogs())[0].revision,dialog.revision,'Refused answers must not retire the live question');
 if(productAnswer)await native.answerQuestionDialog(response);
 else {
  // Original terminal UI selects the second option, preserving an independent reference answer.
  native.input(native.state.ownerId,'\x1b[B');await delay(200);native.input(native.state.ownerId,'\r');
 }
 await waitFor(async()=> (await evidence()).events.some(event=>event.type==='closed'&&event.value.type==='answered'),'Native terminal did not answer the question',10000);
 await waitFor(()=>model.calls.length>=2&&!native.busy,'Question did not resume the original native model');
 const captured=await evidence(),closed=captured.events.find(event=>event.type==='closed'&&event.value.type==='answered');
 await assert.rejects(native.answerQuestionDialog(response),/changed or expired/);
 assert.equal(closed.value.result.behavior,'allow');
 assert.equal(closed.value.result.updatedInput.answers['Which synthetic fixture should be selected?'],'Beta');
 assert.deepEqual(closed.value.result.updatedInput.annotations,{});
 assert.equal(captured.questionContracts[0]?.admitted.kind,'admitted');
 for(const name of ['unknownAnswer','changedQuestions','forgedHostField'])assert.equal(captured.questionContracts[0][name].kind,'refused');
 await writeFile(join(workspace,'native-question-contract.json'),JSON.stringify({receipt,closed,calls:model.calls},null,2));
 await native.close();
 console.log(JSON.stringify({evidence:'apack-native-'+scenario,targetSha256:hash(await readFile(executable)),nativeOriginalQuestion:true,nativeTerminalAnswer:!productAnswer,nativeProductAnswer:productAnswer,nativeQuestionRender:renderScenario,nativeRenderCallback:renderScenario,nativeRewrittenReply:scenario==='terminal-question-render-owner',nativeInvalidAnswerRefused:true,nativeReplayRefused:true,nativeAnswerAdmission:true,sameSession:receipt.sessionId===sessionId,ownedShutdown:true,syntheticApiRequests:seed.calls.length+model.calls.length,realModelRequests:0,scope:'Original native question descriptor/result contract; no app question UI acceptance'}));
} finally {
 clearInterval(timer);unsubscribe?.();store.killAllHandles();if(native)await native.close();
 await writeFile(join(workspace,'native-question-terminal.txt'),terminal);await writeFile(join(workspace,'native-question-model-calls.json'),JSON.stringify(model.calls,null,2));
 await seed.close();await model.close();
}
