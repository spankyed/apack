import argparse
import hashlib
import json
import struct
import tarfile
from pathlib import Path


parser = argparse.ArgumentParser(description='Verify the saved offline desktop channel replacement proof.')
parser.add_argument('evidence', type=Path)
parser.add_argument('--screenshots', type=Path)
args = parser.parse_args()
root = args.evidence
receipt = json.loads((root / 'process-receipt.json').read_text())
boundary = json.loads((root / 'boundary.json').read_text())
assert receipt['exitCode'] == 0 and receipt['productCommit'] == boundary['productCommit']
assert receipt['researchCommit'] == boundary['researchCommit']
assert not receipt['containerState']['Running'] and not receipt['containerState']['OOMKilled']
assert all(boundary[key] for key in ('networkDisabled', 'pinnedExecutableReadOnly', 'requireMcpChannelReplacement'))
assert 'All frozen inputs unchanged after journey' in (root / 'app.log').read_text()
request_method = 'notifications/claude/channel/permission_request'
verdict_method = 'notifications/claude/channel/permission'

with tarfile.open(root / 'results.tar.gz') as archive:
    def read(name):
        entry = archive.getmember('./' + name)
        assert entry.isfile() and entry.size < 10 * 1024 * 1024
        return archive.extractfile(entry).read()

    def read_json(name):
        return json.loads(read(name))

    app = read_json('direct-electron-proof.json')
    assert app['route'] == 'real-Electron-fresh-native-command'
    assert app['status'] == 'complete' and app['quit'] == 'normal' and app['rootExitObserved']
    proof = read_json('electron-results/native-command.json')
    assert proof['status'] == 'complete' and proof['staleRefused'] and proof['writersRetired']
    old, fresh = proof['retiredOffer'], proof['freshOffer']
    writer = proof['resumedWriter']
    assert len({proof['pid'], writer['pid'], old['peerPid'], fresh['peerPid']}) == 4
    assert writer['ownerId'] != proof['initial']['native']['state']['ownerId']
    assert old['requestId'] != fresh['requestId'] and old['approvalId'] != fresh['approvalId']
    assert read_json('electron-results/writer-retirement.json')['retired']
    assert read_json('electron-results/profile-restoration.json')['restored']

    wire = [json.loads(line) for line in read('native-channel-receipts.jsonl').splitlines()]
    effects = [row for row in wire if row['value'].get('method') in (request_method, verdict_method, 'tools/call')]
    assert [row['value']['method'] for row in effects] == [request_method, request_method, verdict_method, verdict_method, 'tools/call']
    assert [row['direction'] for row in effects] == ['in', 'in', 'out', 'out', 'in']
    assert [row['pid'] for row in effects] == [old['peerPid']] + [fresh['peerPid']] * 4
    for row, offer in zip(effects[:4], (old, fresh, old, fresh), strict=True):
        assert row['value']['params']['request_id'] == offer['requestId']
        if row['direction'] == 'out':
            assert row['value']['params']['behavior'] == 'allow'
    assert effects[-1] == proof['freshExecuted']
    assert effects[-1]['value']['params']['arguments'] == {'message': 'Owned release echo 3'}

    debug = read(f"native-channel-debug.{writer['pid']}.log").decode()
    prefix = verdict_method + ': '
    refused = prefix + old['requestId'] + ' → allow (no pending entry'
    accepted = prefix + fresh['requestId'] + ' → allow (matched pending'
    assert debug.count(refused) == debug.count(accepted) == 1 and debug.index(refused) < debug.index(accepted)

    journal = read('electron-results/native-parent-transcript.jsonl')
    rows = [json.loads(line) for line in journal.splitlines()]
    session = proof['sessionId']
    assert {row['sessionId'] for row in rows if 'sessionId' in row} == {session}
    human = [row['message']['content'] for row in rows if row['type'] == 'user']
    assert [value for value in human if isinstance(value, str)] == [
        proof['seed'],
        'Check the first release echo through the channel.',
        'Check the third release echo through the channel.',
    ]
    results = [block for blocks in human if isinstance(blocks, list) for block in blocks if block['type'] == 'tool_result']
    assert [block['tool_use_id'] for block in results] == ['toolu_owned_relay_1', 'toolu_owned_relay_3']
    assert results[0]['is_error'] and 'outcome is unknown' in results[0]['content']
    assert not results[1].get('is_error') and results[1]['content'] == [{'type': 'text', 'text': 'The owned release echo finished.'}]

    captures = {}
    if args.screenshots:
        args.screenshots.mkdir(exist_ok=True)
    for label, dimensions in [('normal', (1100, 900)), ('compact', (680, 600))]:
        name = 'native-channel-replacement-' + label + '.png'
        assert name in proof['captures']
        screenshot = read('electron-results/' + name)
        assert screenshot[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II', screenshot[16:24]) == dimensions
        captures[name] = hashlib.sha256(screenshot).hexdigest()
        if args.screenshots:
            (args.screenshots / name).write_bytes(screenshot)

print(json.dumps({
    'sessionId': session,
    'retiredOffer': old,
    'freshOffer': fresh,
    'replacementNativePid': writer['pid'],
    'originalPendingOutcome': 'unknown after stop',
    'staleVerdict': 'no pending entry',
    'freshToolRuns': 1,
    'ownedProcessesRetired': True,
    'captures': captures,
    'journalSha256': hashlib.sha256(journal).hexdigest(),
}, indent=2))
