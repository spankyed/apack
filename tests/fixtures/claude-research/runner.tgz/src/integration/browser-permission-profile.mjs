import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,writeFile,lstat,mkdir,rename} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const setup='/work/.claude-research/profile-setup-app10',sha=b=>createHash('sha256').update(b).digest('hex');
function boundary(workspace){assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));assert.match(workspace,/^\/work\/\.claude-research\/browser-permission-app[0-9]+$/);}
async function bytes(path){try{const s=await lstat(path);assert.ok(s.isFile()&&s.uid===1000&&s.size<=2*1048576);return{data:await readFile(path),mode:s.mode&0o7777}}catch(error){if(error.code==='ENOENT')return null;throw error}}
function paths(){return{config:join(setup,'app-data/claude-code-profile/config/.claude.json'),local:join(setup,'project/.claude/settings.local.json')}}
/** A real original MCP registration selects the original prefix-based approval producer. No browser/account gate is overridden. */
export async function prepareBrowserPermissionProfile({workspace,setupWorkspace}){
 boundary(workspace);assert.equal(setupWorkspace,setup);const settings=await bytes(join(setup,'app-data/claude-code-profile/config/settings.json'));assert.equal(sha(settings.data),'5eb7b71763d6c0fc454f048fe69cb174724f161d2f4cdc50a8776c83cbc2e128');
 const files=paths(),original={},ledger={files:{}};await mkdir(join(workspace,'browser-preimages'),{mode:0o700});
 for(const[name,path]of Object.entries(files)){const before=await bytes(path);original[name]=before;ledger.files[name]={path,present:!!before,mode:before?.mode??0o600,sha256:before?sha(before.data):null};if(before)await writeFile(join(workspace,'browser-preimages',name),before.data,{mode:0o600,flag:'wx'});}
 assert.ok(original.config);const config=JSON.parse(original.config.data);assert.ok(!Object.hasOwn(config.mcpServers??{},'claude-in-chrome'),'Do not replace another native browser namespace owner');
 await writeFile(join(workspace,'browser-profile.json'),JSON.stringify(ledger),{mode:0o600,flag:'wx'});
 const bootstrap=join(workspace,'mcp-bootstrap.mjs'),receipts=join(workspace,'mcp-receipts.jsonl');
 const source='await import('+JSON.stringify(new URL('../protocol/synthetic-browser-permission-server.mjs',import.meta.url).href)+');\n';await writeFile(bootstrap,source,{mode:0o600,flag:'wx'});
 try{await writeFile(files.config,JSON.stringify({...config,mcpServers:{...config.mcpServers,'claude-in-chrome':{type:'stdio',command:process.execPath,args:[bootstrap],env:{APACK_BROWSER_APPROVAL_RECEIPTS:receipts}}}}));return{receipts,bootstrap,originalConfigSha256:ledger.files.config.sha256,restore:()=>recoverBrowserPermissionProfile(workspace)}}catch(error){await recoverBrowserPermissionProfile(workspace);throw error}
}
/** The caller must stop the owned app/native writers and hold the work lock before emergency recovery. */
export async function recoverBrowserPermissionProfile(workspace){
 boundary(workspace);const ledger=JSON.parse(await readFile(join(workspace,'browser-profile.json'),'utf8')),expected=paths(),restored=[];
 for(const[name,path]of Object.entries(expected)){const entry=ledger.files[name];assert.equal(entry.path,path);const before=entry.present?await readFile(join(workspace,'browser-preimages',name)):null;assert.equal(before?sha(before):null,entry.sha256);const current=await bytes(path),preserved=join(workspace,'preserved-browser-'+name);
  if(current&&(!before||!current.data.equals(before))){assert.ok(!existsSync(preserved),'Preserve unexpected repeated profile changes');await rename(path,preserved);}
  if(before&&!existsSync(path))await writeFile(path,before,{mode:entry.mode,flag:'wx'});const after=await bytes(path);assert.equal(!!after,entry.present);if(before){assert.deepEqual(after.data,before);assert.equal(after.mode,entry.mode);}restored.push({name,path,present:!!after,sha256:after?sha(after.data):null});
 }
 const result={restored:true,files:restored};await writeFile(join(workspace,'browser-profile-restoration.json'),JSON.stringify(result));return result;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){assert.equal(process.argv.length,3);console.log(JSON.stringify(await recoverBrowserPermissionProfile(process.argv[2])));}
