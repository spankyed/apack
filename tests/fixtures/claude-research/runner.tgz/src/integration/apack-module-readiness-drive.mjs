import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs';
import { readCombinedEverydayJournal } from './apack-combined-everyday-drive.mjs';
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs';
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs';
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';

const sha = bytes => createHash('sha256').update(bytes).digest('hex');

async function processStart(pid) {
  try {
    const stat = await readFile('/proc/' + pid + '/stat', 'utf8');
    const fields = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
    return fields[0] === 'Z' ? undefined : fields[19];
  } catch (error) {
    if (error.code === 'ENOENT') return undefined;
    throw error;
  }
}

export async function driveModuleReadiness({ checkout, workspace, env }) {
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.moduleReadiness && boundary.networkDisabled && boundary.profileTmpfs);
  const project = join(workspace, 'project');
  const observer = join(workspace, 'readiness');
  await mkdir(project);
  await mkdir(observer, { mode: 0o700 });
  execFileSync('/usr/bin/git', ['init', '--quiet', project], { timeout: 5000 });
  const account = await configureNativeCreditAccount(workspace, 'oauth', { featureCache: 'native-defaults' });
  const configDir = join(workspace, '.claude');
  const configPath = join(configDir, '.claude.json');
  const settingsPath = join(configDir, 'settings.json');
  const config = JSON.parse(await readFile(configPath, 'utf8'));
  config.hasCompletedOnboarding = true;
  config.fullscreenUpsellSeenCount = 3;
  await writeFile(configPath, JSON.stringify(config));
  await writeFile(settingsPath, JSON.stringify({ theme: 'dark', model: 'opus' }));
  const configBefore = await readFile(configPath);
  const settingsBefore = await readFile(settingsPath);
  const tls = await prepareNativeCreditTls(join(workspace, 'account-tls'));
  const billing = await startNativeCreditBilling(tls, { allowMutations: false, evidencePath: join(workspace, 'account-live.json') });
  const model = await startSyntheticModel(workspace, 'TextOnly', { captureMessages: true, maxRequests: 8, textReply: 'The readiness review is complete.' });
  const launchEnv = {
    ...env, ...account, NODE_EXTRA_CA_CERTS: tls.ca, ANTHROPIC_BASE_URL: model.url,
    DISABLE_AUTOUPDATER: '1', PATH: '/frozen-claude:' + env.PATH, CLAUDE_RESEARCH_PROJECT: project,
    CLAUDE_RESEARCH_MODULE_READINESS: observer, CLAUDE_RESEARCH_API_NODE_OPTIONS: env.NODE_OPTIONS,
  };
  delete launchEnv.ANTHROPIC_API_KEY;
  const proof = { status: 'running', captures: [] };
  const result = join(workspace, 'electron-results');
  try {
    await driveFreshNativeApp({ checkout, workspace, env: launchEnv, route: 'real-Electron-module-readiness',
      journeyBudgetMs: 150000, journey: args => journey({ ...args, proof, observer, model }) });
    assert.notEqual(await processStart(proof.cliPid), proof.processStart);
    const journal = await readCombinedEverydayJournal(join(workspace, 'app-data'), proof.sessionId, undefined, configDir);
    await writeFile(join(result, 'native-parent-transcript.jsonl'), journal);
    const rows = journal.toString().trim().split('\n').map(JSON.parse);
    const humans = rows.filter(row => row.type === 'user' && !row.isMeta && !row.isVirtual &&
      !row.isSidechain && (!row.origin || row.origin.kind === 'human'));
    const user = humans.find(row => row.uuid === proof.delivered.uuid);
    assert.ok(user, 'Native journal must contain the same human UUID');
    assert.equal(humans.filter(row => row.uuid === proof.delivered.uuid).length, 1);
    const content = user.message.content;
    assert.equal(typeof content === 'string' ? content : content.map(block => block.text).join(''), proof.draft);
    proof.journalSha256 = sha(journal);
  } finally {
    await model.close();
    await billing.close();
    await writeFile(join(result, 'model-calls.json'), JSON.stringify(model.calls));
    await writeFile(configPath, configBefore);
    await writeFile(settingsPath, settingsBefore);
    assert.deepEqual(await readFile(configPath), configBefore);
    assert.deepEqual(await readFile(settingsPath), settingsBefore);
    proof.profileRestored = true;
    await writeFile(join(result, 'module-readiness.json'), JSON.stringify(proof, null, 2));
  }
}

async function journey({ app, page, project, output, expect, proof, observer, model }) {
  const save = () => writeFile(join(output, 'module-readiness.json'), JSON.stringify(proof, null, 2));
  const events = async () => (await readFile(join(observer, 'traffic.jsonl'), 'utf8')).trim().split('\n').map(JSON.parse);
  await expect.poll(async () => (await events()).some(row => row.kind === 'installed')).toBe(true);
  await app.waitForSurface('default-setup/threads');
  await app.navigate('default-setup/threads');
  await expect.poll(() => page.evaluate(() => !!window.applicationState.system.get('default-setup/threads').getSnapshot().context.currentThread?.id)).toBe(true);
  await app.navigate('host/settings');
  await page.evaluate(() => {
    const actor = window.applicationState.system.get('host/settings');
    actor.send({ type: 'FEATURE.SELECT', featureId: 'default-setup/code' });
    actor.send({ type: 'TAB.SELECT', tab: 'features' });
  });
  await expect(page.locator('#claude-profile')).toHaveValue('shared');
  await page.evaluate(() => {
    const actor = window.applicationState.system.get('host/settings');
    actor.send({ type: 'TAB.SELECT', tab: 'general' });
    actor.send({ type: 'GENERAL_NAV.SELECT', item: 'secrets' });
  });
  const provider = page.getByText('Claude Code CLI', { exact: true }).locator('..').locator('..').locator('..');
  await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');
  await page.waitForTimeout(700);
  await app.navigate('default-setup/threads');
  await expect.poll(() => page.evaluate(() => {
    const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    return !!c.currentThread?.id && c.tabs.every(tab => c.tabsRead.includes(tab.id));
  })).toBe(true);
  await page.evaluate(project => {
    const actor = window.applicationState.system.get('default-setup/threads');
    actor.send({ type: 'VIEW_DASHBOARD' });
    actor.send({ type: 'NEW_THREAD_IN_PROJECT', directory: project });
    actor.send({ type: 'SET_MODE', mode: 'Claude Code' });
    actor.send({ type: 'SET_PHASE', phase: 'Edit' });
  }, project);
  const context = () => page.evaluate(() => {
    const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    return { threadId: c.currentThread?.id, claude: c.currentThread?.context?.claudeCode,
      messages: c.currentThread?.messages, native: Object.values(c.nativeTerminalViews).find(view => view.threadId === c.currentThread?.id)?.state,
      ui: Object.values(c.nativeUiViews).find(view => view.threadId === c.currentThread?.id)?.state };
  });
  const card = page.locator('[data-onboarding-id="agent-chat-input"]');
  const composer = card.locator('.ProseMirror[contenteditable="true"]');
  const send = card.getByRole('button', { name: 'Send', exact: true });
  const section = page.getByRole('region', { name: 'Claude native interface', exact: true });
  proof.seed = 'Review the release notes before switching to the native session.';
  proof.draft = 'Summarize the release notes after native startup.';
  await composer.fill(proof.seed, { timeout: 8000 });
  await send.click({ timeout: 8000 });
  await expect.poll(async () => (await context()).claude?.turns, { timeout: 35000 }).toBe(1);
  const before = await context();
  proof.sessionId = before.claude.sessionId;
  proof.threadId = before.threadId;
  await composer.fill(proof.draft);
  await composer.press('Home');
  await composer.press('ArrowRight');
  const document = () => composer.evaluate(element => ({
    draft: element.editor.state.doc.toJSON(), selection: element.editor.state.selection.toJSON(),
  }));
  proof.before = await document();
  await save();
  await writeFile(join(observer, 'session'), proof.sessionId, { mode: 0o600, flag: 'wx' });
  await section.getByRole('button', { name: 'Use native interface', exact: true }).click({ timeout: 8000 });
  const seen = new Set();
  // A fresh owned profile may ask the original terminal trust question.
  for (let attempt = 0; attempt < 80; attempt++) {
    if ((await context()).native?.status === 'live' && (await events()).some(row => row.kind === 'ready-held')) break;
    const text = await section.locator('[data-terminal-text]').innerText({ timeout: 250 }).catch(() => '');
    const stage = recognizeOnboardingPrompt(text, project);
    if (stage && !seen.has(stage)) {
      seen.add(stage);
      await section.locator('[aria-label="Terminal input"]').focus();
      if (stage.startsWith('workspace-trust')) await page.waitForTimeout(200);
      await page.keyboard.press(stage === 'workspace-trust' ? 'ArrowDown' : 'Enter');
    }
    await page.waitForTimeout(100);
  }
  await expect.poll(async () => (await events()).some(row => row.kind === 'ready-finished'), { timeout: 8000 }).toBe(true);
  await expect.poll(async () => (await events()).some(row => row.kind === 'poll' && !row.direct), { timeout: 8000 }).toBe(true);
  const rows = await events();
  const held = rows.find(row => row.kind === 'ready-held');
  const released = rows.find(row => row.kind === 'ready-released');
  assert.ok(held && released && released.at - held.at >= 1450);
  assert.equal(rows.filter(row => row.kind === 'ready-held').length, 1);
  assert.ok(!rows.some(row => row.kind === 'ready-aborted'));
  const requested = rows.find(row => row.kind === 'ready-request');
  const pluginPolls = rows.filter(row => row.kind === 'poll' && !row.direct);
  assert.ok(requested && requested.at <= held.at);
  assert.ok(pluginPolls.some(row => row.at >= released.at));
  assert.ok(pluginPolls.every(row => row.at < requested.at || row.at >= released.at));
  proof.readiness = {
    requested, held, released,
    pluginPollsBeforeRequest: pluginPolls.filter(row => row.at < requested.at).length,
    directPollsWhileHeld: rows.filter(row => row.kind === 'poll' && row.direct && row.at >= held.at && row.at < released.at).length,
  };
  await expect.poll(async () => (await context()).native?.status, { timeout: 20000 }).toBe('live');
  proof.cliPid = (await context()).native.nativePid;
  proof.processStart = await processStart(proof.cliPid);
  assert.ok(proof.processStart);
  await section.getByRole('button', { name: 'Back to conversation', exact: true }).click({ timeout: 8000 });
  await expect.poll(async () => (await context()).ui?.status, { timeout: 20000 }).toBe('live');
  await expect(composer).toHaveText(proof.draft, { timeout: 5000 });
  proof.after = await document();
  assert.deepEqual(proof.after, proof.before);
  for (const [label, width, height] of [['normal', 1100, 900], ['compact', 680, 600]]) {
    await page.setViewportSize({ width, height });
    await expect(send).toBeInViewport({ ratio: 1 });
    const name = 'retained-draft-' + label + '.png';
    await page.screenshot({ path: join(output, name), timeout: 8000 });
    proof.captures.push(name);
  }
  await save();
  await send.click({ timeout: 8000 });
  await expect.poll(async () => (await context()).messages?.findLast(row => row.sender === 'assistant')?.text, { timeout: 20000 }).toBe('The readiness review is complete.');
  await expect.poll(async () => (await context()).claude?.turns, { timeout: 20000 }).toBe(2);
  const final = await context();
  const displayed = final.messages.filter(row => row.sender === 'user' && row.text === proof.draft);
  assert.equal(displayed.length, 1);
  assert.ok(displayed[0].context?.cliUuid);
  assert.equal(final.threadId, proof.threadId);
  assert.equal(final.claude.sessionId, proof.sessionId);
  assert.equal(final.native.nativePid, proof.cliPid);
  assert.equal(await processStart(proof.cliPid), proof.processStart);
  const matched = model.calls.filter(call => {
    const content = call.messages?.findLast(row => row.role === 'user')?.content;
    return content === proof.draft || Array.isArray(content) && content.some(block => block.type === 'text' && block.text === proof.draft);
  });
  assert.equal(matched.length, 1);
  proof.delivered = { uuid: displayed[0].context.cliUuid, modelCalls: matched.length };
  await section.getByRole('button', { name: 'Use native interface', exact: true }).click({ timeout: 8000 });
  await section.getByRole('button', { name: 'Stop session', exact: true }).click({ timeout: 8000 });
  await expect.poll(() => processStart(proof.cliPid), { timeout: 15000 }).not.toBe(proof.processStart);
  proof.status = 'complete';
  await save();
}
