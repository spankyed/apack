import assert from 'node:assert/strict';
import {access,readFile,writeFile} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';
import {pathToFileURL} from 'node:url';
import {randomUUID} from 'node:crypto';
import {prepareNativeDocumentMediaFixture} from '../protocol/native-document-media-fixture.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {hash} from '../artifacts/runs.mjs';
const [checkout,executable,root]=process.argv.slice(2),target='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10';
assert.equal(process.platform,'linux');await access('/.dockerenv');assert.equal(process.getuid(),1000);assert.ok(isAbsolute(root));assert.equal(hash(await readFile(executable)),target);
for(const name of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[name],undefined);
const fixture=await prepareNativeDocumentMediaFixture(root,{sourceRefusals:true}),{cwd,ordinary,preload,content}=fixture,exitPath=join(cwd,'native-query-exit.json');
await writeFile(preload,(await readFile(preload,'utf8'))+'\n{const {writeFileSync}=await import("node:fs");process.on("exit",code=>writeFileSync('+JSON.stringify(exitPath)+',JSON.stringify({pid:process.pid,code})));}\n');
const path=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts'),{query}=await import(pathToFileURL(path).href),model=await startSyntheticModel(cwd,'TextOnly',{captureMessages:true});
const input={type:'user',uuid:randomUUID(),message:{role:'user',content},parent_tool_use_id:null};let handle,events=[],result;
try{
 handle=await query({cliPath:executable,cwd,env:{HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),BUN_OPTIONS:'--preload='+preload,ANTHROPIC_BASE_URL:model.url},settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),settingSources:[],strictMcpConfig:true,pluginDir:[ordinary],tools:[],maxTurns:1,prompt:input,replayUserMessages:true,signal:AbortSignal.timeout(30000)});
 const initialization=await handle.initialized;for await(const event of handle.events)events.push(event);result=await handle.result;
 const observations={};for(const[name,file]of Object.entries({managed:'managed-documents.json',ordinary:'ordinary-documents.json',settled:'settled-documents.json'}))observations[name]=JSON.parse(await readFile(join(cwd,file),'utf8'));
 const exit=JSON.parse(await readFile(exitPath,'utf8'));assert.equal(exit.pid,handle.pid);assert.equal(exit.code,0);
 const evidence={targetSha256:target,checkout,querySourceSha256:hash(await readFile(path)),input,initialization,result,events,observations,calls:model.calls,exit,managedSourceSha256:fixture.managedSourceSha256,realModelRequests:0,scope:'Current product direct-query block-array transport and original document media gates only; no default composer inline upload or OS/MDM acceptance.'};
 await writeFile(join(cwd,'product-document-media.json'),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify({workspace:cwd,pid:handle.pid,sessionId:result.sessionId,nativeExit:exit.code,documents:observations.managed.rows.length,modelRequests:model.calls.filter(row=>row.path?.startsWith('/v1/messages')).length,scope:evidence.scope}));
}finally{await handle?.close();await writeFile(join(cwd,'query-events.json'),JSON.stringify({events,result,calls:model.calls},null,2)+'\n');await model.close();}
