/** Reach a real transcript row with the scroll container's ordinary wheel input. */
export async function readNativeTranscriptRow(page,expect,locator,{checkTextHit=false,companion}={}) {
  const viewport=page.getByTestId('chat-transcript').locator(':scope > div').first();
  const viewportNode=await viewport.elementHandle();
  const companionNode=await companion?.elementHandle();
  let geometry;
  try {
    if(checkTextHit){
      // Resizing can temporarily show the row before tail-following applies the new layout.
      // Start an ordinary upward read so queued tail-following cannot move the capture.
      const box=await viewport.boundingBox();
      await page.mouse.move(box.x+box.width/2,box.y+box.height/2);
      await page.mouse.wheel(0,-32);
      await viewport.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
    }
    await expect.poll(async()=>{
      geometry=await locator.evaluate(async(row,{scroll,checkTextHit,companion})=>{
        if(checkTextHit)await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
        const bounds=element=>{
          const box=element.getBoundingClientRect();
          return {top:box.top,left:box.left,bottom:box.bottom,right:box.right};
        };
        const shape=bounds(row);
        let adjacent;
        if(companion){
          const box=bounds(companion);
          adjacent={...box,loaded:companion.complete&&companion.naturalWidth>0,
            reachable:companion.contains(row.ownerDocument.elementFromPoint((box.left+box.right)/2,(box.top+box.bottom)/2))};
          shape.top=Math.min(shape.top,box.top);shape.bottom=Math.max(shape.bottom,box.bottom);
          shape.left=Math.min(shape.left,box.left);shape.right=Math.max(shape.right,box.right);
        }
        const viewport={top:0,left:0,bottom:window.innerHeight,right:window.innerWidth};
        const clipping=[];
        for(let element=scroll;element;element=element.parentElement){
          const style=getComputedStyle(element);
          const box=bounds(element);
          const inside={top:box.top+element.clientTop,left:box.left+element.clientLeft,
            bottom:box.top+element.clientTop+element.clientHeight,right:box.left+element.clientLeft+element.clientWidth};
          if(style.overflowY!=='visible'){
            viewport.top=Math.max(viewport.top,inside.top);
            viewport.bottom=Math.min(viewport.bottom,inside.bottom);
          }
          if(style.overflowX!=='visible'){
            viewport.left=Math.max(viewport.left,inside.left);
            viewport.right=Math.min(viewport.right,inside.right);
          }
          if(style.overflowX!=='visible'||style.overflowY!=='visible')clipping.push({
            element:element.tagName,testId:element.getAttribute('data-testid'),
            overflowX:style.overflowX,overflowY:style.overflowY,inside,
          });
        }
        let textRects;
        if(checkTextHit){
          const textRange=row.ownerDocument.createRange();
          textRange.selectNodeContents(row);
          textRects=[...textRange.getClientRects()].filter(rect=>rect.width>0&&rect.height>0).map(rect=>({
            top:rect.top,bottom:rect.bottom,left:rect.left,right:rect.right,
            reachable:[.1,.5,.9].every(offset=>row.contains(row.ownerDocument.elementFromPoint(
              rect.left+offset*rect.width,rect.top+rect.height/2))),
          }));
        }
        return {row:shape,viewport,clipping,textRects,adjacent,scrollTop:scroll.scrollTop,scrollHeight:scroll.scrollHeight,
          clientHeight:scroll.clientHeight};
      },{scroll:viewportNode,checkTextHit,companion:companionNode});
      const {row,viewport:view}=geometry;
      if(view.bottom-view.top<row.bottom-row.top||view.right<=view.left)return false;
      if(row.top>=view.top&&row.bottom<=view.bottom&&(!companion||geometry.adjacent.loaded&&geometry.adjacent.reachable))return !checkTextHit||geometry.textRects.length>0&&geometry.textRects.every(rect=>
        rect.top>=view.top&&rect.bottom<=view.bottom&&rect.left>=view.left&&rect.right<=view.right&&rect.reachable);
      const delta=Math.round((row.top+row.bottom-view.top-view.bottom)/2);
      await page.mouse.move((view.left+view.right)/2,(view.top+view.bottom)/2);
      await page.mouse.wheel(0,delta);
      return false;
    },{timeout:8000,intervals:[150,250,500]}).toBe(true);
    if(!checkTextHit)await expect(locator).toBeInViewport({ratio:1});
    return geometry;
  } catch(cause) {
    throw new Error('Native transcript reading geometry '+JSON.stringify(geometry),{cause});
  } finally {
    await viewportNode.dispose();
    await companionNode?.dispose();
  }
}
