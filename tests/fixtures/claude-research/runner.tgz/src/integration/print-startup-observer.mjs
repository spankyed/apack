import childProcess from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {writeFileSync} from 'node:fs';
import {join} from 'node:path';

/** Observe existing emit calls: adding data listeners would change readable flow. */
export function observePrintStartup({target,directory,maxChildren=4,maxBytes=262144}){
 const original=childProcess.spawn,records=[];
 const selected=['HOME','CLAUDE_CONFIG_DIR','ANTHROPIC_BASE_URL','BUN_OPTIONS','NODE_OPTIONS','NODE_EXTRA_CA_CERTS','CLAUDE_CODE_ENTRYPOINT'];
 function flush(row,stage){try{writeFileSync(row.path,JSON.stringify({...row.public,stage,elapsedMs:Number(process.hrtime.bigint()-row.started)/1e6,stdout:Buffer.concat(row.stdout).toString('base64'),stderr:Buffer.concat(row.stderr).toString('base64')},null,2)+'\n',{mode:0o600})}catch(error){row.public.observerWriteError=error.message}}
 function spawn(file,...rest){
  const child=Reflect.apply(original,this,[file,...rest]);
  if(file!==target||records.length>=maxChildren)return child;
  const args=Array.isArray(rest[0])?rest[0]:[],options=(Array.isArray(rest[0])?rest[1]:rest[0])??{};
  const row={started:process.hrtime.bigint(),path:join(directory,`print-${process.pid}-${records.length}.json`),stdout:[],stderr:[],public:{observerPid:process.pid,pid:child.pid,target,args:args.map(v=>String(v).slice(0,4096)).slice(0,128),cwd:options.cwd,environment:Object.fromEntries(selected.filter(k=>options.env?.[k]!==undefined).map(k=>[k,options.env[k]])),environmentKeys:Object.keys(options.env??{}).sort(),stdoutBytes:0,stderrBytes:0,stdoutCapturedBytes:0,stderrCapturedBytes:0,events:[]}};
  records.push(row);
  for(const kind of ['stdout','stderr'])if(child[kind]){const stream=child[kind],emit=stream.emit;stream.emit=function(event,...values){if(event==='data'){const bytes=Buffer.from(values[0]),count=kind+'Bytes',captured=kind+'CapturedBytes';if(row.public[count]===0)row.public[kind+'FirstByteMs']=Number(process.hrtime.bigint()-row.started)/1e6;row.public[count]+=bytes.length;const part=bytes.subarray(0,Math.max(0,maxBytes-row.public[captured]));if(part.length){row[kind].push(Buffer.from(part));row.public[captured]+=part.length}}return Reflect.apply(emit,this,[event,...values])};}
  const emit=child.emit;child.emit=function(event,...values){if(['spawn','error','exit','close'].includes(event)){row.public.events.push({event,atMs:Number(process.hrtime.bigint()-row.started)/1e6,...event==='error'?{error:{code:values[0]?.code,message:values[0]?.message}}:{values}});if(event==='close')flush(row,'closed')}return Reflect.apply(emit,this,[event,...values])};
  flush(row,'spawn-returned');return child;
 }
 childProcess.spawn=spawn;syncBuiltinESMExports();
 const onExit=()=>records.forEach(row=>flush(row,'parent-exit'));process.once('exit',onExit);
 return()=>{if(childProcess.spawn===spawn){childProcess.spawn=original;syncBuiltinESMExports()}process.removeListener('exit',onExit);records.forEach(row=>flush(row,'observer-restored'))};
}
