import assert from 'node:assert/strict';
import { join } from 'node:path';
import { createNativeTestImage } from '../protocol/native-test-image.mjs';
import { warmPrompt } from '../protocol/native-idle-compaction-model.mjs';

/** Observe the original completed-turn offer through the desktop card. */
export async function observeAutocompactOffer({ page, expect, context, composer, send, settings, output,
  proof, inference, decision, verifyDraft, verifyAttachment, verifyPanel, verifyComposition, replyAfter }) {
  const offer = page.locator('[data-native-notice="autocompact_offer"]');
  const smaller = offer.getByRole('button', { name: 'Smaller', exact: true });
  const larger = offer.getByRole('button', { name: 'Larger', exact: true });
  const keep = offer.locator('[data-native-choice="compact_keep"]');
  const accept = offer.locator('[data-native-choice="compact_accept"]');
  const limit = offer.locator('output');
  const card = page.locator('[data-onboarding-id="agent-chat-input"]');
  const settingsButton = card.getByRole('button', { name: 'Claude settings', exact: true });
  const panel = page.getByRole('dialog', { name: 'Claude Code settings', exact: true });
  const openSettings = async () => {
    if (await settingsButton.isVisible()) await settingsButton.click();
    else {
      await card.getByRole('button', { name: 'More actions', exact: true }).click();
      await page.getByRole('menuitem', { name: 'Claude settings', exact: true }).click();
    }
  };
  const model = 'claude-sonnet-5-5';
  const saved = async () => (await settings()).modelSettings?.[model]?.autoCompactWindow;
  const submit = async text => {
    await composer.fill(text);
    await expect(composer).toHaveText(text);
    await send.click({ timeout: 12000 });
  };

  proof.offer = { decision };
  assert.equal(await saved(), 700000);
  await submit(warmPrompt);
  await expect(offer).toBeVisible({ timeout: 22000 });
  await expect(limit).toHaveText('400,000 tokens');
  const original = (await context()).native.notice;
  assert.equal(original.kind, 'autocompact_offer');
  assert.equal(original.sessionId, proof.sessionId);
  assert.equal(original.selectedTokens, 400000);
  assert.equal(inference().filter(row => row.kind === 'warm').length, 1);
  assert.equal(inference().find(row => row.kind === 'warm').usage.cache_creation_input_tokens, 220000);

  await larger.click();
  await expect(limit).toHaveText('500,000 tokens');
  const moved = (await context()).native.notice;
  assert.equal(moved.id, original.id);
  assert.notEqual(moved.revision, original.revision);
  await expect(larger).toBeDisabled();
  await expect(smaller).toBeEnabled();
  await expect(accept).toContainText('500');
  assert.equal(await saved(), 700000);

  for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
    await page.setViewportSize(viewport);
    await expect(offer).toBeInViewport({ ratio: 0.8 });
    await expect(accept).toBeInViewport({ ratio: 1 });
    await expect(keep).toBeInViewport({ ratio: 1 });
    await expect(composer).toBeEditable();
    const name = 'autocompact-offer-' + size + '.png';
    await page.screenshot({ path: join(output, name), animations: 'disabled' });
    proof.captures.push(name);
    if (verifyDraft) {
      const draft = 'Keep this unsent release note while I decide.';
      await composer.fill(draft);
      await expect(offer).toBeHidden();
      await expect(composer).toHaveText(draft);
      await expect(composer).toBeFocused();
      const hidden = (await context()).native.notice;
      assert.equal(hidden.id, moved.id);
      assert.equal(hidden.revision, moved.revision);
      assert.equal(await saved(), 700000);
      const capture = 'autocompact-offer-draft-' + size + '.png';
      await page.screenshot({ path: join(output, capture), animations: 'disabled' });
      await composer.fill('');
      await expect(offer).toBeVisible();
      await expect(limit).toHaveText('500,000 tokens');
      await expect(composer).toBeFocused();
      const restored = (await context()).native.notice;
      assert.deepEqual(restored, hidden);
      (proof.draftLifecycle ??= []).push({ size, draft, hidden, restored, capture });
    }
  }
  const modelCalls = inference().length;
  if (verifyComposition) {
    const composing = () => composer.evaluate(element => element.editor.view.composing);
    await composer.focus();
    await expect(composer).toHaveText('');
    await composer.dispatchEvent('compositionstart', { data: '', bubbles: true });
    await expect.poll(composing).toBe(true);
    await expect(offer).toBeHidden();
    await expect(composer).toHaveText('');
    await expect(composer).toBeFocused();
    const hidden = (await context()).native.notice;
    const capture = 'autocompact-offer-composition-compact.png';
    await page.screenshot({ path: join(output, capture), animations: 'disabled' });
    await composer.dispatchEvent('compositionend', { data: '', bubbles: true });
    await expect.poll(composing).toBe(false);
    await expect(offer).toBeVisible();
    await expect(limit).toHaveText('500,000 tokens');
    await expect(composer).toBeFocused();
    const restored = (await context()).native.notice;
    assert.deepEqual(hidden, restored);
    assert.equal(restored.id, moved.id);
    assert.equal(await saved(), 700000);
    assert.equal(inference().length, modelCalls);
    proof.offerComposition = { capture, hidden, restored };
  }
  if (verifyAttachment) {
    const captureHidden = async tag => {
      await expect(offer).toBeHidden();
      const capture = 'autocompact-offer-' + tag + '-compact.png';
      await page.screenshot({ path: join(output, capture), animations: 'disabled' });
      return capture;
    };
    const verifyRestored = async () => {
      await expect(offer).toBeVisible();
      await expect(limit).toHaveText('500,000 tokens');
      const observation = await context();
      assert.equal(observation.native.ownerId, proof.owner.ownerId);
      assert.equal(observation.native.sessionId, proof.sessionId);
      assert.equal(observation.native.notice.id, moved.id);
      assert.equal(await saved(), 700000);
      assert.equal(inference().length, modelCalls);
      return observation.native.notice;
    };
    const filename = 'Release-preview.png';
    await composer.evaluate((element, { name, bytes }) => {
      const clipboardData = new DataTransfer();
      clipboardData.items.add(new File([new Uint8Array(bytes)], name, { type: 'image/png' }));
      element.dispatchEvent(new ClipboardEvent('paste', { clipboardData, bubbles: true, cancelable: true }));
    }, { name: filename, bytes: [...createNativeTestImage()] });
    const remove = page.getByRole('button', { name: 'Remove Release-preview 1.png', exact: true });
    await expect(remove).toBeVisible();
    await expect(composer).toHaveText('');
    proof.offerInterruption = { attachment: { capture: await captureHidden('attachment') } };
    await remove.click();
    proof.offerInterruption.attachment.restored = await verifyRestored();

    if (verifyPanel) {
      await openSettings();
      const message = 'Respond to the open Claude Code prompt before running this command.';
      await expect(card.getByText(message, { exact: true })).toBeVisible({ timeout: 12000 });
      await expect(panel).toBeHidden();
      await expect(composer).toHaveText('');
      const unchanged = await verifyRestored();
      const refusedCapture = 'autocompact-offer-panel-refusal-compact.png';
      await page.screenshot({ path: join(output, refusedCapture), animations: 'disabled' });
      proof.offerInterruption.panel = { message, unchanged, refusedCapture };
    }
  }
  if (decision === 'accept') await accept.press('Enter');
  else if (decision === 'keep') await keep.press('Enter');
  else await keep.press('Escape');
  await expect(offer).toBeHidden({ timeout: 12000 });
  const expected = decision === 'accept' ? 500000 : 700000;
  await expect.poll(saved, { timeout: 12000 }).toBe(expected);
  const outcome = decision === 'accept' ? /Autocompact set to 500k tokens/i
    : decision === 'keep' ? /Keeping 700k tokens/i : /Autocompact unchanged/i;
  await expect(page.getByText(outcome).filter({ visible: true }).first()).toBeVisible({ timeout: 12000 });
  assert.equal(inference().length, modelCalls);
  const snapshot = await context();
  assert.equal(snapshot.native.ownerId, proof.owner.ownerId);
  assert.equal(snapshot.native.sessionId, proof.sessionId);
  if (verifyPanel) {
    await openSettings();
    await expect(panel).toBeVisible({ timeout: 12000 });
    await expect(panel.getByRole('textbox', { name: 'Search Claude Code settings', exact: true })).toBeVisible();
    await expect(offer).toBeHidden();
    const reopenedCapture = 'autocompact-offer-settings-open-compact.png';
    await page.screenshot({ path: join(output, reopenedCapture), animations: 'disabled' });
    await panel.getByRole('button', { name: 'Close settings', exact: true }).click();
    await expect(panel).toBeHidden();
    await expect(composer).toBeEditable();
    await expect(offer).toBeHidden();
    assert.equal(await saved(), expected);
    assert.equal(inference().length, modelCalls);
    const afterPanel = await context();
    assert.equal(afterPanel.native.ownerId, proof.owner.ownerId);
    assert.equal(afterPanel.native.sessionId, proof.sessionId);
    proof.offerInterruption.panel.reopenedCapture = reopenedCapture;
  }
  proof.offer = { decision, original, moved, savedTokens: await saved() };

  const followup = 'Continue the release checklist after choosing the compaction size.';
  await submit(followup);
  await expect.poll(() => replyAfter(followup), { timeout: 22000 }).toBe(true);
  const continued = await context();
  assert.equal(continued.native.ownerId, proof.owner.ownerId);
  assert.equal(continued.native.sessionId, proof.sessionId);
  proof.offer.continued = true;
}
