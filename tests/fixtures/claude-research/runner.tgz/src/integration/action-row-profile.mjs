import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir,readFile,writeFile,lstat,rename} from 'node:fs/promises';
import {join,basename,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {record} from '../protocol/record.mjs';
import {MANAGED_SECURITY_KEY} from '../protocol/native-managed-security-fixture.mjs';

/** Install one ordinary local plugin through Claude; retain every temporary registry preimage. */
export async function prepareActionRowProfile({setupWorkspace,workspace,env}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.equal(process.getuid(),1000);assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');assert.match(workspace,/^\/work\/\.claude-research\/action-row-app[0-9]+$/);
 const sha=b=>createHash('sha256').update(b).digest('hex'),executable='/frozen-claude/claude';assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 const config=join(setupWorkspace,'app-data/claude-code-profile/config'),market=basename(workspace),marketplace=join(workspace,'marketplace'),plugin=join(marketplace,'plugins/release-review-controls');
 const saved=new Map();for(const relative of ['settings.json','plugins/known_marketplaces.json','plugins/installed_plugins.json']){
  const path=join(config,relative);let bytes;try{const info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1048576);bytes=await readFile(path)}catch(error){if(error.code!=='ENOENT')throw error}saved.set(relative,bytes);
 }
 assert.ok(saved.get('settings.json'));for(const name of ['native-action-row-effects.json','native-action-row-draws.json'])assert.equal(existsSync(join(setupWorkspace,'project',name)),false,'Fixture receipts must be new');for(const kind of ['cache','marketplaces'])assert.equal(existsSync(join(config,'plugins',kind,market)),false,'Fixture marketplace must be new');
 for(const path of [join(marketplace,'.claude-plugin'),join(plugin,'.claude-plugin'),join(plugin,'hooks')])await mkdir(path,{recursive:true});
 await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:market,owner:{name:'Local release review'},plugins:[{name:'release-review-controls',source:'./plugins/release-review-controls'}]}));
 await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'release-review-controls',version:'0.0.1'}));await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
 const source=`export function register(on){let original,receipts=[],draws=[];
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);
 const row=Box({flexDirection:'row',children:[Button({key:'add-checklist',label:'Add checklist',onPress:async()=>{const before=await $.prompt.read();original=before.text;const result=await $.prompt.fill({mode:'append',text:'\\nCheck migration notes.'}),after=await $.prompt.read();receipts.push({action:'add',before,result,after,surface:e.surface});await $.fs.write('native-action-row-effects.json',JSON.stringify(receipts));$.ui.invalidate('ui.render');}}),Button({key:'restore-wording',label:'Restore wording',onPress:async()=>{if(original===undefined)throw Error('No original wording');const before=await $.prompt.read(),result=await $.prompt.fill({mode:'replace',text:original}),after=await $.prompt.read();receipts.push({action:'restore',before,result,after,surface:e.surface});await $.fs.write('native-action-row-effects.json',JSON.stringify(receipts));$.ui.invalidate('ui.render');}})]});
 if(draws.length>=128)throw Error('Action-row draw limit');draws.push({surface:e.surface,component:e.component,requestId:e.requestId,explicitGap:Object.hasOwn(row.props??{},'gap')});await $.fs.write('native-action-row-draws.json',JSON.stringify(draws));return Box({children:[Text({size:'heading',weight:'medium',children:['Release review']}),row]});});}
`;
 await writeFile(join(plugin,'hooks/register.ts'),source);let restored=false;
 async function restore(){if(restored)return;const result=[];for(const[relative,before]of saved){const path=join(config,relative),preserved=join(workspace,'preserved-'+relative.replaceAll('/','-'));if(existsSync(path))await rename(path,preserved);if(before!==undefined){await mkdir(dirname(path),{recursive:true});await writeFile(path,before,{mode:0o600,flag:'wx'});assert.deepEqual(await readFile(path),before)}else assert.equal(existsSync(path),false);result.push({path:relative,originalPresent:before!==undefined,restoredPresent:existsSync(path),sha256:before===undefined?null:sha(before)});}
  for(const kind of ['cache','marketplaces']){const path=join(config,'plugins',kind,market);if(existsSync(path)){const info=await lstat(path);assert.ok(info.isDirectory()&&info.uid===process.getuid());await rename(path,join(workspace,'preserved-plugin-'+kind));}}
  for(const name of ['native-action-row-effects.json','native-action-row-draws.json']){const path=join(setupWorkspace,'project',name);if(existsSync(path))await rename(path,join(workspace,name));}
  await writeFile(join(workspace,'action-row-profile-restoration.json'),JSON.stringify({restored:true,files:result}));restored=true;
 }
 try{
  const environment={...env,HOME:join(setupWorkspace,'home'),CLAUDE_CONFIG_DIR:config,ANTHROPIC_API_KEY:MANAGED_SECURITY_KEY,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
  const runs=[];for(const args of [['--setting-sources','','plugin','marketplace','add',marketplace],['--setting-sources','','plugin','install','release-review-controls@'+market]]){
   const run=await record({executable,cwd:join(setupWorkspace,'project'),output:join(workspace,'installation'),env:environment,args,timeoutMs:20000,maxBytes:1048576});runs.push(run);assert.equal(run.code,0,'Original local plugin installation refused');assert.equal(run.status,'complete');
  }
  const registry=JSON.parse(await readFile(join(config,'plugins/installed_plugins.json'),'utf8')),entries=registry.plugins?.['release-review-controls@'+market];assert.ok(Array.isArray(entries)&&entries.length===1);assert.equal(entries[0].scope,'user');assert.equal(sha(await readFile(join(entries[0].installPath,'hooks/register.ts'))),sha(Buffer.from(source)));
  await writeFile(join(workspace,'action-row-installation.json'),JSON.stringify({runs,marketplace:market,installation:entries[0],pluginSourceSha256:sha(Buffer.from(source)),binarySha256:sha(await readFile(executable)),scope:'Ordinary local directory registration/install via original CLI. No model calls requested, private policy or manual registry fabrication.'}));
  return {restore,pluginSourceSha256:sha(Buffer.from(source))};
 }catch(error){await restore();throw error}
}
