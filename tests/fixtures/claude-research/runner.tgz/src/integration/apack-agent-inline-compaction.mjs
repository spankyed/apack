import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { promisify } from 'node:util';

import { startSyntheticAgentModel } from '../protocol/synthetic-agent-model.mjs';
import { hash } from '../artifacts/runs.mjs';

const [checkout, executable, evidence] = process.argv.slice(2);
assert.equal(process.argv.length, 5, 'Expected Apack checkout, pinned executable and new private evidence directory');
assert.equal(process.env.HOME, evidence, 'Set HOME to the disposable evidence directory');
const from = (...parts) => import(pathToFileURL(join(...parts)).href);
const directory = join(checkout, 'packages/default-setup/src/features/code/be/services/claude-code');
const { query } = await from(directory, 'query.ts');
const { argsFromOptions } = await from(directory, 'args.ts');
const targetSha256 = hash(await readFile(executable));
assert.equal(targetSha256, '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');
for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN']) assert.equal(process.env[key], undefined);
await mkdir(evidence);
const model = await startSyntheticAgentModel({ parentLaunchOnce: true, requestLimit: 6 });
let handle;
const events = [];
try {
  const name = 'status-fixture';
  const agents = { [name]: {
    description: 'Private release reviewer', prompt: 'NativeStatusChildSystem. Return the fixed review marker.',
    tools: [], maxTurns: 2, autoCompactWindow: 100_000,
  }};
  const workspace = await mkdtemp(join(evidence, 'positive-'));
  const config = (home) => ({
    HOME: home, CLAUDE_CONFIG_DIR: join(home, '.claude'), ANTHROPIC_BASE_URL: model.url,
    DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1',
  });
  const settings = JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' });
  const options = {
    cliPath: executable, cwd: workspace, env: config(workspace), settings, settingSources: [], strictMcpConfig: true,
    permissionMode: 'acceptEdits', tools: ['Agent'], allowedTools: ['Agent'], agents, replayUserMessages: true,
    keepStdinOpen: true, signal: AbortSignal.timeout(35000), model: 'sonnet', noSessionPersistence: true,
  };
  const argv = argsFromOptions(options);
  assert.deepEqual(JSON.parse(argv[argv.indexOf('--agents') + 1]), agents);
  handle = await query(options);
  const initialized = await handle.initialized;
  const positivePid = handle.pid;
  assert.ok(positivePid);
  assert.ok(initialized.agents.some(agent => agent.name === name && agent.description === agents[name].description));
  handle.send('NativeSubagentParentFixture: Run the disposable status worker.');
  for await (const event of handle.events) {
    events.push(event);
    if (event.type === 'result' && !handle.hasPendingBackgroundTasks(event) && model.calls.some(call => call.child && call.delivered)) {
      assert.equal(event.subtype, 'success');
      break;
    }
  }
  const launched = events.find(event => event.type === 'assistant' && event.message?.content?.some(block =>
    block.type === 'tool_use' && block.name === 'Agent' && block.input?.subagent_type === name));
  assert.ok(launched);
  const workerCalls = model.calls.filter(call => call.child && call.delivered);
  assert.equal(workerCalls.length, 1);
  assert.deepEqual(workerCalls[0].toolNames ?? [], []);
  assert.ok(events.some(event => event.type === 'result' && event.subtype === 'success'));
  await handle.close();
  handle = undefined;
  assert.throws(() => process.kill(positivePid, 0), { code: 'ESRCH' });
  const requests = model.messageRequestCount();
  const negative = await mkdtemp(join(evidence, 'negative-'));
  const invalidAgents = { [name]: { ...agents[name], autoCompactWindow: 99_999 } };
  const run = promisify(execFile);
  const refusal = await run(executable, argsFromOptions({ ...options, agents: invalidAgents }), {
    cwd: negative, env: { PATH: process.env.PATH, ...config(negative) }, timeout: 15000,
  }).then(() => undefined, error => ({ code: error.code, stderr: error.stderr, stdout: error.stdout }));
  assert.ok(refusal && Number.isInteger(refusal.code) && refusal.code !== 0);
  assert.match(refusal.stderr + refusal.stdout, /autoCompactWindow/);
  assert.match(refusal.stderr + refusal.stdout, /100000|100,000/);
  assert.equal(model.messageRequestCount(), requests);
  const receipt = {
    status: 'verified-inline-agent-launch-and-native-refusal', targetSha256, validDefinition: agents[name],
    acceptedAgent: initialized.agents.find(agent => agent.name === name), originalWorkerRequests: workerCalls.length,
    originalWorkerToolNames: workerCalls[0].toolNames ?? [], positiveResult: 'success', invalidWindow: 99_999,
    refusal, positiveProcessRetired: true, invalidModelRequests: 0, syntheticModelRequests: requests,
    qualification: 'Typed launch transport and native validation. Worker executed, compaction threshold behavior not triggered.',
  };
  await writeFile(join(evidence, 'proof.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt));
} finally {
  if (handle) { handle.kill(); await handle.close().catch(() => {}); }
  await model.close();
  await writeFile(join(evidence, 'events.json'), JSON.stringify(events, null, 2) + '\n');
  await writeFile(join(evidence, 'model-calls.json'), JSON.stringify(model.calls, null, 2) + '\n');
}
