import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,writeFile,lstat,mkdir,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';

/** Configure a disposable native helper; only the original Claude scheduler invokes it. */
export async function prepareChildCaptionProfile({setupWorkspace,workspace}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv'));assert.ok(existsSync('/control/offline-verified'));
 assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');assert.match(workspace,/^\/work\/\.claude-research\/child-caption-app[0-9]+$/);
 const settingsPath=join(setupWorkspace,'app-data/claude-code-profile/config/settings.json');
 const info=await lstat(settingsPath);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1024*1024);
 const original=await readFile(settingsPath),settings=JSON.parse(original);
 const receipts=join(workspace,'caption-invocations');await mkdir(receipts,{mode:0o700});
 const helper=join(workspace,'caption-helper.mjs');
 const source=`import {writeFileSync,readFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
let input='';for await(const chunk of process.stdin){input+=chunk;if(Buffer.byteLength(input)>1048576)process.exit(65);}
const value=JSON.parse(input);if(typeof value.session_id!=='string'||!Array.isArray(value.tasks)||typeof value.columns!=='number')process.exit(66);
const stdout=value.tasks.map(task=>JSON.stringify({id:task.id,content:'Release review · '+task.id+' · '+task.status})).join('\\n')+'\\n';
const stat=readFileSync('/proc/self/stat','utf8'),start=stat.slice(stat.lastIndexOf(')')+2).split(' ')[19];
const ancestry=[];let parent=process.ppid;for(let depth=0;parent>1&&depth<16;depth++){try{const raw=readFileSync('/proc/'+parent+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');ancestry.push({pid:parent,start:fields[19]});const next=Number(fields[1]);if(!Number.isSafeInteger(next)||next===parent)break;parent=next;}catch{break;}}
writeFileSync(${JSON.stringify(receipts)}+'/'+randomUUID()+'.json',JSON.stringify({at:Date.now(),pid:process.pid,parentPid:process.ppid,start,ancestry,input:value,stdout}),{mode:0o600,flag:'wx'});
process.stdout.write(stdout);
`;
 await writeFile(helper,source,{mode:0o600,flag:'wx'});
 const quote=value=>"'"+value.replaceAll("'","'\\''")+"'";
 const command=quote(process.execPath)+' '+quote(helper);
 await writeFile(join(workspace,'caption-settings-before.json'),original,{mode:0o600,flag:'wx'});
 await writeFile(settingsPath,JSON.stringify({...settings,subagentStatusLine:{type:'command',command}}));
 let restored=false;
 return {command,helper,helperSha256:createHash('sha256').update(source).digest('hex'),originalSettingsSha256:createHash('sha256').update(original).digest('hex'),
  async invocations(){const names=await readdir(receipts);assert.ok(names.length<=128,'Unexpected helper refresh loop');return Promise.all(names.map(async name=>{assert.match(name,/^[a-f0-9-]+\.json$/);const path=join(receipts,name),info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=2*1024*1024);return JSON.parse(await readFile(path,'utf8'));}));},
  async restore(){if(restored)return;await writeFile(join(workspace,'caption-settings-after.json'),await readFile(settingsPath),{mode:0o600,flag:'wx'});await writeFile(settingsPath,original);assert.deepEqual(await readFile(settingsPath),original);restored=true;}
 };
}
