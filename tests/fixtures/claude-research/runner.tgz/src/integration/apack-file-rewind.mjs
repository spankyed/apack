import assert from 'node:assert/strict';
import{readFile,writeFile}from'node:fs/promises';
import{join}from'node:path';
import{pathToFileURL}from'node:url';
import{probeFileRewind}from'../protocol/file-rewind-probe.mjs';
import{startSyntheticModel}from'../protocol/synthetic-model.mjs';
import{hash}from'../artifacts/runs.mjs';
const[checkout,executable,workspace]=process.argv.slice(2);
const native=await probeFileRewind(executable,workspace,workspace);
const{getSessionFileRewindPreview,rewindSessionFiles}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/session-controls.ts')));
const model=await startSyntheticModel(native.cwd);
try{
 const options={sessionId:native.sessionId,userMessageId:native.userMessageId,cwd:native.cwd,cliPath:executable,
  env:{PATH:process.env.PATH,HOME:native.cwd,CLAUDE_CONFIG_DIR:join(native.cwd,'.claude'),ANTHROPIC_BASE_URL:model.url,
   ANTHROPIC_API_KEY:'research-fixture-key',CLAUDE_CODE_ENABLE_SDK_FILE_CHECKPOINTING:'1',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}};
 const file=join(native.cwd,'fixture.txt');await writeFile(file,'after\n');
 const invalid=await getSessionFileRewindPreview({...options,userMessageId:'55555555-5555-4555-8555-555555555555'});
 const preview=await getSessionFileRewindPreview(options);
 const previewUnchanged=await readFile(file,'utf8')==='after\n';
 const rewind=await rewindSessionFiles(options);
 const restored=await readFile(file,'utf8')==='before\n';
 assert.equal(invalid.canRewind,false);assert.equal(preview.canRewind,true);assert.equal(previewUnchanged,true);
 assert.equal(rewind.canRewind,true);assert.equal(restored,true);assert.equal(model.calls.length,0);
 console.log(JSON.stringify({evidence:'apack-native-file-rewind',targetSha256:hash(await readFile(executable)),
  invalidRejected:!invalid.canRewind,previewUnchanged,restored,serviceApiRequests:model.calls.length,realModelRequests:0,native,invalid,preview,rewind}));
}finally{await model.close()}
