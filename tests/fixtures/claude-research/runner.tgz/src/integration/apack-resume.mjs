import assert from 'node:assert/strict';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { createHash } from 'node:crypto';
import { readFile, realpath, readdir } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// Launch this script with the isolated worktree's tsx loader and a minimal environment.
const [checkoutArg, executableArg, workspaceArg] = process.argv.slice(2);
if (!checkoutArg || !executableArg || !workspaceArg) {
  throw new Error('Expected isolated-apack-worktree, pinned-Claude-executable, disposable-workspace');
}
const checkout = await realpath(checkoutArg);
const primary = await realpath('/Users/spankyed/Develop/Projects/apack/monorepo');
assert.notEqual(checkout, primary, 'Refusing to load product code from the shared primary checkout');
const executable = resolve(executableArg);
const workspace = resolve(workspaceArg);
assert.equal(process.env.HOME, workspace, 'Use an isolated HOME for the probe');
assert.equal(process.env.CLAUDE_CODE_SIMPLE, '1', 'Bare-mode environment is required for this probe');
for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN']) {
  assert.equal(process.env[key], undefined, `Do not supply credentials: ${key}`);
}
const { query } = await import(pathToFileURL(join(checkout,
  'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href);
const { getSessionContextUsage } = await import(pathToFileURL(join(checkout,
  'packages/default-setup/src/features/code/be/services/claude-code/context.ts')).href);
const model = await startSyntheticModel(workspace);
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const options = { cliPath: executable, cwd: workspace, env: {
  PATH: process.env.PATH, HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'),
  CLAUDE_CODE_SIMPLE: '1', ANTHROPIC_BASE_URL: model.url,
  DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1',
}, tools: ['Bash'], strictMcpConfig: true,
settings: JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' }), settingSources: [],
permissionMode: 'default', model: 'claude-sonnet-4-6', maxTurns: 3,
signal: AbortSignal.timeout(25000),
onPermissionRequest: async request => ({ behavior: 'allow', updatedInput: request.input }) };
let active;
try {
  active = await query(options);
  const initialized = await active.initialized;
  active.send('Create fixture.txt with literal content synthetic protocol fixture.');
  for await (const event of active.events) { if (event.type === 'result') break; }
  await active.result;
  const sessionId = await active.sessionId;
  const before = await active.getContextUsage();
  await active.close(); active = undefined;
  const files = await readdir(join(workspace, '.claude', 'projects'), { recursive: true });
  const matches = files.filter(path => path.endsWith(`${sessionId}.jsonl`));
  assert.equal(matches.length, 1, 'Expected one persisted synthetic transcript');
  const transcript = join(workspace, '.claude', 'projects', matches[0]);
  const transcriptBefore = digest(await readFile(transcript));
  const requestsBefore = model.calls.length;
  const after = await getSessionContextUsage({ sessionId, cwd: workspace, cliPath: executable,
    env: options.env, signal: options.signal });
  assert.equal(model.calls.length, requestsBefore);
  assert.equal(after.model, before.model);
  assert.equal(after.maxTokens, before.maxTokens);
  assert.ok(before.messageBreakdown.userMessageTokens > 0);
  assert.deepEqual(after.messageBreakdown, before.messageBreakdown);
  const transcriptAfter = digest(await readFile(transcript));
  assert.equal(transcriptAfter, transcriptBefore);
  console.log(JSON.stringify({ evidence: 'apack-resumed-context', checkout, nativeSessionService: true,
    targetSha256: digest(await readFile(executable)), version: initialized.claude_code_version,
    sessionId, model: after.model, maxTokens: after.maxTokens,
    userMessageTokens: after.messageBreakdown.userMessageTokens,
    messageBreakdownRestored: true, transcriptUnchanged: true,
    syntheticApiRequests: model.calls.length, resumedApiRequests: model.calls.length - requestsBefore,
    realModelRequests: 0, userPromptsSent: 1,
    qualification: 'Actual persisted CLI session from a synthetic model turn; resumed context sends no prompt or model request.' }));
} finally {
  try {
    if (active) await active.close();
  } finally { await model.close(); }
}
