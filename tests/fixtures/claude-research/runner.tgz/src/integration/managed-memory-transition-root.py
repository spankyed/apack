from hashlib import sha256
import json
import os
from pathlib import Path
import re
import sys
import time

workspace = Path(sys.argv[1])
folder = Path('/etc/claude-code')
policy = folder / 'managed-settings.json'
finish = Path('/control/managed-memory-finish')

assert os.geteuid() == 0 and Path('/.dockerenv').exists()
assert re.fullmatch(r'/work/\.claude-research/apack-terminal-owner-app-command[0-9]+', str(workspace))
assert workspace.resolve() == workspace and workspace.stat().st_uid == 1000
assert any(line.split()[4] == str(folder) and ' - tmpfs ' in line
           for line in Path('/proc/self/mountinfo').read_text().splitlines())
assert list(folder.iterdir()) == []

def contents(enterprise):
    label = 'Enterprise' if enterprise else 'Local'
    settings = {'statusLine': {'type': 'command', 'command': f"/usr/bin/printf '{label} memory policy fixture'"}}
    if enterprise:
        settings['autoMemoryEnabled'] = False
    return (json.dumps(settings) + '\n').encode()

def receipt(stage, payload):
    st = policy.stat()
    info = {'stage': stage, 'owner': st.st_uid, 'mode': st.st_mode & 0o777,
            'inode': st.st_ino, 'sha256': sha256(payload).hexdigest()}
    tmp = workspace / f'.memory-{stage}.root.json'
    with tmp.open('x') as file:
        os.fchmod(file.fileno(), 0o644)
        file.write(json.dumps(info))
    tmp.rename(workspace / f'memory-{stage}.root.json')

def requested(stage):
    req = workspace / f'memory-{stage}.request'
    deadline = time.monotonic() + 150
    while not finish.exists():
        if req.exists():
            assert req.is_file() and not req.is_symlink()
            return req.read_text() == stage
        if time.monotonic() >= deadline:
            raise TimeoutError(stage)
        time.sleep(.05)
    return False

try:
    with policy.open('xb') as file:
        os.fchmod(file.fileno(), 0o644)
        file.write(contents(False))
    receipt('ready', contents(False))
    if requested('lock'):
        policy.write_bytes(contents(True))
        receipt('lock', contents(True))
        if requested('release'):
            policy.write_bytes(contents(False))
            receipt('release', contents(False))
    requested('completed')
finally:
    assert policy.read_bytes() in (contents(True), contents(False))
    policy.unlink()
    (workspace / 'memory-cleaned.root.json').write_text(json.dumps({'initialAbsenceRestored': not policy.exists()}))
