import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';

/** Native-only owned-worker handshake. No raw module handles are used as desktop actions. */
export async function probeOwnedWorkerDesktop({checkout,launcher,job,output,project}){
 const receipt={status:'running',pid:job.pid,sessionId:job.sessionId,steps:[],scope:'Fresh owned original worker only; not production or actual-app acceptance.'};
 const save=()=>writeFile(join(output,'owned-worker-desktop.json'),JSON.stringify(receipt,null,2));
 let bridge,ui,attached=false,releaseDesktop;
 let draft='Owned child desktop draft あ🙂';const initialDraft=draft,hostCalls=[];
 const client_id='owned-worker-desktop';
 try{
  const scope=await launcher.desktopScope(job);receipt.processStart=scope.processStart;await save();
  const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
  const {createClaudeTerminalUiTransport}=await import(pathToFileURL(join(base,'terminal-ui.ts')).href);
  const {createClaudeUiControls}=await import(pathToFileURL(join(base,'ui-controls.ts')).href);
  const {createClaudeUiDrawing}=await import(pathToFileURL(join(base,'ui-tree.ts')).href);
  bridge=createClaudeTerminalUiTransport({socketPath:scope.socketPath,token:scope.token,current:()=>({pid:job.pid,sessionId:job.sessionId})});
  releaseDesktop=await launcher.bindDesktopTransport(job,bridge);
  bridge.transport.promptHosts.register(client_id,{
   async read(){hostCalls.push('read');return {text:draft,cursor:draft.length};},
   async fill(input){assert.equal(input.mode,'replace');hostCalls.push('fill');draft=input.text;return true;},
  });
  const capabilities=await bridge.transport.request({subtype:'apack_ui_capabilities'});receipt.capabilities=capabilities;receipt.steps.push('capabilities');await save();
  assert.ok(capabilities.capabilities?.includes('ui_surface_v1'),'Original child desktop admission unavailable');
  ui=createClaudeUiControls(Promise.resolve(capabilities),{request:value=>bridge.transport.request(value)},bridge.transport.promptHosts);
  receipt.attachment=await ui.attach({client_id,surface:'desktop',viewport:{columns:100,rows:24}});attached=true;receipt.steps.push('attached');await save();
  receipt.hookRegistration=await bridge.transport.request({subtype:'apack_research_hook_snapshot'});await save();
  const placements=await ui.composerPlacements(client_id);receipt.placements=placements;await save();
  // AbovePrompt is a native client-owned site; PromptHint is a separate composer producer.
  const scopeInput={client_id,component:'AbovePrompt',instance_id:client_id+':above-prompt',instance_revision:1};
  const frame=await ui.render({...scopeInput,surface:'desktop',props:{},viewport:{columns:100,rows:24}});
  receipt.frame=frame;const drawing=createClaudeUiDrawing(frame.tree);receipt.drawing={tree:drawing.tree,actionCount:drawing.actions.size};receipt.steps.push('rendered');await save();
  const action=[...drawing.actions.values()].find(value=>value.key==='child-drawing-proof');
  assert.ok(action?.plugin,'Original host-stamped child callback required');receipt.action=action;await save();
  receipt.press=await ui.press({...scopeInput,surface:'desktop',...action});assert.equal(receipt.press.handled,true);receipt.steps.push('pressed');await save();
  const callback=JSON.parse(await readFile(join(project,'native-child-drawing-press-'+job.sessionId+'.json'),'utf8'));
  assert.equal(callback.sessionId,job.sessionId);assert.equal(callback.callback,true);assert.deepEqual(callback.prompt.before,{text:initialDraft,cursor:initialDraft.length});assert.equal(callback.prompt.filled.isFilled,true);assert.equal(callback.prompt.after.text,'Owned child desktop replacement あ🙂');assert.equal(draft,callback.prompt.after.text);receipt.promptHost={calls:hostCalls,initialDraft,finalDraft:draft};receipt.callback=callback;assert.equal(hostCalls.filter(value=>value==='fill').length,1);assert.equal(hostCalls[0],'read');assert.equal(hostCalls.at(-1),'read');assert.ok(hostCalls.length>=3&&hostCalls.length<=8&&hostCalls.every(value=>value==='read'||value==='fill'));
  const released=await ui.releaseInstance(scopeInput);assert.equal(released.released,true);receipt.steps.push('released');
  const stale=await ui.press({...scopeInput,surface:'desktop',...action});assert.equal(stale.handled,false,'Released child action must not dispatch');receipt.staleAction={handled:false};
  const after=await launcher.snapshot(job);assert.equal(after.worker.processStart,scope.processStart);receipt.sameOriginalWorker=true;
  receipt.status='complete';await save();return receipt;
 }catch(error){receipt.status='failed';receipt.error=String(error.message).slice(0,2048);await save();throw error;}
 finally{releaseDesktop?.();if(attached)await ui.detach({client_id,surface:'desktop'}).catch(()=>{});bridge?.close();}
}
