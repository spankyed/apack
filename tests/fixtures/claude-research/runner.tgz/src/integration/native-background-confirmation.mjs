import {startSyntheticAgentModel,WORKFLOW_APPROVAL_FIXTURE_SCRIPT} from '../protocol/synthetic-agent-model.mjs';
import assert from 'node:assert/strict';
import {readFile,mkdir,writeFile,readdir}from'node:fs/promises';
import {join,basename,isAbsolute}from'node:path';
import {setTimeout as delay}from'node:timers/promises';
import {stripVTControlCharacters}from'node:util';
import {createHash}from'node:crypto';
import {execFileSync}from'node:child_process';
import {prepareNativeManagedSecurity}from'../protocol/native-managed-security-fixture.mjs';
import {recognizeOnboardingPrompt}from'../protocol/pty-onboarding.mjs';
import {startSyntheticModel}from'../protocol/synthetic-model.mjs';
import {adaptNativeResearchPreload} from './native-platform-preload.mjs';
import {record}from'../protocol/record.mjs';
const [executable,workspace,output,checkout]=process.argv.slice(2);
assert.equal(process.platform,'linux');assert.ok(isAbsolute(workspace)&&basename(workspace).startsWith('apack-terminal-owner-app-'));assert.ok(isAbsolute(output));
assert.equal(createHash('sha256').update(await readFile(executable)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
await mkdir(workspace,{recursive:true});assert.deepEqual(await readdir(workspace),[],'Fresh private profile required');await mkdir(output,{recursive:true});
await mkdir(join(workspace,'.claude'),{recursive:true});
// Match the already-onboarded profile used by app journeys; approvals remain native.
await writeFile(join(workspace,'.claude/.claude.json'),JSON.stringify({hasCompletedOnboarding:true}));
await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify({theme:'dark'}));
const project=join(workspace,'project');await mkdir(project);
execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null'},timeout:5000,maxBuffer:1024*1024});
const sources={};for(const name of [new URL(import.meta.url),new URL('../protocol/native-managed-security-fixture.mjs',import.meta.url),new URL('../protocol/record.mjs',import.meta.url),new URL('../protocol/synthetic-model.mjs',import.meta.url)])sources[name.pathname]=createHash('sha256').update(await readFile(name)).digest('hex');
await writeFile(join(output,'source-inputs.json'),JSON.stringify(sources,null,2)+'\n');
const auth=await prepareNativeManagedSecurity(workspace,executable);await auth.close();
assert.ok(isAbsolute(checkout));
const preload=join(workspace,'background-observer.mjs');
const observation=String.raw`import {createHash} from 'node:crypto';import {readFileSync} from 'node:fs';
{
 const {writeFileSync,renameSync}=await import('node:fs');let last;const rows=[],deadline=Date.now()+100000;
 const timer=setInterval(async()=>{if(Date.now()>deadline){clearInterval(timer);return}try{
  const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),binding=runtime.ey();if(binding?.surface!=='terminal'||typeof binding.toolContext!=='function')return;
  const context=binding.toolContext(new AbortController()),tasks=Object.entries(context.taskRegistry.all()).slice(0,64).map(([id,t])=>({id,type:t.type,status:t.status,isBackgrounded:t.isBackgrounded,v2Run:t.v2Run!==undefined,stoppedByUser:t.stoppedByUser,workflowAgents:t.workflowProgress?.filter(row=>row.type==='workflow_agent').map(row=>({state:row.state,queuedAt:row.queuedAt,startedAt:row.startedAt}))}));
  const value={tasks,dialogs:context.dialogStore.getState().open.map(d=>({id:d.id,kind:d.kind}))},key=JSON.stringify(value),current={at:Date.now(),pid:process.pid,...value},file=OBSERVATION_FILE+'.'+process.pid;
  writeFileSync(file+'.tmp',JSON.stringify(current));renameSync(file+'.tmp',file);
  if(key===last)return;last=key;rows.push(current);if(rows.length>128)rows.shift();
  writeFileSync(file+'.history',JSON.stringify(rows));
 }catch(error){if(rows.length<128){rows.push({at:Date.now(),error:String(error)});writeFileSync(OBSERVATION_FILE+'.'+process.pid+'.history',JSON.stringify(rows))}}},100);timer.unref();
}`.replaceAll('OBSERVATION_FILE',JSON.stringify(join(workspace,'background-task-observations.json')));
await writeFile(preload,await adaptNativeResearchPreload(checkout,observation));
await mkdir(join(workspace,'.claude/agents'),{recursive:true});
await writeFile(join(workspace,'.claude/agents/status-fixture.md'),'---\nname: status-fixture\ndescription: Owned review task\nmodel: sonnet\n---\nNativeStatusChildSystem: return the fixed review response.\n');
const model=await startSyntheticAgentModel({workflowProbe:true,workflowScript:WORKFLOW_APPROVAL_FIXTURE_SCRIPT,holdChildUntilRelease:true,parentLaunchOnce:true,captureMessages:true,requestLimit:12});
const prompt='Review the release notes while I check the migration guidance.',env={...auth.env,ANTHROPIC_BASE_URL:model.url,BUN_OPTIONS:'--preload='+preload};
const runs=[],actions=[];let short,stopped=false;
const processState=async pid=>{try{const value=await readFile('/proc/'+pid+'/stat','utf8'),fields=value.slice(value.lastIndexOf(')')+2).split(' ');return {state:fields[0],startTime:fields[19]};}catch(error){if(error.code==='ENOENT')return null;throw error}};
const save=async()=>writeFile(join(output,'background-session-observation.json'),JSON.stringify({targetVersion:'2.1.302',short,stopped,runs,actions,bootstrapKeyApproved:auth.state.bootstrapKeyApproved,modelCalls:model.calls},null,2)+'\n');
async function cli(label,args,timeoutMs=20000,tty=false){
 let terminal='';const keys=[],timers=[];
 try{
  const run=await record({executable:tty?'/usr/bin/python3':executable,args:tty?[new URL('../protocol/pty_bridge.py',import.meta.url).pathname,executable,...args]:args,cwd:project,env,output:join(output,label),timeoutMs,maxBytes:2*1024*1024,...(tty?{onStdout(bytes,channel){terminal+=bytes.toString('utf8');const stage=recognizeOnboardingPrompt(terminal,project);if(stage&&!keys.includes(stage)){keys.push(stage);timers.push(setTimeout(()=>channel.send(stage==='workspace-trust'?'\x1b[B':'\r'),stage==='workspace-trust-selected'?1500:200));}}}:{})});runs.push({label,...run,tty,trustKeys:keys});await save();
  const stdout=await readFile(join(run.directory,'stdout.bin'),'utf8'),stderr=await readFile(join(run.directory,'stderr.bin'),'utf8');return{...run,stdout,stderr};
 }finally{for(const timer of timers)clearTimeout(timer)}
}
try{
 // Complete trust through the original terminal; background startup also uses its native PTY route.
 let terminal='',workspaceReady=false,initialSent=false,handoffSent=false,trustRun,liveTask,cancelled=false,confirmationCount=0,channel,checking=false;let phase='start';const timers=[];let escapedAt,parentPid;
 try{
  const run=await record({executable:'/usr/bin/python3',args:[new URL('../protocol/pty_bridge.py',import.meta.url).pathname,executable,'--model','claude-sonnet-4-6','--setting-sources','user,project,local','--tools','Workflow','--allowed-tools','Workflow','--permission-mode','acceptEdits','--strict-mcp-config'],cwd:project,env,output:join(output,'workspace-trust'),timeoutMs:85000,maxBytes:2*1024*1024,onStdout(bytes,io){
   channel=io;terminal+=bytes.toString('utf8');const stage=recognizeOnboardingPrompt(terminal,project);
   if(stage&&!actions.includes(stage)){actions.push(stage);timers.push(setTimeout(()=>channel.send(stage==='workspace-trust'?'\x1b[B':'\r'),stage==='workspace-trust-selected'?1500:200));}
   const text=stripVTControlCharacters(terminal).replace(/\s/g,'');
   if(actions.includes('workspace-trust-selected')&&text.includes('APIUsageBilling')&&text.includes('shift+tabtocycle')&&!initialSent){workspaceReady=true;initialSent=true;timers.push(setTimeout(()=>channel.send('Start the owned review task before backgrounding this conversation.'),400),setTimeout(()=>channel.send('\r'),1100));}
   if(text.includes('Backgroundthissession?')&&phase==='confirm-cancel'){
    confirmationCount++;phase='cancel-scheduled';terminal='';timers.push(setTimeout(()=>{channel.send('\x1b');escapedAt=Date.now();cancelled=true;actions.push('native-confirmation-escape');terminal='';phase='cancel-verification';},300));
   }else if(text.includes('Backgroundthissession?')&&phase==='confirm-fork'){
    confirmationCount++;phase='fork';actions.push('native-confirmation-confirm');timers.push(setTimeout(()=>channel.send('\r'),300));
   }
   if(!checking&&initialSent&&['start','cancel-verification'].includes(phase)){
    checking=true;void readdir(workspace).then(async names=>{
     const files=names.filter(name=>/^background-task-observations\.json\.\d+$/.test(name));
     const snapshots=await Promise.all(files.map(async name=>JSON.parse(await readFile(join(workspace,name),'utf8'))));
     const latest=snapshots.filter(row=>!parentPid||row.pid===parentPid).sort((a,b)=>b.at-a.at)[0],task=latest?.tasks?.find(t=>t.type==='local_workflow'&&t.status==='running');
     if(!task||!task.workflowAgents?.some(agent=>agent.state==='progress'||agent.state==='start'&&!(agent.queuedAt!==undefined&&agent.startedAt===undefined))||latest.dialogs.some(d=>d.kind==='local_jsx'))return;
     if(phase==='cancel-verification'){if(latest.at<escapedAt+200)return;assert.equal(latest.pid,parentPid);assert.deepEqual(task.workflowAgents,liveTask.workflowAgents,'Escape must preserve the original reviewer lifecycle');assert.equal(task.id,liveTask.id,'Stay/Escape must retain the running original task');actions.push('native-task-retained-after-escape');phase='confirm-fork';terminal='';}
     else if(phase==='start'){liveTask=task;parentPid=latest.pid;phase='confirm-cancel';handoffSent=true;actions.push('original-background-command');terminal='';}
     else return;
     await writeFile(join(output,'confirmation-progress.json'),JSON.stringify({liveTask,cancelled,confirmationCount,phase,escapedAt,parentPid,latest},null,2));
     timers.push(setTimeout(()=>channel.send('/background'),500),setTimeout(()=>channel.send('\r'),1100));
    }).catch(error=>{if(error.code!=='ENOENT'){actions.push('observation-error:'+String(error));}}).finally(()=>{checking=false});
   }

  }});trustRun=run;runs.push({label:'workspace-trust',...run});
 }finally{for(const timer of timers)clearTimeout(timer)}
 await writeFile(join(output,'workspace-trust-acknowledgement.json'),JSON.stringify({workspaceReady,initialSent,handoffSent,cancelled,confirmationCount,liveTask,phase,actions,exitCode:trustRun?.code,status:trustRun?.status,qualification:'Original owned Workflow execution, /background task warning, Escape retaining the same task, then original confirmation/fork; no injected tasks/dialogs or gate changes.'},null,2)+'\n');assert.equal(workspaceReady,true,'Original workspace trust must reach the REPL');assert.equal(trustRun.status,'complete','Native trust preparation must exit cleanly');
 const started={...trustRun,stdout:await readFile(join(trustRun.directory,'stdout.bin'),'utf8'),stderr:await readFile(join(trustRun.directory,'stderr.bin'),'utf8')};assert.equal(handoffSent,true,'Original foreground conversation must reach background command');
 short=stripVTControlCharacters(started.stdout).match(/backgrounded\s*·\s*([a-f0-9]{8})/u)?.[1];await save();assert.equal(started.status,'complete',started.stderr||stripVTControlCharacters(started.stdout));assert.ok(short,'Original CLI must report its job identity');
 assert.equal(cancelled,true);assert.equal(confirmationCount,2);assert.ok(actions.includes('native-task-retained-after-escape'));
 let before;
 for(let attempt=0;attempt<12;attempt++){
  const listed=await cli('list-'+attempt,['agents','--json','--all','--cwd',project]);assert.equal(listed.status,'complete',listed.stderr);before=JSON.parse(listed.stdout).find(row=>row.id===short);if(before?.pid)break;await delay(300);
 }
 await writeFile(join(output,'listed-before-stop.json'),JSON.stringify(before,null,2)+'\n');assert.equal(before.kind,'background');assert.ok(before.sessionId);assert.ok(Number.isSafeInteger(before.pid));
 const pidBefore=await processState(before.pid);assert.ok(pidBefore&&pidBefore.state!=='Z','Original background process must be alive before Stop');
 const stop=await cli('stop',['stop',short],25000);assert.equal(stop.status,'complete',stop.stderr);stopped=true;
 const listed=await cli('list-after-stop',['agents','--json','--all','--cwd',project]);assert.equal(listed.status,'complete',listed.stderr);const after=JSON.parse(listed.stdout).find(row=>row.id===short);assert.ok(after);
 await writeFile(join(output,'listed-after-stop.json'),JSON.stringify(after,null,2)+'\n');
 assert.equal(after.state,'stopped');let pidAfter;
 for(let attempt=0;attempt<40;attempt++){pidAfter=await processState(before.pid);if(!pidAfter||pidAfter.state==='Z'||pidAfter.startTime!==pidBefore.startTime)break;await delay(100);}
 assert.ok(!pidAfter||pidAfter.state==='Z'||pidAfter.startTime!==pidBefore.startTime,'Stopped original job process remains live');
 await writeFile(join(output,'owned-job-stop.json'),JSON.stringify({pid:before.pid,pidBefore,pidAfter,nativeState:after.state,originalStopConfirmed:true},null,2)+'\n');await save();
 console.log(JSON.stringify({nativeBackgroundConfirmation:true,cancelled,confirmationCount,liveTask,short,before,after,stopped,syntheticRequests:model.calls.length,realModelRequests:0,scope:'Original task-backed command warning/Stay-Escape/confirm/fork only; desktop host and left-arrow gesture remain unverified.'}));
}finally{
 if(short&&!stopped)await cli('cleanup-stop',['stop',short],15000).catch(()=>{});
 await writeFile(join(workspace,'native-held-model-release'),'release');await save();await model.close();
}
