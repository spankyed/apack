import {brokerApprovalPrompts,driveBrokerApprovalLoss} from './native-broker-approval-journey.mjs';
import {permissionsFeedbackThemes} from './permissions-feedback-theme.mjs';
import {driveDesktopPermissionsJourney} from './native-desktop-permissions-journey.mjs';
import {driveAddDirectoryCommandJourney} from './native-add-directory-command-journey.mjs';
import {prepareOwnedStartingTerminal,stopStartingTerminal,finishStartingTerminalJourney} from './native-terminal-startup-stop-journey.mjs';
import {driveTerminalBrokerLoss} from './native-terminal-broker-loss-journey.mjs';
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {startSyntheticModel, flaggedReviewRules, retainedReviewRead} from '../protocol/synthetic-model.mjs';
import {EFFORT_EVAL_ROUTE} from '../protocol/native-effort-rollout.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {driveDirectAutoVerdict} from './native-recent-denials-journey.mjs';
import {startManagedMcpTaskHttpServer} from '../protocol/owned-managed-mcp-task-http-server.mjs';
import {driveMcpTaskJourney,mcpTaskPrompt} from './native-mcp-task-journey.mjs';
import {driveManagedMemoryTransition} from './apack-managed-memory-transition.mjs';
import {driveCompactWorkspace} from './apack-compact-workspace-drive.mjs';
import {channelPrompt,driveOwnedChannelRefusal,selectOwnedChannel} from './apack-mcp-channel-refusal-drive.mjs';
import {driveOwnedChannelRevocation} from './apack-mcp-channel-revocation-drive.mjs';
import {driveOwnedChannelReplacement} from './apack-mcp-channel-replacement-drive.mjs';
import {driveOwnedChannelRelay} from './apack-mcp-channel-relay-drive.mjs';
import {driveOwnedChannelIngress} from './apack-mcp-channel-ingress-drive.mjs';
import {channelMarketplace,channelPlugin,channelSelector,installOwnedChannel} from './owned-channel-installation.mjs';
import {driveManagedScanJourney} from './native-managed-scan-journey.mjs';
import {driveMountedManagedRuleRefresh,driveLiveManagedRuleSources,driveManagedRuleCatalog,driveManagedRuleSources,managedRuleReads,validateManagedRulePolicy} from './native-managed-rule-journey.mjs';
import {driveCommandRefusalJourney} from './native-command-refusal-journey.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function birth(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),f=raw.slice(raw.lastIndexOf(')')+2).split(' ');return f[0]==='Z'?null:f[19]}catch(error){if(error.code==='ENOENT')return null;throw error}}

/** Original local command through the normal app dispatcher and shared broker drawing. */
export async function driveFreshNativeCommand({checkout,workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-command[0-9]+$/);
 const managedRuleSources=env.CLAUDE_RESEARCH_MANAGED_RULE_SOURCES==='1';
 const managedRuleCatalog=env.CLAUDE_RESEARCH_MANAGED_RULE_CATALOG==='1';
 const liveManagedRuleSources=env.CLAUDE_RESEARCH_MANAGED_RULE_LIVE==='1';
 const mountedManagedRuleRefresh=env.CLAUDE_RESEARCH_MANAGED_RULE_REFRESH==='1';
 const heldManagedRuleEdit=env.CLAUDE_RESEARCH_HELD_MANAGED_RULE_EDIT==='1';
 const heldManagedRuleAddition=env.CLAUDE_RESEARCH_HELD_MANAGED_RULE_ADDITION==='1';
 assert.ok(!heldManagedRuleAddition||mountedManagedRuleRefresh&&!heldManagedRuleEdit);
 assert.ok(!heldManagedRuleEdit||mountedManagedRuleRefresh);
 const managedRuleVariants=[managedRuleCatalog,liveManagedRuleSources,mountedManagedRuleRefresh].filter(Boolean);
 assert.ok(managedRuleVariants.length<=1&&(managedRuleSources||managedRuleVariants.length===0));
 const channelRevocation=env.CLAUDE_RESEARCH_MCP_CHANNEL_REVOCATION==='1';
 const flaggedDecision=env.CLAUDE_RESEARCH_MANAGED_SCAN_FLAGGED;
 const project=join(workspace,'project');await mkdir(project);await writeFile(join(project,'release-notes.md'),'# Release notes\n\nReview local permissions before continuing.\n');execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,channelRevocation?'oauth-team':'oauth',{featureCache:'native-defaults'}),configPath=join(workspace,'.claude/.claude.json'),settingsPath=join(workspace,'.claude/settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));const feedbackTheme=env.CLAUDE_RESEARCH_PERMISSIONS_FEEDBACK_THEME==='1'?join(workspace,'.claude/themes/permissions-review.json'):undefined;if(feedbackTheme){assert.equal(env.CLAUDE_RESEARCH_DESKTOP_PERMISSIONS,'1');assert.equal(env.CLAUDE_RESEARCH_PERMISSIONS_ENVIRONMENT,'feedback');await mkdir(join(workspace,'.claude/themes'),{recursive:true});await writeFile(feedbackTheme,JSON.stringify(permissionsFeedbackThemes.initial),{flag:'wx',mode:0o600})}await writeFile(settingsPath,JSON.stringify({theme:feedbackTheme?'custom:permissions-review':'dark',model:'opus',...(managedRuleSources?{permissions:{ask:['Read']}}:{}),...(flaggedDecision&&{permissions:{allow:[...flaggedReviewRules,retainedReviewRead]}})}));const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath);
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,defaultProfile:'shared',config,settings:JSON.parse(settingsBefore)},null,2));
 const managedScan=env.CLAUDE_RESEARCH_MANAGED_SCAN==='1';
 const managedScanReview=env.CLAUDE_RESEARCH_MANAGED_SCAN_REVIEW;
 const managedScanServed=env.CLAUDE_RESEARCH_MANAGED_SCAN_ROLLOUT==='1';
 const managedScanReset=env.CLAUDE_RESEARCH_MANAGED_SCAN_RESET==='1';
 const holdTaskPointerAcrossReset=env.CLAUDE_RESEARCH_MANAGED_SCAN_POINTER_RESET==='1';
 assert.ok(!holdTaskPointerAcrossReset||managedScanReset);
 assert.ok(!managedScanReset||managedScanServed);
 assert.ok(managedScanReview===undefined||managedScanServed&&!managedScanReset&&['accept','decline'].includes(managedScanReview));
 assert.ok(flaggedDecision===undefined||managedScanReview==='accept'&&['pick','all','leave','cancel','stale-pick'].includes(flaggedDecision));
 if(managedScanServed){
  assert.ok(managedScan);
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(boundary.requireServedManagedScan&&boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
  assert.equal(managedScanReset,boundary.requireManagedScanReset===true);
  assert.equal(holdTaskPointerAcrossReset,boundary.requireManagedScanPointerReset===true);
  assert.equal(managedScanReview,boundary.managedScanReview);
  assert.equal(flaggedDecision,boundary.flaggedDecision);
  assert.equal(config.cachedGrowthBookFeatures,undefined);
  assert.equal(config.growthBookOverrides,undefined);
 }
 const directAuto=env.CLAUDE_RESEARCH_AUTO_DIRECT_VERDICT==='1';
 if(directAuto){
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(boundary.requireDirectAutoVerdict&&boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
 }
 const refusalCase=env.CLAUDE_RESEARCH_COMMAND_REFUSAL==='1',desktopPermissions=env.CLAUDE_RESEARCH_DESKTOP_PERMISSIONS==='1';
 const addDirectoryCommand=['1','semantic','restart','write-refusal','standalone'].includes(env.CLAUDE_RESEARCH_ADD_DIRECTORY_COMMAND);
 const terminalBrokerLoss=env.CLAUDE_RESEARCH_TERMINAL_BROKER_LOSS==='1';
 const brokerApprovalLoss=env.CLAUDE_RESEARCH_BROKER_APPROVAL_LOSS==='1';
 let brokerApprovalReads;
 if(brokerApprovalLoss){
  const settingsDirectory=join(project,'.claude');
  await mkdir(settingsDirectory);
  await writeFile(join(settingsDirectory,'settings.json'),JSON.stringify({permissions:{ask:['Read']}}));
  brokerApprovalReads=brokerApprovalPrompts.map((prompt,index)=>({prompt,file:join(project,index===0?'first-release-checklist.md':'revised-release-checklist.md')}));
  for(const [index,{file}] of brokerApprovalReads.entries())await writeFile(file,index===0?'Owned first release checklist.':'Owned revised release checklist.');
 }
 if(managedRuleSources){
  await validateManagedRulePolicy(project);
  const reads=managedRuleReads(project,liveManagedRuleSources);
  if(!managedRuleCatalog&&!mountedManagedRuleRefresh) brokerApprovalReads=reads;
  await writeFile(reads[0].file,'Private checklist for the release review.',{flag:'wx'});
  await writeFile(reads[1].file,liveManagedRuleSources?'Revised private checklist for the release review.':'Managed checklist for the release review.',{flag:'wx'});
 }

 const startingTerminalStop=env.CLAUDE_RESEARCH_STOP_STARTING_TERMINAL==='1';
 assert.ok([managedScan,refusalCase,desktopPermissions,directAuto,addDirectoryCommand,startingTerminalStop,terminalBrokerLoss,brokerApprovalLoss,managedRuleSources].filter(Boolean).length<=1);
 const channelRefusal=env.CLAUDE_RESEARCH_MCP_CHANNEL_REFUSAL==='1';
 const channelIngress=env.CLAUDE_RESEARCH_MCP_CHANNEL_INGRESS==='1';
 const channelRelay=env.CLAUDE_RESEARCH_MCP_CHANNEL_RELAY==='1';
 const channelReplacement=env.CLAUDE_RESEARCH_MCP_CHANNEL_REPLACEMENT==='1';
 assert.ok(!channelReplacement||(channelRelay&&!channelRevocation));
 assert.ok(!channelRelay||channelIngress);
 assert.ok(!channelRevocation||channelRelay);
 const relayDirectory=channelRelay?join(workspace,'owned-channel-relay'):undefined;
 assert.ok(!(channelRefusal&&channelIngress));
 const channelRelease=join(workspace,'release-owned-channel');
 const channelDebug=join(workspace,'native-channel-debug');
 const channelReceipts=join(workspace,'native-channel-receipts.jsonl');
 const startingTerminal=startingTerminalStop?await prepareOwnedStartingTerminal(workspace):undefined;
 let executable=startingTerminal?.launcher??'/frozen-claude/claude';
 if(heldManagedRuleEdit||heldManagedRuleAddition){
  executable=join(workspace,'managed-rule-debug-launcher');
  await writeFile(executable,'#!/bin/sh\nexec /frozen-claude/claude --debug-file "'+workspace+'/held-rule-debug-$$.log" "$@"\n',{mode:0o700});
 }
 if(channelIngress){
  if(relayDirectory)await mkdir(relayDirectory);
  await installOwnedChannel({workspace,project,account,receipts:channelReceipts,release:channelRelay?undefined:channelRelease,relayDirectory,channelRevocation,channelReplacement});
 }
 if(channelRefusal||channelIngress){
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.equal(channelIngress,boundary.requireMcpChannelIngress===true);
  assert.equal(channelRelay,boundary.requireMcpChannelRelay===true);
  assert.equal(channelRevocation,boundary.requireManagedChannelRelay===true);
  assert.equal(channelReplacement,boundary.requireMcpChannelReplacement===true);
  assert.equal(channelRefusal,boundary.requireMcpChannelRefusal===true);
  assert.ok(boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
  assert.ok(!config.cachedGrowthBookFeatures&&!config.growthBookOverrides&&!config.mcpServers?.research);
  if(channelRefusal)await writeFile(configPath,JSON.stringify({...config,mcpServers:{...config.mcpServers,research:{
   type:'stdio',command:process.execPath,args:[new URL('../protocol/owned-mcp-channel-server.mjs',import.meta.url).pathname],
   env:{APACK_MCP_TASK_RECEIPT:channelReceipts},
  }}}));
  executable=join(workspace,'channel-diagnostic-launcher');
  await writeFile(executable,'#!/bin/sh\nexec /frozen-claude/claude --debug-file '+channelDebug+'.$$.log "$@"\n',{mode:0o700});
 }
 const managedMemoryTransition=env.CLAUDE_RESEARCH_MANAGED_MEMORY_TRANSITION==='1';
 let autoRefreshMemoryPolicy=false,memoryPolicyPopout=false;
 if(managedMemoryTransition){
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(boundary.requireManagedMemoryTransition&&boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
  autoRefreshMemoryPolicy=boundary.autoRefreshMemoryPolicy===true;
  memoryPolicyPopout=boundary.memoryPolicyPopout===true;
  assert.ok(!memoryPolicyPopout||autoRefreshMemoryPolicy);
 }
 const workspaceHeader=env.CLAUDE_RESEARCH_WORKSPACE_HEADER==='1';
 let requireWorkspaceReachability=false,filterWorkspace=false;
 if(workspaceHeader){
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(boundary.requireWorkspaceHeader&&boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
  requireWorkspaceReachability=boundary.requireWorkspaceReachability===true;
  filterWorkspace=boundary.filterWorkspace===true;
 }
 const mcpTask=env.CLAUDE_RESEARCH_MCP_TASK_DESKTOP==='1';
 assert.ok([managedMemoryTransition,workspaceHeader,channelRefusal,channelIngress,mcpTask,managedScan,refusalCase,desktopPermissions,directAuto].filter(Boolean).length<=1);
 const mcpTaskInput=env.CLAUDE_RESEARCH_MCP_TASK_INPUT==='1';
 const mcpTaskUpdateExhaustion=env.CLAUDE_RESEARCH_MCP_TASK_UPDATE_EXHAUSTION==='1';
 const mcpTaskLongFollowup=env.CLAUDE_RESEARCH_MCP_TASK_LONG_FOLLOWUP==='1';
 const mcpTaskSecondInput=env.CLAUDE_RESEARCH_MCP_TASK_SECOND_INPUT==='1';
 const mcpTaskCompletionNotice=env.CLAUDE_RESEARCH_MCP_TASK_COMPLETION_NOTICE==='1';
 const mcpTaskExpired=env.CLAUDE_RESEARCH_MCP_TASK_EXPIRED==='1';
 const taskTransportDrop=env.CLAUDE_RESEARCH_MCP_TASK_TRANSPORT_DROP==='1';
 const taskAutoReattach=env.CLAUDE_RESEARCH_MCP_TASK_AUTO_REATTACH==='1';
 assert.ok(!taskAutoReattach||mcpTask&&!taskTransportDrop);
 const taskReattach=env.CLAUDE_RESEARCH_MCP_TASK_REATTACH==='1';
 assert.ok(!taskReattach||taskTransportDrop);
 const taskPark=env.CLAUDE_RESEARCH_MCP_TASK_PARK==='1';
 const taskRetiredPoll=env.CLAUDE_RESEARCH_MCP_TASK_RETIRED_POLL==='1';
 assert.ok(!taskRetiredPoll||mcpTask&&taskPark);
 const lateTaskReplyPath=taskRetiredPoll?join(workspace,'mcp-task-release-retired-poll'):undefined;
 const taskChangeTransport=env.CLAUDE_RESEARCH_MCP_TASK_CHANGE_TRANSPORT==='1';
 const requestedTaskOutcome=env.CLAUDE_RESEARCH_MCP_TASK_SETTLED_ON_RESUME;
 const settledTaskOutcome=requestedTaskOutcome==='1'?'completed':requestedTaskOutcome;
 assert.ok(settledTaskOutcome===undefined||['completed','failed','cancelled'].includes(settledTaskOutcome));
 const taskSettledOnResume=settledTaskOutcome!==undefined;
 assert.ok(!(taskChangeTransport&&taskSettledOnResume));
 assert.ok(!taskRetiredPoll||!taskChangeTransport&&!taskSettledOnResume);
 assert.ok(!(taskChangeTransport||taskSettledOnResume)||taskPark);
 const taskStatePath=join(workspace,'mcp-task-owned-state.json');
 const changedTaskPeerReceipts=join(workspace,'mcp-task-changed-peer-receipts.jsonl');
 const changeTaskTransport=taskChangeTransport?async()=>{
  const current=JSON.parse(await readFile(configPath,'utf8')),peer=current.mcpServers.research;
  assert.equal(peer.type,'stdio');
  assert.equal(peer.env.APACK_MCP_TASK_RECEIPT,taskReceipts);
  const {APACK_MCP_TASK_RECONNECT_STATE,APACK_MCP_TASK_FINISH_RECOVERED,...replacementEnv}=peer.env;
  assert.ok(APACK_MCP_TASK_RECONNECT_STATE&&APACK_MCP_TASK_FINISH_RECOVERED);
  const replacement={...peer,args:[...peer.args,'replacement-peer'],env:{...replacementEnv,APACK_MCP_TASK_RECEIPT:changedTaskPeerReceipts}};
  current.mcpServers.research=replacement;
  await writeFile(configPath,JSON.stringify(current));
  return {serverName:'research',originalArgs:peer.args,replacementArgs:replacement.args};
 }:undefined;

 const taskFinish=taskReattach||taskPark||taskAutoReattach?join(workspace,'mcp-task-finish-recovered'):undefined;
 const taskVariants=[mcpTaskInput,mcpTaskExpired,taskTransportDrop,taskPark,taskAutoReattach].filter(Boolean);
 assert.ok(taskVariants.length<=1&&(!taskVariants.length||mcpTask));
 const taskInputAction=env.CLAUDE_RESEARCH_MCP_TASK_INPUT_ACTION??'accept';
 assert.ok(['accept','decline','cancel'].includes(taskInputAction));
 const staleTaskInput=env.CLAUDE_RESEARCH_MCP_TASK_STALE_INPUT==='1';
 assert.ok(taskInputAction==='accept'||mcpTaskInput);
 assert.ok(!staleTaskInput||(mcpTaskInput&&taskInputAction==='accept'));
 assert.ok(!mcpTaskUpdateExhaustion||mcpTaskInput&&!staleTaskInput&&!mcpTaskSecondInput&&!mcpTaskCompletionNotice&&taskInputAction==='accept');
 assert.ok(!mcpTaskLongFollowup||mcpTaskSecondInput);
 assert.ok(!mcpTaskSecondInput||mcpTaskInput&&!staleTaskInput&&taskInputAction==='accept');
 assert.ok(!mcpTaskCompletionNotice||mcpTaskInput&&taskInputAction==='accept'&&!staleTaskInput);
 const mcpTaskScenario=mcpTaskInput?'input':mcpTaskExpired?'expired':'held';
 const taskAdvanceRelease=taskVariants.length?join(workspace,'mcp-task-advance-release'):undefined;
 const taskReceipts=join(workspace,'mcp-task-receipts.jsonl');
 let taskPeer;
 if(mcpTask){
  assert.ok(![managedScan,refusalCase,desktopPermissions,directAuto].some(Boolean));
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(boundary.requireMcpTaskDesktop&&boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
  assert.equal(mcpTaskInput,boundary.requireMcpTaskInput===true);
  assert.equal(mcpTaskUpdateExhaustion,boundary.requireMcpTaskUpdateExhaustion===true);
  assert.equal(mcpTaskLongFollowup,boundary.requireMcpTaskLongFollowup===true);
  assert.equal(mcpTaskSecondInput,boundary.requireMcpTaskSecondInput===true);
  assert.equal(taskInputAction,boundary.taskInputAction??'accept');
  assert.equal(staleTaskInput,boundary.requireStaleMcpTaskInput===true);
  assert.equal(mcpTaskCompletionNotice,boundary.requireMcpTaskCompletionNotice===true);
  assert.equal(mcpTaskExpired,boundary.requireMcpTaskExpired===true);
  assert.equal(taskTransportDrop,boundary.requireMcpTaskTransportDrop===true);
  assert.equal(taskReattach,boundary.requireMcpTaskReattach===true);
  assert.equal(taskAutoReattach,boundary.requireMcpTaskAutoReattach===true);
  assert.equal(taskPark,boundary.requireMcpTaskPark===true);
  assert.equal(taskRetiredPoll,boundary.requireMcpTaskRetiredPoll===true);
  assert.equal(taskChangeTransport,boundary.requireMcpTaskChangedTransport===true);
  assert.equal(taskSettledOnResume,boundary.requireMcpTaskSettledOnResume===true);
  if(taskSettledOnResume)assert.equal(settledTaskOutcome,boundary.mcpTaskSettledOutcome??'completed');
  assert.ok(!config.cachedGrowthBookFeatures&&!config.growthBookOverrides&&!config.mcpServers?.research);
  if(taskAutoReattach)taskPeer=await startManagedMcpTaskHttpServer({receipts:taskReceipts,interruptPath:taskAdvanceRelease,finishPath:taskFinish});
  if(taskRetiredPoll)taskPeer=await startManagedMcpTaskHttpServer({receipts:taskReceipts,holdPath:taskAdvanceRelease,
   finishPath:taskFinish,lateReplyPath:lateTaskReplyPath});
  await writeFile(configPath,JSON.stringify({...config,mcpServers:{...config.mcpServers,research:taskPeer?{type:'http',url:taskPeer.url}:{
   type:'stdio',command:process.execPath,args:[new URL('../protocol/owned-mcp-task-server.mjs',import.meta.url).pathname],
   env:{APACK_MCP_ADVERTISE_TASKS:'1',APACK_MCP_TASK_RECEIPT:taskReceipts,...(mcpTaskUpdateExhaustion&&{APACK_MCP_TASK_FAIL_UPDATES:'1'}),...(mcpTaskSecondInput&&{APACK_MCP_TASK_SECOND_INPUT:'1'}),...(mcpTaskLongFollowup&&{APACK_MCP_TASK_LONG_FOLLOWUP:'1'}),...(taskTransportDrop&&{APACK_MCP_TASK_DISCONNECT_ON_RELEASE:'1'}),...(taskFinish&&{APACK_MCP_TASK_RECONNECT_STATE:taskStatePath,APACK_MCP_TASK_FINISH_RECOVERED:taskFinish}),...(staleTaskInput&&{APACK_MCP_TASK_FORGET_BEFORE_ANSWER:'1'}),...(taskAdvanceRelease&&{APACK_MCP_TASK_ADVANCE_RELEASE:taskAdvanceRelease})},
  }}}));
 }
 const output=join(workspace,'electron-results');let model,billing,proof;
 try{
  model=await startSyntheticModel(directAuto?project:workspace,mcpTask?'mcp__research__review':channelRefusal?'mcp__research__echo':'TextOnly',{
   ...(mcpTask?{mcpTaskScenario,mcpTaskPrompt}:channelRefusal?{mcpChannelScenario:true,mcpChannelPrompt:channelPrompt}:{textReply:'The local release permissions review is complete.'}),channelRelayScenario:channelRelay,captureMessages:true,brokerApprovalReads,captureSystem:managedScan,managedScanHold:managedScan,managedScanFlagged:!!flaggedDecision,nativeRecentDenials:directAuto||env.CLAUDE_RESEARCH_PERMISSIONS_RECENT==='1',maxRequests:env.CLAUDE_RESEARCH_PERMISSIONS_RECENT==='1'?16:mcpTask?12:8});
  const tls=await prepareNativeCreditTls(join(workspace,'account-tls'));billing=await startNativeCreditBilling(tls,{allowMutations:false,managedScanRollout:managedScanServed,mcpTaskRollout:mcpTask,
    ...(channelIngress&&{channelRelay,accountType:channelRevocation?'team':'pro',channelPluginAllowlist:[{marketplace:channelMarketplace,plugin:channelPlugin}]}),evidencePath:join(workspace,'account-live.json')});
  const environmentJourney=['1','transitions','defaults','feedback'].includes(env.CLAUDE_RESEARCH_PERMISSIONS_ENVIRONMENT);
  const configuredEditor=join(workspace,'original-environment-editor');
  if(environmentJourney)await writeFile(configuredEditor,'#!/bin/sh\nprintf \'%s\\n\' \"$1\" >> \"$HOME/original-editor-invocations\"\n',{mode:0o700});
  const launchEnv={...env,...account,...environmentJourney?{VISUAL:configuredEditor}:{},NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  if(taskSettledOnResume){
   executable=join(workspace,'task-resume-diagnostic-launcher');
   await writeFile(executable,'#!/bin/sh\nexec /frozen-claude/claude --debug-file "'+workspace+'/task-resume-debug-$$.log" "$@"\n',{mode:0o700});
  }
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:heldManagedRuleAddition?'real-Electron-held-managed-rule-addition':heldManagedRuleEdit?'real-Electron-held-managed-rule-edit':mountedManagedRuleRefresh?'real-Electron-mounted-managed-rule-refresh':liveManagedRuleSources?'real-Electron-live-managed-rule-sources':managedRuleCatalog?'real-Electron-managed-rule-catalog':managedRuleSources?'real-Electron-managed-rule-sources':'real-Electron-fresh-native-command',journeyBudgetMs:memoryPolicyPopout?150000:120000,journey:async({app,page,electronApp,expect,phase,userDataDir})=>{
   proof={status:'running',scope:'Original main /permissions native terminal panel, keyboard navigation, close/reopen and same-session follow-up only; no permission mutation, Agent/background or parity acceptance.',captures:[],layouts:[]};const save=()=>writeFile(join(output,'native-command.json'),JSON.stringify(proof,null,2));
   const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews}});
   const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
   const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await composer.pressSequentially(text);await expect(composer).toHaveText(text)};
   try{
    if(environmentJourney)page.setDefaultTimeout(10000);
    await app.waitForSurface('default-setup/threads');await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill(executable);await page.waitForTimeout(700);
    await app.navigate('default-setup/threads');await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return!!c.currentThread?.id&&c.openedThreadId===null&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code')}),{timeout:15000}).toBe(true);
    await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
    proof.seed='Review the local release notes before checking permissions.';await replace(proof.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);
    if(startingTerminal)await stopStartingTerminal({page,expect,context,composer,section,proof,output,birth,save,model,fixture:startingTerminal});
    if(channelRefusal||channelIngress)await selectOwnedChannel({page,card,composer,replace,expect,context,proof,output,save,selector:channelIngress?channelSelector:undefined});
    const openNative=async()=>{
     await section.getByRole('button',{name:'Use native interface',exact:true}).click();
     const seen=new Set();for(let i=0;i<100;i++){const native=(await context()).native?.state;if(native?.nativePid&&native.status==='live')break;const text=await section.locator('[data-terminal-text]').innerText().catch(()=>''),stage=recognizeOnboardingPrompt(text,project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100);}
     await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
    };
    await openNative();
    proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.pid=proof.initial.native.state.nativePid;proof.processStart=await birth(proof.pid);assert.ok(proof.processStart);await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
    if(managedRuleSources){await (mountedManagedRuleRefresh?driveMountedManagedRuleRefresh:liveManagedRuleSources?driveLiveManagedRuleSources:managedRuleCatalog?driveManagedRuleCatalog:driveManagedRuleSources)({page,expect,context,composer,send,section,replace,proof,output,model,birth,save,phase,project,control:env.CLAUDE_RESEARCH_POLICY_CONTROL,heldManagedRuleEdit,heldManagedRuleAddition});return;}
    if(brokerApprovalLoss){await driveBrokerApprovalLoss({page,expect,context,composer,section,replace,openNative,proof,output,birth,save,model,phase,userDataDir,readFiles:brokerApprovalReads.map(row=>row.file)});return;}
    if(terminalBrokerLoss){await driveTerminalBrokerLoss({page,expect,context,composer,send,section,replace,openNative,proof,output,birth,save,model,phase});return;}
    if(startingTerminal){await finishStartingTerminalJourney({page,expect,context,composer,send,section,replace,proof,output,birth,save,phase});return;}
    if(channelIngress){
     await expect.poll(()=>billing.state.requests.some(request=>request.method==='POST'&&request.path===EFFORT_EVAL_ROUTE&&request.status===200&&request.syntheticAuth),{timeout:12000}).toBe(true);
     const channelJourney={page,expect,context,composer,section,proof,output,debug:channelDebug+'.'+proof.pid+'.log',
       receipts:channelReceipts,model,birth,save,phase};
     if(channelRevocation)await driveOwnedChannelRevocation({...channelJourney,send,replace,relayDirectory,control:env.CLAUDE_RESEARCH_POLICY_CONTROL});
     else if(channelReplacement)await driveOwnedChannelReplacement({...channelJourney,send,replace,relayDirectory,debugPrefix:channelDebug});
     else if(channelRelay)await driveOwnedChannelRelay({...channelJourney,send,replace,relayDirectory});
     else await driveOwnedChannelIngress({...channelJourney,release:channelRelease});
     return;
    }
    if(channelRefusal){
     await driveOwnedChannelRefusal({page,expect,context,composer,send,section,replace,proof,output,debug:channelDebug+'.'+proof.pid+'.log',receipts:channelReceipts,model,birth,save,phase});
     return;
    }
    if(managedMemoryTransition){
     await driveManagedMemoryTransition({page,electronApp,expect,context,composer,send,section,replace,proof,output,workspace,model,birth,save,phase,autoRefreshMemoryPolicy,memoryPolicyPopout});
     return;
    }
    if(workspaceHeader){
     await driveCompactWorkspace({page,expect,context,composer,send,section,replace,proof,output,birth,save,phase,requireReachability:requireWorkspaceReachability,filterWorkspace});
     return;
    }
    if(mcpTask){
     await expect.poll(()=>billing.state.requests.some(request=>request.method==='POST'&&request.path===EFFORT_EVAL_ROUTE&&request.status===200&&request.syntheticAuth),{timeout:12000}).toBe(true);
     await driveMcpTaskJourney({page,expect,context,composer,send,section,replace,proof,output,receipts:taskReceipts,scenario:mcpTaskScenario,taskInputAction,staleTaskInput,mcpTaskSecondInput,mcpTaskLongFollowup,mcpTaskUpdateExhaustion,mcpTaskCompletionNotice,taskTransportDrop,taskAutoReattach,taskPark,taskFinish,taskAdvanceRelease,lateTaskReplyPath,changeTaskTransport,changedTaskPeerReceipts,settledTaskState:taskSettledOnResume?{path:taskStatePath,outcome:settledTaskOutcome}:undefined,workspace,model,birth,save,phase});
     return;
    }
    if(addDirectoryCommand){await driveAddDirectoryCommandJourney({page,expect,context,composer,send,section,replace,proof,output,workspace,project,birth,save,phase,model,semantic:['semantic','restart','write-refusal'].includes(env.CLAUDE_RESEARCH_ADD_DIRECTORY_COMMAND),restart:env.CLAUDE_RESEARCH_ADD_DIRECTORY_COMMAND==='restart',writeRefusal:env.CLAUDE_RESEARCH_ADD_DIRECTORY_COMMAND==='write-refusal',standalone:env.CLAUDE_RESEARCH_ADD_DIRECTORY_COMMAND==='standalone'});return;}
    if(desktopPermissions){
     // Observe the real app transport; never replace its send function or any native callback.
     await page.evaluate(()=>{const system=window.applicationState.system,events=[];let previous='',overflow=0;const append=v=>{if(events.length<512)events.push(v);else overflow++};const inspector=system.inspect(e=>{if(e.type==='@xstate.event'&&e.event?.type==='CLAUDE_UI_SETTINGS')append({kind:'request',requestId:e.event.requestId,action:e.event.action})});const subscription=system.get('default-setup/threads').subscribe(s=>{for(const view of Object.values(s.context.nativeUiViews)){const settings=view.state?.agentInput?.settings;if(!settings)continue;const next={kind:'reply',requestId:settings.requestId,status:settings.status,problem:settings.problem,revision:settings.snapshot?.revision,title:settings.snapshot?.permissions?.title,search:settings.snapshot?.permissions?.search},encoded=JSON.stringify(next);if(encoded!==previous){previous=encoded;append(next)}}});window.__permissionsObservation={events,overflow:()=>overflow,stop:()=>{inspector.unsubscribe();subscription.unsubscribe()}}});
     try{await driveDesktopPermissionsJourney({page,expect,context,composer,send,section,replace,proof,output,workspace,birth,save,phase,model,workspaceJourney:env.CLAUDE_RESEARCH_PERMISSIONS_WORKSPACE==='1',autocompleteJourney:env.CLAUDE_RESEARCH_PERMISSIONS_AUTOCOMPLETE==='1',autoModeJourney:env.CLAUDE_RESEARCH_PERMISSIONS_AUTOMODE==='1',searchJourney:env.CLAUDE_RESEARCH_PERMISSIONS_SEARCH==='1',recentJourney:env.CLAUDE_RESEARCH_PERMISSIONS_RECENT==='1',environmentJourney,feedbackTheme,environmentTransitionJourney:env.CLAUDE_RESEARCH_PERMISSIONS_ENVIRONMENT==='1'?false:env.CLAUDE_RESEARCH_PERMISSIONS_ENVIRONMENT});}
     finally{const observed=await page.evaluate(()=>{const observation=window.__permissionsObservation;observation.stop();delete window.__permissionsObservation;return{events:observation.events,overflow:observation.overflow()}});proof.permissionExchanges=observed.events;proof.permissionExchangeOverflow=observed.overflow;await save()}
     if(env.CLAUDE_RESEARCH_PERMISSIONS_SEARCH==='1'){assert.equal(proof.permissionExchangeOverflow,0);assert.deepEqual(proof.permissionExchanges.filter(v=>v.kind==='reply'&&v.status==='error'),[])}
     return;
    }
    if(directAuto){await driveDirectAutoVerdict({page,expect,context,composer,send,section,replace,proof,project,output,model,birth,save,phase});return;}
    if(refusalCase){await driveCommandRefusalJourney({page,electronApp,multipleWindows:env.CLAUDE_RESEARCH_COMMAND_WINDOWS==='1',expect,context,composer,send,section,replace,proof,output,birth,save,phase,model});return;}
    if(managedScanServed){
     await expect.poll(()=>billing.state.requests.some(request=>request.method==='POST'&&request.path===EFFORT_EVAL_ROUTE&&request.status===200&&request.syntheticAuth),{timeout:12000}).toBe(true);
     proof.originalHostedSetupEvaluation=true;
     phase('native-managed-scan-cohort-served');
    }
    if(managedScan){await driveManagedScanJourney({app,page,expect,context,composer,send,section,replace,proof,workspace,userDataDir,output,model,birth,save,phase,clearBeforeStop:managedScanReset,holdTaskPointerAcrossReset,reviewDecision:managedScanReview,flaggedDecision});return;}
    const panel=page.getByRole('dialog',{name:'Native /permissions panel',exact:true});
    const capture=async stage=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect(panel).toBeInViewport({ratio:1});await expect(panel.getByRole('button',{name:'Close panel',exact:true})).toBeInViewport({ratio:1});await page.evaluate(()=>document.fonts.ready);await expect.poll(()=>panel.locator('[data-native-terminal]').evaluate(e=>{const canvas=e.querySelector('canvas'),host=e.parentElement;if(!canvas||!host)return false;const r=canvas.getBoundingClientRect(),h=host.getBoundingClientRect(),text=e.querySelector('[data-terminal-text]')?.innerText??'',rulers=text.split('\n').filter(line=>/^─{10,}$/.test(line.trim()));return r.width<=h.width+1&&r.height<=h.height+1&&h.width-r.width<16&&h.height-r.height<30&&rulers.at(-1)?.trim().length===Number(e.dataset.nativeTerminalColumns)}),{timeout:15000}).toBe(true);await expect.poll(()=>panel.locator('[data-terminal-text]').innerText(),{timeout:15000}).toMatch(/permission/i);proof.layouts.push({stage,size,text:await panel.locator('[data-terminal-text]').innerText(),box:await panel.boundingBox(),drawing:await panel.locator('[data-native-terminal]').evaluate(e=>({columns:e.dataset.nativeTerminalColumns,rows:e.dataset.nativeTerminalRows,canvas:(()=>{const r=e.querySelector('canvas').getBoundingClientRect();return{width:r.width,height:r.height}})(),host:(()=>{const r=e.parentElement.getBoundingClientRect();return{width:r.width,height:r.height}})()}))});const file='native-command-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);await save()}};
    for(const cycle of ['first','reopened']){await replace('/permissions');const before=model.calls.length;await send.click();await expect(panel).toBeVisible({timeout:15000});await expect(panel.locator('[aria-label="Terminal input"]')).toBeFocused();await capture(cycle);await panel.locator('[aria-label="Terminal input"]').focus();await page.keyboard.press('Tab');await capture(cycle+'-keyboard');await panel.getByRole('button',{name:'Close panel',exact:true}).click();await expect(panel).toBeHidden({timeout:15000});await expect(composer).toBeEditable();assert.equal(model.calls.length,before,'Local commands must not query the model');assert.equal((await context()).native.state.nativePid,proof.pid);assert.equal(await birth(proof.pid),proof.processStart);}
    proof.followup='Continue the release summary after checking local permissions.';await replace(proof.followup);await send.click();await expect.poll(async()=>{const c=await context();return c.native?.state?.busy===false&&c.messages?.filter(m=>m.sender==='user'&&m.text===proof.followup).length===1&&c.claude?.chatState==='success'},{timeout:15000}).toBe(true);await replace('Keep the release summary draft for the next step.');proof.final=await context();assert.equal(proof.final.claude.sessionId,proof.sessionId);assert.equal(proof.final.native.state.nativePid,proof.pid);assert.equal(proof.final.claude.totalCostUsd,proof.final.native.state.session.totalCostUsd);
    for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await expect(composer).toBeInViewport({ratio:1});await expect(send).toBeInViewport({ratio:1});const file='native-command-recovered-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file)}
    await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);proof.stopped=true;proof.status='complete';await save();phase('native-command-complete');
   }catch(error){
    proof.status='failed';proof.error=error.message;
    if(environmentJourney||terminalBrokerLoss||brokerApprovalLoss){try{const filename=terminalBrokerLoss||brokerApprovalLoss?'terminal-broker-failure.png':'native-environment-failure.png';await page.screenshot({path:join(output,filename),animations:'disabled',timeout:5000});proof.failureScreenshot=filename}catch(captureError){proof.failureScreenshotError=captureError.message}}
    proof.failureContext=await context().catch(()=>null);await save();
    const activePid=proof.resumedWriter?.pid??proof.pid, activeStart=proof.resumedWriter?.start??proof.processStart;
    if((managedScan||refusalCase||desktopPermissions||addDirectoryCommand||startingTerminalStop||terminalBrokerLoss||brokerApprovalLoss||managedRuleSources||directAuto||mcpTask||workspaceHeader||managedMemoryTransition||channelRefusal||channelIngress)&&activePid&&await birth(activePid)===activeStart){
     proof.failureCleanup={attempted:true};
     try{
      const closeDetails=page.getByRole('button',{name:'Close Claude session details',exact:true});
      if(await closeDetails.isVisible()){
       await page.keyboard.press('Escape');
       if(await closeDetails.isVisible())await closeDetails.click({timeout:3000});
      }
      const show=section.getByRole('button',{name:'Use native interface',exact:true});if(await show.isVisible())await show.click({timeout:3000});
      await section.getByRole('button',{name:'Stop session',exact:true}).click({timeout:3000});
      await expect.poll(()=>birth(activePid),{timeout:15000}).toBe(null);proof.failureCleanup.nativeWriterRetired=true;
     }catch(cleanupError){proof.failureCleanup.error=cleanupError.message}
     await save();
    }
    throw error;
   }
  }});
 }finally{
  if(managedScan)await writeFile(join(workspace,'managed-scan-model-release'),'release');
  await taskPeer?.close();await model?.close();await billing?.close();await mkdir(output,{recursive:true});if(model)await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2));if(billing)await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2));
  const retired=(!proof?.pid||await birth(proof.pid)!==proof.processStart)&&(!proof?.resumedWriter||await birth(proof.resumedWriter.pid)!==proof.resumedWriter.start);await writeFile(join(output,'writer-retirement.json'),JSON.stringify({retired,pid:proof?.pid,processStart:proof?.processStart,resumedWriter:proof?.resumedWriter}));assert.ok(retired,'Native writer must retire before profile restoration');await writeFile(join(output,'native-settings-after.json'),await readFile(settingsPath));await writeFile(join(output,'native-config-after.json'),await readFile(configPath));await writeFile(configPath,configBefore);await writeFile(settingsPath,settingsBefore);assert.deepEqual(await readFile(configPath),configBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configSha256:sha(configBefore),settingsSha256:sha(settingsBefore)}));
  if(proof?.sessionId){
   const root=join(workspace,'.claude/projects'),files=await readdir(root,{recursive:true});
   const journals=[['native-parent-transcript.jsonl',proof.sessionId]];
   if(proof.fresh?.sessionId)journals.push(['native-fresh-directory-transcript.jsonl',proof.fresh.sessionId]);
   if(proof.reset?.newSessionId)journals.push(['native-reset-transcript.jsonl',proof.reset.newSessionId]);
   for(const [name,id] of journals){
    const matches=files.filter(file=>basename(file)===id+'.jsonl');assert.equal(matches.length,1);
    await writeFile(join(output,name),await readFile(join(root,matches[0])));
   }
  }
 }
}
