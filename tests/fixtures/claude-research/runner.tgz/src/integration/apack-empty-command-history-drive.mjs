import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';

export function driveEmptyCommandHistory(options) {
 return driveChildComposer({...options,modelTool:'TextOnly',modelOptions:{childPlanDirectory:join(options.setupWorkspace,'app-data/claude-code-profile/config/plans')},modelRequestLimit:24,journey:emptyHistoryJourney,journeyName:'empty-command-history'});
}
async function emptyHistoryJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 const proof={status:'running',parentSessionId,initial,scope:'Original empty local-command stdout remains in native journal and absent from app bubbles through load/reload and resumed parent; normal/compact composing retained.',captures:[]};
 const save=()=>writeFile(join(output,'empty-command-history.json'),JSON.stringify(proof,null,2));
 const journal=async()=>{const root=join(userDataDir,'claude-code-profile/config/projects');for(const directory of(await readdir(root,{withFileTypes:true})).slice(0,64)){if(!directory.isDirectory())continue;const path=join(root,directory.name,parentSessionId+'.jsonl');let info;try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);return {path,raw,rows:raw.toString().split('\n').filter(Boolean).map(JSON.parse)};}throw Error('Original parent journal missing');};
 const emptyRows=rows=>rows.filter(row=>row.type==='user'&&row.entrypoint==='cli'&&row.origin===undefined&&row.message?.content==='<local-command-stdout>(no content)</local-command-stdout>');
 const check=async(stage)=>{
  const state=await context();assert.equal(state.claude.sessionId,parentSessionId);assert.ok(!state.messages.some(message=>message.text?.trim()==='(no content)'));await expect(page.locator('[data-chat-message]').getByText('(no content)',{exact:true})).toHaveCount(0);
  for(const[name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(size);await composer.fill('Keep the release review draft.');await expect(composer).toHaveText('Keep the release review draft.');await expect(card.getByRole('button',{name:'Send',exact:true})).toBeInViewport({ratio:1});const capture='empty-command-'+stage+'-'+name+'.png';await page.screenshot({path:join(output,capture)});proof.captures.push(capture);}
  proof[stage]=await context();await save();
 };
 try{
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill('/background ResearchChildPlan1 Enter planning for the release review.');await card.getByRole('button',{name:'Send',exact:true}).click();
  const widget=page.getByRole('region',{name:'Background Claude session',exact:true});await expect(widget).toBeVisible({timeout:25000});
  await expect.poll(async()=>(await context()).native?.background?.desktop,{timeout:25000}).toBeTruthy();proof.background=await context();
  await expect.poll(async()=>emptyRows((await journal()).rows).length,{timeout:15000}).toBeGreaterThan(0);
  const original=await journal();proof.emptyNativeRows=emptyRows(original.rows);await writeFile(join(output,'native-empty-command-before.jsonl'),original.raw);proof.journal={path:original.path,beforeSha256:createHash('sha256').update(original.raw).digest('hex')};
  await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});
  await check('loaded');await composer.fill('');
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:20000}).toBe('exited');
  await page.reload();await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');await expect.poll(async()=>(await context()).claude?.sessionId,{timeout:15000}).toBe(parentSessionId);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');proof.resumed=await context();assert.notEqual(proof.resumed.native.state.nativePid,initial.native.state.nativePid);
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await check('resumed');
  const after=await journal();assert.deepEqual(emptyRows(after.rows).map(row=>row.uuid),proof.emptyNativeRows.map(row=>row.uuid));await writeFile(join(output,'native-empty-command-after.jsonl'),after.raw);proof.journal.afterSha256=createHash('sha256').update(after.raw).digest('hex');
  await composer.fill('');await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:20000}).toBe('exited');proof.final=await context();proof.status='complete';await save();phase('empty-command-history-complete');
 }catch(error){proof.status='failed';proof.error=String(error.message).slice(0,4096);await save();await page.screenshot({path:join(output,'empty-command-failure.png')}).catch(()=>{});throw error;}
}
