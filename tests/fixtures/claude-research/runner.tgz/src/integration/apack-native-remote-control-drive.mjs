import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs'
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs'
import { createNativeRemoteControlFixture } from '../protocol/native-remote-control-fixture.mjs'
import { isolatedModelGateway } from '../protocol/native-loopback-model-gateway.mjs'
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs'
import { startSyntheticModel } from '../protocol/synthetic-model.mjs'
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs'

const executable = '/frozen-claude/claude'
const pin = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
const seed = 'Read the release notes before reviewing remote access.'
const followup = 'Confirm that this release review stays on the local machine.'
const draft = 'Check the release checklist before turning on remote access.'

export async function driveNativeRemoteControl({checkout,workspace,env,verifyDraft=false}) {
  assert.equal(process.platform,'linux')
  assert.equal(process.getuid(),1000)
  assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-remote-control[0-9]+$/)
  const boundary = JSON.parse(await readFile('/control/offline-verified'))
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly && boundary.requireRemoteControlCallout)
  assert.equal(boundary.requireDraftWithdrawal===true,verifyDraft)
  assert.equal(digest(await readFile(executable)),pin)
  assert.match(await readFile('/etc/hosts','utf8'),/^127\.0\.0\.1\s+api\.anthropic\.com(?:\s|$)/m)
  const project = join(workspace,'project')
  await mkdir(project)
  await writeFile(join(project,'release-notes.md'),'# Release notes\n\nAll changes are part of an isolated release review.\n')
  execFileSync('/usr/bin/git',['init','--quiet','-b','main'],{cwd:project,env:{PATH:'/usr/bin:/bin',HOME:workspace,
    GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000})
  const account = await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'})
  const configPath = join(account.CLAUDE_CONFIG_DIR,'.claude.json')
  const config = JSON.parse(await readFile(configPath,'utf8'))
  config.hasCompletedOnboarding = true
  config.projects = {[project]:{hasTrustDialogAccepted:true}}
  assert.equal(config.remoteDialogSeen,undefined)
  assert.equal(config.cachedGrowthBookFeatures,undefined)
  assert.equal(config.growthBookOverrides,undefined)
  await writeFile(configPath,JSON.stringify(config))

  const fixture = createNativeRemoteControlFixture()
  const wire = []
  const tls = await prepareNativeCreditTls(join(workspace,'account-tls'))
  const model = await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:8,textReply:'The local release review is ready.'})
  try {
    const routeModel = isolatedModelGateway(model,wire)
    const billing = await startNativeCreditBilling(tls,{allowMutations:false,managedConnector:async(req,res)=>
      await fixture.handle(req,res) || await routeModel(req,res)})
    try {
      const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:'https://api.anthropic.com',
        DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project}
      for (const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','DISABLE_TELEMETRY','DISABLE_ERROR_REPORTING',
        'DISABLE_GROWTHBOOK','CLAUDE_INTERNAL_FC_OVERRIDES','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC']) delete launchEnv[key]
      await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-remote-control-callout',journeyBudgetMs:125000,
        journey:args=>remoteJourney({...args,fixture,model,configPath,verifyDraft})})
    } finally {
      await billing.close()
      assert.equal(billing.state.purchases.length,0)
      assert.equal(billing.state.adminRequests.length,0)
      await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2))
    }
  } finally {
    await model.close()
    await writeFile(join(workspace,'remote-control-wire.json'),JSON.stringify(fixture.snapshot(),null,2))
    await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2))
  }
}

async function remoteJourney({app,page,output,project,userDataDir,expect,phase,fixture,model,configPath,verifyDraft}) {
  const proof = {status:'running',captures:[],decisions:[],...(verifyDraft?{draftWithdrawal:[]}:{} )}
  const save = () => writeFile(join(output,'remote-control.json'),JSON.stringify(proof,null,2))
  const context = () => page.evaluate(()=>{
    const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context
    const view=Object.values(c.nativeTerminalViews).find(entry=>entry.threadId===c.currentThread?.id)
    return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,native:view?.state,
      answer:view?.noticeAnswer,messages:c.currentThread?.messages}
  })
  const seen = async () => JSON.parse(await readFile(configPath,'utf8')).remoteDialogSeen===true
  const attempts = () => fixture.snapshot().filter(event=>event.kind==='bridge-registration-refused')
  const card = page.locator('[data-onboarding-id="agent-chat-input"]')
  const composer = card.locator('[contenteditable="true"]')
  const send = card.getByRole('button',{name:'Send',exact:true})
  const region = page.getByRole('region',{name:'Claude native interface',exact:true})
  const dialog = page.getByRole('dialog',{name:'Remote Control',exact:true})
  const dismiss = dialog.getByRole('button',{name:'Never mind',exact:true})
  const enable = dialog.getByRole('button',{name:'Enable Remote Control',exact:true})
  const submit = async text => {
    await composer.fill(text)
    await expect(composer).toHaveText(text)
    await send.click({timeout:12000})
  }

  try {
    const compiled=JSON.parse(await readFile('/control/producer-pack-inputs.json'))
    for (const file of ['runtime/fe.js','runtime/index.cjs']) {
      assert.equal(digest(await readFile(join(userDataDir,'apack/packs/default-setup',file))),compiled[file])
    }
    await app.waitForSurface('default-setup/threads')
    await app.navigate('host/settings')
    await page.evaluate(()=>{
      const settings=window.applicationState.system.get('host/settings')
      settings.send({type:'TAB.SELECT',tab:'general'})
      settings.send({type:'GENERAL_NAV.SELECT',item:'secrets'})
    })
    await page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..')
      .getByPlaceholder('Path override (auto-detected if empty)').fill(executable)
    await page.waitForTimeout(700)
    await app.navigate('default-setup/threads')
    await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.modes.some(mode=>mode.name==='Claude Code')),{timeout:15000}).toBe(true)
    await page.evaluate(directory=>{
      const threads=window.applicationState.system.get('default-setup/threads')
      threads.send({type:'VIEW_DASHBOARD'})
      threads.send({type:'NEW_THREAD_IN_PROJECT',directory})
      threads.send({type:'SET_MODE',mode:'Claude Code'})
      threads.send({type:'SET_PHASE',phase:'Edit'})
    },project)
    await submit(seed)
    await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1)
    await region.getByRole('button',{name:'Use native interface',exact:true}).click({timeout:10000})
    const completed = new Set()
    for (let attempt=0;attempt<100;attempt++) {
      if ((await context()).native?.status==='live') break
      const screen=await region.locator('[data-terminal-text]').innerText().catch(()=>'')
      const step=recognizeOnboardingPrompt(screen,project)
      if (step && !completed.has(step)) {
        completed.add(step)
        await region.locator('[aria-label="Terminal input"]').focus()
        await page.waitForTimeout(200)
        await page.keyboard.press(step==='workspace-trust'?'ArrowDown':'Enter')
      }
      await page.waitForTimeout(100)
    }
    await expect.poll(async()=>(await context()).native?.status,{timeout:20000}).toBe('live')
    const initial=await context()
    proof.owner={threadId:initial.threadId,sessionId:initial.native.sessionId,ownerId:initial.native.ownerId,pid:initial.native.nativePid}
    await region.getByRole('button',{name:'Back to conversation',exact:true}).click({timeout:10000})
    await expect.poll(()=>fixture.snapshot().some(row=>row.kind==='evaluation' && row.rollout),{timeout:12000}).toBe(true)
    await save()

    for (const choice of verifyDraft ? ['dismiss'] : ['dismiss','escape','enable']) {
      assert.equal(await seen(),false)
      assert.equal(attempts().length,0)
      await submit('/remote-control')
      await expect(dialog).toBeVisible({timeout:18000})
      await expect(enable).toBeEnabled({timeout:12000})
      const offer=(await context()).native?.notice
      assert.equal(offer?.kind,'remote_callout')
      assert.equal(offer.sessionId,proof.owner.sessionId)
      assert.ok(!proof.decisions.some(row=>row.offer.revision===offer.revision))
      if (choice==='dismiss') {
        for (const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
          await page.setViewportSize(viewport)
          await page.evaluate(()=>document.fonts.ready)
          await expect(dialog).toBeInViewport({ratio:0.9})
          await expect(enable).toBeInViewport({ratio:1})
          await expect(dismiss).toBeInViewport({ratio:1})
          if (verifyDraft) {
            const original=await context()
            const staleButton=await enable.elementHandle({timeout:5000})
            try {
              await composer.click()
              await composer.pressSequentially(draft)
              await expect(composer).toHaveText(draft)
              await composer.press('End')
              await composer.press('Shift+ArrowLeft')
              await expect.poll(()=>composer.evaluate(el=>el.contains(getSelection()?.anchorNode)
                && document.activeElement===el && getSelection().toString()),{timeout:4500}).toBe('.')
              await expect(dialog).toBeHidden({timeout:6000})
              assert.equal(await staleButton.evaluate(button=>button.isConnected),false)
              await staleButton.evaluate(button=>button.click())
              await expect(composer).toBeFocused()
              await expect(composer).toHaveText(draft)
              assert.equal(await composer.evaluate(()=>getSelection().toString()),'.')
              const editing=await context()
              assert.deepEqual(editing.answer,original.answer)
              assert.equal(editing.native?.notice?.id,original.native?.notice?.id)
              assert.equal(editing.native?.notice?.revision,original.native?.notice?.revision)
              assert.equal(await seen(),false)
              assert.equal(attempts().length,0)
              const hidden='remote-control-editing-'+size+'.png'
              await page.screenshot({path:join(output,hidden),animations:'disabled'})
              proof.captures.push(hidden)
              await composer.press('ControlOrMeta+a')
              await composer.press('Backspace')
              await expect(composer).toHaveText('')
              await expect(dialog).toBeVisible({timeout:8000})
              const restored=await context()
              assert.equal(restored.native?.notice?.id,original.native?.notice?.id)
              assert.equal(restored.native?.notice?.revision,original.native?.notice?.revision)
              assert.equal(restored.native.sessionId,proof.owner.sessionId)
              proof.draftWithdrawal.push({size,draft,selection:'.',detached:true,noticeId:restored.native.notice.id,revision:restored.native.notice.revision})
              await save()
            } finally {
              await staleButton.dispose()
            }
          }
          const name='remote-control-'+size+'.png'
          await page.screenshot({path:join(output,name),animations:'disabled'})
          proof.captures.push(name)
        }
        await dismiss.click({timeout:10000})
      } else if (choice==='escape') {
        await dismiss.focus()
        await dismiss.press('Escape')
      } else await enable.click({timeout:10000})

      await expect(dialog).toBeHidden({timeout:10000})
      await expect.poll(async()=>(await context()).answer?.status,{timeout:10000}).toBe('done')
      const answer=(await context()).answer
      assert.equal(answer.revision,offer.revision)
      proof.decisions.push({choice,offer,answer})
      if (choice==='enable') {
        await expect.poll(seen,{timeout:10000}).toBe(true)
        await expect.poll(()=>attempts().length,{timeout:17000}).toBeGreaterThan(0)
      } else {
        assert.equal(await seen(),false)
        assert.equal(attempts().length,0)
      }
      await save()
    }
    if (verifyDraft) {
      assert.equal(await seen(),false)
      assert.equal(attempts().length,0)
    }
    await submit(followup)
    await expect.poll(async()=>{
      const c=await context()
      return model.calls.some(call=>call.messages?.some(message=>message.role==='user'&&JSON.stringify(message.content).includes(followup)))
        && c.native?.busy===false && c.claude?.chatState==='success'
    },{timeout:22000}).toBe(true)
    const returned=await context()
    assert.equal(returned.threadId,proof.owner.threadId)
    assert.equal(returned.native.sessionId,proof.owner.sessionId)
    assert.equal(returned.native.ownerId,proof.owner.ownerId)
    const messages=returned.messages.filter(message=>message.sender==='user'&&message.text===followup)
    assert.equal(messages.length,1)
    assert.ok(messages[0].context?.cliUuid)
    proof.followup={sessionId:returned.native.sessionId,cliUuid:messages[0].context.cliUuid}
    await region.getByRole('button',{name:'Use native interface',exact:true}).click({timeout:10000})
    await region.getByRole('button',{name:'Stop session',exact:true}).click({timeout:10000})
    await expect.poll(()=>readFile('/proc/'+proof.owner.pid+'/stat','utf8').then(text=>!text.includes(') Z '),()=>false),{timeout:15000}).toBe(false)
    proof.status='complete'
    phase('remote-control-callout-complete')
  } catch (error) {
    proof.status='failed'
    proof.error=error.message
    proof.observed=await context().catch(()=>null)
    throw error
  } finally {
    await save()
  }
}
