/** Install before navigating an owned window so the hold sees messages before app listeners. */
export async function holdOwnedPromptDelivery(page) {
  await page.addInitScript(() => {
    if (window !== window.top) return;
    const key = '__claudeResearchPromptDeliveryHold';
    if (window[key]) throw Error('Prompt delivery hold already installed');
    const OriginalSocket = window.WebSocket;
    const sockets = new Set();
    const deliveries = [];
    const replayed = new WeakSet();
    let armed;
    const types = new Set(['CLAUDE_PROMPT_STATE', 'CLAUDE_PROMPT_COMPLETIONS', 'CLAUDE_PROMPT_HOST_REQUEST']);

    function receive(message) {
      if (!armed || this.protocol !== 'apack' || replayed.has(message) || typeof message.data !== 'string') return;
      let frame;
      try { frame = JSON.parse(message.data); } catch { return; }
      const delivery = frame?.result?.type === 'data' && frame.result.data;
      const event = delivery?.event;
      const details = event?.request ?? event?.result;
      if (delivery?.to !== 'default-setup/threads' || event?.type !== armed.type
        || event.threadId !== armed.threadId || event.mountId !== armed.mountId
        || !Number.isSafeInteger(details?.revision)
        || (armed.revision !== undefined && details.revision !== armed.revision)
        || (armed.text !== undefined && (details.frame?.text ?? details.input?.text ?? details.text) !== armed.text)
        || (armed.label !== undefined && !details.result?.suggestions?.some(item => item.label === armed.label))
        || (armed.kind && details.kind !== armed.kind)) return;
      message.stopImmediatePropagation();
      const receipt = { heldAt: Date.now(), type: event.type, threadId: event.threadId, mountId: event.mountId,
        revision: details.revision, status: details.status,
        ...(details.frame && { text: details.frame.text, cursor: details.frame.cursor }),
        ...(details.result?.suggestions && { labels: details.result.suggestions.map(item => item.label) }),
        ...(details.kind && { kind: details.kind, requestId: details.requestId, expiresAt: details.expiresAt,
          text: details.input?.text ?? details.text }) };
      deliveries.push({ socket: this, data: message.data, origin: message.origin, receipt });
      armed = undefined;
    }

    class ObservedSocket extends OriginalSocket {
      constructor(...args) {
        super(...args);
        const url = new URL(this.url);
        const port = String(window.electronAPI?.apiPort ?? '');
        if (port && url.protocol === 'ws:' && url.hostname === '127.0.0.1' && url.port === port) {
          sockets.add(this);
          this.addEventListener('message', receive);
        }
      }
    }

    window.WebSocket = ObservedSocket;
    window[key] = {
      arm(target) {
        const payloadMatches = ['CLAUDE_PROMPT_STATE','CLAUDE_PROMPT_HOST_REQUEST'].includes(target.type) && typeof target.text === 'string'
          || target.type === 'CLAUDE_PROMPT_COMPLETIONS' && typeof target.label === 'string';
        if (armed || !types.has(target.type) || !target.mountId || !target.threadId
          || (target.revision === undefined && !payloadMatches)
          || (target.revision !== undefined && (!Number.isSafeInteger(target.revision) || target.revision < 0))) throw Error('Invalid prompt hold target');
        if (target.type === 'CLAUDE_PROMPT_HOST_REQUEST' && !['fill', 'suggest'].includes(target.kind)) throw Error('Expected a mutating host request');
        armed = target;
      },
      receipts() { return deliveries.map(({ receipt }) => ({ ...receipt })); },
      release(index) {
        const entry = deliveries[index];
        if (!entry || entry.receipt.outcome) throw Error('No unreleased addressed delivery');
        entry.receipt.releasedAt = Date.now();
        if (entry.socket.readyState !== OriginalSocket.OPEN) {
          entry.receipt.outcome = 'original-socket-closed';
        } else {
          const event = new MessageEvent('message', { data: entry.data, origin: entry.origin });
          replayed.add(event);
          entry.socket.dispatchEvent(event);
          entry.receipt.outcome = 'delivered-on-original-socket';
        }
        return { ...entry.receipt };
      },
      close() {
        if (window.WebSocket !== ObservedSocket) throw Error('App WebSocket constructor changed');
        for (const socket of sockets) socket.removeEventListener('message', receive);
        window.WebSocket = OriginalSocket;
        delete window[key];
      },
    };
  });

  const call = (method, argument) => page.evaluate(({ method, argument }) => {
    const hold = window.__claudeResearchPromptDeliveryHold;
    if (!hold) throw Error('Prompt delivery hold unavailable');
    return hold[method](argument);
  }, { method, argument });
  return { arm: target => call('arm', target), receipts: () => call('receipts'),
    release: index => call('release', index), close: () => call('close') };
}
