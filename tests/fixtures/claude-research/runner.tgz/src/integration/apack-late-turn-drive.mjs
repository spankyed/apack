import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {processStart,liveOriginals} from './native-process-state.mjs';
import {startNativeTurnCompletionDelay} from './native-turn-completion-delay.mjs';
import {prepareTurnCompletionProfile} from './turn-completion-profile.mjs';
import {holdOwnedSessionHandoff} from './owned-session-handoff-hold.mjs';
import {createNativeTestImage} from '../protocol/native-test-image.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');

export async function driveLateTurnApp({checkout,workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
 assert.equal(sha(await readFile('/frozen-claude/claude')),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 const mediaReset=env.CLAUDE_RESEARCH_RESET_MEDIA==='1';
 const compactImageLayout=env.CLAUDE_RESEARCH_COMPACT_IMAGE_LAYOUT==='1';
 const requireCleanImageText=compactImageLayout||env.CLAUDE_RESEARCH_REQUIRE_CLEAN_IMAGE_TEXT==='1';
 const evidenceFile=mediaReset?'reset-media.json':'late-turn.json';
 const project=join(workspace,'project');await mkdir(project);execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),configPath=join(workspace,'.claude/.claude.json'),settingsPath=join(workspace,'.claude/settings.json'),config=JSON.parse(await readFile(configPath));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({theme:'dark',model:'opus'}));const before=await readFile(configPath),settings=await readFile(settingsPath),output=join(workspace,'electron-results');
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,config,settings:JSON.parse(settings)}));
 let delay,profile,model,billing;
 try{
  if(!mediaReset){
   delay=await startNativeTurnCompletionDelay();
   profile=await prepareTurnCompletionProfile({workspace,env:{...env,...account},delay});
  }
  model=await startSyntheticModel(workspace,'TextOnly',{textReply:'The session review is complete.',captureMessages:true,maxRequests:10});const tls=await prepareNativeCreditTls(join(workspace,'account-tls'));billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
  const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  await driveFreshNativeApp({
   checkout,workspace,env:launchEnv,route:mediaReset?'real-Electron-reset-media':'real-Electron-late-turn',
   journeyBudgetMs:150000,journey:args=>journey({...args,checkout,delay,model,mediaReset,requireCleanImageText,compactImageLayout,evidenceFile}),
  });
 }finally{
  await mkdir(output,{recursive:true});await model?.close();await billing?.close();if(model)await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls));if(billing)await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state));
  let remaining;for(let i=0;i<100;i++){remaining=await liveOriginals();if(!remaining.length)break;await new Promise(r=>setTimeout(r,50))}await writeFile(join(output,'writer-retirement.json'),JSON.stringify({retired:remaining.length===0,originalProcessesRemaining:remaining}));assert.equal(remaining.length,0,'Retire original writers before profile restoration');
  let proof;try{proof=JSON.parse(await readFile(join(output,evidenceFile)))}catch(error){if(error.code!=='ENOENT')throw error}
  if(proof?.oldSession){const folder=join(workspace,'.claude/projects'),files=await readdir(folder,{recursive:true});assert.ok(files.length<=4096);for(const id of new Set([proof.oldSession,proof.freshSession].filter(Boolean))){const matches=files.filter(f=>basename(f)===id+'.jsonl');assert.equal(matches.length,1);await writeFile(join(output,'native-'+id+'.jsonl'),await readFile(join(folder,matches[0])))}}
  if(delay){await writeFile(join(output,'completion-delay.json'),JSON.stringify(delay.receipts()));await writeFile(join(output,'completion-delay-cleanup.json'),JSON.stringify(await delay.close()))}
  await profile?.restore();await writeFile(configPath,before);assert.deepEqual(await readFile(configPath),before);assert.deepEqual(await readFile(settingsPath),settings);await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,configSha256:sha(before),settingsSha256:sha(settings)}));
 }
}
async function journey({app,page,electronApp,checkout,workspace,output,userDataDir,project,expect,phase,delay,model,mediaReset,requireCleanImageText,compactImageLayout,evidenceFile}){
 page.setDefaultTimeout(10000);
 const p={status:'running',captures:[],scope:mediaReset
  ?'Retained unsent image across native clear, followed by one explicit fresh submission.'
  :'Original late main-turn completion across genuine clear/session rebinding; no forced queue sever or native setter.'};
 const save=()=>writeFile(join(output,evidenceFile),JSON.stringify(p,null,2));
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,phase:c.phase,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id)}});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 const doc=()=>composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
 const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await expect(composer).toHaveText('');await composer.pressSequentially(text);await expect(composer).toHaveText(text)};
 const capture=async(tag,preview,visibleText)=>{
  for(const[size,bounds]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(bounds);
   await page.evaluate(()=>document.fonts.ready);
   await composer.scrollIntoViewIfNeeded();
   await expect(composer).toBeInViewport({ratio:1});
   await expect(send).toBeInViewport({ratio:1});
   const history=page.getByTestId('chat-transcript').locator(':scope > .overflow-y-auto');
   if(visibleText){
    await expect(visibleText).toHaveText(p.draft);
    if(size==='compact'&&!compactImageLayout){
     // Give the picture and caption room using the same workspace divider a reader can drag.
     const divider=page.locator('.cursor-row-resize:visible').first();
     const box=await divider.boundingBox();
     assert.ok(box);
     await page.mouse.move(box.x+box.width/2,box.y+box.height/2);
     await page.mouse.down();
     await page.mouse.move(box.x+box.width/2,box.y+box.height/2-90,{steps:6});
     await page.mouse.up();
    }
    const bounds=await history.boundingBox();
    assert.ok(bounds&&bounds.height>40);
    await page.mouse.move(bounds.x+bounds.width/2,bounds.y+bounds.height/2);
    // A reader's wheel gesture retires the app's follow-latest work before the capture.
    await page.mouse.wheel(0,-20);
    await expect(page.getByRole('button',{name:'Scroll to latest message',exact:true})).toBeVisible();
    await visibleText.evaluate(element=>element.closest('[data-chat-message]').scrollIntoView({block:'center',behavior:'instant'}));
    await expect(visibleText).toBeInViewport({ratio:0.9});
    await expect(preview).toBeInViewport({ratio:0.9});
    (p.presentation??={})[size]=await visibleText.innerText();
   }else if(preview){
    await preview.scrollIntoViewIfNeeded();
    await expect(preview).toBeInViewport({ratio:1});
   }
   if(compactImageLayout){
    const image=preview??card.getByRole('img',{name:p.imageName,exact:true});
    await expect(image).toBeInViewport({ratio:0.9});
    const body=await (visibleText??composer).boundingBox();
    const picture=await image.boundingBox();
    const clip=await history.boundingBox();
    assert.ok(body&&picture&&clip);
    assert.equal(picture.width,size==='compact'?48:80);
    if(visibleText&&size==='compact')assert.ok(body.x>=picture.x+picture.width+8&&body.y<picture.y+picture.height);
    ((p.imageLayout??={})[tag]??={})[size]={body,picture,historyHeight:clip.height};
   }
   if(compactImageLayout)await page.mouse.move(16,40);
   const name=`${mediaReset?'reset-media':'late-turn'}-${tag}-${size}.png`;
   await page.screenshot({path:join(output,name),animations:'disabled'});
   p.captures.push(name);
  }
  await save();
 };
 let relay,installation;const cancellation=new AbortController();
 const restoreRelay=async()=>{
  if(!relay||p.socketRestoration)return;
  // Retain traffic even if the broker removes its owned directory during shutdown.
  p.traffic=relay.traffic();p.relayErrors=relay.errors();p.delay=delay.receipts();
  await save();
  p.socketRestoration=await relay.close();
  await save();
 };
 try{
  const producer=JSON.parse(await readFile('/control/producer-pack-inputs.json'));for(const file of ['runtime/fe.js','runtime/index.cjs'])assert.equal(sha(await readFile(join(userDataDir,'apack/packs/default-setup',file))),producer[file]);
  await app.waitForSurface('default-setup/threads');await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');await page.waitForTimeout(700);await app.navigate('default-setup/threads');await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return!!c.currentThread?.id&&c.tabs.every(t=>c.tabsRead.includes(t.id))}),{timeout:15000}).toBe(true);await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'})});
  p.seed='Review the current session before changing it.';await replace(p.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);p.oldSession=(await context()).claude.sessionId;
  const existing=new Set(await readdir('/tmp'));let installFailure;
  if(!mediaReset)installation=(async()=>{const end=Date.now()+25000;while(Date.now()<end){cancellation.signal.throwIfAborted();for(const name of await readdir('/tmp')){if(existing.has(name)||!/^cc-app-[A-Za-z0-9_-]+$/.test(name))continue;const directory=join('/tmp',name);try{const config=JSON.parse(await readFile(join(directory,'observer.json')));if(config.sessionId!==p.oldSession)continue;relay=await holdOwnedSessionHandoff({directory,sessionId:p.oldSession,signal:cancellation.signal});return}catch(error){if(error.code!=='ENOENT')throw error}}await new Promise(r=>setTimeout(r,10))}throw Error('Owned bridge unavailable before native attachment')})().catch(error=>{installFailure=error});
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();const seen=new Set();for(let i=0;i<100;i++){if((await context()).native?.state?.status==='live')break;const stage=recognizeOnboardingPrompt(await section.locator('[data-terminal-text]').innerText().catch(()=>''),project);if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100)}await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');if(!mediaReset){await installation;if(installFailure)throw installFailure;assert.ok(relay)}
  p.before=await context();p.pid=p.before.native.state.nativePid;p.processStart=await processStart(p.pid);assert.ok(p.processStart);
  if(mediaReset){
   await resetWithMedia({page,electronApp,workspace,expect,context,doc,replace,card,composer,send,section,model,p,save,capture,requireCleanImageText,compactImageLayout});
   phase('reset-media-complete');
   return;
  }
  const argv=(await readFile('/proc/'+p.pid+'/cmdline')).toString().split('\0'),index=argv.indexOf('--plugin-dir');assert.ok(index>=0);const module=await readFile(join(argv[index+1],'hooks/register.ts')),program=module.toString().slice(module.indexOf(10)+1),expected=(await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/native-plugin/program.generated.ts')).href)).CLAUDE_NATIVE_PLUGIN_PROGRAM;assert.equal(program,expected);p.programSha256=sha(program);
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();delay.arm(p.oldSession);p.nativePrompt='Finish this review before clearing the session.';await replace(p.nativePrompt);await send.click();p.draft='Keep this draft through the session change.';await replace(p.draft);p.document=await doc();await expect.poll(()=>delay.receipts().some(r=>r.held),{timeout:15000}).toBe(true);p.held=delay.receipts().find(r=>r.held);assert.equal(p.held.outcome,undefined);p.beforeClear=await context();await save();
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();const tty=section.locator('[aria-label="Terminal input"]');await electronApp.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0]?.focus());await tty.focus();await page.keyboard.type('/clear');await page.keyboard.press('Enter');
  await expect.poll(async()=>(await context()).native?.state?.sessionId,{timeout:8000}).not.toBe(p.oldSession);p.freshSession=(await context()).native.state.sessionId;assert.ok(p.freshSession);p.sessionModeObservations=delay.receipts().filter(r=>r.route==='/session');assert.equal(delay.receipts().find(r=>r.held).outcome,undefined);p.beforeRelease=await context();assert.equal(p.beforeRelease.native.state.sessionId,p.freshSession);assert.equal(p.beforeRelease.native.state.nativePid,p.pid);assert.equal(await processStart(p.pid),p.processStart);delay.release();await expect.poll(()=>delay.receipts().some(r=>r.phase==='returned'&&r.turnId===p.held.turnId),{timeout:5000}).toBe(true);
  assert.ok(!relay.traffic().some(r=>r.path==='/turn'&&r.sessionId===p.freshSession&&r.turnId===p.held.turnId),'Retired completion published under fresh session');p.afterRelease=await context();
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect.poll(async()=>(await context()).claude?.sessionId,{timeout:15000}).toBe(p.freshSession);assert.deepEqual(await doc(),p.document);await capture('handoff');
  p.freshPrompt='Review only the fresh session after the change.';await replace(p.freshPrompt);await send.click();await expect.poll(()=>relay.traffic().some(r=>r.path==='/turn'&&r.sessionId===p.freshSession&&r.running===false&&r.turnId!==p.held.turnId),{timeout:20000}).toBe(true);await expect.poll(async()=>(await context()).native.state.busy,{timeout:10000}).toBe(false);p.afterFresh=await context();assert.ok(!relay.traffic().some(r=>r.path==='/turn'&&r.sessionId===p.freshSession&&r.turnId===p.held.turnId),'Retired completion arrived before fresh completion');await replace(p.draft);await capture('continued');
  // Stop retires the broker and removes both socket paths. Restore the still-live broker first.
  await restoreRelay();
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processStart(p.pid),{timeout:15000}).not.toBe(p.processStart);const back=section.getByRole('button',{name:'Back to conversation',exact:true});if(await back.isVisible())await back.click();p.followup='Continue after the session handoff verification.';await replace(p.followup);await send.click();await expect.poll(async()=>{const c=await context();return c.claude.chatState==='success'&&c.claude.sessionId===p.freshSession&&c.messages.some(m=>m.sender==='user'&&m.text===p.followup&&m.context?.cliUuid)},{timeout:20000}).toBe(true);await replace('Ready for the next session review.');p.final=await context();await capture('recovered');p.modelRequestCount=model.calls.length;p.status='complete';phase('late-turn-complete');
 }catch(error){p.error={message:error.message,stack:error.stack};p.observed=await context().catch(()=>null);await page.screenshot({path:join(output,mediaReset?'reset-media-failure.png':'late-turn-failure.png')}).catch(()=>{});throw error}finally{
  cancellation.abort();
  try{
   await installation;
   await restoreRelay();
   if(!mediaReset&&p.status==='complete'){
    assert.ok(p.socketRestoration?.restored);
    assert.deepEqual(p.relayErrors,[]);
    assert.ok(!p.traffic.some(r=>r.path==='/turn'&&r.sessionId===p.freshSession&&r.turnId===p.held.turnId));
   }
  }finally{
   if(delay)p.delay=delay.receipts();
   await save();
  }
 }
}

async function resetWithMedia({page,electronApp,workspace,expect,context,doc,replace,card,composer,send,section,model,p,save,capture,requireCleanImageText,compactImageLayout}){
 const image=join(workspace,'native-reset-attachment.png');
 await writeFile(image,createNativeTestImage([50,145,231,255]));
 await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
 p.draft='Review this image in the new session.';
 await replace(p.draft);
 await electronApp.evaluate(async({clipboard,nativeImage,ClipboardItem},file)=>{
  const data=nativeImage.createFromPath(file);
  if(data.isEmpty())throw Error('Owned PNG did not decode');
  await clipboard.write([new ClipboardItem({'image/png':new Blob([Uint8Array.from(data.toPNG())],{type:'image/png'})})]);
 },image);
 await composer.press('Control+v');
 const thumbnail=card.locator('img[src^="data:image/png"]');
 await expect(thumbnail).toHaveCount(1);
 p.image=await thumbnail.getAttribute('src');
 p.imageName=await thumbnail.getAttribute('alt');
 p.nativeText=p.draft+'\n\n[Image: '+p.imageName+'][Image #1]';
 p.document=await doc();
 await capture('before');
 const modelRequests=()=>model.calls.filter(row=>row.path.split('?')[0]==='/v1/messages');
 p.requestsBeforeClear=modelRequests().length;
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 const tty=section.locator('[aria-label="Terminal input"]');
 await electronApp.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0]?.focus());
 await tty.focus();
 await page.keyboard.type('/clear');
 await page.keyboard.press('Enter');
 await expect.poll(async()=>{
  const current=await context(),id=current.native?.state?.sessionId;
  return !!id&&id!==p.oldSession&&current.claude.sessionId===id;
 },{timeout:15000}).toBe(true);
 const cleared=await context();
 p.freshSession=cleared.claude.sessionId;
 assert.equal(cleared.threadId,p.before.threadId);
 assert.equal(cleared.native.state.nativePid,p.pid);
 assert.equal(await processStart(p.pid),p.processStart);
 await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
 await expect(thumbnail).toHaveCount(1);
 assert.equal(await thumbnail.getAttribute('src'),p.image);
 assert.deepEqual(await doc(),p.document);
 p.requestsAfterClear=modelRequests().length;
 assert.equal(p.requestsAfterClear,p.requestsBeforeClear);
 await capture('retained');

 const before=await context(),known=new Set(before.messages.map(message=>message.context?.cliUuid));
 await send.click();
 await expect.poll(async()=>{
  const current=await context();
  return current.claude.sessionId===p.freshSession&&current.native.state.busy===false&&
   current.messages.some(message=>message.sender==='user'&&message.text===p.nativeText&&message.context?.cliUuid&&message.references?.images?.length===1)&&
   current.messages.some(message=>message.sender==='assistant'&&message.text==='The session review is complete.'&&
    message.context?.cliUuid&&!known.has(message.context.cliUuid));
 },{timeout:25000}).toBe(true);
 await expect(thumbnail).toHaveCount(0);
 p.final=await context();
 const modelDelta=modelRequests().slice(p.requestsAfterClear);
 const titlePrompt='<session>\n'+p.nativeText+'\n</session>\n\nWrite the title in the predominant language of the session';
 const isTitle=({toolNames,messages})=>toolNames?.length===0&&messages.length===1&&messages[0].role==='user'&&
  messages[0].content?.length===1&&messages[0].content[0].type==='text'&&messages[0].content[0].text.startsWith(titlePrompt);
 const turnRequests=modelDelta.filter(request=>!isTitle(request));
 p.freshTitleRequests=modelDelta.length-turnRequests.length;
 assert.ok(p.freshTitleRequests<=1);
 assert.equal(turnRequests.length,1);
 const userInput=turnRequests[0].messages.filter(message=>message.role==='user').at(-1)?.content;
 assert.ok(Array.isArray(userInput)&&userInput.some(block=>block.type==='text'&&block.text===p.nativeText));
 const images=userInput.filter(block=>block.type==='image');
 assert.equal(images.length,1);
 assert.deepEqual(images[0].source,{type:'base64',media_type:'image/png',data:p.image.split(',')[1]});
 assert.ok(!JSON.stringify(modelDelta[0].messages).includes(p.seed),'Fresh request retained old model context');
 p.freshRequests=turnRequests.length;
 const submitted=p.final.messages.find(message=>message.sender==='user'&&message.text===p.nativeText);
 assert.deepEqual(submitted.references.images.map(({name})=>name),[p.imageName]);
 const row=page.locator('[data-chat-message="'+submitted.id+'"]');
 const preview=row.getByRole('img',{name:p.imageName,exact:true});
 await expect(preview).toBeVisible();
 const body=row.locator('[data-chat-message-content]');
 if(requireCleanImageText)await expect(body).toHaveText(p.draft);
 p.shownText=await body.innerText();
 await capture('submitted',preview,requireCleanImageText?body:undefined);
 if(compactImageLayout){
  await row.getByRole('button',{name:'Preview '+p.imageName,exact:true}).press('Enter');
  const dialog=page.getByRole('dialog',{name:'Image preview',exact:true});
  await expect(dialog).toBeVisible();
  const full=dialog.locator('img');
  await expect(full).toHaveAttribute('src',submitted.references.images[0].url);
  await expect.poll(async()=>(await full.boundingBox())?.width??0).toBeGreaterThanOrEqual(120);
  p.keyboardPreview={width:(await full.boundingBox()).width,opened:true};
  await page.keyboard.press('Escape');
  await expect(dialog).toHaveCount(0);
  p.keyboardPreview.dismissed=true;
 }
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await section.getByRole('button',{name:'Stop session',exact:true}).click();
 await expect.poll(()=>processStart(p.pid),{timeout:15000}).not.toBe(p.processStart);
 p.status='complete';
 await save();
}
