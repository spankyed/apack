import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {record} from '../protocol/record.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.platform,'darwin');assert.equal(process.env.HOME,workspace);
const targetSha256=hash(await readFile(executable));
const expectedVersion=new Map([['1f04c69e1c24e4d0a716a863af0aad8fc64d49a499334c29701f073700276b99','2.1.301'],['5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37','2.1.302']]).get(targetSha256);
assert.ok(expectedVersion,'Status fixture requires an explicitly pinned release hash');
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(base,'query.ts')).href);
const {createClaudeConversation}=await import(pathToFileURL(join(base,'conversation.ts')).href);
const marker=join(workspace,'status-invocations.jsonl'),helper=join(workspace,'status-fixture.py');
const helperSource=`import json,sys,time\nwith open(${JSON.stringify(marker)},'a') as output:\n    output.write(json.dumps({'input':json.load(sys.stdin),'at':time.time()})+chr(10))\nprint('NativeStatusFixture')\nprint('Second native status line')\n`;
await writeFile(helper,helperSource);
const settings={apiKeyHelper:'/usr/bin/printf research-fixture-key',statusLine:{type:'command',command:`/usr/bin/python3 '${helper.replaceAll("'","'\\''")}'`,refreshInterval:1,padding:0}};
const model=await startSyntheticModel(workspace,'TextOnly');
const env={PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),TERM:'xterm-256color',COLUMNS:'100',LINES:'30',ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
let terminal='',theme=false,security=false,navigated=false,trusted=false,markerSeen=false,exitKeys=0,bound,owner;
const timers=[];
try{
 const bridge=fileURLToPath(new URL('../protocol/pty_bridge.py',import.meta.url));
 const pty=await record({executable:'/usr/bin/python3',cwd:workspace,output:join(workspace,'pty-runs'),timeoutMs:18000,
  args:[bridge,executable,'--setting-sources','','--strict-mcp-config','--tools','','--settings',JSON.stringify(settings)],env,
  onStdout(bytes,transport){
   terminal+=bytes.toString('utf8');const screen=recognizeOnboardingPrompt(terminal,workspace);
   const compact=terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');
   let input;
   if(screen==='theme'&&!theme){theme=true;input='\r'}
   else if(screen==='security-notes'&&theme&&!security){security=true;input='\r'}
   else if(screen==='workspace-trust'&&!navigated){navigated=true;input='\x1b[B'}
   else if(screen==='workspace-trust-selected'&&navigated&&!trusted){trusted=true;input='\r'}
   else if(trusted&&!markerSeen&&compact.includes('NativeStatusFixture')&&compact.includes('Secondnativestatusline')){
    markerSeen=true;timers.push(setTimeout(()=>{exitKeys++;transport.send('\x04')},2200));
   }else if(exitKeys===1&&/pressctrl[+-]dagaintoexit/i.test(compact)){exitKeys++;input='\x04'}
   if(input!==undefined){timers.push(setTimeout(()=>transport.send(input),150));clearTimeout(bound);bound=setTimeout(()=>transport.stop('status-line-step-bound'),5000)}
  }});
 assert.equal(pty.status,'complete');assert.ok(trusted&&markerSeen&&exitKeys>0);
 const before=(await readFile(marker,'utf8')).trim().split('\n').map(line=>JSON.parse(line));
 assert.ok(before.length>=2,'Periodic native status refresh not observed');
 assert.ok(before.every(value=>value.input.cwd===workspace&&value.input.version===expectedVersion&&typeof value.input.session_id==='string'));
 assert.equal(model.calls.length,0);
 const native=await query({cliPath:executable,cwd:workspace,env:{...env,CLAUDE_CODE_SIMPLE:undefined},tools:[],strictMcpConfig:true,settingSources:[],keepStdinOpen:true,replayUserMessages:true,signal:AbortSignal.timeout(15000),settings:JSON.stringify(settings)});
 const events=[];owner=createClaudeConversation(native,async()=>{throw Error('Unexpected autonomous turn')});owner.subscribe(event=>events.push(event));await native.initialized;
 for(let turn=0;turn<2;turn++)await new Promise((resolve,reject)=>{owner.start('Synthetic status observation '+turn,async scoped=>{try{for await(const event of scoped.handle.events){};owner.release(scoped.handle);resolve()}catch(error){reject(error)}})});
 await native.ui.attach({client_id:'status-observer',surface:'desktop'});
 await native.ui.render({client_id:'status-observer',surface:'desktop',component:'AbovePrompt',instance_id:'status-observer',props:{}});
 await new Promise(resolve=>setTimeout(resolve,2200));
 await native.ui.detach('status-observer');await owner.close();
 const after=(await readFile(marker,'utf8')).trim().split('\n').map(line=>JSON.parse(line));
 assert.equal(after.length,before.length,'Streaming unexpectedly executed native status command');
 assert.equal(JSON.stringify(events).includes('NativeStatusFixture'),false);assert.equal(model.calls.length,2);
 await writeFile(join(workspace,'status-payloads.json'),JSON.stringify(before,null,2));
 console.log(JSON.stringify({evidence:'apack-native-status-line',targetSha256,expectedVersion,helperSha256:hash(Buffer.from(helperSource)),ptyRun:pty.directory,ptyInvocations:before.length,ptyMarkerRendered:true,ptyPeriodicRefresh:true,workspaceTrustAccepted:true,samePrivateWorkspaceForStreaming:true,streamHostTurns:2,streamAdditionalStatusInvocations:after.length-before.length,streamUiAttached:true,streamStatusMarkerExported:false,payloadKeys:Object.keys(before[0].input).sort(),payloadModel:before[0].input.model,payloadVersion:before[0].input.version,syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{clearTimeout(bound);for(const timer of timers)clearTimeout(timer);try{if(owner){owner.kill();await owner.close().catch(()=>{})}}finally{await model.close()}}
