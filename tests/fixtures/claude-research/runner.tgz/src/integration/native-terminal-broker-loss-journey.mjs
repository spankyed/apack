import assert from 'node:assert/strict';
import { readFile, readlink } from 'node:fs/promises';
import { join } from 'node:path';

const brokerBinary = '/frozen-broker/apack-terminal';

export async function findOwnedBroker(nativePid) {
  assert.ok(Number.isSafeInteger(nativePid) && nativePid > 1);
  for (let pid = nativePid; pid > 1;) {
    const executable = await readlink('/proc/' + pid + '/exe');
    const raw = await readFile('/proc/' + pid + '/stat', 'utf8');
    const fields = raw.slice(raw.lastIndexOf(')') + 2).split(' ');
    if (executable === brokerBinary) {
      const [, socket] = (await readFile('/proc/' + pid + '/cmdline', 'utf8')).split('\0');
      assert.match(socket, /^\/tmp\/apack-term-[a-f0-9]{12}\/t\.sock$/);
      assert.notEqual(pid, nativePid);
      return { pid, start: fields[19], executable, socket };
    }
    const parent = Number(fields[1]);
    assert.ok(Number.isSafeInteger(parent) && parent > 0 && parent !== pid);
    pid = parent;
  }
  assert.fail('The pinned private broker is not an ancestor of Claude.');
}

export async function driveTerminalBrokerLoss({ page, expect, context, composer, send, section, replace, openNative, proof, output, birth, save, model, phase }) {
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.requireTerminalBrokerLoss && boundary.networkDisabled && boundary.pinnedExecutableReadOnly && boundary.profileTmpfs);
  proof.scope = 'Abrupt loss of the actual apack-terminal broker while composing, and exact same-session recovery.';
  const useNative = section.getByRole('button', { name: 'Use native interface', exact: true });
  const snapshotDraft = () => composer.evaluate(element => {
    const { doc, selection } = element.editor.state;
    return { doc: doc.toJSON(), selection: selection.toJSON() };
  });
  await replace('Keep this release draft through the terminal disconnect.');
  await composer.press('Home');
  await composer.press('Shift+ArrowRight');
  const draft = await snapshotDraft();
  assert.notEqual(draft.selection.anchor, draft.selection.head);
  const prior = await context();
  const requestCount = model.calls.length;
  const broker = await findOwnedBroker(proof.pid);
  proof.brokerLoss = { broker, draft, requestCount };
  assert.deepEqual(await findOwnedBroker(proof.pid), broker);
  assert.equal(await birth(broker.pid), broker.start);
  process.kill(broker.pid, 'SIGKILL');
  await expect.poll(() => birth(broker.pid)).toBe(null);
  await expect.poll(async () => (await context()).native.state.status, { timeout: 15000 }).toBe('error');
  await expect.poll(() => birth(proof.pid), { timeout: 15000 }).toBe(null);
  await expect(section.getByRole('status')).toContainText('disconnected unexpectedly');
  const after = await context();
  assert.equal(after.threadId, prior.threadId);
  assert.equal(after.claude.sessionId, proof.sessionId);
  assert.equal(after.claude.turns, prior.claude.turns);
  assert.equal(after.claude.totalCostUsd, prior.claude.totalCostUsd);
  assert.deepEqual(after.messages, prior.messages);
  assert.deepEqual(await snapshotDraft(), draft);
  assert.equal(model.calls.length, requestCount);
  proof.brokerLoss.retired = true;

  const capture = async label => {
    for (const [name, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
      await page.setViewportSize(viewport);
      await expect(composer).toBeInViewport();
      await expect(send).toBeInViewport({ ratio: 1 });
      if (label === 'disconnected') await expect(useNative).toBeInViewport({ ratio: 1 });
      const filename = 'terminal-broker-' + label + '-' + name + '.png';
      await page.screenshot({ path: join(output, filename), animations: 'disabled' });
      proof.captures.push(filename);
    }
  };

  await capture('disconnected');
  await save();
  await page.setViewportSize({ width: 1100, height: 900 });
  await openNative();
  const resumed = await context();
  const pid = resumed.native.state.nativePid;
  const start = await birth(pid);
  assert.ok(start);
  proof.resumedWriter = { pid, start };
  assert.equal(resumed.threadId, prior.threadId);
  assert.equal(resumed.native.state.sessionId, proof.sessionId);
  assert.notEqual(resumed.native.state.ownerId, prior.native.state.ownerId);
  const freshBroker = await findOwnedBroker(pid);
  assert.equal(freshBroker.socket, broker.socket);
  assert.notDeepEqual(freshBroker, broker);
  proof.brokerLoss.freshBroker = freshBroker;
  await section.getByRole('button', { name: 'Back to conversation', exact: true }).click();
  await expect(composer).toBeEditable();
  assert.deepEqual(await snapshotDraft(), draft);
  const reopenRequests = model.calls.slice(requestCount);
  for (const call of reopenRequests) {
    // The original CLI probes account reachability and quota when a new process attaches.
    const hello = call.path === '/api/hello' && call.messages?.length === 0;
    const quota = call.path === '/v1/messages?beta=true' && call.messages?.length === 1
      && call.messages[0].role === 'user' && call.messages[0].content === 'quota' && !call.toolNames?.length;
    assert.ok(hello || quota, 'Reopen issued a request other than the original hello or quota probe');
  }
  proof.brokerLoss.reopenRequestPaths = reopenRequests.map(call => call.path);

  proof.followup = 'Finish the release review after the terminal recovered.';
  await replace(proof.followup);
  await send.click();
  await expect.poll(async () => {
    const state = await context();
    return state.claude.sessionId === proof.sessionId && state.claude.chatState === 'success'
      && state.native.state.nativePid === pid && !state.native.state.busy
      && state.messages.filter(message => message.sender === 'user' && message.text === proof.followup).length === 1
      && state.messages.filter(message => message.sender === 'assistant').length
        === prior.messages.filter(message => message.sender === 'assistant').length + 1;
  }, { timeout: 15000 }).toBe(true);
  proof.final = await context();
  assert.equal(proof.final.claude.totalCostUsd, proof.final.native.state.session.totalCostUsd);
  await capture('recovered');
  await useNative.click();
  await section.getByRole('button', { name: 'Stop session', exact: true }).click();
  await expect.poll(() => birth(pid), { timeout: 15000 }).toBe(null);
  proof.stopped = true;
  proof.status = 'complete';
  await save();
  phase('terminal-broker-loss-complete');
}
