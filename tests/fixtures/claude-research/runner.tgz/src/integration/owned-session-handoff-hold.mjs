import assert from 'node:assert/strict';
import {createServer,request as httpRequest} from 'node:http';
import {lstat,rename,readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';

/** Delay genuine bridge traffic; never synthesize a native callback, response or session. */
export async function holdOwnedSessionHandoff({directory,sessionId,signal}) {
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.match(directory,/^\/tmp\/cc-app-[A-Za-z0-9_-]+$/);assert.match(sessionId,/^[a-f0-9-]{36}$/);
 signal.throwIfAborted();
 const dir=await lstat(directory);assert.ok(dir.isDirectory()&&!dir.isSymbolicLink()&&dir.uid===1000);
 const socket=join(directory,'bridge.sock'),backend=join(directory,'bridge.research-original.sock');
 const original=await lstat(socket);assert.ok(original.isSocket()&&original.uid===1000);
 const configPath=join(directory,'observer.json'),stat=await lstat(configPath);assert.ok(stat.isFile()&&!stat.isSymbolicLink()&&stat.uid===1000&&stat.size<=65536);
 const config=JSON.parse(await readFile(configPath,'utf8'));assert.equal(config.socketPath,socket);assert.equal(config.sessionId,sessionId);
 await assert.rejects(lstat(backend),{code:'ENOENT'});
 const receipts=[],traffic=[],errors=[],held=new Map(),connections=new Set();let armed=false,closed=false,count=0,closing;
 const fail=error=>{if(errors.length<32)errors.push({at:Date.now(),code:error?.code??error?.name??'error'});};
 const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
 const remember=(kind,body,forward)=>{
  assert.ok(!held.has(kind));const receipt={kind,sessionId:JSON.parse(body).sessionId,heldAt:Date.now(),bodySha256:sha(body)};receipts.push(receipt);
  held.set(kind,()=>{assert.ok(!receipt.releasedAt);receipt.releasedAt=Date.now();held.delete(kind);forward();});return receipt;
 };
 const server=createServer(async(req,res)=>{
  try{
   assert.ok(++count<=2048);assert.equal(req.method,'POST');
   if(!['/poll','/turn','/transcript','/result'].includes(req.url)){
    const outgoing=httpRequest({socketPath:backend,path:req.url,method:req.method,headers:req.headers},reply=>{res.writeHead(reply.statusCode,reply.headers);reply.pipe(res);reply.on('error',()=>res.destroy());});
    outgoing.on('error',error=>{fail(error);res.destroy();});req.on('error',()=>outgoing.destroy());req.pipe(outgoing);return;
   }
   const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;assert.ok(size<=65536);chunks.push(chunk);}
   let heldReceipt;res.once('finish',()=>{if(heldReceipt)heldReceipt.deliveredAt=Date.now();});res.once('close',()=>{if(heldReceipt&&!res.writableFinished)heldReceipt.closedBeforeDelivery=true;});
   const body=Buffer.concat(chunks),value=JSON.parse(body);traffic.push({path:req.url,sessionId:value.sessionId,directOwner:value.directOwner===true,receivedAt:Date.now(),bodySha256:sha(body),...(req.url==='/turn'?{running:value.running}:{}) });
   const forward=()=>{
    const outgoing=httpRequest({socketPath:backend,path:req.url,method:req.method,headers:req.headers},reply=>{
     const chunks=[];let size=0;reply.on('data',chunk=>{size+=chunk.length;if(size>65536){reply.destroy();res.destroy();return;}chunks.push(chunk);});
     reply.on('error',error=>{fail(error);res.destroy();});reply.on('end',()=>{try{
      const response=Buffer.concat(chunks),deliver=()=>{res.writeHead(reply.statusCode,reply.headers);res.end(response);};
      if(armed&&req.url==='/poll'&&value.sessionId===sessionId&&value.directOwner!==true&&!receipts.some(r=>r.kind==='old-poll')){
       // A real command would have effects of its own: this scope holds only an idle response.
       assert.ok(!JSON.parse(response).id);heldReceipt=remember('old-poll',body,deliver);heldReceipt.responseSha256=sha(response);
      }else deliver();
     }catch(error){fail(error);res.destroy();}});
    });outgoing.on('error',error=>{fail(error);res.destroy();});outgoing.end(body);
   };
   if(armed&&req.url==='/turn'&&value.running===true&&value.sessionId!==sessionId&&!receipts.some(r=>r.kind==='new-turn'))heldReceipt=remember('new-turn',body,forward);
   else forward();
  }catch(error){fail(error);res.destroy();}
 });
 server.on('connection',socket=>{connections.add(socket);socket.once('close',()=>connections.delete(socket));if(connections.size>128)socket.destroy();});
 await rename(socket,backend);
 try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(socket,resolve);});}
 catch(error){await rename(backend,socket);throw error;}
 const close=()=>closing??=(async()=>{
  closed=true;armed=false;signal.removeEventListener('abort',abort);
  for(const release of [...held.values()])release();
  const stopped=new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()));
  for(const connection of connections)connection.destroy();await stopped;await rename(backend,socket);
  const restored=await lstat(socket);assert.ok(restored.isSocket()&&restored.dev===original.dev&&restored.ino===original.ino);
  return {restored:true,originalSocketIdentity:{dev:original.dev,ino:original.ino},requests:count};
 })();
 const abort=()=>{void close().catch(fail);};signal.addEventListener('abort',abort,{once:true});
 if(signal.aborted){await close();signal.throwIfAborted();}
 return {arm(){assert.ok(!armed&&!closed);armed=true;},receipts:()=>receipts.map(row=>({...row})),traffic:()=>traffic.map(row=>({...row})),errors:()=>errors.map(row=>({...row})),release(kind){assert.ok(!closed&&held.has(kind));held.get(kind)();},close};
}
