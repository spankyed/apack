import {snapshotOwnedAppProcesses} from './owned-app-process-snapshot.mjs';
import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {once} from 'node:events';
import {existsSync,appendFileSync,createWriteStream} from 'node:fs';
import {mkdir,readFile,writeFile,readdir,readlink,lstat} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {createServer} from 'node:https';
import {prepareNativeCreditTls} from '../protocol/native-credit-billing.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {MANAGED_SECURITY_KEY} from '../protocol/native-managed-security-fixture.mjs';

/** Verify native app-profile setup on real Electron inside the inspected offline Linux boundary. */
export async function driveChildComposer({checkout,workspace,setupWorkspace,env,modelTool='TextOnly',modelRequestLimit=12,modelOptions={textReply:'The release review outline is ready.'},modelFactory,askBeforePlanEntry=false,askBeforeNotebookEdit=false,askBeforeToolPermissions=false,askBeforeGenericPermission=false,showClearContextOnPlanAccept=false,journey=childJourney,journeyName='composer',waitForAppLaunchGate=false}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv'));
 assert.ok(existsSync('/control/offline-verified'));
 assert.ok(!env.NODE_OPTIONS?.includes('linux-electron-launch.mjs'),'Direct launch scopes --no-sandbox to Electron; no global launch patch');
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
 assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
 const executable='/frozen-claude/claude';assert.equal(createHash('sha256').update(await readFile(executable)).digest('hex'),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');
 const userDataDir=join(setupWorkspace,'app-data'),project=join(setupWorkspace,'project'),settingsPath=join(userDataDir,'claude-code-profile/config/settings.json');
 const originalSettings=await readFile(settingsPath);
 assert.equal(typeof askBeforePlanEntry,'boolean');assert.equal(typeof askBeforeNotebookEdit,'boolean');assert.equal(typeof askBeforeToolPermissions,'boolean');assert.equal(typeof askBeforeGenericPermission,'boolean');assert.equal(typeof showClearContextOnPlanAccept,'boolean');
 assert.ok(modelFactory===undefined||typeof modelFactory==='function');
 const model=modelFactory?await modelFactory({workspace,project,maxRequests:modelRequestLimit}):await startSyntheticModel(workspace,modelTool,{...modelOptions,captureMessages:true,maxRequests:modelRequestLimit});
 assert.match(model.url,/^http:\/\/127\.0\.0\.1:\d+$/);assert.ok(Array.isArray(model.calls)&&typeof model.close==='function');
 const tls=await prepareNativeCreditTls(join(workspace,'profile-setup-tls'));
 const requests=[];
 const server=createServer({key:await readFile(tls.key),cert:await readFile(tls.cert)},(req,res)=>{
  req.resume();const path=new URL(req.url,'https://api.anthropic.com').pathname;
  if(requests.length>=200){res.writeHead(429);res.end();return;}
  requests.push({path,method:req.method,foreignKey:!!req.headers['x-api-key']&&req.headers['x-api-key']!==MANAGED_SECURITY_KEY});
  if(req.method==='GET'&&['/api/hello','/v1/oauth/hello'].includes(path)){res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({ok:true}));return;}
  if(req.method==='GET'&&path==='/api/claude_code/settings'){res.writeHead(204);res.end();return;}
  res.writeHead(req.method==='HEAD'&&path==='/api/hello'?200:404,{'content-type':'application/json'});res.end('{}');
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(443,'127.0.0.1',resolve)});server.unref();
 env={...env,ANTHROPIC_API_KEY:MANAGED_SECURITY_KEY,ANTHROPIC_BASE_URL:model.url,NODE_EXTRA_CA_CERTS:tls.ca,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH};
 const output=join(workspace,'electron-results');await mkdir(output,{recursive:true});
 // Preserve a native startup error before the original daemon truncates its stderr.
 // Monitoring leaves the original exception and exit behavior intact.
 assert.equal(env.BUN_OPTIONS,undefined,'No unrelated preload belongs to this isolated fixture');
 const startupTrace=join(workspace,'observe-startup.mjs');
 await writeFile(startupTrace,"import {appendFileSync,statSync} from 'node:fs';const output="+JSON.stringify(join(output,'startup-errors.jsonl'))+";process.on('uncaughtExceptionMonitor',error=>{try{let size=0;try{size=statSync(output).size}catch{}if(size<1048576)appendFileSync(output,JSON.stringify({pid:process.pid,name:error?.name,code:error?.code,message:String(error?.message??error).slice(0,4096),stack:String(error?.stack??'').slice(0,16384)})+'\\n',{mode:0o600});}catch{}});",{mode:0o600});
 env.BUN_OPTIONS='--preload='+startupTrace;

 const phase=(kind,extra={})=>appendFileSync(join(workspace,'direct-electron-events.jsonl'),JSON.stringify({at:Date.now(),kind,...extra})+'\n');
 const require=createRequire(join(checkout,'package.json'));
 phase('loading-playwright');
 const {_electron}=require('@playwright/test');
 phase('loading-app-environment');
 const {appLaunchEnv}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/launch-env.ts')).href);
 const {waitForApplicationWindow}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/application-window.ts')).href);
 const {expect}=require('@playwright/test');
 const JOURNEY_TIMEOUT_MS=120000;
 const compiledDependencyCache={enabled:false};
 let electronApp,appProcess,page,timer,cleanupTimer,log,logBytes=0,quit='not-started',status='failed';
 try {
   // Leave the fresh profile to the app's normal shipped-pack installation.
   const originalConfig=JSON.parse(originalSettings);
   await writeFile(settingsPath,JSON.stringify({...originalConfig,...(showClearContextOnPlanAccept?{showClearContextOnPlanAccept:true}:{}),...(askBeforePlanEntry||askBeforeNotebookEdit||askBeforeToolPermissions||askBeforeGenericPermission?{permissions:{...originalConfig.permissions,ask:[...new Set([...(originalConfig.permissions?.ask??[]),...(askBeforePlanEntry?['EnterPlanMode']:[]),...(askBeforeNotebookEdit?['NotebookEdit']:[]),...(askBeforeToolPermissions?['Skill','WebFetch']:[]),...(askBeforeGenericPermission?['mcp__research__echo']:[])])]}}:{}),apiKeyHelper:'/usr/bin/printf '+MANAGED_SECURITY_KEY}));
   phase('preparing-app-helpers');
   const {resolveAppEnvironment}=await import(pathToFileURL(require.resolve('@apackdev/sdk/env')).href);
   const {appDir}=resolveAppEnvironment({env:'test',userDataDir:userDataDir});
   // Use the published fixture bundle, as repository E2E does; importing its source loads the full host graph.
   const {createAppDriver,waitForAppReady}=await import(pathToFileURL(require.resolve('@apackdev/testing')).href);
   // Share already-prepared dependency bytecode with the real API process; app/source/clock stay unchanged.
   // The controller admits only this run's existing bounded /tmp, never a persistent per-run snapshot.
   if(env.NODE_COMPILE_CACHE){
    assert.equal(env.NODE_COMPILE_CACHE,'/tmp/claude-app-bytecode');
    const {getCompileCacheDir,flushCompileCache}=await import('node:module');
    const directory=getCompileCacheDir();assert.ok(directory?.startsWith(env.NODE_COMPILE_CACHE+'/'));flushCompileCache();
    const files=await readdir(directory),sizes=await Promise.all(files.map(async name=>(await lstat(join(directory,name))).size));
    const bytes=sizes.reduce((sum,value)=>sum+value,0);assert.ok(files.length>0&&bytes<=256*1048576);
    Object.assign(compiledDependencyCache,{enabled:true,directory,files:files.length,bytes,maxBytes:256*1048576,storage:'existing bounded container /tmp'});phase('prepared-dependency-bytecode',compiledDependencyCache);
   }
   if(waitForAppLaunchGate){phase('authored-preparation-complete');process.stdout.write('APACK_RESEARCH_APP_PREPARED\n');while(!existsSync('/control/app-launch-release'))await new Promise(resolve=>setTimeout(resolve,50));}
   const launchStartedAt=Date.now();phase('launch-requested',{launchStartedAt});
   // Let Playwright install its Electron loader; executablePath bypasses that loader.
   assert.equal(require('electron'),createRequire(require.resolve('playwright-core/package.json'))('electron/index.js'));
   electronApp=await _electron.launch({args:['--no-sandbox',checkout],cwd:checkout,env:appLaunchEnv(env,userDataDir),timeout:60000});
   appProcess=electronApp.process();
   appProcess.once('exit',(code,signal)=>phase('app-process-exit',{code,signal}));
   log=createWriteStream(join(output,'app-0.log'));
   const capture=chunk=>{const bytes=Buffer.from(chunk).subarray(0,Math.max(0,4*1048576-logBytes));logBytes+=bytes.length;if(bytes.length)log.write(bytes);};
   appProcess.stdout?.on('data',capture);appProcess.stderr?.on('data',capture);
   phase('process-attached',{pid:appProcess.pid});
   // The app owns its60s API clock. Attachment can precede API startup; a second
   // clock here would shorten that allowance. The enclosing recorder bounds setup.
   let backendReady=false;
   while(!backendReady){
    assert.ok(appProcess.exitCode===null&&appProcess.signalCode===null,'App exited before API readiness: code='+appProcess.exitCode+' signal='+appProcess.signalCode);
    const text=await readFile(join(appDir,'logs/main.jsonl'),'utf8').catch(error=>{if(error.code==='ENOENT')return '';throw error});
    const records=text.split('\n').flatMap(line=>{try{const value=JSON.parse(line);return Date.parse(value.timestamp)>=launchStartedAt&&typeof value.startupId==='string'?[value]:[]}catch{return[]}});
    const startupId=records[0]?.startupId,current=records.filter(record=>record.startupId===startupId);
    assert.ok(!current.some(record=>record.message?.includes('[MAIN] API server failed to start')),'App API startup failed; inspect this startup in the original main log');
    backendReady=current.some(record=>record.message?.includes('[MAIN] API server is running on port '));
    if(!backendReady)await new Promise(resolve=>setTimeout(resolve,200));
   }
   phase('backend-ready');
   // Match the existing standard app fixture's window discovery budget.
   page=await waitForApplicationWindow(electronApp,45000);await page.setViewportSize({width:1400,height:900});
   phase('app-window-ready',{url:page.url()});
   page.setDefaultTimeout(0);
   await waitForAppReady(page);phase('app-connected');
   const app=createAppDriver(page,output);
  await Promise.race([(async()=>{
   phase('shared-ui-journey-started');
   await journey({app,page,electronApp,checkout,output,workspace,project,userDataDir,env,expect,phase,model});
   assert.ok(!requests.some(row=>row.foreignKey),'Only the synthetic credential belongs to this journey');
   await writeFile(join(output,'native-requests.json'),JSON.stringify(requests,null,2));
   status='complete';phase('journey-complete');
  })(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Profile setup journey exceeded its existing app-test allowance')),JOURNEY_TIMEOUT_MS)})]);
 }catch(error){
  phase('journey-failed',{message:error.message});
  if(appProcess)await snapshotOwnedAppProcesses(appProcess.pid,join(output,'failed-processes.json')).catch(failure=>writeFile(join(output,'failed-process-snapshot-error.json'),JSON.stringify({message:failure.message})));
  if(!page&&electronApp)page=electronApp.windows().find(candidate=>!candidate.isClosed());
  if(page&&!page.isClosed()){
   await page.screenshot({path:join(output,'direct-profile-setup-failure.png'),timeout:5000}).catch(()=>{});
   await writeFile(join(output,'direct-profile-setup-failure.txt'),await page.locator('body').innerText({timeout:5000}).catch(()=>''));
   const state=await page.evaluate(()=>{const context=(window).applicationState.system.get('default-setup/code')?.getSnapshot().context;const threads=window.applicationState.system.get('default-setup/threads')?.getSnapshot().context;return {threadState:threads?{mode:threads.mode,phase:threads.phase,threadId:threads.currentThread?.id,claude:threads.currentThread?.context?.claudeCode,native:threads.nativeTerminalViews,ui:threads.nativeUiViews}:null,baseDirectory:context?.baseDirectory,pendingSetup:context?.pendingClaudeProfileSetup,setupError:context?.claudeProfileSetupError,openFiles:context?.openFiles?.map(file=>({path:file.path,isTerminal:file.isTerminal,title:file.terminalInfo?.title})),terminalEvents:(window).__profileTerminalEvents?.slice(-500)};}).catch(()=>null);
   await writeFile(join(output,'profile-setup-failure-state.json'),JSON.stringify(state,null,2));
  }
  throw error;
 }finally{
  clearTimeout(timer);
  if(electronApp){
   try{await Promise.race([(async()=>{await electronApp.close();if(appProcess.exitCode===null&&appProcess.signalCode===null)await once(appProcess,'exit')})(),new Promise((_,reject)=>{cleanupTimer=setTimeout(()=>reject(Error('Owned Electron close did not finish')),30000)})]);quit='normal';}
   catch{quit='forced';if(appProcess.exitCode===null&&appProcess.signalCode===null)appProcess.kill('SIGKILL');}
   finally{clearTimeout(cleanupTimer);}
  }
  await writeFile(join(output,'native-requests.json'),JSON.stringify(requests,null,2));
  await writeFile(join(output,'synthetic-model-calls.json'),JSON.stringify(model.calls,null,2));
  await model.close();await writeFile(settingsPath,originalSettings);
  assert.deepEqual(await readFile(settingsPath),originalSettings);
  server.closeAllConnections();await new Promise(resolve=>server.close(resolve));
  if(log)await new Promise(resolve=>log.end(resolve));
  await writeFile(join(workspace,'direct-electron-proof.json'),JSON.stringify({route:'real-Electron-owned-child-'+journeyName+'-journey',status,quit,rootExitObserved:!!appProcess&&(appProcess.exitCode!==null||appProcess.signalCode!==null),rootExitCode:appProcess?.exitCode??null,rootExitSignal:appProcess?.signalCode??null,pageUrl:page?.url(),testRunnerUsed:false,packPreparation:'app-owned-shipped-pack-refresh',preparationIncludedInJourneyBudget:false,startupIncludedInJourneyBudget:false,journeyBudgetMs:JOURNEY_TIMEOUT_MS,preparationGated:waitForAppLaunchGate,compiledDependencyCache,syntheticModelRequestLimit:modelRequestLimit,startupErrorMonitor:'uncaughtExceptionMonitor only; original exceptions/exits preserved;1MiB bound'},null,2));
  if(status==='complete')assert.equal(quit,'normal','Actual-app shutdown must finish without a forced stop');
 }
}


async function childJourney({app,page,output,workspace,project,userDataDir,env,expect,phase}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');
 // The child is a fresh original process. Keep the production connector untouched and
 // add one separately hashed module to its generated, disposable plugin manifest.
 const key=createHash('sha256').update(JSON.stringify([userDataDir,parentSessionId])).digest('hex');
 const directory=join('/tmp','apack-claude-background-'+process.getuid(),key);
 let pointer=join(directory,'head'),generation;
 for(let depth=0;depth<4096;depth++){
  const info=await lstat(pointer);assert.equal(info.uid,process.getuid());assert.equal(info.mode&0o077,0);
  generation=JSON.parse(await readFile(pointer,'utf8'));const next=join(directory,generation.id+'.next');
  if(!existsSync(next))break;pointer=next;assert.ok(depth<4095);
 }
 const hooks=join(generation.directory,'plugin/hooks'),manifest=join(hooks,'hooks.json');
 const connector=await readFile(join(hooks,'register.ts')),originalManifest=await readFile(manifest),config=JSON.parse(originalManifest);
 const fixture=String.raw`export function register(on){on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const original=await next(e),{Box,Text,Button}=$.ui.resolve(e);return Box({children:[original,Text({children:['Release review']}),Button({key:'review-outline',label:'Use review outline',onPress:async()=>{const before=await $.prompt.read(),filled=await $.prompt.fill({text:'Review the release outline あ🙂',mode:'replace'}),after=await $.prompt.read(),sessionId=await $.session.id();await $.fs.write('review-outline-'+sessionId+'.json',JSON.stringify({sessionId,before,filled,after}));}})]});});}`;
 await writeFile(join(hooks,'desktop-fixture.ts'),fixture,{mode:0o600});
 assert.deepEqual(config.modules,['./register.ts']);
 await writeFile(join(hooks,'desktop-entry.ts'),"import {register as connector} from './register.ts';import {register as fixture} from './desktop-fixture.ts';export function register(on){connector(on);fixture(on);}",{mode:0o600});
 await writeFile(manifest,JSON.stringify({...config,modules:['./desktop-entry.ts']}));
 assert.deepEqual(await readFile(join(hooks,'register.ts')),connector);
 const proof={status:'running',parentSessionId,originalParentPid:initial.native.state.nativePid,fixtureSha256:createHash('sha256').update(fixture).digest('hex'),productionConnectorUnchanged:true,scope:'One owned cold-child app composer; fixture module proves callbacks, not general plugin installation or full parity.',sizes:[]};
 const save=()=>writeFile(join(output,'child-composer.json'),JSON.stringify(proof,null,2));await save();
 try{
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill('/background Continue reviewing the release notes.');await card.getByRole('button',{name:'Send',exact:true}).click();phase('background-command-submitted');
  const widget=page.getByRole('region',{name:'Background Claude session',exact:true});
  await expect(widget.getByRole('button',{name:'Stop background session',exact:true})).toBeEnabled({timeout:25000});
  await widget.getByRole('button',{name:'Refresh status',exact:true}).click();
  await expect.poll(async()=>(await context()).native?.background?.desktop,{timeout:25000}).toBeTruthy();
  proof.running=await context();proof.target=proof.running.native.background.desktop;assert.notEqual(proof.target.sessionId,parentSessionId);await save();phase('child-desktop-ready');
  await composer.fill('Keep the parent review notes here.');const parentDraft=await composer.textContent();
  await widget.getByRole('button',{name:'Reply',exact:true}).click();
  const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');
  await expect(editor).toBeEditable({timeout:15000});
  await editor.fill('Child review draft あ🙂');phase('child-editor-ready');
  await form.getByRole('button',{name:'Session tools',exact:true}).click();
  await expect(form.getByRole('button',{name:'Session tools',exact:true})).toHaveAttribute('aria-expanded','true');
  await form.getByRole('button',{name:'Use review outline',exact:true}).click();
  await expect(editor).toHaveText('Review the release outline あ🙂');phase('native-child-callback-complete');
  const nativeReceipt=join(project,'review-outline-'+proof.target.sessionId+'.json');
  await expect.poll(()=>readFile(nativeReceipt,'utf8').then(JSON.parse).catch(error=>{if(error.code==='ENOENT')return null;throw error;})).toBeTruthy();
  proof.callback=JSON.parse(await readFile(nativeReceipt,'utf8'));assert.equal(proof.callback.sessionId,proof.target.sessionId);assert.equal(proof.callback.before.text,'Child review draft あ🙂');assert.equal(proof.callback.after.text,'Review the release outline あ🙂');
  await expect(composer).toHaveText(parentDraft);await save();
  for(const [name,size]of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(size);
   await expect(editor).toBeInViewport({ratio:1});await expect(form.getByRole('button',{name:'Send message',exact:true})).toBeInViewport({ratio:1});
   await expect(form.getByRole('button',{name:'Use review outline',exact:true})).toBeInViewport({ratio:1});
   const geometry=await form.evaluate(element=>{const r=element.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,viewport:{width:innerWidth,height:innerHeight},scrollWidth:element.scrollWidth,clientWidth:element.clientWidth};});
   assert.ok(geometry.scrollWidth<=geometry.clientWidth);proof.sizes.push({name,...geometry});
   await page.screenshot({path:join(output,'child-composer-'+name+'.png')});await save();
  }
  await form.getByRole('button',{name:'Back to parent notes',exact:true}).click();await expect(form).toHaveCount(0);
  await expect(composer).toBeVisible();await expect(composer).toBeFocused();await expect(composer).toHaveText(parentDraft);proof.parentNotesReturned=true;
  await page.screenshot({path:join(output,'child-parent-notes-return-compact.png')});
  await widget.getByRole('button',{name:'Reply',exact:true}).click();await expect(editor).toHaveText('Review the release outline あ🙂');await expect(editor).toBeEditable();proof.collapseRetainedDraft=true;
  await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(editor).toHaveText('',{timeout:20000});await expect(composer).toHaveText(parentDraft);proof.replyAcknowledged=true;
  let replyReceipt;
  await expect.poll(async()=>{
   const projects=join(userDataDir,'claude-code-profile/config/projects');
   for(const directory of (await readdir(projects,{withFileTypes:true})).slice(0,64)){
    if(!directory.isDirectory())continue;
    const path=join(projects,directory.name,proof.target.sessionId+'.jsonl');let info;
    try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}
    assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);
    const source=await readFile(path,'utf8');assert.ok(Buffer.byteLength(source)<=8*1024*1024);
    const rows=source.split('\n').slice(0,-1).filter(Boolean).map(line=>JSON.parse(line));
    const human=rows.find(row=>row.type==='user'&&row.origin?.kind==='human'&&row.message?.content==='Review the release outline あ🙂');
    if(!human)continue;
    const byId=new Map(rows.map(row=>[row.uuid,row]));
    const follows=row=>{let parent=row.parentUuid;for(let count=0;parent&&count<rows.length;count++){if(parent===human.uuid)return true;parent=byId.get(parent)?.parentUuid}return false};
    const answer=rows.find(row=>row.type==='assistant'&&follows(row)&&Array.isArray(row.message?.content)&&row.message.content.some(block=>block.type==='text'&&block.text==='The release review outline is ready.'));
    if(!answer)continue;
    replyReceipt={transcriptPath:path,sha256:createHash('sha256').update(source).digest('hex'),humanUuid:human.uuid,assistantUuid:answer.uuid,responseMessageId:answer.message.id};
    await writeFile(join(output,'native-child-transcript.jsonl'),source);return true;
   }
   return false;
  },{timeout:20000}).toBe(true);
  proof.nativeReply=replyReceipt;await save();phase('original-child-reply-received');
  await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});await expect(form).toHaveCount(0);const stopped=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(stopped.sessionId,proof.target.sessionId);assert.equal(stopped.state,'stopped');proof.nativeStopped={jobId:proof.target.jobId,sessionId:stopped.sessionId,state:stopped.state,cwd:stopped.cwd};proof.originalStop=true;proof.final=await context();proof.status='complete';await save();phase('child-journey-complete');
 }finally{
  const state=await context().catch(()=>null),sessionId=proof.target?.sessionId??state?.claude?.nativeContinuation?.continuedInSessionId;
  if(sessionId){
   const run=promisify(execFile),cliEnv={...env,CLAUDE_CONFIG_DIR:join(userDataDir,'claude-code-profile/config')};
   const rows=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024})).stdout);
   const owned=rows.find(row=>row.sessionId===sessionId&&row.cwd===project);
   if(owned&&owned.state!=='stopped'){await run('/frozen-claude/claude',['stop',owned.id],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024});proof.cleanupStoppedOwnedJob=true;}
  }
  // Restore only the generated fixture manifest. Do not replace the connector or worker.
  await writeFile(manifest,originalManifest).catch(error=>{if(error.code!=='ENOENT')throw error;});
  await save();
 }
}
