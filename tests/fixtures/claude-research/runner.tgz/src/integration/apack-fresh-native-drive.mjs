import assert from 'node:assert/strict';
import {once} from 'node:events';
import {existsSync,appendFileSync,createWriteStream} from 'node:fs';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';

/** Launch one fresh owned Electron profile; startup, journey and shutdown keep separate clocks. */
export async function driveFreshNativeApp({checkout,workspace,env,journey,journeyBudgetMs,route,preparePage}) {
 assert.equal(typeof journey,'function');assert.match(route,/^real-Electron-[a-z-]+$/);
 const maxJourneyMs=route==='real-Electron-idle-compaction-on-return'?3_820_000
  :route==='real-Electron-idle-compaction-timer'?2_020_000
  :route==='real-Electron-managed-mcp-parked-recovery'?480_000
  :route==='real-Electron-managed-mcp-reconnect-exhaustion'?420_000:180_000;
 assert.ok(Number.isSafeInteger(journeyBudgetMs)&&journeyBudgetMs>0&&journeyBudgetMs<=maxJourneyMs);
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv'));
 assert.ok(existsSync('/control/offline-verified'));
 assert.ok(env.CLAUDE_RESEARCH_PROJECT&&env.CLAUDE_RESEARCH_PROJECT!==workspace,'Billing needs a project separate from app/HOME data');
 assert.ok(!env.NODE_OPTIONS?.includes('linux-electron-launch.mjs'),'Direct launch scopes --no-sandbox to Electron; no global launch patch');
 const output=join(workspace,'electron-results');await mkdir(output,{recursive:true});
 const phase=(kind,extra={})=>appendFileSync(join(workspace,'direct-electron-events.jsonl'),JSON.stringify({at:Date.now(),kind,...extra})+'\n');
 // This diagnostic observes the unchanged app before its first window/debug endpoint.
 const observeStartup=process.env.CLAUDE_RESEARCH_ELECTRON_STARTUP==='1';
 const startupObserver=join(workspace,'electron-startup-observer.cjs');
 if(observeStartup)await writeFile(startupObserver,String.raw`
const fs=require('node:fs'),Module=require('node:module'),{app}=require('electron');
let rows=0;const write=(kind,extra={})=>{if(rows++<2000)fs.appendFileSync(process.env.CLAUDE_RESEARCH_ELECTRON_STARTUP_LOG,JSON.stringify({at:Date.now(),kind,...extra})+'\n')};
write('preload',{pid:process.pid,node:process.versions.node,electron:process.versions.electron});
const original=Module._load;
Module._load=function(request,parent,isMain){const started=performance.now();write('require-start',{request,parent:parent?.filename});try{return Reflect.apply(original,this,arguments)}finally{write('require-end',{request,elapsedMs:performance.now()-started})}};
app.once('will-finish-launching',()=>write('will-finish-launching'));
app.once('ready',()=>{Module._load=original;write('ready')});
setInterval(()=>write('tick',{resources:process.getActiveResourcesInfo()}),5000).unref();
`);
 const require=createRequire(join(checkout,'package.json'));
 phase('loading-playwright');
 const {_electron}=require('@playwright/test');
 phase('loading-app-environment');
 const {appLaunchEnv}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/launch-env.ts')).href);
 const {waitForApplicationWindow}=await import(pathToFileURL(join(checkout,'packages/apack-testing/src/application-window.ts')).href);
 const {expect}=require('@playwright/test');
 let electronApp,appProcess,page,timer,cleanupTimer,log,logBytes=0,quit='not-started',status='failed';
 try {
   // Leave the fresh profile to the app's normal shipped-pack installation.
   phase('preparing-app-helpers');
   const {resolveAppEnvironment}=await import(pathToFileURL(require.resolve('@apackdev/sdk/env')).href);
   const {appDir}=resolveAppEnvironment({env:'test',userDataDir:join(workspace,'app-data')});
   const {createAppDriver,waitForAppReady}=await import(pathToFileURL(require.resolve('@apackdev/testing')).href);
   phase('launch-requested');
   // Let Playwright install its Electron loader; executablePath bypasses that loader.
   assert.equal(require('electron'),createRequire(require.resolve('playwright-core/package.json'))('electron/index.js'));
   electronApp=await _electron.launch({args:['--no-sandbox',...(observeStartup?['-r',startupObserver]:[]),...(env.CLAUDE_RESEARCH_MODULE_READINESS?['-r',new URL('./readiness-bootstrap.cjs',import.meta.url).pathname]:[]),...(env.CLAUDE_RESEARCH_QUESTION_CONVERSION_HOLD?['-r',new URL('./question-conversion-bootstrap.cjs',import.meta.url).pathname]:[]),...(env.CLAUDE_RESEARCH_PRINT_STARTUP_TRACE?['-r',new URL('./print-startup-bootstrap.cjs',import.meta.url).pathname]:[]),...(env.CLAUDE_RESEARCH_UI_PRESS_TRACE?['-r',new URL('./ui-press-bootstrap.cjs',import.meta.url).pathname]:[]),...(env.CLAUDE_RESEARCH_HELPER_TIMING?['-r',new URL('./native-helper-timing-bootstrap.cjs',import.meta.url).pathname]:[]),...(env.CLAUDE_RESEARCH_HELPER_READ_HOLD_DIR?['-r',new URL('./helper-generation-bootstrap.cjs',import.meta.url).pathname]:[]),...(env.CLAUDE_RESEARCH_API_RECOVERY_TRACE_DIR?['-r',new URL('./api-recovery-trace-bootstrap.cjs',import.meta.url).pathname]:[]),checkout],cwd:checkout,env:appLaunchEnv({...env,...(observeStartup?{CLAUDE_RESEARCH_ELECTRON_STARTUP_LOG:join(workspace,'electron-startup.jsonl')}:{})},join(workspace,'app-data')),timeout:60000});
   appProcess=electronApp.process();
   log=createWriteStream(join(output,'app-0.log'));
   const capture=chunk=>{const bytes=Buffer.from(chunk).subarray(0,Math.max(0,4*1048576-logBytes));logBytes+=bytes.length;if(bytes.length)log.write(bytes);};
   appProcess.stdout?.on('data',capture);appProcess.stderr?.on('data',capture);
   phase('process-attached',{pid:appProcess.pid});
   appProcess.once('exit',(code,signal)=>phase('app-process-exit',{code,signal}));
   // The app owns its60s API clock. Attachment can precede API startup; a second
   // clock here would shorten that allowance. The enclosing recorder bounds setup.
   let backendReady=false;
   while(!backendReady){
    assert.ok(appProcess.exitCode===null&&appProcess.signalCode===null,'App exited before API readiness');
    const text=await readFile(join(appDir,'logs/main.jsonl'),'utf8').catch(error=>{if(error.code==='ENOENT')return '';throw error});
    assert.ok(!text.includes('[MAIN] API server failed to start'),'App API startup failed; inspect the original main log');
    backendReady=text.includes('[MAIN] API server is running on port ');
    if(!backendReady)await new Promise(resolve=>setTimeout(resolve,200));
   }
   phase('backend-ready');
   // Match the existing standard app fixture's window discovery budget.
   page=await waitForApplicationWindow(electronApp,45000);await page.setViewportSize({width:1400,height:900});
   phase('app-window-ready',{url:page.url()});
   page.setDefaultTimeout(0);
   await preparePage?.(page);
   const startupRecovery={enabled:env.CLAUDE_RESEARCH_STARTUP_RELOAD_ONCE==='1',attempts:0,status:'not-needed'};
   try{await waitForAppReady(page)}catch(error){
    const text=await page.locator('body').innerText({timeout:5000}).catch(()=>'');
    if(!startupRecovery.enabled||!text.includes('Unable to connect')||!text.includes('The backend did not respond within 30 seconds'))throw error;
    await page.screenshot({path:join(output,'startup-connection-failure.png'),timeout:5000});
    startupRecovery.originalError=text;startupRecovery.attempts=1;startupRecovery.status='requested';
    await writeFile(join(output,'startup-recovery.json'),JSON.stringify(startupRecovery,null,2));phase('startup-ui-reload-requested');
    await page.getByRole('button',{name:'Reload',exact:true}).click();await waitForAppReady(page);
    startupRecovery.status='completed';phase('startup-ui-reload-completed');
   }
   await writeFile(join(output,'startup-recovery.json'),JSON.stringify(startupRecovery,null,2));phase('app-connected');
   if(env.CLAUDE_RESEARCH_HELPER_TIMING){const files=await readdir(env.CLAUDE_RESEARCH_HELPER_TIMING),rows=await Promise.all(files.filter(n=>/^observer-ready-[0-9]+\.json$/.test(n)).map(n=>readFile(join(env.CLAUDE_RESEARCH_HELPER_TIMING,n),'utf8').then(JSON.parse)));assert.ok(rows.some(row=>row.apiProcess===true),'API helper timing observer must be ready before the diagnostic journey');phase('helper-timing-ready');}
   const app=createAppDriver(page,output);
  await Promise.race([(async()=>{
   phase('shared-ui-journey-started');
   await journey({app,page,electronApp,output,workspace,project:env.CLAUDE_RESEARCH_PROJECT,userDataDir:join(workspace,'app-data'),expect,phase});
   status='complete';phase('journey-complete');
  })(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Desktop journey exceeded its bounded interactive and recovery allowances')),journeyBudgetMs)})]);
 }catch(error){
  phase('journey-failed',{message:error.message});
  if(!page&&electronApp)page=electronApp.windows().find(candidate=>!candidate.isClosed());
  if(page&&!page.isClosed()){
   await page.screenshot({path:join(output,'direct-agent-billing-failure.png'),timeout:5000}).catch(()=>{});
   await writeFile(join(output,'direct-agent-billing-failure.txt'),await page.locator('body').innerText({timeout:5000}).catch(()=>''));
  }
  throw error;
 }finally{
  clearTimeout(timer);
  if(electronApp){
   try{await Promise.race([(async()=>{await electronApp.close();if(appProcess.exitCode===null&&appProcess.signalCode===null)await once(appProcess,'exit')})(),new Promise((_,reject)=>{cleanupTimer=setTimeout(()=>reject(Error('Owned Electron close did not finish')),30000)})]);quit='normal';}
   catch{quit='forced';if(appProcess.exitCode===null&&appProcess.signalCode===null)appProcess.kill('SIGKILL');}
   finally{clearTimeout(cleanupTimer);}
  }
  if(log)await new Promise(resolve=>log.end(resolve));
  await writeFile(join(workspace,'direct-electron-proof.json'),JSON.stringify({route,status,quit,rootExitObserved:!!appProcess&&(appProcess.exitCode!==null||appProcess.signalCode!==null),rootExitCode:appProcess?.exitCode??null,rootExitSignal:appProcess?.signalCode??null,pageUrl:page?.url(),testRunnerUsed:false,packPreparation:'app-first-boot',preparationIncludedInJourneyBudget:false,startupIncludedInJourneyBudget:false,journeyBudgetMs:journeyBudgetMs},null,2));
  if(status==='complete')assert.equal(quit,'normal','Actual-app shutdown must finish without a forced stop');
 }
}
