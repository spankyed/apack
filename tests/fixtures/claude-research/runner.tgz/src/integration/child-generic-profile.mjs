import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,writeFile,lstat,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';

/** Install only a disposable stdio server in the existing owned synthetic profile. */
export async function prepareChildGenericProfile({setupWorkspace,workspace}) {
 assert.equal(process.platform,'linux');assert.ok(existsSync('/.dockerenv'));assert.ok(existsSync('/control/offline-verified'));
 assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');assert.match(workspace,/^\/work\/\.claude-research\/child-generic-app[0-9]+$/);
 const configPath=join(setupWorkspace,'app-data/claude-code-profile/config/.claude.json'),info=await lstat(configPath);
 assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1024*1024);
 const localPath=join(setupWorkspace,'project/.claude/settings.local.json');
 let originalLocal;try{const stat=await lstat(localPath);assert.ok(stat.isFile()&&stat.uid===process.getuid()&&stat.size<=1024*1024);originalLocal=await readFile(localPath);}catch(error){if(error.code!=='ENOENT')throw error;}
 const original=await readFile(configPath);assert.ok(original.length<=1024*1024);const config=JSON.parse(original);
 assert.ok(!Object.hasOwn(config.mcpServers??{},'research'),'Do not replace another MCP owner');
 const children=join(workspace,'mcp-children.jsonl'),exits=join(workspace,'mcp-exits.jsonl'),receipts=join(workspace,'mcp-receipts.jsonl'),bootstrap=join(workspace,'mcp-bootstrap.mjs');
 await writeFile(join(workspace,'profile-config-before.json'),original,{mode:0o600,flag:'wx'});
 const source=`import {appendFileSync,readFileSync} from 'node:fs';
const start=readFileSync('/proc/self/stat','utf8').slice(readFileSync('/proc/self/stat','utf8').lastIndexOf(')')+2).split(' ')[19];
const parentStat=readFileSync('/proc/'+process.ppid+'/stat','utf8'),parentStart=parentStat.slice(parentStat.lastIndexOf(')')+2).split(' ')[19];
appendFileSync(${JSON.stringify(children)},JSON.stringify({pid:process.pid,ppid:process.ppid,start,parentStart})+'\\n',{mode:0o600});
process.once('exit',code=>appendFileSync(${JSON.stringify(exits)},JSON.stringify({pid:process.pid,start,code})+'\\n',{mode:0o600}));
process.once('SIGTERM',()=>process.exit(0));
await import(${JSON.stringify(new URL('../protocol/synthetic-generic-permission-server.mjs',import.meta.url).href)});`;
 await writeFile(bootstrap,source,{mode:0o600,flag:'wx'});
 await writeFile(configPath,JSON.stringify({...config,mcpServers:{...config.mcpServers,research:{type:'stdio',command:process.execPath,args:[bootstrap],env:{APACK_MCP_RECEIPT:receipts}}}}));
 let restored=false;
 return {children,exits,receipts,bootstrap,originalConfigSha256:createHash('sha256').update(original).digest('hex'),async restore(){if(restored)return;let finalLocal;try{const stat=await lstat(localPath);assert.ok(stat.isFile()&&stat.uid===process.getuid()&&stat.size<=1024*1024);finalLocal=await readFile(localPath);await writeFile(join(workspace,'native-local-settings-after.json'),finalLocal);}catch(error){if(error.code!=='ENOENT')throw error;}await writeFile(configPath,original);assert.deepEqual(await readFile(configPath),original);if(originalLocal!==undefined){await writeFile(localPath,originalLocal);assert.deepEqual(await readFile(localPath),originalLocal);}else if(finalLocal!==undefined)await rm(localPath);restored=true;}};
}

/** Wait for owned MCP processes and their original native writers before restoring profile bytes. */
export async function observeChildGenericShutdown(profile) {
 const bounded=async path=>{const info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1024*1024);return(await readFile(path,'utf8')).trim().split('\n').filter(Boolean).map(line=>JSON.parse(line));};
 const children=await bounded(profile.children).catch(error=>{if(error.code==='ENOENT')return[];throw error});
 const inspect=async(pid,start)=>{assert.ok(Number.isSafeInteger(pid)&&pid>1&&typeof start==='string'&&/^[0-9]+$/.test(start));try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return {pid,start,alive:fields[19]===start&&fields[0]!=='Z'};}catch(error){if(error.code==='ENOENT'||error.code==='ESRCH')return {pid,start,alive:false};throw error;}};
 let observed=[];
 for(let attempt=0;attempt<50;attempt++){
  observed=await Promise.all(children.flatMap(child=>[inspect(child.pid,child.start),inspect(child.ppid,child.parentStart)]));
  if(observed.every(row=>!row.alive))break;
  await new Promise(resolve=>setTimeout(resolve,100));
 }
 const exits=await bounded(profile.exits).catch(error=>{if(error.code==='ENOENT')return[];throw error});
 return {children,exits,observed,passed:observed.every(row=>!row.alive)};
}
