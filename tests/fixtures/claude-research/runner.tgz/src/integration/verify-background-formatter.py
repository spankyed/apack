"""Verify saved actual-app configured child formatter updates and retained everyday behavior."""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import subprocess
import sys

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence',type=Path)
parser.add_argument('product_checkout',type=Path)
parser.add_argument('--commit',required=True)
parser.add_argument('--research-commit',required=True)
mode=parser.add_mutually_exclusive_group()
mode.add_argument('--formatter-lifecycle',action='store_true')
mode.add_argument('--formatter-policy',action='store_true')
args=parser.parse_args()
subprocess.run([sys.executable,str(Path(__file__).with_name('verify-background-status.py')),str(args.evidence),str(args.product_checkout),'--commit',args.commit,'--research-commit',args.research_commit,'--capture-profile','formatter-policy' if args.formatter_policy else 'formatter-lifecycle' if args.formatter_lifecycle else 'owner-loss-layout'],check=True,stdout=subprocess.DEVNULL)
evidence=args.evidence.resolve()
load=lambda path:json.loads(path.read_text())
paths=list((evidence/'records/workspaces').glob('*/native-background-app-observation.json'))
assert len(paths)==1
workspace=paths[0].parent
assert load(workspace/'native-terminal-app-evidence.json')['nativeBackgroundFormatter'] is True
state=load(paths[0]);formatter=state['childFormatter'];child=state['job'];loss=state['parentOwnerLoss']
assert formatter['parentStopped'] and formatter['retiredAfterStop']
assert formatter['info']['statusLine'] != formatter['afterReturn']['statusLine'], 'Must observe new native output, not just retain an earlier string'
receipts=[json.loads(line) for line in (workspace/'background-formatter-helper.jsonl').read_text().splitlines() if line]
normalize=lambda text:'\n'.join(line.strip() for line in text.strip().split('\n') if line.strip())
matched=[]
for field in ['info','afterReturn']:
    info=formatter[field]
    assert info['sessionId']==child['sessionId'] and info['pid']==child['pid'] and info['jobId']==child['id']
    assert info['observedAt']>loss['closedAt']
    rows=[row for row in receipts if row['sessionId']==child['sessionId'] and row['at']>loss['closedAt'] and normalize(row['stdout'])==info['statusLine']]
    assert rows, 'Visible status must match original helper stdout produced after parent Stop'
    matched.append(min(rows,key=lambda row:row['at']))
assert matched[1]['at']>matched[0]['at']
lifecycle=None
if args.formatter_lifecycle:
    lifecycle=state['childFormatterLifecycle']
    assert load(workspace/'native-terminal-app-evidence.json')['nativeBackgroundFormatterLifecycle'] is True
    assert lifecycle['before']['input']['formatter']['command']
    assert lifecycle['withdrawal']['input']['formatter']['command'] is None
    assert lifecycle['withdrawal']['reply']['shellPrefix']==lifecycle['before']['input']['formatter']['shellPrefix'], 'Withdrawal must restore the original user prefix'
    assert lifecycle['withdrawal']['reply']['originalPrefix']==lifecycle['before']['input']['formatter']['shellPrefix']
    assert lifecycle['replacement']['input']['formatter']['command']!=lifecycle['before']['input']['formatter']['command']
    assert 'AppNativeRestored '+child['sessionId'] in lifecycle['after']['statusLine']
    assert lifecycle['after']['sessionId']==child['sessionId'] and lifecycle['after']['pid']==child['pid']
    assert lifecycle['parent']['messages']==lifecycle['afterParent']['messages']
    assert lifecycle['parent']['claude']['totalCostUsd']==lifecycle['afterParent']['claude']['totalCostUsd']
    original=lifecycle['originalPost'];assert original['status']==200
    for field in ['lateWithdrawn','lateRestored']:
        assert lifecycle[field]['status']==409
    late=[row for row in lifecycle['brokerRows']if row['path']=='/background-formatter' and row['status']==409 and row.get('input',{}).get('generation')==original['input']['generation']]
    assert len(late)==2
    for row in late:
        for field in ['sessionId','pid','token','generation','stdout']:
            assert row['input'][field]==original['input'][field]
        assert int(row['input']['startedAt'])>int(original['input']['startedAt'])
    assert lifecycle['lateWithdrawn']['at']>=lifecycle['withdrawal']['at']
    assert lifecycle['lateRestored']['at']>=lifecycle['replacement']['at']
    decode=lambda prefix:json.loads(base64.urlsafe_b64decode(prefix.rsplit(' -',1)[1]+'==='))
    old_config=decode(lifecycle['before']['reply']['shellPrefix'])
    new_config=decode(lifecycle['replacement']['reply']['shellPrefix'])
    assert old_config['token']==new_config['token']==original['input']['token']
    assert old_config['generation']==original['input']['generation']!=new_config['generation']
    assert any(row['sessionId']==child['sessionId'] and row['at']>=lifecycle['replacement']['at'] and normalize(row['stdout'])==lifecycle['after']['statusLine'] for row in receipts), 'Replacement status must match fresh original helper stdout'

policy_proof=None
if args.formatter_policy:
    policy=state['childFormatterPolicy']
    assert load(workspace/'native-terminal-app-evidence.json')['nativeBackgroundFormatterPolicy'] is True
    assert policy['ready']['profile']=='background-formatter'
    restricted,restored=policy['receipts']
    for receipt,sequence,name,content in [(restricted,1,'restricted',{'disableAllHooks':True}),(restored,2,'restored',{})]:
        assert receipt['sequence']==sequence and receipt['mode']==name
        assert receipt['path']=='/etc/claude-code/managed-settings.json' and receipt['uid']==0 and receipt['fileMode']==0o644
        assert receipt['sha256']==hashlib.sha256((json.dumps(content)+'\n').encode()).hexdigest()
    root_restored=load(evidence/'records/policy-control/restored.json')
    assert root_restored['sha256']==policy['ready']['initialSha256']
    assert root_restored['path']=='/etc/claude-code/managed-settings.json'
    assert restricted['at']*1000>policy['held']['at']
    assert policy['restriction']['clearedAt']>restricted['at']*1000
    assert policy.get('suppressed') is None or policy['suppressed'].get('statusLine') is None
    before,after=policy['helperBefore'],policy.get('helperAfter')
    assert before['pid']==policy['held']['pid'] and before['ppid']==policy['held']['parentPid'] and before['state']!='Z'
    finished=policy.get('finished')
    if finished:
        assert finished['sessionId']==child['sessionId'] and finished['marker']=='STALE_BACKGROUND_POLICY_HELPER'
        outcome='delayed-helper-finished'
    else:
        assert after is None or after['state']=='Z' or after['start']!=before['start']
        assert policy['lateRestricted']['at']-policy['held']['at']<12000, 'Cancellation must precede the fixture watchdog'
        outcome='original-helper-retired-before-watchdog'
    assert policy['restoration']['at']>restored['at']*1000
    assert policy['restoration']['input']['token']!=policy['before']['input']['token']
    assert policy['after']['sessionId']==child['sessionId'] and policy['after']['pid']==child['pid']
    assert policy['after']['observedAt']>restored['at']*1000
    assert 'AppNativeMain '+child['sessionId'] in policy['after']['statusLine']
    assert any(row['sessionId']==child['sessionId'] and row['at']>restored['at']*1000 and normalize(row['stdout'])==policy['after']['statusLine'] for row in receipts)
    assert policy['parent']['messages']==policy['afterParent']['messages']
    assert policy['parent']['claude']['totalCostUsd']==policy['afterParent']['claude']['totalCostUsd']
    original=policy['originalPost'];assert original['status']==200
    stale=[row for row in policy['brokerRows'] if row['path']=='/background-formatter' and row['status']==409 and row.get('input',{}).get('generation')==original['input']['generation']]
    assert len(stale)==2
    for row in stale:
        for field in ['sessionId','pid','token','generation','stdout']:
            assert row['input'][field]==original['input'][field]
        assert int(row['input']['startedAt'])>int(original['input']['startedAt'])
    assert policy['lateRestricted']['status']==policy['lateRestored']['status']==409
    assert stale[0]['at']>=policy['restriction']['clearedAt'] and stale[1]['at']>restored['at']*1000
    assert not any('STALE_BACKGROUND_POLICY_HELPER' in row.get('input',{}).get('stdout','') for row in policy['brokerRows'] if row['path']=='/background-formatter' and row['status']==200)
    policy_proof={'realLinuxManagedFileTransitions':True,'privateObserverStatusRetired':True,'heldHelperOutcome':outcome,'sameWorkerFreshLeaseAndFormatterRestored':True,'capturedOldResultRefused':2,'exactPolicyBytesRestored':True,'scope':'Linux real-path disableAllHooks/restoration after parent Stop; actual held-helper retirement and separate captured stale-post refusal. No successful late-helper stdout, installed macOS MDM, full restart or combined F1–F5 acceptance.'}
previous=load(evidence/'background-status-verification.json')
proof={**previous,'configuredChildFormatter':{'freshAfterParentStop':True,'freshAfterSecondReplyAndSettingsReturn':True,'originalStdoutMatchesNativeNormalization':True,'retiredAfterChildStop':True,'matchedHelperReceipts':matched,'observations':{name:formatter[name] for name in ['info','afterReturn']}},
 'scope':'Scoped actual-app configured child root statusLine after parent Stop, fresh replies and Settings return; normal/compact retained short notes and controls. User-prefix composition and observed policy/helper/worker retirement have focused checks. No native existing-prefix/policy-transition, full broker/app restart, custom subagent formatter, drawing/actions or original combined F1–F5 acceptance.'}
if lifecycle:
    proof['formatterLifecycle']={'nativeWithdrawalObserved':True,'nativeReplacementObserved':True,'lateCapturedOutputRefused':2,'workerAndParentHistoryPreserved':True,'scope':'Native user-helper withdrawal/replacement and stale captured-post refusal only; no managed OS policy, live-held helper cancellation or broader restart claim.'}
if policy_proof:
    proof['formatterPolicy']=policy_proof
    proof['scope']=policy_proof['scope']
(evidence/'background-formatter-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'status':'passed','runtimeCommit':proof.get('runtimeCommit'),'configuredChildFormatter':proof['configuredChildFormatter'],'scope':proof['scope']},indent=2))
