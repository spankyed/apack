"""Verify saved actual-app configured child formatter updates and retained everyday behavior."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence',type=Path)
parser.add_argument('product_checkout',type=Path)
parser.add_argument('--commit',required=True)
parser.add_argument('--research-commit',required=True)
args=parser.parse_args()
subprocess.run([sys.executable,str(Path(__file__).with_name('verify-background-status.py')),str(args.evidence),str(args.product_checkout),'--commit',args.commit,'--research-commit',args.research_commit,'--capture-profile','owner-loss-layout'],check=True,stdout=subprocess.DEVNULL)
evidence=args.evidence.resolve()
load=lambda path:json.loads(path.read_text())
paths=list((evidence/'records/workspaces').glob('*/native-background-app-observation.json'))
assert len(paths)==1
workspace=paths[0].parent
assert load(workspace/'native-terminal-app-evidence.json')['nativeBackgroundFormatter'] is True
state=load(paths[0]);formatter=state['childFormatter'];child=state['job'];loss=state['parentOwnerLoss']
assert formatter['parentStopped'] and formatter['retiredAfterStop']
assert formatter['info']['statusLine'] != formatter['afterReturn']['statusLine'], 'Must observe new native output, not just retain an earlier string'
receipts=[json.loads(line) for line in (workspace/'background-formatter-helper.jsonl').read_text().splitlines() if line]
normalize=lambda text:'\n'.join(line.strip() for line in text.strip().split('\n') if line.strip())
matched=[]
for field in ['info','afterReturn']:
    info=formatter[field]
    assert info['sessionId']==child['sessionId'] and info['pid']==child['pid'] and info['jobId']==child['id']
    assert info['observedAt']>loss['closedAt']
    rows=[row for row in receipts if row['sessionId']==child['sessionId'] and row['at']>loss['closedAt'] and normalize(row['stdout'])==info['statusLine']]
    assert rows, 'Visible status must match original helper stdout produced after parent Stop'
    matched.append(min(rows,key=lambda row:row['at']))
assert matched[1]['at']>matched[0]['at']
previous=load(evidence/'background-status-verification.json')
proof={**previous,'configuredChildFormatter':{'freshAfterParentStop':True,'freshAfterSecondReplyAndSettingsReturn':True,'originalStdoutMatchesNativeNormalization':True,'retiredAfterChildStop':True,'matchedHelperReceipts':matched,'observations':{name:formatter[name] for name in ['info','afterReturn']}},
 'scope':'Scoped actual-app configured child root statusLine after parent Stop, fresh replies and Settings return; normal/compact retained short notes and controls. User-prefix composition and observed policy/helper/worker retirement have focused checks. No native existing-prefix/policy-transition, full broker/app restart, custom subagent formatter, drawing/actions or original combined F1–F5 acceptance.'}
(evidence/'background-formatter-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'status':'passed','runtimeCommit':proof.get('runtimeCommit'),'configuredChildFormatter':proof['configuredChildFormatter'],'scope':proof['scope']},indent=2))
