/** Passive, bounded summaries of the owned API's existing native snapshot replies. */
import fs from 'node:fs';
import http from 'node:http';
import {syncBuiltinESMExports} from 'node:module';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
const directory=process.env.CLAUDE_RESEARCH_API_RECOVERY_TRACE_DIR;
if(directory&&!process.versions.bun&&process.cwd()==='/work/packages/api'&&process.argv.some(arg=>arg==='dist/server.js'||arg.endsWith('/dist/server.js'))){
 if(process.platform!=='linux'||process.getuid()!==1000||!/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+\/api-recovery-trace$/.test(directory))throw Error('Unowned API trace directory');
 const info=fs.lstatSync(directory);if(!info.isDirectory()||info.uid!==process.getuid()||(info.mode&0o077))throw Error('API trace directory is not private');
 const sha=value=>typeof value==='string'?createHash('sha256').update(value).digest('hex'):null;
 let records=0,next=0;const record=value=>{if(records++>=1024)return;try{fs.appendFileSync(join(directory,'events.jsonl'),JSON.stringify({pid:process.pid,at:Date.now(),...value})+'\n',{mode:0o600});}catch{}};
 record({event:'installed',apiProcess:true});
 const emit=http.Server.prototype.emit;
 http.Server.prototype.emit=function(...args){
  const [event,request,response]=args;
  if(event==='request'&&['/background-status','/background-register'].includes(request?.url)){
   const id=++next,iterator=request[Symbol.asyncIterator];
   request[Symbol.asyncIterator]=async function*(){let size=0,chunks=[];for await(const chunk of Reflect.apply(iterator,this,[])){size+=chunk.length;if(size<=262144)chunks.push(Buffer.from(chunk));yield chunk;}try{if(size<=262144){const value=JSON.parse(Buffer.concat(chunks).toString());record({event:'report',id,route:request.url,sequence:value.sequence,sessionId:value.sessionId,workerPid:value.pid,command:sha(value.formatter?.command),commandPresent:typeof value.formatter?.command==='string',policy:value.helpers?.policyKey,cost:value.usage?.cost?.usd});}}catch{}};
   const end=response.end;response.end=function(...values){record({event:'report-reply',id,route:request.url,statusCode:response.statusCode});return Reflect.apply(end,this,values);};
  }
  return Reflect.apply(emit,this,args);
 };
 const write=fs.writeFileSync;
 fs.writeFileSync=function(path,bytes,...args){
  const result=Reflect.apply(write,this,[path,bytes,...args]);
  if(typeof path==='string'&&/^\/tmp\/cc-child-[A-Za-z0-9]+\/workers\/w-[0-9]+-[A-Za-z0-9]+\/observer\.json(?:\.[a-f0-9-]+)?$/.test(path))try{const value=JSON.parse(String(bytes));record({event:'config-write',epoch:sha(value.transportEpoch),generation:sha(value.generations?.main),claimed:value.mainObservationClaimed});}catch{}
  return result;
 };
 const original=http.request;
 http.request=function(...args){
  const request=Reflect.apply(original,this,args),options=args[0];
  if(options?.path!=='/control'||typeof options.socketPath!=='string'||!/^\/tmp\/cc-child-[A-Za-z0-9]+\/workers\/w-[0-9]+-[A-Za-z0-9]+\/ui\.sock$/.test(options.socketPath))return request;
  let summary;const end=request.end;
  request.end=function(...values){try{const text=String(values[0]);if(Buffer.byteLength(text)<=1048576){const body=JSON.parse(text);if(body.request?.subtype==='apack_owner_snapshot')summary={id:++next,sequence:body.sequence,epoch:sha(body.transportEpoch),observe:body.request.include_main_status_observation===true,cache:body.request.include_main_status_cache===true};}}catch{}return Reflect.apply(end,this,values);};
  request.once('response',response=>{if(!summary)return;let bytes=0,chunks=[];response.on('data',chunk=>{bytes+=chunk.length;if(bytes<=2*1048576)chunks.push(Buffer.from(chunk));});response.once('end',()=>{try{if(bytes>2*1048576){record({...summary,event:'over-bound'});return;}const body=JSON.parse(Buffer.concat(chunks).toString()),value=body.result,observation=value?.mainStatusObservation,receipt=observation?.receipt;
   const policy=value?.policy?JSON.stringify([value.policy.allowManagedHooksOnly,value.policy.disableAllHooks,value.hooksDisabled]):undefined;
   const normalized=text=>typeof text==='string'?text.trim().split('\n').flatMap(line=>line.trim()||[]).join('\n'):null;
   record({...summary,event:'reply',statusCode:response.statusCode,error:typeof body.error==='string'?body.error.slice(0,160):undefined,sessionId:value?.sessionId,command:sha(value?.statusCommand),policy,pending:observation?.pending,receiptPresent:!!receipt,receipt:receipt?{kind:receipt.kind,sessionId:receipt.sessionId,parentPid:receipt.parentPid,generation:sha(receipt.generation),command:sha(receipt.command),commandMatches:receipt.command===value?.statusCommand,policyMatches:receipt.policyKey===policy,cost:receipt.totalCostUsd,code:receipt.code,signal:receipt.signal,truncated:receipt.truncated,text:sha(normalized(receipt.stdout))}:null,cachedText:sha(normalized(value?.cachedMainStatus)),cacheMatches:receipt?normalized(receipt.stdout)===normalized(value?.cachedMainStatus):null});
  }catch(error){record({...summary,event:'decode-error',error:error.name});}});});
  request.once('error',error=>{if(summary)record({...summary,event:'request-error',error:error.code??error.name});});return request;
 };
 syncBuiltinESMExports();
}
