#!/usr/bin/env python3
"""Independently verify the scoped real-app API recovery evidence; never execute a target."""
import argparse, hashlib, json, subprocess, tarfile
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('evidence',type=Path)
p.add_argument('--product',required=True,type=Path)
p.add_argument('--product-commit',required=True)
p.add_argument('--research',required=True,type=Path)
p.add_argument('--research-commit',required=True)
a=p.parse_args();root=a.evidence;records=root/'records'
def read(path):return json.loads(path.read_text())
def one(name):
 rows=list(records.rglob(name));assert len(rows)==1,(name,len(rows));return rows[0]
def sha(blob):return hashlib.sha256(blob).hexdigest()
def committed(repo,rev,path):
 rev=subprocess.check_output(['git','rev-parse','--verify','--end-of-options',rev+'^{commit}'],cwd=repo,text=True).strip()
 manifest=read(path)
 for name,digest in manifest.items():
  assert sha(subprocess.check_output(['git','show',rev+':'+name],cwd=repo))==digest,name
 return len(manifest)
def retired(after,before):return after['state']in{'gone','Z'}or isinstance(after.get('start'),str)and after['start']!=before['start']
product=committed(a.product,a.product_commit,root/'source-inputs.json')
research=committed(a.research,a.research_commit,root/'authored-inputs.json')
before=read(root/'compiled-before.json');assert before==read(root/'compiled-after.json');assert len(before['files'])>300
boundary=read(root/'offline-boundary.json');assert boundary['networkDisabled']and boundary['pinnedExecutableReadOnly'];assert set(boundary['networks'])=={'none'}
assert boundary['memory']==boundary['memorySwap']==6*1024**3 and boundary['nanoCpus']==2*10**9
frame=[]
for line in one('stdout.bin').read_text(errors='replace').splitlines():
 try:value=json.loads(line)
 except json.JSONDecodeError:continue
 if isinstance(value,dict)and value.get('evidence')=='apack-native-terminal-owner-app':frame.append(value)
assert len(frame)==1;frame=frame[0]
assert frame['targetSha256']=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
assert frame['realModelRequests']==0 and frame['appHandoffAccepted']is False
for key in ['nativeBackgroundApiRestart','nativeBackgroundSettledHandoff','nativeLeftArrow','nativeBackgroundHandoff','nativeBackgroundReply','nativeBackgroundParentOwnerLoss','nativeBackgroundStatus','nativeBackgroundFormatter','nativeBackgroundControls']:assert frame[key]is True,key
assert frame['nativeBackgroundConfirmation']is False
proof=read(one('native-background-app-observation.json'));x=proof['childApiRestart'];standalone=read(one('background-api-restart-observation.json'))
assert standalone['phase']==x['phase']=='recovered'
assert x['apiBefore']['pid']!=x['apiAfter']['pid']
assert x['crashedAt']<=x['disconnectedAt']<x['busResubscribedAt']<=x['reconnectedAt']
assert x['workerBefore']['start']==x['workerAfter']['start']==proof['childReply']['workerAfter']['start']
assert x['workerAfter']['state']!='Z'
assert x['before']['sessionId']==x['after']['sessionId']==proof['current']['sessionId']
assert x['before']['messages']==x['after']['messages']==proof['current']['messages']
assert x['before']['claude']['totalCostUsd']==x['after']['claude']['totalCostUsd']==proof['current']['claude']['totalCostUsd']
assert x['draft']==proof['retainedDraft']
assert x['retainedReply']==proof['childReply']['retainedReply']
job=proof['job'];assert x['infoAfter']['sessionId']==job['sessionId'] and x['infoAfter']['pid']==job['pid']
assert x['infoAfter']['observedAt']>x['reconnectedAt']
old=x['oldConfig'];new=x['newProducer'];assert new['socketPath']==old['socketPath'] and new['brokerToken']==old['brokerToken']
assert new['generation']!=old['generation'] and new['token']!=old['token']
assert x['stalePost']['status']==x['brokerProbe']['status']==409
workspace=one('native-background-app-observation.json').parent
audit=[json.loads(line)for line in(workspace/'background-broker-audit.jsonl').read_text().splitlines()]
status=x['infoAfter']['statusLine']
normalize=lambda value:'\n'.join(line.strip()for line in value.strip().split('\n')if line.strip())
assert any(row['pid']==x['apiAfter']['pid']and row['path']=='/background-formatter'and row['status']==200 and row['input'].get('generation')==new['generation']and normalize(row['input']['stdout'])==status for row in audit)
helpers=[json.loads(line)for line in(workspace/'background-formatter-helper.jsonl').read_text().splitlines()]
assert any(row['sessionId']==job['sessionId']and row['at']>x['reconnectedAt']and normalize(row['stdout'])==status for row in helpers)
stale=x['oldPost']['input']
assert any(row['pid']==x['apiAfter']['pid']and row['path']=='/background-formatter'and row['status']==409 and {k:v for k,v in row.get('input',{}).items()if k!='startedAt'}=={k:v for k,v in stale.items()if k!='startedAt'}and int(row['input']['startedAt'])>int(stale['startedAt']) for row in audit)
def journal(session):
 paths=list((workspace/'.claude/projects').rglob(session+'.jsonl'));assert len(paths)==1
 return[json.loads(line)for line in paths[0].read_text().splitlines()if line]
child=journal(job['sessionId']);by_id={row['uuid']:row for row in child if row.get('uuid')}
for text in [proof['childReply']['replyText'],x['retainedReply']]:
 humans=[row for row in child if row.get('origin',{}).get('kind')=='human'and row.get('message',{}).get('content')==text];assert len(humans)==1
 answered=False
 for row in child:
  if row.get('type')!='assistant'or not any(block.get('type')=='text'and block.get('text')for block in row.get('message',{}).get('content',[])if isinstance(block,dict)):continue
  parent=row.get('parentUuid');seen=set()
  while parent and parent not in seen:
   if parent==humans[0]['uuid']:answered=True;break
   seen.add(parent);parent=by_id.get(parent,{}).get('parentUuid')
 assert answered,text
parent=journal(proof['parentSessionId']);costs=[row for row in parent if row.get('type')=='cost-state'];assert costs and costs[-1]['totalCostUSD']==proof['current']['claude']['totalCostUsd']
assert proof['uiStop']and proof['childPidRetired']and retired(proof['childProcessAfterStop'],x['workerBefore'])
assert x['authorityRetiredAfterChildStop']and retired(x['authorityAfterStop'],x['authorityAfter']['process'])
assert x['authorityAfter']['args']==['--version']
starts=[json.loads(line)for line in(workspace/'native-children.jsonl').read_text().splitlines()]
assert all(row['args']and row['args'][0]in{'--version','agents','stop'}for row in starts if row['at']>x['crashedAt'])
with tarfile.open(root/'raw-evidence.tgz')as archive:
 installed=[member for member in archive if member.isfile()and member.name.endswith('/packs/default-setup/runtime/index.cjs')];assert len(installed)==1
 assert sha(archive.extractfile(installed[0]).read())==frame['compiledPackHashes']['runtime/index.cjs']
telemetry=[json.loads(line)for line in(root/'memory-telemetry.jsonl').read_text().splitlines()]
for row in telemetry:
 events=dict(line.split()for line in row.get('memory.events','').splitlines());assert int(events.get('oom','0'))==int(events.get('oom_kill','0'))==0
review=read(root/'visual-review.json');assert len(review['files'])==8
for name,digest in review['files'].items():
 path=(root/name).resolve();assert path.is_relative_to(root.resolve());assert sha(path.read_bytes())==digest
models=read(one('model-calls.json'));assert isinstance(models['seed'],list)and isinstance(models['agent'],list)
report={'status':'scoped-api-recovery-accepted','syntheticModelRequests':len(models['seed'])+len(models['agent']),'verifierSha256':sha(Path(__file__).read_bytes()),'productCommit':a.product_commit,'researchCommit':a.research_commit,'productInputsVerified':product,'researchInputsVerified':research,'compiledFilesUnchanged':len(before['files']),'apiBefore':x['apiBefore'],'apiAfter':x['apiAfter'],'workerPid':job['pid'],'workerStart':x['workerBefore']['start'],'freshNativeStatus':True,'capturedOldResultRefused':True,'exactSecondReplyAndNativeResponse':True,'parentDraftHistoryCostPreserved':True,'uiStopAndRecoveredAuthorityRetired':True,'reviewedCaptures':8,'memoryPeakBytes':max(int(row.get('memory.peak','0'))for row in telemetry),'memorySamples':len(telemetry),'oom':False,'realModelRequests':0,'targetSha256':frame['targetSha256'],'limits':['API crash/restart only; full Electron restart and other window/policy/stale-UI-action cases remain open.','Compact expanded Reply requires its existing inner scrolling; wider polished combined layouts remain open.','Original combined F1–F5 remains open.']}
(root/'api-recovery-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
