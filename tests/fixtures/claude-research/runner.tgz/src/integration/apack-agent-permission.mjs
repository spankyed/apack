import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
const [checkout,executable,workspace,kind='agent-permission']=process.argv.slice(2);
const denied=kind==='agent-permission-deny';
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const command="/usr/bin/printf NativeChildPermissionApproved > child-permission-marker.txt";
const model=await startSyntheticAgentModel({childTool:{name:'Bash',input:{command,description:'Write only the disposable child permission marker'}}});
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(base,'query.ts')).href);
const {createClaudeConversation}=await import(pathToFileURL(join(base,'conversation.ts')).href);
let native,owner;const events=[],turns=[],permissions=[],nested=[];
const wait=async(predicate,label)=>{const deadline=Date.now()+22000;while(!predicate()){if(Date.now()>deadline)throw Error('Timed out: '+label);await new Promise(resolve=>setTimeout(resolve,10))}};
try{
 native=await query({cliPath:executable,cwd:workspace,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:undefined,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},permissionMode:'default',tools:['Agent','Bash'],allowedTools:['Agent'],agents:{'status-fixture':{description:'Disposable local permission worker',prompt:'NativeStatusChildSystem. Use the provided fixture tool once, then return the fixed marker.',tools:['Bash'],maxTurns:2}},settingSources:[],strictMcpConfig:true,replayUserMessages:true,keepStdinOpen:true,surfaceControlRequests:true,signal:AbortSignal.timeout(28000),settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})});
 const consume=async turn=>{
  const lines=[];
  for await(const event of turn.handle.events){
   lines.push(event);
   if(event.type==='assistant')for(const block of event.message?.content??[])if(block.type==='tool_use')turn.activity.register(block.id,line=>nested.push(line));
   if(event.type==='control_request'){
    const request=event.request;
    assert.equal(request.subtype,'can_use_tool');assert.equal(request.tool_name,'Bash');assert.equal(request.tool_use_id,'child_permission_fixture');assert.equal(request.input.command,command);
    assert.equal(turns.length,1);assert.equal(turn.inputId,undefined);
    permissions.push({requestId:event.request_id,toolName:request.tool_name,toolUseId:request.tool_use_id,afterLaunchingTurn:true,autonomousScope:true});
    turn.handle.respond(event.request_id,denied?{behavior:'deny',message:'Deny only this disposable child tool.'}:{behavior:'allow',updatedInput:request.input});
   }
  }
  turns.push({inputId:turn.inputId??null,costBaseline:turn.costBaseline,resultCount:lines.filter(event=>event.type==='result').length,accounting:turn.activity.takeAccounting()});owner.release(turn.handle);
 };
 owner=createClaudeConversation(native,consume);owner.subscribe(event=>events.push(event));await native.initialized;
 owner.start('NativeSubagentParentFixture: Run the disposable status worker.',consume);
 await wait(()=>events.some(event=>event.type==='system'&&event.subtype==='task_notification')&&!owner.busy,'worker terminal notification');
 assert.equal(permissions.length,1);
 if(denied)await assert.rejects(readFile(join(workspace,'child-permission-marker.txt')),error=>error.code==='ENOENT');
 else assert.equal(await readFile(join(workspace,'child-permission-marker.txt'),'utf8'),'NativeChildPermissionApproved');
 const results=events.filter(event=>event.type==='result');assert.equal(results.length,2);assert.ok(results.every(event=>event.subtype==='success'));
 assert.ok(nested.some(event=>JSON.stringify(event).includes('SubagentFixtureComplete')));
 assert.equal(model.calls.filter(call=>call.response==='Bash').length,1);assert.ok(model.calls.some(call=>call.childToolResult&&call.childToolError===denied));
 const started=events.find(event=>event.type==='system'&&event.subtype==='task_started');const completed=events.find(event=>event.type==='system'&&event.subtype==='task_notification');assert.equal(completed.status,'completed');assert.equal(completed.task_id,started.task_id);
 await owner.close();
 console.log(JSON.stringify({evidence:`apack-native-${kind}`,targetSha256:hash(await readFile(executable)),hostInputs:1,permissions,turns,childToolExecuted:!denied,childToolDenied:denied,childOutputRetained:true,taskIdsMatched:true,syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{
 await writeFile(join(workspace,'agent-permission-events.json'),JSON.stringify(events,null,2));await writeFile(join(workspace,'agent-permission-requests.json'),JSON.stringify(model.requests,null,2));
 console.log(JSON.stringify({diagnostic:'agent-permission',permissions,turns,nested,calls:model.calls}));
 try{if(owner){owner.kill();await owner.close().catch(()=>{})}else if(native){native.kill();await native.close().catch(()=>{})}}finally{await model.close()}
}
