import {readdir,lstat,readFile} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';

/** Read only this owned worker's startup metadata; never persist authentication tokens. */
export async function childCaptionStartupDiagnostic({userDataDir,sessionId,pid}) {
 if(!Number.isSafeInteger(pid)||pid<=1||typeof sessionId!=='string'||!/^[a-f0-9-]{36}$/i.test(sessionId))return {matched:false,reason:'No original worker identity recorded'};
 const privateFile=async(path,maxBytes=65536)=>{const info=await lstat(path);if(!info.isFile()||info.uid!==process.getuid()||(info.mode&0o077)!==0||info.size>maxBytes)throw Error('Unowned startup metadata');return readFile(path);};
 const results=[];
 const names=(await readdir('/tmp')).filter(name=>/^cc-child-[A-Za-z0-9]+$/.test(name));
 if(names.length>256)return {matched:false,reason:'Startup directory inventory exceeded bound'};
 for(const name of names){
  const directory=join('/tmp',name);
  try{
   const info=await lstat(directory);if(!info.isDirectory()||info.uid!==process.getuid()||(info.mode&0o077)!==0)continue;
   const descriptor=JSON.parse(await privateFile(join(directory,'child-ui-launch.json')));
   if(descriptor.configDir!==join(userDataDir,'claude-code-profile/config'))continue;
   const marker=JSON.parse(await privateFile(join(directory,'worker-'+pid+'.json')));
   if(marker.pid!==pid||marker.sessionId!==sessionId)continue;
   const workerName=basename(String(marker.configPath).replace(/\/observer\.json$/,''));
   if(!new RegExp('^w-'+pid+'-[A-Za-z0-9]+$').test(workerName)||marker.configPath!==join(directory,'workers',workerName,'observer.json'))continue;
   const config=JSON.parse(await privateFile(marker.configPath)),runtime={};
   for(const filename of ['status.mjs','ui.mjs']){try{const bytes=await privateFile(join(directory,'workers',workerName,filename),4*1024*1024);runtime[filename]={present:true,sha256:createHash('sha256').update(bytes).digest('hex')};}catch(error){runtime[filename]={present:false,error:typeof error.code==='string'?error.code:error.name};}}
   const socket=async path=>{try{return(await lstat(path)).isSocket();}catch{return false;}};
   results.push({directory,pid,sessionId,start:marker.start,configSessionId:config.sessionId,configJobSessionId:config.jobSessionId,hasSubagentGeneration:typeof config.generations?.subagent==='string',subagentGenerationSha256:typeof config.generations?.subagent==='string'?createHash('sha256').update(config.generations.subagent).digest('hex'):null,hasMainGeneration:typeof config.generations?.main==='string',runtime,workerSocket:await socket(config.uiSocketPath),brokerSocket:await socket(config.socketPath)});
  }catch(error){if(error.code!=='ENOENT')results.push({directory,matched:false,error:typeof error.code==='string'?error.code:error.name});}
 }
 return {matched:results.some(row=>row.pid===pid),results};
}

/** Passive, bounded diagnostics on the disposable worker template; no headers or tokens recorded. */
export async function installChildCaptionTransportDiagnostic({userDataDir,workspace}) {
 const {writeFile}=await import('node:fs/promises');
 const candidates=[];
 for(const name of(await readdir('/tmp')).filter(name=>/^cc-child-[A-Za-z0-9]+$/.test(name)).slice(0,256)){
  const directory=join('/tmp',name);
  try{const info=await lstat(directory);if(!info.isDirectory()||info.uid!==process.getuid()||(info.mode&0o077)!==0)continue;
   const path=join(directory,'child-ui-launch.json'),stat=await lstat(path);if(!stat.isFile()||stat.uid!==process.getuid()||(stat.mode&0o077)!==0||stat.size>65536)continue;
   const descriptor=JSON.parse(await readFile(path));if(descriptor.configDir===join(userDataDir,'claude-code-profile/config'))candidates.push(directory);
  }catch(error){if(error.code!=='ENOENT')throw error;}
 }
 if(candidates.length!==1)throw Error('Caption diagnostic needs one exact owned startup directory');
 const path=join(candidates[0],'child-helper-template.mjs'),info=await lstat(path);if(!info.isFile()||info.uid!==process.getuid()||(info.mode&0o077)!==0||info.size>4*1024*1024)throw Error('Unowned helper observer template');
 const original=await readFile(path),receipt=join(workspace,'helper-transport.jsonl');
 const prefix=`import diagnosticHttp from 'node:http';
import {appendFileSync as diagnosticAppend} from 'node:fs';
import {createHash as diagnosticHash} from 'node:crypto';
import {ChildProcess as diagnosticChildProcess} from 'node:child_process';
const diagnosticOriginal=diagnosticHttp.request;let diagnosticCount=0;
function diagnosticRecord(value){try{diagnosticAppend(${JSON.stringify(receipt)},JSON.stringify({at:Date.now(),...value})+'\\n',{mode:0o600});}catch{}}
diagnosticRecord({phase:'installed',pid:process.pid,hasSpawn:typeof diagnosticChildProcess.prototype.spawn==='function'});
diagnosticHttp.request=function(...args){const request=Reflect.apply(diagnosticOriginal,this,args);if(!['/native-status','/observer-error'].includes(args[0]?.path)||diagnosticCount>=128)return request;const id=++diagnosticCount,end=request.end;request.end=function(...values){try{const value=JSON.parse(String(values[0]));diagnosticRecord({id,phase:'send',path:args[0]?.path,sessionId:value.sessionId,parentPid:value.parentPid,kind:value.kind,command:value.command,policyKey:value.policyKey,generationSha256:typeof value.generation==='string'?diagnosticHash('sha256').update(value.generation).digest('hex'):null,startedAt:value.startedAt,code:value.code,signal:value.signal,truncated:value.truncated,tasks:value.tasks,stdoutSha256:diagnosticHash('sha256').update(value.stdout??'').digest('hex')});}catch{diagnosticRecord({id,phase:'parse-failed'});}return Reflect.apply(end,this,values);};request.once('response',response=>diagnosticRecord({id,phase:'response',code:response.statusCode}));request.once('error',error=>diagnosticRecord({id,phase:'error',code:error.code??error.name}));return request;};
`;
 await writeFile(path,Buffer.concat([Buffer.from(prefix),original]),{mode:0o600});
 return {receipt,templateOriginalSha256:createHash('sha256').update(original).digest('hex'),diagnosticPrefixSha256:createHash('sha256').update(prefix).digest('hex')};
}
