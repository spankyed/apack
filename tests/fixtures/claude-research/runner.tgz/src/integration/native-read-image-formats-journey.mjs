import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { nativeReadImageReply } from '../protocol/native-read-image-formats.mjs';

export async function verifyReadImageFormats({ page, electronApp, section, composer, send, status, expect, context,
  output, project, proof, save, sendMain, processStart, model, cases, readJournal }) {
  proof.scope = 'Original Read payloads, native file result formatting and same-session recovery.';
  proof.imageFormats = [];
  const nativeWindow = await electronApp.browserWindow(page);
  const verifyCompactHeader = JSON.parse(await readFile('/control/offline-verified', 'utf8')).requireCompactReadingHeader === true;
  for (const [index, item] of cases.entries()) {
    await sendMain(item.prompt);
    const approval = page.getByTestId('native-read-approval');
    const group = page.locator('[data-native-tool-activity][data-native-tool-ids~="' + item.id + '"]');
    await expect.poll(async () => await approval.isVisible() || await group.count() === 1, { timeout: 15000 }).toBe(true);
    if (await approval.isVisible()) {
      await expect(approval.getByTestId('native-read-path')).toHaveText(join(project, item.file));
      await approval.getByRole('button', { name: 'Approve', exact: true }).click({ timeout: 5000 });
    }
    const received = () => model.calls.find(call => call.nativeImage?.id === item.id && call.nativeImage.result)?.nativeImage.result;
    await expect.poll(received, { timeout: 15000 }).toBeTruthy();
    const outcome = received();
    assert.equal(!!outcome.is_error, !!item.error);
    const bytes = await readFile(join(project, item.file));
    const blocks = Array.isArray(outcome.content) ? outcome.content : [{ type: 'text', text: outcome.content }];
    const observed = { name: item.file, fileSha256: digest(bytes), captures: [] };
    if (item.pages) {
      assert.deepEqual(blocks.map(block => block.type), ['text', 'image', 'text', 'image']);
      assert.match(blocks[0].text, /PDF pages extracted: 3 page/);
      assert.match(blocks[2].text, /Page 2 could not be processed as an image/i);
      observed.pages = [];
      for (const [page, block] of [[1, blocks[1]], [3, blocks[3]]]) {
        const reference = await readFile(join(project, '..', 'reference-pdf-pages', 'page-' + page + '.jpg'));
        assert.equal(block.source.type, 'base64');
        assert.equal(block.source.media_type, 'image/jpeg');
        const delivered = digest(Buffer.from(block.source.data, 'base64'));
        assert.equal(delivered, digest(reference));
        observed.pages.push({ page, sha256: delivered });
      }
      observed.failedPage = blocks[2].text;
    } else if (item.error) {
      assert.ok(blocks.every(block => block.type === 'text'));
      const message = blocks.map(block => block.text).join('\n');
      assert.ok(message.includes(item.error));
      observed.nativeError = message;
    } else if (item.mediaType) {
      const image = blocks.find(block => block.type === 'image');
      assert.equal(image?.source?.type, 'base64');
      observed.mediaType = image.source.media_type;
      observed.deliveredSha256 = digest(Buffer.from(image.source.data, 'base64'));
      assert.equal(observed.mediaType, item.mediaType);
      assert.equal(observed.deliveredSha256, observed.fileSha256);
    } else {
      assert.ok(blocks.length > 0 && blocks.every(block => block.type === 'text'));
      const lines = bytes.toString('utf8').trimEnd().split('\n');
      const delivered = blocks.map(block => block.text).join('\n');
      for (const line of lines) assert.ok(delivered.includes(line), 'Original source line absent from tool result');
      observed.sourceLines = lines.length;
    }
    proof.imageFormats.push(observed);
    await save();
    const reply = item.reply ?? nativeReadImageReply;
    const expectedReplies = cases.slice(0, index + 1).filter(entry => (entry.reply ?? nativeReadImageReply) === reply).length;
    await expect.poll(async () => (await context()).messages.filter(message =>
      message.sender === 'assistant' && message.text === reply).length,
    { timeout: 15000 }).toBe(expectedReplies);
    const draft = 'Keep the release checklist open while I review the cover.';
    await composer.fill(draft);
    const toggle = group.getByRole('button').first();
    await expect(group).toBeVisible({ timeout: 10000 });
    if (await toggle.getAttribute('aria-expanded') !== 'true') await toggle.click({ timeout: 5000 });
    const result = group.locator('[data-native-tool-result="' + item.id + '"] [data-native-tool-format]');
    await expect(result).toContainText(item.error ?? (item.pages ? /PDF|page/i : item.mediaType ? /image/i : /Read.*line/i), { timeout: 10000 });
    const rows = (await readJournal()).toString().split('\n').filter(Boolean).map(JSON.parse);
    const original = rows.find(row => row.type === 'user' && row.message?.content?.some?.(block => block.tool_use_id === item.id));
    const caller = rows.find(row => row.type === 'assistant' && row.message?.content?.some?.(block => block.id === item.id));
    const frame = Object.values((await context()).ui).flatMap(view => view.state?.transcriptMessages ?? [])
      .find(row => row.component === 'ToolResult' && row.uuid === item.id);
    assert.ok(original?.uuid && caller?.uuid);
    assert.equal(frame?.resultUuid, original.uuid);
    assert.equal(frame?.assistantUuid, caller.uuid);
    if (item.pages) {
      assert.equal(original.toolUseResult?.type, 'parts');
      assert.equal(original.toolUseResult.file.count, 3);
      assert.equal(original.toolUseResult.firstPage, 1);
      assert.equal(original.toolUseResult.pages, undefined);
    } else if (item.error) {
      const originalResult = original.message.content.find(block => block.tool_use_id === item.id);
      assert.equal(originalResult.is_error, true);
      assert.ok(JSON.stringify(originalResult.content).includes(item.error));
    } else assert.equal(original.toolUseResult?.type, item.mediaType ? 'image' : 'text');
    if (!item.mediaType && !item.error && !item.pages) {
      assert.equal(original.toolUseResult.file.content.trimEnd(), bytes.toString('utf8').trimEnd());
      await expect(group.locator('[data-release-cover="vector-source"]')).toHaveCount(0);
    }
    Object.assign(observed, { text: await result.innerText(), nativeResultUuid: original.uuid, nativeAssistantUuid: caller.uuid });
    for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
      await page.setViewportSize(viewport);
      const transcript = page.getByTestId('chat-transcript').locator(':scope > div.overflow-y-auto');
      const positions = item.error && size === 'compact' ? ['start', 'end'] : ['center'];
      for (const position of positions) {
        await revealResultLine(page, expect, result, transcript, position);
        await expect(composer).toHaveText(draft);
        for (const control of [composer, status, send]) await expect(control).toBeInViewport();
        const suffix = position === 'center' ? '' : '-' + position;
        const capture = 'native-read-' + item.extension + '-' + size + suffix + '.png';
        const snapshot = await nativeWindow.evaluate(async (window, dimensions) => {
          const bitmap = await window.webContents.capturePage({ x: 0, y: 0, ...dimensions });
          return { size: bitmap.getSize(), png: bitmap.toPNG().toString('base64') };
        }, viewport);
        assert.deepEqual(snapshot.size, viewport);
        await writeFile(join(output, capture), Buffer.from(snapshot.png, 'base64'));
        if (item.pages) {
          const geometry = await page.evaluate(() => {
            const bounds = element => {
              if (!element) return null;
              const rect = element.getBoundingClientRect(), style = getComputedStyle(element);
              return { top: rect.top, bottom: rect.bottom, height: rect.height, clientHeight: element.clientHeight,
                scrollHeight: element.scrollHeight, overflowY: style.overflowY, minHeight: style.minHeight };
            };
            const inspect = selector => bounds(document.querySelector(selector));
            const transcript = document.querySelector('[data-testid="chat-transcript"] > div.overflow-y-auto');
            const ancestors = [];
            for (let parent = transcript; parent && ancestors.length < 12; parent = parent.parentElement) {
              ancestors.push({ label: parent.getAttribute('data-testid') ?? parent.className, ...bounds(parent) });
            }
            return { ancestors, transcript: bounds(transcript), card: inspect('[data-onboarding-id="agent-chat-input"]'),
              editor: inspect('[data-testid="composer-editor-area"]'), toolbar: inspect('[data-composer-toolbar]'),
              status: inspect('[aria-label="Claude session status"]'), shell: inspect('.native-chat-shell'),
              navigation: inspect('[data-testid="chat-thread-switch"]') };
          });
          (observed.geometry ??= []).push({ size, ...geometry });
          if (verifyCompactHeader && size === 'compact') {
            assert.ok(geometry.transcript.height >= 100, 'Compact transcript must retain at least 100px on the observed PDF journey');
            const latest = section.getByRole('button', { name: 'Scroll to latest message', exact: true });
            await expect(latest).toBeInViewport({ ratio: 1 });
            await expect(section.getByRole('button', { name: 'Use native interface', exact: true })).toBeInViewport({ ratio: 1 });
            await latest.click({ timeout: 5000 });
            await expect.poll(() => transcript.evaluate(el => el.scrollHeight - el.clientHeight - el.scrollTop),
              { timeout: 5000 }).toBeLessThanOrEqual(2);
            await expect(latest).toBeHidden();
            await expect(composer).toHaveText(draft);
            await expect(status).toBeInViewport({ ratio: 1 });
            await expect(send).toBeInViewport({ ratio: 1 });
            observed.compactLatestJump = true;
          }
        }
        observed.captures.push(capture);
      }
      await save();
    }
    if (await toggle.getAttribute('aria-expanded') === 'true') await toggle.click({ timeout: 5000 });
    assert.equal((await context()).native.state.nativePid, proof.pid);
  }
  await section.getByRole('button', { name: 'Use native interface', exact: true }).click({ timeout: 5000 });
  await section.getByRole('button', { name: 'Stop session', exact: true }).click({ timeout: 5000 });
  await expect.poll(() => processStart(proof.pid), { timeout: 15000 }).not.toBe(proof.processStart);
  proof.nativeWriterRetired = true;
  await section.getByRole('button', { name: 'Back to conversation', exact: true }).click({ timeout: 5000 });
  const followup = 'Continue this saved release cover review.';
  await sendMain(followup);
  await expect.poll(async () => (await context()).messages.findIndex(message => message.sender === 'user' && message.text === followup),
    { timeout: 15000 }).toBeGreaterThanOrEqual(0);
  await expect.poll(async () => (await context()).messages.at(-1)?.sender, { timeout: 15000 }).toBe('assistant');
  assert.equal((await context()).claude.sessionId, proof.parentSessionId);
  proof.resumedPrintSameSession = true;
  proof.status = 'complete';
  await save();
}

async function revealResultLine(page, expect, result, transcript, position) {
  const frame = await transcript.boundingBox();
  assert.ok(frame && frame.height >= 40);
  await page.mouse.move(frame.x + frame.width * 0.75, frame.y + frame.height / 2);
  await expect.poll(async () => {
    const located = await result.evaluate((element, position) => {
      const rects = [];
      const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        if (!walker.currentNode.textContent.trim()) continue;
        const range = document.createRange();
        range.selectNodeContents(walker.currentNode);
        rects.push(...range.getClientRects());
      }
      const line = position === 'start' ? rects[0] : position === 'end' ? rects.at(-1) : rects[Math.floor(rects.length / 2)];
      if (!line) return null;
      const x = line.x + line.width / 2, y = line.y + line.height / 2;
      return { y, visible: element.contains(document.elementFromPoint(x, y)) };
    }, position);
    if (!located) return false;
    if (located.visible) return true;
    await page.mouse.wheel(0, Math.max(-240, Math.min(240, located.y - frame.y - frame.height / 2)));
    return false;
  }, { timeout: 10000 }).toBe(true);
}

const digest = bytes => createHash('sha256').update(bytes).digest('hex');
