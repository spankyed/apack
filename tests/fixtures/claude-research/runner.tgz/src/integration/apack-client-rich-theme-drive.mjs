import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {prepareClientRichThemeProfile} from './client-rich-theme-profile.mjs';

export async function driveClientRichThemeReview(options){
 const profile=await prepareClientRichThemeProfile(options);
 try{await driveChildComposer({...options,modelRequestLimit:10,journey:args=>clientRichThemeJourney({...args,profile}),journeyName:'client-rich-theme-review'});}
 finally{await profile.restore();}
}
async function clientRichThemeJourney({app,page,electronApp,output,project,userDataDir,expect,phase,model,profile}){
 const proof={status:'running',captures:[],readings:[],popupReadings:[],screenReadings:[],seed:'Help me inspect a release draft.',draft:'Keep my release notes while reviewing these actions.',finalText:'Continue the release review with the saved audience.'};
 const save=()=>writeFile(join(output,'client-rich-theme.json'),JSON.stringify(proof,null,2));
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:Object.values(c.nativeUiViews).find(v=>v.threadId===c.currentThread?.id),mountIds:Object.keys(c.nativeUiViews)};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 const client=card.locator('[data-native-client]'),notes=client.getByRole('textbox',{name:'Release notes',exact:true}),audience=client.getByRole('combobox',{name:'Audience',exact:true}),saveReview=client.getByRole('button',{name:'Save review',exact:true});
 const review=saveReview;
 const fieldText='Ship the updated release notes.';proof.fieldText=fieldText;
 const rgb=hex=>'rgb('+[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)).join(', ')+')';
 const start=async pid=>(await readFile('/proc/'+pid+'/stat','utf8')).split(') ').at(-1).split(' ')[19];
 const receipts=async()=>{try{return JSON.parse(await readFile(join(project,'native-client-rich-theme-receipts.json'),'utf8'));}catch(e){if(e.code==='ENOENT')return[];throw e;}};
 const nativeSite=card.locator('.native-extension-surface');
 const capture=async(stage,size)=>{
  const fields=[client.getByText('Release workspace',{exact:true}),notes,audience],documents=[client.locator('[data-native-markdown-ansi]'),client.getByRole('region',{name:'Code',exact:true}),saveReview,client.getByText('Saved reviews: '+(stage==='recovered'?2:1),{exact:true})];
  for(const[group,elements]of size==='compact'?[['fields',fields],['documents',documents]]:[['all',[...fields,...documents]]]){
   for(let attempt=0;attempt<4;attempt++){
    const site=await nativeSite.boundingBox(),bounds=await Promise.all(elements.map(element=>element.boundingBox()));assert.ok(site&&bounds.every(Boolean));
    const top=Math.min(...bounds.map(box=>box.y)),bottom=Math.max(...bounds.map(box=>box.y+box.height));
    assert.ok(bottom-top<=site.height,'Reading group must fit the actual native pane');
    const delta=top<site.y?top-site.y-4:bottom>site.y+site.height?bottom-site.y-site.height+4:0;
    if(!delta)break;await page.mouse.move(site.x+site.width/2,site.y+site.height/2);await page.mouse.wheel(0,delta);
    await expect.poll(async()=>{const b=await Promise.all(elements.map(element=>element.boundingBox()));return Math.min(...b.map(box=>box.y))>=site.y&&Math.max(...b.map(box=>box.y+box.height))<=site.y+site.height;}).toBe(true);
   }
   await expect(composer).toHaveText(proof.draft);await expect(send).toBeEnabled();await expect(send).toBeInViewport({ratio:1});for(const element of elements)await expect(element).toBeInViewport({ratio:1});
   const file='client-rich-theme-'+stage+(group==='all'?'':'-'+group)+'-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);proof.screenReadings.push({stage,size,group,scrollTop:await nativeSite.evaluate(el=>el.scrollTop)});await save();
  }
 };
 const readPaint=()=>client.evaluate(root=>{
  const input=root.querySelector('textarea[aria-label="Release notes"]'),select=root.querySelector('[role="combobox"]'),box=root.querySelector('.native-box'),code=root.querySelector('[data-native-code-ansi]'),markdown=root.querySelector('[data-native-markdown-ansi]');
  return {clientId:root.dataset.nativeClient,notes:input?.value,selection:input?[input.selectionStart,input.selectionEnd,input.selectionDirection]:null,notesFocused:document.activeElement===input,fieldColor:input&&getComputedStyle(input).color,selectColor:select&&getComputedStyle(select).color,background:box&&getComputedStyle(box).backgroundColor,code:code?.textContent,markdown:markdown?.textContent,codeBaseColor:code&&getComputedStyle(code).color,markdownBaseColor:markdown&&getComputedStyle(markdown).color,titleColor:getComputedStyle([...root.querySelectorAll('.native-text-run')].find(el=>el.textContent==='Release workspace')).color,buttonColor:getComputedStyle(root.querySelector('button[aria-label="Save review"]')).color,codeColors:code?[...new Set([...code.querySelectorAll('span')].map(s=>getComputedStyle(s).color))]:[],documentColors:markdown?[...new Set([...markdown.querySelectorAll('span')].map(s=>getComputedStyle(s).color))]:[]};
 });
 const readPalette=async(name)=>{
  const value=await readPaint();assert.equal(value.fieldColor,rgb(profile.palettes[name].overrides.text));assert.equal(value.selectColor,rgb(profile.palettes[name].overrides.text));assert.equal(value.background,rgb(profile.palettes[name].overrides.inverseText));assert.equal(value.notes,fieldText);assert.equal(value.codeBaseColor,rgb(profile.palettes[name].overrides.text));assert.equal(value.markdownBaseColor,rgb(profile.palettes[name].overrides.text));assert.equal(value.titleColor,rgb(profile.palettes[name].overrides.success));assert.equal(value.buttonColor,rgb(profile.palettes[name].overrides.suggestion));assert.ok(value.code.includes('const audience = "public";'));assert.ok(value.markdown.replace(/\s+/g,' ').includes('Before publishing: review the notes and audience.'));return value;
 };
 try{
  await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
  await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code');}),{timeout:15000}).toBe(true);
  await page.evaluate(project=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'VIEW_DASHBOARD'});actor.send({type:'NEW_THREAD_IN_PROJECT',directory:project});},project);
  await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.pendingThreadCwd)).toBe(project);
  await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
  await composer.fill(proof.seed);await send.click();
  await expect.poll(async()=>{const c=await context();return c.claude?.turns===1&&c.claude?.isRunning===false&&c.messages.some(m=>m.sender==='assistant'&&m.text?.trim()==='The release review outline is ready.');},{timeout:120000}).toBe(true);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
  proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.nativePid=proof.initial.native.state.nativePid;proof.processStart=await start(proof.nativePid);
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await expect.poll(async()=>{const c=await context();return c.ui?.state?.status;},{timeout:25000}).toMatch(/^(live|error)$/);
  if((await context()).ui?.state?.status==='error'){
   const before=await context();proof.initialUiRecovery={before};await save();
   await card.getByRole('button',{name:'Reconnect controls',exact:true}).click({timeout:5000});
   await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toBe('live');
   const after=await context();assert.equal(after.native.state.nativePid,proof.nativePid);assert.equal(after.native.state.sessionId,proof.sessionId);assert.equal(after.native.state.ownerId,before.native.state.ownerId);
   proof.initialUiRecovery.after=after;await save();
  }
  if(!await review.isVisible())await card.getByRole('button',{name:'Session tools',exact:true}).click({timeout:5000});await expect(review).toBeVisible({timeout:5000});await composer.fill(proof.draft);
  proof.modelRequestsBeforeReview=model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length;
  const window=await electronApp.browserWindow(page);await window.evaluate(w=>{w.show();w.focus();});await expect.poll(()=>page.evaluate(()=>document.hasFocus())).toBe(true);
  await notes.fill(fieldText);await expect.poll(async()=>(await receipts()).filter(r=>r.operation==='notes').at(-1)?.notes).toBe(fieldText);
  await audience.click();await page.getByRole('option',{name:'Public',exact:true}).click();await expect.poll(async()=>(await receipts()).filter(r=>r.operation==='audience').at(-1)?.audience).toBe('public');
  await saveReview.click();await expect.poll(async()=>(await receipts()).filter(r=>r.operation==='save').map(r=>r.saves)).toEqual([1]);
  const inputHandle=await notes.elementHandle();assert.ok(inputHandle);proof.clientId=await client.getAttribute('data-native-client');
  for(const theme of ['dark','light']){
   if(theme==='light'){
    await notes.click();await notes.press('ControlOrMeta+a');const before=await readPaint();assert.equal(before.notesFocused,true);proof.selectionBeforeReload=before.selection;
    await writeFile(profile.themePath,JSON.stringify(profile.palettes.light));await expect.poll(async()=>(await readPaint()).fieldColor,{timeout:15000}).toBe(rgb(profile.palettes.light.overrides.text));
    assert.equal(await inputHandle.evaluate(el=>el.isConnected&&document.activeElement===el),true);assert.deepEqual((await readPaint()).selection,proof.selectionBeforeReload);
   }
   for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
    await page.setViewportSize(viewport);const paint=await readPalette(theme);assert.equal(paint.clientId,proof.clientId);proof.readings.push({theme,size,...paint,ui:(await context()).ui});await capture(theme,size);
   }
   await audience.click();const popup=page.getByRole('listbox');await expect(popup).toBeVisible();await expect(page.getByRole('option',{name:'Public',exact:true})).toBeFocused();await page.keyboard.press('Home');await expect(page.getByRole('option',{name:'Team',exact:true})).toBeFocused();
   const beforeCancel=(await receipts()).filter(r=>r.operation==='audience');
   for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
    await page.setViewportSize(viewport);await expect(popup).toBeInViewport({ratio:1});const option=page.getByRole('option',{name:'Team',exact:true});await expect(option).toBeInViewport({ratio:1});
    const paint=await option.evaluate(el=>({color:getComputedStyle(el).color,background:getComputedStyle(el).backgroundColor}));assert.equal(paint.color,rgb(profile.palettes[theme].overrides.inverseText));assert.equal(paint.background,rgb(profile.palettes[theme].overrides.text));
    const ordinary=page.getByRole('option',{name:'Public',exact:true});await expect(ordinary).toBeInViewport({ratio:1});const ordinaryColor=await ordinary.evaluate(el=>getComputedStyle(el).color);assert.equal(ordinaryColor,rgb(profile.palettes[theme].overrides.text));
    const file='client-rich-theme-'+theme+'-popup-'+size+'.png';await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);proof.popupReadings.push({theme,size,...paint,ordinaryColor});await save();
   }
   await page.keyboard.press('Escape');await expect(popup).toBeHidden();await expect(audience).toBeFocused();assert.deepEqual((await receipts()).filter(r=>r.operation==='audience'),beforeCancel);await expect(audience).toHaveText(/Public/);
  }
  await saveReview.click();await expect.poll(async()=>(await receipts()).filter(r=>r.operation==='save').map(r=>r.saves)).toEqual([1,2]);proof.receipts=await receipts();assert.ok(proof.receipts.every(r=>r.surface==='desktop'&&r.privateColor==='success'));assert.ok(proof.receipts.filter(r=>r.operation==='save').every(r=>r.notes===fieldText&&r.audience==='public'));
  assert.equal(model.calls.filter(c=>c.path.split('?')[0]==='/v1/messages').length,proof.modelRequestsBeforeReview);proof.beforeSend=await context();assert.deepEqual(proof.beforeSend.messages,proof.initial.messages);await inputHandle.dispose();
  await composer.click();await composer.press('ControlOrMeta+a');await composer.pressSequentially(proof.finalText);await expect(composer).toHaveText(proof.finalText);await send.click();await expect.poll(async()=>{const c=await context();return c.native.state.busy===false&&c.messages.filter(m=>m.sender==='user').at(-1)?.text===proof.finalText;},{timeout:15000}).toBe(true);await composer.fill(proof.draft);proof.final=await context();assert.equal(proof.final.claude.sessionId,proof.sessionId);assert.equal(proof.final.native.state.nativePid,proof.nativePid);assert.equal(await start(proof.nativePid),proof.processStart);
  for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){await page.setViewportSize(viewport);await capture('recovered',size);}
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(async()=>{try{return(await readFile('/proc/'+proof.nativePid+'/stat','utf8')).split(') ').at(-1).split(' ')[0]==='Z'||await start(proof.nativePid)!==proof.processStart;}catch(e){if(e.code==='ENOENT')return true;throw e;}},{timeout:15000}).toBe(true);proof.nativeWriterRetired=true;
  const root=join(userDataDir,'claude-code-profile/config/projects'),names=await readdir(root,{recursive:true});assert.ok(names.length<=20000);const name=names.find(p=>basename(p)===proof.sessionId+'.jsonl');assert.ok(name);const bytes=await readFile(join(root,name));assert.ok(bytes.length<=8388608);await writeFile(join(output,'native-transcript.jsonl'),bytes);const rows=bytes.toString().split('\n').filter(Boolean).map(JSON.parse);proof.persistedCost=rows.filter(r=>r.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(proof.persistedCost,proof.final.claude.totalCostUsd);proof.status='complete';phase('client-rich-theme-complete');
 }finally{if(proof.status!=='complete'){proof.status='failed';proof.failureContext=await context().catch(()=>null);await page.screenshot({path:join(output,'client-rich-theme-failure.png')}).catch(()=>{});}await save();}
}
