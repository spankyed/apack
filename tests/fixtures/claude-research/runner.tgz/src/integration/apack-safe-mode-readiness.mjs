import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {setTimeout as delay} from 'node:timers/promises';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';

// Observe native admission/readiness through the product adapter; never enable suppressed hooks.
const [checkout,binary,workspace,inputJournal]=process.argv.slice(2);
assert.equal(process.platform,'linux');assert.ok(checkout&&binary&&workspace&&inputJournal);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
assert.equal(sha(await readFile(binary)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
const original=await readFile(inputJournal),rows=original.toString().trim().split('\n').map(JSON.parse);
const sessionId=rows.find(row=>row.sessionId)?.sessionId;
assert.match(sessionId,/^[a-f0-9-]{36}$/i);
await mkdir(workspace,{recursive:false});
const config=join(workspace,'.claude'),bucket=workspace.replace(/[^a-zA-Z0-9]/g,'-');
await mkdir(join(config,'projects',bucket),{recursive:true});
await copyFile(inputJournal,join(config,'projects',bucket,sessionId+'.jsonl'));
await writeFile(join(config,'settings.json'),JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}));
const modulePath=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-owner.ts');
const {prepareClaudeNativeTerminal}=await import(pathToFileURL(modulePath).href);
globalThis.self??=globalThis;
const {Terminal}=createRequire(join(checkout,'package.json'))('@app/claude-terminal-xterm');
const screenTerminal=new Terminal({cols:120,rows:40,allowProposedApi:true});
let owner,sequence=0,theme=false,security=false,navigated=false,trusted=false,lastInputAt=0,screen='';
const snapshots=[];let observationError;
try{
 const prepared=await prepareClaudeNativeTerminal({sessionId,cwd:workspace,settings:{effective:{},sources:[]},permissionMode:'default',cliPath:binary,columns:120,rows:40,
 env:{HOME:workspace,CLAUDE_CONFIG_DIR:config,CLAUDE_CODE_SAFE_MODE:'1',ANTHROPIC_BASE_URL:'http://127.0.0.1:1',ANTHROPIC_API_KEY:'research-fixture-key',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}});
 owner=await prepared.start();
 const deadline=Date.now()+30000;
 while(Date.now()<deadline){
  const chunks=owner.output.filter(chunk=>chunk.sequence>sequence);
  if(chunks.length){await new Promise(resolve=>screenTerminal.write(chunks.map(chunk=>chunk.text).join(''),resolve));sequence=chunks.at(-1).sequence;}
  const buffer=screenTerminal.buffer.active;screen=Array.from({length:40},(_,row)=>buffer.getLine(buffer.baseY+row)?.translateToString(true)??'').join('\n');
  const state=owner.state;if(!snapshots.length||JSON.stringify(snapshots.at(-1))!==JSON.stringify(state))snapshots.push(state);
  const kind=recognizeOnboardingPrompt(screen,workspace);let key;
  if(Date.now()-lastInputAt>1200){
   if(kind==='theme'&&!theme){theme=true;key='\r';}
   else if(kind==='security-notes'&&!security){security=true;key='\r';}
   else if(kind==='workspace-trust'&&!navigated){navigated=true;key='\x1b[B';}
   else if(kind==='workspace-trust-selected'&&!trusted){trusted=true;key='\r';}
   if(key!==undefined){owner.input(state.ownerId,key);lastInputAt=Date.now();}
  }
  await writeFile(join(workspace,'native-safe-mode-observation.json'),JSON.stringify({sessionId,inputJournal:resolve(inputJournal),inputSha256:sha(original),state,screen,snapshots,onboarding:{theme,security,navigated,trusted},modelInputsSent:0}));
  await delay(250);
 }
 try{const snapshot=await owner.uiTransport.request({subtype:'apack_owner_snapshot',policy_only:true});await writeFile(join(workspace,'native-safe-mode-owner-snapshot.json'),JSON.stringify(snapshot));}catch(error){observationError=String(error);}
}finally{
 const beforeClose=owner?.state;
 if(owner)await owner.close();screenTerminal.dispose();
 await writeFile(join(workspace,'native-safe-mode-boundary-result.json'),JSON.stringify({sessionId,beforeClose,afterClose:owner?.state,observationError,modelInputsSent:0,originalInputUnchanged:sha(await readFile(inputJournal))===sha(original)}));
}
console.log(JSON.stringify({workspace,sessionId,modelInputsSent:0}));
