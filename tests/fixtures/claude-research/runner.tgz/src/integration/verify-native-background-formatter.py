"""Verify saved original child formatter/public-env evidence; never execute recovered source."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence', type=Path)
parser.add_argument('product', type=Path)
args = parser.parse_args()
research = Path(__file__).resolve().parents[2]
evidence = args.evidence
records = evidence / 'export/records'
workspace = evidence / 'export/apack-terminal-owner-app-background'
read = lambda path: json.loads(path.read_text())
boundary = read(evidence / 'offline-boundary.json')
assert boundary['networkDisabled'] and boundary['pinnedExecutableReadOnly']
assert set(boundary['networks']) == {'none'}
assert boundary['memory'] == boundary['memorySwap'] == 6 * 1024**3
assert boundary['nanoCpus'] == 2 * 10**9
inputs = read(records / 'source-inputs.json')
for name, digest in inputs.items():
    if name.startswith('/research/'):
        source = research / name.removeprefix('/research/')
    else:
        assert name.startswith('/product/')
        source = args.product / name.removeprefix('/product/')
    assert hashlib.sha256(source.read_bytes()).hexdigest() == digest, name
native = read(records / 'leftarrow-evidence.json')
assert native['verifyFork'] and native['verifyAttach'] and native['nativeAttachmentObserved'] and native['stopped']
assert native['realModelRequests'] == 0
assert native['run']['reason'] == 'owned-leftarrow-observation-complete'
child = native['forkJob']
attachment = read(records / 'original-child-attach-observation.json')
assert attachment['frameSeen'] and attachment['jobBefore']['pid'] == attachment['jobAfter']['pid'] == child['pid']
assert attachment['processBefore']['startTime'] == attachment['processAfter']['startTime']
assert attachment['processAfter']['state'] != 'Z'
audit = read(records / 'child-formatter-audit.json')
assert hashlib.sha256((workspace / 'formatter-helper.mjs').read_bytes()).hexdigest() == audit['helperSha256']
assert [row['stage'] for row in audit['snapshots']] == ['before-attach', 'after-attach']
assert audit['snapshots'][0]['at'] <= audit['snapshots'][1]['at']
for row in audit['snapshots']:
    assert row['childSessionId'] == child['sessionId']
    actual = [item for item in row['invocations'] if item['sessionId'] == child['sessionId']]
    assert len(actual) == row['childInvocations'] and len(actual) > 0
    assert all(item['input']['session_id'] == child['sessionId'] for item in actual)
    assert all(item['input']['cost'] and item['input']['context_window'] for item in actual)
registration = read(workspace / 'project' / ('native-formatter-prefix-' + child['sessionId'] + '.json'))
assert registration['originalPrefix'] is None and registration['setResult'] == {}
assert registration['readback'].endswith('/native-status-prefix.mjs')
exports = [row for row in audit['exports'] if row['sessionId'] == child['sessionId']]
assert exports
for row in exports:
    assert row['kind'] == 'main' and row['code'] == 0 and row['signal'] is None and row['truncated'] is False
    assert any(item['stdout'] == row['stdout'] for item in audit['snapshots'][-1]['invocations'] if item['sessionId'] == child['sessionId'])
proof = {'status':'passed', 'scope':'Native-only configured child root formatter observation through admitted public env.set; no app acceptance.',
         'verifiedSourceInputs':len(inputs), 'childSessionId':child['sessionId'], 'nativeWorkerPid':child['pid'],
         'childFormatterInvocationsBeforeAttach':audit['snapshots'][0]['childInvocations'], 'exactChildExports':len(exports),
         'originalPublicEnvSetAccepted':True, 'existingUserPrefixTested':False, 'policyTransitionsTested':False,
         'originalChildStop':True, 'syntheticRequests':native['syntheticRequests'], 'realModelRequests':0}
(evidence / 'saved-record-verification.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
