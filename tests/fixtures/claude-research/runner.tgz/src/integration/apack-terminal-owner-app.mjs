import {assertTerminalImageFixtureFlags} from '../protocol/terminal-image-fixture-profile.mjs';
import {addNativeSelectionLimitFixture} from '../protocol/native-selection-limit-fixture.mjs';
import {addNativeClientThemeFixture} from '../protocol/native-client-theme-fixture.mjs';
import {driveAgentBilling} from './apack-agent-billing-drive.mjs';
import {nativeBashAdmissionObserver} from '../protocol/native-bash-admission-observer.mjs';
import {PLUGIN_HINT_COMMAND,addNativePluginHintAppFixture,verifyNativePluginHintApp,nativePluginHintObserver} from '../protocol/native-plugin-hint-app.mjs';
import {nativeCompletionNavigationHook} from '../protocol/native-completion-navigation-fixture.mjs';
import {requireNativeManagedModelInput} from '../protocol/native-managed-model-proof.mjs';
import {createNativeLargeTestImage} from '../protocol/native-test-image.mjs';
import {verifyNativeCreditPurchase,verifyNativeCreditAdmin,verifyNativeCreditBundle,verifyNativeCreditFailure,verifyNativeCreditPaymentError,verifyNativeCreditAdminError} from '../protocol/native-credit-proof.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {LINE_RESET_PLUGIN,verifyPromptLineResets} from '../protocol/native-prompt-line-reset.mjs';
import {FONT_RESET_PLUGIN,verifyPromptFontResets} from '../protocol/native-prompt-font-reset.mjs';
import {waitForWorkflowStop} from '../protocol/owned-workflow-stop.mjs';
import {WORKFLOW_UNSETTLED_SCRIPT,verifyWorkflowUnsettled} from '../protocol/native-workflow-unsettled.mjs';
import {nativeBareModeObserver,verifyNativeBareMode} from '../protocol/native-bare-mode.mjs';
import {addNativeModelPanelFixture,verifyNativeModelPanel} from '../protocol/native-model-panel-fixture.mjs';
import {verifyNativeEveryday,verifyNativeModelNotices} from '../protocol/native-everyday-proof.mjs';
import {addNativeFieldLifetimeFixture,verifyNativeFieldLifetime} from '../protocol/native-field-lifetime-fixture.mjs';
import {verifyPromptBrokerFailure} from '../protocol/native-prompt-broker-proof.mjs';
import {verifyNativeAgentRoundtrip} from '../protocol/native-agent-roundtrip-proof.mjs';
const promptBrokerFailure=process.env.CLAUDE_RESEARCH_PROMPT_BROKER_FAILURE==='1';
if(promptBrokerFailure&&process.env.CLAUDE_RESEARCH_PROMPT_TIMEOUT!=='1')throw Error('Pending-read broker failure requires the original prompt-timeout fixture');
import {verifyNativeDesktopSettings} from '../protocol/native-settings-proof.mjs';
import {nativeSettingsInspector,nativeSettingsFreshnessInspector} from '../protocol/native-settings-inspector.mjs';
import {addLspRecommendationAppFixture,verifyLspRecommendationApp} from '../protocol/native-lsp-recommendation.mjs';
import {verifyResumeUpload,verifyPopulatedResumeUpload} from '../protocol/verify-resume-upload.mjs';
import {addNativeQuestionToolNoticeFixture,verifyNativeQuestionToolNoticeFixture} from '../protocol/native-question-tool-notice-fixture.mjs';
import {addNativeLogFixture,verifyNativeLogFixture} from '../protocol/native-log-fixture.mjs';
import {addNativeNotifyFixture,verifyNativeNotifyFixture} from '../protocol/native-notify-fixture.mjs';
import {addNativeComposeFixture,verifyNativeComposeFixture} from '../protocol/native-compose-fixture.mjs';
import {verifyResetMedia} from '../protocol/verify-reset-media.mjs';
import {addNativeSelectFixture,verifyNativeSelectFixture} from '../protocol/native-select-fixture.mjs';
import {verifyPromptProcessReplacement} from '../protocol/verify-prompt-process-replacement.mjs';
import {verifyAgentStatusRecovery} from '../protocol/verify-agent-status-recovery.mjs';
import {addNativeSearchReviewFixture,verifyNativeIdleRedraw} from '../protocol/native-search-review-fixture.mjs';
import {nativeTaskRosterObserver} from '../protocol/native-task-roster-observer.mjs';
import {nativeAgentMediaBoundaryObserver} from '../protocol/native-agent-media-boundary.mjs';
import {verifyNativeAgentMediaBoundary} from '../protocol/verify-native-agent-media-boundary.mjs';
import {verifyNativeQuestionOwnerFailure} from '../protocol/native-question-owner-failure.mjs';
import {addNativeLspFixture,verifyNativeLspFixture} from '../protocol/native-lsp-fixture.mjs';
import {startSyntheticLspModel} from '../protocol/synthetic-lsp-model.mjs';
import {verifyNativeSystemPolicyStartup} from '../protocol/native-system-policy-proof.mjs';
import {startOwnedMcpUrlBrowser} from '../protocol/owned-mcp-url-browser.mjs';
import {nativeMcpUrlPrintRequests,verifyNativeMcpUrlApp} from '../protocol/native-mcp-url-app-fixture.mjs';
import {verifyNativeMcpFormApp} from '../protocol/native-mcp-form-app-fixture.mjs';
import {addMcpElicitationAppFixture,verifyMcpElicitationApp,mcpElicitationModelRequests} from '../protocol/mcp-elicitation-app-fixture.mjs';
import { addNativeGenericPermissionFixture, verifyNativeGenericPermissions } from '../protocol/native-generic-permission-fixture.mjs';
import { randomUUID } from 'node:crypto';
import { addNativeToolPermissionFixture, verifyNativeToolPermissions } from '../protocol/native-tool-permission-fixture.mjs';
import { addNativeTextMeasurementFixture, addNativeTextDirectionFixture } from '../protocol/native-text-measurement-fixture.mjs';
import { addNativeRestingHoverFixture } from '../protocol/native-resting-hover-fixture.mjs';
import {addNativeNotebookEditFixture,verifyNativeNotebookEdit} from '../protocol/native-notebook-edit-fixture.mjs';
import {startOwnedMcpOAuthServer} from '../protocol/owned-mcp-oauth-server.mjs';
import {verifyNativeAttachmentMedia} from '../protocol/native-attachment-media-proof.mjs';
import {nativeAgentStructuredHook,verifyAgentStructuredProof} from '../protocol/native-agent-structured-fixture.mjs';
import { requireReviewedNativeAppTarget, adaptNativeResearchPreload } from './native-platform-preload.mjs';
import { nativeActionAppHook, nativeActionDialogAppHook, nativeActionPaneAppHook, nativeActionAppBindings, verifyNativeActionContextAppProof, verifyNativeActionDialogAppProof, verifyNativeActionPaneAppProof } from '../protocol/native-action-app-fixture.mjs';
import { nativeActionKeyInspector } from '../protocol/native-action-key-inspector.mjs';
import {verifyNativeStagedDirectories} from '../protocol/native-staged-directory-fixture.mjs';
import {resourceText,resourceBlob,resourceUris,verifyMcpResourceProof} from '../protocol/mcp-resource-fixture.mjs';
import {addNativeHistoryReopenFixture,verifyNativeHistoryReopen} from '../protocol/native-history-reopen-fixture.mjs';
import {addNativeLargeDocumentFixture,largeDocumentCode} from '../protocol/native-large-document-fixture.mjs';
import {nativeHandbackStateFixture} from '../protocol/native-handback-state-fixture.mjs';
import {nativeClientControlObserver} from '../protocol/native-client-control-observer.mjs';
import {addNativeReadMediaFixture,verifyNativeReadMediaResults,verifyNativeNotebookImages,verifyNativePdfPageFailures,verifyNativePdfPageSuccess} from '../protocol/native-read-media-fixture.mjs';
import { nativeWorkflowWorkerFixture } from '../protocol/native-workflow-worker-fixture.mjs';
import { nativeUiErrorFixture } from '../protocol/native-ui-error-fixture.mjs';
import { addNativeWorkflowEditorFixture } from '../protocol/native-workflow-editor-fixture.mjs';
import { addNativeRootImeFixture } from '../protocol/native-root-ime-fixture.mjs';
import { addNativeManagedMediaFixture } from '../protocol/native-managed-media-fixture.mjs';
import { addNativePolicyHeldClientFixture } from '../protocol/native-policy-held-client-fixture.mjs';
import { nativeFocusContextObserver, nativeQueuedCompletionObserver } from '../protocol/native-focus-context-fixture.mjs';
import { addNativeThemeCreateResetFixture } from '../protocol/native-theme-create-reset-fixture.mjs';
import { addNativeSnapshotActionFixture } from '../protocol/native-snapshot-action-fixture.mjs';
import { addNativePrintThemeFixture } from '../protocol/native-print-theme-fixture.mjs';
import { addNativePrintClientFixture } from '../protocol/native-print-client-fixture.mjs';
import { addNativeClientLifecycleFixture } from '../protocol/native-client-lifecycle-fixture.mjs';
import { addNativeClientLayoutFixture } from '../protocol/native-client-layout-fixture.mjs';
import { addTerminalClientFixture } from '../protocol/terminal-client-fixture.mjs';
import { nativeComposerAdapter } from '../protocol/native-composer-adapter.mjs';
import {startSyntheticFileModel} from '../protocol/synthetic-file-model.mjs';
import { nativeManagedFiles } from '../protocol/native-managed-files.mjs';
import { nativeCommandInspector } from '../protocol/native-command-inspector.mjs';
import { nativeToolSites } from '../protocol/native-tool-sites.mjs';
import { nativeComposerSites, verifyNativeComposerSites } from '../protocol/native-composer-sites.mjs';
import { nativeDialogInspector } from '../protocol/native-dialog-inspector.mjs';
import { nativeStatusLaunchInspector } from '../protocol/native-status-launch-inspector.mjs';
import assert from 'node:assert/strict';
import { createNativeTestImage } from '../protocol/native-test-image.mjs';
import { spawn, execFileSync } from 'node:child_process';
import { lstat, mkdir, readFile, writeFile, symlink, cp, access, readdir, mkdtemp, stat, rm } from 'node:fs/promises';
import { userInfo } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startSyntheticModel, BASH_RELEASE_SCRIPT } from '../protocol/synthetic-model.mjs';
import { startSyntheticAgentModel, HANDBACK_RELEASE_REPORT, WORKFLOW_RESUME_FIXTURE_SCRIPT, WORKFLOW_PROGRESS_FIXTURE_SCRIPT, WORKFLOW_APPROVAL_FIXTURE_SCRIPT } from '../protocol/synthetic-agent-model.mjs';
import { hash } from '../artifacts/runs.mjs';
const [checkout, executable, workspace, scenario='markdown'] = process.argv.slice(2);
assertTerminalImageFixtureFlags(process.env);
const agentBilling=process.env.CLAUDE_RESEARCH_AGENT_BILLING==='1';
// Keep the billing project outside both the checkout and private app/HOME data.
const nativeProject=agentBilling?await mkdtemp('/tmp/claude-usage-project-'):process.env.CLAUDE_RESEARCH_BACKGROUND_OWNER_LOSS_APP==='1'?join(workspace,'project'):workspace;
if(nativeProject!==workspace){if(!agentBilling)await mkdir(nativeProject);execFileSync('/usr/bin/git',['init','--quiet',nativeProject],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null'},timeout:5000,maxBuffer:1024*1024});}
if(agentBilling){await writeFile(join(nativeProject,'release-notes.md'),'# Release review\n\n- Clarify native usage status.\n- Preserve parent and worker drafts.\n');await writeFile(join(workspace,'native-project-fixture.json'),JSON.stringify({project:nativeProject,home:workspace,appData:join(workspace,'app-data'),git:true}));}
const childResumeApp=process.env.CLAUDE_RESEARCH_BACKGROUND_RESUME_APP==='1';
const childInteractionApp=process.env.CLAUDE_RESEARCH_BACKGROUND_INTERACTION_APP==='1';
const childAttachApp=process.env.CLAUDE_RESEARCH_BACKGROUND_ATTACH_APP==='1'||childInteractionApp||childResumeApp;
const childReplyApp=process.env.CLAUDE_RESEARCH_BACKGROUND_REPLY_APP==='1'||process.env.CLAUDE_RESEARCH_BACKGROUND_OWNER_LOSS_APP==='1';
const childAppRestart=process.env.CLAUDE_RESEARCH_BACKGROUND_APP_RESTART==='1';
const composerLayout=process.env.CLAUDE_RESEARCH_BACKGROUND_COMPOSER_LAYOUT_APP==='1';
const sourceFrontendUrl=process.env.CLAUDE_RESEARCH_SOURCE_FRONTEND_URL;
if(sourceFrontendUrl)assert.ok(composerLayout,'Source frontend evidence requires the explicit composer profile');
const leftArrowApp=process.env.CLAUDE_RESEARCH_LEFTARROW_APP==='1'||childAttachApp||childReplyApp;
const leftArrowLookupTrace=leftArrowApp&&process.env.CLAUDE_RESEARCH_LEFTARROW_LOOKUP_TRACE==='1';
const backgroundConfirmation=leftArrowApp||process.env.CLAUDE_RESEARCH_BACKGROUND_CONFIRM==='1';
const backgroundHandoff=backgroundConfirmation||process.env.CLAUDE_RESEARCH_BACKGROUND_HANDOFF==='1';
assert.ok(!backgroundHandoff||scenario==='plan-theme','Background handoff uses the plain theme launch profile');
const fieldLifetime=process.env.CLAUDE_RESEARCH_FIELD_LIFETIME==='1';
const bareMode=process.env.CLAUDE_RESEARCH_BARE_MODE==='1';
assert.ok(!bareMode||scenario==='markdown','Bare startup uses the ordinary transcript profile');
assert.ok(!fieldLifetime||scenario==='markdown','Field lifetime uses the plain desktop transcript profile');
const heldHelperKind=process.env.CLAUDE_RESEARCH_HELD_HELPER_KIND??'main',heldSubagent=process.env.CLAUDE_RESEARCH_HELD_HELPER==='1'&&heldHelperKind==='subagent';
assert.ok(['main','subagent'].includes(heldHelperKind));
const planScenario=scenario.startsWith('plan-')?scenario.slice(5):undefined,managedPlan=planScenario==='managed-clear',rewindScenario=planScenario==='rewind',mcpScenario=['mcp-status','mcp-controls'].includes(planScenario)||process.env.CLAUDE_RESEARCH_MCP_PANEL==='1';
const mcpDirectory=mcpScenario&&process.env.CLAUDE_RESEARCH_MCP_DIRECTORY==='1';
const mcpResources=mcpScenario&&(process.env.CLAUDE_RESEARCH_MCP_RESOURCES==='1'||mcpDirectory);
assert.ok(!mcpResources||planScenario==='mcp-status','Resource fixture requires the MCP status profile');
if(agentBilling)assert.equal(planScenario,'agent-layout');
const directAgentBilling=process.env.CLAUDE_RESEARCH_DIRECT_AGENT_BILLING==='1';
if(directAgentBilling)assert.ok(agentBilling,'Direct route requires the same Agent billing fixture');
const handbackOwner=process.env.CLAUDE_RESEARCH_HANDBACK_OWNER==='1'&&planScenario==='agent-layout';
const printClients=process.env.CLAUDE_RESEARCH_PRINT_CLIENT==='1'&&planScenario==='composer-layout';
const snapshotActions=printClients&&process.env.CLAUDE_RESEARCH_SNAPSHOT_ACTIONS==='1';
const selectionToolbar=printClients&&process.env.CLAUDE_RESEARCH_SELECTION_TOOLBAR==='1';
const printTheme=printClients&&process.env.CLAUDE_RESEARCH_PRINT_THEME==='1';
const clientLifecycle=process.env.CLAUDE_RESEARCH_CLIENT_LIFECYCLE==='1'&&planScenario==='composer-layout';
const clientLayout=process.env.CLAUDE_RESEARCH_CLIENT_LAYOUT==='1'&&planScenario==='composer-layout';
const terminalClients=process.env.CLAUDE_RESEARCH_TERMINAL_CLIENTS==='1'&&planScenario==='composer-layout';
const emptyKeyboardClient=terminalClients&&process.env.CLAUDE_RESEARCH_EMPTY_KEYBOARD_CLIENT==='1';
const imageFileLifetime=terminalClients&&process.env.CLAUDE_RESEARCH_IMAGE_FILE_LIFETIME==='1';
assert.ok(!imageFileLifetime||process.env.CLAUDE_RESEARCH_IMAGE_FILES==='1');
const clientLifetime=scenario==='client-lifetime',fileScenario=scenario==='file'||clientLifetime,bashScenario=scenario==='bash',managedPolicy=scenario.startsWith('managed')||managedPlan,previewMode=managedPolicy||bashScenario||fileScenario||planScenario?'markdown':scenario;
const questionForms=planScenario==='question-forms';
const workflowQueue=planScenario==='task-controls'&&process.env.CLAUDE_RESEARCH_WORKFLOW_QUEUE==='1';
const focusQueue=workflowQueue||planScenario==='theme'&&process.env.CLAUDE_RESEARCH_FOCUS_QUEUE==='1';
const rootIme=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_ROOT_IME==='1';
const focusBash=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_FOCUS_BASH==='1';
const focusSummary=planScenario==='theme'&&(process.env.CLAUDE_RESEARCH_FOCUS_SUMMARY==='1'||focusBash||focusQueue);
const focusContext=planScenario==='theme'&&(process.env.CLAUDE_RESEARCH_FOCUS_CONTEXT==='1'||focusSummary);
const mcpElicitation=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_MCP_ELICITATION==='1';
const nativeMcpForm=mcpElicitation&&process.env.CLAUDE_RESEARCH_NATIVE_MCP_FORM==='1';
const nativeMcpUrl=mcpElicitation&&process.env.CLAUDE_RESEARCH_NATIVE_MCP_URL==='1';
const modernMcpUrl=nativeMcpUrl&&process.env.CLAUDE_RESEARCH_MCP_MODERN==='1';
const realMcpBrowser=process.env.CLAUDE_RESEARCH_NATIVE_MCP_BROWSER==='1';assert.ok(!realMcpBrowser||nativeMcpUrl);
const genericPermissions=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_GENERIC_PERMISSIONS==='1';
const searchReview=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_SEARCH_REVIEW==='1';
const cwdNavigation=searchReview&&process.env.CLAUDE_RESEARCH_CWD_NAVIGATION==='1';
const idleRedraw=searchReview&&process.env.CLAUDE_RESEARCH_IDLE_REDRAW==='1';
const toolPermissions=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_TOOL_PERMISSIONS==='1';
const notebookEdit=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_NOTEBOOK_EDIT==='1';
const heldModelPause=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_HELD_MODEL_PAUSE==='1';
const heldModelStreaming=heldModelPause&&process.env.CLAUDE_RESEARCH_STREAMING_MODEL_PAUSE==='1';
const heldModelRich=heldModelStreaming&&process.env.CLAUDE_RESEARCH_STREAMING_MODEL_RICH==='1';
const taskManager=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_TASK_MANAGER==='1';
const shellDesktop=taskManager&&process.env.CLAUDE_RESEARCH_SHELL_DESKTOP==='1';
const activeToolPause=heldModelPause||taskManager||planScenario==='theme'&&process.env.CLAUDE_RESEARCH_ACTIVE_TOOL_PAUSE==='1';
const activeToolCancel=activeToolPause||planScenario==='theme'&&process.env.CLAUDE_RESEARCH_ACTIVE_TOOL_CANCEL==='1';
const lspUnload=process.env.CLAUDE_RESEARCH_LSP_UNLOAD==='1';
const lspLifetime=process.env.CLAUDE_RESEARCH_LSP_LIFETIME==='1';
const lspLifecycle=process.env.CLAUDE_RESEARCH_LSP_LIFECYCLE==='1';
const refusalNotice=planScenario==='theme'?process.env.CLAUDE_RESEARCH_REFUSAL_NOTICE:undefined;
if(refusalNotice)assert.ok(['retry_fallback','edit_prompt','cancelled'].includes(refusalNotice));
const pluginHint=planScenario==='theme'?process.env.CLAUDE_RESEARCH_PLUGIN_HINT:undefined;
if(pluginHint)assert.ok(['yes','no','disable','timeout'].includes(pluginHint));
const bashAdmissionTrace=!!pluginHint&&process.env.CLAUDE_RESEARCH_BASH_ADMISSION_TRACE==='1';
const lspRecommendation=planScenario==='theme'?process.env.CLAUDE_RESEARCH_LSP_RECOMMENDATION:undefined;
if(lspRecommendation)assert.ok(['yes','no','never','disable','timeout'].includes(lspRecommendation));
const lspReview=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_LSP==='1';
const systemPolicyUnreadable=process.env.CLAUDE_RESEARCH_SYSTEM_POLICY_UNREADABLE==='1';
const systemPolicyTransitions=process.env.CLAUDE_RESEARCH_SYSTEM_POLICY_TRANSITIONS==='1';
const systemPolicy=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_SYSTEM_POLICY==='1';
const darwinSystemPolicy=process.env.CLAUDE_RESEARCH_DARWIN_SYSTEM_POLICY==='1';
const darwinPolicyLive=process.env.CLAUDE_RESEARCH_DARWIN_POLICY_LIVE==='1';
assert.ok(!darwinPolicyLive || darwinSystemPolicy);
if (darwinSystemPolicy) {
 assert.ok(systemPolicy && !systemPolicyTransitions && !(darwinPolicyLive && systemPolicyUnreadable));
 assert.equal(process.platform,'darwin');
 assert.notEqual(process.getuid(),0);
}

const agentImeCancel=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_AGENT_IME_CANCEL==='1';
const bashImage=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_BASH_IMAGE==='1';
const readMedia=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_READ_MEDIA==='1';
const notebookImages=readMedia&&process.env.CLAUDE_RESEARCH_NOTEBOOK_IMAGES==='1';
const managedModelRestart=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_MANAGED_MODEL_RESTART==='1';
const completionNavigation=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_COMPLETION_NAVIGATION==='1';
if(managedModelRestart)await requireNativeManagedModelInput(workspace,executable);
const readMediaPageSuccess=readMedia&&process.env.CLAUDE_RESEARCH_PDF_SUCCESS==='1';
const readMediaPages=readMedia&&process.env.CLAUDE_RESEARCH_PDF_PAGES==='1';
const pendingWorkflow=planScenario==='task-controls'&&process.env.CLAUDE_RESEARCH_PENDING_WORKFLOW==='1';
const workflowProgress=pendingWorkflow&&process.env.CLAUDE_RESEARCH_WORKFLOW_PROGRESS==='1';
const workflowUnsettled=process.env.CLAUDE_RESEARCH_WORKFLOW_UNSETTLED==='1';
const workflowResume=pendingWorkflow&&process.env.CLAUDE_RESEARCH_WORKFLOW_RESUME==='1';
const workflowResumeEligibility=workflowResume&&process.env.CLAUDE_RESEARCH_WORKFLOW_RESUME_ELIGIBILITY==='1';
const workflowWorkerActions=workflowProgress&&process.env.CLAUDE_RESEARCH_WORKFLOW_WORKER_ACTIONS==='1';
const workflowTaskControls=pendingWorkflow&&process.env.CLAUDE_RESEARCH_WORKFLOW_TASK_CONTROLS==='1';
assert.ok(!workflowUnsettled||pendingWorkflow&&workflowTaskControls&&!workflowProgress&&!workflowResume,'Unsettled Workflow requires its own task-controls profile');
const workflowGrantScope=pendingWorkflow&&process.env.CLAUDE_RESEARCH_WORKFLOW_GRANT_SCOPE==='1';
const workflowStanding=pendingWorkflow&&process.env.CLAUDE_RESEARCH_WORKFLOW_STANDING==='1';
const workflowEditor=pendingWorkflow&&process.env.CLAUDE_RESEARCH_WORKFLOW_EDITOR==='1';
const workflowEditorWithheld=workflowEditor&&process.env.CLAUDE_RESEARCH_WORKFLOW_EDITOR_WITHHELD==='1';
const workflowDeny=pendingWorkflow&&process.env.CLAUDE_RESEARCH_WORKFLOW_DENY==='1',workflowWithheld=workflowEditorWithheld||workflowDeny&&process.env.CLAUDE_RESEARCH_WORKFLOW_WITHHELD==='1';
const resetTask=planScenario==='task-controls'&&process.env.CLAUDE_RESEARCH_RESET_TASK==='1';
const resetUpload=resetTask&&process.env.CLAUDE_RESEARCH_RESET_UPLOAD==='1';
const resumeUpload=resetUpload&&process.env.CLAUDE_RESEARCH_RESUME_UPLOAD==='1';
const populatedResumeUpload=resumeUpload&&process.env.CLAUDE_RESEARCH_POPULATED_RESUME_UPLOAD==='1';
const pendingDuration=planScenario==='task-controls'&&(process.env.CLAUDE_RESEARCH_PENDING_DURATION==='1'||pendingWorkflow);
assert.ok(!populatedResumeUpload||pendingDuration,'Populated-session upload requires the existing idle task-controls profile');
const durationSettings=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_DURATION_SETTINGS==='1';
const multipleWindows=process.env.CLAUDE_RESEARCH_MULTIPLE_WINDOWS==='1';
const windowAgent=multipleWindows&&process.env.CLAUDE_RESEARCH_WINDOW_AGENT==='1';
const multipleWindowSelection=multipleWindows&&process.env.CLAUDE_RESEARCH_WINDOW_SELECTION==='1';
const composerPhase=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_COMPOSER_PHASE==='1';
const permissionAdmission=composerPhase&&process.env.CLAUDE_RESEARCH_PERMISSION_ADMISSION==='1';
const permissionRefusal=composerPhase&&process.env.CLAUDE_RESEARCH_PERMISSION_REFUSAL==='1';
const permissionRestriction=permissionRefusal?process.env.CLAUDE_RESEARCH_PERMISSION_RESTRICTION:undefined;
assert.ok(permissionRestriction===undefined||permissionRestriction==='settings','Unknown permission restriction profile');
const windowPhase=composerPhase&&multipleWindows&&process.env.CLAUDE_RESEARCH_WINDOW_PHASE==='1';
const composerCold=composerPhase&&process.env.CLAUDE_RESEARCH_COMPOSER_COLD==='1';
const savedPlan=composerCold&&process.env.CLAUDE_RESEARCH_SAVED_PLAN==='1';
const stagedDirectories=planScenario==='theme'&&(process.env.CLAUDE_RESEARCH_STAGED_DIRECTORIES==='1'||composerCold);
const configCallbacks=process.env.CLAUDE_RESEARCH_CONFIG_CALLBACKS==='1';
const configDesktop=process.env.CLAUDE_RESEARCH_CONFIG_DESKTOP==='1';
const settingsBrokerLoss=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_SETTINGS_BROKER_LOSS==='1';
const helpDesktop=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_HELP_DESKTOP==='1';
const helpLinks=helpDesktop&&process.env.CLAUDE_RESEARCH_HELP_LINKS==='1';
const agentHelpDesktop=helpDesktop&&process.env.CLAUDE_RESEARCH_AGENT_HELP_DESKTOP==='1';
const agentSettingsRoutes=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_AGENT_SETTINGS_ROUTES==='1';
const settingsRoutes=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_SETTINGS_ROUTES==='1';
const externalConsent=configDesktop&&process.env.CLAUDE_RESEARCH_EXTERNAL_CONSENT==='1';
const updateDecisions=configDesktop&&process.env.CLAUDE_RESEARCH_SETTINGS_UPDATE_DECISIONS==='1';
const remoteHome=configDesktop&&process.env.CLAUDE_RESEARCH_SETTINGS_REMOTE_HOME==='1';
if(updateDecisions||remoteHome){const proof=JSON.parse(await readFile('/control/offline-verified','utf8'));assert.equal(proof.networkDisabled,true);assert.deepEqual(proof.networks,{});assert.equal(executable,'/frozen-claude/claude');}
let externalConsentDirectory;
const themeCreateReset=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_THEME_CREATE_RESET==='1';
const capabilityProfile=planScenario==='theme'?process.env.CLAUDE_RESEARCH_TERMINAL_CAPABILITIES:undefined;
if(capabilityProfile)assert.ok(['default','disabled','no-color'].includes(capabilityProfile));
const promptThemeEveryday=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_PROMPT_THEME==='everyday';
const combinedEveryday=process.env.CLAUDE_RESEARCH_COMBINED_ACCEPTANCE==='1';
const nativeModelDesktop=process.env.CLAUDE_RESEARCH_NATIVE_MODEL_PANEL==='1';
const nativeCreditDesktop=process.env.CLAUDE_RESEARCH_NATIVE_CREDITS==='1';
const nativeCreditScenario=process.env.CLAUDE_RESEARCH_NATIVE_CREDIT_SCENARIO??'purchase';
assert.ok(['purchase','admin','admin-error','bundle-pending','payment-failed','payment-action','payment-http-error'].includes(nativeCreditScenario)&&(!process.env.CLAUDE_RESEARCH_NATIVE_CREDIT_SCENARIO||nativeCreditDesktop),'Explicit supported credit profile required');
assert.ok(!nativeCreditDesktop||process.platform==='linux'&&promptThemeEveryday&&!nativeModelDesktop&&!combinedEveryday,'Credit acceptance requires the isolated Linux everyday profile');
assert.ok(!nativeModelDesktop||promptThemeEveryday&&!combinedEveryday,'Model panel uses a dedicated everyday control journey');
assert.ok(!combinedEveryday||promptThemeEveryday,'Combined acceptance requires the ordinary everyday profile');
const modelPolicyNotice=process.env.CLAUDE_RESEARCH_MODEL_POLICY_NOTICE==='1';
if(modelPolicyNotice){
 assert.ok(combinedEveryday,'Managed model notices require combined everyday acceptance');
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
 assert.equal(boundary.networkDisabled,true);assert.deepEqual(boundary.networks,{});assert.equal(executable,'/frozen-claude/claude');
 const path='/etc/claude-code/managed-settings.json',metadata=await stat(path),bytes=await readFile(path),settings=JSON.parse(bytes);
 assert.equal(metadata.uid,0);assert.equal(metadata.mode&0o022,0);assert.equal(settings.model,'sonnet');
 await writeFile(join(workspace,'native-model-policy-input.json'),JSON.stringify({path,uid:metadata.uid,mode:metadata.mode&0o777,sha256:hash(bytes),model:settings.model,networkDisabled:true}));
}
const questionOwnerFailure=promptThemeEveryday&&process.env.CLAUDE_RESEARCH_QUESTION_OWNER_FAILURE==='1';
const promptThemeText=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_PROMPT_THEME==='text-wrap';
const textDirection=promptThemeText&&process.env.CLAUDE_RESEARCH_TEXT_DIRECTION==='1';
const textMeasurement=promptThemeText&&process.env.CLAUDE_RESEARCH_TEXT_MEASUREMENT==='1';
const restingHover=promptThemeText&&process.env.CLAUDE_RESEARCH_RESTING_HOVER==='1';
const promptExpiryOnly=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_PROMPT_THEME==='expiry';
const combinedReconnect=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_PROMPT_THEME==='reconnect';
const agentReconnectOnly=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_PROMPT_THEME==='agent-reconnect';
const promptThemeReconnect=planScenario==='theme'&&['reconnect','expiry','agent-reconnect'].includes(process.env.CLAUDE_RESEARCH_PROMPT_THEME);
const promptThemeReverse=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_PROMPT_THEME==='reverse-lifetime';
const promptThemeStale=planScenario==='theme'&&['stale','reverse-lifetime','reconnect','expiry','agent-reconnect'].includes(process.env.CLAUDE_RESEARCH_PROMPT_THEME);
const promptRichSelection=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_PROMPT_THEME==='rich-selection';
const agentRoundtrip=promptRichSelection&&process.env.CLAUDE_RESEARCH_AGENT_ROUNDTRIP==='1';
if(agentRoundtrip)assert.equal(process.env.CLAUDE_RESEARCH_AGENT_REFERENCE,'1','Round-trip profile requires the existing native reference fixture');
if(agentRoundtrip)assert.notEqual(process.env.CLAUDE_RESEARCH_STATUS_STARTUP,'1','Round-trip and startup-only journeys are distinct profiles');
const agentSource=promptRichSelection&&process.env.CLAUDE_RESEARCH_AGENT_SOURCE==='1';
const promptThemeSelection=planScenario==='theme'&&['selection','rich-selection'].includes(process.env.CLAUDE_RESEARCH_PROMPT_THEME);
const promptThemeAgent=planScenario==='theme'&&['agent','selection','rich-selection','stale','reverse-lifetime','reconnect','expiry','agent-reconnect'].includes(process.env.CLAUDE_RESEARCH_PROMPT_THEME);
const everydayRich=promptThemeAgent&&process.env.CLAUDE_RESEARCH_EVERYDAY_RICH==='1';
if(everydayRich)assert.equal(process.env.CLAUDE_RESEARCH_PROMPT_THEME,'agent');
const agentMediaBoundary=promptThemeAgent&&process.env.CLAUDE_RESEARCH_AGENT_MEDIA_BOUNDARY==='1';
const promptStructured=planScenario==='theme'&&(process.env.CLAUDE_RESEARCH_PROMPT_THEME==='structured'||stagedDirectories||composerPhase);
const promptLineResets=process.env.CLAUDE_RESEARCH_PROMPT_LINE_RESETS==='1';
const promptFontResets=process.env.CLAUDE_RESEARCH_PROMPT_FONT_RESETS==='1'||promptLineResets;
assert.ok(!promptFontResets||promptStructured,'Font reset acceptance requires the structured main-owner profile');
const promptMedia=promptStructured&&process.env.CLAUDE_RESEARCH_PROMPT_MEDIA==='1';
const promptBoundaries=promptStructured&&process.env.CLAUDE_RESEARCH_PROMPT_BOUNDARIES==='1';
const promptSource=promptStructured&&process.env.CLAUDE_RESEARCH_PROMPT_SOURCE==='1';
const sourceFill=promptStructured&&process.env.CLAUDE_RESEARCH_SOURCE_FILL==='1';
const fieldBounds=promptStructured&&process.env.CLAUDE_RESEARCH_FIELD_BOUNDS==='1';
const actionKeysApp=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_ACTION_KEYS_APP==='1';
const actionKeyContextsApp=actionKeysApp&&process.env.CLAUDE_RESEARCH_ACTION_KEY_CONTEXTS==='1';
const actionKeyDialogApp=actionKeysApp&&process.env.CLAUDE_RESEARCH_ACTION_KEY_DIALOG==='1';
const actionKeyPanesApp=actionKeysApp&&process.env.CLAUDE_RESEARCH_ACTION_KEY_PANES==='1';
const promptSyntax=promptStructured&&process.env.CLAUDE_RESEARCH_PROMPT_SYNTAX==='1';
const uiSelection=(promptStructured||promptThemeAgent)&&process.env.CLAUDE_RESEARCH_UI_SELECTION==='1';
const uiCopy=promptStructured&&process.env.CLAUDE_RESEARCH_UI_COPY==='1';
const promptAllSelection=promptStructured&&process.env.CLAUDE_RESEARCH_PROMPT_ALL_SELECTION==='1';
const managedMedia=promptMedia&&process.env.CLAUDE_RESEARCH_MANAGED_MEDIA==='1';
const promptTheme=planScenario==='theme'&&(stagedDirectories||composerPhase||['1','agent','text-wrap','everyday','selection','rich-selection','stale','reverse-lifetime','reconnect','expiry','agent-reconnect','structured'].includes(process.env.CLAUDE_RESEARCH_PROMPT_THEME));
if(stagedDirectories)assert.ok(promptTheme&&promptStructured,'Staged directories require the shared composer/status fixture');
const pendingApprovalFailure=planScenario==='theme'?process.env.CLAUDE_RESEARCH_PENDING_APPROVAL_FAILURE:undefined;
if(pendingApprovalFailure)assert.ok(['native','broker','cancel'].includes(pendingApprovalFailure));
const largeDocuments=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_LARGE_DOCUMENTS==='1';
const historyReopen=largeDocuments&&process.env.CLAUDE_RESEARCH_HISTORY_REOPEN==='1';
const ownerFailure=historyReopen?process.env.CLAUDE_RESEARCH_OWNER_FAILURE:undefined;
if(ownerFailure)assert.ok(['native','broker'].includes(ownerFailure));
const coldReopen=historyReopen&&process.env.CLAUDE_RESEARCH_COLD_REOPEN==='1';
const startupCancel=coldReopen&&process.env.CLAUDE_RESEARCH_STARTUP_CANCEL==='1',reopenOffset=startupCancel?1:0;
const importReopen=coldReopen&&process.env.CLAUDE_RESEARCH_IMPORT_REOPEN==='1';
const documentTheme=planScenario==='theme'&&process.env.CLAUDE_RESEARCH_DOCUMENT_THEME==='1';
const fileLayout=fileScenario&&process.env.CLAUDE_RESEARCH_FILE_LAYOUT==='1';
const fileStanding=fileScenario&&!clientLifetime&&process.env.CLAUDE_RESEARCH_FILE_STANDING==='1';
const bashStanding=bashScenario&&process.env.CLAUDE_RESEARCH_BASH_STANDING==='1';
assert.ok(['markdown','html'].includes(previewMode));
await writeFile(join(workspace,'question-preview-fixture.json'),JSON.stringify({refusalNotice,pluginHint,lspRecommendation,genericPermissions,toolPermissions,textDirection,textMeasurement,restingHover,heldPolicyClient:process.env.CLAUDE_RESEARCH_POLICY_HELD_CLIENT==='1',borrowedPolicyClient:process.env.CLAUDE_RESEARCH_POLICY_BORROWED_CLIENT==='1',fileLayout,mode:previewMode,planScenario,largeDocuments,pendingApprovalFailure,historyReopen,ownerFailure,coldReopen,importReopen,startupCancel,handbackOwner,rootIme,workflowQueue,focusQueue,focusBash,focusSummary,focusContext,pendingWorkflow,workflowGrantScope,workflowStanding,workflowEditor,workflowEditorWithheld,workflowDeny,workflowWithheld,pendingDuration,durationSettings,themeCreateReset,clientLifetime,terminalClients,printClients,printTheme,selectionToolbar,snapshotActions,documentTheme,questionForms,fileStanding,capabilityProfile,managedMedia,promptMedia,promptRichSelection,promptStructured,promptSyntax,promptAllSelection,uiCopy,uiSelection,promptTheme,promptThemeAgent,promptThemeText,promptThemeEveryday,promptThemeSelection,transition:scenario==='managed-transition',restriction:scenario==='managed-no-helper'||scenario==='managed-disable-hooks'?scenario:undefined}));
const referenceDirectory = await mkdtemp(join(workspace, '..', 'native-reference-outside-'));
if(stagedDirectories){await mkdir(join(referenceDirectory,'extra project'));await mkdir(join(referenceDirectory,'later project'));}
const referenceFile=stagedDirectories?join(referenceDirectory,'extra project','native-reference.txt'):join(referenceDirectory,largeDocuments?'release-migrations.js':promptThemeEveryday?'release-checklist.md':'native-reference.txt');
const referenceContent=largeDocuments?largeDocumentCode:promptThemeEveryday?'# Release checklist\n\n- Describe behavior changes.\n- Keep migration guidance.\n- Confirm interruption recovery.\n':'NativeReferenceFileBytes';
await writeFile(referenceFile,referenceContent);
const secondDirectoryFile=stagedDirectories?join(referenceDirectory,'later project','native-reference.txt'):undefined;
if(secondDirectoryFile)await writeFile(secondDirectoryFile,'NativeSecondDirectoryFileBytes');
await writeFile(join(workspace,'reference-fixture.json'),JSON.stringify({file:referenceFile,content:referenceContent,...(secondDirectoryFile?{secondFile:secondDirectoryFile,secondContent:'NativeSecondDirectoryFileBytes'}:{})}));
assert.equal(process.env.HOME, workspace);
const reviewedExecutionTarget=await requireReviewedNativeAppTarget(checkout,executable);
await writeFile(join(workspace,'native-execution-platform.json'),JSON.stringify(reviewedExecutionTarget,null,2)+'\n');
for (const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN']) assert.equal(process.env[key], undefined);
try { await access('/usr/local/bin/codex'); throw Error('Real fallback Codex exists; refuse the isolated fixture') } catch (error) { if (error.code !== 'ENOENT') throw error }
await writeFile(join(workspace,'native-app-image.png'),createNativeTestImage());
if(externalConsent){externalConsentDirectory=await mkdtemp('/tmp/apack-native-external-consent-');const path=join(externalConsentDirectory,'review-instructions.md'),marker='ExternalConsentInstruction_'+randomUUID();await writeFile(path,'# External review instructions\n\nFor this isolated review, retain the marker '+marker+'.\n');await writeFile(join(workspace,'CLAUDE.md'),'@'+path+'\n');await writeFile(join(workspace,'external-consent-fixture.json'),JSON.stringify({path,marker,content:await readFile(path,'utf8')}));}
await mkdir(join(workspace,'.claude/agents'),{recursive:true}); await mkdir(join(workspace,'bin'));
if(remoteHome){const path=join(workspace,'.claude/.claude.json'),prior=JSON.parse(await readFile(path,'utf8').catch(error=>{if(error.code==='ENOENT')return '{}';throw error;}));await writeFile(path,JSON.stringify({...prior,remoteHomeSettingsMode:'forward'}));await writeFile(join(workspace,'native-cloud-settings-fixture.json'),JSON.stringify({initialMode:'forward',nativeFlagOverrides:false,scope:'Private previously saved preference; original LKe retained-preference admission and native grant checks unchanged.'}));}
const shellArgument = value => "'" + value.replaceAll("'", "'\\''") + "'";
if(workflowUnsettled){const preload=join(workspace,'owned-workflow-stop-client.mjs');await writeFile(preload,'import {tagWorkflowStopDelivery} from '+JSON.stringify(new URL('../protocol/owned-workflow-stop.mjs',import.meta.url).href)+';tagWorkflowStopDelivery('+JSON.stringify({workspace})+');\n');await writeFile(join(workspace,'bin/node'),'#!/bin/sh\ncase "$*" in *dist/server.js*) exec '+shellArgument(process.execPath)+' --import '+shellArgument(preload)+' "$@" ;; *) exec '+shellArgument(process.execPath)+' "$@" ;; esac\n',{mode:0o700});}else if(imageFileLifetime){const preload=join(workspace,'owned-image-read-preload.mjs');await writeFile(preload,'import {installOwnedImageReadHold} from '+JSON.stringify(new URL('../protocol/owned-image-read-hold.mjs',import.meta.url).href)+';installOwnedImageReadHold('+JSON.stringify({workspace,path:join(workspace,'prompt-fixture/release-cover.rgba')})+');\n');await writeFile(join(workspace,'bin/node'),'#!/bin/sh\ncase "$*" in *dist/server.js*) exec '+shellArgument(process.execPath)+' --import '+shellArgument(preload)+' "$@" ;; *) exec '+shellArgument(process.execPath)+' "$@" ;; esac\n',{mode:0o700});}else if((process.env.CLAUDE_RESEARCH_BACKGROUND_STATUS_LIFECYCLE_APP==='1'||process.env.CLAUDE_RESEARCH_BACKGROUND_FORMATTER_LIFECYCLE_APP==='1'||process.env.CLAUDE_RESEARCH_BACKGROUND_FORMATTER_POLICY_APP==='1'||process.env.CLAUDE_RESEARCH_BACKGROUND_API_RESTART_APP==='1'||childAppRestart))await writeFile(join(workspace,'bin/node'),'#!/bin/sh\ncase "$*" in *dist/server.js*) exec '+shellArgument(process.execPath)+' --import '+shellArgument(new URL('./owned-background-broker-audit.mjs',import.meta.url).pathname)+' "$@" ;; *) exec '+shellArgument(process.execPath)+' "$@" ;; esac\n',{mode:0o700});else if(fileLayout)await writeFile(join(workspace,'bin/node'),'#!/bin/sh\ncase "$*" in *dist/server.js*) exec '+shellArgument(process.execPath)+' --import '+shellArgument(join(workspace,'research-event-observer.mjs'))+' "$@" ;; *) exec '+shellArgument(process.execPath)+' "$@" ;; esac\n',{mode:0o700});else await symlink(process.execPath,join(workspace,'bin/node'));
await writeFile(join(workspace,'.claude/agents/status-fixture.md'),'---\nname: status-fixture\ndescription: Disposable native status worker\ntools: []\n---\nNativeStatusChildSystem. Return the fixed worker marker without tools.\n');
await writeFile(join(workspace,'main.py'),"import json,sys,pathlib,os\np=json.load(sys.stdin)\npathlib.Path("+JSON.stringify(join(workspace,'helper-bun-options.txt'))+").write_text(os.environ.get('BUN_OPTIONS','unset'))\ncontrol=pathlib.Path("+JSON.stringify(join(workspace,'status-mode.txt'))+")\nmode=control.read_text() if control.exists() else 'normal'\nif mode=='empty': sys.exit(0)\nif mode=='failure':\n print('Failure output must not become status')\n sys.exit(7)\nprint('\\x1b[32mAppNativeMain '+p['session_id']+' prefix='+os.environ.get('APACK_PREFIX_FIXTURE','original')+'\\x1b[0m')\nprint('Second native status line')\n");
if(process.env.CLAUDE_RESEARCH_BACKGROUND_FORMATTER_APP==='1'){
 const helper=join(workspace,'main.py');
 const receipt="\nwith open("+JSON.stringify(join(workspace,'background-formatter-helper.jsonl'))+",'a') as f:\n f.write(json.dumps({'at':int(__import__('time').time()*1000),'sessionId':p['session_id'],'stdout':'\\x1b[32mAppNativeMain '+p['session_id']+' prefix='+os.environ.get('APACK_PREFIX_FIXTURE','original')+'\\x1b[0m\\nSecond native status line\\n'})+'\\n')\n";
 await writeFile(helper,(await readFile(helper,'utf8')).replace("print('Second native status line')","formatter_observation=str(__import__('time').time_ns())\nprint('Second native status line '+formatter_observation)")+receipt.replace("Second native status line","Second native status line '+formatter_observation+'"));
}
if(process.env.CLAUDE_RESEARCH_BACKGROUND_FORMATTER_POLICY_APP==='1'){
 const helper=join(workspace,'main.py');
 const hold=`import time,signal
arm=pathlib.Path(${JSON.stringify(join(workspace,'background-policy-helper-arm'))})
claimed=pathlib.Path(${JSON.stringify(join(workspace,'background-policy-helper-claimed'))})
release=pathlib.Path(${JSON.stringify(join(workspace,'background-policy-helper-release'))})
held=False
try:
 if arm.read_text()!=p['session_id']: raise FileNotFoundError
 arm.rename(claimed)
 held=True
except FileNotFoundError: pass
if held:
 signal.signal(signal.SIGTERM,signal.SIG_IGN)
 pathlib.Path(${JSON.stringify(join(workspace,'background-policy-helper-started.json'))}).write_text(json.dumps({'pid':os.getpid(),'parentPid':os.getppid(),'sessionId':p['session_id'],'at':int(time.time()*1000)}))
 deadline=time.monotonic()+12
 while not release.exists() and time.monotonic()<deadline: time.sleep(0.02)
 if not release.exists(): sys.exit(9)
 emitted=False
 try:
  print('STALE_BACKGROUND_POLICY_HELPER',flush=True)
  emitted=True
 except BrokenPipeError: pass
 pathlib.Path(${JSON.stringify(join(workspace,'background-policy-helper-finished.json'))}).write_text(json.dumps({'pid':os.getpid(),'sessionId':p['session_id'],'marker':'STALE_BACKGROUND_POLICY_HELPER','emitted':emitted,'at':int(time.time()*1000)}))
 os._exit(0)
`;
 await writeFile(helper,(await readFile(helper,'utf8')).replace('p=json.load(sys.stdin)\n','p=json.load(sys.stdin)\n'+hold));
}
if(process.env.CLAUDE_RESEARCH_STATUS_STARTUP==='1')await writeFile(join(workspace,'main.py'),`import json,sys,pathlib,os,time
p=json.load(sys.stdin)
with open(${JSON.stringify(join(workspace,'status-startup-helper.jsonl'))},'a') as f: f.write(json.dumps({'at':int(time.time()*1000),'pid':os.getpid(),'sessionId':p['session_id']})+'\\n')
print('Session ready')
print('Reviewing release notes')
`);
if(planScenario==='composer-layout'){const helper=join(workspace,'main.py');await writeFile(helper,(await readFile(helper,'utf8')).replace("if mode=='empty':","if mode=='long':\n print(chr(27)+'[32mNativeLongStatusStart_'+'W'*512+chr(27)+'[0m')\n for index in range(24): print('Native status row '+str(index)+' details')\n print('NativeLongStatusEnd')\n sys.exit(0)\nif mode=='empty':"));}
await writeFile(join(workspace,'sub.py'),"import json,sys,os\np=json.load(sys.stdin)\nprint('invalid fixture row')\nprint(json.dumps({'id':'foreign','content':'ForeignMustNotReachApp'}))\nfor t in p['tasks']:\n print(json.dumps({'id':t['id'],'content':'AppNativeAgent '+t['status']+' prefix='+os.environ.get('CLAUDE_CODE_SHELL_PREFIX','unset')}))\n");
if(planScenario==='agent-layout')await writeFile(join(workspace,'sub.py'),"import json,sys\np=json.load(sys.stdin)\nfor t in p['tasks']:\n text='AppNativeAgent '+t['status']+' NativeAgentLongStart_'+'W'*512+'\\n'+'\\n'.join('Agent status row '+str(i)+' details' for i in range(24))+'\\nNativeAgentLongEnd'\n print(json.dumps({'id':t['id'],'content':text}))\n");
if(process.env.CLAUDE_RESEARCH_HELD_HELPER==='1'){
 const helper=join(workspace,heldSubagent?'sub.py':'main.py'),text=await readFile(helper,'utf8');
 const held="import time,signal\nsignal.signal(signal.SIGTERM,signal.SIG_IGN)\narm=pathlib.Path("+JSON.stringify(join(workspace,'held-helper-arm'))+")\nclaimed=pathlib.Path("+JSON.stringify(join(workspace,'held-helper-claimed'))+")\nrelease=pathlib.Path("+JSON.stringify(join(workspace,'held-helper-release'))+")\nheld=False\ntry:\n arm.rename(claimed)\n held=True\nexcept FileNotFoundError: pass\nif held:\n pathlib.Path("+JSON.stringify(join(workspace,'held-helper-started.json'))+").write_text(json.dumps({'pid':os.getpid(),'parentPid':os.getppid(),'sessionId':p['session_id'],'taskIds':[t['id'] for t in p.get('tasks',[])]}))\n deadline=time.monotonic()+12\n while not release.exists() and time.monotonic()<deadline: time.sleep(0.02)\n if not release.exists(): sys.exit(9)\n "+(heldSubagent?"for t in p['tasks']: print(json.dumps({'id':t['id'],'content':'STALE_HELD_HELPER'}),flush=True)":"print('STALE_HELD_HELPER',flush=True)")+"\n pathlib.Path("+JSON.stringify(join(workspace,'held-helper-finished.json'))+").write_text(json.dumps({'pid':os.getpid(),'printed':'STALE_HELD_HELPER'}))\n sys.exit(0)\n";
 await writeFile(helper,heldSubagent?text.replace("import json,sys,os","import json,sys,os,pathlib").replace("print('invalid fixture row')",held.replace("try:\n arm.rename", "try:\n if not any(t['status']=='running' for t in p['tasks']): raise FileNotFoundError\n arm.rename")+"print('invalid fixture row')"):text.replace("if mode=='empty':",held+"if mode=='empty':"));
}
const prefixPath=join(workspace,"user's app prefix"),prefixLog=join(workspace,'prefix-calls.jsonl'),shellPrefix=mcpScenario||genericPermissions||mcpElicitation?prefixPath:prefixPath+' --fixture-prefix';
await writeFile(prefixPath,`#!/usr/bin/python3
import json,os,subprocess,sys
with open(${JSON.stringify(prefixLog)},'a') as f:f.write(json.dumps({'args':sys.argv[1:],'prefix':os.environ.get('CLAUDE_CODE_SHELL_PREFIX')})+'\\n')
if sys.argv[1:2]==[${JSON.stringify(process.execPath)}]: os.execv(sys.argv[1],sys.argv[1:])
result=subprocess.run(['/bin/sh','-c',sys.argv[-1]],stdin=sys.stdin,stdout=sys.stdout,stderr=sys.stderr)
with open(${JSON.stringify(join(workspace,'prefix-exits.jsonl'))},'a') as f:f.write(json.dumps({'args':sys.argv[1:],'code':result.returncode})+'\\n')
sys.exit(result.returncode)
`,{mode:0o700});
if(process.env.CLAUDE_RESEARCH_HELD_HELPER==='1')await writeFile(prefixPath,(await readFile(prefixPath,'utf8')).replace('import json,os,subprocess,sys','import json,os,subprocess,sys,signal\nif sys.argv[-1].find("/'+(heldSubagent?'sub.py':'main.py')+'")>=0: signal.signal(signal.SIGTERM,signal.SIG_IGN)'));
// The original scheduler cancels an unfinished helper on refresh. The hosted macOS
// desktop fixture runs its Python prefix and helper alongside Electron.
const statusRefreshInterval = process.platform === 'darwin' && promptThemeEveryday ? 4 : 1;
await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify({...planScenario?{showClearContextOnPlanAccept:true,...['accept-edits','clear-accept-edits'].includes(planScenario)?{disableAutoMode:'disable'}:{}}:{},permissions:{...(workflowResume?{allow:['Read']}:mcpScenario?{allow:['mcp__research__echo']}:{ }),ask:workflowResume?[]:planScenario==='enter'?['EnterPlanMode']:fileStanding?[]:fileScenario||rewindScenario?['Write','Edit']:bashScenario?(bashStanding?['Read']:['Read','Bash']):['Read']},env:{CLAUDE_CODE_SHELL_PREFIX:shellPrefix},apiKeyHelper:'/usr/bin/printf research-fixture-key',statusLine:{type:'command',command:`/usr/bin/python3 '${join(workspace,'main.py')}'`,...(process.env.CLAUDE_RESEARCH_STATUS_STARTUP==='1'?{}:{refreshInterval:statusRefreshInterval})},subagentStatusLine:{type:'command',command:`/usr/bin/python3 '${join(workspace,'sub.py')}'`}}));
if(refusalNotice){const path=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(path,'utf8'));await writeFile(path,JSON.stringify({...settings,model:'claude-opus-5',switchModelsOnFlag:false}));}
if(externalConsent){const file=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(file,'utf8'));await writeFile(file,JSON.stringify({...settings,language:'French',timeFormat:'24-hour'}));await writeFile(join(workspace,'.claude/settings.local.json'),JSON.stringify({spinnerTipsEnabled:false,prefersReducedMotion:true}));}
if(updateDecisions||remoteHome)await writeFile(join(workspace,'native-update-offline.json'),await readFile('/control/offline-verified','utf8'));
if(permissionRestriction==='settings'){const path=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(path,'utf8'));settings.permissions.disableBypassPermissionsMode='disable';await writeFile(path,JSON.stringify(settings));}
if(workflowGrantScope&&!workflowStanding)throw Error('Grant scope requires standing Workflow fixture');
if(workflowStanding){await mkdir(join(workspace,'.claude/workflows'),{recursive:true});await writeFile(join(workspace,'.claude/workflows/release-review.js'),WORKFLOW_APPROVAL_FIXTURE_SCRIPT);}
if(workflowGrantScope)await writeFile(join(workspace,'.claude/workflows/security-review.js'),WORKFLOW_APPROVAL_FIXTURE_SCRIPT.replaceAll('release-review','security-review').replace('Review release notes','Review security notes'));
if(workflowEditor)await addNativeWorkflowEditorFixture(workspace);
const userPreload=join(workspace,'user-preload.mjs'),userPreloadCalls=join(workspace,'user-preload-calls.jsonl'),originalBunOptions='--preload='+userPreload;
await writeFile(userPreload,"import {appendFileSync} from 'node:fs';appendFileSync("+JSON.stringify(userPreloadCalls)+",JSON.stringify({pid:process.pid})+'\\n');");
if (darwinPolicyLive) {
 const receipt = join(workspace, 'native-darwin-policy-poll.jsonl');
 await writeFile(userPreload, (await readFile(userPreload, 'utf8')) + `
{
 if (!process.argv.includes('--print')) {
  const { appendFileSync } = await import('node:fs');
  const originalInterval = globalThis.setInterval;
  globalThis.setInterval = function(callback, delay, ...args) {
   if (delay !== 1800000 || typeof callback !== 'function' ||
       !Function.prototype.toString.call(callback).includes('Detected MDM settings change via poll')) {
    return Reflect.apply(originalInterval, this, [callback, delay, ...args]);
   }
   globalThis.setInterval = originalInterval;
   appendFileSync(${JSON.stringify(receipt)}, JSON.stringify({pid:process.pid,originalMs:delay,replayMs:2000})+'\\n');
   return Reflect.apply(originalInterval, this, [callback, 2000, ...args]);
  };
 }
}
`);
}
if(process.platform==='darwin'&&promptThemeEveryday)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeStatusLaunchInspector(workspace));
if(actionKeysApp){await writeFile(join(workspace,'.claude/keybindings.json'),JSON.stringify(nativeActionAppBindings(false,actionKeyContextsApp?'Plugin':'Global')));await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeActionKeyInspector(join(workspace,'native-action-app-inspection.json'),{observeDispatch:true,...(actionKeyContextsApp?{contextCommandPath:join(workspace,'native-action-context-command.json')}:{})}));}
// Billing/Client journeys use real app state and native receipts, not dialog inspection.
if(!agentBilling)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeDialogInspector(join(workspace,'native-dialog-shapes.json'),{promptRestoration:!!refusalNotice&&process.env.CLAUDE_RESEARCH_REFUSAL_EMPTY_DRAFT==='1'||themeCreateReset&&process.env.CLAUDE_RESEARCH_THEME_DESKTOP==='1',recommendationChoices:!!lspRecommendation,questionContracts:questionForms,fileChoices:fileStanding,maxSnapshotBytes:fileScenario||planScenario?1000000:200000}));
if(bashAdmissionTrace)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeBashAdmissionObserver(workspace));
if(process.env.CLAUDE_RESEARCH_SETTINGS_FRESHNESS==='1')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeSettingsFreshnessInspector(join(workspace,'native-settings-freshness.json')));
if(process.env.CLAUDE_RESEARCH_CONFIG_ROWS==='1')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeSettingsInspector(join(workspace,'native-settings-rows.json')));
if(workflowWorkerActions||workflowResume)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeWorkflowWorkerFixture(workspace));
if(pendingApprovalFailure||questionOwnerFailure||largeDocuments||process.env.CLAUDE_RESEARCH_CLIENT_RETURN==='1')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeClientControlObserver(join(workspace,'native-client-control-receipts.json'),{documents:largeDocuments,dialogs:!!pendingApprovalFailure||questionOwnerFailure}));
if(process.env.CLAUDE_RESEARCH_UI_ERRORS==='1'||workflowDeny||workflowWorkerActions||workflowResume||process.env.CLAUDE_RESEARCH_RASTER==='1'||process.env.CLAUDE_RESEARCH_IMAGE==='1')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeUiErrorFixture(join(workspace,'native-ui-error-receipt.json'),{timings:process.env.CLAUDE_RESEARCH_UI_ERRORS==='1'}));

if(pendingWorkflow)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+`{const {writeFileSync,appendFileSync}=await import('node:fs'),runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),loopState=await import('/$bunfs/root/chunk-tnpfcesk.js');const deadline=Date.now()+100000;let previous;const timer=setInterval(()=>{if(Date.now()>deadline){clearInterval(timer);return}try{const binding=runtime.ey();if(binding?.surface!=='terminal')return;const context=binding.toolContext(new AbortController()),tasks=Object.values(context.taskRegistry.all()).filter(task=>task.type==='local_workflow').map(task=>({id:task.id,type:task.type,status:task.status,notified:task.notified${workflowProgress||workflowResume||workflowUnsettled?',workflowProgress:task.workflowProgress,logs:task.logs,result:task.result,scriptPath:task.scriptPath,workflowRunId:task.workflowRunId,settled:loopState.AE(task.id)'+(workflowUnsettled?',controllers:[...(task.agentControllers??[])].map(([id,controller])=>({id,aborted:controller.signal.aborted}))':''):''}})),next=JSON.stringify(tasks);if(next===previous)return;previous=next;writeFileSync(${JSON.stringify(join(workspace,'native-workflow-state.json'))},next,{mode:0o600});${workflowUnsettled||workflowResumeEligibility?`appendFileSync(${JSON.stringify(join(workspace,'native-workflow-state-history.jsonl'))},JSON.stringify({at:Date.now(),tasks})+String.fromCharCode(10),{mode:0o600});`:''}}catch{}},${workflowUnsettled||workflowResumeEligibility?5:100});timer.unref();}`);
if(focusContext)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeFocusContextObserver(join(workspace,'native-focus-context.json')));
if(focusQueue)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeQueuedCompletionObserver(join(workspace,'native-queued-completion.json')));
if(focusSummary||managedMedia)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+`{const http=(await import('node:http')).default,{appendFileSync}=await import('node:fs'),original=http.createServer;http.createServer=function(...args){const index=args.findIndex(value=>typeof value==='function');if(index>=0){const listener=args[index];args[index]=function(request,response){const end=response.end;response.end=function(chunk,...rest){try{if(typeof chunk==='string'){const value=JSON.parse(chunk);if(value.error)appendFileSync(${JSON.stringify(join(workspace,'native-group-adapter-errors.jsonl'))},JSON.stringify({path:request.url,error:value.error})+'\\n',{mode:0o600})}}catch{}return end.call(this,chunk,...rest)};return listener.call(this,request,response)}}return original.apply(this,args)}}`);

if(bashScenario||fileScenario)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeToolSites(join(workspace,'native-tool-sites.json')));
if(bashScenario&&!bashStanding)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeComposerSites(join(workspace,'native-composer-sites.json')));
if(bashScenario&&process.env.CLAUDE_RESEARCH_COMPOSER_ADAPTER==='1')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+await nativeComposerAdapter(checkout,join(workspace,'native-composer-adapter.json'),{terminalPlacements:process.env.CLAUDE_RESEARCH_TERMINAL_PLACEMENTS==='1'}));
if(process.env.CLAUDE_RESEARCH_STATUS_STARTUP==='1'||windowAgent)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+`{const http=(await import('node:http')).default,{appendFileSync}=await import('node:fs'),original=http.request;http.request=function(...args){const request=original.apply(this,args);if(args[0]?.path==='/native-status'){let posted;const end=request.end;request.end=function(body,...rest){try{const v=JSON.parse(body);posted={at:Date.now(),sessionId:v.sessionId,childPid:v.childPid,parentPid:v.parentPid,generation:v.generation,kind:v.kind,stdout:v.stdout,code:v.code,signal:v.signal,startedAt:v.startedAt}}catch{}return end.call(this,body,...rest)};request.once('response',response=>{if(posted)try{appendFileSync(${JSON.stringify(join(workspace,'status-startup-posts.jsonl'))},JSON.stringify({...posted,responseAt:Date.now(),httpStatus:response.statusCode})+'\\n',{mode:0o600})}catch{}})}return request}}`);
if(process.env.CLAUDE_RESEARCH_HELD_HELPER==='1')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+`{const http=(await import('node:http')).default,{appendFileSync}=await import('node:fs'),original=http.request;http.request=function(...args){const request=original.apply(this,args);if(args[0]?.path==='/native-status'){const end=request.end;request.end=function(body,...rest){try{const value=JSON.parse(body);appendFileSync(${JSON.stringify(join(workspace,'held-helper-native-posts.jsonl'))},JSON.stringify({childPid:value.childPid,parentPid:value.parentPid,generation:value.generation,policyKey:value.policyKey,kind:value.kind,tasks:value.tasks,stdout:value.stdout,code:value.code,signal:value.signal})+'\\n',{mode:0o600})}catch{}return end.call(this,body,...rest)}}return request}}`);
if(scenario==='managed-transition')await writeFile(userPreload,`import {writeFileSync as writePolicyObserverPath} from 'node:fs';{ const match=(process.env.BUN_OPTIONS??'').split(' ').find(value=>(value.startsWith('--preload=/private/tmp/cc-app-')||value.startsWith('--preload=/tmp/cc-app-'))&&value.endsWith('/status.mjs'));if(match)writePolicyObserverPath(${JSON.stringify(join(workspace,'native-observer-path.json'))},JSON.stringify({path:match.slice('--preload='.length,-'status.mjs'.length)+'observer.json'}),{mode:0o600});}`+(await readFile(userPreload,'utf8')));
if(planScenario==='parent-commands')await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeCommandInspector(join(workspace,'native-command-lifecycle.json')));
if(startupCancel){const original=await readFile(userPreload,'utf8'),first=original.indexOf('\n')+1;await writeFile(userPreload,original.slice(0,first)+`{const fs=await import('node:fs');const arm=${JSON.stringify(join(workspace,'hold-native-startup'))};if(process.argv.includes('--no-session-persistence')&&fs.existsSync(arm)){fs.renameSync(arm,arm+'.claimed');fs.writeFileSync(${JSON.stringify(join(workspace,'held-native-startup.json'))},JSON.stringify({pid:process.pid,argv:process.argv}));await new Promise(resolve=>{const timer=setInterval(()=>{if(fs.existsSync(arm+'.release')){clearInterval(timer);resolve();}},50);});}}`+original.slice(first));}
if(agentMediaBoundary)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeAgentMediaBoundaryObserver(workspace));
if(combinedReconnect)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeTaskRosterObserver(workspace));
if (darwinSystemPolicy) {
 const directory = '/Library/Managed Preferences';
 const username = userInfo().username;
 assert.match(username, /^[A-Za-z_][A-Za-z0-9_-]*$/);
 const domain = 'com.anthropic.claudecode.plist';
 const locations = [
  {path:join(directory,username,domain), scope:'per-user', caption:'Managed OS policy ready'},
  {path:join(directory,domain), scope:'device', caption:'Device policy fallback'},
 ];
 const preferences = await Promise.all(locations.map(async ({path,scope,caption}) => {
  const metadata = await lstat(path);
  assert.ok(metadata.isFile());
  assert.equal(metadata.uid,0);
  const mode = metadata.mode & 0o777;
  if (systemPolicyUnreadable && scope === 'per-user') {
   assert.equal(mode,0);
   await assert.rejects(readFile(path),{code:'EACCES'});
   return {path,scope,caption,uid:metadata.uid,mode,errno:'EACCES'};
  }
  assert.equal(mode,0o644);
  const bytes = await readFile(path);
  const policy = JSON.parse(execFileSync('/usr/bin/plutil',['-convert','json','-o','-',path],{encoding:'utf8',timeout:5000}));
  assert.equal(policy.allowManagedHooksOnly,true);
  assert.equal(policy.statusLine.type,'command');
  assert.equal(policy.statusLine.command,"/usr/bin/printf '"+caption+"\\nManaged source has priority\\n'");
  return {path,scope,caption,uid:metadata.uid,mode:metadata.mode&0o777,sha256:hash(bytes)};
 }));
 await writeFile(join(workspace,'native-system-policy-install.json'),JSON.stringify({platform:'darwin',preferences,filesystemMapping:false,platformEmulation:false}));
}
else if(systemPolicy){
 assert.equal(process.platform,'linux','Real system-policy acceptance requires the owned Linux container');await access('/.dockerenv');
 const path='/etc/claude-code/managed-settings.json',installed=await stat(path);assert.equal(installed.uid,0);
 if(systemPolicyUnreadable){
  assert.equal(installed.mode&0o777,0);await assert.rejects(readFile(path,'utf8'),error=>error.code==='EACCES');
  await writeFile(join(workspace,'native-system-policy-install.json'),JSON.stringify({path,uid:installed.uid,mode:0,unreadable:true,errno:'EACCES',filesystemMapping:false,platformEmulation:false}));
 }else{
  const text=await readFile(path,'utf8'),policy=JSON.parse(text);assert.equal(installed.mode&0o777,0o644);assert.equal(policy.allowManagedHooksOnly,true);
  assert.equal(policy.statusLine.command,"/usr/bin/printf 'Managed OS policy ready\\nManaged source has priority\\n'");
  await writeFile(join(workspace,'native-system-policy-install.json'),JSON.stringify({path,uid:installed.uid,mode:installed.mode&0o777,sha256:hash(Buffer.from(text)),policy,filesystemMapping:false,platformEmulation:false}));
 }
}
if(managedPolicy){
 const user=JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8'));
 if(process.env.CLAUDE_RESEARCH_HELD_HELPER==='1'){const setting=heldSubagent?user.subagentStatusLine:user.statusLine;setting.command="trap '' TERM; "+setting.command;}
 const policyDirectory=join(workspace,'policy');await mkdir(policyDirectory);
 await writeFile(join(policyDirectory,'managed-settings.json'),JSON.stringify(scenario==='managed-no-helper'?{allowManagedHooksOnly:true}:{allowManagedHooksOnly:scenario!=='managed-transition',...(scenario==='managed-disable-hooks'||managedPlan?{disableAllHooks:true}:{}),statusLine:user.statusLine,subagentStatusLine:user.subagentStatusLine}));
 await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify({...user,statusLine:{type:'command',command:'/usr/bin/printf UserMustNotExecute'},subagentStatusLine:{type:'command',command:'/usr/bin/printf UserAgentMustNotExecute'}}));
 await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeManagedFiles({directory:policyDirectory,receipt:join(workspace,'managed-file-reads.jsonl'),watchPolicy:scenario==='managed-transition',platform:process.platform}));
}
if(handbackOwner){
 await writeFile(join(workspace,'.claude/agents/status-fixture.md'),'---\nname: status-fixture\ndescription: Review release notes\ntools: []\npermissionMode: auto\n---\nNativeStatusChildSystem. Return the fixed release report through SubagentHandback.\n');
 const hook=join(workspace,'handback-hook.cjs');await writeFile(hook,`let body='';process.stdin.on('data',chunk=>body+=chunk);process.stdin.on('end',()=>{const e=JSON.parse(body);if(e.tool_name==='Agent'){if(e.tool_input.subagent_type!=='status-fixture'||e.tool_input.prompt!=='Return the synthetic worker marker only.')process.exit(1);}else if(e.tool_name!=='SubagentHandback'||e.tool_input.message!==${JSON.stringify(HANDBACK_RELEASE_REPORT)})process.exit(1);process.stdout.write(JSON.stringify({hookSpecificOutput:{hookEventName:'PreToolUse',permissionDecision:'allow'}}));});`);
 const settings=join(workspace,'.claude/settings.json'),value=JSON.parse(await readFile(settings,'utf8')),quote=text=>"'"+text.replaceAll("'","'\\''")+"'";
 value.hooks={PreToolUse:[{matcher:'Agent|SubagentHandback',hooks:[{type:'command',command:quote(process.execPath)+' '+quote(hook)}]}]};await writeFile(settings,JSON.stringify(value));
 await writeFile(join(workspace,'handback-fixture.json'),JSON.stringify({report:HANDBACK_RELEASE_REPORT}));
 await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeHandbackStateFixture(workspace));
}
const mcpOAuth=process.env.CLAUDE_RESEARCH_MCP_OAUTH==='1';
const oauthServer=mcpOAuth?await startOwnedMcpOAuthServer(workspace):undefined;
const mcpBrowser=realMcpBrowser?await startOwnedMcpUrlBrowser({checkout,workspace,completionMode:modernMcpUrl?'confirm':process.env.CLAUDE_RESEARCH_NATIVE_MCP_URL_RETRY==='1'?'retry':'notify'}):undefined;
if(mcpOAuth)await writeFile(join(workspace,'owned-browser.py'),'#!/usr/bin/python3\nimport sys,json,urllib.parse\nu=urllib.parse.urlparse(sys.argv[1])\nassert u.scheme=="http" and u.hostname=="127.0.0.1" and u.path=="/authorize"\nwith open('+JSON.stringify(join(workspace,'owned-browser-urls.jsonl'))+',"a") as f:f.write(json.dumps({"url":sys.argv[1]})+"\\n")\n',{mode:0o700});
if(nativeMcpUrl&&!realMcpBrowser)await writeFile(join(workspace,'native-mcp-url-browser.mjs'),'#!'+process.execPath+'\nimport {appendFileSync,readFileSync} from \'node:fs\';appendFileSync('+JSON.stringify(join(workspace,'native-mcp-url-browser.jsonl'))+',JSON.stringify({phase:Number(readFileSync('+JSON.stringify(join(workspace,'mcp-elicitation-phase.txt'))+',\'utf8\')),url:process.argv[2]})+\'\\n\');\n',{mode:0o700});
if(nativeMcpUrl)execFileSync(process.execPath,['--check',join(workspace,'native-mcp-url-browser.mjs')]);
const mcpArgs=[];
if(mcpOAuth){
 const config=join(workspace,'mcp-fixture.json');await writeFile(config,JSON.stringify({mcpServers:{research:{type:'http',url:oauthServer.origin+'/mcp'}}}));mcpArgs.push('--mcp-config',config,'--strict-mcp-config');
}else if(mcpScenario||genericPermissions||mcpElicitation){
 if(mcpResources)await writeFile(join(workspace,'mcp-resource-expectations.json'),JSON.stringify({resourceText,resourceBlob:resourceBlob.toString('base64'),resourceUris}));
 const bootstrap=join(workspace,'mcp-fixture.mjs'),children=join(workspace,'mcp-children.jsonl'),exits=join(workspace,'mcp-exits.jsonl');
 await writeFile(bootstrap,`import {appendFileSync} from 'node:fs';import {execFileSync} from 'node:child_process';const ancestors=[];let ancestor=process.ppid;while(ancestor>1&&ancestors.length<16){ancestors.push(ancestor);try{ancestor=Number(execFileSync('/bin/ps',['-p',String(ancestor),'-o','ppid='],{encoding:'utf8'}).trim())}catch{break}}appendFileSync(${JSON.stringify(children)},JSON.stringify({pid:process.pid,ppid:process.ppid,ancestors})+'\\n');process.once('exit',code=>appendFileSync(${JSON.stringify(exits)},JSON.stringify({pid:process.pid,code})+'\\n'));process.once('SIGTERM',()=>process.exit(0));await import(${JSON.stringify(new URL(mcpElicitation?(modernMcpUrl?'../protocol/synthetic-modern-elicitation-server.mjs':'../protocol/synthetic-app-elicitation-server.mjs'):genericPermissions?'../protocol/synthetic-generic-permission-server.mjs':mcpResources?'../protocol/synthetic-mcp-resource-server.mjs':'../protocol/synthetic-mcp-server.mjs',import.meta.url).href)});`);
 execFileSync(process.execPath,['--check',bootstrap]);
 const config=join(workspace,'mcp-fixture.json');
 await writeFile(config,JSON.stringify({mcpServers:{research:{type:'stdio',command:process.execPath,args:[bootstrap],env:{APACK_MCP_ELICITATION_RECEIPT:join(workspace,'mcp-elicitation-receipts.jsonl'),APACK_MCP_RECEIPT:join(workspace,'mcp-receipts.jsonl'),...(mcpDirectory?{APACK_MCP_DIRECTORY:'1'}:{}),...(nativeMcpUrl?{APACK_MCP_URL_CONTROL_ROOT:workspace}:{}),...(mcpBrowser?{APACK_MCP_URL_BROWSER_ORIGIN:mcpBrowser.origin}:{})}}}}));
 mcpArgs.push('--mcp-config',config,'--strict-mcp-config');
}
if(bashScenario&&process.env.CLAUDE_RESEARCH_TERMINAL_PLACEMENTS==='1')await writeFile(join(workspace,'native-bash-wait.py'),BASH_RELEASE_SCRIPT);
if(activeToolCancel)await writeFile(join(workspace,'native-bash-wait.py'),(shellDesktop?'print("Owned release review is waiting.",flush=True)\n':'')+'import pathlib,time,os,json\np=pathlib.Path(__file__).with_name("native-bash-release");stat=pathlib.Path("/proc/self/stat").read_text().split(") ",1)[1].split();pathlib.Path(__file__).with_name("native-active-bash-ready.json").write_text(json.dumps({"pid":os.getpid(),"ppid":os.getppid(),"pgid":os.getpgrp(),"start":stat[19]}));end=time.monotonic()+60\nwhile not p.exists() and time.monotonic()<end: time.sleep(0.05)\n');
async function holdEverydayDecision(name){
 const stem=name==='Read'?'read':'question';
 await writeFile(join(workspace,'everyday-'+stem+'-ready.json'),JSON.stringify({ready:true}));
 const deadline=Date.now()+8000;
 while(Date.now()<deadline){try{await access(join(workspace,'everyday-'+stem+'-release'));return}catch(error){if(error.code!=='ENOENT')throw error}await new Promise(resolve=>setTimeout(resolve,25));}
 throw new Error('Everyday decision draft barrier expired: '+name);
}
let releaseLargeRead;const largeReadReady=new Promise(resolve=>{releaseLargeRead=resolve});
let largeReadTimer;if(largeDocuments||pendingApprovalFailure)largeReadTimer=setInterval(()=>{void access(join(workspace,'release-large-read')).then(()=>{releaseLargeRead();clearInterval(largeReadTimer);},()=>{});},50);
if(toolPermissions){
 const token=randomUUID(),ready=join(workspace,'native-tool-permission-offline-ready.json');
 await writeFile(ready,JSON.stringify({token,pid:process.pid}));
 const deadline=Date.now()+90000;let isolated=false;
 while(Date.now()<deadline){
  const proof=await readFile(join(workspace,'native-tool-permission-network-disabled.json'),'utf8').then(JSON.parse,error=>{if(error.code!=='ENOENT')throw error;return undefined;});
  if(proof?.token===token&&proof.networkDisabled===true){isolated=true;break;}
  await new Promise(resolve=>setTimeout(resolve,50));
 }
 if(!isolated)throw Error('Owned offline network boundary was not confirmed before native startup');
}
const quotaHeaders=agentBilling?{'anthropic-ratelimit-unified-status':'allowed','anthropic-ratelimit-unified-representative-claim':'five_hour','anthropic-ratelimit-unified-reset':String(Math.floor(Date.now()/1000)+3600)}:undefined;
const seed = lspRecommendation==='yes'?await startSyntheticLspModel(workspace,{seedUntilInstalled:true}):await startSyntheticModel(workspace,'TextOnly',{rateLimitHeaders:quotaHeaders,...(mcpElicitation&&!nativeMcpForm&&!nativeMcpUrl?{mcpElicitations:true,maxRequests:24}:{}),captureSystem:configCallbacks||configDesktop,captureEffort:configDesktop,captureMessages:!!refusalNotice||!!pluginHint||workflowResumeEligibility||completionNavigation||managedModelRestart||notebookImages||bashImage||populatedResumeUpload||agentRoundtrip||externalConsent||mcpElicitation||planScenario==='rename'||promptThemeEveryday||savedPlan,...(promptThemeEveryday?{textReply:'Ready to review the release notes. Your session is saved.'}:{})}), agent = agentBilling ? await startSyntheticAgentModel({rateLimitHeaders:quotaHeaders,parentLaunchOnce:true,childDelayMs:7500,requestLimit:8,captureMessages:true}) : backgroundConfirmation ? await startSyntheticAgentModel({workflowProbe:true,workflowScript:WORKFLOW_APPROVAL_FIXTURE_SCRIPT,holdChildUntilRelease:true,parentLaunchOnce:true,captureMessages:true,...(childInteractionApp?{referenceFile,questionProbe:true,everydayProbe:true,requestLimit:16}:{...(childReplyApp?{everydayProbe:true}:{}),requestLimit:childResumeApp||childReplyApp?16:12})}) : backgroundHandoff ? await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:12}) : refusalNotice ? await startSyntheticModel(workspace,'Refusal',{refusalCategory:'cyber',refusalCount:2,...(process.env.CLAUDE_RESEARCH_REFUSAL_EMPTY_DRAFT==='1'?{refusalText:''}:{}),captureMessages:true,maxRequests:6}) : completionNavigation ? await startSyntheticAgentModel({parentLaunchOnce:true,childDelayMs:7500,requestLimit:8,captureMessages:true,agentClassifierSafe:true}) : managedModelRestart ? await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:6,textReply:'The model review is complete.'}) : bashImage ? await startSyntheticModel(workspace,'Bash',{forceBash:true,bashImage:true,captureMessages:true,maxRequests:4}) : agentSettingsRoutes||agentHelpDesktop ? await startSyntheticAgentModel({parentLaunchOnce:true,childDelayMs:7500,requestLimit:8,captureMessages:true}) : nativeModelDesktop ? await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:4,textReply:'The selected model handled the review.'}) : bareMode ? await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:4,textReply:'Bare session review complete.'}) : searchReview ? await startSyntheticModel(workspace,'SearchReview',{captureMessages:true,maxRequests:16}) : nativeMcpForm||nativeMcpUrl ? await startSyntheticModel(workspace,'TextOnly',{mcpElicitations:true,...(nativeMcpUrl?{mcpUrlElicitations:true}:{}),captureMessages:true,maxRequests:nativeMcpUrl?24:16}) : pendingApprovalFailure ? await startSyntheticAgentModel({referenceFile,referenceRetry:true,everydayProbe:true,launchAgent:false,parentLaunchOnce:true,requestLimit:8,captureMessages:true,beforeDecision:async()=>{await writeFile(join(workspace,'large-read-ready'),'ready');await largeReadReady;}}) : largeDocuments ? await startSyntheticAgentModel({referenceFile,everydayProbe:true,launchAgent:false,parentLaunchOnce:true,requestLimit:8,captureMessages:true,beforeDecision:async()=>{await writeFile(join(workspace,'large-read-ready'),'ready');await largeReadReady;}}) : handbackOwner ? await startSyntheticAgentModel({handbackProbe:true,handbackMessage:HANDBACK_RELEASE_REPORT,handbackClassifierUnavailable:true,parentLaunchOnce:true,requestLimit:16,captureMessages:true}) : genericPermissions ? await startSyntheticModel(workspace,'TextOnly',{genericPermissions:true,captureMessages:true,maxRequests:20}) : toolPermissions ? await startSyntheticModel(workspace,'TextOnly',{toolPermissions:true,captureMessages:true,maxRequests:24}) : notebookEdit ? await startSyntheticModel(workspace,'TextOnly',{notebookEdits:true,captureMessages:true,maxRequests:8}) : heldModelPause ? await startSyntheticModel(workspace,'TextOnly',{heldModel:true,heldModelStreaming,heldModelRich,captureMessages:true,maxRequests:4}) : activeToolCancel ? await startSyntheticModel(workspace,'Bash',{forceBash:true,bashPerInput:true,bashReleaseFile:join(workspace,'native-bash-release'),captureMessages:true,maxRequests:4}) : pluginHint ? await startSyntheticModel(workspace,'Bash',{forceBash:true,bashCommand:PLUGIN_HINT_COMMAND,captureMessages:true,maxRequests:4}) : lspRecommendation ? await startSyntheticModel(workspace,'Edit',{maxRequests:6,captureMessages:true}) : lspReview ? await startSyntheticLspModel(workspace,{lifecycle:lspLifecycle,lifetime:lspLifetime,unload:lspUnload}) : systemPolicy ? await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,textReply:'Managed policy review complete.',maxRequests:4}) : readMedia ? await startSyntheticModel(workspace,'TextOnly',{readMedia:true,readMediaPages,readMediaPageSuccess,captureMessages:true,maxRequests:8}) : heldSubagent ? await startSyntheticAgentModel({backgroundAgent:true,childDelayMs:15000,holdChildUntilRelease:true,parentLaunchOnce:true,requestLimit:8}) : focusBash ? await startSyntheticModel(workspace,'BashBackground',{captureMessages:true,maxRequests:10}) : focusSummary ? await startSyntheticAgentModel({backgroundAgent:true,childDelayMs:15000,holdChildUntilRelease:true,parentLaunchOnce:true,requestLimit:12}) : focusContext ? await startSyntheticModel(workspace,'TextOnly',{pairedText:true,focusContextTool:!focusSummary,thinkingBlock:focusSummary,narration:focusSummary,captureMessages:true,maxRequests:8}) : promptThemeEveryday ? await startSyntheticAgentModel({referenceFile,questionProbe:true,everydayProbe:true,...(questionOwnerFailure?{questionRecoveryProbe:true,launchAgent:false,captureMessages:true}:{}),beforeDecision:holdEverydayDecision,parentLaunchOnce:true,childDelayMs:15000,requestLimit:16,onPauseRequest:()=>writeFile(join(workspace,'native-pause-ready.json'),JSON.stringify({ready:true}))}) : promptThemeAgent ? await startSyntheticAgentModel({parentLaunchOnce:true,childDelayMs:7500,requestLimit:everydayRich?10:8,agentClassifierSafe:windowAgent,captureMessages:everydayRich||process.env.CLAUDE_RESEARCH_AGENT_STRUCTURED==='1'||agentSource||agentMediaBoundary||windowAgent||process.env.CLAUDE_RESEARCH_AGENT_REFERENCE==='1'||process.env.CLAUDE_RESEARCH_AGENT_IME==='1'}) : questionForms ? await startSyntheticModel(workspace,'AskUserQuestion',{questionExtended:true,captureMessages:true,maxRequests:12}) : planScenario==='parent-commands' ? await startSyntheticAgentModel({parentLaunchOnce:true,launchAgent:false,childDelayMs:7500,requestLimit:16}) : ['agent-layout','task-controls','task-steering'].includes(planScenario) ? await startSyntheticAgentModel({workflowProbe:pendingWorkflow,...(workflowStanding?{workflowName:'release-review',workflowGrantScope}:{}),captureMessages:workflowDeny||workflowResume||workflowUnsettled,...(workflowResume?{workflowResumeProbe:true,workflowWorkspace:workspace,workflowScript:WORKFLOW_RESUME_FIXTURE_SCRIPT}:{}),...(workflowProgress?{workflowScript:WORKFLOW_PROGRESS_FIXTURE_SCRIPT}:{}),...(workflowUnsettled?{workflowScript:WORKFLOW_UNSETTLED_SCRIPT,workflowReturnBarrier:signal=>waitForWorkflowStop(workspace,{signal})}:{}),...(workflowWithheld?{workflowScript:WORKFLOW_APPROVAL_FIXTURE_SCRIPT.replace('; return await','; /* LARGE_WORKFLOW_FIXTURE:'+'x'.repeat(200010)+'*/ return await')}:{}),backgroundAgent:pendingDuration,childDelayMs:15000,holdChildUntilRelease:planScenario==='task-controls',parentLaunchOnce:planScenario==='task-steering'||pendingDuration,requestLimit:workflowGrantScope||workflowResume?16:planScenario==='task-steering'||pendingWorkflow?12:undefined,steeringProbe:planScenario==='task-steering'}) : mcpScenario ? await startSyntheticModel(workspace,mcpResources?'ListMcpResourcesTool':'mcp__research__echo',{mcpResources,mcpResourceDirectory:mcpDirectory,captureMessages:true,maxRequests:8}) : rewindScenario ? await startSyntheticFileModel(workspace) : planScenario ? await startSyntheticModel(workspace,['fork','revert','resume','import','onboarding-import','direct-resume','rename','client','client-fields','theme','composer-layout'].includes(planScenario)?'TextOnly':['enter','auto-enter'].includes(planScenario)?'EnterPlanMode':planScenario==='empty'?'ExitPlanMode':'TuiPlan',{captureSystem:configCallbacks||configDesktop,captureEffort:configDesktop,...(stagedDirectories?{directoryReadFiles:[referenceFile,secondDirectoryFile]}:{}),captureMessages:true,maxRequests:8,...(planScenario==='withheld'?{planText:'X'.repeat(200001)}:{})}) : fileScenario ? await startSyntheticFileModel(workspace,{requestDelayMs:fileStanding?1000:0,longReview:fileLayout}) : bashScenario ? await startSyntheticModel(workspace,'Bash',{forceBash:true,bashStandingRule:bashStanding,bashPerInput:true,bashDelayMs:bashStanding?0:process.env.CLAUDE_RESEARCH_TERMINAL_PLACEMENTS==='1'?0:5000,...(process.env.CLAUDE_RESEARCH_TERMINAL_PLACEMENTS==='1'?{bashReleaseFile:join(workspace,'native-bash-release')}:{}),captureMessages:true,maxRequests:8}) : await startSyntheticAgentModel({referenceFile,questionProbe:true,questionPreviewFormat:previewMode,childDelayMs:12000,onPauseRequest:()=>writeFile(join(workspace,'native-pause-ready.json'),JSON.stringify({ready:true}))});
let leftArrowReviewerReported=false;
let resetTaskChildObserved=false;
let pendingDurationTimer;if(leftArrowApp||handbackOwner||heldSubagent||pendingDuration||focusSummary&&!focusBash)pendingDurationTimer=setInterval(async()=>{if(leftArrowApp&&!leftArrowReviewerReported&&agent.calls.some(row=>row.child)){leftArrowReviewerReported=true;await writeFile(join(workspace,'native-leftarrow-reviewer-ready.json'),JSON.stringify({originalChildRequest:true,index:agent.calls.findIndex(row=>row.child)}));}if(resetTask&&!resetTaskChildObserved&&agent.calls.some(row=>row.child)){resetTaskChildObserved=true;await writeFile(join(workspace,'native-reset-task-provider-started'),'original child request held');}try{await access(join(workspace,'native-pending-duration-release'));agent.releaseChild();clearInterval(pendingDurationTimer);if(resetTask){await Promise.resolve();const child=agent.calls.find(row=>row.child);await writeFile(join(workspace,'native-reset-task-provider-released.json'),JSON.stringify({heldReleased:child?.heldReleased===true,disconnectedWhenReleased:child?.disconnectedWhenReleased===true}));}}catch(error){if(error.code!=='ENOENT')throw error}},50);
let parentDelayTimer,parentDelayArmed=false,parentDelayObserved=false;
if(planScenario==='parent-commands'||focusQueue)parentDelayTimer=setInterval(async()=>{if(parentDelayArmed){if(focusQueue&&!parentDelayObserved&&agent.calls.some(call=>call.delayedMs&&!call.delivered)){parentDelayObserved=true;await writeFile(join(workspace,'native-parent-delay-active'),'active')}return}try{await access(join(workspace,'native-parent-delay-request'));parentDelayArmed=true;agent.delayNextParentResponse(6000);await writeFile(join(workspace,'native-parent-delay-ready'),'ready')}catch(error){if(error.code!=='ENOENT')throw error}},50);
const plugin=join(workspace,'prompt-fixture');await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'native-history-fixture',version:'0.0.1',...(process.env.CLAUDE_RESEARCH_SETTINGS_EDITORS==='1'?{userConfig:{reviewNote:{type:'string',title:'Review note',description:'Release review note',default:'Original release note'},reviewCount:{type:'number',title:'Review count',description:'Bounded review count',default:2,min:1,max:9}}}:{})}));
await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
const promptFixture=`export function register(on){let draw=0;on('prompt.submit',async($,e,next)=>{if(e.text==='DropNativeHistoryFixture'){await $.fs.write('native-drop-observed.json',JSON.stringify({text:e.text}));return {drop:'Native history fixture refused'};}return next(e.text==='RewriteNativeHistoryFixture'?{...e,text:'NativeSubagentParentFixture: run the disposable status worker.'}:e);});on('ui.render',{component:'AskUserQuestion'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Text({children:['Native question tools '+draw]}),Button({key:'question-redraw',label:'Refresh question decoration',onPress:async()=>{draw++;await $.fs.write('native-question-hook-callback.json',JSON.stringify({draw,requestId:e.requestId}));$.ui.invalidate('ui.render');}}),await next({...e,props:{...e.props,questions:e.props.questions.map(q=>({...q,question:'Display '+draw+': '+q.question}))}})]});});}`;
if(planScenario==='theme'){
 await mkdir(join(workspace,'.claude/themes'),{recursive:true});
 await writeFile(join(workspace,'.claude/themes/research.json'),JSON.stringify({name:'Research',base:'light',overrides:{text:'#123456',success:'rgb(17,34,51)',warning:'#abcdef',suggestion:'#445566'}}));
}
await writeFile(join(plugin,'hooks/register.ts'),questionForms||fileStanding||mcpResources?'export function register(on) {}':promptFixture);
if(['task-steering','task-controls'].includes(planScenario))await writeFile(join(plugin,'hooks/register.ts'),promptFixture.replace('let draw=0;',`let draw=0;on('ui.render',{component:'UserMessage'},async($,e,next)=>{if(e.surface!=='desktop'||!e.props.text.startsWith('NativeAgentSteerFixture: reply from the focused Agent composer.'))return next(e);const{Box,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next(e),Button({key:'check-message-draft',label:'Check message draft',onPress:async()=>$.fs.write('native-agent-message-hook.json',JSON.stringify({uuid:e.requestId,origin:e.props.origin,box:await $.prompt.read()}))})]});});on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);const agentId=e.props.view?.agentId;return Box({flexDirection:'column',children:agentId?[Text({children:['Agent controls']}),Button({key:'read-agent-draft',label:'Read this draft',onPress:async()=>$.fs.write('native-agent-draft-read.json',JSON.stringify({agentId,box:await $.prompt.read()}))})]:[Button({key:'view-worker',label:'View native worker',onPress:async()=>{const task=(await $.agent.list()).find(task=>task.type==='status-fixture');if(!task)throw Error('No native worker exists');const result=await $.ui.view({agentId:task.id});await $.fs.write('native-view-button.json',JSON.stringify({taskId:task.id,result}));}})]});});`));
if(planScenario==='parent-commands')await writeFile(join(plugin,'hooks/register.ts'),promptFixture.replace('let draw=0;',"let draw=0;const prompts=[];").replace("on('prompt.submit',async($,e,next)=>{","on('prompt.submit',async($,e,next)=>{prompts.push({text:e.text});await $.fs.write('native-parent-prompt-hooks.json',JSON.stringify(prompts));"));
if(planScenario==='parent-commands')await writeFile(join(plugin,'hooks/register.ts'),(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace("export function register(on){","export function register(on){const edits=[];on('prompt.edit',async($,e,next)=>{const original=await next(e);const structured='**Native structured title**\\n\\n*   first\\n*   second';const result=original.text==='NativeStructureFixture'?{...original,text:structured,cursor:structured.length,decorations:[{start:structured.indexOf('first'),end:structured.indexOf('first')+5,color:'#ffaa00'},{start:structured.indexOf('second'),end:structured.indexOf('second')+6,underline:true}]}:original;edits.push({text:e.text,cursor:e.cursor,by:e.by,key:e.key,result});await $.fs.write('native-main-prompt-edits.json',JSON.stringify(edits.slice(-32)));return result;});"));
if(planScenario==='parent-commands')await writeFile(join(plugin,'hooks/register.ts'),(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace("export function register(on){","export function register(on){on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Button}=$.ui.resolve(e);return Button({key:'read-structured',label:'Read structured draft',onPress:async()=>$.fs.write('native-structure-read.json',JSON.stringify(await $.prompt.read()))});});"));
if(planScenario==='parent-commands')await writeFile(join(plugin,'hooks/register.ts'),(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace("export function register(on){","export function register(on){on('ui.render',{component:'CommandOutput'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next({...e,props:{...e.props,text:'Native command result: '+e.props.command}}),Button({key:'inspect-command',label:'Inspect native command result',onPress:async()=>$.fs.write('native-command-output-hook.json',JSON.stringify({requestId:e.requestId,props:e.props,box:await $.prompt.read()}))})]});});"));
if(bashScenario)await writeFile(join(plugin,'hooks/register.ts'),(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace("export function register(on){","export function register(on){on('ui.render',{component:'SessionMode'},async($,e,next)=>{if(e.surface==='desktop'){await $.fs.write('native-composer-mode-hook.json',JSON.stringify({requestId:e.requestId,props:e.props}));return next({...e,props:{...e.props,modes:[...e.props.modes,'Native fixture mode']}});}await $.fs.write('native-session-mode-input.json',JSON.stringify({surface:e.surface,requestId:e.requestId,props:e.props}));return next(e);});on('ui.render',{component:'PromptHint'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);await $.fs.write('native-composer-hint-hook.json',JSON.stringify({requestId:e.requestId,props:e.props}));return next({...e,props:{...e.props,hint:e.props.isDraft?'Draft ready from native hook':'Native hook idle'}});});on('ui.render',{component:'Spinner'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);await $.fs.write('native-composer-spinner-hook.json',JSON.stringify({requestId:e.requestId,props:e.props}));const{Box,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next({...e,props:{...e.props,word:'Native activity '+e.props.word}}),Button({key:'inspect-activity',label:'Inspect activity',onPress:async()=>$.fs.write('native-composer-spinner-action.json',JSON.stringify({requestId:e.requestId,props:e.props,box:await $.prompt.read()}))})]});});"));
if(bashScenario||fileScenario&&!fileStanding)await writeFile(join(plugin,'hooks/register.ts'),(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace("export function register(on){","export function register(on){const expandedGroups=new Set();on('ui.render',{component:'ToolGroup'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);await $.fs.write('native-tool-group-'+e.requestId+'.json',JSON.stringify({requestId:e.requestId,props:e.props}));const{Box,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next({...e,props:{...e.props,isExpanded:expandedGroups.has(e.requestId)?true:e.props.isExpanded}}),Button({key:'inspect-group',label:'Inspect tool group',onPress:async()=>{await $.fs.write('native-tool-group-callback.json',JSON.stringify({requestId:e.requestId,props:e.props,box:await $.prompt.read()}));expandedGroups.add(e.requestId);$.ui.invalidate('ui.render');}})]});});"));
if(bashScenario)await writeFile(join(plugin,'hooks/register.ts'),(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace("export function register(on){","export function register(on){on('ui.render',{component:'ToolUse'},async($,e,next)=>{if(e.surface==='desktop')await $.fs.write('native-bash-tool-use.json',JSON.stringify({requestId:e.requestId,props:e.props}));return next(e);});on('ui.render',{component:'ToolProgress'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);await $.fs.write('native-bash-tool-progress.json',JSON.stringify({requestId:e.requestId,props:e.props}));return next({...e,props:{...e.props,hint:'Native background hint: '+e.props.hint}});});"));
if(fileScenario&&!clientLifetime&&!fileStanding)await writeFile(join(plugin,'hooks/register.ts'),(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace("export function register(on){","export function register(on){on('ui.render',{component:'ToolUse'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);await $.fs.write('native-tool-use-'+e.props.tool_use_id+'.json',JSON.stringify({requestId:e.requestId,props:e.props}));if(e.props.tool_use_id!=='file_fixture_1')return next(e);return next({...e,props:{...e.props,tool:'ShownWrite',input:{...e.props.input,file_path:'display-only.txt'}}});});"));
if(fileScenario&&!fileStanding)await writeFile(join(plugin,'hooks/register.ts'),(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace("export function register(on){","export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface!=='desktop'||e.props.tool_use_id!=='file_fixture_1')return next(e);const{Box,Button}=$.ui.resolve(e);const output=e.props.tool==='Write'&&e.props.output?.type==='create'?{...e.props.output,content:'Rewritten native tool result\\n'}:e.props.output;return Box({flexDirection:'column',children:[await next({...e,props:{...e.props,output}}),Button({key:'inspect-result',label:'Inspect native tool result',onPress:async()=>$.fs.write('native-tool-result-hook.json',JSON.stringify({requestId:e.requestId,props:e.props,box:await $.prompt.read()}))})]});});"));
if(clientLifetime){
 const register=join(plugin,'hooks/register.ts');
 let hook=await readFile(register,'utf8');
 hook=hook.replace("e.props.tool_use_id!=='file_fixture_1'","!['file_fixture_1','file_read_3'].includes(e.props.tool_use_id)");
 hook=hook.replace("const{Box,Button}=$.ui.resolve(e);const output=","const{Box,Button,Client}=$.ui.resolve(e);const output=").replace("children:[await next({...e,props:{...e.props,output}})","children:[Client({key:'result-client',module:'./lifetime-client.ts',props:{name:e.props.tool_use_id==='file_read_3'?'group-result':'result'},width:'100%',height:3}),await next({...e,props:{...e.props,output}})");
 hook=hook.replace("export function register(on){","export function register(on){const lifetime={};on('ui.message',async($,e)=>{const name=e.data.name;lifetime[name]={...e.data,posts:(lifetime[name]?.posts??0)+1};await $.fs.write('native-client-lifetime.json',JSON.stringify(lifetime));return {props:{name}};});on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Client}=$.ui.resolve(e);return Client({key:'above-client',module:'./lifetime-client.ts',props:{name:'above'},width:'100%',height:1});});");
 await writeFile(register,hook);
 await writeFile(join(plugin,'hooks/lifetime-client.ts'),`export default function(props,s){const{Box,Text,Button}=s.elements;const post=()=>s.post({name:props.name,...s.state});if(s.state===undefined){s.setState({ticks:0,pressed:0,key:'none'});s.every(200,()=>{s.setState({...s.state,ticks:s.state.ticks+1});post();});}s.onKey(e=>{s.setState({...s.state,key:e.key});post();});return Box({flexDirection:'column',children:[Text({children:[props.name+' ticks='+s.state.ticks+' pressed='+s.state.pressed+' key='+s.state.key]}),...(props.name!=='above'?[Button({key:'action',label:'Result action',onPress:()=>{s.setState({...s.state,pressed:s.state.pressed+1});post();}})]:[])]});}`);
}
if(scenario==='managed-transition'){
 const register=join(plugin,'hooks/register.ts');
 await writeFile(register,(await readFile(register,'utf8')).replace('export function register(on){',"export function register(on){let posts=0;on('ui.render',{component:'InfoNotice'},async($,e,next)=>e.surface==='terminal'?next({...e,props:{...e.props,text:'Policy notice: '+e.props.text}}):next(e));on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Client}=$.ui.resolve(e);return Client({key:'policy-clock',module:'./policy-client.ts',props:{},width:'100%',height:1});});on('ui.message',async($,e,next)=>{if(e.data?.kind!=='policy-clock')return next(e);await $.fs.write('native-policy-client.json',JSON.stringify({...e.data,posts:++posts}));return {props:{}};});"));
 await writeFile(join(plugin,'hooks/policy-client.ts'),"export default function(props,s){const{Text}=s.elements;if(s.state===undefined){s.setState({ticks:0,key:'none'});s.every(100,()=>{s.setState({...s.state,ticks:s.state.ticks+1});s.post({kind:'policy-clock',...s.state});});}s.onKey(e=>{s.setState({...s.state,key:e.key});s.post({kind:'policy-clock',...s.state});});return Text({children:['Policy Client ticks='+s.state.ticks+' key='+s.state.key]});}");
}
if(planScenario==='theme')await writeFile(join(plugin,'hooks/register.ts'),promptFixture.replace('let draw=0;',`let draw=0;on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const{Box,Text,Button,Input,Select}=$.ui.resolve(e);const note=await $.fs.read('native-theme-note.txt').catch(()=>''),choice=await $.fs.read('native-theme-choice.txt').catch(()=>'a');return Box({key:'theme-scope',borderStyle:'single',borderColor:'warning',backgroundColor:'inverseText',children:[Text({color:'success',children:['Native themed label']}),Input({key:'theme-note',label:'Theme note',placeholder:'Write a note',value:note,onInput:async value=>{await $.fs.write('native-theme-note.txt',value);$.ui.invalidate('ui.render');},onSubmit:async value=>{await $.fs.write('native-theme-note-submitted.txt',value);$.ui.invalidate('ui.render');}}),Select({key:'theme-choice',label:'Theme choice',value:choice,options:[{value:'a',label:'Current session'},{value:'b',label:'Next session'}],onSelect:async value=>{await $.fs.write('native-theme-choice.txt',value);$.ui.invalidate('ui.render');}}),Button({key:'theme-action',label:'Native theme action',variant:'primary',hover:{color:'warning'},onPress:async()=>$.fs.write('native-theme-action.txt','pressed')})]});});`));
if(documentTheme){
 const docs="Link({href:'https://example.com/native-document-link',label:'Native document link'}),Markdown({key:'native-document',text:\"Native document paragraph with **bold words** and [native callback](https://example.com/native-document-callback).\\n\\n```javascript\\nconst nativeMarkdownValue = \\\"document\\\";\\n```\\n\\n| Native | Value |\\n| --- | --- |\\n| Markdown | 42 |\",onLinkPress:async link=>$.fs.write('native-document-link.json',JSON.stringify(link))}),Code({source:\"const nativeThemeValue = \\\"document\\\";\\nconsole.log(nativeThemeValue);\",language:'javascript',startLine:3}),Code({source:\"@@ -1 +1 @@\\n-const nativeThemeDiff = 1;\\n+const nativeThemeDiff = 2;\",language:'javascript',format:'diff'}),";
 const code=(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace('const{Box,Text,Button,Input,Select}=$.ui.resolve(e)','const{Box,Text,Button,Input,Select,Link,Markdown,Code}=$.ui.resolve(e)').replace("children:[Text({color:'success'","children:["+docs+"Text({color:'success'");
 await writeFile(join(plugin,'hooks/register.ts'),code);
}

if(largeDocuments)await addNativeLargeDocumentFixture(plugin,workspace);
if(planScenario==='direct-resume')await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.message',async($,e,next)=>{if(e.data?.kind!=='resume-checkpoint')return next(e);const rows=JSON.parse(await $.fs.read('native-resume-client-receipts.json').catch(()=>'[]'));rows.push(e.data);await $.fs.write('native-resume-client-receipts.json',JSON.stringify(rows));return {props:{}};});on('ui.render',{component:'UserMessage'},async($,e,next)=>{if(e.surface!=='desktop'||!e.props.text.startsWith('NativeForkCheckpointAlpha: remember this source-only marker.'))return next(e);const{Box,Client}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next(e),Client({key:'checkpoint-review',module:'./resume-client.ts',props:{},width:'100%',height:3})]});});on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Button}=$.ui.resolve(e);return Button({key:'review-resumed-draft',label:'Review resumed draft',onPress:async()=>{const result=await $.prompt.read();const rows=JSON.parse(await $.fs.read('native-resume-draft-receipts.json').catch(()=>'[]'));rows.push({requestId:e.requestId,result});await $.fs.write('native-resume-draft-receipts.json',JSON.stringify(rows));}});});}`);
if(planScenario==='direct-resume')await writeFile(join(plugin,'hooks/resume-client.ts'),`export default function(props,s){const{Box,Text,Button}=s.elements;if(s.state===undefined)s.setState({pressed:0});return Box({flexDirection:'column',children:[Text({children:['Checkpoint review count '+s.state.pressed]}),Button({key:'review',label:'Review imported checkpoint',onPress:()=>{const pressed=s.state.pressed+1;s.setState({pressed});s.post({kind:'resume-checkpoint',pressed});}})]});}`);
if(historyReopen)await addNativeHistoryReopenFixture(plugin);

if(planScenario==='client'){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){let visible=true,label='initial';on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const{Box,Button,Client}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Button({key:'props',label:'Update Client props',onPress:()=>{label='changed';$.ui.invalidate('ui.render');}}),Button({key:'toggle',label:'Toggle Client',onPress:()=>{visible=!visible;$.ui.invalidate('ui.render');}}),...(visible?[Client({key:'counter',module:'./client.ts',props:{label},width:'100%',height:6,flexGrow:1})]:[])]});});on('ui.message',async($,e,next)=>{await $.fs.write('native-client-message.json',JSON.stringify(e));return {props:{label:'reply'}};});}`);
 await writeFile(join(plugin,'hooks/client.ts'),`export default function(props,s){const{Box,Text,Button}=s.elements;if(s.state===undefined){s.setState({count:0,ticks:0,key:'none',xy:'none'});s.every(1000,()=>s.setState({...s.state,ticks:s.state.ticks+1}));}s.onKey(e=>{s.setState({...s.state,key:e.key});s.post({key:e.key});});s.onPointer(e=>s.setState({...s.state,xy:e.x+','+e.y}));return Box({flexDirection:'column',children:[Text({children:['Native Client label='+props.label+' count='+s.state.count+' tick='+s.state.ticks+' key='+s.state.key+' xy='+s.state.xy+' room='+s.columns+'x'+s.rows]}),Button({key:'increment',label:'Increment Client',onPress:()=>s.setState({...s.state,count:s.state.count+1})})]});}`);
}
if(planScenario==='client-fields'){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){const fields=[],completed=[];on('ui.input',async($,e,next)=>{fields.push(e);await $.fs.write('native-client-field-events.json',JSON.stringify(fields));const before=await $.clock.now();await $.clock.sleep(60,{signal:next.signal});completed.push({value:e.value,elapsed:(await $.clock.now())-before});await $.fs.write('native-client-field-completed.json',JSON.stringify(completed));return next(e.value==='RewriteField'?{...e,value:'NativeRewritten'}:e);});on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const{Box,Client}=$.ui.resolve(e);return Box({flexDirection:'row',children:['A','B'].map(name=>Client({key:name,module:'./client.ts',props:{name},width:'49%',height:14}))});});on('ui.message',async($,e,next)=>{await $.fs.write('native-client-message.json',JSON.stringify(e));return {props:{name:e.data.name,reply:e.data.key}};});}`);
 await writeFile(join(plugin,'hooks/client.ts'),`export default function(props,s){const{Box,Text,Input,Select}=s.elements;if(s.state===undefined){s.setState({draft:'',choice:'a',submitted:'',key:'none',ticks:0});s.every(25,()=>s.setState({...s.state,ticks:s.state.ticks+1}));}s.onKey(e=>{s.setState({...s.state,key:e.key});s.post({name:props.name,key:e.key});});return Box({flexDirection:'column',children:[Text({children:['Client '+props.name+' key='+s.state.key+' submitted='+s.state.submitted+' room='+s.columns+'x'+s.rows]}),Input({key:'draft',label:props.name+' draft',value:s.state.draft,onInput:value=>s.setState({...s.state,draft:value}),onSubmit:value=>s.setState({...s.state,submitted:value})}),Select({key:'choice',label:props.name+' choice',value:s.state.choice,options:[{value:'a',label:'Alpha'},{value:'b',label:'Beta'}],onSelect:value=>s.setState({...s.state,choice:value})})]});}`);
}
if(capabilityProfile)await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Markdown}=$.ui.resolve(e);return Markdown({key:'native-capability-note',text:'Review **current session** and [session details](https://example.com/native-session-details).',onLinkPress:async link=>$.fs.write('native-capability-link.json',JSON.stringify(link))});});}`);
if(promptTheme){
 await writeFile(join(workspace,'.claude/themes/research.json'),JSON.stringify({name:'Research',base:'dark',overrides:{text:'#e5e7eb',success:'#8ac49a',warning:'#abcdef',inverseText:'#263241',suggestion:'#c4b5fd'}}));
 await writeFile(join(workspace,'main.py'),`import json,sys,pathlib,os\np=json.load(sys.stdin)\npathlib.Path(${JSON.stringify(join(workspace,'helper-bun-options.txt'))}).write_text(os.environ.get('BUN_OPTIONS','unset'))\nprint('\\x1b[32mSession ready\\x1b[0m')\nprint('Reviewing release notes')\n`);
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){const edits=[];on('prompt.edit',async($,e,next)=>{const original=await next(e);const result={...original,decorations:original.text.length?[{start:0,end:Math.min(6,original.text.length),color:'warning',backgroundColor:'inverseText'}]:[]};edits.push({text:e.text,cursor:e.cursor,origin:e.origin,key:e.key,start:e.start,end:e.end,inputText:e.inputText,result});await $.fs.write('native-prompt-theme-edits.json',JSON.stringify(edits.slice(-64)));return result;});on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Text({children:['Review the current release notes.']}),Button({key:'review-template',label:'Use review template',onPress:async()=>{const before=await $.prompt.read();const result=await $.prompt.fill({text:'Review release notes before merging.',decorations:[{start:0,end:6,color:'warning',backgroundColor:'inverseText'}]});const after=await $.prompt.read();await $.fs.write('native-prompt-theme-fill.json',JSON.stringify({before,result,after}));}})]});});}`);
}
if(uiSelection&&promptThemeAgent){
 const fixture=await readFile(join(plugin,'hooks/register.ts'),'utf8');
 await writeFile(join(plugin,'hooks/register.ts'),fixture.replace('export function register(on){',`export function register(on){const excerpts=[],copies=[];on('prompt.autocomplete',{token:/^#/},async($,e,next)=>({suggestions:[{text:e.token+'-complete',label:'Complete '+e.token}]}));on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next(e),Button({key:'review-excerpt',label:'Review selected excerpt',onPress:async()=>{const before=await $.prompt.read(),value=await $.ui.selection();excerpts.push({before,view:e.props.view,selected:value!==undefined,...(value?{value}:{})});await $.fs.write('native-agent-selection-receipts.json',JSON.stringify(excerpts));$.ui.invalidate('ui.render');}}),...(excerpts.at(-1)?.value?[Text({children:[excerpts.at(-1).value.text]}),Button({key:'copy-excerpt',label:'Copy reviewed excerpt',onPress:async()=>{const text=excerpts.at(-1).value.text,result=await $.ui.copy({text,surface:'desktop'});copies.push({text,result,view:e.props.view});await $.fs.write('native-agent-copy-receipts.json',JSON.stringify(copies));}})]:[])]});});`));
}
if(promptRichSelection){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Button}=$.ui.resolve(e);return Box({children:[Button({key:'rich-review',label:'Use review template',onPress:async()=>{const before=await $.prompt.read(),owner=before.text.toLowerCase().includes('worker')?'Worker':'Parent',text='# '+owner+' review\\n\\n'+String.fromCharCode(96).repeat(3)+'ts\\nconst ready = true\\n'+String.fromCharCode(96).repeat(3)+'\\n\\nReview changes.'${process.env.CLAUDE_RESEARCH_AGENT_REFERENCE==='1'?"+(before.text.includes('apack-ref://thread/')?' [Reference]('+before.text.slice(before.text.indexOf('apack-ref://thread/')).split(')')[0]+')':'')":''},start=text.indexOf('Review changes.');const result=await $.prompt.fill({text,decorations:[{start,end:start+6,bold:true}]});await $.fs.write('native-rich-draft-fill.json',JSON.stringify({before,result,after:await $.prompt.read()}));}}),Button({key:'read-review',label:'Read current draft',onPress:async()=>$.fs.write('native-rich-draft-read.json',JSON.stringify(await $.prompt.read()))})]});});}`);
}
if(agentRoundtrip){const source=await readFile(join(plugin,'hooks/register.ts'),'utf8');const before="JSON.stringify(await $.prompt.read())";assert.ok(source.includes(before));await writeFile(join(plugin,'hooks/register.ts'),source.replace(before,"JSON.stringify({...await $.prompt.read(),view:e.props.view})"));}
if(process.env.CLAUDE_RESEARCH_AGENT_STRUCTURED==='1')await writeFile(join(plugin,'hooks/register.ts'),nativeAgentStructuredHook());
if(activeToolCancel||process.env.CLAUDE_RESEARCH_CONFIG_THEME==='1'||process.env.CLAUDE_RESEARCH_AGENT_SETTINGS==='1'||process.env.CLAUDE_RESEARCH_COMMAND_INTERACTIONS==='1')await writeFile(join(plugin,'hooks/register.ts'),'export function register(){}');
if(agentSource)await writeFile(join(plugin,'hooks/register.ts'),"export function register(on){const edits=[],reads=[];on('prompt.edit',async($,e,next)=>{const original=await next(e);if(e.origin?.kind!=='composer'||!original.text.endsWith(' outline'))return original;const text='  '+original.text.slice(0,-8)+'\\n\\n~~~~ts\\nconst ready = true\\n~~~~  ',cursor=text.indexOf('~~~~')+1,result={...original,text,cursor,decorations:[{start:text.indexOf('~~~~'),end:text.lastIndexOf('~~~~')+4,color:'warning',underline:true}]};edits.push({input:original.text,result});await $.fs.write('native-agent-source-edits.json',JSON.stringify(edits));return result;});on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Button}=$.ui.resolve(e);return Button({key:'read-source-review',label:'Read review draft',onPress:async()=>{reads.push({view:e.props.view,value:await $.prompt.read()});await $.fs.write('native-agent-source-reads.json',JSON.stringify(reads));}});});}");
if(promptRichSelection&&process.env.CLAUDE_RESEARCH_AGENT_IME==='1'){
 const fixture=await readFile(join(plugin,'hooks/register.ts'),'utf8');
 await writeFile(join(plugin,'hooks/register.ts'),fixture.replace('export function register(on){',"export function register(on){const edits=[];on('prompt.edit',async($,e,next)=>{const result=await next(e);edits.push({before:e.text,inputText:e.inputText,text:result.text,cursor:result.cursor,origin:e.origin});await $.fs.write('native-agent-ime-edits.json',JSON.stringify(edits.slice(-128)));return result;});"));
}
if(promptStructured){
 const outline='# Release review\n\n```ts\nconst ready = true\n```\n\nReview changes.',append=promptSyntax?'\n\n*   __Verify behavior__\n*   Document migration':'\n\n* Verify behavior\n* Document migration';
 const steps=[{label:'Use review outline',mode:promptMedia?'append':'replace',text:promptMedia?'\n\n'+outline:outline,paint:'Review changes.'},{label:'Add release checklist',mode:'append',text:append,paint:'Verify behavior',syntax:promptSyntax},{label:'Add review note',mode:'insert',text:'Please ',paint:'Please'}];
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){let phase=0;const receipts=[],steps=${JSON.stringify(steps)};on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop'||phase>=steps.length)return next(e);const{Button}=$.ui.resolve(e);const step=steps[phase];return Button({key:'review-outline',label:step.label,onPress:async()=>{const before=await $.prompt.read(),at=step.text.indexOf(step.paint),input={text:step.text,mode:step.mode,decorations:[{start:step.syntax?step.text.indexOf('*')+1:at,end:at+step.paint.length+(step.syntax?1:0),bold:true,underline:step.syntax===true,color:'warning'}]},result=await $.prompt.fill(input),after=await $.prompt.read();receipts.push({mode:step.mode,input,before,result,after});await $.fs.write('native-structured-prompt-receipts.json',JSON.stringify(receipts));if(result.isFilled){phase++;$.ui.invalidate('ui.render');}}});});}`);
 if(promptAllSelection){
  const fixture=await readFile(join(plugin,'hooks/register.ts'),'utf8');
  await writeFile(join(plugin,'hooks/register.ts'),fixture.replace('export function register(on){',`export function register(on){const reads=[];on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next(e),Button({key:'read-selected-draft',label:'Read selected draft',onPress:async()=>{reads.push(await $.prompt.read());await $.fs.write('native-all-selection-reads.json',JSON.stringify(reads));}})]});});`));
 }
 if(uiSelection){
  const fixture=await readFile(join(plugin,'hooks/register.ts'),'utf8');
  await writeFile(join(plugin,'hooks/register.ts'),fixture.replace('export function register(on){',`export function register(on){const selections=[];on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next(e),Button({key:'review-excerpt',label:'Review selected excerpt',onPress:async()=>{const value=await $.ui.selection();selections.push({selected:value!==undefined,...(value?{value}:{})});await $.fs.write('native-selection-receipts.json',JSON.stringify(selections));$.ui.invalidate('ui.render');}}),...(selections.length?[Text({children:[selections.at(-1).value?.text??'No text selected']})]:[])]});});`));
 }
 if(uiCopy){
  const fixture=await readFile(join(plugin,'hooks/register.ts'),'utf8');
  await writeFile(join(plugin,'hooks/register.ts'),fixture.replace('let phase=0;','let phase=0;const copies=[];').replace("const{Button}=$.ui.resolve(e);const step=steps[phase];",`const{Button}=$.ui.resolve(e);if(copies.length<7)return Button({key:'copy-checklist',label:'Copy release checklist',onPress:async()=>{const text=copies.length===4?'漢'.repeat(1000000):copies.length===5?'👋'.repeat(500000):copies.length===6?String.fromCharCode(92,10).repeat(500000):copies.length===3?'x'.repeat(1000001):'Release checklist '+copies.length+'\\nVerify behavior 👋',result=await $.ui.copy({text,surface:'desktop'});copies.push({textLength:text.length,...(text.length<1000?{text}:{}),result});await $.fs.write('native-copy-receipts.json',JSON.stringify(copies));$.ui.invalidate('ui.render');}});const step=steps[phase];`));
 }
}
if(multipleWindows){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){const receipts=[];on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Button}=$.ui.resolve(e);return Box({children:[Button({key:'window-read',label:'Read window draft',onPress:async()=>{receipts.push({kind:'read',before:await $.prompt.read()});await $.fs.write('native-multiple-window-receipts.json',JSON.stringify(receipts));}}),Button({key:'window-fill',label:'Fill window draft',onPress:async()=>{const before=await $.prompt.read(),result=await $.prompt.fill({text:'Original first-client fill.',mode:'replace'});receipts.push({kind:'fill',before,result,after:await $.prompt.read()});await $.fs.write('native-multiple-window-receipts.json',JSON.stringify(receipts));}})]});});}`);
}
if(multipleWindowSelection){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){const reads=[],copies=[],prompts=[];let selected;on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Button({key:'window-selection',label:'Review window selection',onPress:async()=>{selected=await $.ui.selection();reads.push({selected:selected!==undefined,...(selected?{value:selected}:{})});await $.fs.write('native-window-selection-receipts.json',JSON.stringify(reads));$.ui.invalidate('ui.render');}}),Button({key:'window-copy',label:'Copy window selection',onPress:async()=>{const text=selected?.text??'',result=await $.ui.copy({text,surface:'desktop'});copies.push({text,result});await $.fs.write('native-window-copy-receipts.json',JSON.stringify(copies));}}),Button({key:'focused-read',label:'Read focused draft',onPress:async()=>{prompts.push({before:await $.prompt.read()});await $.fs.write('native-window-focused-prompt-receipts.json',JSON.stringify(prompts));}}),Button({key:'focused-fill',label:'Fill focused draft',onPress:async()=>{const result=await $.prompt.fill({text:'Popout native fill.',mode:'replace'});prompts.push({result,after:await $.prompt.read()});await $.fs.write('native-window-focused-prompt-receipts.json',JSON.stringify(prompts));}}),...(selected?[Text({children:[selected.text]})]:[])]});});}`);
}
if(windowAgent){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){const receipts=[];on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Button}=$.ui.resolve(e);return Box({children:[Button({key:'active-read',label:'Read active composer',onPress:async()=>{receipts.push({box:await $.prompt.read()});await $.fs.write('native-window-agent-receipts.json',JSON.stringify(receipts));}}),Button({key:'active-fill',label:'Fill active composer',onPress:async()=>{const result=await $.prompt.fill({text:'Native focused worker draft.',mode:'replace'});receipts.push({result,box:await $.prompt.read()});await $.fs.write('native-window-agent-receipts.json',JSON.stringify(receipts));}})]});});}`);
}
if(stagedDirectories||composerPhase)await writeFile(join(plugin,'hooks/register.ts'),'export function register(on){}');
if(promptThemeStale){
 const fixture=await readFile(join(plugin,'hooks/register.ts'),'utf8');
 const autocomplete="on('prompt.autocomplete',{token:/^#/},async($,e,next)=>({suggestions:[{text:e.token+'-complete',label:'Complete '+e.token}]}));";
 const suggest="Button({key:'next-step',label:'Suggest next step',onPress:async()=>{const result=await $.prompt.suggest({text:'Review the remaining release checklist.'});await $.fs.write('native-prompt-suggest.json',JSON.stringify(result));}})";
 const readButton=(promptThemeReverse||promptThemeReconnect)?",Button({key:'read-current',label:'Read current draft',onPress:async()=>$.fs.write('native-prompt-read.json',JSON.stringify(await $.prompt.read()))})":'';
 assert.ok(fixture.includes('}})]});});}'));
 await writeFile(join(plugin,'hooks/register.ts'),fixture.replace('const edits=[];','const edits=[];'+autocomplete).replace('}})]});});}', '}}),'+suggest+readButton+']});});}'));
}
if(promptFontResets)await writeFile(join(plugin,'hooks/register.ts'),promptLineResets?LINE_RESET_PLUGIN:FONT_RESET_PLUGIN);
if(promptBoundaries)await writeFile(join(plugin,'hooks/register.ts'),"export function register(on){let rewritten=false;const edits=[];on('prompt.edit',async($,e,next)=>{const original=await next(e);let result=original;if(!rewritten&&e.origin?.kind==='composer'&&original.text.endsWith(' outline')){rewritten=true;const text=original.text.slice(0,-8)+'\\n\\n~~~ts\\nconst ready = true\\n~~~';result={...original,text,cursor:text.indexOf('ready')+5,decorations:[{start:text.indexOf('~~~')+1,end:text.lastIndexOf('~~~')+2,underline:true,color:'warning'}]};await $.fs.write('native-prompt-boundary-rewrite.json',JSON.stringify(result));}edits.push({origin:e.origin,text:e.text,cursor:e.cursor,result});await $.fs.write('native-prompt-boundary-edits.json',JSON.stringify(edits.slice(-128)));return result;});on('prompt.submit',async($,e,next)=>{await $.fs.write('native-prompt-boundary-submit.json',JSON.stringify({text:e.text}));return next(e);});}");
if(actionKeysApp)await writeFile(join(plugin,'hooks/register.ts'),actionKeyPanesApp?nativeActionPaneAppHook:actionKeyDialogApp?nativeActionDialogAppHook:nativeActionAppHook);
if(fieldBounds)await writeFile(join(plugin,'hooks/register.ts'),"export function register(on){let notes='Release review notes\\n'+'original detail '.repeat(1600)+'\\nEnd of original notes.  ',saved=false,written=false;const receipts=[];on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Input}=$.ui.resolve(e);if(!written){written=true;await $.fs.write('native-field-bounds-initial.json',JSON.stringify({value:notes,rows:80}));}return Box({flexDirection:'column',children:[...(saved?[Text({children:['Review notes saved']})]:[]),Input({key:'review-notes',label:'Release review notes',submitLabel:'save',rows:80,value:notes,onInput:async value=>{notes=value;receipts.push({kind:'change',value});await $.fs.write('native-field-bounds-receipts.json',JSON.stringify(receipts));},onSubmit:async value=>{notes=value;saved=true;receipts.push({kind:'submit',value});await $.fs.write('native-field-bounds-receipts.json',JSON.stringify(receipts));$.ui.invalidate('ui.render');}})]});});}");
if(promptSource)await writeFile(join(plugin,'hooks/register.ts'),"export function register(on){let phase=0,source,uriCursor;const receipts=[];on('prompt.edit',async($,e,next)=>{const original=await next(e);let result=original;if(phase===0&&e.origin?.kind==='composer'&&original.text.endsWith(' outline')){source='  '+original.text.slice(0,-8)+'\\n\\n~~~~ts\\nconst ready = true\\n~~~~  ';uriCursor=source.indexOf('apack-ref://')+'apack-ref://'.length+3;result={...original,text:source,cursor:uriCursor};phase=1;receipts.push({stage:'uri',input:original.text,result});}else if(phase===1&&original.text===source.slice(0,uriCursor)+' '+source.slice(uriCursor)){result={...original,text:source,cursor:source.indexOf('~~~~')+1,decorations:[{start:source.indexOf('~~~~'),end:source.lastIndexOf('~~~~')+4,underline:true,color:'warning'}]};phase=2;receipts.push({stage:'fence',input:original.text,result});}if(receipts.length)await $.fs.write('native-prompt-source-receipts.json',JSON.stringify(receipts));return result;});on('prompt.submit',async($,e,next)=>{await $.fs.write('native-prompt-boundary-submit.json',JSON.stringify({text:e.text}));return next(e);});}");
if(sourceFill)await writeFile(join(plugin,'hooks/register.ts'),"export function register(on){let phase=0,offered=true;const receipts=[],submits=[];on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop'||!offered||phase>=2)return next(e);const{Button}=$.ui.resolve(e);return Button({key:'prepare-review',label:phase===0?'Prepare release review':'Start fresh review',onPress:async()=>{const operations=phase===0?[{mode:'append',text:'\\n\\n~~~ts\\nconst ready = true\\n~~~'},{mode:'insert',text:'\\nReview linked notes.',decorations:[{start:1,end:21,color:'warning',underline:true}]}]:[{mode:'replace',text:'~~~ts\\nconst fresh = true\\n~~~'},{mode:'append',text:'\\nFresh review notes.'}];for(const input of operations){const before=await $.prompt.read(),result=await $.prompt.fill(input),after=await $.prompt.read();receipts.push({phase,input,before,result,after});await $.fs.write('native-source-fill-receipts.json',JSON.stringify(receipts));if(!result.isFilled)throw Error('Native source fill refused');}offered=false;$.ui.invalidate('ui.render');}});});on('prompt.submit',async($,e,next)=>{if(!offered&&phase<2){submits.push({phase,text:e.text});phase++;offered=phase<2;await $.fs.write('native-source-fill-submits.json',JSON.stringify(submits));$.ui.invalidate('ui.render');}return next(e);});}");
if(promptThemeText){
 const modes=['wrap','end','middle','truncate','truncate-start','truncate-middle','truncate-end'];
 const rows=modes.map(wrap=>`Text({wrap:${JSON.stringify(wrap)},children:[Text({bold:true,children:['Release notes: ']}),Text({children:['/workspace/projects/desktop/integrations/claude-code/research/release-candidates/2026/october/verified/']}),Link({href:'https://example.test/releases',children:[Text({italic:true,children:['release-summary.md']})]})]})`).join(',');
 const resetRow="Box({key:'review-style',children:[Text({bold:true,italic:true,underline:true,strikethrough:true,dimColor:true,children:['Checks pending ',Text({bold:false,italic:false,underline:false,strikethrough:false,dimColor:false,children:['Release ready']}),Text({children:['Inherited review']}),Text({hover:{scope:'review-detail',bold:false,italic:false,underline:false,strikethrough:false,dimColor:false},children:['Review detail']})]}),Text({hover:{scope:'review-detail',color:'success'},children:['Review detail trigger']})]})";
 const hook=await readFile(join(plugin,'hooks/register.ts'),'utf8');
 await writeFile(join(plugin,'hooks/register.ts'),hook.replace('const{Box,Text,Button}=$.ui.resolve(e);','const{Box,Text,Button,Link}=$.ui.resolve(e);').replace("Text({children:['Review the current release notes.']})",`Box({flexDirection:'column',children:[${resetRow},${rows}]})`).replace('export function register(on){',"export function register(on){on('ui.render',{component:'PromptHint'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Text}=$.ui.resolve(e);return Text({hover:{scope:'review-detail',color:'success'},children:['Release review ready']});});"));
}
if(restingHover)await addNativeRestingHoverFixture(plugin,workspace);
if(textMeasurement)await addNativeTextMeasurementFixture(plugin,workspace);
if(textDirection)await addNativeTextDirectionFixture(plugin,workspace);
if(promptThemeEveryday){
 await writeFile(join(workspace,'.claude/agents/release-reviewer.md'),'---\nname: release-reviewer\ndescription: Review release changes and migration notes\ntools: []\n---\nNativeStatusChildSystem. Review the release notes and return concise guidance.\n'.replaceAll('\\n','\n'));
 await writeFile(join(workspace,'main.py'),`import json,sys,pathlib,os\np=json.load(sys.stdin)\npathlib.Path(${JSON.stringify(join(workspace,'helper-bun-options.txt'))}).write_text(os.environ.get('BUN_OPTIONS','unset'))\nprint('\\x1b[32mRelease review\\x1b[0m')\nprint('Workspace notes and checklist')\n`);
 await writeFile(join(workspace,'sub.py'),`import json,sys,pathlib\np=json.load(sys.stdin)\npathlib.Path(${JSON.stringify(join(workspace,'everyday-agent-status-input.json'))}).write_text(json.dumps(p))\nfor t in p['tasks']:\n print(json.dumps({'id':t['id'],'content':'Review complete' if t['status']=='completed' else 'Reviewing release notes'}))\n`);
 await writeFile(join(plugin,'hooks/register.ts'),'export function register(on){}');
}
if(refusalNotice||pluginHint||shellDesktop||settingsRoutes||agentSettingsRoutes||helpDesktop||settingsBrokerLoss||bashImage||notebookImages||managedModelRestart||completionNavigation||workflowResumeEligibility){
 assert.ok(!promptTheme,'Desktop shell acceptance uses its own minimal status fixture, not another prompt-theme journey');
 await writeFile(join(workspace,'main.py'),"import json,sys\np=json.load(sys.stdin)\nprint('Session ready')\nprint('Reviewing release notes')\n");
 await writeFile(join(plugin,'hooks/register.ts'),'export function register(on){}');
}
if(completionNavigation){
 await writeFile(join(workspace,'sub.py'),`import json,sys\np=json.load(sys.stdin)\nfor t in p['tasks']:\n print(json.dumps({'id':t['id'],'content':'Review complete' if t['status']=='completed' else 'Reviewing release notes'}))\n`);
}
if(helpDesktop){
 await mkdir(join(workspace,'.claude/commands'),{recursive:true});
 await writeFile(join(workspace,'.claude/commands/review-release.md'),'---\ndescription: Review the release checklist and report remaining risks.\n---\nReview the release checklist. Do not change files.\n');
}
if(bashImage){
 const png=process.env.CLAUDE_RESEARCH_BASH_IMAGE_LARGE==='1'?createNativeLargeTestImage().toString('base64'):'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=';
 await writeFile(join(workspace,'release-cover.png'),Buffer.from(png,'base64'));
 await writeFile(join(workspace,'emit-release-image.py'),'import base64,pathlib\nprint("data:image/png;base64,"+base64.b64encode(pathlib.Path(__file__).with_name("release-cover.png").read_bytes()).decode())\n');
 await writeFile(join(plugin,'hooks/register.ts'),"export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&e.props.tool_use_id==='toolu_research_fixture')await $.fs.write('native-bash-image-result.json',JSON.stringify({props:e.props}));return next(e)});}");
}
if(completionNavigation)await writeFile(join(plugin,'hooks/register.ts'),nativeCompletionNavigationHook());
if(nativeModelDesktop)await addNativeModelPanelFixture(workspace);
let quotaEnv;
if(agentBilling){
 assert.ok((await readFile('/control/offline-verified','utf8')).trim());
 quotaEnv=await configureNativeCreditAccount(workspace);
 const configPath=join(workspace,'.claude/.claude.json'),config=JSON.parse(await readFile(configPath,'utf8'));delete config.cachedGrowthBookFeatures;await writeFile(configPath,JSON.stringify(config));
 const settingsPath=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(settingsPath,'utf8'));delete settings.apiKeyHelper;delete settings.statusLine;delete settings.subagentStatusLine;await writeFile(settingsPath,JSON.stringify(settings));
 await writeFile(join(plugin,'hooks/register.ts'),'export function register(on) {}');
 await writeFile(join(workspace,'native-quota-fixture-inputs.json'),JSON.stringify({headers:quotaHeaders,profile:'synthetic OAuth; no status helpers, no extension drawings, no credit feature flags',firstPartyStartup:'container-only HTTPS hello/profile; no billing mutations'}));
}
let creditTls,creditEnv,creditBilling;
if(nativeCreditDesktop||agentBilling){
 const offline=await readFile('/control/offline-verified','utf8');assert.ok(offline.trim(),'Offline container receipt required');
 const hosts=await readFile('/etc/hosts','utf8');for(const host of ['api.anthropic.com','claude.ai','platform.claude.com'])assert.ok(hosts.split('\n').some(line=>{const [ip,...names]=line.trim().split(/\s+/);return ip==='127.0.0.1'&&names.includes(host)}),'Container-only original billing host mapping required: '+host);
 if(nativeCreditDesktop)creditEnv=await configureNativeCreditAccount(workspace,['admin','admin-error'].includes(nativeCreditScenario)?'oauth-team':'oauth');
 creditTls=await prepareNativeCreditTls(join(workspace,'native-credit-tls'));
 if(nativeCreditDesktop){const path=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(path,'utf8'));delete settings.apiKeyHelper;await writeFile(path,JSON.stringify(settings));}
}
if(focusSummary)await writeFile(join(plugin,'hooks/register.ts'),'export function register(on) {}');
if(process.env.CLAUDE_RESEARCH_POLICY_BORROWED_CLIENT==='1'&&process.env.CLAUDE_RESEARCH_POLICY_HELD_CLIENT!=='1')throw Error('Borrowed policy Client requires held-policy profile');
if(process.env.CLAUDE_RESEARCH_POLICY_HELD_CLIENT==='1'){if(scenario!=='managed-transition')throw Error('Held-policy Client needs the private transition profile');await addNativePolicyHeldClientFixture(workspace,plugin,{borrowed:process.env.CLAUDE_RESEARCH_POLICY_BORROWED_CLIENT==='1'});}
if(process.env.CLAUDE_RESEARCH_PROMPT_TIMEOUT==='1'){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){let sequence=0;on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const{Button}=$.ui.resolve(e);return Button({key:'timeout-read',label:'Read current draft',onPress:async()=>{const call=++sequence,started=Date.now();try{const result=await $.prompt.read();await $.fs.write('native-timeout-read-'+call+'.json',JSON.stringify({call,started,finished:Date.now(),result}));}catch(error){await $.fs.write('native-timeout-read-'+call+'.json',JSON.stringify({call,started,finished:Date.now(),error:String(error)}));throw error;}}});});}`);
}
if(process.env.CLAUDE_RESEARCH_TOOL_WIDTH==='1'){
 const source='Review the release checklist carefully and preserve the current configuration. Keep migration notes readable across narrow windows and return to the same session after inspecting the result.';
 await writeFile(join(workspace,'native-tool-width-source.json'),JSON.stringify({source}));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface!=='desktop'||e.props.tool_use_id!=='file_fixture_1')return next(e);await $.fs.write('native-tool-width-original.json',JSON.stringify(e.props));return next({...e,props:{...e.props,output:{...e.props.output,content:${JSON.stringify(source)}}}});});}`);
}
if(managedMedia)await addNativeManagedMediaFixture(workspace,userPreload,plugin);
if(rootIme)await addNativeRootImeFixture(plugin);
if(backgroundHandoff)await writeFile(join(plugin,'hooks/register.ts'),'export function register(on) {}');
if(process.env.CLAUDE_RESEARCH_BACKGROUND_STATUS_APP==='1')await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){const seen=new Set();let httpCount=0;on('http.fetch',async($,e,next)=>{if(httpCount<128&&['http://apack/background-register','http://apack/background-status'].includes(e.url)){let body;try{body=JSON.parse(e.init?.body??'{}')}catch{}if(body?.sessionId){const at=await $.clock.now();await $.fs.write('native-background-http-'+body.sessionId+'-'+at+'-'+(httpCount++)+'.json',JSON.stringify({sessionId:body.sessionId,at,path:e.url,pid:body.pid,sequence:body.sequence}));}}return next(e);});on('session.start',async($,e,next)=>{const sessionId=await $.session.id();await $.fs.write('native-background-start-'+sessionId+'.json',JSON.stringify({sessionId,agentId:e.agentId??null}));return next(e);});on('ui.render',{component:'SessionMode'},async($,e,next)=>{const sessionId=await $.session.id();if(!seen.has(sessionId)&&seen.size<8){seen.add(sessionId);let identity;try{const result=await $.process.run(['/bin/sh','-c','printf "%s" "$PPID"'],{timeoutMs:3000});identity={pid:Number(result.stdout.trim()),exitCode:result.exitCode,stderr:result.stderr.slice(0,256)};}catch(error){identity={error:String(error).slice(0,256)}}await $.fs.write('native-background-mode-'+sessionId+'.json',JSON.stringify({sessionId,surface:e.surface,identity,model:await $.session.model()}));}return next(e);});}`);

await writeFile(userPreload,await adaptNativeResearchPreload(checkout,await readFile(userPreload,'utf8')));
const launcher = join(workspace,'native-app-launcher.cjs');
if(workflowUnsettled)await writeFile(join(workspace,'research-workflow-stop-preload.mjs'),await adaptNativeResearchPreload(checkout,`import {createHash} from 'node:crypto';import {readFileSync} from 'node:fs';import {holdAndObserveWorkflowStops} from ${JSON.stringify(new URL('../protocol/owned-workflow-stop.mjs',import.meta.url).href)};const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),loopState=await import('/$bunfs/root/chunk-tnpfcesk.js');holdAndObserveWorkflowStops({directory:process.env.CLAUDE_RESEARCH_WORKFLOW_DIRECTORY,workspace:${JSON.stringify(workspace)},snapshot(id){const binding=runtime.ey();if(binding?.surface!=='terminal')return;const task=Object.values(binding.toolContext(new AbortController()).taskRegistry.all()).find(task=>task.id===id);return task?{id:task.id,type:task.type,status:task.status,settled:loopState.AE(id),stoppedByUser:task.stoppedByUser,result:task.result}:undefined;}});`));
if(promptFontResets)await writeFile(join(workspace,'research-font-reset-preload.mjs'),`import {observePromptFontResets} from ${JSON.stringify(new URL('../protocol/native-prompt-font-reset.mjs',import.meta.url).href)};observePromptFontResets({directory:process.env.CLAUDE_RESEARCH_FONT_DIRECTORY,workspace:${JSON.stringify(workspace)}});`);
if(activeToolPause)await writeFile(join(workspace,'research-turn-observer-preload.mjs'),`import {observeOwnedTurnControls} from ${JSON.stringify(new URL('../protocol/owned-turn-control-observer.mjs',import.meta.url).href)};observeOwnedTurnControls({directory:process.env.CLAUDE_RESEARCH_TURN_DIRECTORY,workspace:${JSON.stringify(workspace)}});`);
if(promptThemeStale)await writeFile(join(workspace,'research-ui-delay-preload.mjs'),`import {installOwnedUiDelay} from ${JSON.stringify(new URL('../protocol/owned-ui-host-delay.mjs',import.meta.url).href)};installOwnedUiDelay({directory:process.env.CLAUDE_RESEARCH_BROKER_DIRECTORY,workspace:${JSON.stringify(workspace)}});`);
if(everydayRich)await writeFile(join(plugin,'hooks/register.ts'),'export function register(){}');
await writeFile(launcher,`#!/usr/bin/env node
const {spawn}=require('node:child_process');const{appendFileSync,readFileSync,writeFileSync}=require('node:fs');
const args=process.argv.slice(2);
if(${JSON.stringify(promptThemeStale)}&&!args.includes('--print')){const match=(process.env.BUN_OPTIONS??'').match(new RegExp('--preload=(/(?:private/)?tmp/cc-app-[A-Za-z0-9_-]+)/status[.]mjs'));if(!match)throw Error('Missing owned native broker preload');appendFileSync(${JSON.stringify(join(workspace,'native-owned-broker.jsonl'))},JSON.stringify({directory:match[1]})+'\\n');}
if(${JSON.stringify(!!capabilityProfile)}&&!args.includes('--print'))appendFileSync(${JSON.stringify(join(workspace,'native-capability-launch.jsonl'))},JSON.stringify({FORCE_COLOR:process.env.FORCE_COLOR??null,FORCE_HYPERLINK:process.env.FORCE_HYPERLINK??null,NO_COLOR:process.env.NO_COLOR??null})+'\\n');
const env={...process.env,...${JSON.stringify(nativeMcpUrl?{BROWSER:join(workspace,'native-mcp-url-browser.mjs')}:mcpOAuth?{BROWSER:join(workspace,'owned-browser.py')}:{})},ENABLE_TOOL_SEARCH:${JSON.stringify(planScenario?'0':undefined)},CLAUDE_CODE_QUESTION_PREVIEW_FORMAT:${JSON.stringify(previewMode)},...(${JSON.stringify(questionForms)}?{CLAUDE_CODE_ENTRYPOINT:'sdk-cli',CLAUDE_CODE_QUESTION_EXTENDED:'1',CLAUDE_CODE_QUESTION_OPTIONAL_DESCRIPTIONS:'1'}:{}),HOME:${JSON.stringify(workspace)},CLAUDE_CONFIG_DIR:${JSON.stringify(join(workspace,'.claude'))},ANTHROPIC_BASE_URL:args.includes('--print')?${JSON.stringify(seed.url)}:${JSON.stringify(agent.url)}};
// The everyday cost proof compares one resumed turn against its native result and journal.
if(${JSON.stringify(process.env.CLAUDE_RESEARCH_ISOLATE_TURN_COST==='1')})env.CLAUDE_CODE_ENABLE_PROMPT_SUGGESTION='0';
if(${JSON.stringify(!!refusalNotice)})env.ANTHROPIC_DEFAULT_OPUS_MODEL='claude-opus-4-8';
if(${JSON.stringify(handbackOwner)}&&!args.includes('--print')){const at=args.indexOf('--permission-mode');if(at>=0)args[at+1]='auto';else args.push('--permission-mode','auto');env.CLAUDE_CODE_SENDMESSAGE_HANDBACK='1';}
if(${JSON.stringify(focusContext)}&&!args.includes('--print'))env.CLAUDE_CODE_NO_FLICKER='1';
if(${JSON.stringify(leftArrowLookupTrace)}&&!args.includes('--print')){env.BUN_OPTIONS='--preload='+${JSON.stringify(new URL('../protocol/native-leftarrow-lookup-trace.mjs',import.meta.url).pathname)}+' '+env.BUN_OPTIONS;}
if(${JSON.stringify(leftArrowApp)}&&!args.includes('--print')){env.BUN_OPTIONS='--preload='+${JSON.stringify(new URL('../protocol/native-leftarrow-observation.mjs',import.meta.url).pathname)}+' '+env.BUN_OPTIONS;}
if(${JSON.stringify(clientLifecycle)}&&!args.includes('--print')){env.BUN_OPTIONS='--preload='+${JSON.stringify(join(workspace,'research-client-load-preload.mjs'))}+' '+env.BUN_OPTIONS;}
if(${JSON.stringify(promptThemeStale)}&&!args.includes('--print')){const match=(env.BUN_OPTIONS??'').match(new RegExp('--preload=(/(?:private/)?tmp/cc-app-[A-Za-z0-9_-]+)/status[.]mjs'));env.CLAUDE_RESEARCH_BROKER_DIRECTORY=match[1];env.BUN_OPTIONS='--preload='+${JSON.stringify(join(workspace,'research-ui-delay-preload.mjs'))}+' '+env.BUN_OPTIONS;}
if(${JSON.stringify(workflowUnsettled)}&&!args.includes('--print')){const match=(env.BUN_OPTIONS??'').match(new RegExp('--preload=((?:/private)?/tmp/cc-app-[A-Za-z0-9_-]+)/status[.]mjs'));if(!match)throw Error('Owned native Workflow directory missing');env.CLAUDE_RESEARCH_WORKFLOW_DIRECTORY=match[1];env.BUN_OPTIONS='--preload='+${JSON.stringify(join(workspace,'research-workflow-stop-preload.mjs'))}+' '+env.BUN_OPTIONS;}
if(${JSON.stringify(promptFontResets)}&&!args.includes('--print')){const match=(env.BUN_OPTIONS??'').match(new RegExp('--preload=((?:/private)?/tmp/cc-app-[A-Za-z0-9_-]+)/status[.]mjs'));if(!match)throw Error('Owned font audit directory missing');env.CLAUDE_RESEARCH_FONT_DIRECTORY=match[1];env.BUN_OPTIONS='--preload='+${JSON.stringify(join(workspace,'research-font-reset-preload.mjs'))}+' '+env.BUN_OPTIONS;}
if(${JSON.stringify(activeToolPause)}&&!args.includes('--print')){const match=(env.BUN_OPTIONS??'').match(new RegExp('--preload=((?:/private)?/tmp/cc-app-[A-Za-z0-9_-]+)/status[.]mjs'));if(!match)throw Error('Owned native preload directory missing');env.CLAUDE_RESEARCH_TURN_DIRECTORY=match[1];env.BUN_OPTIONS='--preload='+${JSON.stringify(join(workspace,'research-turn-observer-preload.mjs'))}+' '+env.BUN_OPTIONS;}
if(${JSON.stringify(updateDecisions)})for(const key of ['DISABLE_AUTOUPDATER','DISABLE_UPDATES','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC'])delete env[key];
if(${JSON.stringify(!!pluginHint)})delete env.CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC; // Generic fixture switch also suppresses native recommendations; network-none remains authoritative.
for(const key of ['CLAUDE_CODE_SIMPLE','CLAUDE_CODE_COORDINATOR_MODE','ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])delete env[key];
if(${JSON.stringify(agentBilling)})Object.assign(env,${JSON.stringify(quotaEnv??{})},${JSON.stringify(creditTls?{NODE_EXTRA_CA_CERTS:creditTls.ca}:{})});
if(${JSON.stringify(bareMode)}&&args.includes('--bare'))env.ANTHROPIC_API_KEY='research-fixture-key';
if(${JSON.stringify(nativeCreditDesktop)}){for(const key of ['CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC','DISABLE_TELEMETRY','DISABLE_GROWTHBOOK','CLAUDE_INTERNAL_FC_OVERRIDES','CLAUDE_CODE_CUSTOM_OAUTH_URL'])delete env[key];Object.assign(env,${JSON.stringify(creditEnv??{})},${JSON.stringify(creditTls?{NODE_EXTRA_CA_CERTS:creditTls.ca}:{})});}
Object.assign(env,${JSON.stringify(planScenario==='composer-layout'?{"ANTHROPIC_CUSTOM_MODEL_OPTION": "native-catalog-model-mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm", "ANTHROPIC_CUSTOM_MODEL_OPTION_NAME": "NativeCatalogLabelStart Long model label Long model label Long model label Long model label Long model label Long model label Long model label Long model label Long model label Long model label Long model label Long model label  NativeCatalogLabelEnd", "ANTHROPIC_CUSTOM_MODEL_OPTION_DESCRIPTION": "NativeCatalogDescriptionStart Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail Native model detail  NativeCatalogDescriptionEnd"}:{})});
if(process.platform==='linux')delete env.NODE_OPTIONS;
if(${JSON.stringify(agentBilling)}){
 const selected=Object.fromEntries(['HOME','CLAUDE_CONFIG_DIR','ANTHROPIC_BASE_URL','BUN_OPTIONS','NODE_OPTIONS','TERM','CLAUDE_CODE_ENTRYPOINT','CLAUDE_CODE_ENABLE_SDK_FILE_CHECKPOINTING','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC','DISABLE_NONESSENTIAL_TRAFFIC','ENABLE_TOOL_SEARCH'].map(key=>[key,env[key]??null]));
 const preloads=[];for(const match of (env.BUN_OPTIONS??'').matchAll(/--preload=([^ ]+)/g)){
  const path=match[1].startsWith('file:')?require('node:url').fileURLToPath(match[1]):match[1];
  if(!path.startsWith(${JSON.stringify(workspace)}+'/')&&!new RegExp('^/tmp/(cc-print-clients-[A-Za-z0-9_-]+/clients|cc-app-[A-Za-z0-9_-]+/status)[.]mjs$').test(path))throw Error('Unexpected Agent billing preload path');
  const bytes=readFileSync(path);if(bytes.length>2097152)throw Error('Unexpected Agent billing preload size');
  const saved=${JSON.stringify(join(workspace,'native-launch-preload-'))}+preloads.length+'.mjs';writeFileSync(saved,bytes,{mode:0o600});preloads.push({path,saved,sha256:require('node:crypto').createHash('sha256').update(bytes).digest('hex')});
 }
 appendFileSync(${JSON.stringify(join(workspace,'native-launch-context.jsonl'))},JSON.stringify({at:Date.now(),launcherPid:process.pid,cwd:process.cwd(),args,env:selected,environmentKeys:Object.keys(env).sort(),preloads})+'\\n');
}
const child=spawn(${JSON.stringify(executable)},['--debug-file',${JSON.stringify(join(workspace,'native-debug.log'))},'--plugin-dir',${JSON.stringify(plugin)},...${JSON.stringify(clientLifecycle?['--plugin-dir',join(workspace,'pending-client-fixture')]:[])},...${JSON.stringify(process.env.CLAUDE_RESEARCH_COMPOSE==='1'?['--plugin-dir',join(workspace,'native-compose-observer')]:[])},...${JSON.stringify(mcpArgs)},...args],{env,stdio:args.includes('--print')?['inherit','pipe','inherit']:'inherit'});
if(child.stdout){let pending='',captured=0;child.stdout.setEncoding('utf8');child.stdout.on('data',chunk=>{if(${JSON.stringify(agentBilling)}&&captured<1048576){const bytes=Buffer.from(chunk).subarray(0,1048576-captured);appendFileSync(${JSON.stringify(join(workspace,'native-print-stdout.jsonl'))},bytes);captured+=bytes.length;}pending+=chunk;let end;while((end=pending.indexOf('\\n'))>=0){const line=pending.slice(0,end);pending=pending.slice(end+1);try{const value=JSON.parse(line);if(value.type==='result')appendFileSync(${JSON.stringify(join(workspace,'native-print-results.jsonl'))},JSON.stringify({pid:child.pid,sessionId:value.session_id,totalCostUsd:value.total_cost_usd,subtype:value.subtype})+'\\n');}catch{}}});child.stdout.pipe(process.stdout);}
child.on('spawn',()=>appendFileSync(${JSON.stringify(join(workspace,'native-children.jsonl'))},JSON.stringify({pid:child.pid,args,at:Date.now()})+'\\n'));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>child.kill(signal));
const timeout=setTimeout(()=>child.kill('SIGKILL'),${configDesktop||agentBilling?280000:lspLifecycle?210000:agentMediaBoundary?140000:searchReview?180000:toolPermissions||genericPermissions||mcpElicitation||readMediaPageSuccess||agentImeCancel||systemPolicy||resetTask||lspReview?180000:combinedReconnect?190000:pendingDuration&&!pendingWorkflow?140000:planScenario==='direct-resume'?150000:promptThemeReconnect?130000:planScenario==='theme'?180000:85000});
child.on('error',()=>{clearTimeout(timeout);process.exitCode=1});child.on('close',(code,signal)=>{clearTimeout(timeout);appendFileSync(${JSON.stringify(join(workspace,'native-exits.jsonl'))},JSON.stringify({pid:child.pid,code,signal,at:Date.now()})+'\\n');process.exitCode=code??1});
`,{mode:0o755});
execFileSync(process.execPath,['--check',launcher]);
const names=['runtime/index.cjs','runtime/fe.js','runtime/fe.css','runtime/content/actions.content.json','runtime/content/flows.content.json'];
if(printClients)await addNativePrintClientFixture(plugin);
else if(clientLifecycle){
  await addNativeClientLifecycleFixture(plugin,workspace);
  await writeFile(join(workspace,'research-client-load-preload.mjs'),`import {installOwnedClientLoadDelay} from ${JSON.stringify(new URL('../protocol/owned-client-load-delay.mjs',import.meta.url).href)};installOwnedClientLoadDelay({workspace:${JSON.stringify(workspace)},modulePath:${JSON.stringify(join(workspace,'pending-client-fixture/hooks/pending-extension.ts'))}});`);
}
else if(clientLayout)await addNativeClientLayoutFixture(plugin);
else if(terminalClients)await addTerminalClientFixture(plugin);
if(printTheme)await addNativePrintThemeFixture(plugin,workspace);
if(process.env.CLAUDE_RESEARCH_CLIENT_THEME==='1'){assert.ok(agentBilling);await addNativeClientThemeFixture(plugin,workspace);}
if(process.env.CLAUDE_RESEARCH_SELECTION_LIMIT==='1'){assert.ok(agentBilling);await addNativeSelectionLimitFixture(plugin);}
if(snapshotActions)await addNativeSnapshotActionFixture(plugin);
if(themeCreateReset||durationSettings||focusContext)await addNativeThemeCreateResetFixture(plugin,workspace);
if(fileLayout)await writeFile(join(workspace,'research-event-observer.mjs'),`import {EventEmitter} from 'node:events';import{appendFileSync}from'node:fs';const original=EventEmitter.prototype.emit;EventEmitter.prototype.emit=function(name,...args){if(['plugin-send','outgoing'].includes(name)&&['UPDATE_MESSAGE_STATE','THREAD_UPDATED','LOAD_CHAT_THREAD'].includes(args[0]?.event?.type)){const m=args[0],e=m.event;appendFileSync(${JSON.stringify(join(workspace,'native-file-publications.jsonl'))},JSON.stringify({at:Date.now(),pid:process.pid,name,listeners:this.listenerCount(name),to:m.to,client:m.client,type:e.type,messageId:e.messageId,pending:e.updates?.context?.claudeCode?.pendingControlRequest?.approvalMessageId,response:e.blockResponse})+'\\n')}return Reflect.apply(original,this,[name,...args])};`);
const compiled=async()=>Object.fromEntries(await Promise.all(names.map(async name=>[name,hash(await readFile(join(checkout,'packages/default-setup/dist',name)))])));
const rendererFiles=async()=>{const root=join(checkout,'packages/renderer/dist'),files=['index.html',...(await readdir(join(root,'assets'))).filter(name=>/\.(?:js|css)$/.test(name)).sort().map(name=>'assets/'+name)],result={};for(const name of files)result[name]=hash(await readFile(join(root,name)));return result;};
if(bashScenario&&process.env.CLAUDE_RESEARCH_TERMINAL_PLACEMENTS==='1')await writeFile(join(plugin,'hooks/register.ts'),(await readFile(join(plugin,'hooks/register.ts'),'utf8')).replace("export function register(on){", "export function register(on){for(const component of ['TurnDuration','InfoNotice'])on('ui.render',{component},async($,e,next)=>{await $.fs.write('native-terminal-placement-'+component+'.json',JSON.stringify({surface:e.surface,requestId:e.requestId,props:e.props}));const{Box,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next({...e,props:{...e.props,...component==='TurnDuration'?{word:'Native completion'}:{text:'Native notice: '+e.props.text}}}),Button({key:'inspect-native-placement',label:'Inspect '+component,onPress:async()=>$.fs.write('native-terminal-placement-action.json',JSON.stringify({component,surface:e.surface,requestId:e.requestId}))})]});});"));
if(notebookEdit)await addNativeNotebookEditFixture(workspace,plugin);
if(mcpElicitation)await addMcpElicitationAppFixture(workspace);
if(genericPermissions)await addNativeGenericPermissionFixture(workspace,plugin);
if(toolPermissions)await addNativeToolPermissionFixture(workspace,plugin);
if(process.env.CLAUDE_RESEARCH_SELECT_EMPTY==='1'||bareMode)await addNativeSelectFixture(plugin);
if(bareMode)await writeFile(userPreload,(await readFile(userPreload,'utf8'))+await adaptNativeResearchPreload(checkout,nativeBareModeObserver(join(workspace,'native-bare-policy.json')),{includeRuntime:false}));
if(process.env.CLAUDE_RESEARCH_COMPOSE==='1')await addNativeComposeFixture(workspace,plugin);
if(process.env.CLAUDE_RESEARCH_QUESTION_TOOL_NOTICE==='1')await addNativeQuestionToolNoticeFixture(workspace,plugin);
if(process.env.CLAUDE_RESEARCH_LOG==='1')await addNativeLogFixture(workspace,plugin);
if(process.env.CLAUDE_RESEARCH_NOTIFY==='1')await addNativeNotifyFixture(workspace,plugin);
if(searchReview)await addNativeSearchReviewFixture(workspace,plugin);
if(idleRedraw)await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){let count=0;on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Text({children:['Session context refreshed '+count]}),Button({key:'refresh-context',label:'Refresh session context',onPress:async()=>{const read=await $.prompt.read();count++;await $.fs.write('native-idle-redraw-receipts.json',JSON.stringify({count,requestId:e.requestId,read}));$.ui.invalidate('ui.render');}})]});});}`);
if(pluginHint){await addNativePluginHintAppFixture(executable,workspace,join(workspace,'recommendation-registration'),process.env.CLAUDE_RESEARCH_PLUGIN_HINT_SNAPSHOT);await writeFile(join(plugin,'hooks/register.ts'),'export function register(on){}');await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativePluginHintObserver(workspace));}
if(lspRecommendation){await addLspRecommendationAppFixture(executable,workspace,join(workspace,'recommendation-registration'));await writeFile(join(plugin,'hooks/register.ts'),'export function register(on){}');}
if(lspReview)await addNativeLspFixture(workspace,plugin);
if(readMedia)await addNativeReadMediaFixture(workspace,plugin,{pageSuccess:readMediaPageSuccess,notebookImages});
if(handbackOwner||workflowUnsettled||workflowResumeEligibility)await writeFile(join(plugin,'hooks/register.ts'),'export function register(on){}');
if(fieldLifetime)await addNativeFieldLifetimeFixture(plugin);
const before=await compiled(),rendererBefore=await rendererFiles();await writeFile(join(workspace,'compiled-renderer-hashes.json'),JSON.stringify(rendererBefore),{mode:0o600});let child,exited=false,timeout;
try {
 if(agentBilling)creditBilling=await startNativeCreditBilling(creditTls,{allowMutations:false,evidencePath:join(workspace,'native-credit-billing-live.json')});
 if(nativeCreditDesktop)creditBilling=await startNativeCreditBilling(creditTls,{allowMutations:true,evidencePath:join(workspace,'native-credit-billing-live.json'),accountType:['admin','admin-error'].includes(nativeCreditScenario)?'team':'pro',...nativeCreditScenario==='admin-error'?{adminRequestOutcome:'disconnect',adminRequestsAllowed:'until-first-attempt',adminBarrier:join(workspace,'native-credit-admin-release')}:nativeCreditScenario==='admin'?{adminBarrier:join(workspace,'native-credit-admin-release')}:['bundle-pending','payment-failed'].includes(nativeCreditScenario)?{purchaseOutcome:nativeCreditScenario==='payment-failed'?'pending-failed':'pending-paid',paymentBarrier:join(workspace,'native-credit-payment-release')}:nativeCreditScenario==='payment-action'?{purchaseOutcome:'requires-action'}:nativeCreditScenario==='payment-http-error'?{purchaseOutcome:'error'}:{}});
 const appSpecs=agentBilling?['tests/e2e/ui/claude-native-agent-billing.spec.ts']:everydayRich?['tests/e2e/ui/claude-native-everyday-rich.spec.ts']:leftArrowApp?(childAppRestart?['tests/e2e/ui/claude-native-leftarrow.spec.ts','tests/e2e/ui/claude-native-background-app-reopen.spec.ts']:['tests/e2e/ui/claude-native-leftarrow.spec.ts']):backgroundConfirmation?['tests/e2e/ui/claude-native-background-confirmation.spec.ts']:backgroundHandoff?['tests/e2e/ui/claude-native-background.spec.ts']:refusalNotice?['tests/e2e/ui/claude-native-refusal.spec.ts']:workflowResumeEligibility?['tests/e2e/ui/claude-native-workflow-resume-eligibility.spec.ts']:completionNavigation?['tests/e2e/ui/claude-native-completion-navigation.spec.ts']:managedModelRestart?['tests/e2e/ui/claude-native-managed-model-restart.spec.ts']:notebookImages?['tests/e2e/ui/claude-native-notebook-images.spec.ts']:bashImage?['tests/e2e/ui/claude-native-bash-image.spec.ts']:settingsBrokerLoss?['tests/e2e/ui/claude-native-settings-broker-loss.spec.ts']:helpDesktop?[helpLinks?'tests/e2e/ui/claude-native-help-links.spec.ts':agentHelpDesktop?'tests/e2e/ui/claude-native-agent-help-desktop.spec.ts':'tests/e2e/ui/claude-native-help-desktop.spec.ts']:agentSettingsRoutes?['tests/e2e/ui/claude-native-agent-settings-routes.spec.ts']:settingsRoutes?['tests/e2e/ui/claude-native-settings-routes.spec.ts']:nativeCreditDesktop?[nativeCreditScenario==='admin-error'?'tests/e2e/ui/claude-native-credit-admin-error.spec.ts':nativeCreditScenario==='admin'?'tests/e2e/ui/claude-native-credit-admin.spec.ts':['payment-failed','payment-action','payment-http-error'].includes(nativeCreditScenario)?'tests/e2e/ui/claude-native-credit-failure.spec.ts':nativeCreditScenario==='bundle-pending'?'tests/e2e/ui/claude-native-credit-bundle.spec.ts':'tests/e2e/ui/claude-native-credits.spec.ts']:nativeModelDesktop?['tests/e2e/ui/claude-native-model-panel.spec.ts']:promptLineResets?['tests/e2e/ui/claude-native-prompt-line-resets.spec.ts']:promptFontResets?['tests/e2e/ui/claude-native-prompt-font-resets.spec.ts']:workflowUnsettled?['tests/e2e/ui/claude-native-workflow-unsettled.spec.ts']:bareMode?['tests/e2e/ui/claude-native-bare-mode.spec.ts']:fieldLifetime?['tests/e2e/ui/claude-native-field-lifetime.spec.ts']:configDesktop?['tests/e2e/ui/claude-native-config-desktop.spec.ts']:pluginHint?['tests/e2e/ui/claude-native-plugin-hint.spec.ts']:lspRecommendation?['tests/e2e/ui/claude-native-lsp-recommendation.spec.ts']:process.env.CLAUDE_RESEARCH_SAFE_MODE==='1'?['tests/e2e/ui/claude-native-safe-mode.spec.ts']:process.env.CLAUDE_RESEARCH_LOG==='1'?['tests/e2e/ui/claude-native-log.spec.ts']:process.env.CLAUDE_RESEARCH_NOTIFY==='1'?['tests/e2e/ui/claude-native-notify.spec.ts']:process.env.CLAUDE_RESEARCH_COMPOSE==='1'?['tests/e2e/ui/claude-native-compose.spec.ts']:process.env.CLAUDE_RESEARCH_SELECT_EMPTY==='1'?['tests/e2e/ui/claude-native-select-empty.spec.ts']:process.env.CLAUDE_RESEARCH_CONFIG_SHORTHAND==='1'?['tests/e2e/ui/claude-native-config-shorthand.spec.ts']:searchReview?['tests/e2e/ui/claude-native-search-review.spec.ts']:agentMediaBoundary?['tests/e2e/ui/claude-native-agent-media-boundary.spec.ts']:lspReview?['tests/e2e/ui/claude-native-lsp.spec.ts']:resumeUpload?[populatedResumeUpload?'tests/e2e/ui/claude-native-populated-resume-upload.spec.ts':'tests/e2e/ui/claude-native-resume-upload.spec.ts']:resetUpload?['tests/e2e/ui/claude-native-reset-upload.spec.ts']:resetTask?['tests/e2e/ui/claude-native-reset-task.spec.ts']:systemPolicy?['tests/e2e/ui/claude-native-system-policy.spec.ts']:nativeMcpUrl?['tests/e2e/ui/claude-native-mcp-url.spec.ts']:nativeMcpForm?['tests/e2e/ui/claude-native-mcp-form.spec.ts']:mcpElicitation?['tests/e2e/ui/claude-mcp-elicitation.spec.ts']:genericPermissions?['tests/e2e/ui/claude-native-generic-permission.spec.ts']:toolPermissions?['tests/e2e/ui/claude-native-tool-permission.spec.ts']:notebookEdit?['tests/e2e/ui/claude-native-notebook-edit.spec.ts']:mcpOAuth?['tests/e2e/ui/claude-native-mcp-oauth.spec.ts']:process.env.CLAUDE_RESEARCH_MCP_PANEL==='1'?['tests/e2e/ui/claude-native-mcp-panel.spec.ts']:heldModelPause?['tests/e2e/ui/claude-native-held-model-pause.spec.ts']:taskManager?['tests/e2e/ui/claude-native-task-manager.spec.ts']:activeToolPause?['tests/e2e/ui/claude-native-active-tool-pause.spec.ts']:activeToolCancel?['tests/e2e/ui/claude-native-active-tool-cancel.spec.ts']:process.env.CLAUDE_RESEARCH_ATTACHMENT_MEDIA==='1'?['tests/e2e/ui/claude-native-attachment-media.spec.ts']:process.env.CLAUDE_RESEARCH_CONFIG_THEME==='1'?['tests/e2e/ui/claude-native-config-theme.spec.ts']:process.env.CLAUDE_RESEARCH_COMMAND_INTERACTIONS==='1'?['tests/e2e/ui/claude-native-command-interactions.spec.ts']:process.env.CLAUDE_RESEARCH_AGENT_SETTINGS==='1'?['tests/e2e/ui/claude-native-agent-settings.spec.ts']:process.env.CLAUDE_RESEARCH_CONFIG_LAYOUT==='1'?['tests/e2e/ui/claude-native-config-layout.spec.ts']:process.env.CLAUDE_RESEARCH_CONFIG_MODEL==='1'?['tests/e2e/ui/claude-native-config-model.spec.ts']:process.env.CLAUDE_RESEARCH_AGENT_STRUCTURED==='1'?['tests/e2e/ui/claude-native-agent-structured.spec.ts']:process.env.CLAUDE_RESEARCH_COMPOSER_WRAP==='1'?['tests/e2e/ui/claude-native-composer-wrap.spec.ts']:process.env.CLAUDE_RESEARCH_STATUS_STARTUP==='1'?['tests/e2e/ui/claude-native-status-startup.spec.ts']:process.env.CLAUDE_RESEARCH_AGENT_CARET==='1'?[process.env.CLAUDE_RESEARCH_AGENT_CARET_FAST==='1'?'tests/e2e/ui/claude-native-agent-caret-fast.spec.ts':'tests/e2e/ui/claude-native-agent-caret.spec.ts']:agentImeCancel?['tests/e2e/ui/claude-native-agent-ime-cancel.spec.ts']:process.env.CLAUDE_RESEARCH_AGENT_IME_LIFETIME==='1'?['tests/e2e/ui/claude-native-agent-ime-lifetime.spec.ts']:process.env.CLAUDE_RESEARCH_TOOL_WIDTH==='1'?['tests/e2e/ui/claude-native-tool-width.spec.ts']:process.env.CLAUDE_RESEARCH_PROMPT_TIMEOUT==='1'?['tests/e2e/ui/claude-native-prompt-timeout.spec.ts']:process.env.CLAUDE_RESEARCH_POLICY_HELD_CLIENT==='1'?['tests/e2e/ui/claude-native-policy-held-client.spec.ts']:actionKeysApp?['tests/e2e/ui/claude-native-action-keys.spec.ts']:fieldBounds?['tests/e2e/ui/claude-native-field-bounds.spec.ts']:agentSource?['tests/e2e/ui/claude-native-agent-source.spec.ts']:sourceFill?['tests/e2e/ui/claude-native-source-fill.spec.ts']:promptSource?['tests/e2e/ui/claude-native-prompt-source.spec.ts']:promptBoundaries?['tests/e2e/ui/claude-native-prompt-boundaries.spec.ts']:permissionAdmission?['tests/e2e/ui/claude-native-permission-admission.spec.ts']:permissionRefusal?['tests/e2e/ui/claude-native-permission-refusal.spec.ts']:windowPhase?['tests/e2e/ui/claude-native-window-phase.spec.ts']:savedPlan?['tests/e2e/ui/claude-native-saved-plan-save.spec.ts','tests/e2e/ui/claude-native-saved-plan-reopen.spec.ts']:composerCold?['tests/e2e/ui/claude-native-composer-cold-save.spec.ts','tests/e2e/ui/claude-native-composer-cold-reopen.spec.ts']:composerPhase?['tests/e2e/ui/claude-native-composer-phase.spec.ts']:stagedDirectories?['tests/e2e/ui/claude-native-staged-directories.spec.ts']:windowAgent?['tests/e2e/ui/claude-native-window-agent.spec.ts']:multipleWindowSelection?['tests/e2e/ui/claude-native-window-selection.spec.ts']:multipleWindows?['tests/e2e/ui/claude-native-multiple-window.spec.ts']:configCallbacks?['tests/e2e/ui/claude-native-config-callbacks.spec.ts']:coldReopen?['tests/e2e/ui/claude-native-cold-save.spec.ts','tests/e2e/ui/claude-native-cold-reopen.spec.ts']:[pendingApprovalFailure?'tests/e2e/ui/claude-native-pending-approval-failure.spec.ts':historyReopen?'tests/e2e/ui/claude-native-history-reopen.spec.ts':largeDocuments?'tests/e2e/ui/claude-native-large-documents.spec.ts':handbackOwner?'tests/e2e/ui/claude-native-handback-owner.spec.ts':readMedia?'tests/e2e/ui/claude-native-read-media.spec.ts':questionForms?'tests/e2e/ui/claude-native-extended-questions.spec.ts':planScenario==='parent-commands'?'tests/e2e/ui/claude-native-parent-commands.spec.ts':planScenario==='task-steering'?'tests/e2e/ui/claude-native-task-steering.spec.ts':planScenario==='task-controls'?(pendingDuration?(pendingWorkflow?'tests/e2e/ui/claude-native-pending-workflow.spec.ts':'tests/e2e/ui/claude-native-pending-duration.spec.ts'):'tests/e2e/ui/claude-native-task-controls.spec.ts'):planScenario==='agent-layout'?'tests/e2e/ui/claude-native-agent-layout.spec.ts':['client','client-fields'].includes(planScenario)?'tests/e2e/ui/claude-native-client.spec.ts':planScenario==='theme'?(rootIme?'tests/e2e/ui/claude-native-root-ime.spec.ts':focusSummary?'tests/e2e/ui/claude-native-focus-summary.spec.ts':focusContext?'tests/e2e/ui/claude-native-focus-context.spec.ts':durationSettings?'tests/e2e/ui/claude-native-duration-settings.spec.ts':themeCreateReset?'tests/e2e/ui/claude-native-theme-create-reset.spec.ts':promptTheme?(managedMedia?'tests/e2e/ui/claude-native-managed-media.spec.ts':promptRichSelection?'tests/e2e/ui/claude-native-rich-agent-draft.spec.ts':promptStructured?'tests/e2e/ui/claude-native-structured-prompt.spec.ts':agentReconnectOnly?'tests/e2e/ui/claude-native-agent-reconnect.spec.ts':promptExpiryOnly?'tests/e2e/ui/claude-native-prompt-expiry.spec.ts':promptThemeReconnect?'tests/e2e/ui/claude-native-prompt-reconnect.spec.ts':promptThemeReverse?'tests/e2e/ui/claude-native-prompt-reverse-lifetime.spec.ts':promptThemeStale?'tests/e2e/ui/claude-native-prompt-stale.spec.ts':promptThemeSelection?'tests/e2e/ui/claude-native-prompt-ownership.spec.ts':promptThemeEveryday?(questionOwnerFailure?'tests/e2e/ui/claude-native-question-owner-failure.spec.ts':'tests/e2e/ui/claude-native-everyday.spec.ts'):promptThemeText?'tests/e2e/ui/claude-native-text-wrap.spec.ts':promptThemeAgent?(uiSelection?'tests/e2e/ui/claude-native-agent-selection.spec.ts':'tests/e2e/ui/claude-native-agent-prompt-theme.spec.ts'):'tests/e2e/ui/claude-native-prompt-theme.spec.ts'):capabilityProfile?'tests/e2e/ui/claude-native-capabilities.spec.ts':'tests/e2e/ui/claude-native-theme.spec.ts'):planScenario==='composer-layout'?(snapshotActions?'tests/e2e/ui/claude-native-snapshot-actions.spec.ts':printClients?'tests/e2e/ui/claude-native-print-client.spec.ts':clientLifecycle?'tests/e2e/ui/claude-native-client-lifecycle.spec.ts':clientLayout?'tests/e2e/ui/claude-native-client-layout.spec.ts':emptyKeyboardClient?'tests/e2e/ui/claude-native-empty-client.spec.ts':terminalClients?'tests/e2e/ui/claude-native-terminal-client.spec.ts':'tests/e2e/ui/claude-native-composer-layout.spec.ts'):mcpScenario?(mcpDirectory?'tests/e2e/ui/claude-native-mcp-directory.spec.ts':mcpResources?'tests/e2e/ui/claude-native-mcp-resources.spec.ts':'tests/e2e/ui/claude-native-mcp-status.spec.ts'):planScenario==='rename'?'tests/e2e/ui/claude-native-session-rename.spec.ts':planScenario==='direct-resume'?'tests/e2e/ui/claude-native-direct-resume.spec.ts':planScenario==='onboarding-import'?'tests/e2e/ui/claude-native-onboarding-import.spec.ts':planScenario==='import'?'tests/e2e/ui/claude-native-session-import.spec.ts':planScenario==='resume'?'tests/e2e/ui/claude-native-session-resume.spec.ts':rewindScenario?'tests/e2e/ui/claude-native-session-rewind.spec.ts':planScenario==='revert'?'tests/e2e/ui/claude-native-session-revert.spec.ts':planScenario==='fork'?'tests/e2e/ui/claude-native-session-fork.spec.ts':planScenario==='reset'?'tests/e2e/ui/claude-native-session-reset.spec.ts':planScenario?'tests/e2e/ui/claude-native-plan-approval.spec.ts':fileScenario?(fileStanding?'tests/e2e/ui/claude-native-file-standing.spec.ts':'tests/e2e/ui/claude-native-file-approval.spec.ts'):bashScenario?(bashStanding?'tests/e2e/ui/claude-native-bash-standing.spec.ts':'tests/e2e/ui/claude-native-bash-approval.spec.ts'):managedPolicy?'tests/e2e/ui/claude-native-managed-policy.spec.ts':'tests/e2e/ui/claude-native-terminal.spec.ts'];
 if(childAppRestart)assert.deepEqual(appSpecs,['tests/e2e/ui/claude-native-leftarrow.spec.ts','tests/e2e/ui/claude-native-background-app-reopen.spec.ts']);
 else if(backgroundHandoff)assert.deepEqual(appSpecs,[leftArrowApp?'tests/e2e/ui/claude-native-leftarrow.spec.ts':backgroundConfirmation?'tests/e2e/ui/claude-native-background-confirmation.spec.ts':'tests/e2e/ui/claude-native-background.spec.ts']);
 for(const appSpec of appSpecs){
 const appEnv={...process.env,...((process.env.CLAUDE_RESEARCH_BACKGROUND_STATUS_LIFECYCLE_APP==='1'||process.env.CLAUDE_RESEARCH_BACKGROUND_FORMATTER_LIFECYCLE_APP==='1'||process.env.CLAUDE_RESEARCH_BACKGROUND_FORMATTER_POLICY_APP==='1'||process.env.CLAUDE_RESEARCH_BACKGROUND_API_RESTART_APP==='1'||childAppRestart)?{CLAUDE_RESEARCH_BACKGROUND_BROKER_AUDIT:join(workspace,'background-broker-audit.jsonl')}:{}),...((multipleWindowSelection||windowAgent||windowPhase)?{NODE_OPTIONS:((process.env.NODE_OPTIONS??'')+' --import='+fileURLToPath(new URL('../protocol/owned-playwright-window-focus.mjs',import.meta.url))).trim()}:{}),...(fileLayout?{NODE_OPTIONS:((process.env.NODE_OPTIONS??'')+' --import='+join(workspace,'research-event-observer.mjs')).trim()}:{}),BUN_OPTIONS:originalBunOptions,PATH:join(workspace,'bin')+':/usr/bin:/bin:/usr/sbin:/sbin',CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_PROJECT:nativeProject,...(themeCreateReset&&process.env.CLAUDE_RESEARCH_THEME_DESKTOP==='1'?{CLAUDE_RESEARCH_THEME_DESKTOP:'1'}:{}),...(searchReview?{CLAUDE_RESEARCH_SEARCH_REVIEW:'1'}:{}),...(cwdNavigation?{CLAUDE_RESEARCH_CWD_NAVIGATION:'1'}:{}),...(idleRedraw?{CLAUDE_RESEARCH_IDLE_REDRAW:'1'}:{}),...(planScenario==='direct-resume'&&process.env.CLAUDE_RESEARCH_IMPORT_IMAGE==='1'?{CLAUDE_RESEARCH_IMPORT_IMAGE:'1'}:{}),CLAUDE_RESEARCH_LAUNCHER:launcher,CLAUDE_RESEARCH_UI_DELAY:fileURLToPath(new URL('../protocol/owned-ui-host-delay.mjs',import.meta.url)),CLAUDE_RESEARCH_ACTION_KEYS_FIXTURE:fileURLToPath(new URL('../protocol/native-action-app-fixture.mjs',import.meta.url)),CLAUDE_RESEARCH_PROMPT_REPLY_HOLD:new URL('./owned-prompt-reply-hold.mjs',import.meta.url).pathname,CLAUDE_RESEARCH_ONBOARDING:fileURLToPath(new URL('../protocol/pty-onboarding.mjs',import.meta.url)),E2E_KEEP_DATA:'1',E2E_DATA_DIR:join(workspace,'app-data')};
 if(directAgentBilling){await driveAgentBilling({checkout,workspace,env:appEnv});continue;}
 const appOutput=join(workspace,'playwright-results',appSpec.split('/').at(-1));
 child=spawn(process.execPath,[join(checkout,'scripts/with-source.mjs'),process.execPath,join(checkout,'node_modules/@playwright/test/cli.js'),'test',appSpec,'--reporter=line','--output',appOutput],{cwd:checkout,env:appEnv,stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);
 // These multi-step journeys need bounded interaction/recovery time beyond single-dialog fixtures.
 exited=false;timeout=setTimeout(()=>child.kill('SIGTERM'),agentBilling||configDesktop?290000:lspLifecycle?220000:process.env.CLAUDE_RESEARCH_IMAGE_PIXELS==='1'?150000:agentMediaBoundary?150000:searchReview?190000:emptyKeyboardClient||actionKeysApp||toolPermissions||genericPermissions||mcpElicitation||readMediaPageSuccess||agentImeCancel||systemPolicy||resetTask||lspReview?190000:promptThemeEveryday?170000:combinedReconnect?200000:windowAgent?160000:pendingDuration&&!pendingWorkflow?150000:planScenario==='direct-resume'?160000:promptThemeReconnect?140000:planScenario==='theme'?190000:100000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',code=>{exited=true;resolve(code)})});clearTimeout(timeout);
 await cp(appOutput,(coldReopen||composerCold||childAppRestart)?join(workspace,'electron-results',appSpec.split('/').at(-1)):join(workspace,'electron-results'),{recursive:true});
 assert.equal(code,0,'Native terminal app acceptance failed: '+appSpec);
 }
 if(realMcpBrowser){
  const launched=mcpBrowser.events.filter(row=>row.kind==='launch');const retryBrowser=process.env.CLAUDE_RESEARCH_NATIVE_MCP_URL_RETRY==='1';
  const pauseAfterReturn=retryBrowser&&process.env.CLAUDE_RESEARCH_MCP_RETRY_BROWSER_PAUSE==='1';
  assert.equal(launched.length,modernMcpUrl||pauseAfterReturn?3:retryBrowser?2:4);assert.equal(mcpBrowser.events.some(row=>row.kind==='exit'),false,'Browser windows must remain open through app confirmation/cancellation and recovery');
  await writeFile(join(workspace,'owned-mcp-browser-retained.json'),JSON.stringify({retainedThroughRecovery:true,browserIds:launched.map(row=>row.id)}));
 }
 await mcpBrowser?.close();
 assert.deepEqual(await compiled(),before,'Pack changed during terminal app acceptance');
 assert.deepEqual(await rendererFiles(),rendererBefore,'Renderer changed during terminal app acceptance');
 const evidence=JSON.parse(await readFile(join(workspace,'native-terminal-app-evidence.json'),'utf8'));
 if(childAppRestart){
  const proof=JSON.parse(await readFile(join(workspace,'background-app-restart-observation.json'),'utf8'));
  assert.equal(evidence.nativeBackgroundAppRestart,true);assert.equal(proof.phase,'verified');
  assert.equal(proof.freshStatus,true);assert.equal(proof.replyDraft,proof.saved.retainedReply);
  assert.equal(proof.worker.start,proof.saved.worker.start);assert.equal(proof.workerAfterReply.start,proof.saved.worker.start);
  assert.ok(proof.workerAfterStop&&(['gone','Z'].includes(proof.workerAfterStop.state)||proof.workerAfterStop.start!==proof.saved.worker.start));
  console.log(JSON.stringify({evidence:'apack-native-terminal-owner-app',...evidence,activeFrontend:sourceFrontendUrl?'source-vite':'sealed-pack',sealedCandidateAccepted:sourceFrontendUrl?false:undefined,compiledPackHashes:before,targetSha256:hash(await readFile(executable)),realModelRequests:0,scope:'Graceful full Electron quit/relaunch of one linked child in an owned profile only; other lifecycle, policy, UI and original F1–F5 requirements remain open.'}));
 }else if(backgroundHandoff){
  const proof=JSON.parse(await readFile(join(workspace,'native-background-app-observation.json'),'utf8'));
  if(leftArrowApp)assert.equal(evidence.nativeLeftArrow,true);
  if(childInteractionApp){assert.equal(evidence.nativeBackgroundChildInteractions,true);assert.equal(proof.childInteraction?.read,true);assert.equal(proof.childInteraction?.question,true);assert.ok(agent.calls.some(call=>call.referenceReadResult==='1\tNativeReferenceFileBytes'&&call.referenceReadError===false),'Original child must receive the file bytes');assert.ok(agent.calls.some(call=>call.nativeQuestionResult?.includes('\"Who should the release summary address?\"=\"Developers\"')&&call.nativeQuestionError===false),'Original child must receive the selected answer');}
  if(childResumeApp){assert.equal(evidence.nativeBackgroundResume,true);assert.equal(proof.childResume?.refusal.originalText,true);assert.equal(proof.childResume?.refusal.noWorker,true);assert.equal(proof.childResume?.sameSession,true);assert.equal(proof.childResume?.parentPreserved,true);assert.equal(proof.childResume?.uiStop,true);assert.equal(proof.childResume?.workerRetired,true);assert.ok(proof.childResume.workerProcessAfterStop&&(['gone','Z'].includes(proof.childResume.workerProcessAfterStop.state)||(typeof proof.childResume.workerProcessAfterStop.start==='string'&&proof.childResume.workerProcessAfterStop.start!==proof.childResume.resumed?.start)),'Original resumed worker must actually exit');assert.equal(proof.childResume?.historyRefusal?.originalText,true);assert.equal(proof.childResume?.historyRefusal?.noWorker,true);assert.equal(proof.childResume?.historyRefusal?.journalRestored,true);}
  if(childAttachApp&&!childResumeApp){assert.equal(evidence.nativeBackgroundAttachment,true);assert.equal(proof.childAttachment?.closedClientOnly,true);assert.equal(proof.childAttachment?.parentHistoryPreserved,true);assert.equal(proof.childAttachment?.parentDraftPreserved,true);assert.equal(proof.childAttachment?.workerBefore.start,proof.childAttachment?.workerAfter.start);}
  if(process.env.CLAUDE_RESEARCH_BACKGROUND_API_RESTART_APP==='1'||composerLayout){assert.equal(evidence.nativeBackgroundSettledHandoff,true);assert.equal(evidence.nativeBackgroundConfirmation,false);assert.equal(proof.settledParentBeforeHandoff?.native?.state?.activity?.pendingWorkflows,0);assert.equal(proof.settledParentBeforeHandoff?.native?.state?.busy,false);}else if(backgroundConfirmation)assert.equal(evidence.nativeBackgroundConfirmation,true);
  if(composerLayout){
   assert.equal(evidence.nativeBackgroundComposerLayout,true);assert.equal(proof.backgroundCombinedLayout.length,6);
   if(sourceFrontendUrl){assert.equal(evidence.nativeBackgroundSourceFrontend,true);const source=JSON.parse(await readFile(join(workspace,'source-frontend-proof.json'),'utf8'));assert.deepEqual(evidence.sourceFrontendProof,source);assert.equal(new URL(source.pageUrl).origin,new URL(sourceFrontendUrl).origin);assert.equal(source.rawSha256,source.expectedSha256);}
   for(const reading of proof.backgroundCombinedLayout){assert.ok(reading.background.scrollHeight<=reading.background.clientHeight+1);assert.equal(reading.background.scrollTop,0);assert.ok(reading.background.controls.every(control=>control.hit));}
  }
  assert.equal(evidence.nativeBackgroundHandoff,true);assert.notEqual(evidence.sessionId,evidence.backgroundSessionId);assert.equal(proof.after.find(row=>row.id===proof.job.id)?.state,'stopped');
  assert.equal(evidence.appHandoffAccepted,false,'Discovery does not establish completed desktop handoff');
  console.log(JSON.stringify({evidence:'apack-native-terminal-owner-app',...evidence,compiledPackHashes:before,targetSha256:hash(await readFile(executable)),realModelRequests:0,scope:composerLayout?'Ordinary settled native handoff with live/exited parent, two exact child replies, visible status/reply/notes at normal and compact sizes, and UI Stop; busy warning setup and other original F1–F5 cases remain separate.':process.env.CLAUDE_RESEARCH_BACKGROUND_API_RESTART_APP==='1'?'Original live child API-crash recovery, fresh status/formatter and second reply, captured old-result refusal and UI Stop/helper retirement only; full Electron restart, other window/policy/action cases and combined F1–F5 remain unaccepted.':childResumeApp?'Original trust Exit refusal, trusted stopped-child resume and missing-history refusal with journal restoration, child-only input receipt, parent isolation and final UI Stop; structured child desktop contracts and other native refusal variants remain unaccepted.':childInteractionApp?'Original live child terminal Read consent and single-question answer, exact original file/answer effects, close/reopen and parent isolation; structured desktop child contracts, stopped-child resume and full parity remain unaccepted.':childAttachApp?'Original live background child terminal attachment, input, close/reopen and parent isolation only; stopped-child resume, child approval/question journeys and structured desktop child bindings remain unaccepted.':leftArrowApp?'Original left-arrow warning/fork and linked-job controls only; child attachment/resume and complete desktop handoff remain unaccepted.':'Native fork through app command route only; complete desktop handoff remains unaccepted.'}));
 }else{
 if(process.env.CLAUDE_RESEARCH_CONFIG_ROWS==='1'){const rows=JSON.parse(await readFile(join(workspace,'native-settings-rows.json'),'utf8'));assert.equal(rows.status,'observed');assert.equal(rows.writes,0);assert.ok(rows.rows.length>0);evidence.nativeSettingsRows={status:rows.status,count:rows.rows.length,writes:rows.writes};}
 if(planScenario==='direct-resume')evidence.promptProcessReplacement=await verifyPromptProcessReplacement(workspace);
 if(handbackOwner&&process.env.CLAUDE_RESEARCH_BILLING_NOTICE_CANCEL==='1'){assert.equal(evidence.nativeBillingNoticeCancel,true);assert.equal(evidence.nativeRetainedDraft,true);const proof=JSON.parse(await readFile(join(workspace,'native-billing-notice-cancel-proof.json'),'utf8'));assert.ok(proof.dialogs.some(event=>event.type==='closed'&&event.value?.id===proof.notice.id&&event.value?.result==='interrupt'));assert.ok(proof.original.every(task=>!task.handbackReport));}
 else if(handbackOwner){for(const key of ['nativeHandbackOwnerReport','nativeHandbackOwnerReturn','nativeHandbackOwnerContinuation','nativeRetainedDraft'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-handback-owner-proof.json'),'utf8'));assert.deepEqual(proof.details.handback,{taskId:proof.original.id,...proof.original.handbackReport});assert.ok(agent.requests.some((request,index)=>!agent.calls[index]?.child&&request.tools?.some(tool=>tool.name==='Agent')&&JSON.stringify(request.messages).includes('Release review complete.')));}

 if(pendingDuration&&!resetTask&&!workflowDeny&&!workflowTaskControls){for(const key of ['nativePendingDuration',pendingWorkflow?'nativePendingWorkflow':'nativePendingAgent','nativePendingCompletion'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-pending-duration-proof.json'),'utf8'));assert.match(proof.waiting,pendingWorkflow?/Waiting for.*dynamic workflow/:/Waiting for.*background agent/);assert.doesNotMatch(proof.completed,/Waiting for/);assert.ok(proof.pendingNativeRows.some(row=>row.uuid===proof.pendingFrame.uuid&&(pendingWorkflow?row.pendingWorkflowCount:row.pendingBackgroundAgentCount)===1));}
 if(pendingWorkflow&&!workflowDeny&&!workflowTaskControls){for(const key of ['nativeWorkflowApproval','nativeWorkflowActivity','nativeWorkflowConcurrentPrompt'])assert.equal(evidence[key],true);const activity=JSON.parse(await readFile(join(workspace,'native-pending-duration-proof.json'),'utf8'));assert.equal(activity.during.pendingWorkflows,1);assert.equal(activity.after.pendingWorkflows,0);assert.equal(activity.submittedWhilePending,true);const inspection=JSON.parse(await readFile(join(workspace,'native-dialog-shapes.json'),'utf8'));const shown=inspection.events.flatMap(event=>event.value?.open??[]).find(dialog=>dialog.kind==='permission_workflow');const granted=inspection.events.find(event=>event.type==='closed'&&event.value?.id===shown?.id)?.value?.result;assert.equal(granted?.behavior,'allow');assert.equal(granted.updatedInput.script,workflowEditor?JSON.parse(await readFile(join(workspace,'native-workflow-editor-receipt.json'),'utf8')).after:shown.payload.script);assert.ok(agent.calls.some(call=>call.child&&call.delivered));if(workflowStanding){assert.equal(evidence.nativeWorkflowStanding,true);assert.equal(shown.payload.workflowName,'release-review');assert.ok(granted.permissionUpdates?.some(update=>update.type==='addRules'&&update.destination==='localSettings'&&update.behavior==='allow'&&update.rules?.some(rule=>rule.toolName==='Workflow'&&rule.ruleContent==='release-review')));const local=JSON.parse(await readFile(join(workspace,'.claude/settings.local.json'),'utf8'));assert.ok(local.permissions?.allow?.includes('Workflow(release-review)'));}}
 if(workflowGrantScope){assert.equal(evidence.nativeWorkflowMatchingRepeat,true);assert.equal(evidence.nativeWorkflowUnrelatedDenied,true);const proof=JSON.parse(await readFile(join(workspace,'native-workflow-grant-scope-proof.json'),'utf8'));assert.equal(proof.repeatedApprovalCount,proof.initialApprovalCount);const inspection=JSON.parse(await readFile(join(workspace,'native-dialog-shapes.json'),'utf8'));const unrelated=inspection.events.flatMap(event=>event.value?.open??[]).find(dialog=>dialog.kind==='permission_workflow'&&dialog.payload?.workflowName==='security-review');assert.ok(unrelated);assert.equal(inspection.events.find(event=>event.type==='closed'&&event.value?.id===unrelated.id)?.value?.result?.behavior,'deny');assert.equal(proof.unrelatedNotLaunched,true);assert.equal(proof.finalApprovalIds.length,proof.initialApprovalCount+1);assert.ok(agent.calls.some(call=>call.workflowStage==='repeat'&&call.workflowInput?.name==='release-review'));assert.ok(agent.calls.some(call=>call.workflowStage==='unrelated'&&call.workflowInput?.name==='security-review'));}
 if(workflowTaskControls&&!workflowWorkerActions&&!workflowResume&&!workflowUnsettled){assert.equal(evidence.nativeWorkflowTaskControls,true);assert.equal(evidence.nativeWorkflowTaskStop,!workflowProgress);const proof=JSON.parse(await readFile(join(workspace,'native-workflow-task-controls-proof.json'),'utf8'));assert.equal(proof.initialDetails.taskId,proof.taskId);assert.equal(proof.initialDetails.canInput,false);assert.equal(proof.initialDetails.canMessage,false);assert.equal(proof.stoppedDetails.status,workflowProgress?'completed':'killed');assert.ok(proof.nativeTasks.some(task=>task.id===proof.taskId&&task.type==='local_workflow'&&task.status===(workflowProgress?'completed':'killed')));if(workflowProgress){assert.equal(evidence.nativeWorkflowProgress,true);assert.equal(evidence.nativeWorkflowTaskStop,false);const original=proof.nativeTasks.find(task=>task.id===proof.taskId);assert.equal(proof.stoppedDetails.workflow.progress.length,original.workflowProgress.length);for(let index=0;index<original.workflowProgress.length;index++)for(const [key,value] of Object.entries(proof.stoppedDetails.workflow.progress[index]))assert.deepEqual(value,original.workflowProgress[index][key]);assert.deepEqual(proof.stoppedDetails.workflow.logs,original.logs);assert.equal(proof.stoppedDetails.workflow.output,JSON.stringify(original.result));}assert.equal(proof.sameNativeOwner,true);}
 if(workflowUnsettled)evidence.workflowUnsettled=await verifyWorkflowUnsettled(workspace,evidence,{seed:seed.calls,agent:agent.calls});
 if(workflowWorkerActions){assert.equal(evidence.nativeWorkflowWorkerActions,true);const proof=JSON.parse(await readFile(join(workspace,'native-workflow-worker-actions-proof.json'),'utf8')),signals=JSON.parse(await readFile(join(workspace,'native-workflow-worker-signals.json'),'utf8'));assert.notEqual(proof.initial.agentId,proof.restarted.agentId);assert.notEqual(proof.initial.controlToken,proof.restarted.controlToken);assert.ok(signals.aborts.some(event=>event.taskId===proof.taskId&&event.agentId===proof.initial.agentId&&event.reason==='user-retry'));assert.ok(signals.aborts.some(event=>event.taskId===proof.taskId&&event.agentId===proof.restarted.agentId&&event.reason==='user-skip'));assert.equal(signals.aborts.filter(event=>event.reason==='user-retry').length,1);assert.equal(signals.aborts.filter(event=>event.reason==='user-skip').length,1);assert.equal(proof.staleRefused,true);assert.equal(proof.final.status,'completed');assert.ok(proof.final.workflow.progress.some(event=>event.type==='workflow_agent'&&event.agentId===proof.restarted.agentId&&event.skipped===true));assert.ok(agent.calls.filter(call=>call.child).length>=1&&agent.calls.filter(call=>call.child).length<=2);}
 if(process.env.CLAUDE_RESEARCH_ATTACHMENT_MEDIA==='1')await verifyNativeAttachmentMedia(workspace,evidence,agent.calls);
 if(readMedia){assert.equal(evidence.nativeReadMedia,true);const results=agent.calls.filter(call=>call.mediaResult).map(call=>call.mediaResult);if(readMediaPageSuccess)assert.equal(evidence.nativePdfPageSuccess,true);const verified=notebookImages?await verifyNativeNotebookImages(workspace,results):readMediaPageSuccess?await verifyNativePdfPageSuccess(workspace,results):readMediaPages?verifyNativePdfPageFailures(results):await verifyNativeReadMediaResults(workspace,results);await writeFile(join(workspace,'native-media-delivery-verified.json'),JSON.stringify(verified),{mode:0o600});await writeFile(join(workspace,'native-media-model-results.json'),JSON.stringify(results),{mode:0o600});}
 if(workflowResume){assert.equal(evidence.nativeWorkflowPausedResumed,true);const proof=JSON.parse(await readFile(join(workspace,'native-workflow-resume-proof.json'),'utf8'));assert.equal(proof.paused.status,'paused');if(workflowResumeEligibility)assert.equal(typeof proof.paused.settled,'boolean');else assert.equal(proof.paused.settled,true);assert.equal(proof.resumed.workflowRunId,proof.paused.workflowRunId);assert.notEqual(proof.resumed.id,proof.paused.id);assert.equal(proof.completed.status,'completed');assert.ok(proof.completed.workflowProgress.some(event=>event.type==='workflow_agent'&&event.index===1&&event.cached===true));assert.equal(agent.calls.filter(call=>call.child&&call.workflowStage==='cached').length,1);assert.equal(agent.calls.filter(call=>call.child&&call.workflowStage==='resume').length,2);assert.ok(agent.calls.some(call=>call.workflowInput?.resumeFromRunId===proof.paused.workflowRunId&&call.workflowInput.scriptPath===proof.paused.scriptPath));}
 if(workflowDeny){assert.equal(evidence.nativeWorkflowDenied,true);assert.equal(evidence.nativeWorkflowFeedback,true);assert.equal(evidence.nativeNoWorkflowStarted,true);const proof=JSON.parse(await readFile(join(workspace,'native-workflow-denial-proof.json'),'utf8')),inspection=JSON.parse(await readFile(join(workspace,'native-dialog-shapes.json'),'utf8'));const shown=inspection.events.flatMap(event=>event.value?.open??[]).find(dialog=>dialog.kind==='permission_workflow'),denied=inspection.events.find(event=>event.type==='closed'&&event.value?.id===shown?.id)?.value?.result;assert.equal(denied?.behavior,'deny');assert.equal(denied.feedback,proof.feedback);assert.ok(agent.calls.some(call=>call.agentResultError&&JSON.stringify(call.messages).includes(proof.feedback)));assert.ok(!agent.calls.some(call=>call.child));assert.deepEqual(JSON.parse(await readFile(join(workspace,'native-workflow-state.json'),'utf8')),[]);}
 if(process.env.CLAUDE_RESEARCH_WORKFLOW_RESULT_REVIEW==='1'){assert.equal(evidence.nativeWorkflowBoundedReview,true);const proof=JSON.parse(await readFile(join(workspace,'native-workflow-bounded-result-proof.json'),'utf8'));assert.equal(proof.toolUse.body.status,'live');assert.ok(proof.toolUse.engineOutput.includes('Review release notes'));assert.ok(proof.toolUse.engineOutput.includes('Full Workflow script omitted from this view.'));assert.equal(proof.sameNativeOwner,true);const errors=JSON.parse(await readFile(join(workspace,'native-ui-error-receipt.json'),'utf8').catch(()=>'[]'));assert.ok(!errors.some(entry=>entry.request?.component==='ToolUse'&&entry.request?.instance_id==='status_agent_fixture'));}
 if(rootIme){assert.equal(evidence.nativeRootClientIme,true);const proof=JSON.parse(await readFile(join(workspace,'native-root-ime-proof.json'),'utf8'));assert.equal(proof.committed.text,'日本語');assert.deepEqual(proof.committed.keys,['日','本','語']);assert.ok(proof.afterRedraw.ticks>proof.beforeRedraw.ticks);assert.equal(proof.afterRedraw.text,'');}
 if(focusBash)assert.equal(evidence.nativeBashNotification,true);
 if(focusQueue){assert.equal(evidence.nativeQueuedCompletion,true);const proof=JSON.parse(await readFile(join(workspace,'native-queued-completion-proof.json'),'utf8'));assert.ok(proof.held.queue.some(command=>command.mode==='task-notification'&&proof.held.tasks.some(task=>task.id===command.taskId&&task.status==='completed')));assert.equal(proof.held.counts[workflowQueue?'pendingWorkflows':'pendingAgents'],1);assert.equal(proof.drained.counts[workflowQueue?'pendingWorkflows':'pendingAgents'],0);}
 if(focusSummary){assert.equal(evidence.nativeNotificationGroup,true);const proof=JSON.parse(await readFile(join(workspace,'native-focus-summary-proof.json'),'utf8'));assert.ok(proof.originalGroup);}
 if(focusContext&&!focusSummary){for(const key of ['nativeFocusContext','nativeFocusProjection','nativeFocusGroup','nativeFocusToggle','nativeRetainedDraft'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-focus-context-proof.json'),'utf8'));assert.ok(proof.focused.frames.some(frame=>frame.hiddenCount>0));assert.ok(proof.restored.frames.every(frame=>frame.hiddenCount===0));assert.ok(proof.nativeHidden.includes(proof.omitted.context.cliUuid));assert.equal(proof.originalGroupInteraction,true);}
 if(durationSettings){for(const key of ['nativeDurationSettings','nativeDurationHidden','nativeDurationRestored'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-duration-settings-proof.json'),'utf8'));assert.deepEqual(proof.map(row=>row.stage),['disabled','Review the release notes with duration hidden.','enabled','Review the release notes with duration restored.']);assert.equal(proof[1].text,'');assert.match(proof[3].text,/for \d/);}
 if(themeCreateReset){if(process.env.CLAUDE_RESEARCH_THEME_DESKTOP==='1')assert.equal(evidence.nativeThemeDesktop,true);for(const key of ['nativeThemeCreateReset','nativeThemeEmptyName','nativeThemeInvalidRejected','nativeThemeFork','nativeThemeCollision','nativeThemeTokenReset'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-theme-create-reset-proof.json'),'utf8'));assert.deepEqual(proof.emptyNameFilesBefore,proof.emptyNameFilesAfter);assert.equal(proof.invalidFileBefore,proof.invalidFileAfter);assert.deepEqual(proof.resetTheme.overrides,{warning:'#cc9944'});assert.equal(proof.pluginBefore,proof.pluginAfter);assert.equal(proof.createdBefore,proof.createdAfter);}
 if(pendingApprovalFailure){
  assert.equal(evidence.nativePendingApprovalFailure,pendingApprovalFailure);
  assert.equal(evidence.nativeCancelledApprovalLabel,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-pending-approval-failure-proof.json'),'utf8'));
  const answered=JSON.parse(await readFile(join(workspace,'native-client-control-receipts.json'),'utf8')).filter(row=>row.request.subtype==='apack_answer_file_dialog');
  assert.equal(answered.length,1);assert.equal(answered[0].response.result.answered,true);assert.equal(answered[0].response.pid,evidence.reopenedNativePid);
  assert.equal(answered[0].request.id,proof.fresh.nativeTerminal.dialogId);assert.equal(answered[0].request.revision,proof.fresh.nativeTerminal.revision);
  const results=agent.calls.flatMap(call=>call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).filter(block=>block.type==='tool_result');
  assert.ok(results.some(block=>block.tool_use_id==='native_reference_retry'&&block.is_error!==true&&JSON.stringify(block.content).includes('NativeReferenceFileBytes')),'Fresh original Read must deliver the real file bytes');
  assert.ok(!results.some(block=>block.tool_use_id==='native_reference_read'&&block.is_error!==true&&JSON.stringify(block.content).includes('NativeReferenceFileBytes')),'The interrupted unapproved Read must never deliver file bytes');
  let closedLedger;
  for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{closedLedger=(await readFile(join(workspace,'.claude/projects',bucket,proof.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse).filter(row=>row.type==='cost-state').at(-1);break}catch(error){if(error.code!=='ENOENT')throw error}}
  assert.equal(closedLedger?.totalCostUSD,proof.continuedCost);assert.equal(proof.nativePrintResult.totalCostUsd,proof.continuedCost);assert.equal(proof.sessionId,evidence.sessionId);assert.ok(proof.recoveredCost>=proof.nativeCost&&proof.continuedCost>proof.recoveredCost);
  evidence.pendingApprovalReceiptVerification={retiredMessageId:proof.retired.approvalMessageId,freshMessageId:proof.fresh.approvalMessageId,freshOriginalAnswers:answered.length,interruptedReadDelivered:false,freshReadDelivered:true,historyRows:proof.history.length,closedCost:proof.continuedCost};
 }
 if(coldReopen)assert.equal(evidence.nativeColdReopen,true);
 if(historyReopen){for(const key of ['nativeHistoryReopened','nativeRetiredActionRefused','nativeLiveNoticeRetired','nativeHistoryIdentity'])assert.equal(evidence[key],true);evidence.historyReceiptVerification=await verifyNativeHistoryReopen(workspace,evidence);}
 if(largeDocuments){for(const key of ['nativeLargeCode','nativeLargeMarkdown','nativeLargeNavigation','nativeRetainedDraft'])assert.equal(evidence[key],true);assert.ok(agent.calls.some(call=>call.referenceReadResult&&!call.referenceReadError&&JSON.stringify(call.referenceReadResult).includes('migration700')),'Original Read must actually deliver the end of the large source');}
 if(documentTheme){
  for(const key of ['nativeDocumentTheme','nativeDocumentSyntaxToggle','nativeDocumentCallback','nativeDocumentCompact'])assert.equal(evidence[key],true,'Missing document app acceptance: '+key);
  const documents=JSON.parse(await readFile(join(workspace,'native-document-app-evidence.json'),'utf8'));
  assert.deepEqual(documents.receipts.map(receipt=>receipt.stage),['preview','preview-cancelled','custom-saved','syntax-disabled','syntax-restored','custom-reloaded']);
  assert.notEqual(documents.receipts[2].diff.nativeAnsi,documents.receipts[3].diff.nativeAnsi,'Original Ctrl+T did not change Code rendering');
  assert.equal(documents.receipts[2].diff.nativeAnsi,documents.receipts[4].diff.nativeAnsi,'Original Ctrl+T did not restore Code rendering');
  assert.notEqual(documents.receipts[2].markdown.nativeAnsi,documents.receipts[3].markdown.nativeAnsi,'Original Ctrl+T did not change Markdown rendering');
  assert.equal(documents.receipts[2].markdown.nativeAnsi,documents.receipts[4].markdown.nativeAnsi,'Original Ctrl+T did not restore Markdown rendering');
  for(const receipt of documents.receipts)assert.ok(receipt.markdown.nativeAnsi.includes('\x1b]8;'),'Native Markdown hyperlink identity missing');
  assert.deepEqual(documents.callback,{href:'https://example.com/native-document-callback'});
  assert.ok(agent.calls.some(call=>Array.isArray(call.messages)&&call.messages.length>0),'Captured native model messages required');
  const modelInput=JSON.stringify(agent.calls);for(const text of ['nativeThemeValue','nativeThemeDiff','Native document paragraph'])assert.equal(modelInput.includes(text),false,'Document UI text leaked into model input');
 }
 if(snapshotActions){assert.equal(evidence.nativePromptCanonicalFill,true);assert.equal(evidence.nativeStableSnapshotActions,true);assert.equal(evidence.nativeInvalidationRetirement,true);const fill=JSON.parse(await readFile(join(workspace,'native-print-theme-fill.json'),'utf8'));assert.equal(fill.call,1);assert.equal(fill.result?.isFilled,true);const stable=JSON.parse(await readFile(join(workspace,'native-snapshot-action-app.json'),'utf8'));assert.deepEqual(stable.beforeAction,stable.afterAction);assert.ok(stable.afterTick>stable.beforeTick+1);assert.equal(stable.originalCallbackCount,1);const retired=JSON.parse(await readFile(join(workspace,'native-snapshot-invalidation-app.json'),'utf8'));assert.notDeepEqual(retired.beforeInvalidationAction,retired.afterInvalidationAction);assert.equal(fill.after.text,'Review release notes before merging.');}
 else if(printTheme){assert.equal(snapshotActions?evidence.nativePromptCanonicalFill:evidence.nativePrintTheme,true);const fill=JSON.parse(await readFile(join(workspace,'native-print-theme-fill.json'),'utf8'));assert.equal(fill.result?.isFilled,true);assert.equal(fill.after.text,'Review release notes before merging.');}
 if(printClients&&!snapshotActions){assert.equal(evidence.nativePrintClient,true);const rows=JSON.parse(await readFile(join(workspace,'native-print-client-receipts.json'),'utf8'));const keyReceipt=JSON.parse(await readFile(join(workspace,'native-print-client-key.json'),'utf8'));assert.equal(keyReceipt.surface,'desktop');assert.equal(keyReceipt.component,'AbovePrompt');assert.equal(keyReceipt.key,'x');assert.ok(rows.some(row=>row.columns>0&&row.rows>0&&row.ticks>0),'Original print timer/resize receipt missing');}
 else if(clientLifecycle){assert.equal(evidence.nativeClientLifecycle,true);const rows=JSON.parse(await readFile(join(workspace,'native-client-lifecycle-receipts.json'),'utf8'));for(const operation of ['held-start','held-finished','applied'])assert.ok(rows.some(row=>row.operation===operation&&row.surface==='desktop'&&row.component==='AbovePrompt'),'Original native lifecycle receipt missing '+operation);assert.deepEqual(JSON.parse(await readFile(join(workspace,'native-client-pending-action.json'),'utf8')),{pendingExtension:true,count:1,surface:'desktop',component:'AbovePrompt'});}
 else if(clientLayout){assert.equal(evidence.nativeClientLayout,true);const regions=JSON.parse(await readFile(join(workspace,'native-client-layout-regions.json'),'utf8'));for(const label of ['Session','Ready','Workspace connected','Context available','Height fixed','Height percent','Height flexible'])assert.ok(regions.some(row=>row.label===label&&row.columns>0&&row.rows>0&&row.surface==='desktop'&&row.component==='AbovePrompt'),'Original desktop region receipt missing: '+label);}
 else if(terminalClients&&process.env.CLAUDE_RESEARCH_CLIENT_RETURN==='1'){for(const key of ['nativeClientReturnKeys','nativeClientReturnActions','nativeClientRetiredToken','nativeRetainedDraft'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-client-return-proof.json'),'utf8'));assert.equal(proof.stages.length,3);assert.deepEqual(proof.stages.map(stage=>stage.key),['j','k','l']);assert.ok(proof.stages.every(stage=>stage.originalReceipt.surface==='terminal'));}
 else if(terminalClients&&process.env.CLAUDE_RESEARCH_IMAGE_SHM==='1'){for(const key of ['nativeImageSharedMemory','nativeImageSharedGeneration','nativeImageSharedOneUse'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-image-shm-proof.json'),'utf8'));assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.boundNativePid,evidence.boundNativePid);assert.equal(proof.format,'rgb');assert.deepEqual(proof.initial,[255,136,0,255]);assert.deepEqual(proof.blitted,[0,136,255,255]);assert.deepEqual(proof.generation,[0,200,80,255]);assert.equal(proof.initialConsumed,true);assert.equal(proof.blitConsumed,true);assert.equal(proof.redrawRetained,true);assert.deepEqual(proof.receipts.map(row=>row.result),[{}]);assert.ok(!(await readFile(join(workspace,'native-debug.log'),'utf8')).includes('EIO:terminal image file could not be read'));}
 else if(imageFileLifetime){for(const key of ['nativeImageFileTimeout','nativeImageFileClose'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-image-read-lifetime-proof.json'),'utf8'));assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.boundNativePid,evidence.boundNativePid);assert.equal(proof.latePixelRetired,true);assert.deepEqual(proof.freshPixel,[0,200,80,255]);assert.deepEqual(proof.receipts.map(row=>row.result),[{},{},{},{}]);for(const row of [proof.timeoutRead,proof.closeRead]){assert.equal(row.reason,'explicit');assert.equal(row.bytesRead,16);assert.ok(row.releasedAt>row.startedAt);assert.ok(row.closedAt>=row.releasedAt);assert.notEqual(row.pid,evidence.boundNativePid);}assert.ok(proof.timeoutObservedAt-proof.timeoutRead.startedAt>=3500);assert.ok(proof.timeoutObservedAt<proof.timeoutRead.releasedAt);assert.ok(proof.closeRequestedAt-proof.closeRead.startedAt<4000);}
 else if(terminalClients&&process.env.CLAUDE_RESEARCH_IMAGE_PIXELS==='1'){for(const key of ['nativeImagePixels','nativeImageSwap','nativeTerminalImagePixels'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-image-app-proof.json'),'utf8'));assert.equal(proof.sameNativeOwner,true);assert.deepEqual(proof.receipts.map(receipt=>receipt.result),[{},{}]);if(process.env.CLAUDE_RESEARCH_IMAGE_FILES==='1'){assert.equal(evidence.nativeImageFiles,true);assert.equal(evidence.nativeImageFileGeneration,true);assert.equal(proof.namedFiles,true);assert.deepEqual(proof.fileGeneration,[0,200,80,255]);const files=JSON.parse(await readFile(join(workspace,'native-image-files.json'),'utf8'));assert.deepEqual(await readFile(files.initial),await readFile(files.updated));}}
 else if(terminalClients&&process.env.CLAUDE_RESEARCH_IMAGE==='1'){assert.equal(evidence.nativeImageFallback,true);const proof=JSON.parse(await readFile(join(workspace,'native-image-app-proof.json'),'utf8'));assert.equal(proof.text,'Release cover updated');assert.equal(proof.sameNativeOwner,true);assert.equal(proof.receipts.length,3);assert.ok(proof.receipts.every(receipt=>typeof receipt.result.deny==='string'));assert.match(proof.receipts[1].result.deny,/no Image/);}
 else if(terminalClients&&process.env.CLAUDE_RESEARCH_RASTER==='1'){assert.equal(evidence.nativeRaster,true);const proof=JSON.parse(await readFile(join(workspace,'native-raster-app-proof.json'),'utf8'));assert.equal(proof.text,process.env.CLAUDE_RESEARCH_RASTER_BLIT==='1'?'Release \nblitted ':'Release \nupdated ');assert.equal(proof.sameNativeOwner,true);if(process.env.CLAUDE_RESEARCH_RASTER_BLIT==='1'){assert.equal(evidence.nativeRasterBlit,true);assert.equal(proof.blit,true);assert.equal(proof.receipts.length,5);assert.deepEqual(proof.receipts.map(receipt=>receipt.key),['b','f','x','b','b']);assert.deepEqual(proof.receipts[0].result,{});assert.ok(proof.receipts.slice(1,4).every(receipt=>typeof receipt.result.deny==='string'));assert.deepEqual(proof.receipts[4].result,{})}}
 else if(emptyKeyboardClient){
  for(const key of ['nativeEmptyKeyboardClient','nativeClientEmptyRootReachable','nativeClientHiddenInputRefused','nativeClientEmptyReopenContinuity','nativeClientEmptyWithdrawal'])assert.equal(evidence[key],true,key);
  const proof=JSON.parse(await readFile(join(workspace,'native-empty-client-proof.json'),'utf8'));
  assert.deepEqual(proof.receipts.map(row=>row.count),[1,2,3,4,5]);
  assert.ok(proof.receipts.every(row=>row.surface==='desktop'&&row.component==='AbovePrompt'));
  assert.equal(proof.receipts.at(-1).retired,true);
  assert.ok(seed.calls.every(call=>call.path==='/api/hello'||call.path==='/v1/messages?beta=true'),'Unexpected request in the keyboard Client journey');
 }
 else if(terminalClients){
  assert.equal(evidence.nativeTerminalClients,true,'Terminal Client app acceptance required');
  const events=JSON.parse(await readFile(join(workspace,'native-terminal-client-events.json'),'utf8'));
  for(const[kind,key]of [['InfoNotice','k'],['TurnDuration','d']])assert.ok(events.some(event=>event.kind===kind&&event.component===kind&&event.surface==='terminal'&&event.count===1&&event.key===key),'Original terminal Client receipt missing for '+kind);
  const fields=JSON.parse(await readFile(join(workspace,'native-terminal-client-fields.json'),'utf8'));
  assert.ok(fields.some(field=>field.component==='InfoNotice'&&field.surface==='terminal'&&field.value==='rewrite'&&field.requestId.endsWith('\0client\0terminal-client')),'Original terminal Client field namespace missing');
  evidence.nativeTerminalClientScopes=true;
 }
 if(bashScenario&&process.env.CLAUDE_RESEARCH_TERMINAL_PLACEMENTS==='1')assert.equal(evidence.nativeTerminalPlacements,true,'Terminal placements must pass actual app acceptance');
 if(bashScenario&&!bashStanding){const sites=JSON.parse(await readFile(join(workspace,'native-composer-sites.json'),'utf8'));verifyNativeComposerSites(sites);evidence.nativeComposerProducerInputs=true;}
 if(bashScenario&&process.env.CLAUDE_RESEARCH_COMPOSER_ADAPTER==='1'){
  const adapter=JSON.parse(await readFile(join(workspace,'native-composer-adapter.json'),'utf8'));
  assert.equal(adapter.error,undefined,'Original composer helper probe failed');
  const expected=process.env.CLAUDE_RESEARCH_TERMINAL_PLACEMENTS==='1'?['Spinner','SessionMode','PromptHint','TurnDuration','InfoNotice']:['Spinner','SessionMode','PromptHint'];
  assert.deepEqual(adapter.samples.map(sample=>sample.component).sort(),expected.sort(),'Original helper probe missed required placements');
  assert.ok(adapter.samples.every(sample=>sample.rootsBefore===sample.rootsAfter),'Original helper probe leaked a native render root');
  evidence.nativeComposerAdapterProbe=true;
 }

 if(bareMode){evidence.bareVerification=await verifyNativeBareMode(workspace,evidence,{seed:seed.calls,agent:agent.calls});}
 else if(fieldLifetime){evidence.fieldLifetime=await verifyNativeFieldLifetime(workspace,evidence);assert.equal(seed.calls.length,2);}
 else if(!managedPolicy&&!bashScenario&&!fileScenario&&!planScenario){
 const modelImages=agent.requests.flatMap(request=>request.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).filter(block=>block.type==='image');assert.ok(modelImages.some(block=>block.source?.data===createNativeTestImage().toString('base64')),'Actual app upload did not reach the native model intact');
 let finalLedger;for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{const lines=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);finalLedger=lines.filter(row=>row.type==='cost-state').at(-1);break}catch(error){if(error.code!=='ENOENT')throw error}}
 assert.equal(finalLedger?.totalCostUSD,evidence.resumedCost,'Closed native ledger must match the accepted resumed result');
 const prefixCalls=(await readFile(prefixLog,'utf8')).trim().split('\n').map(JSON.parse);
 const originalMain=`/usr/bin/python3 '${join(workspace,'main.py')}'`;
 const mainCalls=prefixCalls.filter(call=>call.args.at(-1)===originalMain);assert.ok(mainCalls.length>0);
 const livePrefix=join(workspace,"user's changed app prefix")+' --live-prefix';
 for(const call of mainCalls){assert.ok(call.prefix===shellPrefix||call.prefix===livePrefix);assert.deepEqual(call.args,[call.prefix===shellPrefix?'--fixture-prefix':'--live-prefix',originalMain]);}
 assert.equal(prefixCalls.some(call=>call.args.at(-1).includes('/cc-app-')),false);
 const selectedRequest=agent.requests.find(request=>JSON.stringify(request.messages??[]).includes('NativeComposerAcceptedFixture'));assert.match(selectedRequest?.model??'',/haiku/i,'The normal composer ignored native model selection');
 const referenceRequest=agent.requests.find(request=>JSON.stringify(request.messages??[]).includes('NativeReferenceReadFixture'));assert.ok(JSON.stringify(referenceRequest?.messages).includes('[Thread:')&&JSON.stringify(referenceRequest?.messages).includes('(session: '+evidence.sessionId+')'),'Thread reference was not resolved into native context');
 assert.ok(agent.calls.some(call=>call.referenceReadResult&&JSON.stringify(call.referenceReadResult).includes('NativeReferenceFileBytes')&&!call.referenceReadError),'Native did not read the approved external fixture');
 assert.ok(agent.calls.some(call=>call.nativeQuestionResult&&!call.nativeQuestionError&&['Custom Alpha','Gamma','Delta','Native notes'].every(value=>JSON.stringify(call.nativeQuestionResult).includes(value))),'Native question answers/notes did not reach the original model result');
 if(previewMode==='html')assert.ok(agent.calls.some(call=>call.nativeQuestionResult&&JSON.stringify(call.nativeQuestionResult).includes('<strong>Native Gamma preview</strong>')),'Original HTML preview annotation was lost');
 const hookReceipt=JSON.parse(await readFile(join(workspace,'native-question-hook-callback.json'),'utf8'));assert.equal(hookReceipt.draw,2);
 assert.ok(agent.calls.some(call=>call.nativeQuestionResult&&!JSON.stringify(call.nativeQuestionResult).includes('Display ')),'Displayed labels leaked into the canonical native answer');
 assert.ok(agent.calls.some(call=>call.pauseWaiting&&call.pauseCancelled),'Native model request survived normal composer Pause');
 assert.equal(seed.calls.length,2);assert.equal(seed.calls[1].model,seed.calls[0].model,'Default model reset did not survive sequential print resumption');assert.ok(agent.calls.some(call=>call.child&&call.delivered));
 }else if(process.env.CLAUDE_RESEARCH_HELD_HELPER==='1'){
 assert.equal(evidence.nativeHeldHelper,true);const proof=JSON.parse(await readFile(join(workspace,'native-held-helper-proof.json'),'utf8'));assert.ok(proof.raw.stdout.includes('STALE_HELD_HELPER'));if(heldSubagent){assert.equal(evidence.nativeHeldSubagentHelper,true);assert.equal(proof.kind,'subagent');assert.ok(proof.started.taskIds.includes(proof.taskId));assert.ok(proof.raw.tasks.some(task=>task.id===proof.taskId&&task.status==='running'));assert.ok(proof.raw.stdout.split('\n').filter(Boolean).map(JSON.parse).some(row=>row.id===proof.taskId&&row.content==='STALE_HELD_HELPER'));} assert.ok(proof.raw.code===0&&proof.raw.signal===null||proof.raw.code===null&&proof.raw.signal==='SIGTERM','Expected original successful helper or cancelled Linux outer shell with retained late stdout');evidence.heldHelperExit=proof.raw.signal==='SIGTERM'?'cancelled-outer-shell':'successful';assert.equal(proof.raw.parentPid,evidence.boundNativePid);assert.equal(proof.started.sessionId,evidence.sessionId);assert.equal(proof.finished?.printed,'STALE_HELD_HELPER');assert.equal(proof.raw.generation,proof.before[heldHelperKind]);assert.equal(proof.raw.policyKey,'[false,false,false]');assert.notEqual(proof.before[heldHelperKind],proof.restricted[heldHelperKind]);assert.ok(proof.samples.length>0&&proof.samples.every(text=>!text.includes('STALE_HELD_HELPER')));const posts=(await readFile(join(workspace,'held-helper-native-posts.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);for(const generation of [proof.restricted[heldHelperKind],proof.restored[heldHelperKind]])assert.ok(posts.some(row=>row.generation===generation&&row.code===0&&row.stdout.includes(heldSubagent?'AppNativeAgent':'AppNativeMain '+evidence.sessionId)));for(const pid of [proof.started.pid,proof.started.parentPid,proof.raw.childPid]){let live=false;try{process.kill(pid,0);live=true}catch(error){if(error.code!=='ESRCH')throw error}assert.equal(live,false,'Owned held helper survived shutdown')}assert.equal(seed.calls.length,2);
}else if(process.env.CLAUDE_RESEARCH_TOOL_WIDTH==='1'){
 assert.equal(evidence.nativeToolRowWidth,true);assert.equal(seed.calls.length,2);assert.equal(await readFile(join(workspace,'file-fixture.txt'),'utf8'),'created\n');
 const proof=JSON.parse(await readFile(join(workspace,'native-tool-width-proof.json'),'utf8'));
 assert.equal(proof.samples.length,3);assert.ok(proof.samples[0].columns>proof.samples[1].columns);assert.equal(proof.samples[2].columns,proof.samples[0].columns);
 assert.equal(proof.noPhantomTurn,true);assert.ok(agent.calls.some(call=>call.turn===1&&call.response?.type==='text'));
}else if(promptBrokerFailure){
 evidence.promptBrokerFailure=await verifyPromptBrokerFailure(workspace,evidence,seed.calls);
}else if(process.env.CLAUDE_RESEARCH_PROMPT_TIMEOUT==='1'){
 const proof=JSON.parse(await readFile(join(workspace,'native-prompt-timeout-proof.json'),'utf8'));
 assert.deepEqual(proof.expired.result,{text:'',cursor:0});assert.ok(proof.expired.finished-proof.expired.started>=3500);
 assert.notEqual(proof.replies[0].requestId,proof.replies[1].requestId);assert.ok(proof.replies[0].releasedAt>proof.expired.finished);
 assert.deepEqual(proof.fresh.result,proof.current);assert.equal(proof.oldDidNotSettleFresh,true);assert.equal(proof.noPhantomTurn,true);
 assert.equal(seed.calls.length,2);assert.equal(evidence.nativePromptRequestTimeout,true);
}else if(process.env.CLAUDE_RESEARCH_POLICY_HELD_CLIENT==='1'){
 const proof=JSON.parse(await readFile(join(workspace,'native-policy-held-proof.json'),'utf8'));
 if(process.env.CLAUDE_RESEARCH_POLICY_BORROWED_CLIENT==='1'){assert.equal(proof.borrowedPolicyClient,true);assert.equal(proof.heldStarted.event.component,'InfoNotice');assert.equal(proof.heldStarted.event.surface,'terminal');assert.match(proof.heldRetired.error,/^HooksError: ui\.press\/ui\.input\/ui\.select: no handler is held under handle -?\d+$/);assert.equal(proof.heldSettled,null);assert.equal(evidence.nativeBorrowedPolicyHeldClient,true);}else assert.equal(proof.heldSettled.result.element,'held-policy-action');
 assert.deepEqual(proof.heldStarted.draft,proof.parent);assert.deepEqual(proof.freshDraft,proof.parent);assert.equal(proof.afterHeld.pressed,0);assert.equal(proof.afterFresh.pressed,1);assert.notEqual(proof.oldToken,proof.freshToken);assert.equal(proof.noPhantomTurn,true);assert.equal(seed.calls.length,2);assert.equal(evidence.nativePolicyHeldClient,true);
}else if(managedPolicy&&!planScenario){
 const prefixCalls=(await readFile(prefixLog,'utf8').catch(error=>{if(error.code==='ENOENT')return '';throw error;})).trim().split('\n').filter(Boolean).map(JSON.parse);if(scenario==='managed'||scenario==='managed-transition')assert.ok(prefixCalls.some(call=>call.args.at(-1).includes('/main.py')));else assert.equal(prefixCalls.some(call=>call.args.at(-1).includes('/main.py')),false);assert.equal(prefixCalls.some(call=>call.args.at(-1).includes('MustNotExecute')),false);assert.ok(agent.calls.some(call=>call.child&&call.delivered));assert.ok(agent.calls.some(call=>call.pauseWaiting&&call.pauseCancelled));assert.equal(seed.calls.length,2);
 }
 if(bashScenario){
  assert.equal(seed.calls.length,2,'Bash decisions must preserve sequential same-session print resumption');
  const buckets=await readdir(join(workspace,'.claude/projects'));let journal;
  for(const bucket of buckets){try{journal=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}
  assert.ok(journal,'Missing original native Bash journal');
  const blocks=journal.flatMap(row=>Array.isArray(row.message?.content)?row.message.content:[]);
  assert.ok(blocks.some(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_research_fixture_1'&&block.is_error===false),'Original Bash Allow result missing');
  assert.ok(blocks.some(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_research_fixture_2'&&block.is_error===true&&String(block.content).includes('rejected')),'Original Bash Deny result missing');
  if(bashStanding){
   assert.equal(evidence.nativeBashStanding,true);assert.equal(await readFile(join(workspace,'fixture.txt'),'utf8'),'synthetic protocol fixture\n');
   for(const turn of [3,4])assert.ok(blocks.some(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_research_fixture_'+turn&&block.is_error===false),'Original remembered Bash result missing');
   const settings=JSON.parse(await readFile(join(workspace,'.claude/settings.local.json'),'utf8'));assert.ok(settings.permissions.allow.includes('Bash('+evidence.editedPrefix+')'));
   assert.equal(blocks.find(block=>block.type==='tool_use'&&block.id==='toolu_research_fixture_3')?.input.command,evidence.originalCommand);
  }else assert.equal(await readFile(join(workspace,'fixture.txt'),'utf8'),'Preserved after denial','Denied or cancelled Bash unexpectedly executed');
 }
 if(fileScenario&&process.env.CLAUDE_RESEARCH_TOOL_WIDTH!=='1'){
  if(fileStanding){
   for(const key of ['nativeFileStanding','nativeFileMatchingRepeat','nativeFileFeedback','nativeRetainedDraft'])assert.equal(evidence[key],true);
   assert.ok(agent.calls.some(call=>call.turn===4&&JSON.stringify(call.messages).includes('Keep the existing file unchanged.')),'Original denial feedback missing from model continuation');
   const inspected=JSON.parse(await readFile(join(workspace,'native-file-standing-dialog-evidence.json'),'utf8'));
   const closed=inspected.events.filter(event=>event.type==='closed').map(event=>event.value);
   assert.equal(closed.length,2,'Matching remembered file operations must not open additional dialogs');
   assert.deepEqual(closed[0].result.permissionUpdates,[{type:'setMode',mode:'acceptEdits',destination:'session'}]);
   assert.deepEqual(closed[1].result,{behavior:'deny',feedback:'Keep the existing file unchanged.'});
  }
  assert.equal(seed.calls.length,2);assert.equal(await readFile(join(workspace,'file-fixture.txt'),'utf8'),'edited\n');assert.ok(agent.calls.some(call=>call.turn===3&&call.response?.type==='text'));
  let journal;for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{journal=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}
  assert.ok(journal,'Missing original file-decision journal');
  const blocks=journal.flatMap(row=>Array.isArray(row.message?.content)?row.message.content:[]);
  for(const turn of (fileStanding?[1,2,3,4]:[1,2,3,4,5,6]))assert.ok(blocks.some(block=>block.type==='tool_result'&&block.tool_use_id==='file_fixture_'+turn&&(turn>3?block.is_error===true&&String(block.content).includes('rejected'):block.is_error!==true&&String(block.content).includes('successfully'))),'Original native file result missing for '+turn);
 }

 if(agentMediaBoundary){assert.equal(evidence.nativeAgentMediaBoundary,true);evidence.agentMediaBoundary=await verifyNativeAgentMediaBoundary(workspace,agent.calls);}
 else if(questionOwnerFailure){assert.equal(evidence.nativeQuestionOwnerFailure,true);evidence.questionOwnerVerification=await verifyNativeQuestionOwnerFailure(workspace,agent.calls);}
 else if(nativeCreditDesktop){evidence.creditVerification=await (nativeCreditScenario==='admin-error'?verifyNativeCreditAdminError:nativeCreditScenario==='admin'?verifyNativeCreditAdmin:['payment-action','payment-http-error'].includes(nativeCreditScenario)?verifyNativeCreditPaymentError:nativeCreditScenario==='payment-failed'?verifyNativeCreditFailure:nativeCreditScenario==='bundle-pending'?verifyNativeCreditBundle:verifyNativeCreditPurchase)(workspace,evidence,creditBilling.state,{seed:seed.calls,agent:agent.calls});}
 else if(nativeModelDesktop){evidence.modelPanelVerification=await verifyNativeModelPanel(workspace,evidence,{seed:seed.calls,agent:agent.calls});}
 else if(promptThemeEveryday){if(combinedEveryday)evidence.everydayVerification=await verifyNativeEveryday(workspace,evidence,{seed:seed.calls,agent:agent.calls});if(modelPolicyNotice)evidence.modelNoticeVerification=await verifyNativeModelNotices(workspace,evidence,{managedPolicy:true});if(process.env.CLAUDE_RESEARCH_QUESTION_TOOL_NOTICE==='1')evidence.questionToolNotice=await verifyNativeQuestionToolNoticeFixture(workspace);for(const key of ['nativeEverydayCombined','nativeAgentReturn','nativePausedWhileWorking','nativeHistorySynchronized','nativeCostSynchronized'])assert.equal(evidence[key],true);assert.ok(agent.calls.some(call=>call.child&&call.delivered));assert.ok(agent.calls.some(call=>call.referenceReadResult!==undefined&&!call.referenceReadError&&JSON.stringify(call.referenceReadResult).includes('Keep migration guidance')));assert.ok(agent.calls.some(call=>call.nativeQuestionResult!==undefined&&!call.nativeQuestionError&&JSON.stringify(call.nativeQuestionResult).includes('Developers')));assert.ok(agent.calls.some(call=>call.pauseWaiting&&call.pauseCancelled));}
 else if(agentReconnectOnly){
  assert.equal(evidence.nativeAgentPromptReconnect,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-agent-reconnect-receipts.json'),'utf8'));
  assert.equal(proof.length,2);assert.deepEqual(proof.map(row=>row.kind).sort(),['completion','edit']);
  for(const row of proof){assert.equal(row.owner,'agent');assert.equal(row.native.length,1);const native=row.native[0];assert.equal(native.status,200);assert.equal(native.reason,'explicit');assert.ok(native.heldAt<=native.releasedAt&&native.deliveredAt>=native.releasedAt);}
  evidence.agentReconnect={lateEditRefused:true,lateCompletionRefused:true,freshReadFillSuggestCompletion:true,parentDraftRetained:true};
 }
 else if(promptExpiryOnly){
  assert.equal(evidence.nativePromptExpiry,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-prompt-expiry-receipts.json'),'utf8'));
  assert.equal(proof.length,1);const receipt=proof[0];
  for(const key of ['staleActionRefused','addressedStaleActionDelivered','freshFill'])assert.equal(receipt[key],true);
  assert.equal(receipt.kind,'expired-attachment');assert.equal(receipt.retired.subtype,'ui_detach');assert.equal(receipt.retired.detached,true);
  assert.equal(receipt.retired.clientSha256,receipt.originalNativeAttachment.clientSha256);assert.ok(receipt.retired.at>=receipt.offlineAt);
  assert.equal(receipt.replacement.subtype,'ui_attach');assert.notEqual(receipt.replacement.clientSha256,receipt.retired.clientSha256);
  assert.equal(typeof receipt.controlAddress,'string');assert.ok(receipt.controlAddress.length>0);
  evidence.parentLeaseExpiry={addressedStaleActionDelivered:true,freshFill:true,retirementAfterOfflineMs:receipt.retired.at-receipt.offlineAt,distinctNativeClient:true};
 }
 else if(promptThemeReconnect)assert.equal(evidence.nativePromptReconnect,true);
 else if(promptThemeReverse)assert.equal(evidence.nativePromptReverseLifetime,true);
 else if(promptThemeStale)assert.equal(evidence.nativePromptStaleOwnership,true);
 else if(actionKeysApp){
  assert.equal(evidence.nativeDesktopActionKeys,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-action-app-proof.json'),'utf8'));
  assert.equal(proof.boundNativePid,evidence.boundNativePid);assert.equal(proof.noPhantomTurn,true);
  if(actionKeyPanesApp){
   assert.equal(evidence.nativeActionKeyPanes,true);
   evidence.nativeActionKeyPaneVerification=verifyNativeActionPaneAppProof(proof);
  }else if(actionKeyDialogApp){
   assert.equal(evidence.nativeActionKeyDialog,true);
   evidence.nativeActionKeyDialogVerification=verifyNativeActionDialogAppProof(proof);
  }else{
  assert.ok(proof.receipts.length>=5);assert.ok(proof.receipts.some(row=>row.view.agentId===proof.taskId));
  assert.ok(proof.receipts.some(row=>row.value.text===proof.parent.text&&row.value.cursor===proof.parent.cursor));
  assert.ok(proof.receipts.some(row=>row.value.text===proof.agent.text&&row.value.cursor===proof.agent.cursor));
  if(actionKeyContextsApp){
   assert.equal(evidence.nativeActionKeyContexts,true);
   const original=JSON.parse(await readFile(join(workspace,'native-action-app-inspection.json'),'utf8'));
   assert.equal(original.contextControl.sequence,8);assert.equal(original.contextControl.owned,false);
   evidence.nativeActionKeyContextVerification=verifyNativeActionContextAppProof(proof);
  }else{
   assert.equal(proof.staleHandled,false);assert.equal(proof.enginePriority,true);assert.equal(proof.rebound,true);
   evidence.nativeDesktopActionKeysVerification={currentDesktopCallback:true,exactMainAndAgentPrompt:true,enginePriority:true,liveRebind:true,retiredActionRefused:true,noPhantomTurn:true};
  }
  }
 }
 else if(fieldBounds){
  assert.equal(evidence.nativeFieldBounds,true);const proof=JSON.parse(await readFile(join(workspace,'native-field-bounds-proof.json'),'utf8'));assert.ok(proof.drawnValueLength>16384);assert.equal(proof.requestedRows,80);assert.ok(proof.revised.length<=16384&&proof.revised.includes('\n')&&proof.revised.endsWith('  '));assert.ok(proof.receipts.some(row=>row.kind==='change'&&row.value===proof.revised));assert.ok(proof.receipts.some(row=>row.kind==='submit'&&row.value===proof.revised));for(const width of [1100,680]){const value=proof.geometry[String(width)];assert.equal(value.fits,true);assert.ok(value.rows>0&&value.rows<80);}assert.equal(proof.noPhantomTurn,true);assert.equal(proof.boundNativePid,evidence.boundNativePid);evidence.nativeFieldBoundsVerification={wholeDrawnValue:true,nativeInputLimit:16384,requestedRows:80,viewportBounded:true,exactChangeAndSubmit:true,noPhantomTurn:true};
 }
 else if(agentSource){
  assert.equal(evidence.nativeAgentSource,true);const proof=JSON.parse(await readFile(join(workspace,'native-agent-source-proof.json'),'utf8'));assert.equal(proof.remounted,true);assert.equal(proof.edits.length,2);assert.ok(proof.nativeUuid&&proof.taskId);for(const owner of ['parent','agent']){const frame=proof[owner];assert.ok(frame.text.startsWith('  '));assert.ok(frame.text.endsWith('  '));assert.equal(frame.cursor,frame.text.indexOf('~~~~')+1);}assert.equal(proof.sent,proof.agent.text.slice(0,proof.agent.cursor)+'\nChecked worker notes.'+proof.agent.text.slice(proof.agent.cursor));assert.ok(proof.reads.some(row=>row.view.agentId===proof.taskId&&row.value.text===proof.agent.text&&row.value.cursor===proof.agent.cursor));const text=call=>(call.messages??[]).flatMap(message=>typeof message.content==='string'?[message.content]:(message.content??[]).filter(block=>block.type==='text').map(block=>block.text)).join('\n');assert.equal(proof.submitted,proof.sent.trimEnd());assert.ok(agent.calls.some(call=>call.child&&text(call).includes(proof.submitted)),'Native-normalized literal Agent source did not reach its original model request');
  evidence.nativeAgentSourceVerification={remounted:true,independentParentDraft:true,nativeCaret:true,rawWhitespace:true,exactAgentSubmission:true,nativeHumanUuid:proof.nativeUuid};
 }
 else if(nativeMcpUrl){assert.equal(evidence.nativeMcpUrlApp,true);evidence.nativeMcpUrl=await verifyNativeMcpUrlApp(workspace,agent.calls,{retry:process.env.CLAUDE_RESEARCH_NATIVE_MCP_URL_RETRY==='1',modern:modernMcpUrl,realBrowser:realMcpBrowser});}
 else if(nativeMcpForm){assert.equal(evidence.nativeMcpFormApp,true);evidence.nativeMcpForm=await verifyNativeMcpFormApp(workspace,agent.calls);}
 else if(mcpElicitation){assert.equal(evidence.mcpElicitationApp,true);evidence.mcpElicitation=await verifyMcpElicitationApp(workspace,seed.calls);}
 else if(genericPermissions){assert.equal(evidence.nativeGenericPermissions,true);const proof=JSON.parse(await readFile(join(workspace,'native-generic-permission-app.json'),'utf8'));evidence.genericPermissions=await verifyNativeGenericPermissions(workspace,agent.calls,proof);}
 else if(idleRedraw){evidence.idleRedraw=await verifyNativeIdleRedraw(workspace,{seedCalls:seed.calls,agentCalls:agent.calls,evidence});}
 else if(cwdNavigation){const proof=JSON.parse(await readFile(join(workspace,'native-search-review-proof.json'),'utf8'));assert.deepEqual(proof.navigation.map(row=>row.width),[1100,680]);for(const row of proof.navigation){assert.equal(row.explorerDirectory,workspace);assert.equal(row.nativePid,evidence.boundNativePid);assert.equal(row.sessionId,evidence.sessionId);assert.equal(row.draft,row.draftBefore);assert.deepEqual(row.documentAfter,row.documentBefore);assert.ok(row.draft.includes('Keep this release draft while browsing files.')&&row.draft.includes('Second line stays unsent.'));}assert.equal(evidence.nativeCwdNavigation,true);assert.equal(evidence.nativeRetainedDraft,true);assert.equal(evidence.resumedPrintSameSession,true);}
 else if(searchReview){assert.equal(evidence.nativeSearchReview,true);const proof=JSON.parse(await readFile(join(workspace,'native-search-review-proof.json'),'utf8'));assert.equal(proof.results.length,4);for(const [index,row] of proof.results.entries()){assert.equal(row.phase,index+1);assert.equal(row.original.tool_use_id,'native_search_review_'+row.phase);assert.equal(row.original.isErrored,row.phase===4);assert.ok(agent.calls.some(call=>(call.searchReviewResults??[]).some(result=>result.tool_use_id===row.id&&!!result.is_error===(row.phase===4))),'Original search result must reach the model');}evidence.searchReview={cases:4,originalResults:true};}
 else if(toolPermissions){assert.equal(evidence.nativeToolPermissions,true);const proof=JSON.parse(await readFile(join(workspace,'native-tool-permission-app.json'),'utf8'));evidence.toolPermissions=await verifyNativeToolPermissions(workspace,agent.calls,proof);}
 else if(notebookEdit){
  assert.equal(evidence.nativeNotebookEdit,true);const proof=JSON.parse(await readFile(join(workspace,'native-notebook-edit-proof.json'),'utf8'));evidence.nativeNotebookEditVerification=await verifyNativeNotebookEdit(workspace,agent.calls,proof);
 }
 else if(mcpOAuth){
  assert.equal(evidence.nativeMcpOAuth,true);const proof=JSON.parse(await readFile(join(workspace,'native-mcp-oauth-proof.json'),'utf8'));assert.equal(proof.originalStateRefusal,true);assert.equal(proof.cancelledBeforeToken,true);assert.equal(proof.authenticated,true);assert.equal(proof.originalTurnAccounting,true);assert.equal(proof.noExtraUserPrompt,true);assert.equal(proof.afterTurns,proof.beforeTurns+2);assert.equal(proof.commandUuids.length,2);assert.notEqual(proof.firstState,proof.secondState);assert.equal(agent.calls.length,0,'MCP authentication must not issue a model request');assert.equal(proof.boundNativePid,evidence.boundNativePid);assert.equal(oauthServer.events.filter(row=>row.kind==='token'&&row.pkceVerified).length,1);assert.ok(oauthServer.events.some(row=>row.kind==='rpc'&&row.method==='tools/list'&&row.authorized));
 }
 else if(process.env.CLAUDE_RESEARCH_MCP_PANEL==='1'){
  assert.equal(evidence.nativeMcpPanel,true);const proof=JSON.parse(await readFile(join(workspace,'native-mcp-panel-proof.json'),'utf8'));assert.equal(proof.noPhantomTurn,true);assert.equal(proof.beforeTurns,proof.afterTurns);assert.equal(proof.boundNativePid,evidence.boundNativePid);assert.deepEqual(proof.captures.map(row=>[row.stage,row.width]),[['details',1100],['details',680],['tools',680]]);for(const row of proof.captures)assert.match(row.paint,row.stage==='tools'?/echo/i:/Research MCP Server/);
 }
 else if(heldModelPause){
  assert.equal(evidence.nativeHeldModelPause,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-held-model-pause-proof.json'),'utf8'));
  assert.equal(proof.ownerRetained,true);assert.equal(proof.lateOutputRejected,true);assert.equal(proof.captures.length,3);
  const held=agent.calls.filter(call=>call.heldModel);assert.equal(held.length,1);assert.equal(held[0].responseClosed,true);assert.equal(held[0].lateResponseAttempted,true);if(heldModelStreaming){assert.equal(held[0].streamingStarted,true);assert.equal(proof.streamingStarted,true);assert.equal(proof.partialVisible,true);if(heldModelRich){assert.equal(held[0].richPreview,true);assert.equal(proof.richPreviewVerified,true);assert.equal(proof.richCaptures.length,2);}}
  const controls=(await readFile(join(workspace,'native-pause-controls.jsonl'),'utf8')).trim().split('\n').map(line=>JSON.parse(line));
  const state=controls.find(row=>row.subtype==='apack_turn_state'&&row.result?.turn?.cancelled===false),cancel=controls.find(row=>row.subtype==='apack_abort_turn'&&row.result?.cancelled===true);
  assert.ok(state&&cancel);assert.equal(cancel.turnId,state.result.turn.id);assert.equal(cancel.status,200);
 }
 else if(activeToolCancel){
  assert.equal(evidence[taskManager?'nativeTaskManager':activeToolPause?'nativeActiveToolPause':'nativeActiveToolCancel'],true);const proof=JSON.parse(await readFile(join(workspace,taskManager?'native-task-manager-proof.json':activeToolPause?'native-active-tool-pause-proof.json':'native-active-tool-cancel-proof.json'),'utf8'));
  for(const key of ['childExited','sideEffectAbsent',activeToolPause?'ownerRetained':'ownedStop'])assert.equal(proof[key],true);
  assert.ok(proof.child.pid>1&&proof.childRetiredAt>=proof.stoppedAt);assert.equal(proof.captures.length,3);assert.equal(proof.sessionId,evidence.sessionId);
  await assert.rejects(readFile(join(workspace,'fixture.txt')),error=>error.code==='ENOENT');
  assert.ok(agent.calls.some(call=>call.fixtureTurn===1&&call.toolNames?.includes('Bash')));
  if(activeToolPause){
   assert.equal(proof.continuedNativePid,proof.boundNativePid);assert.ok(proof.continuedTurns>proof.afterStopTurns);assert.equal(proof.beforeTurns,proof.afterStopTurns);
   if(taskManager){assert.equal(proof.taskStoppedIndependently,true);assert.deepEqual(proof.managerScreens.map(row=>row.width),[1100,680]);if(shellDesktop){assert.equal(evidence.nativeShellDesktop,true);assert.equal(proof.desktopShell,true);assert.equal(proof.managerStopKey,'desktop-stop');for(const screen of proof.managerScreens)assert.ok(screen.text.includes('Owned release review is waiting.'));}else assert.match(proof.managerStopKey,/^(?:Control\+)?[ksx]$/i);}
   assert.equal(proof.backgroundReceipt.toolUseResult.backgroundedByTurnAbort,true);assert.ok(proof.backgroundReceipt.toolUseResult.backgroundTaskId);
   const controls=(await readFile(join(workspace,'native-pause-controls.jsonl'),'utf8')).trim().split('\n').map(line=>JSON.parse(line));
   const state=controls.find(row=>row.subtype==='apack_turn_state'&&row.result?.turn?.cancelled===false),cancel=controls.find(row=>row.subtype==='apack_abort_turn'&&row.result?.cancelled===true);
   assert.ok(state&&cancel);assert.equal(cancel.turnId,state.result.turn.id);assert.equal(cancel.status,200);
   assert.ok(agent.calls.some(call=>call.messages?.some(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_research_fixture_1'&&String(block.content).includes(proof.backgroundReceipt.toolUseResult.backgroundTaskId)))),'Fresh original request must retain the native background task receipt');
  }else assert.ok(!agent.calls.some(call=>call.messages?.some(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_research_fixture_1'))),'Stopped command must not deliver a successful delayed result');
 }
 else if(process.env.CLAUDE_RESEARCH_ATTACHMENT_MEDIA==='1'){assert.equal(evidence.nativeAttachmentMedia,true);}
 else if(process.env.CLAUDE_RESEARCH_CONFIG_THEME==='1'){
  assert.equal(evidence.nativeConfigTheme,true);const proof=JSON.parse(await readFile(join(workspace,'native-config-theme-proof.json'),'utf8'));
  assert.equal(proof.noPhantomTurn,true);assert.deepEqual(proof.finalHumans,proof.originalHumans);assert.equal(proof.captures.length,4);assert.equal(proof.retained.length,3);
  assert.deepEqual(proof.themeReceipts.map(row=>[row.stage,row.theme]),[['cancel','dark'],['commit','light'],['reopen','light'],['restore','dark']]);assert.equal(proof.themeReceipts[2].highlighted,'Light mode');
  for(const row of proof.samples){assert.equal(row.view.taskId,proof.taskId);assert.ok(row.geometry.close.bottom<=row.height);assert.ok(row.geometry.screen.bottom<=row.geometry.viewport.bottom+1);}
 }
 else if(process.env.CLAUDE_RESEARCH_COMMAND_INTERACTIONS==='1'){
  assert.equal(evidence.nativeCommandInteractions,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-command-interactions-proof.json'),'utf8'));
  assert.equal(proof.noPhantomTurn,true);assert.equal(proof.statusScrollRestored,true);
  assert.deepEqual(proof.originalHumans,proof.finalHumans);assert.equal(proof.retained.length,2);
  assert.deepEqual(proof.dateSelections.map(row=>row.label),['Last 7 days','Last 30 days']);
  assert.equal(proof.captures.length,3);assert.equal(proof.clipboardExports.length,2);
  for(const row of proof.samples){assert.equal(row.view.taskId,proof.taskId);assert.ok(row.geometry.close.bottom<=row.height);assert.ok(row.geometry.screen.bottom<=row.geometry.viewport.bottom+1);}
  for(const row of proof.clipboardExports){
   assert.ok(row.formats.includes('image/png'));assert.ok(row.size.width>0&&row.size.height>0);assert.match(row.sha256,/^[a-f0-9]{64}$/);
   const paths=await readdir(join(workspace,'electron-results'),{recursive:true});const matches=paths.filter(path=>path.endsWith('/'+row.file));assert.equal(matches.length,1);
   const png=await readFile(join(workspace,'electron-results',matches[0]));assert.equal(png.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(png.readUInt32BE(16),row.size.width);assert.equal(png.readUInt32BE(20),row.size.height);
   assert.equal((await import('node:crypto')).createHash('sha256').update(png).digest('hex'),row.sha256);
  }
 }
 else if(completionNavigation){assert.equal(evidence.nativeCompletionNavigation,true);}
 else if(managedModelRestart){assert.equal(evidence.nativeManagedModelRestart,true);}
 else if(bashImage){
  assert.equal(evidence.nativeBashImage,true);const proof=JSON.parse(await readFile(join(workspace,'native-bash-image-proof.json'),'utf8'));assert.equal(proof.captures.length,2);assert.ok(proof.notice.includes('Image data detected and sent to Claude'));
 }
 else if(settingsBrokerLoss){
  assert.equal(evidence.nativeSettingsBrokerLoss,true);const proof=JSON.parse(await readFile(join(workspace,'native-settings-broker-proof.json'),'utf8'));assert.equal(proof.captures.length,6);assert.notEqual(proof.old.input.panel.id,proof.fresh.input.panel.id);assert.equal(proof.afterStale.input.panel.id,proof.fresh.input.panel.id);assert.equal(proof.beforeReturn.turns,1);
 }
 else if(helpLinks){
  assert.equal(evidence.nativeHelpLinks,true);const proof=JSON.parse(await readFile(join(workspace,'native-help-links-proof.json'),'utf8'));assert.equal(proof.activations.length,6);assert.equal(proof.requests.length,6);assert.ok(proof.requests.every(url=>url==='https://code.claude.com/docs/en/overview'));assert.equal(proof.captures.length,2);
 }
 else if(helpDesktop){
  assert.equal(evidence.nativeHelpDesktop,true);if(agentHelpDesktop)assert.equal(evidence.nativeAgentHelpDesktop,true);const proof=JSON.parse(await readFile(join(workspace,agentHelpDesktop?'native-agent-help-proof.json':'native-help-proof.json'),'utf8'));assert.equal(proof.captures.length,6);assert.deepEqual(proof.samples.map(row=>[row.tab,row.width]),[['General',1100],['General',680],['Commands',1100],['Commands',680],['Custom commands',1100],['Custom commands',680]]);assert.equal(proof.after.turns,proof.baseline.turns);assert.equal(proof.after.claude.totalCostUsd,proof.baseline.claude.totalCostUsd);
 }
 else if(agentSettingsRoutes){
  assert.equal(evidence.nativeAgentSettingsRoutes,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-agent-settings-routes-proof.json'),'utf8'));
  assert.deepEqual(proof.routes.map(row=>[row.command,row.tab]),[['status','Status'],['usage','Usage'],['cost','Usage'],['stats','Stats']]);
  assert.equal(proof.captures.length,8);assert.equal(proof.before.turns,proof.after.turns);assert.equal(proof.before.claude.totalCostUsd,proof.after.claude.totalCostUsd);
  for(const row of proof.routes)assert.deepEqual(row.view,proof.originalView);
 }
 else if(process.env.CLAUDE_RESEARCH_AGENT_SETTINGS==='1'){
  assert.equal(evidence.nativeAgentSettings,true);const proof=JSON.parse(await readFile(join(workspace,'native-agent-settings-proof.json'),'utf8'));
  assert.equal(proof.desktop,true);assert.equal(proof.noPhantomTurn,true);assert.deepEqual(proof.finalHumans,proof.originalHumans);
  if(proof.statsLoadingTrace){assert.ok(proof.statsLoadingTrace.some(row=>row.loaded));assert.ok(proof.statsLoadingTrace.every(row=>!row.missingDataClaim));}
  const calendar=proof.calendarSamples!==undefined;
  assert.equal(proof.captures.length,calendar?16:14);assert.equal(proof.samples.length,calendar?12:10);assert.ok(proof.expectedStatsTokens>0);assert.ok(proof.usageUuids.length>0);
  if(calendar){assert.deepEqual(proof.calendarSamples.map(row=>row.width),[1100,680]);for(const row of proof.calendarSamples){assert.equal(row.cells,364);assert.ok(row.active>0);assert.equal(row.graphical,true);assert.equal(row.realWheel,true);assert.equal(row.geometry.visible,true);for(const edge of ['top','left'])assert.ok(row.geometry.target[edge]>=row.geometry.viewport[edge]-1);for(const edge of ['bottom','right'])assert.ok(row.geometry.target[edge]<=row.geometry.viewport[edge]+1);}}
  assert.deepEqual(proof.totals,{input:proof.expectedStatsInputTokens,output:proof.expectedStatsOutputTokens,all:proof.expectedStatsTokens});
  assert.deepEqual(proof.retained.map(row=>row.draft),['Keep the worker release review draft unchanged.','/config']);
  for(const label of ['status-tab','config-controls','usage-tab','stats-overview',...(calendar?['stats-calendar']:[]),'stats-models'])assert.deepEqual(proof.samples.filter(row=>row.label===label).map(row=>row.width),[1100,680]);
  for(const row of proof.samples){assert.equal(row.view.taskId,proof.taskId);assert.ok(row.geometry.close.bottom<=row.height);assert.ok(row.geometry.panel.right<=row.width);assert.match(row.text,/Agent ·/);if(row.label==='status-tab')assert.match(row.text,/2\.1\.302/);if(row.label==='usage-tab')assert.match(row.text,/Context window/);if(row.label==='stats-models')assert.match(row.text,/Cache read/);}
 }
 else if(process.env.CLAUDE_RESEARCH_AGENT_STRUCTURED==='1'){assert.equal(evidence.nativeAgentStructured,true);const proof=JSON.parse(await readFile(join(workspace,'native-agent-structured-proof.json'),'utf8'));evidence.nativeAgentStructuredVerification=verifyAgentStructuredProof(proof,agent.calls);assert.equal(seed.calls.length,2);}
 else if(process.env.CLAUDE_RESEARCH_COMPOSER_WRAP==='1'){
  assert.equal(evidence.nativeComposerWrap,true);const proof=JSON.parse(await readFile(join(workspace,'native-composer-wrap-proof.json'),'utf8'));
  assert.equal(proof.noPhantomTurn,true);assert.deepEqual(proof.samples.map(row=>[row.width,row.height]),[[1100,900],[680,600],[680,800],[680,600],[1100,900]]);for(const row of proof.samples){assert.equal(row.geometry.horizontalOverflow,false);assert.equal(row.geometry.caretVisible,true);assert.ok(row.geometry.scrollers.length<=1);assert.equal(row.canonical,proof.canonical);}assert.ok(proof.samples[1].geometry.lines>proof.samples[0].geometry.lines);assert.equal(seed.calls.length,2);
 }
 else if(settingsRoutes){
  assert.equal(evidence.nativeSettingsRoutes,true);const proof=JSON.parse(await readFile(join(workspace,'native-settings-routes-proof.json'),'utf8'));
  for(const key of ['desktopPanels','editorRetained','modelCostUnchangedDuringRoutes','sameSessionRecovery'])assert.equal(proof[key],true);
  assert.deepEqual(proof.routes.map(row=>[row.command,row.tab]),[['status','Status'],['usage','Usage'],['cost','Usage'],['stats','Stats']]);assert.equal(proof.captures.length,8);
  assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.boundNativePid,evidence.boundNativePid);assert.equal(agent.calls.length,0);
 }
 else if(configDesktop){const statusOnly=process.env.CLAUDE_RESEARCH_STATUS_ROWS==='1';assert.equal(JSON.parse(await readFile(join(workspace,'native-config-desktop-proof.json'),'utf8')).nativeStatusRows===true,statusOnly,'Wrong desktop Settings profile');assert.equal(JSON.parse(await readFile(join(workspace,'native-config-desktop-proof.json'),'utf8')).nativeStatusDiagnostics===true,process.env.CLAUDE_RESEARCH_STATUS_DIAGNOSTICS==='1','Wrong diagnostic profile');assert.equal(JSON.parse(await readFile(join(workspace,'native-config-desktop-proof.json'),'utf8')).nativeSettingsEditors===true,process.env.CLAUDE_RESEARCH_SETTINGS_EDITORS==='1','Wrong Settings editor profile');if(process.env.CLAUDE_RESEARCH_STATUS_DIAGNOSTICS==='1')assert.equal(JSON.parse(await readFile(join(workspace,'native-config-desktop-proof.json'),'utf8')).nativeStatusDiagnosticList,true,'Missing full diagnostic reading journey');if(externalConsent)assert.ok(JSON.parse(await readFile(join(workspace,'native-config-desktop-proof.json'),'utf8')).externalConsent,'Missing external consent journey');if(process.env.CLAUDE_RESEARCH_SETTINGS_GROUPS==='1')assert.ok(JSON.parse(await readFile(join(workspace,'native-config-desktop-proof.json'),'utf8')).groupEditors,'Missing native grouped Settings journey');if(process.env.CLAUDE_RESEARCH_SETTINGS_EDITORS==='1')assert.ok(JSON.parse(await readFile(join(workspace,'native-config-desktop-proof.json'),'utf8')).modelEditor,'Missing native Model editor journey');const verified=await verifyNativeDesktopSettings(workspace,evidence,{seed:seed.calls,agent:agent.calls});evidence.nativeConfigDesktopLanguageApplied=verified.nativeConfigDesktopLanguageApplied;if(remoteHome){assert.ok(verified.nativeRemoteHomeSettings,'Missing original cloud Settings journey');evidence.nativeRemoteHomeSettings=true;}if(updateDecisions){assert.ok(verified.nativeUpdateDecisions,'Missing update decision journey');evidence.nativeUpdateDecisions=true;}if(process.env.CLAUDE_RESEARCH_SETTINGS_UPDATES==='1'){assert.ok(verified.nativeUpdateSettings,'Missing native update Settings journey');evidence.nativeUpdateSettings=true;}if(externalConsent){assert.ok(verified.nativeExternalConsent,'Missing verified external consent');evidence.nativeExternalConsent=true;}if(process.env.CLAUDE_RESEARCH_SETTINGS_GROUPS==='1'){assert.ok(verified.nativeGroupedSettings,'Missing verified grouped Settings');evidence.nativeGroupedSettings=true;}if(statusOnly)evidence.nativeStatusRows=true;if(process.env.CLAUDE_RESEARCH_SETTINGS_EDITORS==='1')evidence.nativeSettingsEditors=true;}
 else if(refusalNotice){await writeFile(join(workspace,'model-calls.json'),JSON.stringify({seed:seed.calls,agent:agent.calls}));const proof=JSON.parse(await readFile(join(workspace,'native-refusal-app.json'),'utf8'));assert.equal(proof.decision,refusalNotice);assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.shown.kind,'refusal_fallback_prompt');assert.equal(proof.shown.originalModel,'claude-opus-5');assert.equal(proof.shown.fallbackModel,'claude-opus-4-8');assert.equal(proof.captures.length,process.env.CLAUDE_RESEARCH_REFUSAL_EMPTY_DRAFT==='1'?6:4);assert.equal(proof.sameSessionRecovery,true);assert.equal(agent.calls.length,refusalNotice==='retry_fallback'?4:3);}
 else if(pluginHint){await writeFile(join(workspace,'model-calls.json'),JSON.stringify({seed:seed.calls,agent:agent.calls}));evidence.pluginHint=await verifyNativePluginHintApp(workspace,agent.calls,evidence,pluginHint);}
 else if(lspRecommendation){await writeFile(join(workspace,'model-calls.json'),JSON.stringify({seed:seed.calls,agent:agent.calls}));evidence.lspRecommendation=await verifyLspRecommendationApp(workspace,agent.calls,evidence,lspRecommendation);}
 else if(process.env.CLAUDE_RESEARCH_STATUS_STARTUP==='1'){
  assert.equal(evidence.nativeStatusStartup,true);const proof=JSON.parse(await readFile(join(workspace,'native-status-startup-proof.json'),'utf8'));
  assert.equal(proof.noPhantomTurn,true);assert.equal(proof.samples.length,2);assert.ok(proof.helper.length>0);assert.ok(proof.posts.some(row=>row.kind==='main'&&row.code===0&&[200,202].includes(row.httpStatus)&&row.parentPid===evidence.boundNativePid&&row.stdout.includes('Session ready')));for(const sample of proof.samples)assert.equal(sample.status,'Session ready\nReviewing release notes');assert.equal(seed.calls.length,2);
 }
 else if(process.env.CLAUDE_RESEARCH_AGENT_CARET_FAST==='1'){
  assert.equal(evidence.nativeAgentCaretFast,true);const proof=JSON.parse(await readFile(join(workspace,'native-agent-caret-fast-proof.json'),'utf8'));
  assert.equal(proof.noAcknowledgementWaitBeforeKeys,true);assert.equal(proof.noPhantomTurn,true);assert.deepEqual(proof.initialNative,{text:proof.base,cursor:9});assert.deepEqual(proof.finalNative,{text:proof.expected,cursor:14});assert.equal(seed.calls.length,2);
 }
 else if(process.env.CLAUDE_RESEARCH_AGENT_CARET==='1'){
  assert.equal(evidence.nativeAgentCaret,true);const proof=JSON.parse(await readFile(join(workspace,'native-agent-caret-proof.json'),'utf8'));
  assert.equal(proof.samples.length,2);for(const sample of proof.samples){assert.deepEqual(sample.positions.map(row=>row.native.cursor),[0,9,proof.base.length]);assert.equal(sample.finalNative.text,proof.expected);assert.equal(sample.finalNative.cursor,14);}
  assert.equal(proof.noPhantomTurn,true);assert.equal(seed.calls.length,2);
 }
 else if(agentImeCancel){
  assert.equal(evidence.nativeAgentImeCancellation,true);const proof=JSON.parse(await readFile(join(workspace,'native-agent-ime-cancel-proof.json'),'utf8'));
  assert.equal(proof.beforeInterrupt.composing,true);assert.equal(proof.cancelled.composing,false);
  for(const state of [proof.cancelled,proof.restored])for(const key of ['doc','selection','storedMarks'])assert.deepEqual(state[key],proof.committed[key]);
  assert.ok(!proof.edits.some(edit=>edit.text.includes(proof.preview)));assert.ok(proof.nativeUuid);assert.ok(proof.finalText.includes('**checked**'));
  assert.ok(agent.calls.some(call=>call.child&&JSON.stringify(call.messages??[]).includes(proof.finalText)),'Committed Agent text missing from original worker request');
 }
 else if(process.env.CLAUDE_RESEARCH_AGENT_IME_LIFETIME==='1'){
  assert.equal(evidence.nativeAgentImeLifetime,true);const proof=JSON.parse(await readFile(join(workspace,'native-agent-ime-lifetime-proof.json'),'utf8'));
  assert.equal(proof.beforeInterrupt.composing,true);assert.deepEqual(proof.restored.doc,proof.committed.doc);assert.deepEqual(proof.restored.selection,proof.committed.selection);assert.deepEqual(proof.restored.storedMarks,proof.committed.storedMarks);
  assert.ok(!proof.edits.some(edit=>edit.text.includes(proof.preview)));assert.ok(proof.nativeUuid);assert.ok(proof.finalText.includes('**checked**'));
  assert.ok(agent.calls.some(call=>call.child&&JSON.stringify(call.messages??[]).includes(proof.finalText)),'Committed Agent text missing from original worker request');
 }
 else if(agentRoundtrip){const result=await verifyNativeAgentRoundtrip(workspace,evidence,{seed:seed.calls,agent:agent.calls});evidence.nativeAgentRoundtrip=result;}
 else if(promptRichSelection){assert.equal(evidence.nativeRichAgentDraft,true);if(process.env.CLAUDE_RESEARCH_AGENT_IME==='1'){assert.equal(evidence.nativeAgentIme,true);const proof=JSON.parse(await readFile(join(workspace,'native-agent-ime-proof.json'),'utf8')),composition=JSON.parse(await readFile(join(workspace,'native-agent-ime-composition-proof.json'),'utf8'));assert.ok(proof.nativeUuid&&proof.remounted);assert.equal(composition.turnsBefore,composition.turnsAfter);assert.ok(!composition.committedEdits.some(edit=>edit.text.includes(composition.preview)));assert.equal(proof.text.split(composition.commit).length,2);assert.ok(agent.calls.some(call=>call.child&&JSON.stringify(call.messages??[]).includes(composition.commit)),'Committed Agent composition did not reach its native model request');} if(process.env.CLAUDE_RESEARCH_AGENT_REFERENCE==='1'){assert.equal(evidence.nativeAgentReference,true);const proof=JSON.parse(await readFile(join(workspace,'native-agent-reference-proof.json'),'utf8'));assert.ok(proof.nativeUuid&&proof.remounted&&proof.referenceHref.startsWith('apack-ref://thread/'));assert.ok(agent.calls.some(call=>call.child&&JSON.stringify(call.messages??[]).includes(proof.referenceHref)),'Selected-Agent reference did not reach its native model request');}}
 else if(managedMedia){assert.equal(evidence.nativeManagedMedia,true);const proof=JSON.parse(await readFile(join(workspace,'native-managed-media-proof.json'),'utf8'));for(const key of ['unlisted','unmanaged','settled'])assert.equal(typeof proof[key].deny,'string');const managed=JSON.parse(await readFile(join(workspace,'native-managed-media.json'),'utf8'));assert.equal(managed.listed.base64,createNativeTestImage().toString('base64'));const images=agent.calls.flatMap(call=>call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).filter(block=>block.type==='image');assert.ok(images.some(block=>block.source?.data===createNativeTestImage().toString('base64')));evidence.nativeManagedMediaBytesIntact=true;}
 else if(composerPhase){
  for(const key of ['nativeComposerPhase',permissionAdmission?'nativePermissionAdmission':permissionRefusal?'nativePermissionRefusal':composerCold?'nativeComposerCold':'nativeComposerPhaseReload','nativeComposerPhaseOnSend','nativeComposerPhaseRestore'])assert.equal(evidence[key],true);
  const proof=JSON.parse(await readFile(join(workspace,'native-composer-phase-proof.json'),'utf8'));
  assert.equal(proof.plannedMode,'plan');assert.equal(proof.editedMode,proof.originalMode);
  if(permissionAdmission){assert.equal(proof.admittedMode,'bypassPermissions');assert.equal(proof.originalMode,'bypassPermissions');assert.equal(proof.plannedPrePlanMode,'bypassPermissions');assert.notEqual(proof.reopenedNativePid,evidence.boundNativePid);evidence.nativePermissionAdmissionVerification={originalAdmission:true,liveDefaultToBypass:true,planRestoresBypass:true,reopenedNativePid:proof.reopenedNativePid};}
  if(permissionRefusal){
   assert.equal(proof.nativeReason,permissionRestriction==='settings'?'Cannot set permission mode to bypassPermissions because it is disabled by settings or configuration':'Cannot set permission mode to bypassPermissions because the session was not launched with --dangerously-skip-permissions');
   if(permissionRestriction==='settings'){
    assert.equal(evidence.nativePermissionSettingsRestriction,true);assert.equal(proof.settingsTransitions.length,2);
    assert.deepEqual(proof.settingsTransitions.map(row=>row.disabled),[false,true]);
    for(const row of proof.settingsTransitions){assert.equal(row.mode,proof.originalMode);assert.equal(row.nativeMode,proof.originalMode);assert.equal(row.nativePid,evidence.boundNativePid);assert.equal(row.staged,proof.staged.stored);assert.equal(row.reason,row.disabled?proof.nativeReason:'Cannot set permission mode to bypassPermissions because the session was not launched with --dangerously-skip-permissions');}
    const settings=JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8'));assert.equal(settings.permissions.disableBypassPermissionsMode,'disable');
    evidence.nativePermissionSettingsTransitions=proof.settingsTransitions;
   }
   assert.equal(proof.refusedMode,proof.originalMode);assert.equal(proof.refusedNativeMode,proof.originalMode);
   assert.equal(JSON.parse(proof.staged.stored).phase,'Plan');
   evidence.nativePermissionRefusalVerification={nativeReason:proof.nativeReason,acceptedModePreserved:true,stagedPlanPreserved:true,allowedChoiceRecovery:true};
  }
  for(const text of [proof.planText,proof.editText,...(windowPhase?[proof.mainFollowText]:[])])assert.equal(proof.history.filter(row=>row.text===text).length,1);
  const planCall=agent.calls.find(call=>JSON.stringify(call.messages??[]).includes(proof.planText));
  assert.ok(planCall,'Original native Plan prompt did not reach the model');
  assert.ok(JSON.stringify(planCall.messages).includes('Plan mode is active'),'Original native Plan reminder missing');
  assert.ok(agent.calls.some(call=>JSON.stringify(call.messages??[]).includes(proof.editText)),'Original native Edit prompt did not reach the model');
  let journal;
  for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{journal=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}
  assert.ok(journal,'Original phase session journal missing');
  const accepted=[];
  for(const text of [proof.planText,proof.editText,...(windowPhase?[proof.mainFollowText]:[])]){
   const rows=journal.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&(typeof row.message?.content==='string'?row.message.content===text:row.message?.content?.some(block=>block.type==='text'&&block.text===text)));
   assert.equal(rows.length,1,'Native human prompt must be recorded exactly once');
   assert.ok(proof.history.some(row=>row.uuid===rows[0].uuid&&row.text===text),'App human identity must match original journal');accepted.push(rows[0].uuid);
  }
  if(windowPhase){
   assert.equal(evidence.nativeWindowPhase,true);
   assert.equal(proof.mainInitial.phase,'Plan');assert.equal(proof.popoutInitial.phase,'Edit');
   assert.notEqual(proof.mainInitial.revision,proof.popoutInitial.revision);
   assert.equal(proof.mainPending?.phase,'Plan');assert.notEqual(proof.mainPending.revision,proof.mainInitial.revision);
   assert.deepEqual(proof.popoutAfterMain,proof.popoutInitial);assert.deepEqual(proof.popoutReloaded,proof.popoutInitial);
   assert.deepEqual(proof.mainAfterPopout,proof.mainPending);assert.deepEqual(proof.focus,{main:false,popout:true});
   const focusRows=(await readFile(join(workspace,'native-window-focus-protocol.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
   assert.ok(focusRows.length>=2&&focusRows.every(row=>row.method==='Emulation.setFocusEmulationEnabled'&&row.enabled===false));
   evidence.nativeWindowPhaseVerification={independentStageRevisions:true,retainedOtherWindowStage:true,popoutReload:true,mainSurvivesClose:true,nativeHumanUuids:accepted};
  }
  if(composerCold){
   evidence.stagedDirectoryVerification=await verifyNativeStagedDirectories(workspace,evidence,{seed:seed.calls,agent:agent.calls});
   if(savedPlan){
    assert.equal(evidence.nativeComposerSavedPlan,true);assert.equal(proof.reopenedPrePlanMode,proof.originalMode);
    assert.equal(proof.beforePrintMode,'plan');assert.equal(proof.printPermissionMode,proof.originalMode);
    assert.ok(seed.calls.some(call=>JSON.stringify(call.messages??[]).includes(proof.printEditText)),'Print Edit did not reach original native model');
   }
   assert.notEqual(proof.priorMainPid,proof.coldMainPid);assert.notEqual(proof.priorApiPid,proof.coldApiPid);
   for(const pid of [proof.priorMainPid,proof.priorApiPid]){try{process.kill(pid,0);assert.fail('Prior app/backend still alive')}catch(error){assert.equal(error.code,'ESRCH')}}
  }
  assert.notEqual(accepted[0],accepted[1]);evidence.nativeComposerPhaseReceiptVerification={originalMode:proof.originalMode,planMode:proof.plannedMode,restoredMode:proof.editedMode,humanUuids:accepted,originalPlanReminder:true};
 }
 else if(stagedDirectories)evidence.stagedDirectoryVerification=await verifyNativeStagedDirectories(workspace,evidence,{seed:seed.calls,agent:agent.calls});
 else if(process.env.CLAUDE_RESEARCH_LOG==='1'){assert.equal(evidence.nativeLog,true);evidence.log=await verifyNativeLogFixture(workspace);}
 else if(process.env.CLAUDE_RESEARCH_NOTIFY==='1'){assert.equal(evidence.nativeNotify,true);evidence.notify=await verifyNativeNotifyFixture(workspace);}
 else if(process.env.CLAUDE_RESEARCH_COMPOSE==='1'){assert.equal(evidence.nativeCompose,true);evidence.compose=await verifyNativeComposeFixture(workspace);}
 else if(process.env.CLAUDE_RESEARCH_SAFE_MODE==='1'){assert.equal(evidence.nativeSafeMode,true);assert.equal(evidence.nativePrivateControlsSuppressed,true);assert.equal(evidence.resumedPrintSameSession,true);}
 else if(process.env.CLAUDE_RESEARCH_SELECT_EMPTY==='1'){assert.equal(evidence.nativeSelectEmpty,true);evidence.selectEmpty=await verifyNativeSelectFixture(workspace);}
 else if(process.env.CLAUDE_RESEARCH_CONFIG_SHORTHAND==='1'){
  assert.equal(evidence.nativeConfigShorthand,true);const proof=JSON.parse(await readFile(join(workspace,'native-config-shorthand-proof.json'),'utf8'));assert.equal(proof.receipts.length,4);assert.equal(proof.receipts[2].settings.spinnerTipsEnabled,false);assert.equal(proof.receipts[3].settings.spinnerTipsEnabled,true);
 }
 else if(windowAgent){
  evidence.agentStatusRecovery=await verifyAgentStatusRecovery(workspace);
  for(const key of ['nativeWindowAgentSwitch','nativeWindowAgentDrafts','nativeWindowAgentPrompt','nativeWindowAgentParentRefused','nativeWindowAgentDetach'])assert.equal(evidence[key],true);
  const proof=JSON.parse(await readFile(join(workspace,'native-window-agent-proof.json'),'utf8'));
  assert.equal(proof.receipts.length,3);assert.ok(proof.taskId);
  assert.equal(proof.backendDelivered,true);assert.ok(proof.addressedOldAction?.mountId);
  assert.notEqual(proof.addressedOldAction.mountId,proof.old.mountId);
  assert.equal(proof.addressedOldAction.actionId,proof.old.actionId);
  assert.equal(proof.addressedOldAction.threadId,proof.old.threadId);
  const controls=(await readFile(join(workspace,'app-data/apack/logs/app-events.log'),'utf8')).trim().split('\n').filter(Boolean).map(line=>JSON.parse(line));
  assert.ok(controls.some(row=>row.meta?.from&&row.meta.event?.type==='CLAUDE_UI_PRESS'&&row.meta.event.mountId===proof.addressedOldAction.mountId&&row.meta.event.threadId===proof.addressedOldAction.threadId&&row.meta.event.actionId===proof.addressedOldAction.actionId),'Old native token must reach backend through addressed current Agent mount');
  assert.ok(agent.calls.some(call=>JSON.stringify(call.messages??[]).includes('Continue after closing the popout.')));
 }
 else if(multipleWindowSelection){for(const key of ['nativeWindowSelection','nativeWindowCopy','nativeWindowPromptEligibility','nativeWindowSelectionAfterDetach'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-window-selection-proof.json'),'utf8'));assert.equal(proof.reads.length,3);assert.equal(proof.copies.length,1);assert.equal(proof.secondOwner.nativePid,evidence.boundNativePid);assert.equal(proof.secondOwner.sessionId,evidence.sessionId);assert.ok(agent.calls.some(call=>JSON.stringify(call.messages??[]).includes('Continue after closing the popout.')));}
 else if(multipleWindows){for(const key of ['nativeMultipleWindows','nativeWindowDrafts','nativeWindowRouting','nativeForeignWindowRefused','nativeWindowDetachSurvived'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-multiple-window-proof.json'),'utf8'));assert.equal(proof.receipts.length,4);assert.equal(proof.secondOwner.nativePid,evidence.boundNativePid);assert.equal(proof.secondOwner.sessionId,evidence.sessionId);assert.ok(agent.calls.some(call=>JSON.stringify(call.messages??[]).includes('Continue after closing the popout.')));}
 else if(process.env.CLAUDE_RESEARCH_CONFIG_LAYOUT==='1'){
  assert.equal(evidence.nativeConfigLayout,true);const proof=JSON.parse(await readFile(join(workspace,'native-config-layout-proof.json'),'utf8'));
  assert.equal(proof.noPhantomTurn,true);assert.equal(proof.captures.length,6);assert.equal(proof.samples.length,4);
  for(const row of proof.samples){assert.ok(row.geometry.close.bottom<=row.height);assert.ok(row.geometry.screen.bottom<=row.geometry.viewport.bottom+1);if(row.label==='picker-guidance')assert.match(row.text,/Enter to confirm.*Esc to cancel/);else assert.match(row.text,/Version[\s\S]*2\.1\.302/);}
 }
 else if(process.env.CLAUDE_RESEARCH_CONFIG_MODEL==='1'){assert.equal(evidence.nativeConfigModel,true);const proof=JSON.parse(await readFile(join(workspace,'native-config-model-proof.json'),'utf8'));assert.match(proof.receipts[0].selectedSettings.model,/sonnet/i);assert.match(seed.calls.at(-1).model,/sonnet/i);assert.equal(proof.captures.length,4);}
 else if(configCallbacks){assert.equal(evidence.nativeConfigLanguage,true);assert.ok(agent.calls.some(call=>JSON.stringify(call.messages??[]).includes('Always respond in French.')),'Original Config language preference did not reach the native model request');evidence.nativeConfigLanguageApplied=true;assert.equal(evidence.nativeConfigCallbacks,true);assert.equal(evidence.nativeConfigPersistence,true);assert.equal(evidence.nativeConfigReturn,true);}
 else if(sourceFill){
  assert.equal(evidence.nativeSourceFill,true);const proof=JSON.parse(await readFile(join(workspace,'native-source-fill-proof.json'),'utf8'));
  assert.deepEqual(proof.operations.map(row=>row.input.mode),['append','insert','replace','append']);
  for(const row of proof.operations){assert.equal(row.result.isFilled,true);const offset=row.input.mode==='replace'?0:row.input.mode==='append'?row.before.text.length:row.before.cursor;const text=row.input.mode==='replace'?row.input.text:row.before.text.slice(0,offset)+row.input.text+row.before.text.slice(offset);assert.equal(row.after.text,text);assert.equal(row.after.cursor,offset+row.input.text.length);}
  assert.ok(proof.operations[0].before.text.includes('\n'));assert.ok(proof.firstText.includes(proof.referenceHref));assert.ok(!proof.secondText.includes(proof.referenceHref));assert.equal(proof.withdrawnReferences.length,0);
  let journal;for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{journal=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}
  for(const [index,uuid] of [proof.firstUuid,proof.secondUuid].entries()){const rows=journal.filter(row=>row.type==='user'&&row.uuid===uuid);assert.equal(rows.length,1);const text=typeof rows[0].message.content==='string'?rows[0].message.content:rows[0].message.content.filter(block=>block.type==='text').map(block=>block.text).join('\n');assert.equal(text,proof.submits[index].text);assert.ok(agent.calls.some(call=>(call.messages??[]).some(message=>(typeof message.content==='string'?message.content:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text).join('\n'):'').includes(index===0?proof.firstText:proof.secondText))),'Original model missed source-filled message');}
  assert.equal(evidence.nativeSourceFillReload,true);assert.equal(proof.reloads.length,2);for(const [index,row] of proof.reloads.entries()){assert.equal(row.linked,index===0);assert.equal(row.text,index===0?proof.firstText:proof.secondText);assert.equal(row.restoredDocument,true);assert.equal(row.editable,true);assert.equal(row.sameNativePid,true);assert.equal(row.references.length,index===0?1:0);}
  evidence.nativeSourceFillVerification={modes:['replace','append','insert'],rendererReload:true,hardBreak:true,retainedReference:true,explicitReferenceWithdrawal:true,nativeHumanUuids:[proof.firstUuid,proof.secondUuid]};
 }
 else if(promptSource){
  assert.equal(evidence.nativePromptSource,true);assert.equal(evidence.nativeStructuredPrompt,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-prompt-source-proof.json'),'utf8'));assert.equal(proof.receipts.length,2);
  const [uri,fence]=proof.receipts;assert.equal(uri.stage,'uri');assert.equal(fence.stage,'fence');assert.equal(fence.result.text,uri.result.text);
  assert.equal(fence.input,uri.result.text.slice(0,uri.result.cursor)+' '+uri.result.text.slice(uri.result.cursor));
  assert.equal(proof.afterFence,fence.result.text.slice(0,fence.result.cursor-1)+fence.result.text.slice(fence.result.cursor));assert.equal(proof.expected,proof.afterFence+'\nReview linked notes.');
  assert.ok(proof.expected.includes(proof.referenceHref));assert.ok(agent.calls.some(call=>(call.messages??[]).some(message=>JSON.stringify(message).includes(proof.referenceHref)&&(typeof message.content==='string'?message.content:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text).join('\n'):'').includes(proof.expected))),'Original model lost exact native source');
  let journal;for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{journal=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}
  const rows=journal.filter(row=>row.type==='user'&&row.uuid===proof.sentUuid);assert.equal(rows.length,1);const text=typeof rows[0].message.content==='string'?rows[0].message.content:rows[0].message.content.filter(block=>block.type==='text').map(block=>block.text).join('\n');assert.equal(text,proof.submitted);
  evidence.nativePromptSourceVerification={uriCaret:true,fenceCaret:true,exactRawText:true,retainedReference:true,nativeHumanUuid:proof.sentUuid};
 }
 else if(promptFontResets){if(promptLineResets)evidence.promptLineResetVerification=await verifyPromptLineResets(workspace,evidence,{seed:seed.calls,agent:agent.calls});else evidence.promptFontResetVerification=await verifyPromptFontResets(workspace,evidence,{seed:seed.calls,agent:agent.calls});}
 else if(promptBoundaries){
  assert.equal(evidence.nativePromptBoundaries,true);assert.equal(evidence.nativeStructuredPrompt,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-prompt-boundary-proof.json'),'utf8'));
  assert.ok(proof.nativeRewrite.text.includes('~~~ts'));assert.ok(proof.canonical.includes('```ts'));
  assert.ok(proof.canonical.includes(proof.referenceHref));assert.ok(proof.canonical.includes('const readyChecked = true'));
  assert.ok(agent.calls.some(call=>JSON.stringify(call.messages??[]).includes('const readyChecked = true')&&JSON.stringify(call.messages).includes(proof.referenceHref)),'Original model request lost code or linked context');
  let journal;for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{journal=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}
  const rows=journal.filter(row=>row.type==='user'&&row.uuid===proof.sentUuid);assert.equal(rows.length,1);
  const text=typeof rows[0].message.content==='string'?rows[0].message.content:rows[0].message.content.filter(block=>block.type==='text').map(block=>block.text).join('\n');assert.equal(text,proof.submitted);
  evidence.nativePromptBoundaryVerification={nativeCaret:true,normalizedFencePaint:true,referenceHref:proof.referenceHref,nativeHumanUuid:proof.sentUuid,originalSubmit:true};
 }
 else if(uiCopy){assert.equal(evidence.nativeClipboard,true);assert.equal(evidence.nativeClipboardSameSessionRecovery,true);assert.equal(evidence.nativeStructuredPrompt,false);}
 else if(promptStructured){if(promptAllSelection)assert.equal(evidence.nativePromptAllSelection,true);if(uiSelection){assert.equal(evidence.nativeSelection,true);assert.equal(evidence.nativeUserBodyPointer,true);}if(uiCopy)assert.equal(evidence.nativeClipboard,true);if(promptSyntax)assert.equal(evidence.nativeSyntaxDecorations,true);assert.equal(evidence.nativeStructuredPrompt,true);if(promptMedia){assert.equal(evidence.nativeStructuredMedia,true);const images=agent.calls.flatMap(call=>call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).filter(block=>block.type==='image');assert.ok(images.some(block=>block.source?.data===createNativeTestImage().toString('base64')),'Native structured media did not preserve original image bytes');evidence.nativeModelImageIntact=true;}}
 else if(promptThemeSelection)assert.equal(evidence.nativePromptSelection,true);
 else if(textDirection){assert.equal(evidence.nativeTextDirection,true);const proof=JSON.parse(await readFile(join(workspace,'native-text-direction-app.json'),'utf8'));assert.equal(proof.samples.length,12);assert.ok(proof.samples.every(row=>row.draftRetained===true&&row.nestedDirections.every(dir=>dir===null)));const drawn=JSON.parse(await readFile(join(workspace,'native-text-direction-drawn.json'),'utf8'));assert.equal(drawn.surface,'desktop');assert.equal(drawn.samples.length,2);}
 else if(textMeasurement){assert.equal(evidence.nativeTextMeasurement,true);const proof=JSON.parse(await readFile(join(workspace,'native-text-measurement-app.json'),'utf8'));assert.equal(proof.samples.length,24);assert.ok(proof.samples.every(row=>row.actual===row.expected&&row.draftRetained===true));const drawn=JSON.parse(await readFile(join(workspace,'native-text-measurement-drawn.json'),'utf8'));assert.equal(drawn.surface,'desktop');assert.equal(drawn.samples.length,4);}
 else if(restingHover){assert.equal(evidence.nativeRestingHover,true);const proof=JSON.parse(await readFile(join(workspace,'native-resting-hover-app.json'),'utf8'));assert.equal(proof.samples.length,24);assert.ok(proof.samples.every(row=>row.pointerMoves===0&&row.active===(row.phase%2===0)));const applied=JSON.parse(await readFile(join(workspace,'native-resting-hover-applied.json'),'utf8'));assert.deepEqual(applied.slice(0,24).map(row=>row.phase),Array.from({length:24},(_,i)=>i+1));assert.ok(applied.every(row=>row.surface==='desktop'&&row.component==='AbovePrompt'));}
 else if(promptThemeText)assert.equal(evidence.nativeTextWrap,true);
 else if(lspReview){assert.equal(evidence.nativeLsp,true);const proof=await verifyNativeLspFixture(workspace,agent.calls,{lifecycle:lspLifecycle,lifetime:lspLifetime,unload:lspUnload});await writeFile(join(workspace,'native-lsp-delivery-verified.json'),JSON.stringify(proof));await writeFile(join(workspace,'native-lsp-model-results.json'),JSON.stringify(agent.calls));}
 else if(populatedResumeUpload){assert.equal(evidence.nativePopulatedResumeUpload,true);evidence.populatedResumeUpload=await verifyPopulatedResumeUpload(workspace,seed.calls);}
 else if(resumeUpload){assert.equal(evidence.nativeResumeUpload,true);evidence.resumeUpload=await verifyResumeUpload(workspace);}
 else if(resetUpload){
  assert.equal(evidence.nativeResetUpload,true);
  const proof=JSON.parse(await readFile(join(workspace,'native-reset-upload-proof.json'),'utf8'));
  for(const key of ['uploadHeld','uploadCompleted','resetFromOtherWindow','oldSendRetired','draftAndImageRetained','explicitImageRemoval'])assert.equal(proof[key],true);
  assert.notEqual(proof.sessionId,proof.finalSessionId);assert.equal(proof.replacementImageBlocks,0);
  const ownership=JSON.parse(await readFile(join(workspace,'native-reset-upload-ownership.json'),'utf8'));assert.equal(ownership.sameEditor,true);assert.equal(ownership.ownershipTransitions.length,1);assert.equal(ownership.ownershipTransitions[0].threadId,proof.threadId);assert.equal(ownership.ownershipTransitions[0].mode,'Claude Code');
  let humans;
  for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{humans=(await readFile(join(workspace,'.claude/projects',bucket,proof.finalSessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse).filter(row=>row.type==='user'&&row.isMeta!==true&&row.isVirtual!==true);break;}catch(error){if(error.code!=='ENOENT')throw error;}}
  assert.equal(humans?.length,1);assert.equal(humans[0].uuid,proof.newHumanUuid);assert.equal(typeof humans[0].message.content,'string');assert.ok(!humans[0].message.content.includes(proof.heldDraft));assert.ok(humans[0].message.content.endsWith('Latest user message:\n'+proof.freshText));
 }
 else if(resetTask){evidence.resetMedia=await verifyResetMedia(workspace);for(const key of ['nativeResetTask','nativeBusyResetRefused','nativeResetStateCleared','replacementSessionDistinct','nativeLateTaskResponseIsolated','nativeResetComposerContinued'])assert.equal(evidence[key],true);const proof=JSON.parse(await readFile(join(workspace,'native-reset-task-proof.json'),'utf8'));assert.notEqual(proof.sessionId,proof.finalSessionId);assert.equal(proof.lateResponseIsolated,true);assert.equal(proof.settledSendAtBothSizes,true);assert.ok(proof.followUpHumanUuid);assert.notEqual(proof.followUpHumanUuid,proof.newHumanUuid);const child=agent.calls.find(row=>row.child);assert.equal(child.heldReleased,true);assert.equal(child.disconnectedWhenReleased,true);assert.notEqual(child.delivered,true);}
 else if(systemPolicy){assert.equal(evidence.nativeSystemPolicy,true);const proof=JSON.parse(await readFile(join(workspace,'native-system-policy-app-proof.json'),'utf8'));if(systemPolicyUnreadable){assert.equal(proof.nativeManagedWarning,true);assert.equal(proof.successfulContinuation,true);}else{assert.equal(proof.userStatusOverridden,true);assert.equal(proof.privateControlsSuppressed,true);}assert.ok(proof.nativeHumanUuid);assert.equal(seed.calls.length,2);evidence.systemPolicyVerification=await verifyNativeSystemPolicyStartup(workspace,{unreadable:systemPolicyUnreadable,transitions:systemPolicyTransitions,darwin:darwinSystemPolicy,darwinLive:darwinPolicyLive});}
 else if(readMedia){assert.equal(evidence.nativeReadMedia,true);if(notebookImages)assert.equal(evidence.nativeNotebookImages,true);if(readMediaPageSuccess)assert.equal(evidence.nativePdfPageSuccess,true);}
 else if(agentMediaBoundary){assert.equal(evidence.nativeAgentMediaBoundary,true);}
 else if(everydayRich)assert.equal(evidence.nativeEverydayRich,true);
 else if(promptTheme){if(uiSelection&&promptThemeAgent){assert.equal(evidence.nativeAgentSelection,true);assert.equal(evidence.nativeAgentClipboard,true)}else{assert.equal(evidence.nativePromptTheme,true);if(promptThemeAgent)assert.equal(evidence.nativeAgentPromptTheme,true);}}
 if(capabilityProfile){assert.equal(evidence.nativeCapabilityOverrides,true);const launch=(await readFile(join(workspace,'native-capability-launch.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert.equal(launch.length,1);assert.deepEqual(launch[0],capabilityProfile==='disabled'?{FORCE_COLOR:'0',FORCE_HYPERLINK:'0',NO_COLOR:null}:capabilityProfile==='no-color'?{FORCE_COLOR:null,FORCE_HYPERLINK:'1',NO_COLOR:'1'}:{FORCE_COLOR:'3',FORCE_HYPERLINK:'1',NO_COLOR:null});}
 // The keyboard Client journey starts two print processes. Each can send an independent startup hello.
 if(planScenario){assert.equal(nativeMcpUrl?nativeMcpUrlPrintRequests(seed.calls).length:emptyKeyboardClient||pluginHint||updateDecisions||nativeCreditDesktop||settingsRoutes||agentSettingsRoutes||helpDesktop||settingsBrokerLoss||bashImage||terminalClients&&process.env.CLAUDE_RESEARCH_IMAGE_PIXELS==='1'?seed.calls.filter(call=>call.path==='/v1/messages?beta=true').length:seed.calls.length,populatedResumeUpload?4:externalConsent?3:lspRecommendation==='yes'?3+seed.calls.filter(call=>call.response?.name==='ToolSearch').length:resetTask&&!resetUpload?3:mcpElicitation&&!nativeMcpForm&&!nativeMcpUrl?mcpElicitationModelRequests:2);assert.equal(evidence.nativePlanScenario,planScenario);if(resetTask&&!resumeUpload||['parent-commands','reset','fork','revert','rewind'].includes(planScenario))assert.notEqual(evidence.finalSessionId,evidence.sessionId);else if(['clear','managed-clear','clear-accept-edits'].includes(planScenario)){assert.notEqual(evidence.finalSessionId,evidence.sessionId);assert.ok(agent.calls.some(call=>call.hasSyntheticPlan&&!call.hasTuiSeed),'Original native reset did not carry plan without seed');}else assert.equal(evidence.finalSessionId,evidence.sessionId);const prints=(await readFile(join(workspace,'native-print-results.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert.equal(prints.at(-1).sessionId,evidence.finalSessionId);}
 if(['task-steering','task-controls'].includes(planScenario)&&!pendingDuration){assert.equal(evidence.nativeAppAgentSelection,true);try{await access(join(workspace,'native-view-button.json'));throw Error('Native fixture hook selected the Agent instead of the app control')}catch(error){if(error.code!=='ENOENT')throw error}}
 if(planScenario==='task-steering'){
  const generic=JSON.parse(await readFile(join(workspace,'native-agent-generic-commands-app.json'),'utf8'));
  assert.deepEqual(generic.genericOutputs.map(value=>value.command),['context','agents']);assert.match(generic.genericOutputs[0].text,/context usage/i);assert.match(generic.genericOutputs[1].text,/agent/i);assert.match(generic.helpText,/General/);
  assert.equal(generic.originalStoreDismissal,true);assert.equal(generic.workerTranscriptUnchanged,true);assert.equal(generic.sameSelectedView,true);assert.equal(generic.sessionId,evidence.sessionId);assert.equal(evidence.nativeAgentGenericCommands,true);
  const panel=JSON.parse(await readFile(join(workspace,'native-agent-panel-app.json'),'utf8'));
  assert.equal(panel.alias,'/cost');assert.equal(panel.canonicalCommand,'usage');assert.match(panel.usageText,/Total cost:/);assert.match(panel.configText,/auto.?compact/i);
  for(const key of ['nativeKeyboardTab','nativeEscape','originalStoreDismissal','workerTranscriptUnchanged','sameNativePid','sameSelectedView'])assert.equal(panel[key],true);
  assert.equal(panel.sessionId,evidence.sessionId);assert.equal(evidence.nativeAgentSettingsPanel,true);
  const output=JSON.parse(await readFile(join(workspace,'native-agent-command-output-app.json'),'utf8'));
  assert.equal(output.originalCommandOutput.status,'command_output');assert.equal(output.originalCommandOutput.output.commandName,'reload-skills');assert.match(output.originalCommandOutput.output.messageId,/^[a-f0-9-]{36}$/);assert.match(output.originalCommandOutput.output.text,/Reloaded skills:/);assert.equal(output.originalCommandOutput.receipt,undefined);
  assert.equal(output.workerTranscriptUnchanged,true);assert.equal(output.taskId,evidence.taskId);assert.equal(output.sessionId,evidence.sessionId);
  const confirmed=JSON.parse(await readFile(join(workspace,'native-agent-command-confirmed.json'),'utf8'));
  assert.equal(confirmed.compactBoundary.type,'system');assert.equal(confirmed.compactBoundary.subtype,'compact_boundary');assert.equal(confirmed.compactBoundary.compactMetadata.trigger,'manual');
  assert.equal(confirmed.sessionId,evidence.sessionId);assert.equal(confirmed.boundNativePid,evidence.boundNativePid);assert.equal(confirmed.taskId,evidence.taskId);
 }
 if(planScenario==='task-steering'){
  assert.ok(agent.calls.some(call=>call.child&&call.steeringObserved&&call.delivered),'The selected native worker never received its message');
  assert.equal(evidence.nativeAgentHumanInput,true);assert.equal(evidence.nativeAgentResume,true);
  for(const key of ['nativeViewObserved','nativeViewParentHeld','nativeViewMainReturn','nativeFocusedAgent','nativeFocusedInputReview','nativeAgentCommandBlock','nativeAgentCommandConfirmation','nativeAgentCommandCancel','nativeAgentCommandConfirmedCompact','nativeFocusedReply','nativeFocusedEscape','nativeAgentDraftRestored','nativeAgentDraftRead','nativeAgentMessageHook'])assert.equal(evidence[key],true);
  assert.equal(evidence.selectedView.taskId,evidence.taskId);
  assert.equal(evidence.queuedReceipt.mode,'queued');assert.equal(evidence.resumeReceipt.mode,'resumed');
  const details=evidence.nativeAgentDetailsSnapshot;assert.equal(details.taskId,evidence.taskId);assert.equal(details.status,'completed');
  for(const text of ['NativeAgentSteerFixture: acknowledge this instruction in the same Agent.','NativeAgentSteerFixture: resume the same Agent for a second instruction.'])assert.equal(details.messages.filter(row=>row.role==='user'&&row.text.includes(text)).length,1,'Human input must appear exactly once');
  assert.equal(details.messages.filter(row=>row.role==='assistant'&&row.text==='ChildSteeringObserved').length,2);
  let nativeRows;
  for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{nativeRows=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId,'subagents','agent-'+evidence.taskId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}
  assert.ok(nativeRows,'Missing original native Agent journal');
  assert.equal(nativeRows.filter(row=>row.type==='user'&&row.origin?.kind==='human').length,3,'All Agent instructions must have native human origin');
  assert.ok(!nativeRows.some(row=>row.type==='user'&&JSON.stringify(row.message?.content).includes('\u200b')),'Unreviewed invisible input reached the worker');
  assert.ok(!nativeRows.some(row=>row.type==='user'&&['/model haiku','/compact','/reload-skills','/cost','/usage','/context','/agents','/help'].includes(row.message?.content)),'A gated local command reached the worker transcript');
  await writeFile(join(workspace,'native-human-agent-journal.json'),JSON.stringify(nativeRows,null,2));
 }
 if(pendingWorkflow&&!workflowDeny&&!workflowTaskControls){assert.equal(evidence.nativeWorkflowSummary,true);const proof=JSON.parse(await readFile(join(workspace,'native-workflow-summary-proof.json'),'utf8'));assert.ok(proof.summaryText.includes(workflowEditor?'Edited review':'Review')&&proof.summaryText.includes('Return the synthetic worker marker only.'));let journal;for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{journal=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}if(workflowStanding)assert.equal(await readFile(join(workspace,'.claude/workflows/release-review.js'),'utf8'),proof.scriptText);const originalScript=workflowEditor?JSON.parse(await readFile(join(workspace,'native-workflow-editor-receipt.json'),'utf8')).before:proof.scriptText;assert.ok(journal?.some(row=>row.type==='assistant'&&Array.isArray(row.message?.content)&&row.message.content.some(block=>block.type==='tool_use'&&block.name==='Workflow'&&(workflowStanding?block.input?.name==='release-review':block.input?.script===originalScript))),'Reviewed original Workflow script differs from the native request');}
 if(workflowEditor){assert.equal(evidence.nativeWorkflowEditor,true);if(workflowEditorWithheld)assert.equal(evidence.nativeWorkflowEditorWithheld,true);const receipt=JSON.parse(await readFile(join(workspace,'native-workflow-editor-receipt.json'),'utf8')),proof=JSON.parse(await readFile(join(workspace,'native-workflow-editor-proof.json'),'utf8'));await assert.rejects(access(receipt.tempPath),{code:'ENOENT'});assert.notEqual(receipt.before,receipt.after);if(workflowEditorWithheld){assert.ok(receipt.before.length>200000);assert.ok(receipt.after.length<200000);}assert.equal(proof.scriptText,receipt.after);assert.equal(await readFile(proof.persistedScriptPath,'utf8'),receipt.after);assert.notEqual(proof.beforeToken,proof.afterToken);assert.equal(proof.sameNativeOwner,true);let live=false;try{process.kill(receipt.pid,0);live=true}catch(error){if(error.code!=='ESRCH')throw error}assert.equal(live,false,'Original editor child survived');}
 if(planScenario==='task-controls'&&!pendingDuration){for(const key of ['nativeFocusedStop','nativeFocusedStopRetainedDraft','nativeFocusedStopParentContinued','nativeFocusedDetails'])assert.equal(evidence[key],true);assert.ok(agent.calls.some(call=>call.child));assert.ok(!agent.calls.some(call=>call.child&&call.delivered),'Stopped native worker returned a success result');}
 if(planScenario==='task-controls'&&!pendingDuration){
  let parentRows;
  for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{parentRows=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}
  assert.ok(parentRows,'Missing original parent journal');
  const input=parentRows.findIndex(row=>row.type==='user'&&row.message?.content==='Continue the same native parent after stopping its selected worker.');
  assert.ok(input>=0,'Parent continuation input was not saved in the original session');
  const reply=parentRows.slice(input+1).find(row=>row.type==='assistant'&&row.message?.content?.some?.(block=>block.type==='text'&&block.text==='ParentSubagentFixtureComplete'));
  assert.ok(reply,'The original parent did not reply after its worker was stopped');
  await writeFile(join(workspace,'native-focused-stop-parent-journal.json'),JSON.stringify({sessionId:evidence.sessionId,input:parentRows[input],reply},null,2));
 }
 if(agentBilling){if(process.env.CLAUDE_RESEARCH_WORKSPACE_LAYOUT_ACCEPT==='1')assert.equal(evidence.nativeWorkspaceLayout,true);if(process.env.CLAUDE_RESEARCH_SELECTION_LIMIT==='1')assert.equal(evidence.nativeSelectionLimit,true);if(process.env.CLAUDE_RESEARCH_TASK_MANAGER==='1'){assert.equal(evidence.nativeTaskManagerReturn,true);assert.equal(evidence.taskManagerReadings?.length,2);}if(process.env.CLAUDE_RESEARCH_CLIENT_THEME==='1')assert.equal(evidence.nativeClientTheme,true);if(process.env.CLAUDE_RESEARCH_AGENT_PANEL_OWNERSHIP==='1')assert.equal(evidence.nativeAgentPanelOwnership,true);assert.equal(evidence.nativeAgentBilling,true);assert.equal(evidence.resumedPrintSameSession,true);assert.ok(agent.calls.some(call=>call.child&&call.delivered));}
 if(planScenario==='agent-layout'&&!handbackOwner&&!agentBilling){assert.ok(agent.calls.some(call=>call.child&&call.delivered));for(const row of evidence.geometry){assert.ok(row.scrollWidth<=row.width+1);assert.ok(row.height<=112);assert.ok(row.scrollHeight>row.height);} }
 if(planScenario==='composer-layout'&&!terminalClients&&!printClients){
  assert.deepEqual(evidence.geometry.map(row=>row.viewportHeight),[600,900]);
  for(const row of evidence.geometry){assert.ok(row.status.width>0&&row.status.height>0);assert.ok(row.status.scrollWidth<=row.status.width+1);assert.ok(row.status.height<=96);assert.ok(row.status.scrollHeight>row.status.height);assert.ok(row.card.scrollHeight<=row.card.height+1);}
 }
 if(planScenario==='rename'){
  assert.equal(evidence.nativeLongJournalTitleDiscovery,true);assert.equal(evidence.nativeTitleOutsideEdgeChunks,true);
  const snapshot=await readFile(join(workspace,'native-title-discovery-journal.jsonl'));
  assert.equal(snapshot.length,evidence.titleJournalBytes);assert.ok(snapshot.length>8192);
  for(const chunk of [snapshot.subarray(0,4096),snapshot.subarray(-4096)])assert.equal(chunk.toString('utf8').includes('"customTitle"'),false);
  const metadata=snapshot.toString('utf8').trim().split('\n').map(JSON.parse).filter(row=>row.type==='custom-title'&&row.sessionId===evidence.sessionId).at(-1);
  assert.equal(metadata?.customTitle,evidence.title);
  evidence.titleDiscoverySnapshotSha256=hash(snapshot);
 }
 if(questionForms){
  for(const key of ['nativeQuestionExtended','nativeQuestionFollowUp','nativeQuestionRefusalRetry','nativeQuestionCancellation','nativeRetainedDraft'])assert.equal(evidence[key],true);
  const inspection=JSON.parse(await readFile(join(workspace,'native-dialog-shapes-before-reopen.json'),'utf8'));
  const reopenedInspection=JSON.parse(await readFile(join(workspace,'native-dialog-shapes.json'),'utf8'));
  assert.equal(reopenedInspection.questionPresentation.extendedQuestions,true);assert.equal(reopenedInspection.questionPresentation.optionalDescriptions,true);
  const replay=JSON.parse(await readFile(join(workspace,'native-question-replay-proof.json'),'utf8'));assert.equal(evidence.nativeQuestionReplacementReplay,true);assert.deepEqual(replay.replayProof.map(row=>row.stage),['follow-up','cancel-recovery']);for(const row of replay.replayProof){assert.notEqual(row.retired.approvalMessageId,row.fresh.approvalMessageId);assert.deepEqual(row.before,row.after);}assert.equal(replay.replayProof[0].retired.nativeTerminal.ownerId,replay.replayProof[0].fresh.nativeTerminal.ownerId);assert.notEqual(replay.replayProof[1].retired.nativeTerminal.ownerId,replay.replayProof[1].fresh.nativeTerminal.ownerId);assert.equal(replay.replayProof[0].before.nativeQuestionAnswer.followUp,true);assert.equal(replay.replayProof[1].before.cancelled,true);assert.equal(JSON.stringify(agent.calls).includes('Stale replay must not win'),false,'Stale native question answer reached original model request');assert.ok(agent.calls.flatMap(call=>call.questionResults??[]).some(row=>row.tool_use_id==='toolu_extended_question_3'&&JSON.stringify(row).includes('Recovered project')),'Fresh question answer did not reach original model request');
  assert.equal(inspection.questionPresentation.extendedQuestions,true);assert.equal(inspection.questionPresentation.optionalDescriptions,true);
  const first=inspection.questionContracts.find(row=>row.admitted?.input?.followUp===true);
  assert.ok(first,'Original native follow-up admission receipt missing');assert.equal(first.admitted.input.answers['What should this project be called?'],'Notebook');assert.equal(first.admitted.input.answers['How many examples should be included?'],'6');
  const nativeResults=agent.calls.flatMap(call=>call.questionResults??[]);
  assert.ok(nativeResults.some(row=>row.tool_use_id==='toolu_extended_question_1_follow'&&JSON.stringify(row).includes('typed greeting')),'Native follow-up answer did not reach model');
  assert.ok(inspection.events.some(event=>event.type==='closed'&&event.value?.type==='dismissed'),'Original cancellation dismissal receipt missing');
  assert.equal(JSON.stringify(nativeResults).includes('Unsubmitted project'),false,'Cancelled partial answer reached model');
 }
 if(planScenario==='rename'){assert.equal(evidence.nativeRenameReminder,true);for(const call of [agent.calls.at(-1),seed.calls.at(-1)])assert.ok(JSON.stringify(call.messages).includes('The user named this session')&&JSON.stringify(call.messages).includes(evidence.title),'Original rename reminder did not reach a subsequent native model request');}
 const children=(await readFile(join(workspace,'native-children.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 if(savedPlan){const proof=JSON.parse(await readFile(join(workspace,'native-composer-phase-proof.json'),'utf8')),last=children.at(-1);assert.equal(last.args[last.args.indexOf('--permission-mode')+1],proof.originalMode);assert.equal(children[3].args[children[3].args.indexOf('--permission-mode')+1],'plan');}
 if(coldReopen){
  const saved=JSON.parse(await readFile(join(workspace,'native-cold-state.json'),'utf8'));
  const selected=(args,name)=>args[args.indexOf(name)+1];
  for(const child of [children[2+reopenOffset],children[3+reopenOffset]]){if(saved.stagedModel)assert.equal(selected(child.args,'--model'),saved.stagedModel);assert.equal(selected(child.args,'--permission-mode'),saved.stagedPermissionMode);}
  evidence.nativeStagedChoicesRestored=!importReopen;
  if(importReopen){
   assert.equal(evidence.nativeImportedHistoryReopened,true);
   const imported=JSON.parse(await readFile(join(workspace,'native-import-history-before-reopen.json'),'utf8'));
   const proof=JSON.parse(await readFile(join(workspace,'native-history-reopen-proof.json'),'utf8'));
   for(const source of imported.sourceHistory){const rows=proof.history.filter(row=>row.uuid===source.uuid);assert.equal(rows.length,1);for(const key of ['text','sender'])assert.equal(rows[0][key],source[key]);assert.notEqual(rows[0].id,source.id);}
   const tool=imported.imported.messages.flatMap(row=>row.blocks??[]).filter(row=>row.type==='tool-activity').flatMap(row=>row.props.entries).find(row=>row.id==='native_reference_read');
   assert.equal(tool.status,'ok');assert.ok(tool.nativeResult?.uuid);assert.equal(tool.nativeResult.sessionId,evidence.sessionId);
   assert.equal(proof.toolCallCount,saved.toolCallCount);
   for(const child of [children[2+reopenOffset],children[3+reopenOffset]]){assert.equal(child.args.includes('--allowedTools'),false);assert.equal(child.args.includes('--append-system-prompt'),false);}
   evidence.importReceiptVerification={sourceThreadId:imported.sourceThreadId,importedThreadId:saved.threadId,canonicalRows:imported.sourceHistory.length,toolResultUuid:tool.nativeResult.uuid,toolCallCount:proof.toolCallCount};
  }
 }

 if(process.env.CLAUDE_RESEARCH_IMPORT_IMAGE==='1')assert.equal(evidence.nativeImportedImage,true,'Image profile must execute actual image assertions');
 assert.equal(children.length,populatedResumeUpload?4:externalConsent?5:settingsBrokerLoss?5:managedModelRestart?5:promptBrokerFailure?5:questionOwnerFailure?5:mcpElicitation&&!nativeMcpForm&&!nativeMcpUrl?4:historyReopen||pendingApprovalFailure||questionForms||stagedDirectories||permissionAdmission?5+reopenOffset:['onboarding-import','direct-resume'].includes(planScenario)?5:rewindScenario?8:planScenario==='revert'?5:planScenario==='fork'?4:3,'Expected seed print, resumed terminal, optional fork preflight and returned print');
 if(planScenario==='fork'){assert.ok(children[2].args.includes('--no-session-persistence'));assert.ok(children[2].args.includes('--resume-session-at'));assert.equal(children[2].args[children[2].args.indexOf('--resume-session-at')+1],evidence.selectedNativeCheckpoint);assert.ok(children[3].args.includes('--fork-session'));assert.equal(children[3].args[children[3].args.indexOf('--resume-session-at')+1],evidence.selectedNativeCheckpoint);}
 if(stagedDirectories){const proof=JSON.parse(await readFile(join(workspace,'native-staged-directory-proof.json'),'utf8'));assert.ok(children[1].args.includes(proof.firstDirectory));for(const child of [children[2],children[3]])for(const directory of [proof.firstDirectory,proof.secondDirectory])assert.ok(child.args.includes(directory),'Original fresh native argv missed staged folder');}
 if(permissionAdmission){assert.equal(children[3].args[children[3].args.indexOf('--permission-mode')+1],'bypassPermissions');assert.equal(children[3].args.includes('--allow-dangerously-skip-permissions'),false);assert.equal(children[3].args.includes('--dangerously-skip-permissions'),false);}
 assert.equal(evidence.boundNativePid,children[1].pid,'Observed native owner must be the real native child behind the launcher');
 if(resetTask&&!resumeUpload)assert.equal(children[2].args.includes('--resume'),false,'Reset replacement must start a fresh CLI session');
 if(resumeUpload&&!populatedResumeUpload)assert.equal(children[2].args[children[2].args.indexOf('--resume')+1],evidence.sessionId,'Upload resume must continue the imported native session');
 if(populatedResumeUpload){const proof=JSON.parse(await readFile(join(workspace,'native-populated-resume-upload-proof.json'),'utf8'));assert.equal(children[2].args.includes('--resume'),false);assert.equal(children[3].args[children[3].args.indexOf('--resume')+1],proof.finalSessionId);const prints=(await readFile(join(workspace,'native-print-results.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert.deepEqual(prints.map(row=>row.sessionId),[proof.sourceSessionId,proof.priorSessionId,proof.priorSessionId,proof.finalSessionId]);assert.deepEqual(prints.map(row=>row.pid),[children[0].pid,children[2].pid,children[2].pid,children[3].pid]);}
 const preloadCalls=(await readFile(userPreloadCalls,'utf8')).trim().split('\n').map(JSON.parse);
 for(const native of children)assert.ok(preloadCalls.some(value=>value.pid===native.pid),'The user preload must run in each native process');

 const exits=(await readFile(join(workspace,'native-exits.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 if(startupCancel){const proof=JSON.parse(await readFile(join(workspace,'native-startup-cancel-proof.json'),'utf8'));assert.equal(evidence.nativeStartupCancelled,true);assert.equal(proof.heldPid,children[2].pid);assert.ok(children[2].args.includes('--no-session-persistence'));assert.ok(exits.find(row=>row.pid===children[2].pid)?.at<=children[3].at,'Cancelled original preflight must exit before retry starts');evidence.startupCancellation=proof;}
 assert.ok(children[0].args.includes('--print'));assert.ok(children[1].args.includes('--resume'));
 assert.ok(exits.find(row=>row.pid===children[0].pid)?.at<=children[1].at,'Print native child must exit before terminal native child starts');
 if(managedModelRestart||settingsBrokerLoss||promptBrokerFailure||historyReopen||pendingApprovalFailure||questionForms||stagedDirectories||permissionAdmission||planScenario==='direct-resume'){assert.ok(children[2+reopenOffset].args.includes('--print')&&children[2+reopenOffset].args.includes('--no-session-persistence'),'Original read-only settings preflight required');assert.ok(children[3+reopenOffset].args.includes('--resume'));assert.equal(children[3+reopenOffset].pid,evidence.reopenedNativePid);assert.ok(exits.find(row=>row.pid===children[2+reopenOffset].pid)?.at<=children[3+reopenOffset].at,'Settings preflight must exit before reopened writer starts');assert.ok(exits.find(row=>row.pid===children[3+reopenOffset].pid)?.at<=children[4+reopenOffset].at,'Reopened owner must exit before print continuation');assert.ok(children[4+reopenOffset].args.includes('--print'));}else if(planScenario==='onboarding-import'){assert.ok(children.at(-1).args.includes('--print'));}else assert.ok(children[2].args.includes('--print'));
 if(rewindScenario){assert.equal(await readFile(join(workspace,'file-fixture.txt'),'utf8'),'created\n');assert.ok(exits.find(row=>row.pid===children[1].pid)?.at<=children.at(-1).at,'Native owner must exit before rewind continuation');assert.ok(children.at(-1).args.includes('--fork-session'));assert.equal(children.at(-1).args[children.at(-1).args.indexOf('--resume-session-at')+1],evidence.priorNativeCheckpoint);}
 else if(planScenario==='revert'){for(const index of [2,3]){assert.ok(children[index].args.includes('--no-session-persistence'));assert.equal(children[index].args[children[index].args.indexOf('--resume-session-at')+1],evidence.priorNativeCheckpoint);}assert.ok(exits.find(row=>row.pid===children[1].pid)?.at<=children[3].at,'Native owner must drain before post-commit validation');assert.ok(exits.find(row=>row.pid===children[3].pid)?.at<=children[4].at,'Post-commit validation must finish before continuation');assert.ok(children[4].args.includes('--fork-session'));assert.equal(children[4].args[children[4].args.indexOf('--resume-session-at')+1],evidence.priorNativeCheckpoint);}
 else if(settingsBrokerLoss||promptBrokerFailure||ownerFailure==='broker'||pendingApprovalFailure==='broker'){
  const proof=JSON.parse(await readFile(join(workspace,settingsBrokerLoss?'native-settings-broker-proof.json':promptBrokerFailure?'native-prompt-broker-failure-proof.json':pendingApprovalFailure?'native-pending-approval-failure-proof.json':'native-history-reopen-proof.json'),'utf8'));
  assert.equal(proof.failure.kind,'broker');assert.equal(proof.failure.nativePid,children[1].pid);
  assert.ok(Number.isFinite(proof.failure.retiredAt)&&proof.failure.retiredAt>=proof.failure.at&&proof.failure.retiredAt<=children[2].at,'Observed original native death must precede the replacement preflight');
  evidence.failedOwnerRetirement={kind:'broker',brokerPid:proof.failure.brokerPid,nativePid:proof.failure.nativePid,observedNativeExitAt:proof.failure.retiredAt,method:'kill(pid,0) returned ESRCH before replacement; final native PID audit also required'};
 }
 else assert.ok(exits.find(row=>row.pid===children[1].pid)?.at<=children[2].at,'Terminal native child must exit before returned print starts');
 if(planScenario==='fork')assert.ok(exits.find(row=>row.pid===children[2].pid)?.at<=children[3].at,'Native history preflight must exit before fork continuation');
 if(mcpScenario&&!mcpOAuth){
  const servers=(await readFile(join(workspace,'mcp-children.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
  const receipts=(await readFile(join(workspace,'mcp-receipts.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
  if(mcpDirectory){assert.equal(evidence.nativeMcpDirectoryGate,true);assert.equal(receipts.some(row=>row.method==='resources/directory/read'),false);assert.ok(agent.calls.flatMap(call=>call.resourceResults??[]).some(row=>row.tool_use_id==='resource-directory'&&JSON.stringify(row.content).includes('Directory listing is not enabled in this build.')));}else if(process.env.CLAUDE_RESEARCH_MCP_PANEL==='1')assert.ok(receipts.some(row=>row.method==='tools/list'),'Original MCP tool inventory never loaded');else if(!mcpResources)assert.ok(receipts.some(row=>row.method==='tools/call'&&row.tool==='echo'),'Original native MCP tool never executed');else{assert.equal(evidence.nativeMcpResources,true);evidence.resourceReceiptVerification=await verifyMcpResourceProof(workspace,JSON.parse(await readFile(join(workspace,'native-mcp-resource-proof.json'),'utf8')),agent.calls);assert.ok(receipts.filter(row=>row.method==='resources/list').length>=2);for(const uri of Object.values(resourceUris))assert.ok(receipts.some(row=>row.method==='resources/read'&&row.uri===uri));}
  assert.ok(servers.some(row=>row.ancestors.includes(children[1].pid)));assert.ok(servers.some(row=>row.ancestors.includes(children.at(-1).pid)));
  if(mcpResources&&!mcpDirectory){const owned=servers.filter(row=>row.ancestors.includes(children[1].pid));assert.equal(owned.length,1);const rpc=receipts.filter(row=>row.pid===owned[0].pid);assert.ok(rpc.filter(row=>row.method==='resources/list').length>=2);assert.deepEqual(rpc.filter(row=>row.method==='resources/read').map(row=>row.uri),Object.values(resourceUris));evidence.resourceReceiptVerification.serverPid=owned[0].pid;}
  for(const server of servers){assert.ok(children.some(row=>server.ancestors.includes(row.pid)));let live=false;try{execFileSync('/bin/ps',['-p',String(server.pid),'-o','pid='],{stdio:'pipe'});live=true}catch(error){if(error.status!==1)throw error}assert.equal(live,false,'Owned MCP server survived app shutdown');}
  if(planScenario==='mcp-controls'){
   const nativeStarts=servers.filter(row=>row.ancestors.includes(children[1].pid)).length,printStarts=servers.filter(row=>row.ancestors.includes(children.at(-1).pid)).length;
   assert.equal(nativeStarts,3,'Native idempotent enable/disable must not start extra transports');assert.equal(printStarts,3,'Print idempotent enable/disable must not start extra transports');assert.equal(servers.length,7);
   evidence.nativeMcpServerStarts=nativeStarts;evidence.printMcpServerStarts=printStarts;
  }
  evidence.ownedMcpShutdown=true;evidence.mcpServerProcesses=servers.length;
 }
 for(const row of children){let present=false;try{execFileSync('/bin/ps',['-p',String(row.pid),'-o','pid='],{stdio:'pipe'});present=true}catch(error){if(error.status!==1)throw error}assert.equal(present,false,'Owned native child survived app shutdown')}
 if(promptThemeEveryday){
  let closedCost;
  for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{const rows=(await readFile(join(workspace,'.claude/projects',bucket,evidence.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);closedCost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;break}catch(error){if(error.code!=='ENOENT')throw error}}
  assert.ok(Number.isFinite(evidence.resumedCost)&&evidence.resumedCost>evidence.nativeCost,'Original resumed print cost required');
  assert.equal(closedCost,evidence.resumedCost,'Closed native cost ledger must match original print result and app');
  evidence.nativeClosedLedgerSynchronized=true;
 }
 console.log(JSON.stringify({evidence:'apack-native-terminal-owner-app',...evidence,configuredPrefixPreserved:true,compiledPackHashes:before,compiledRendererManifest:{sha256:hash(JSON.stringify(rendererBefore)),files:Object.keys(rendererBefore).length},targetSha256:hash(await readFile(executable)),nativeProcesses:children.length,ownedShutdown:true,promptFixtureSha256:hash(await readFile(join(plugin,'hooks/register.ts'))),syntheticApiRequests:seed.calls.length+agent.calls.length,realModelRequests:0}));
 }
} finally {
 clearInterval(pendingDurationTimer);clearInterval(parentDelayTimer);clearTimeout(timeout);if(child&&!exited)child.kill('SIGTERM');
 await writeFile(join(workspace,'model-calls.json'),JSON.stringify({seed:seed.calls,agent:agent.calls},null,2));
 if(agentBilling)await cp(nativeProject,join(workspace,'project-evidence'),{recursive:true,dereference:false});
 if(externalConsentDirectory)await rm(externalConsentDirectory,{recursive:true,force:true});
 if(creditBilling){await writeFile(join(workspace,'native-credit-billing-requests.json'),JSON.stringify(creditBilling.state,null,2)+'\n');await creditBilling.close();}
 await seed.close();releaseLargeRead();clearInterval(largeReadTimer);await oauthServer?.close();await mcpBrowser?.close();await agent.close();
}
