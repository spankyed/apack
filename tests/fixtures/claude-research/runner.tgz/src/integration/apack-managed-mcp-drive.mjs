import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {lstat,mkdir,readFile,readdir,writeFile} from 'node:fs/promises';
import {basename,join} from 'node:path';
import {mcpTaskPrompt} from './native-mcp-task-journey.mjs';
import {holdManagedMcpBackgroundPoll,observeManagedMcpBackgroundPolicy,observeManagedMcpReconnectExhaustion,observeManagedMcpParkedRecovery} from './managed-mcp-background-policy.mjs';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {liveOriginals,processStart} from './native-process-state.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {ownedClaudeAiMcpConnector,OWNED_CLAUDEAI_CONNECTOR_NAME,OWNED_CLAUDEAI_CONNECTOR_URL,OWNED_CLAUDEAI_TASK_TOOL,OWNED_CLAUDEAI_ECHO_TOOL} from '../protocol/owned-claudeai-mcp-connector.mjs';
import {startManagedMcpTaskHttpServer} from '../protocol/owned-managed-mcp-task-http-server.mjs';
import {startManagedMcpHttpServer} from '../protocol/owned-managed-mcp-http-server.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
import {MANAGED_MCP_HOLD_PROMPT,MANAGED_MCP_HOLD_TOOL_ID,startSyntheticModel} from '../protocol/synthetic-model.mjs';

const NAMES=['managed-review','local-review','user-denied-review'];
const POLICY='/etc/claude-code/managed-settings.json';
const sha=value=>createHash('sha256').update(value).digest('hex');
const textReply='The integration review is complete.';

export async function driveManagedMcpApp({checkout,workspace,env}) {
  assert.equal(process.platform,'linux');
  assert.equal(process.getuid(),1000);
  assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday\d+$/);
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(boundary.networkDisabled&&boundary.pinnedExecutableReadOnly&&boundary.requireManagedMcpAdmission);
  const inOwner=boundary.requireManagedMcpLive===true;
  const requireLiveRetirement=boundary.requireManagedMcpLiveRetirement===true;
  const heldCall=boundary.requireManagedMcpHeldCall===true;
  const remoteCall=boundary.requireManagedMcpRemoteCall===true;
  const remoteRecovery=boundary.requireManagedMcpRemoteRecovery===true;
  assert.ok(!remoteCall||heldCall);
  assert.ok(!remoteRecovery||remoteCall);
  const backgroundTask=boundary.requireManagedMcpBackgroundTask===true;
  assert.ok(!backgroundTask||requireLiveRetirement&&!heldCall);
  const backgroundHttp=boundary.requireManagedMcpBackgroundHttp===true;
  assert.ok(!backgroundHttp||backgroundTask);
  const managedProxy=boundary.requireManagedMcpClaudeAiProxy===true;
  assert.ok(!managedProxy||backgroundHttp||remoteCall&&!remoteRecovery);
  const taskServer=managedProxy?OWNED_CLAUDEAI_CONNECTOR_NAME:'local-review';
  const taskTool=managedProxy?OWNED_CLAUDEAI_TASK_TOOL:'mcp__local-review__review';
  const heldTool=managedProxy&&heldCall?OWNED_CLAUDEAI_ECHO_TOOL:'mcp__local-review__echo';
  const heldTransport=managedProxy?'claudeai-proxy':'http';
  const localPanelName=managedProxy?'Managed policy review':'local-review';
  const reconnectExhaustion=boundary.requireManagedMcpReconnectExhaustion===true;
  assert.ok(!reconnectExhaustion||backgroundTask);
  const parkedPresentation=boundary.requireManagedMcpParkedPresentation===true;
  assert.ok(!parkedPresentation||reconnectExhaustion);
  const parkedRecovery=boundary.requireManagedMcpParkedRecovery===true;
  assert.ok(!parkedRecovery||parkedPresentation&&backgroundHttp&&!managedProxy);
  const panelResize=boundary.requireNativeCommandPanelResize===true;
  assert.ok(!requireLiveRetirement||inOwner);
  assert.ok(!heldCall||requireLiveRetirement);
  assert.ok(!panelResize||!inOwner);
  const control=env.CLAUDE_RESEARCH_POLICY_CONTROL;
  assert.match(control,/^\/work\/\.claude-research\/policy-transition-mcp-admission\d+$/);
  const ready=JSON.parse(await readFile(join(control,'ready.json'),'utf8'));
  assert.equal(ready.profile,'mcp-allowlist');
  assert.equal(ready.path,POLICY);
  const project=join(workspace,'project');
  const starts=join(workspace,'mcp-startups');
  await mkdir(project);await mkdir(starts);
  execFileSync('/usr/bin/git',['init','--quiet',project],{env:{HOME:workspace,PATH:'/usr/bin:/bin',GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
  const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'});
  const configPath=join(workspace,'.claude/.claude.json'),settingsPath=join(workspace,'.claude/settings.json');
  const configBefore=await readFile(configPath);
  const initialSettings={theme:'dark',model:'opus'};
  const source=new URL('../protocol/synthetic-mcp-health-server.mjs',import.meta.url).pathname;
  const mcpServers=Object.fromEntries(NAMES.map(name=>[name,{type:'stdio',command:process.execPath,
    args:[source,join(starts,name)],env:{APACK_MCP_RECEIPT:join(workspace,`mcp-${name}.jsonl`),
      ...(heldCall&&name==='local-review'?{APACK_MCP_HOLD_ECHO:'1'}:{})}}]));
  const taskHoldPath=join(workspace,'managed-mcp-background-hold');
  const taskFinishPath=parkedRecovery?join(workspace,'managed-mcp-background-finish'):undefined;
  if(backgroundTask&&!backgroundHttp){
    const taskStartup=join(starts,'local-review');
    mcpServers['local-review']={type:'stdio',command:process.execPath,args:[
      new URL('../protocol/owned-mcp-task-server.mjs',import.meta.url).pathname,taskStartup],env:{
      APACK_MCP_ADVERTISE_TASKS:'1',APACK_MCP_TASK_RECEIPT:join(workspace,'mcp-local-review.jsonl'),
      APACK_MCP_TASK_POLICY_STARTUP:taskStartup,APACK_MCP_TASK_POLICY_HOLD:taskHoldPath,
    }};
  }
  const settings={...initialSettings,allowedMcpServers:NAMES.map(name=>managedProxy&&name==='local-review'?{serverUrl:OWNED_CLAUDEAI_CONNECTOR_URL}:{serverName:name}),
    deniedMcpServers:[{serverName:'user-denied-review'}]};
  if(heldCall)settings.permissions={allow:[heldTool]};
  const config=JSON.parse(configBefore);
  assert.ok(!config.mcpServers&&!config.cachedGrowthBookFeatures&&!config.growthBookOverrides);
  const output=join(workspace,'electron-results');
  let model,billing,remote,managedConnector;
  try {
    if(backgroundHttp){
      remote=await startManagedMcpTaskHttpServer({receipts:join(workspace,'mcp-local-review.jsonl'),holdPath:taskHoldPath,finishPath:taskFinishPath});
    }else if(remoteCall){
      remote=await startManagedMcpHttpServer(join(workspace,'mcp-local-review.jsonl'),{expireFirstCall:remoteRecovery});
    }
    if(managedProxy){
      delete mcpServers['local-review'];
      managedConnector=ownedClaudeAiMcpConnector({peerUrl:remote.url,receipts:join(workspace,'managed-connector-routes.jsonl')});
      account.CLAUDE_CODE_OAUTH_SCOPES+=' user:mcp_servers';
    }else if(remote)mcpServers['local-review']={type:'http',url:remote.url};
    await writeFile(configPath,JSON.stringify({...config,hasCompletedOnboarding:true,mcpServers}));
    await writeFile(settingsPath,JSON.stringify(settings));
    await writeFile(join(workspace,'managed-mcp-inputs.json'),JSON.stringify({settings,mcpServers,originalConfigSha256:sha(configBefore),initialSettings}));
    model=await startSyntheticModel(workspace,backgroundTask?taskTool:'TextOnly',{textReply,captureMessages:true,
      ...(backgroundTask&&{mcpTaskScenario:'held',mcpTaskPrompt}),
      managedMcpHeldCall:heldCall,managedMcpHeldTool:heldTool,maxRequests:inOwner?20:12});
    const tls=await prepareNativeCreditTls(join(workspace,'account-tls'),{includeMcpProxy:managedProxy});
    billing=await startNativeCreditBilling(tls,{allowMutations:false,mcpTaskRollout:backgroundTask,managedConnector,evidencePath:join(workspace,'account-live.json')});
    const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,
      DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};
    if(inOwner){
      launchEnv.DEBUG='1';
      launchEnv.CLAUDE_CODE_DEBUG_LOGS_DIR=join(workspace,'native-debug');
    }
    delete launchEnv.ANTHROPIC_API_KEY;
    await driveFreshNativeApp({checkout,workspace,env:launchEnv,
      route:parkedRecovery?'real-Electron-managed-mcp-parked-recovery':reconnectExhaustion?'real-Electron-managed-mcp-reconnect-exhaustion':'real-Electron-managed-mcp-admission',
      journeyBudgetMs:parkedRecovery?480000:reconnectExhaustion?420000:160000,
      journey:args=>managedMcpJourney({...args,starts,control,ready,inOwner,requireLiveRetirement,heldCall,remoteCall,remoteRecovery,backgroundTask,backgroundHttp,reconnectExhaustion,parkedPresentation,parkedRecovery,taskHoldPath,taskFinishPath,taskServer,taskTool,heldTool,heldTransport,localPanelName,panelResize,workspace,model})});
  } finally {
    await model?.close();await billing?.close();await remote?.close();await mkdir(output,{recursive:true});
    await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model?.calls??[]));
    let active;
    for(let attempt=0;attempt<100;attempt++){
      active=await liveOriginals();
      if(!active.length)break;
      await new Promise(resolve=>setTimeout(resolve,50));
    }
    await writeFile(join(output,'writer-retirement.json'),JSON.stringify({remaining:active}));
    assert.deepEqual(active,[]);
    await writeFile(configPath,configBefore);
    await writeFile(settingsPath,JSON.stringify(initialSettings));
    const proof=await readFile(join(output,'managed-mcp-admission.json'),'utf8').catch(error=>{
      if(error.code==='ENOENT')return null;
      throw error;
    });
    const sessionId=proof&&JSON.parse(proof).sessionId;
    if(sessionId){
      const root=join(workspace,'.claude/projects');
      const matches=(await readdir(root,{recursive:true})).filter(file=>basename(file)===`${sessionId}.jsonl`);
      assert.equal(matches.length,1);
      await writeFile(join(output,'native-parent-transcript.jsonl'),await readFile(join(root,matches[0])));
    }
  }
}

async function managedMcpJourney({app,page,expect,phase,output,project,userDataDir,starts,control,ready,inOwner,requireLiveRetirement,heldCall,remoteCall,remoteRecovery,backgroundTask,backgroundHttp,reconnectExhaustion,parkedPresentation,parkedRecovery,taskHoldPath,taskFinishPath,taskServer,taskTool,heldTool,heldTransport,localPanelName,panelResize,workspace,model}) {
  const usesHttp=remoteCall||backgroundHttp;
  page.setDefaultTimeout(12000);
  const proof={status:'running',inOwner,cases:[],captures:[],draft:'Keep this draft while checking which integrations are available.'};
  const save=()=>writeFile(join(output,'managed-mcp-admission.json'),JSON.stringify(proof,null,2));
  const context=()=>page.evaluate(()=>{
    const state=window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    const thread=state.currentThread;
    return {threadId:thread?.id,claude:thread?.context?.claudeCode,messages:thread?.messages,
      native:Object.values(state.nativeTerminalViews).find(view=>view.threadId===thread?.id)};
  });
  const counts=async()=>Object.fromEntries(await Promise.all(NAMES.map(async name=>{
    if(backgroundHttp&&name==='local-review')return [name,(await serverReceipt(name)).filter(row=>row.value.event==='policy-peer-started').length];
    if(remoteCall&&name==='local-review')return [name,(await serverReceipt(name)).filter(row=>row.method==='initialize').length];
    const text=await readFile(join(starts,name),'utf8').catch(error=>{if(error.code==='ENOENT')return '';throw error;});
    const lines=text.trim().split('\n').filter(Boolean);assert.ok(lines.every(line=>line==='started'));
    return [name,lines.length];
  })));
  const card=page.locator('[data-onboarding-id="agent-chat-input"]');
  const composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true});
  const section=page.getByRole('region',{name:'Claude native interface',exact:true});
  const show=section.getByRole('button',{name:'Use native interface',exact:true});
  const stop=section.getByRole('button',{name:'Stop session',exact:true});
  const back=section.getByRole('button',{name:'Back to conversation',exact:true});
  const panel=page.getByRole('dialog',{name:'Native /mcp panel',exact:true});
  const terminal=panel.locator('[data-terminal-text]');
  const openPanel=async()=>{
    const button=card.getByRole('button',{name:'Claude MCP servers',exact:true});
    if(await button.isVisible())await button.click();
    else{
      await card.getByRole('button',{name:'More actions',exact:true}).click();
      await page.getByRole('menuitem',{name:'Claude MCP servers',exact:true}).click();
    }
  };
  const serverReceipt=async name=>{
    const receipt=await readFile(join(workspace,`mcp-${name}.jsonl`),'utf8').catch(error=>{
      if(error.code==='ENOENT')return '';
      throw error;
    });
    return receipt.trim().split('\n').filter(Boolean).map(line=>JSON.parse(line));
  };
  const serverProcesses=async name=>{
    if(usesHttp&&name==='local-review')return [];
    const ids=new Set((await serverReceipt(name)).map(row=>row.pid??row.value?.pid).filter(Number.isSafeInteger));
    const active=[];
    for(const pid of ids){
      const args=await readFile(`/proc/${pid}/cmdline`,'utf8').catch(error=>{
        if(error.code==='ENOENT')return '';
        throw error;
      });
      if(args.split('\0').includes(join(starts,name))){
        const start=await processStart(pid);
        if(start)active.push({pid,start});
      }
    }
    return active;
  };
  const replace=async text=>{
    await composer.focus();await composer.press('ControlOrMeta+a');await composer.press('Backspace');
    await expect(composer).toHaveText('');await composer.pressSequentially(text);
  };
  await save();
  try {
    const producer=JSON.parse(await readFile('/control/producer-pack-inputs.json','utf8'));
    for(const file of ['runtime/fe.js','runtime/index.cjs'])assert.equal(sha(await readFile(join(userDataDir,'apack/packs/default-setup',file))),producer[file]);
    await app.waitForSurface('default-setup/threads');await app.navigate('host/settings');
    await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'});});
    const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');
    await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');
    await page.waitForTimeout(700);
    await app.navigate('default-setup/threads');
    await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return Boolean(c.currentThread?.id&&c.tabs.every(t=>c.tabsRead.includes(t.id)));}),{timeout:15000}).toBe(true);
    await page.evaluate(directory=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'NEW_THREAD_IN_PROJECT',directory});a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});},project);
    proof.seed='Review the available workspace integrations.';
    await replace(proof.seed);await send.click();
    await expect.poll(async()=>{
      const state=await context();
      return state.claude?.turns===1&&state.claude.chatState==='success'
        &&state.messages.some(message=>message.sender==='user'&&message.text===proof.seed&&message.context?.cliUuid);
    },{timeout:30000}).toBe(true);
    let initial=await context();proof.threadId=initial.threadId;proof.sessionId=initial.claude.sessionId;
    await replace(proof.draft);
    const seen=new Set();
    const cases=panelResize?[[0,'restricted']]:[[0,'restricted'],[1,'unrestricted'],[2,'restricted']];
    for(const [sequence,mode] of cases){
      const row={sequence,mode};proof.cases.push(row);
      row.before=await counts();
      if(heldCall&&!remoteRecovery&&sequence===2){
        const state=await context();
        assert.equal(state.native.state.busy,true);
        assert.equal(model.calls.some(call=>call.managedMcpHeldResult),false);
        proof.heldCall.busyBeforePolicy=true;
      }
      if(sequence){
        await writeFile(join(control,`request-${sequence}.json`),JSON.stringify({sequence,mode}),{flag:'wx',mode:0o600});
        const file=join(control,`receipt-${sequence}.json`);
        await expect.poll(async()=>{try{return (await lstat(file)).uid===0;}catch(error){if(error.code==='ENOENT')return false;throw error;}},{timeout:10000}).toBe(true);
        row.rootReceipt=JSON.parse(await readFile(file,'utf8'));
      }else row.rootReceipt=ready;
      const settings=await readFile(POLICY);
      const policyStat=await lstat(POLICY);
      assert.equal(policyStat.uid,0);assert.equal(policyStat.mode&0o777,0o644);
      row.policy={sha256:sha(settings),body:JSON.parse(settings)};
      assert.equal(row.policy.sha256,row.rootReceipt.sha256??ready.initialSha256);
      if(!inOwner||!sequence)await show.click();
      if(!sequence)for(let n=0;n<100;n++){
        if((await context()).native?.state?.status==='live')break;
        const stage=recognizeOnboardingPrompt(await section.locator('[data-terminal-text]').innerText({timeout:1000}).catch(()=>''),project);
        if(stage&&!seen.has(stage)){seen.add(stage);await section.locator('[aria-label="Terminal input"]').focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter');}
        await page.waitForTimeout(100);
      }
      await expect.poll(async()=> (await context()).native?.state?.status,{timeout:25000}).toBe('live');
      const active=await context();
      row.pid=active.native.state.nativePid;row.start=await processStart(row.pid);
      assert.ok(row.start);
      if(inOwner&&sequence){
        assert.equal(row.pid,proof.cases[0].pid);
        assert.equal(row.start,proof.cases[0].start);
      }else assert.ok(proof.cases.slice(0,-1).every(previous=>previous.pid!==row.pid));
      assert.equal(active.claude.sessionId,proof.sessionId);
      if(!inOwner||!sequence){
        await back.click();await expect(composer).toHaveText(proof.draft);
        await openPanel();
      }
      if(heldCall&&!remoteRecovery&&sequence===2){
        await expect.poll(()=>model.calls.find(call=>call.managedMcpHeldResult)?.managedMcpHeldResult?.is_error,
          {timeout:16000}).toBe(true);
        await expect.poll(async()=>{
          const state=await context();
          return state.claude?.turns===2&&state.claude.chatState==='success'&&!state.native?.state.busy;
        },{timeout:15000}).toBe(true);
        proof.heldCall.result=model.calls.find(call=>call.managedMcpHeldResult).managedMcpHeldResult;
        proof.heldCall.serverReceipt=await serverReceipt('local-review');
        assert.equal(proof.heldCall.serverReceipt.filter(record=>record.method==='tools/call').length,1);
        assert.ok(!proof.heldCall.serverReceipt.some(record=>record.method==='fixture/holdExpired'));
        if(remoteCall){
          const requested=proof.heldCall.serverReceipt.find(record=>record.method==='tools/call');
          await expect.poll(async()=> (await serverReceipt('local-review')).filter(record=>record.method==='transport/call-closed'&&record.id===requested.id).length,{timeout:5000}).toBe(1);
          proof.heldCall.serverReceipt=await serverReceipt('local-review');
          assert.ok(!proof.heldCall.serverReceipt.some(record=>record.method==='fixture/error'));
        }
        await expect(composer).toHaveText(proof.draft);
        initial=await context();
        await openPanel();
      }
      if(inOwner){
        const unrestricted=mode==='unrestricted';
        const matches=async()=>{
          row.liveServers=Object.fromEntries(await Promise.all(NAMES.map(async name=>[name,await serverProcesses(name)])));
          row.panel=await terminal.innerText({timeout:1000}).catch(()=>null);
          await save();
          const showsLocal=row.panel?.includes(localPanelName);
          // Claude may display its original failed/blocked row after removing the connection.
          const connectedLocal=row.panel?.split('\n').some(line=>line.includes(localPanelName)&&line.includes('✔'));
          const policyPresentation=unrestricted?connectedLocal:requireLiveRetirement?!connectedLocal:!showsLocal;
          return Boolean(row.liveServers['managed-review'].length
            &&(usesHttp||Boolean(row.liveServers['local-review'].length)===unrestricted)
            &&!row.liveServers['user-denied-review'].length
            &&row.panel?.includes('managed-review')
            &&policyPresentation
            &&!row.panel.includes('user-denied-review'));
        };
        if(sequence===2&&!requireLiveRetirement){
          const deadline=Date.now()+18000;
          while(!(row.openPanelRefreshed=await matches())&&Date.now()<deadline){
            await new Promise(resolve=>setTimeout(resolve,400));
          }
          if(!row.openPanelRefreshed){
            row.beforePanelReopen={panel:row.panel,liveServers:row.liveServers};
            await panel.getByRole('button',{name:'Close panel',exact:true}).click();
            await expect(composer).toHaveText(proof.draft);
            await openPanel();
            await expect(terminal).toContainText('managed-review',{timeout:15000});
            row.afterPanelReopenMatched=await matches();
          }
        }else await expect.poll(matches,{timeout:18000}).toBe(true);
        assert.equal(await processStart(row.pid),row.start);
      }
      await expect(terminal).toContainText('managed-review',{timeout:15000});
      if(mode==='unrestricted')await expect(terminal).toContainText(localPanelName);
      else if(!inOwner||sequence===0||row.openPanelRefreshed||row.afterPanelReopenMatched)await expect(terminal).not.toContainText(localPanelName);
      await expect(terminal).not.toContainText('user-denied-review');
      await expect.poll(async()=>{
        const latest=await counts();
        return (inOwner&&sequence||latest['managed-review']>row.before['managed-review'])
          &&(mode==='restricted'||latest['local-review']>row.before['local-review']);
      },{timeout:15000}).toBe(true);
      row.panel=await terminal.innerText();row.after=await counts();
      assert.equal(row.after['user-denied-review'],0);
      if(mode==='restricted')assert.equal(row.after['local-review'],row.before['local-review']);
      if(panelResize){
        proof.panelResize=[];
        await measureNativePanelResize({page,expect,panel,terminal,output,pid:row.pid,start:row.start,samples:proof.panelResize});
        proof.captures.push(...proof.panelResize.map(sample=>sample.screenshot));
      }else for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
        await page.setViewportSize(viewport);await expect(panel.getByRole('button',{name:'Close panel',exact:true})).toBeInViewport({ratio:1});
        await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
        const file=`managed-mcp-${sequence}-${size}.png`;
        await page.screenshot({path:join(output,file),animations:'disabled'});proof.captures.push(file);
      }
      if(heldCall&&sequence===1){
        await panel.getByRole('button',{name:'Close panel',exact:true}).click();
        await expect(composer).toHaveText(proof.draft);
        await replace(MANAGED_MCP_HOLD_PROMPT);await send.click();
        if(remoteRecovery){
          const result=()=>model.calls.find(call=>call.managedMcpHeldResult)?.managedMcpHeldResult;
          await expect.poll(()=>result()?.content,{timeout:20000}).toEqual([{type:'text',text:'Recovered HTTP echo: disposable held echo'}]);
          assert.notEqual(result().is_error,true);
          await expect.poll(async()=>{
            const state=await context();
            const settledTool=state.messages.some(message=>message.blocks?.some(block=>
              block.type==='tool-activity'&&block.props.entries.some(entry=>
                entry.id===MANAGED_MCP_HOLD_TOOL_ID&&entry.status==='ok'&&entry.outputSummary===result().content[0].text)));
            const settledReply=state.messages.filter(message=>message.sender==='assistant'&&message.text===textReply).length===2;
            return state.claude?.turns===2&&state.claude.chatState==='success'&&!state.native?.state.busy&&settledTool&&settledReply;
          },{timeout:15000}).toBe(true);
          const server=await serverReceipt('local-review');
          const invocations=server.filter(record=>record.method==='tools/call');
          assert.equal(invocations.length,2);
          assert.notEqual(invocations[0].session,invocations[1].session);
          const expired=server.filter(record=>record.method==='transport/session-expired');
          const completed=server.filter(record=>record.method==='fixture/echo-completed');
          assert.deepEqual(expired.map(record=>record.session),[invocations[0].session]);
          assert.deepEqual(completed.map(record=>record.session),[invocations[1].session]);
          assert.ok(!server.some(record=>record.method==='fixture/error'));
          proof.heldCall={prompt:MANAGED_MCP_HOLD_PROMPT,transport:'http',eligibleRecovery:true,result:result(),serverReceipt:server};
          initial=await context();
        }else{
          await expect.poll(async()=> (await serverReceipt('local-review')).filter(record=>record.method==='tools/call').length,
            {timeout:20000}).toBe(1);
          proof.heldCall={prompt:MANAGED_MCP_HOLD_PROMPT,...(remoteCall?{transport:heldTransport}:{server:row.liveServers['local-review'][0]})};
        }
        await replace(proof.draft);
        if(remoteRecovery)await openPanel();
      }
      if(backgroundTask&&sequence===1){
        await panel.getByRole('button',{name:'Close panel',exact:true}).click();
        proof.background=await holdManagedMcpBackgroundPoll({page,expect,context,replace,send,
          receipt:()=>serverReceipt('local-review'),holdPath:taskHoldPath,serverName:taskServer,taskTool});
        await replace(proof.draft);
        await expect.poll(async()=>{
          const state=await context();
          return state.claude?.turns===2&&!state.native.state.busy
            &&state.messages.filter(row=>row.sender==='assistant'&&row.text===textReply).length===2;
        },{timeout:15000}).toBe(true);
        initial=await context();
        await openPanel();
      }
      if(inOwner&&sequence<2){await save();continue;}
      await panel.getByRole('button',{name:'Close panel',exact:true}).click();await expect(panel).toBeHidden();
      await expect(composer).toHaveText(proof.draft);
      if(backgroundTask)proof.captures.push(await observeManagedMcpBackgroundPolicy({page,expect,output,context,
        receipt:()=>serverReceipt('local-review'),background:proof.background,transport:backgroundHttp?'http':'stdio'}));
      const composed=await context();assert.deepEqual(composed.messages,initial.messages);assert.equal(composed.claude.totalCostUsd,initial.claude.totalCostUsd);
      if(inOwner){
        const prior=model.calls.length;
        proof.nativeFollowup='Confirm the workspace review after the managed policy was restored.';
        await replace(proof.nativeFollowup);await send.click();
        await expect.poll(async()=> (await context()).claude?.turns,{timeout:25000}).toBe(heldCall||backgroundTask?3:2);
        if(backgroundTask){
          await expect.poll(async()=>{
            const current=await context();
            return !current.native.state.busy&&current.messages.filter(message=>
              message.sender==='assistant'&&message.text===textReply&&message.context?.cliUuid).length===3;
          },{timeout:20000}).toBe(true);
        }else await expect.poll(async()=> (await context()).claude?.chatState,{timeout:20000}).toBe('success');
        proof.restoredModelToolNames=model.calls.slice(prior).filter(call=>call.toolNames?.includes('mcp__managed-review__echo')).flatMap(call=>call.toolNames);
        assert.ok(proof.restoredModelToolNames.includes('mcp__managed-review__echo'));
        assert.ok(!proof.restoredModelToolNames.includes('mcp__user-denied-review__echo'));
        if(requireLiveRetirement)assert.ok(!proof.restoredModelToolNames.some(name=>name.startsWith('mcp__local-review__')||name===taskTool||name===heldTool));
        assert.equal(await processStart(row.pid),row.start);
        await save();
      }
      if(reconnectExhaustion){
        await replace(proof.draft);
        const before=await context();
        phase('mcp-reconnect-exhaustion-wait');
        await observeManagedMcpReconnectExhaustion({page,expect,output,context,background:proof.background,
          captures:proof.captures,restrictionAt:row.rootReceipt.at*1000,parkedPresentation});
        const after=await context();
        assert.deepEqual(after.messages,before.messages);
        assert.equal(after.claude.totalCostUsd,before.claude.totalCostUsd);
        await expect(composer).toHaveText(proof.draft);
        phase('mcp-native-reconnect-exhausted');
        if(parkedRecovery){
          await observeManagedMcpParkedRecovery({page,expect,output,context,background:proof.background,captures:proof.captures,
            control,finishPath:taskFinishPath,receipt:()=>serverReceipt('local-review')});
          assert.equal(await processStart(row.pid),row.start);
          await expect(composer).toHaveText(proof.draft);
          phase('mcp-original-parked-task-recovered');
        }
      }
      if(backgroundTask){
        const traffic=await serverReceipt('local-review');
        assert.equal(traffic.filter(row=>row.value.event==='policy-peer-started').length,parkedRecovery?2:1);
        assert.equal(traffic.filter(row=>row.value.event==='policy-poll-held').length,1);
        proof.background.traffic=traffic;
        await save();
      }
      await show.click();
      await stop.click();
      await expect.poll(()=>processStart(row.pid),{timeout:15000}).not.toBe(row.start);
      row.retired=true;if(await back.isVisible())await back.click();await save();
    }
    proof.followup=panelResize?'Continue after checking the resized integrations panel.':'Continue this review after restoring the managed integration policy.';
    await replace(proof.followup);await send.click();
    await expect.poll(async()=> (await context()).claude?.turns,{timeout:25000}).toBe(heldCall||backgroundTask?4:inOwner?3:2);
    await expect.poll(async()=> (await context()).claude.chatState,{timeout:20000}).toBe('success');
    proof.final=await context();assert.equal(proof.final.claude.sessionId,proof.sessionId);assert.equal(proof.final.threadId,proof.threadId);
    proof.status='complete';phase(panelResize?'native-command-panel-resize-complete':'managed-mcp-admission-complete');
  } catch(error) {
    proof.status='failed';
    proof.error=error.message;
    await page.screenshot({path:join(output,'managed-mcp-failure.png'),timeout:3000}).catch(()=>{});
    throw error;
  } finally {await save();}
}

async function measureNativePanelResize({page,expect,panel,terminal,output,pid,start,samples}) {
  const drawing=panel.locator('[data-native-terminal]');
  const read=()=>drawing.evaluate(element=>{
    const canvas=element.querySelector('canvas');
    const text=element.querySelector('[data-terminal-text]')?.textContent??'';
    return {
      fittedColumns:Number(element.dataset.nativeTerminalColumns),
      fittedRows:Number(element.dataset.nativeTerminalRows),
      hostWidth:element.parentElement?.clientWidth??0,
      paintWidth:canvas?.getBoundingClientRect().width??0,
      separatorColumns:Math.max(0,...Array.from(text.matchAll(/─{8,}/g),match=>match[0].length)),
    };
  });
  for(const [label,width,height] of [['normal',1100,900],['compact',680,600],['restored',1100,900]]){
    const before=await read();
    const started=Date.now();
    await page.setViewportSize({width,height});
    await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
    const early=await read();
    const sample={label,width,height,before,early};
    samples.push(sample);
    await expect.poll(async()=>{
      sample.settled=await read();
      const {hostWidth,paintWidth,fittedColumns,separatorColumns}=sample.settled;
      return hostWidth>0&&paintWidth>=hostWidth*.97&&paintWidth<=hostWidth+1
        &&fittedColumns>0&&separatorColumns>=fittedColumns-3&&separatorColumns<=fittedColumns;
    },{intervals:[30,50,75,100,200],timeout:8000,message:`Terminal frame matches ${label} viewport`}).toBe(true);
    await expect(terminal).toContainText('managed-review');
    await expect(panel.getByRole('button',{name:'Close panel',exact:true})).toBeInViewport({ratio:1});
    assert.equal(await processStart(pid),start);
    sample.screenshot=`native-command-panel-${label}.png`;
    sample.settledAfterMs=Date.now()-started;
    await page.screenshot({path:join(output,sample.screenshot),animations:'disabled'});
  }
  const [normal,compact,restored]=samples.map(sample=>sample.settled);
  assert.ok(normal.fittedColumns>compact.fittedColumns*1.25);
  assert.equal(restored.fittedColumns,normal.fittedColumns);
  assert.equal(restored.separatorColumns,normal.separatorColumns);
}
