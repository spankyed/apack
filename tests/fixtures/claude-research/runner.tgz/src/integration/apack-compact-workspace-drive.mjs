import assert from 'node:assert/strict';
import { join } from 'node:path';

export async function driveCompactWorkspace({page,expect,context,composer,send,section,replace,proof,output,birth,save,phase,requireReachability,filterWorkspace=false}) {
  proof.scope='Ordinary workspace controls, session details and active Claude composer at three window widths.';
  proof.draft='Keep the release checklist wording unchanged.';
  await replace(proof.draft);
  const canvas=page.locator('[data-onboarding-id="canvas-area"]');
  const list=canvas.getByTitle('List View',{exact:true});
  const kanban=canvas.getByTitle('Kanban Board',{exact:true});
  const dashboard=canvas.getByTitle('Dashboard',{exact:true});
  const create=canvas.getByRole('button',{name:'New Thread',exact:true});
  const filter=canvas.getByRole('button',{name:'Filter',exact:true});
  const search=canvas.getByPlaceholder('Search threads...', {exact:true});
  proof.workspaceGeometry=[];
  const geometry=(locator,leadingOnly=false)=>locator.evaluate((element,leadingOnly)=>{
    const rect=element.getBoundingClientRect();
    const points=[[0.5,0.5],[0.15,0.5],[0.5,0.2],[0.5,0.8]];
    if(!leadingOnly) points.push([0.85,0.5]);
    const reachable=points.every(([x,y])=>element.contains(document.elementFromPoint(rect.x+rect.width*x,rect.y+rect.height*y)));
    return {x:rect.x,y:rect.y,width:rect.width,height:rect.height,reachable};
  },leadingOnly);
  const capture=async name=>{
    await page.screenshot({path:join(output,name),animations:'disabled'});
    proof.captures.push(name);
  };
  for(const [size,width,height] of [['normal',1100,900],['compact',680,600],['narrow',480,600]]){
    await page.setViewportSize({width,height});
    await expect(composer).toHaveText(proof.draft);
    await expect(send).toBeEnabled();
    const targets=[['list',list],['kanban',kanban],['dashboard',dashboard],['filter',filter],['search',search],['newThread',create],['composer',composer],['send',send]];
    const trigger=canvas.getByRole('button',{name:'Open Claude session details',exact:true});
    if(await trigger.count())targets.push(['sessionDetails',trigger]);
    const controls=Object.fromEntries(await Promise.all(targets.map(async ([name,locator])=>[name,await geometry(locator)])));
    proof.workspaceGeometry.push({size,width,height,controls});
    await capture('native-workspace-header-'+size+'.png');
    await save();
    if(requireReachability){
      assert.deepEqual(Object.entries(controls).filter(([,control])=>!control.reachable).map(([name])=>name),[]);
      await search.click({position:{x:14,y:controls.search.height/2}});
      await expect(search).toBeFocused();
      await expect(composer).toHaveText(proof.draft);
    }
  }
  if(filterWorkspace){
    await page.setViewportSize({width:1100,height:900});
    const filterState=()=>page.evaluate(()=>{
      const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;
      return {available:c.settings?.statuses?.map(status=>status.label)??[],selected:c.filters.statuses,search:c.filters.search??''};
    });
    await filter.click();
    const option=(await filterState()).available[0];
    assert.ok(option,'The ordinary workspace must supply a real status option');
    await page.getByRole('button',{name:option,exact:true}).click();
    await expect.poll(async()=>(await filterState()).selected).toEqual([option]);
    await page.keyboard.press('Escape');
    await expect(filter).toBeFocused();
    await search.fill('Release');
    await expect.poll(async()=>(await filterState()).search).toBe('Release');
    const clearSearch=search.locator('..').getByRole('button');
    const clearFilters=canvas.getByRole('button',{name:/Clear filters/});
    proof.filteredGeometry=[];
    for(const [size,width,height] of [['normal',1100,900],['compact',680,600],['narrow',480,600]]){
      await page.setViewportSize({width,height});
      await expect(composer).toHaveText(proof.draft);
      await expect(send).toBeEnabled();
      const targets={list,kanban,dashboard,filter,clearFilters,search,clearSearch,newThread:create,composer,send};
      const controls=Object.fromEntries(await Promise.all(Object.entries(targets).map(async ([name,locator])=>[name,await geometry(locator,name==='search')])));
      const query=await search.evaluate(input=>{
        const style=getComputedStyle(input);
        const measure=document.createElement('canvas').getContext('2d');
        measure.font=style.font;
        return {
          available:input.clientWidth-parseFloat(style.paddingLeft)-parseFloat(style.paddingRight),
          required:measure.measureText(input.value).width,
        };
      });
      const labels={
        filter:await filter.getByText('Filter',{exact:true}).isVisible(),
        clear:await clearFilters.getByText('Clear filters',{exact:true}).isVisible(),
        newThread:await create.getByText('New Thread',{exact:true}).isVisible(),
      };
      proof.filteredGeometry.push({size,width,height,controls,query,labels,state:await filterState()});
      await capture('native-workspace-filtered-'+size+'.png');
      await save();
      if(requireReachability){
        const unavailable=Object.entries(controls).filter(([name,control])=>!control.reachable).map(([name])=>name);
        assert.deepEqual(unavailable,[]);
        assert.ok(query.required<=query.available,'The entire short query must fit without scrolling');
        assert.deepEqual(labels,{filter:size!=='narrow',clear:size==='normal',newThread:size!=='narrow'});
      }
    }
    if(!requireReachability) await page.setViewportSize({width:1100,height:900});
    await clearSearch.click();
    if(requireReachability) await expect(search).toBeFocused();
    await expect.poll(async()=>(await filterState()).search).toBe('');
    await expect.poll(async()=>(await filterState()).selected).toEqual([option]);
    await clearFilters.click();
    await expect.poll(async()=>(await filterState()).selected).toEqual([]);
    await expect(composer).toHaveText(proof.draft);
    proof.filtersCleared=true;
  }
  await page.setViewportSize({width:680,height:600});
  const trigger=canvas.getByRole('button',{name:'Open Claude session details',exact:true});
  await expect(trigger).toBeVisible();
  await trigger.click();
  const details=page.locator('[aria-label="Claude session details"]');
  await capture('native-workspace-header-details-compact.png');
  await save();
  await expect(details).toContainText((await context()).claude.model);
  await details.getByRole('button',{name:'Close Claude session details',exact:true}).click();
  await expect(details).toBeHidden();
  await expect(trigger).toBeFocused();
  proof.detailsRoundtrip=true;
  await expect(composer).toHaveText(proof.draft);
  proof.final=await context();
  assert.equal(proof.final.threadId,proof.initial.threadId);
  assert.equal(proof.final.claude.sessionId,proof.sessionId);
  assert.equal(proof.final.native.state.nativePid,proof.pid);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
  proof.status='complete';
  await save();
  phase('native-workspace-header-observed');
}
