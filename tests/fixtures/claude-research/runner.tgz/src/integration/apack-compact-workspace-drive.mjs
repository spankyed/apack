import assert from 'node:assert/strict';
import { join } from 'node:path';

export async function driveCompactWorkspace({page,expect,context,composer,send,section,replace,proof,output,birth,save,phase,requireReachability}) {
  proof.scope='Ordinary workspace controls, session details and active Claude composer at three window widths.';
  proof.draft='Keep the release checklist wording unchanged.';
  await replace(proof.draft);
  const canvas=page.locator('[data-onboarding-id="canvas-area"]');
  const list=canvas.getByTitle('List View',{exact:true});
  const kanban=canvas.getByTitle('Kanban Board',{exact:true});
  const dashboard=canvas.getByTitle('Dashboard',{exact:true});
  const create=canvas.getByRole('button',{name:'New Thread',exact:true});
  const filter=canvas.getByRole('button',{name:'Filter',exact:true});
  const search=canvas.getByPlaceholder('Search threads...', {exact:true});
  proof.workspaceGeometry=[];
  const geometry=locator=>locator.evaluate(element=>{
    const rect=element.getBoundingClientRect();
    const points=[[0.5,0.5],[0.15,0.5],[0.85,0.5],[0.5,0.2],[0.5,0.8]];
    const reachable=points.every(([x,y])=>element.contains(document.elementFromPoint(rect.x+rect.width*x,rect.y+rect.height*y)));
    return {x:rect.x,y:rect.y,width:rect.width,height:rect.height,reachable};
  });
  const capture=async name=>{
    await page.screenshot({path:join(output,name),animations:'disabled'});
    proof.captures.push(name);
  };
  for(const [size,width,height] of [['normal',1100,900],['compact',680,600],['narrow',480,600]]){
    await page.setViewportSize({width,height});
    await expect(composer).toHaveText(proof.draft);
    await expect(send).toBeEnabled();
    const targets=[['list',list],['kanban',kanban],['dashboard',dashboard],['filter',filter],['search',search],['newThread',create],['composer',composer],['send',send]];
    const trigger=canvas.getByRole('button',{name:'Open Claude session details',exact:true});
    if(await trigger.count())targets.push(['sessionDetails',trigger]);
    const controls=Object.fromEntries(await Promise.all(targets.map(async ([name,locator])=>[name,await geometry(locator)])));
    proof.workspaceGeometry.push({size,width,height,controls});
    await capture('native-workspace-header-'+size+'.png');
    await save();
    if(requireReachability){
      assert.deepEqual(Object.entries(controls).filter(([,control])=>!control.reachable).map(([name])=>name),[]);
      await search.click({position:{x:14,y:controls.search.height/2}});
      await expect(search).toBeFocused();
      await expect(composer).toHaveText(proof.draft);
    }
  }
  await page.setViewportSize({width:680,height:600});
  const trigger=canvas.getByRole('button',{name:'Open Claude session details',exact:true});
  await expect(trigger).toBeVisible();
  await trigger.click();
  const details=page.locator('[aria-label="Claude session details"]');
  await capture('native-workspace-header-details-compact.png');
  await save();
  await expect(details).toContainText((await context()).claude.model);
  await details.getByRole('button',{name:'Close Claude session details',exact:true}).click();
  await expect(details).toBeHidden();
  await expect(trigger).toBeFocused();
  proof.detailsRoundtrip=true;
  await expect(composer).toHaveText(proof.draft);
  proof.final=await context();
  assert.equal(proof.final.threadId,proof.initial.threadId);
  assert.equal(proof.final.claude.sessionId,proof.sessionId);
  assert.equal(proof.final.native.state.nativePid,proof.pid);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();
  await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(()=>birth(proof.pid),{timeout:15000}).toBe(null);
  proof.status='complete';
  await save();
  phase('native-workspace-header-observed');
}
