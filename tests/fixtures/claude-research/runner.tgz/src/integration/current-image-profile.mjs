import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,rename,lstat} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {record} from '../protocol/record.mjs';

/** One ordinary preview contribution, installed by the original CLI in a disposable profile. */
export async function prepareCurrentImageProfile({workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
 const config=join(workspace,'.claude'),market='release-preview',marketplace=join(workspace,'preview-marketplace'),plugin=join(marketplace,'plugins/release-preview'),picture=join(workspace,'release-cover.rgba'),updatedPicture=join(workspace,'release-cover-updated.rgba'),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
 const executable='/frozen-claude/claude';assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 const names=['settings.json','plugins/known_marketplaces.json','plugins/installed_plugins.json'],saved=new Map();
 for(const name of names){const path=join(config,name);let bytes;try{const info=await lstat(path);assert.ok(info.isFile()&&info.uid===1000&&info.size<=1048576);bytes=await readFile(path)}catch(e){if(e.code!=='ENOENT')throw e}saved.set(name,bytes)}
 assert.ok(saved.get('settings.json'));assert.equal(saved.get('plugins/known_marketplaces.json'),undefined);assert.equal(saved.get('plugins/installed_plugins.json'),undefined);
 const source=`export function register(on){let generation=0;on('ui.render',{component:'TurnDuration'},async($,e,next)=>{const base=await next(e);if(e.surface!=='terminal'||e.view?.agentId)return base;const{Box,Text,Image,Button}=$.ui.resolve(e);return Box({flexDirection:'column',gap:'sm',children:[base,Text({children:['Release preview']}),Image({key:'release-cover',source:{file:generation?${JSON.stringify(updatedPicture)}:${JSON.stringify(picture)},format:'rgba',width:2,height:2,generation},columns:8,rows:2,alt:'Release cover preview'}),Button({key:'update-release-preview',label:'Update release preview',onPress:async()=>{generation++;await $.fs.write('release-preview-actions.json',JSON.stringify({generation,requestId:e.requestId,surface:e.surface}));await $.ui.invalidate('ui.render');}})]});});}`;
 let restored=false;
 async function restore(){if(restored)return;const rows=[];for(const[name,before]of saved){const path=join(config,name);if(existsSync(path)){assert.equal((await lstat(path)).uid,1000);await rename(path,join(workspace,'preserved-image-'+name.replaceAll('/','-')))}if(before!==undefined){await mkdir(join(path,'..'),{recursive:true});await writeFile(path,before,{mode:0o600,flag:'wx'});assert.deepEqual(await readFile(path),before)}else assert.equal(existsSync(path),false);rows.push({path:name,present:before!==undefined,sha256:before===undefined?null:sha(before)})}await writeFile(join(workspace,'image-profile-restoration.json'),JSON.stringify({restored:true,files:rows}));restored=true}
 try{
  await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
  await writeFile(picture,Buffer.from([255,136,0,255,255,136,0,255,255,136,0,255,255,136,0,255]),{mode:0o600,flag:'wx'});await writeFile(updatedPicture,Buffer.from([0,136,255,255,0,136,255,255,0,136,255,255,0,136,255,255]),{mode:0o600,flag:'wx'});
  await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:market,owner:{name:'Local release review'},plugins:[{name:'release-preview',source:'./plugins/release-preview'}]}));
  await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'release-preview',version:'0.0.1'}));await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));await writeFile(join(plugin,'hooks/register.ts'),source);
  const runs=[];for(const args of [['--setting-sources','','plugin','validate',plugin],['--setting-sources','','plugin','marketplace','add',marketplace],['--setting-sources','','plugin','install','release-preview@'+market]]){
   const run=await record({executable,cwd:join(workspace,'project'),output:join(workspace,'image-installation'),env:{...env,HOME:workspace,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},args,timeoutMs:20000,maxBytes:1048576});runs.push(run);assert.equal(run.code,0);assert.equal(run.status,'complete');
  }
  const registry=JSON.parse(await readFile(join(config,'plugins/installed_plugins.json'))),entries=registry.plugins?.['release-preview@'+market];assert.equal(entries?.length,1);assert.equal(entries[0].scope,'user');assert.equal(sha(await readFile(join(entries[0].installPath,'hooks/register.ts'))),sha(Buffer.from(source)));
  await writeFile(join(workspace,'image-profile-installation.json'),JSON.stringify({runs,picture,updatedPicture,sourceSha256:sha(Buffer.from(source)),installation:entries[0],scope:'Public original local plugin installation and one preview contribution; no private gate override or model request requested.'}));return{picture,updatedPicture,restore};
 }catch(error){await restore();throw error}
}
