import http from 'node:http';
import {syncBuiltinESMExports} from 'node:module';

/** Observe only native press RPCs, without adding readable data listeners or recording tokens/text. */
export function observeUiPress({record,maxRequests=8,maxBytes=16384}) {
 const original=http.request;let count=0,controlObserved=false;
 const report=value=>{try{record(value)}catch{/* Diagnostics must not change transport behavior. */}};
 function request(...args){
  const req=Reflect.apply(original,this,args);
  if(args[0]?.path!=='/control'||count>=maxRequests)return req;
  const chunks=[];let bytes=0,selected=false,id;
  const capture=value=>{if(value===undefined||typeof value==='function')return;try{const b=Buffer.isBuffer(value)?value:Buffer.from(value);bytes+=b.length;if(bytes<=maxBytes)chunks.push(Buffer.from(b));}catch{bytes=maxBytes+1}};
  const write=req.write,end=req.end;
  req.write=function(...values){capture(values[0]);return Reflect.apply(write,this,values)};
  req.end=function(...values){
   capture(values[0]);
   if(bytes<=maxBytes&&count<maxRequests){try{
    const body=JSON.parse(Buffer.concat(chunks).toString()),v=body.request;
    if(!controlObserved){controlObserved=true;report({phase:'control-observed',subtype:typeof v?.subtype==='string'?v.subtype.slice(0,64):null});}
    if(v?.subtype==='ui_press'){
     selected=true;id=++count;
     const fields=Object.fromEntries(['subtype','client_id','surface','plugin','handle','key','component','instance_id','instance_revision'].filter(k=>typeof v[k]==='string'||typeof v[k]==='number').map(k=>[k,typeof v[k]==='string'?v[k].slice(0,256):v[k]]));
     report({id,phase:'request',request:fields});
    }
   }catch{/* Not a selected JSON request. */}}
   return Reflect.apply(end,this,values);
  };
  // Wrap response emission before the request callback attaches its ordinary consumers.
  const emit=req.emit;
  req.emit=function(event,...values){
   if(selected&&event==='response'){
    const response=values[0],responseEmit=response.emit,parts=[];let size=0;
    response.emit=function(kind,...data){
     if(kind==='data'){const b=Buffer.from(data[0]);size+=b.length;if(size<=maxBytes)parts.push(Buffer.from(b));}
     if(kind==='end'){
      let result;try{if(size<=maxBytes)result=JSON.parse(Buffer.concat(parts).toString())}catch{}
      report({id,phase:'response',status:response.statusCode,bytes:size,truncated:size>maxBytes,...typeof result?.result?.handled==='boolean'?{handled:result.result.handled}:{},...typeof result?.error==='string'?{errorPresent:true}:{}});
     }
     return Reflect.apply(responseEmit,this,[kind,...data]);
    };
   }
   if(selected&&event==='error')report({id,phase:'error',code:String(values[0]?.code??values[0]?.name??'Error').slice(0,64)});
   return Reflect.apply(emit,this,[event,...values]);
  };
  return req;
 }
 http.request=request;syncBuiltinESMExports();
 return()=>{if(http.request===request){http.request=original;syncBuiltinESMExports()}};
}
