import assert from 'node:assert/strict';
import {addNativeSvgFixture} from '../protocol/native-svg-fixture.mjs';
import {spawn,execFileSync} from 'node:child_process';
import {readFile,readdir,mkdir,writeFile,symlink,access,cp} from 'node:fs/promises';
import {join} from 'node:path';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticAgentModel,HANDBACK_RELEASE_REPORT,HANDBACK_CALLER_REPORT,HANDBACK_LATE_REPORT} from '../protocol/synthetic-agent-model.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkout,executable,workspace,kind]=process.argv.slice(2);
const classifierOutcome=process.env.CLAUDE_RESEARCH_HANDBACK_CLASSIFIER;assert.ok(classifierOutcome===undefined||['blocked','refused'].includes(classifierOutcome));
const cancelCaller=process.env.CLAUDE_RESEARCH_HANDBACK_CANCEL==='1';
const duplicateHandback=process.env.CLAUDE_RESEARCH_HANDBACK_DUPLICATE==='1';
const nestedHandback=process.env.CLAUDE_RESEARCH_HANDBACK_NESTED==='1'||cancelCaller;
const handback=kind==='composer-app'&&process.env.CLAUDE_RESEARCH_HANDBACK==='1';
assert.ok(!duplicateHandback||!nestedHandback);assert.ok(!classifierOutcome||handback&&!duplicateHandback&&!nestedHandback);
const svg=kind==='composer-app'&&process.env.CLAUDE_RESEARCH_SVG==='1';
const cycles=kind === 'thinking-cycles-app';
const composer=kind === 'composer-app' || cycles;
const forms=kind === "question-forms-app";
const wizard=kind === "question-wizard-app" || forms;
const question=kind === "question-app" || wizard;
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
// The app's unrelated Codex root must not resolve a real native provider on fixture startup.
try{await access('/usr/local/bin/codex');throw Error('Real fallback Codex exists; do not run this isolated recipe');}catch(error){if(error.code!=='ENOENT')throw error;}
const plugin=join(workspace,'plugin');await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));await mkdir(join(workspace,'.claude'));await mkdir(join(workspace,'bin'));
const legacyPluginSource=`export function register(on) { let count=0,oversized=false,unsupported=false; on("ui.render",{component:"AbovePrompt"},async($,e,next)=>{const {Box,Text,Button,Link}=$.ui.resolve(e);if(oversized)return Box({children:Array.from({length:1100},()=>Text({children:["x"]}))});return Box({children:[...(unsupported?[Link({href:"https://example.invalid/native-fixture",label:"Unsupported native link"})]:[]),Text({children:["Synthetic apack UI count: "+count]}),Button({key:"fixture-button",label:"Run fixture",onPress:async()=>{count++;await $.fs.write("pressed.txt",String(count));$.ui.invalidate("ui.render");}}),Button({key:"unsupported-button",label:"Unsupported fixture",onPress:async()=>{unsupported=true;await $.fs.write("unsupported-trigger.txt","1");$.ui.invalidate("ui.render");}}),Button({key:"oversize-button",label:"Oversize fixture",onPress:async()=>{oversized=true;await $.fs.write("oversize-trigger.txt","1");$.ui.invalidate("ui.render");}}),await next(e)]});});}`;
let pluginSource = composer ? `export function register(on) {
 let summaryNotes={},summaryFrames={},summaryPresses=[];
 let messageNotes={},messageFrames={},messagePresses=[];
 let userNotes={},userFrames={},userPresses=[];
 on("ui.render",{component:"UserMessage"},async($,e,next)=>{const{Box,Text,Button,Input}=$.ui.resolve(e);userFrames[e.requestId]={id:e.requestId,text:e.props.text,origin:e.props.origin,isExpanded:e.props.isExpanded};await $.fs.write("app-user-frames.json",JSON.stringify(userFrames));return Box({gap:"sm",children:[Text({children:["Native user tools"]}),Button({key:"inspect-user",label:"Inspect native user",onPress:async()=>{userPresses.push({id:e.requestId,text:e.props.text,origin:e.props.origin,isExpanded:e.props.isExpanded});await $.fs.write("app-user-presses.json",JSON.stringify(userPresses));$.ui.invalidate("ui.render");}}),Input({key:"user-note",label:"User note",value:userNotes[e.requestId]??"",onInput:async value=>{userNotes[e.requestId]=value;await $.fs.write("app-user-note.json",JSON.stringify({id:e.requestId,value}));},onSubmit:async()=>{}}),await next({...e,props:{...e.props,text:e.props.isExpanded?"User display: "+e.props.text:"Compact user display: "+e.props.text.slice(0,40)}})]});});
 on("ui.render",{component:"AssistantMessage"},async($,e,next)=>{const{Box,Text,Button,Input}=$.ui.resolve(e);if(e.props.isSummary){summaryFrames[e.requestId]={id:e.requestId,text:e.props.text,isSummary:e.props.isSummary,isFirstOfReply:e.props.isFirstOfReply};await $.fs.write("app-summary-frames.json",JSON.stringify(summaryFrames));return Box({gap:"sm",children:[Button({key:"inspect-summary",label:"Inspect native summary",onPress:async()=>{summaryPresses.push({id:e.requestId,text:e.props.text});await $.fs.write("app-summary-presses.json",JSON.stringify(summaryPresses));$.ui.invalidate("ui.render");}}),Input({key:"summary-note",label:"Summary note",value:summaryNotes[e.requestId]??"",onInput:async value=>{summaryNotes[e.requestId]=value;await $.fs.write("app-summary-note.json",JSON.stringify({id:e.requestId,value}));$.ui.invalidate("ui.render");},onSubmit:async()=>{}}),await next({...e,props:{...e.props,text:"Summary display: "+e.props.text}})]});}messageFrames[e.requestId]={id:e.requestId,text:e.props.text,isFirstOfReply:e.props.isFirstOfReply};await $.fs.write("app-message-frames.json",JSON.stringify(messageFrames));return Box({gap:"sm",children:[Text({children:["Native assistant tools"]}),Button({key:"inspect-message",label:"Inspect native message",onPress:async()=>{messagePresses.push({id:e.requestId,text:e.props.text});await $.fs.write("app-message-presses.json",JSON.stringify(messagePresses));$.ui.invalidate("ui.render");}}),Input({key:"message-note",label:"Message note",value:messageNotes[e.requestId]??"",onInput:async value=>{messageNotes[e.requestId]=value;await $.fs.write("app-message-note.json",JSON.stringify({id:e.requestId,value}));},onSubmit:async()=>{}}),await next({...e,props:{...e.props,text:"Native display: "+e.props.text}})]});});
 let noticeCount=0,count=0,fillCount=0,codeMode=0,suggestions=[],acceptedKeys=[],paneDrafts={},paneCloses=[],paneRefused=false,paneExtra=0,paneScrolls=[],paneScrollArmed=false,paneScrollTested=false;
 on("ui.scroll",async($,e,next)=>{if(e.component==="Pane"){paneScrolls.push(e);await $.fs.write("app-pane-scrolls.json",JSON.stringify(paneScrolls));if(e.origin.kind==="person"&&e.pointer&&paneScrollArmed&&e.by===3){paneScrollArmed=false;paneScrollTested=true;return {deny:"Keep pane position"};}if(e.origin.kind==="person"&&e.pointer&&paneScrollArmed&&e.by===2)return next({...e,offset:e.offset+1});}return next(e);});
 on("ui.close",async($,e,next)=>{paneCloses.push(e);await $.fs.write("app-pane-closes.json",JSON.stringify(paneCloses));if(e.id==="review-a"&&e.origin.kind==="person"&&!paneRefused){paneRefused=true;return {deny:"Keep review open once"};}return next(e);});
 on("ui.render",{component:"Pane"},async($,e,next)=>{const {Box,Text,Input,Button}=$.ui.resolve(e);await $.fs.write("app-pane-render.json",JSON.stringify({id:e.requestId,columns:e.props.bodyColumns,scroll:e.props.scroll,isFocused:e.props.isFocused}));return Box({flexDirection:"column",gap:"sm",children:[Text({children:["Native pane body "+e.requestId]}),Input({key:"pane-note",label:"Pane note",value:paneDrafts[e.requestId]??"",autoFocus:true,onInput:async value=>{paneDrafts[e.requestId]=value;await $.fs.write("app-pane-field.json",JSON.stringify({id:e.requestId,value}));},onSubmit:async()=>{}}),Button({key:"pane-action",label:"Pane action",onPress:async()=>$.fs.write("app-pane-action.json",JSON.stringify({id:e.requestId}))}),...Array.from({length:24},(_,index)=>Text({children:["Scroll row "+(index+1)]})),Box({key:"pane-scroll-target",children:[Text({children:["Native keyed target"]})]}),...Array.from({length:paneExtra},(_,index)=>Text({children:["New pane update "+(index+1)]}))]});});
 on("prompt.edit",async($,e,next)=>{if(e.key?.key==="tab"||e.key?.key==="right"){acceptedKeys.push(e);await $.fs.write("native-accepted-suggestions.json",JSON.stringify(acceptedKeys));}return next(e);});
 on("ui.focus",async($,e,next)=>{await $.fs.write("native-focus.json",JSON.stringify(e));return next(e.element==="focus-note"?{...e,element:"draft"}:e);});
 on("ui.render",{component:"AbovePrompt"},async($,e,next)=>{
  const {Box,Text,Button,Input,Select,Svg,Code}=$.ui.resolve(e);
  return Box({key:"native-preview",flexDirection:"column",gap:"sm",children:[
   Text({weight:"medium",children:["Context tools · "+count+(count===1?" update":" updates")]}),
   Box({flexDirection:"row",flexWrap:"wrap",gap:"sm",children:[
    Button({key:"refresh",label:"Refresh context",hotkey:"1",variant:"primary",children:["Refresh context"],onPress:async()=>{count++;await $.fs.write("pressed.txt",String(count));$.ui.invalidate("ui.render");}}),
    Button({key:"suggest",label:"Suggest next step",onPress:async()=>{const result=await $.prompt.suggest({text:"Review the implementation."});const draft=await $.prompt.read();suggestions.push({result,draft});await $.fs.write("native-suggestions.json",JSON.stringify(suggestions));}}),
    Button({key:"focus-note",label:"Focus note",onPress:async()=>{}}),
    Button({key:"fill-draft",label:"Fill draft",onPress:async()=>{const mode=["append","replace","insert"][Math.min(fillCount++,2)];const text=mode==="append"?" (native draft)":mode==="replace"?["**Native** replacement","","- item"].join(String.fromCharCode(10)):" inserted";const before=await $.prompt.read();const filled=await $.prompt.fill({mode,text,decorations:[{start:mode==="replace"?0:1,end:text.length,italic:true}]});const after=await $.prompt.read();await $.fs.write("native-prompt-host.json",JSON.stringify({mode,before,filled,after}));}}),
    Button({key:"pane-start",label:"Pane start",onPress:async()=>{await $.ui.scroll({to:"start",in:"review-a"});paneScrollArmed=true;}}),
    Button({key:"pane-target",label:"Reveal pane target",onPress:async()=>$.ui.scroll({to:{key:"pane-scroll-target"},in:"review-a",block:"start"})}),
    Button({key:"pane-end",label:"Follow pane end",onPress:async()=>$.ui.scroll({to:"end",in:"review-a"})}),
    Button({key:"pane-grow",label:"Append pane update",onPress:async()=>{paneExtra++;$.ui.invalidate("ui.render");}}),
    Button({key:"open-panes",label:"Open panes",onPress:async()=>{await $.ui.open({id:"review-a",title:"<Native review A>",focus:true,closeOnEscape:true,holdToasts:true,rows:6});await $.ui.open({id:"review-b",title:"Native review B"});}}),
    Button({key:"code-preview",label:"Code preview",onPress:async()=>{codeMode=(codeMode+1)%4;$.ui.invalidate("ui.render");}}),
    Button({key:"show-native-notice",label:"Show native notice",onPress:async()=>{noticeCount++;$.ui.status("<b>Native pinned status "+noticeCount+"</b>"+String.fromCharCode(10)+"Second pinned line");$.ui.toast('<img src="native-toast" onerror="bad()">Native transient notice',{timeoutMs:1000});await $.fs.write("app-native-notices.json",JSON.stringify({count:noticeCount,at:await $.clock.now()}));}}),
    Button({key:"clear-native-notice",label:"Clear native notice",onPress:async()=>{$.ui.status();}}),
    Svg({source:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 140 30"><rect width="140" height="30" rx="6" fill="#303030"/><circle cx="15" cy="15" r="6" fill="#4ade80"/><text x="30" y="20" fill="white" font-size="12" font-family="system-ui,sans-serif">Connected</text></svg>',alt:"Connection status",width:140,height:30})
   ]}),
   Box({flexDirection:"row",flexWrap:"wrap",gap:"sm",children:[
    Box({flexGrow:1,minWidth:24,children:[Input({key:"draft",label:"Context note",rows:1,onInput:async value=>{await $.fs.write("native-field.json",JSON.stringify(value));if(value==="Move focus to response style")await $.ui.focus({requestId:e.requestId,key:"choice"});},onSubmit:async()=>{}})]}),
    Box({width:18,children:[Select({key:"choice",label:"Response style",options:[{value:"alpha",label:"Concise"},{value:"beta",label:"Detailed"}],value:"alpha",onSelect:async value=>$.fs.write("native-choice.json",JSON.stringify(value))})]})
   ]}),
   Box({flexDirection:"row",gap:"sm",children:[Text({color:"subtle",hover:{scope:"details",color:"claude"},children:["More details"]}),Text({color:"subtle",hover:{scope:"details",color:"claude"},children:["Current session"]})]}),
   ...(codeMode?[Code({source:codeMode===3?["@@ -4,2 +8,2 @@"," const unchanged = true;","-<script>old()</script>",'+<img onerror="bad()">',""].join(String.fromCharCode(10)):["const message = "+JSON.stringify("A long literal line ".repeat(18))+";","/* multiline comment","still a comment */","const done = true;"].join(String.fromCharCode(10)),path:"language-hint-only.ts",startLine:98,format:codeMode===3?"diff":"source",wrap:codeMode===2?"truncate-end":"wrap"})]:[]),
   await next(e)
  ]});
 });
}` : legacyPluginSource;
assert.ok(!(svg&&handback));
if(svg||handback)pluginSource='export function register(on) {}';
await writeFile(join(plugin,'.claude-plugin','plugin.json'),JSON.stringify({name:'research-ui-fixture',version:'0.0.1'}));await writeFile(join(plugin,'hooks','hooks.json'),JSON.stringify({modules:['./register.ts']}));await writeFile(join(plugin,'hooks','register.ts'),pluginSource);
if(svg){await addNativeSvgFixture(plugin);pluginSource=await readFile(join(plugin,'hooks','register.ts'),'utf8');}
await writeFile(join(workspace,'.claude','settings.json'),JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',...(cycles?{permissions:{allow:['Bash(/usr/bin/printf NATIVE_THINKING_CYCLE_*)']}}:{})}));
if(handback){
 await writeFile(join(workspace,'handback-fixture.json'),JSON.stringify({report:nestedHandback?HANDBACK_LATE_REPORT:HANDBACK_RELEASE_REPORT,nested:nestedHandback,duplicate:duplicateHandback,cancelCaller,classifierOutcome,reports:nestedHandback?[HANDBACK_CALLER_REPORT,HANDBACK_LATE_REPORT]:[HANDBACK_RELEASE_REPORT]}));
 const hook=join(workspace,'handback-hook.cjs');
 await writeFile(hook,`let body='';process.stdin.on('data',chunk=>body+=chunk);process.stdin.on('end',()=>{const e=JSON.parse(body);if(e.tool_name==='Agent'){if(!${JSON.stringify(nestedHandback?[['status-fixture','Return the synthetic worker marker only.'],['late-fixture','Return the late migration report.']]:[['status-fixture','Return the synthetic worker marker only.']])}.some(([type,prompt])=>e.tool_input.subagent_type===type&&e.tool_input.prompt===prompt))process.exit(1);}else if(${JSON.stringify(cancelCaller)}&&e.tool_name==='TaskStop'){const fs=require('node:fs');const events=fs.readFileSync(${JSON.stringify(join(workspace,'handback-native-events.jsonl'))},'utf8').trim().split(String.fromCharCode(10)).map(JSON.parse);const root=events.find(event=>event.type==='system'&&event.subtype==='task_started'&&event.spawn_depth===1);if(!root||e.tool_input.task_id!==root.task_id||Object.keys(e.tool_input).some(key=>key!=='task_id'))process.exit(1);}else if(e.tool_name!=='SubagentHandback'||!${JSON.stringify(nestedHandback?[HANDBACK_CALLER_REPORT,HANDBACK_LATE_REPORT]:[HANDBACK_RELEASE_REPORT])}.includes(e.tool_input.message))process.exit(1);process.stdout.write(JSON.stringify({hookSpecificOutput:{hookEventName:'PreToolUse',permissionDecision:'allow'}}));});`);
 const settings=join(workspace,'.claude/settings.json'),value=JSON.parse(await readFile(settings,'utf8'));
 const quote=text=>"'"+text.replaceAll("'", "'\\''")+"'";
 value.hooks={PreToolUse:[{matcher:cancelCaller?'Agent|TaskStop':'Agent|SubagentHandback',hooks:[{type:'command',command:quote(process.execPath)+' '+quote(hook)}]}]};await writeFile(settings,JSON.stringify(value));
}
await symlink(process.execPath,join(workspace,'bin','node'));
const compiledHashes=async()=>Object.fromEntries(await Promise.all(['runtime/index.cjs','runtime/fe.js','runtime/fe.css','runtime/content/actions.content.json','runtime/content/flows.content.json'].map(async name=>[name,hash(await readFile(join(checkout,'packages/default-setup/dist',name)))])));
const compiledBefore=await compiledHashes();
let releaseCallerCancel;const callerCancelReady=new Promise(resolve=>{releaseCallerCancel=resolve});
const model=handback?await startSyntheticAgentModel({handbackProbe:true,...(cancelCaller?{handbackNested:true,handbackCancelCaller:true,handbackClassifierSafe:true,handbackMessage:HANDBACK_LATE_REPORT,beforeCallerCancel:async()=>{await writeFile(join(workspace,'caller-cancel-ready'),'ready');await callerCancelReady;}}:classifierOutcome?{handbackClassifierOutcome:classifierOutcome,handbackMessage:HANDBACK_RELEASE_REPORT}:nestedHandback?{handbackNested:true,handbackClassifierSafe:true,handbackMessage:HANDBACK_LATE_REPORT}:duplicateHandback?{handbackDuplicate:true,handbackClassifierSafe:true,handbackMessage:HANDBACK_RELEASE_REPORT}:{handbackClassifierUnavailable:true,handbackMessage:HANDBACK_RELEASE_REPORT}),parentLaunchOnce:true,captureMessages:true,requestLimit:16}):await startSyntheticModel(workspace,question?'AskUserQuestion':'TextOnly',{questionWizard:wizard,questionFormControls:forms,pairedText:composer&&!cycles&&!svg,thinkingBlock:composer&&!svg,narration:composer&&!svg,thinkingCycles:cycles?2:0});
let releaseTimer;if(handback)releaseTimer=setInterval(()=>{void (async()=>{
 if(cancelCaller){
  const events=(await readFile(join(workspace,'handback-native-events.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
  if(events.some(event=>event.type==='system'&&event.subtype==='task_started'&&event.spawn_depth===1))model.releaseChild();
  if(events.some(event=>event.type==='user'&&event.message?.content?.some(block=>block.type==='tool_result'&&block.tool_use_id==='cancel_caller_fixture'&&!block.is_error))){model.releaseGrandchild();clearInterval(releaseTimer);return;}
  await access(join(workspace,'release-caller-cancel'));releaseCallerCancel();return;
 }
 await access(join(workspace,'release-handback'));model.releaseChild();if(!nestedHandback){clearInterval(releaseTimer);return;}
 const events=(await readFile(join(workspace,'handback-native-events.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);if(events.some(event=>event.type==='system'&&event.subtype==='task_notification'&&event.status==='completed'&&event.handback_report?.text===HANDBACK_CALLER_REPORT)){model.releaseGrandchild();clearInterval(releaseTimer);}
 })().catch(()=>{});},50);
const launcher=join(workspace,'native-fixture-launcher.cjs');
const launcherSource=`#!/usr/bin/env node
const {spawn}=require('node:child_process');const {appendFileSync}=require('node:fs');
const args=process.argv.slice(2);appendFileSync(${JSON.stringify(join(workspace,'native-launches.jsonl'))},JSON.stringify({args})+String.fromCharCode(10));
const env={...process.env,HOME:${JSON.stringify(workspace)},CLAUDE_CONFIG_DIR:${JSON.stringify(join(workspace,'.claude'))},ANTHROPIC_BASE_URL:${JSON.stringify(model.url)},DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN','CLAUDE_CODE_SIMPLE','CLAUDE_CODE_COORDINATOR_MODE'])delete env[key];
${handback?`// This private profile explicitly supplies the original auto/handback gates; it is not an auto-mode UI acceptance test.
const at=args.indexOf('--permission-mode');if(at<0)throw Error('Missing native permission mode');args[at+1]='auto';env.CLAUDE_CODE_SENDMESSAGE_HANDBACK='1';args.push('--agents',${JSON.stringify(JSON.stringify({'status-fixture':{description:'Private handback fixture',prompt:'NativeStatusChildSystem. Return only the fixed worker report.',tools:nestedHandback?['Agent']:[],maxTurns:5,permissionMode:'auto'},...(nestedHandback?{'late-fixture':{description:'Migration reviewer',prompt:'NativeStatusGrandchildSystem. Return the late migration report.',tools:[],maxTurns:3,permissionMode:'auto'}}:{})}))});`:''}
const child=spawn(${JSON.stringify(executable)},['--plugin-dir',${JSON.stringify(plugin)},...args],{env,stdio:${handback?"['pipe','pipe','inherit']":question?"['pipe','inherit','inherit']":"'inherit'"}});
${question?`let pending='';process.stdin.on('data',chunk=>{pending+=chunk.toString();let i;while((i=pending.indexOf(String.fromCharCode(10)))>=0){const line=pending.slice(0,i);pending=pending.slice(i+1);try{const value=JSON.parse(line);if(value.type==='control_response')appendFileSync(${JSON.stringify(join(workspace,'native-control-responses.jsonl'))},JSON.stringify(value)+String.fromCharCode(10));}catch{}}});process.stdin.pipe(child.stdin);`:''}
${handback?`process.stdin.pipe(child.stdin);child.stdout.pipe(process.stdout);let nativePending='',nativeRecords=0;child.stdout.on('data',chunk=>{nativePending+=chunk.toString();let at;while((at=nativePending.indexOf(String.fromCharCode(10)))>=0){const line=nativePending.slice(0,at);nativePending=nativePending.slice(at+1);try{const e=JSON.parse(line);if(nativeRecords<100&&(e.type==='result'||e.type==='user'&&e.message?.content?.some(block=>block.type==='tool_result'&&block.tool_use_id==='cancel_caller_fixture')||['assistant','user'].includes(e.type)&&e.parent_tool_use_id||e.type==='system'&&['task_started','task_notification'].includes(e.subtype))){nativeRecords++;appendFileSync(${JSON.stringify(join(workspace,'handback-native-events.jsonl'))},JSON.stringify(e)+String.fromCharCode(10));}}catch{}}if(nativePending.length>2097152)nativePending='';});`:''}
child.on('spawn',()=>appendFileSync(${JSON.stringify(join(workspace,'native-child-processes.jsonl'))},JSON.stringify({args,pid:child.pid})+String.fromCharCode(10)));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>child.kill(signal));
const timeout=setTimeout(()=>child.kill('SIGKILL'),60000);
child.on('error',()=>{clearTimeout(timeout);process.exitCode=1});child.on('close',code=>{appendFileSync(${JSON.stringify(join(workspace,'native-child-exits.jsonl'))},JSON.stringify({pid:child.pid,code})+String.fromCharCode(10));clearTimeout(timeout);process.exitCode=code??1});
`;
await writeFile(launcher,launcherSource,{mode:0o755});
execFileSync(process.execPath,['--check',launcher],{stdio:'pipe'});
let child,exited=false,deadline,escalation;
try{
 child=spawn(process.execPath,[join(checkout,'scripts/with-source.mjs'),process.execPath,join(checkout,'node_modules/@playwright/test/cli.js'),'test',handback?'tests/e2e/ui/claude-native-handback.spec.ts':svg?'tests/e2e/ui/claude-native-svg.spec.ts':cycles?'tests/e2e/ui/claude-native-thinking-cycles.spec.ts':composer?'tests/e2e/ui/claude-native-composer.spec.ts':forms?'tests/e2e/ui/claude-native-question-forms.spec.ts':wizard?'tests/e2e/ui/claude-native-question-wizard.spec.ts':question?'tests/e2e/ui/claude-native-question.spec.ts':'tests/e2e/ui/claude-native-ui.spec.ts','--reporter=line'],{cwd:checkout,env:{...process.env,PATH:join(workspace,'bin')+':/usr/bin:/bin:/usr/sbin:/sbin',CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_LAUNCHER:launcher,CLAUDE_RESEARCH_MODEL_URL:model.url,E2E_KEEP_DATA:'1',E2E_DATA_DIR:join(workspace,'app-data')},stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);
 deadline=setTimeout(()=>{child.kill('SIGTERM');escalation=setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000)},100000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',code=>{exited=true;resolve(code)})});
 await cp(join(checkout,'.apack/tests/results'),join(workspace,'electron-results'),{recursive:true});
 assert.equal(code,0,'Native composer Electron test failed');
 const evidence=JSON.parse(await readFile(join(workspace,cycles?'thinking-cycles-app-evidence.json':composer?'composer-app-evidence.json':forms?'question-forms-app-evidence.json':wizard?'question-wizard-app-evidence.json':question?'question-app-evidence.json':'ui-app-evidence.json'),'utf8'));
 if(cancelCaller){assert.ok(model.messageRequestCount()<=16);assert.ok(model.calls.some(call=>call.grandchild&&call.responseCancelled===true&&!call.delivered));assert.ok(model.calls.some(call=>call.response==='TaskStop'));}
 else if(handback){assert.ok(model.messageRequestCount()<=16);assert.ok(model.requests.some((request,index)=>!model.calls[index]?.child&&request.tools?.some(tool=>tool.name==='Agent')&&JSON.stringify(request.messages).includes(nestedHandback?HANDBACK_LATE_REPORT:'Release review complete.')),'Original parent continuation must contain report');assert.equal(model.calls.filter(call=>call.response==='SubagentHandback').length,nestedHandback?2:1);if(classifierOutcome){const events=(await readFile(join(workspace,'handback-native-events.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);const report=events.find(event=>event.type==='system'&&event.subtype==='task_notification'&&event.handback==='flagged');assert.ok(report?.handback_report?.warning);assert.ok(model.requests.some((request,index)=>!model.calls[index]?.child&&request.tools?.some(tool=>tool.name==='Agent')&&JSON.stringify(request.messages).includes(report.handback_report.warning)),'Original parent must receive the original warning');}}else assert.equal(model.calls.length,cycles?3:composer?2:3);
 if(cycles){assert.equal(model.calls.at(-1).thinkingCycleResults.length,2);assert.ok(model.calls.at(-1).thinkingCycleResults.every(result=>!result.is_error));evidence.nativeToolResults=model.calls.at(-1).thinkingCycleResults;}
 const expectedAnswers={ 'Which synthetic fixture should be selected?':forms?'Custom fixture answer':'Alpha', ...(wizard?{'Which second synthetic fixture should be selected?':forms?'Gamma, Delta':'Delta'}:{}) };
 if(question){const replies=(await readFile(join(workspace,'native-control-responses.jsonl'),'utf8')).trim().split('\n').map(JSON.parse).filter(value=>value.response?.request_id===evidence.requestId);assert.equal(replies.length,1);assert.deepEqual(replies[0].response.response.updatedInput.answers,expectedAnswers);evidence.oneCorrelatedNativeReply=true;const all=(await readFile(join(workspace,'native-control-responses.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert.equal(all.filter(value=>value.response?.request_id===evidence.retiredRequestId).length,0);evidence[wizard?'noNativeReplyAfterCancel':'noNativeReplyAfterPause']=true;}
 if(wizard){
  const results=[];const projects=join(workspace,'.claude','projects');
  for(const folder of await readdir(projects,{withFileTypes:true}))if(folder.isDirectory())for(const file of await readdir(join(projects,folder.name)))if(file.endsWith('.jsonl')){
   const path=join(projects,folder.name,file),bytes=await readFile(path);
   for(const line of bytes.toString().trim().split('\n')){const row=JSON.parse(line);for(const block of Array.isArray(row.message?.content)?row.message.content:[])if(block.type==='tool_result'&&block.tool_use_id==='toolu_research_fixture')results.push({block,transcriptPath:path,transcriptSha256:hash(bytes)});}
  }
  assert.equal(results.length,1);assert.ok(!results[0].block.is_error);assert.equal(typeof results[0].block.content,'string');
  for(const answer of Object.entries(expectedAnswers).map(([question,answer])=>JSON.stringify(question)+'='+JSON.stringify(answer)))assert.ok(results[0].block.content.includes(answer));
  evidence.nativeAnsweredBothQuestions=true;evidence.nativeToolResult=results[0];
 }
 if(handback){const launched=(await readFile(join(workspace,'native-child-processes.jsonl'),'utf8')).trim().split('\n').map(JSON.parse),closed=(await readFile(join(workspace,'native-child-exits.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert.ok(launched.length>0&&launched.every(child=>closed.some(exit=>exit.pid===child.pid)),'Owned native child did not exit');evidence.ownedShutdown=true;}
 assert.deepEqual(await compiledHashes(),compiledBefore,'Pack outputs changed during native UI test');
 console.log(JSON.stringify({evidence:cycles?'apack-native-thinking-cycles-app':composer?'apack-native-composer-app':forms?'apack-native-question-forms-app':wizard?'apack-native-question-wizard-app':question?'apack-native-question-app':'apack-native-ui-app',...evidence,compiledPackHashes:compiledBefore,targetSha256:hash(await readFile(executable)),pluginSourceSha256:hash(Buffer.from(pluginSource)),launcherSourceSha256:hash(Buffer.from(launcherSource)),syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{
 releaseCallerCancel();clearTimeout(deadline);clearTimeout(escalation);clearInterval(releaseTimer);
 if(child&&!exited){child.kill('SIGTERM');setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000).unref()}
 if(handback)await writeFile(join(workspace,'handback-model-requests.json'),JSON.stringify(model.requests,null,2));
 console.log(JSON.stringify({diagnostic:'synthetic-calls',calls:handback?model.calls.map(({messages,...call})=>call):model.calls}));await model.close();
}
