import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdir, readdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs'
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs'
import { createUltraplanCloudFixture, ultraplanFixtureRepository } from '../protocol/native-ultraplan-cloud-fixture.mjs'
import { isolatedModelGateway } from '../protocol/native-loopback-model-gateway.mjs'
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs'
import { startSyntheticModel } from '../protocol/synthetic-model.mjs'
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs'

const title = 'Run ultraplan in the cloud?'
const seed = 'Read the release notes and acknowledge this fixture.'
const planPrompt = 'Review the local release notes and outline the rollout.'
const followup = 'Confirm that I cancelled the cloud review.'
const approvedPlan = '# Owned release plan\n\n' + Array.from({length:22},(_,index)=>`${index+1}. Review migration boundary ${index+1}.`).join('\n')
  + '\n\nDocument the verified rollback command.'

const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const pause = ms => new Promise(resolve => setTimeout(resolve, ms))

async function processStart(pid) {
  if (!Number.isSafeInteger(pid) || pid<=1) return null
  try {
    const stat = await readFile('/proc/'+pid+'/stat','utf8')
    const fields = stat.slice(stat.lastIndexOf(')')+2).split(' ')
    return fields[0] === 'Z' ? null : fields[19]
  } catch (error) {
    if (error.code === 'ENOENT' || error.code === 'ESRCH') return null
    throw error
  }
}

export async function driveUltraplanConsent({checkout,workspace,env,cloudHandoff=false,handoffChoice='cancel'}) {
  assert.equal(process.platform,'linux')
  assert.equal(process.getuid(),1000)
  assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-ultraplan[0-9]+$/)
  const boundary = JSON.parse(await readFile('/control/offline-verified'))
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly && boundary.requireUltraplanConsent)
  assert.equal(boundary.requireUltraplanHandoff===true,cloudHandoff)
  assert.ok(cloudHandoff ? ['cancel','here','fresh'].includes(handoffChoice) : handoffChoice==='cancel')
  assert.equal(boundary.ultraplanHandoffChoice??'cancel',handoffChoice)
  const cloud=cloudHandoff ? createUltraplanCloudFixture({prompt:planPrompt,plan:approvedPlan}) : undefined
  const hosts = await readFile('/etc/hosts','utf8')
  assert.ok(hosts.split('\n').some(line => /^127\.0\.0\.1\s+api\.anthropic\.com(?:\s|$)/.test(line)))
  const project = join(workspace,'project')
  await mkdir(project)
  await writeFile(join(project,'release-notes.md'),'# Release notes\n\nAn owned rollout fixture.\n')
  const git = args=>execFileSync('/usr/bin/git',args,{cwd:project,env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000})
  git(['init','--quiet','-b','main'])
  if (cloud) {
    git(['add','release-notes.md'])
    git(['-c','user.email=fixture@example.test','-c','user.name=Owned fixture','commit','--quiet','-m','Owned release notes'])
    git(['remote','add','origin','https://github.com/'+ultraplanFixtureRepository+'.git'])
    git(['update-ref','refs/remotes/origin/main','HEAD'])
    git(['branch','--set-upstream-to=origin/main','main'])
  }
  const account = await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'})
  const configPath = join(account.CLAUDE_CONFIG_DIR,'.claude.json')
  const config = JSON.parse(await readFile(configPath))
  Object.assign(config,{
    hasCompletedOnboarding:true,hasSeenUltraplanTerms:false,
    projects:{[project]:{hasTrustDialogAccepted:true}},
    cachedGrowthBookFeatures:{tengu_ccr_bridge:true,tengu_ultraplan_config:{enabled:true}},
  })
  await writeFile(configPath,JSON.stringify(config))
  const model = await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:8,textReply:'The release notes fixture is ready.'})
  const requests = []
  let billing
  const modelGateway=isolatedModelGateway(model,requests)
  try {
    const tls = await prepareNativeCreditTls(join(workspace,'account-tls'))
    billing = await startNativeCreditBilling(tls,{
      allowMutations:false,evidencePath:join(workspace,'account-live.json'),managedConnector:async (req,res) => {
        if (cloud && await cloud.handle(req,res)) return true
        return modelGateway(req,res)
      },
    })
    const launchEnv = {...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:'https://api.anthropic.com',
      DISABLE_AUTOUPDATER:'1',DISABLE_TELEMETRY:'1',DISABLE_ERROR_REPORTING:'1',CLAUDE_CODE_GB_DISK_CACHE_WHEN_TELEMETRY_OFF:'1',
      PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project}
    delete launchEnv.ANTHROPIC_API_KEY
    await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-ultraplan-consent',journeyBudgetMs:125000,
      journey:args=>consentJourney({...args,configPath,model,requests,cloud,handoffChoice})})
  } finally {
    await billing?.close()
    await model.close()
    await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2))
    await writeFile(join(workspace,'loopback-proxy.json'),JSON.stringify(requests,null,2))
    if (cloud) await writeFile(join(workspace,'cloud-fixture.json'),JSON.stringify(cloud.snapshot(),null,2))
    if (billing) {
      assert.equal(billing.state.purchases.length,0)
      assert.equal(billing.state.adminRequests.length,0)
      await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2))
    }
  }
}

async function consentJourney({app,page,output,workspace,project,userDataDir,expect,phase,configPath,model,requests,cloud,handoffChoice}) {
  const proof = {status:'running',scenario:cloud?'cloud-handoff-'+handoffChoice:'prelaunch-cancel',captures:[]}
  const activeSession = () => proof.implementation?.sessionId ?? proof.owner.sessionId
  const save = () => writeFile(join(output,'ultraplan-consent.json'),JSON.stringify(proof,null,2))
  const context = () => page.evaluate(() => {
    const context = window.applicationState.system.get('default-setup/threads').getSnapshot().context
    const entry = Object.entries(context.nativeTerminalViews).find(([,view])=>view.threadId===context.currentThread?.id)
    return {threadId:context.currentThread?.id,claude:context.currentThread?.context?.claudeCode,
      native:entry&&{...entry[1],mountId:entry[0]},messages:context.currentThread?.messages}
  })
  const card = page.locator('[data-onboarding-id="agent-chat-input"]')
  const composer = card.locator('[contenteditable="true"]')
  const send = card.getByRole('button',{name:'Send',exact:true})
  const region = page.getByRole('region',{name:'Claude native interface',exact:true})
  const dialog = page.getByRole('dialog',{name:title,exact:true})
  const replace = async text => {
    await composer.click()
    await composer.press('ControlOrMeta+a')
    await composer.press('Backspace')
    await composer.pressSequentially(text)
    await expect(composer).toHaveText(text)
  }
  const decision = async () => {
    const c = await context()
    const state = c.native?.state
    return {id:state?.notice?.id, revision:state?.notice?.revision, sessionId:state?.sessionId, ownerId:state?.ownerId,
      mountId:c.native?.mountId, pid:state?.nativePid, notice:state?.notice}
  }
  const capture = async (stage, subject, controls=[], prepare) => {
    for (const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
      await page.setViewportSize(viewport)
      await page.evaluate(()=>document.fonts.ready.then(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))))
      await prepare?.()
      await expect(subject).toBeInViewport({ratio:0.8})
      for (const control of controls) await expect(control).toBeInViewport({ratio:1})
      const file = 'ultraplan-'+stage+'-'+size+'.png'
      await page.screenshot({path:join(output,file),animations:'disabled'})
      proof.captures.push(file)
    }
    await save()
  }
  try {
    const compiled=JSON.parse(await readFile('/control/producer-pack-inputs.json'))
    for (const part of ['runtime/fe.js','runtime/index.cjs']) {
      assert.equal(sha(await readFile(join(userDataDir,'apack/packs/default-setup',part))),compiled[part])
    }
    await app.waitForSurface('default-setup/threads')
    await app.navigate('host/settings')
    await page.evaluate(()=>{
      const settings=window.applicationState.system.get('host/settings')
      settings.send({type:'TAB.SELECT',tab:'general'})
      settings.send({type:'GENERAL_NAV.SELECT',item:'secrets'})
    })
    const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..')
    await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude')
    await page.waitForTimeout(700)
    await app.navigate('default-setup/threads')
    await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.modes.some(mode=>mode.name==='Claude Code')),{timeout:15000}).toBe(true)
    await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}))
    await page.evaluate(directory=>{
      const threads=window.applicationState.system.get('default-setup/threads')
      threads.send({type:'NEW_THREAD_IN_PROJECT',directory})
      threads.send({type:'SET_MODE',mode:'Claude Code'})
      threads.send({type:'SET_PHASE',phase:'Edit'})
    },project)
    await replace(seed)
    await send.click()
    await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1)
    await region.getByRole('button',{name:'Use native interface',exact:true}).click()
    const seen=new Set()
    for (let attempt=0;attempt<100;attempt++) {
      if ((await context()).native?.state?.status==='live') break
      const text=await region.locator('[data-terminal-text]').innerText().catch(()=>'')
      const step=recognizeOnboardingPrompt(text,project)
      if(step&&!seen.has(step)){
        seen.add(step)
        await region.locator('[aria-label="Terminal input"]').focus()
        await page.waitForTimeout(200)
        await page.keyboard.press(step==='workspace-trust'?'ArrowDown':'Enter')
      }
      await pause(100)
    }
    await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live')
    proof.initialThread=(await context()).threadId
    proof.owner=await decision()
    proof.ownerStart=await processStart(proof.owner.pid)
    assert.ok(proof.ownerStart)
    await region.getByRole('button',{name:'Back to conversation',exact:true}).click()
    await save()

    const callsBefore=model.calls.length
    const wireBefore=requests.length
    await replace('/ultraplan '+planPrompt)
    await send.click()
    phase('ultraplan-command-submitted')
    await expect(dialog).toBeVisible({timeout:22000})
    const run=dialog.getByRole('button',{name:'Yes',exact:true})
    const cancel=dialog.getByRole('button',{name:'No',exact:true})
    await expect(run).toBeEnabled({timeout:16000})
    await expect(cancel).toBeEnabled()
    proof.offer=await decision()
    assert.equal(proof.offer.notice.kind,'ultraplan_launch')
    assert.equal(proof.offer.notice.phase,'terms')
    assert.equal(proof.offer.ownerId,proof.owner.ownerId)
    assert.equal(proof.offer.sessionId,proof.owner.sessionId)
    assert.equal(proof.offer.pid,proof.owner.pid)
    assert.equal(proof.offer.notice.summary.replace(/\s/g,''),planPrompt.replace(/\s/g,''))
    assert.equal(proof.offer.notice.helpUrl,'https://code.claude.com/docs/en/claude-code-on-the-web')
    await capture('terms',dialog,[run,cancel,dialog.getByRole('link',{name:'More information:',exact:true})])
    if (cloud) {
      await run.click()
      await expect(dialog).toBeHidden({timeout:14000})
      await expect.poll(async()=>(await context()).native?.noticeAnswer?.status,{timeout:10000}).toBe('done')
      proof.launch=(await context()).native?.noticeAnswer
      assert.equal(proof.launch?.revision,proof.offer.revision)
      await expect.poll(()=>cloud.snapshot().pendingServed,{timeout:30000}).toBe(true)
      await expect.poll(async()=>(await context()).native?.state?.tasks?.some(task=>task.nativeTaskType==='remote_agent'&&task.status==='running'),{timeout:15000}).toBe(true)
      cloud.release()
      const handoff=page.getByRole('dialog',{name:'Ultraplan approved',exact:true})
      await expect(handoff).toBeVisible({timeout:16000})
      proof.handoff=await decision()
      assert.equal(proof.handoff.ownerId,proof.owner.ownerId)
      assert.equal(proof.handoff.sessionId,proof.owner.sessionId)
      assert.equal(proof.handoff.notice.plan,approvedPlan)
      const here=handoff.getByRole('button',{name:'Implement here',exact:true})
      const fresh=handoff.getByRole('button',{name:'Start new session',exact:true})
      const stop=handoff.getByRole('button',{name:'Cancel',exact:true})
      await capture('approved-plan',handoff,[here,fresh,stop])
      const reading=handoff.locator('.native-notice__body')
      await capture('approved-plan-end',handoff,[here,fresh,stop],async ()=>{
        const endVisible=await reading.evaluate(async el=>{
          el.scrollTop=el.scrollHeight
          await new Promise(resolve=>requestAnimationFrame(resolve))
          const line=el.querySelector('pre')?.lastChild
          const offset=line?.textContent?.lastIndexOf('Document the verified rollback command.')??-1
          if (offset<0) return false
          const range=document.createRange()
          range.setStart(line,offset)
          range.setEnd(line,line.textContent.length)
          const final=range.getBoundingClientRect(),viewport=el.getBoundingClientRect()
          return final.height>0 && final.top>=viewport.top && final.bottom<=viewport.bottom+1
        })
        assert.ok(endVisible,'The approved plan ending must be readable after scrolling')
      })
      const beforeChoice=model.calls.length
      await {cancel:stop,here,fresh}[handoffChoice].click()
      await expect(handoff).toBeHidden({timeout:12000})
      assert.equal(JSON.parse(await readFile(configPath)).hasSeenUltraplanTerms,true)
      if (handoffChoice==='cancel') {
        await expect.poll(async()=>(await context()).native?.noticeAnswer?.status,{timeout:10000}).toBe('done')
        proof.handoffCancel=(await context()).native?.noticeAnswer
        assert.equal(proof.handoffCancel?.revision,proof.handoff.revision)
        const folder=join(workspace,'.claude','plans')
        let matches=[]
        await expect.poll(async()=>{
          const files=await readdir(folder).catch(error=>{if(error.code==='ENOENT')return [];throw error})
          assert.ok(files.length<30)
          matches=[]
          for(const file of files.filter(name=>name.endsWith('.md'))){
            const text=await readFile(join(folder,file),'utf8')
            if (text.includes(approvedPlan)) matches.push({file,text})
          }
          return matches.length
        },{timeout:10000}).toBe(1)
        proof.savedPlan=matches[0]
        assert.equal(model.calls.length,beforeChoice)
        assert.equal((await decision()).sessionId,proof.owner.sessionId)
      } else {
        // A native reset can replace the notice projection before its acknowledgement is visible in the app.
        const originalSentences = {
          here: 'chose to implement it in this session',
          fresh: 'chose to implement it in a fresh session',
        }
        const content = message => typeof message.content==='string' ? message.content
          : (message.content??[]).map(block=>block.text??'').join('\n')
        // The CLI frames the plan and indents every line, including blank lines.
        const planBody=approvedPlan.split('\n').map(line=>'  '+line).join('\n')
        const framedPlan='\n<ultraplan>\n'+planBody+'\n</ultraplan>\n'
        let sent
        await expect.poll(async()=>{
          sent=model.calls.slice(beforeChoice).find(call=>call.messages.some(message=>message.role==='user'
            && content(message).includes(originalSentences[handoffChoice]) && content(message).includes(framedPlan)))
          const current=await context(), id=current.claude?.sessionId
          return !!sent && current.claude?.chatState==='success' && current.native?.state?.busy===false
            && current.native.state.sessionId===id && (handoffChoice==='fresh'?id!==proof.owner.sessionId:id===proof.owner.sessionId)
        },{timeout:28000}).toBe(true)
        const current=await context()
        const hasPriorSeed=sent.messages.some(message=>message.role==='user'&&content(message).includes(seed))
        assert.equal(hasPriorSeed,handoffChoice==='here','Fresh must withhold the old conversation')
        assert.equal(current.threadId,proof.initialThread,'A native reset remains in the app thread')
        const sessionId=current.claude.sessionId
        if(handoffChoice==='fresh')assert.ok(current.claude.previousSessionIds?.includes(proof.owner.sessionId))
        const journals=join(workspace,'.claude','projects')
        let auto
        await expect.poll(async()=>{
          const paths=await readdir(journals,{recursive:true})
          assert.ok(paths.length<200)
          const path=paths.find(path=>path.endsWith('/'+sessionId+'.jsonl'))
          if(!path)return false
          const source=await readFile(join(journals,path),'utf8')
          assert.ok(source.length<=8*1024*1024)
          const rows=source.slice(0,source.lastIndexOf('\n')+1).trim().split('\n').filter(Boolean).map(JSON.parse)
          auto=rows.filter(row=>row.type==='user'&&row.origin?.kind==='auto-continuation'&&content(row.message??{}).includes(framedPlan))
          return auto.length===1
        },{timeout:12000}).toBe(true)
        proof.implementation={choice:handoffChoice,sessionId,nativeUuid:auto[0].uuid,origin:auto[0].origin.kind,hasPriorSeed}
        await capture('implemented',composer,[send])
      }
      await expect.poll(()=>cloud.snapshot().archived,{timeout:10000}).toBe(true)
      assert.equal(await processStart(proof.owner.pid),proof.ownerStart)
      await expect(composer).toBeEditable()
    } else {
      await cancel.click()
      await expect(dialog).toBeHidden({timeout:14000})
      await expect.poll(async()=>(await context()).native?.noticeAnswer?.status,{timeout:10000}).toBe('done')
      proof.cancel=(await context()).native?.noticeAnswer
      assert.equal(proof.cancel?.revision,proof.offer.revision)
      assert.equal(await processStart(proof.owner.pid),proof.ownerStart)
      assert.equal((await decision()).sessionId,proof.owner.sessionId)
      assert.equal(Boolean(JSON.parse(await readFile(configPath)).hasSeenUltraplanTerms),false)
      assert.equal(model.calls.length,callsBefore)
      assert.equal(requests.length,wireBefore)
      proof.afterCancel=await context()
      await save()
      await expect(composer).toHaveText(planPrompt,{timeout:12000})
      await capture('returned-draft',composer,[send])
    }

    await expect.poll(async()=>{
      const current=await context()
      return current.native?.state?.busy===false && current.claude?.chatState==='success'
    },{timeout:20000}).toBe(true)
    await replace(followup)
    await send.click()
    await expect.poll(async()=>{
      const current=await context()
      const reachedModel=model.calls.some(call=>call.messages.some(message=>message.role==='user'&&JSON.stringify(message.content).includes(followup)))
      return reachedModel && current.claude?.chatState==='success' && current.native?.state?.busy===false
    },{timeout:25000}).toBe(true)
    const final=await context()
    assert.equal(final.claude.sessionId,activeSession())
    assert.equal(await processStart(proof.owner.pid),proof.ownerStart)
    const humans=final.messages.filter(message=>message.sender==='user'&&message.text===followup)
    assert.equal(humans.length,1)
    assert.ok(humans[0].context?.cliUuid)
    proof.followup={text:followup,cliUuid:humans[0].context.cliUuid,sessionId:final.claude.sessionId}
    await region.getByRole('button',{name:'Use native interface',exact:true}).click()
    await region.getByRole('button',{name:'Stop session',exact:true}).click()
    await expect.poll(()=>processStart(proof.owner.pid),{timeout:15000}).not.toBe(proof.ownerStart)
    proof.status='complete'
    phase(cloud?'ultraplan-handoff-'+handoffChoice+'-complete':'ultraplan-cancel-return-complete')
  } catch (error) {
    proof.error={message:error.message}
    proof.observed=await context().catch(()=>null)
    await page.screenshot({path:join(output,'ultraplan-first-failure.png'),timeout:3000}).catch(()=>{})
    throw error
  } finally {
    await save()
  }
}
