import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,rename,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {prepareNativeAppCliProfile} from './native-app-cli-profile.mjs';
import {addNativeLspFixture} from '../protocol/native-lsp-fixture.mjs';
import {startSyntheticLspModel} from '../protocol/synthetic-lsp-model.mjs';
import {recognizeOnboardingPrompt} from '../protocol/pty-onboarding.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function birth(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),f=raw.slice(raw.lastIndexOf(')')+2).split(' ');return f[0]==='Z'?null:f[19]}catch(error){if(error.code==='ENOENT')return null;throw error}}

/** A genuine pending native LSP request survives turn interruption until original manager disposal. */
export async function driveLspOwnerReplacement({checkout,workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-lsp[0-9]+$/);
 const project=join(workspace,'project'),plugin=join(project,'fixture-plugin');await mkdir(project);await mkdir(plugin);await mkdir(join(plugin,'.claude-plugin'));await mkdir(join(plugin,'hooks'));
 execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'native-history-fixture',version:'1.0.0'}));
 await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));await addNativeLspFixture(project,plugin);
 // This case deliberately keeps one real request pending across captures and a user command.
 const lspPath=join(plugin,'.lsp.json'),lsp=JSON.parse(await readFile(lspPath,'utf8'));lsp.review.requestTimeout=15000;await writeFile(lspPath,JSON.stringify(lsp));
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),profile=await prepareNativeAppCliProfile({checkout,workspace,account,owned:true});
 const configPath=join(profile,'.claude.json'),settingsPath=join(profile,'settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({...JSON.parse(await readFile(settingsPath,'utf8')),theme:'dark',model:'opus'}));
 const configBefore=await readFile(configPath),settingsBefore=await readFile(settingsPath),launcher=join(workspace,'claude-lsp');
 const quote=s=>"'"+s.replaceAll("'","'\\''")+"'";
 await writeFile(launcher,'#!/bin/sh\nexec /frozen-claude/claude --plugin-dir '+quote(plugin)+' --debug-file '+quote(join(project,'native-debug.log'))+' "$@"\n',{mode:0o700});
 await writeFile(join(project,'native-lsp-phase'),'0');let model,billing,proof;
 try{
  model=await startSyntheticLspModel(project,{lifetime:true,seedBeforeNative:true});const tls=await prepareNativeCreditTls(join(workspace,'account-tls'));billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
  const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-lsp-owner-replacement',journeyBudgetMs:120000,journey:async({app,page,expect,phase,output})=>{
   proof={status:'running',requestTimeoutMs:15000,captures:[],readings:[],scope:'Original native owner Stop/reopen while its LSP request is pending; retire old active authority and recover the same canonical session.'};const save=()=>writeFile(join(output,'lsp-replacement.json'),JSON.stringify(proof,null,2));
   const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:Object.values(c.nativeUiViews).find(v=>v.threadId===c.currentThread?.id)}});
   const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('.ProseMirror[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true}),input=section.locator('[aria-label="Terminal input"]');
   const replace=async text=>{await composer.click();await composer.press('ControlOrMeta+a');await composer.press('Backspace');await composer.pressSequentially(text);await expect(composer).toHaveText(text)};
   const rows=async()=>{try{return(await readFile(join(project,'native-lsp-receipts.jsonl'),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse)}catch(error){if(error.code==='ENOENT')return[];throw error}};
   const owner=JSON.parse(await readFile(join(project,'native-lsp-owner.json'),'utf8')).owner;
   const fault=async value=>{const path=join(project,'native-lsp-fault.json');await writeFile(path+'.tmp',JSON.stringify({owner,...value}));await rename(path+'.tmp',path)};
   const idle=()=>expect.poll(async()=>{const c=await context();return !c.native?.state?.busy&&c.claude?.chatState==='success'},{timeout:20000}).toBe(true);
   const readFreshResult=async size=>{
    const result=page.locator('[data-native-tool-result="native_lsp_7"]'),history=page.getByTestId('chat-transcript').locator(':scope > div').first(),target='Defined in definitions.review:1:14';
    const measure=()=>result.evaluate((e,target)=>{
     const walker=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),nodes=[];let node,text='';while(node=walker.nextNode()){nodes.push({node,start:text.length});text+=node.textContent}
     const index=text.indexOf(target);if(index<0)return null;const begin=nodes.findLast(n=>n.start<=index),end=nodes.findLast(n=>n.start<index+target.length),range=document.createRange();range.setStart(begin.node,index-begin.start);range.setEnd(end.node,index+target.length-end.start);
     const r=range.getBoundingClientRect(),clip={left:0,top:0,right:innerWidth,bottom:innerHeight};for(let parent=e;parent;parent=parent.parentElement){const s=getComputedStyle(parent),b=parent.getBoundingClientRect();if(/auto|scroll|hidden|clip/.test(s.overflowY)){clip.top=Math.max(clip.top,b.top);clip.bottom=Math.min(clip.bottom,b.bottom)}if(/auto|scroll|hidden|clip/.test(s.overflowX)){clip.left=Math.max(clip.left,b.left);clip.right=Math.min(clip.right,b.right)}}
     const rect={left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height},visible=r.width>0&&r.height>0&&r.left>=clip.left-1&&r.right<=clip.right+1&&r.top>=clip.top-1&&r.bottom<=clip.bottom+1,hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);
     return{target,text,rect,clip,visible,reachable:!!hit&&e.contains(hit)};
    },target);
    await expect.poll(async()=>!!await measure(),{timeout:5000}).toBe(true);const wheels=[];
    for(let i=0;i<8;i++){const m=await measure();if(m.visible&&m.reachable)break;const b=await history.boundingBox();assert.ok(b&&b.height>0);await page.mouse.move(b.x+b.width/2,b.y+b.height/2);const delta=m.rect.bottom>m.clip.bottom?Math.min(180,m.rect.bottom-m.clip.bottom+12):-Math.min(180,m.clip.top-m.rect.top+12);wheels.push(delta);await page.mouse.wheel(0,delta);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));}
    await expect.poll(async()=>{const m=await measure();return m?.visible&&m.reachable},{timeout:5000}).toBe(true);(proof.resultReadings??=[]).push({size,...await measure(),wheels,scroll:await history.evaluate(e=>({top:e.scrollTop,height:e.clientHeight,total:e.scrollHeight}))});
   };
   const capture=async stage=>{for(const[size,viewport]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
    await page.setViewportSize(viewport);if(stage==='fresh')await readFreshResult(size);await expect(composer).toHaveText(proof.draft);await expect(send).toBeInViewport({ratio:1});
    await page.evaluate(async()=>{await document.fonts.ready;await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))});
    const file='lsp-replacement-'+stage+'-'+size+'.png';await page.screenshot({path:join(output,file)});proof.captures.push(file);proof.readings.push({stage,size,diagnostics:await page.locator('[data-native-diagnostic]').evaluateAll(nodes=>nodes.map(node=>({id:node.dataset.nativeDiagnostic,text:node.innerText}))),context:await context(),document:await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}))});await save();
   }};
   try{
    await app.waitForSurface('default-setup/threads');await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'TAB.SELECT',tab:'general'});a.send({type:'GENERAL_NAV.SELECT',item:'secrets'})});const provider=page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..');await provider.getByPlaceholder('Path override (auto-detected if empty)').fill(launcher);await page.waitForTimeout(700);
    await app.navigate('default-setup/threads');await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return!!c.currentThread?.id&&c.openedThreadId===null&&c.tabs.every(t=>c.tabsRead.includes(t.id))&&c.modes.some(m=>m.name==='Claude Code')}),{timeout:15000}).toBe(true);
    await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(directory=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory}),project);await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
    proof.seed='Review the language server lifecycle.';await replace(proof.seed);await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);await section.getByRole('button',{name:'Use native interface',exact:true}).click();
    const seen=new Set();for(let i=0;i<100;i++){const native=(await context()).native?.state;if(native?.nativePid&&native.status==='live')break;const text=await section.locator('[data-terminal-text]').innerText().catch(()=>''),stage=recognizeOnboardingPrompt(text,project);if(stage&&!seen.has(stage)){seen.add(stage);await input.focus();if(stage.startsWith('workspace-trust'))await page.waitForTimeout(200);await page.keyboard.press(stage==='workspace-trust'?'ArrowDown':'Enter')}await page.waitForTimeout(100)}
    await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');proof.initial=await context();proof.sessionId=proof.initial.claude.sessionId;proof.pid=proof.initial.native.state.nativePid;proof.start=await birth(proof.pid);assert.ok(proof.start);await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
    proof.draft='Keep these release notes while the language server reloads.';
    const submit=async(number,text)=>{await writeFile(join(project,'native-lsp-phase'),String(number));await replace(text);await send.click();await expect.poll(()=>model.calls.some(row=>row.phase===number&&row.response?.type==='tool_use'&&row.response.id==='native_lsp_'+number),{timeout:15000}).toBe(true);await replace(proof.draft)};
    await submit(1,'Find the release definition before reload.');await idle();await expect.poll(async()=>(await rows()).filter(r=>r.method==='textDocument/definition').length,{timeout:15000}).toBe(1);
    const diagnostic=page.locator('[data-native-diagnostic]').first();await expect(diagnostic).toBeVisible({timeout:15000});proof.diagnosticBefore={id:await diagnostic.getAttribute('data-native-diagnostic'),text:await diagnostic.innerText()};
    const server=(await rows()).find(r=>r.event==='start');assert.ok(server);proof.oldServer={pid:server.pid,start:await birth(server.pid)};await fault({action:'hold',pid:server.pid});
    await submit(4,'Find the definition while retaining a pending server request.');await expect.poll(async()=>(await rows()).some(r=>r.event==='held'),{timeout:15000}).toBe(true);proof.held=(await rows()).find(r=>r.event==='held');await capture('held');
    proof.pauseRequestedAt=Date.now();await card.getByTitle('Pause agent work',{exact:true}).click();
    // A native tool without a cancellation token can remain busy after Pause.
    // Stop must stay reachable before that tool settles, rather than waiting for idle.
    proof.interrupted=await context();proof.pauseObservedAt=Date.now();assert.equal(await birth(server.pid),proof.oldServer.start);assert.ok(!(await rows()).some(r=>r.event==='released'));
    // Re-enter the existing owner to reach Stop while its request is still pending.
    proof.beforeOwnerStop=await context();proof.draftBeforeStop=await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));
    proof.reentryRequestedAt=Date.now();await section.getByRole('button',{name:'Use native interface',exact:true}).click();proof.reentryObservedAt=Date.now();const callsBefore=model.calls.filter(row=>row.phase!==undefined&&row.kind!=='native-quota').length;
    proof.stopRequestedAt=Date.now();await section.getByRole('button',{name:'Stop session',exact:true}).click();proof.stopObservedAt=Date.now();await expect.poll(()=>birth(proof.pid),{timeout:10000}).not.toBe(proof.start);await expect.poll(()=>birth(server.pid),{timeout:10000}).not.toBe(proof.oldServer.start);
    proof.ownerReplacedAt=Date.now();assert.ok(proof.ownerReplacedAt-proof.held.at<proof.requestTimeoutMs);proof.retirement={nativePid:proof.pid,nativeStart:await birth(proof.pid),serverPid:server.pid,serverStart:await birth(server.pid)};
    const debug=await readFile(join(project,'native-debug.log'),'utf8');assert.doesNotMatch(debug,/LSP request.*no response after/);
    if(await section.getByRole('button',{name:'Back to conversation',exact:true}).isVisible())await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
    await expect(composer).toHaveText(proof.draft);assert.deepEqual(await composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()})),proof.draftBeforeStop);
    await expect(page.locator('[data-native-diagnostic]')).toHaveCount(0);proof.retiredDiagnostics=[];await capture('replaced');await fault({action:'none'});
    await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');proof.replacementNative=await context();proof.freshPid=proof.replacementNative.native.state.nativePid;proof.freshStart=await birth(proof.freshPid);assert.ok(proof.freshStart);assert.notEqual(proof.freshPid,proof.pid);assert.notEqual(proof.replacementNative.native.state.ownerId,proof.initial.native.state.ownerId);assert.equal(proof.replacementNative.claude.sessionId,proof.sessionId);
    proof.replacementModelDelta=model.calls.filter(row=>row.phase!==undefined&&row.kind!=='native-quota').length-callsBefore;assert.equal(proof.replacementModelDelta,0);proof.replacementReceipts=await rows();assert.ok(!proof.replacementReceipts.some(r=>r.event==='released'));
    await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toHaveText(proof.draft);
    await submit(7,'Find the release definition with the replacement server.');await idle();await expect.poll(async()=>(await rows()).filter(r=>r.event==='start').length,{timeout:15000}).toBe(2);
    const fresh=(await rows()).filter(r=>r.event==='start').at(-1);assert.notEqual(fresh.pid,server.pid);assert.ok((await rows()).some(r=>r.pid===fresh.pid&&r.method==='textDocument/didOpen'&&r.version===1));proof.freshServer=fresh;
    const group=page.locator('[data-native-tool-activity][data-native-tool-ids~="native_lsp_7"]');await expect(group).toBeVisible();const toggle=group.getByRole('button').first();if(await toggle.getAttribute('aria-expanded')==='false')await toggle.click();await expect(page.locator('[data-native-tool-result="native_lsp_7"]')).toContainText('definitions.review');await capture('fresh');
    proof.beforeStop=await context();assert.equal(proof.beforeStop.native.state.nativePid,proof.freshPid);assert.equal(proof.beforeStop.claude.sessionId,proof.sessionId);
    await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>birth(proof.freshPid),{timeout:15000}).not.toBe(proof.freshStart);
    if(await section.getByRole('button',{name:'Back to conversation',exact:true}).isVisible())await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await writeFile(join(project,'native-lsp-phase'),'0');proof.recovery='Continue the same review after replacing the language server.';await replace(proof.recovery);const recoveryTurns=(await context()).claude.turns,recoveryRequests=model.calls.filter(row=>row.phase===0).length;await send.click();await expect.poll(async()=>{const c=(await context()).claude;return c.turns>recoveryTurns&&c.chatState==='success'&&model.calls.filter(row=>row.phase===0).length>recoveryRequests},{timeout:20000}).toBe(true);await replace(proof.draft);await capture('recovered');proof.final=await context();assert.equal(proof.final.claude.sessionId,proof.sessionId);
    const files=await readdir(join(profile,'projects'),{recursive:true}),journal=files.find(p=>p.endsWith('/'+proof.sessionId+'.jsonl'));assert.ok(journal);await writeFile(join(workspace,'native-journal.jsonl'),await readFile(join(profile,'projects',journal)));proof.receipts=await rows();for(const r of proof.receipts.filter(r=>r.event==='start'))assert.equal(await birth(r.pid),null);proof.status='complete';await save();phase('lsp-replacement-complete');
   }catch(error){proof.error={name:error.name,message:String(error.message).slice(0,3000)};proof.observed=await context().catch(()=>null);await page.screenshot({path:join(output,'lsp-replacement-failure.png')}).catch(()=>{});throw error}finally{await save()}
  }});
 }finally{
  await model?.close();await billing?.close();if(model)await writeFile(join(workspace,'lsp-model-calls.json'),JSON.stringify(model.calls));if(billing)await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state));
  await writeFile(join(workspace,'profile-after.json'),JSON.stringify({configSha256:sha(await readFile(configPath)),settingsSha256:sha(await readFile(settingsPath))}));await writeFile(configPath,configBefore);await writeFile(settingsPath,settingsBefore);await writeFile(join(workspace,'profile-restoration.json'),JSON.stringify({restored:true,configSha256:sha(await readFile(configPath)),settingsSha256:sha(await readFile(settingsPath))}));
 }
}
