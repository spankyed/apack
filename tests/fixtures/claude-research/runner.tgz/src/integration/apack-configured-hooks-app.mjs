import assert from 'node:assert/strict';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const model=await startSyntheticModel(workspace),hooks=[];
const server=http.createServer((req,res)=>{(async()=>{
 let text='';for await(const chunk of req){text+=chunk;if(text.length>65536)throw Error('Oversize hook input')}
 hooks.push({headers:req.headers,input:JSON.parse(text)});res.writeHead(200,{'content-type':'application/json'});res.end('{}');
})().catch(()=>{res.writeHead(400);res.end('{}')})});
server.requestTimeout=8000;await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
const hookUrl=`http://127.0.0.1:${server.address().port}/hook`;
const hashes=async()=>Object.fromEntries(await Promise.all(['actions.content.json','flows.content.json'].map(async name=>[name,hash(await readFile(join(checkout,'packages/default-setup/dist/runtime/content',name)))])));
const before=await hashes();let child,exited=false,deadline,escalation;
try{
 child=spawn(process.execPath,[join(checkout,'node_modules/vitest/vitest.mjs'),'run','tests/features/code/be/services/claude-code/native-configured-hooks-app.spec.ts','--pool=threads','--maxWorkers=1','--minWorkers=1','--no-file-parallelism'],{cwd:join(checkout,'packages/default-setup'),env:{...process.env,CLAUDE_RESEARCH_EXECUTABLE:executable,CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_MODEL_URL:model.url,CLAUDE_RESEARCH_HOOK_URL:hookUrl},stdio:['ignore','pipe','pipe']});
 child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);
 deadline=setTimeout(()=>{child.kill('SIGTERM');escalation=setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000)},50000);
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',code=>{exited=true;resolve(code)})});
 assert.equal(code,0,'Configured native hook app test failed');assert.deepEqual(await hashes(),before);
 assert.equal(hooks.length,1);assert.equal(hooks[0].input.hook_event_name,'PreToolUse');assert.equal(hooks[0].input.tool_name,'Bash');
 assert.equal(hooks[0].headers['x-allowed'],'allowed-fixture');assert.equal(hooks[0].headers['x-unlisted'],'');
 assert.equal(model.calls.length,6);
 const evidence=JSON.parse(await readFile(join(workspace,'configured-hooks-app-evidence.json'),'utf8'));
 console.log(JSON.stringify({evidence:'apack-native-configured-hooks-app',...evidence,httpHookCalls:1,httpAllowedEnvInterpolated:true,httpUnlistedEnvSuppressed:true,targetSha256:hash(await readFile(executable)),compiledContentHashes:before,syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{
 clearTimeout(deadline);clearTimeout(escalation);if(child&&!exited){child.kill('SIGTERM');setTimeout(()=>{if(!exited)child.kill('SIGKILL')},1000).unref()}
 await writeFile(join(workspace,'configured-http-hook-capture.json'),JSON.stringify(hooks,null,2));
 console.log(JSON.stringify({diagnostic:'configured-hook-calls',hooks,calls:model.calls}));server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await model.close();
}
