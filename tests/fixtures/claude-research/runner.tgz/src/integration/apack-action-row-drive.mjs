import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {prepareActionRowProfile} from './action-row-profile.mjs';

/** An original-installed plugin exercising a small everyday desktop action row. */
export async function driveActionRow(options){
 const profile=await prepareActionRowProfile(options);
 try{await driveChildComposer({...options,journey:actionRowJourney,journeyName:'action-row'});}
 finally{await profile.restore();}
}
async function actionRowJourney({app,page,output,project,userDataDir,expect,phase}){
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(m=>m.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await app.navigate('host/settings');
 await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});a.send({type:'TAB.SELECT',tab:'features'});});
 await expect(page.locator('#claude-profile')).toHaveValue('app');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.tabs.every(t=>c.tabsRead.includes(t.id));}),{timeout:15000}).toBe(true);
 await page.evaluate(project=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'VIEW_DASHBOARD'});a.send({type:'NEW_THREAD_IN_PROJECT',directory:project});},project);
 await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.pendingThreadCwd)).toBe(project);
 await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:Object.values(c.nativeUiViews).filter(v=>v.threadId===c.currentThread?.id)};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true});
 const seed='Help me review the release notes.',draft='Review the release notes.';
 await composer.fill(seed);await send.click();await expect.poll(async()=>typeof(await context()).claude?.model,{timeout:30000}).toBe('string');await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),proof={status:'running',sessionId:initial.claude.sessionId,nativePid:initial.native.state.nativePid,geometry:[],captures:[],scope:'Original-installed AbovePrompt button row, graphical default spacing and native prompt callbacks at two sizes; no general parity claim.'};
 const save=()=>writeFile(join(output,'action-row.json'),JSON.stringify(proof,null,2));await save();
 try{
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  const add=card.getByRole('button',{name:'Add checklist',exact:true}),restore=card.getByRole('button',{name:'Restore wording',exact:true});
  if(!await add.isVisible())await card.getByRole('button',{name:'Session tools',exact:true}).click();
  await expect(add).toBeVisible({timeout:15000});await composer.fill(draft);
  for(const[name,size]of[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await page.setViewportSize(size);for(const c of[add,restore,composer,send])await expect(c).toBeInViewport({ratio:1});
   const bounds=await add.evaluate(button=>{const row=button.parentElement,buttons=[...row.children].filter(e=>e.tagName==='BUTTON'),rect=e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height}};return{gap:getComputedStyle(row).gap,rootFontSize:getComputedStyle(document.documentElement).fontSize,buttons:buttons.map(rect),row:rect(row)}});
   assert.equal(bounds.buttons.length,2);const actual=bounds.buttons[1].x-bounds.buttons[0].x-bounds.buttons[0].width,expected=parseFloat(bounds.rootFontSize)*.25;assert.ok(Math.abs(actual-expected)<1,'Native button separation must equal xs');proof.geometry.push({name,...size,...bounds,actual,expected});
   await add.click();await expect(composer).toHaveText(draft+'\nCheck migration notes.');await restore.click();await expect(composer).toHaveText(draft);assert.equal((await context()).claude.sessionId,proof.sessionId);assert.equal((await context()).claude.turns,1);
   const file='action-row-'+name+'.png';await page.screenshot({path:join(output,file)});proof.captures.push(file);await save();phase('action-row-'+name);
  }
  proof.effects=JSON.parse(await readFile(join(project,'native-action-row-effects.json'),'utf8'));assert.deepEqual(proof.effects.map(e=>e.action),['add','restore','add','restore']);for(const e of proof.effects){assert.equal(e.surface,'desktop');assert.equal(e.before.text,e.action==='add'?draft:draft+'\nCheck migration notes.');assert.equal(e.after.text,e.action==='add'?draft+'\nCheck migration notes.':draft)}
  proof.draws=JSON.parse(await readFile(join(project,'native-action-row-draws.json'),'utf8'));assert.ok(proof.draws.length>0);assert.ok(proof.draws.every(d=>d.surface==='desktop'&&d.component==='AbovePrompt'&&!d.explicitGap));
  await send.click();await expect(composer).toHaveText('');await expect.poll(async()=>(await context()).native.state.busy,{timeout:15000}).toBe(false);
  const root=join(userDataDir,'claude-code-profile/config/projects');await expect.poll(async()=>{const names=await readdir(root,{recursive:true}),path=names.find(p=>basename(p)===proof.sessionId+'.jsonl');if(!path)return false;const lines=(await readFile(join(root,path),'utf8')).split('\n').filter(Boolean).map(JSON.parse);const user=lines.filter(r=>r.type==='user'&&!r.isMeta).map(r=>r.message?.content);return user.some(c=>c===draft||Array.isArray(c)&&c.some(b=>b.type==='text'&&b.text===draft));},{timeout:15000}).toBe(true);
  const names=await readdir(root,{recursive:true}),path=names.find(p=>basename(p)===proof.sessionId+'.jsonl');await writeFile(join(output,'native-transcript.jsonl'),await readFile(join(root,path)));proof.final=await context();assert.equal(proof.final.claude.sessionId,proof.sessionId);assert.equal(proof.final.native.state.nativePid,proof.nativePid);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();
  await expect.poll(async()=>{try{const stat=await readFile('/proc/'+proof.nativePid+'/stat','utf8');return stat.slice(stat.lastIndexOf(')')+2).split(' ')[0]==='Z';}catch(error){if(error.code==='ENOENT')return true;throw error}},{timeout:15000}).toBe(true);
  proof.nativeWriterRetired=true;proof.status='complete';await save();phase('action-row-complete');
 }finally{await save();}
}
