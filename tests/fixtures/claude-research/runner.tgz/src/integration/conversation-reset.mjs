import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,realpath,stat,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createRun,hash} from '../artifacts/runs.mjs';
import {record} from '../protocol/record.mjs';

/** Pin-specific observed identity ordering; never equate conversation and resume-session IDs. */
export function verifyConversationReset(evidence){
 for(const key of ['firstSessionId','nextSessionId','resetSessionId','newConversationId','clearInputId'])assert.ok(typeof evidence[key]==='string'&&evidence[key].length>0,`missing ${key}`);
 assert.equal(evidence.resetSessionId,evidence.firstSessionId);
 assert.notEqual(evidence.nextSessionId,evidence.firstSessionId);
 assert.notEqual(evidence.newConversationId,evidence.firstSessionId);
 assert.notEqual(evidence.newConversationId,evidence.nextSessionId);
 assert.equal(evidence.clearResults,1);assert.equal(evidence.closed,true);
 assert.equal(evidence.inferenceRequests,2);assert.equal(evidence.realModelRequests,0);
 if(evidence.owner){
  assert.equal(evidence.turns.length,3);assert.equal(evidence.turns[1].totalCostUsd,0);
  assert.equal(evidence.costAccountingMatches,true,'owner undercounted native cost after reset');
  assert.ok(Math.abs(evidence.expectedCost-evidence.chargedCost)<1e-12);
 }
 const reset=evidence.events.findIndex(event=>event.type==='conversation_reset');
 const initialized=evidence.events.findIndex((event,index)=>index>reset&&event.type==='system'&&event.subtype==='init'&&event.sessionId===evidence.nextSessionId);
 const result=evidence.events.findIndex(event=>event.type==='result'&&event.inputId===evidence.clearInputId);
 assert.ok(reset>=0&&initialized>reset&&result>initialized,'new session init must follow reset and precede clear result');
}

export async function probeConversationReset(checkout,executable,root,output,{mode='raw'}={}){
 assert.ok(['raw','owner','compiled'].includes(mode));
 checkout=await realpath(checkout);assert.ok((await stat(join(checkout,'.git'))).isFile(),'Use the isolated linked worktree');
 assert.equal(await realpath(join(checkout,'node_modules')),join(checkout,'node_modules'),'Do not share node_modules');
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'conversation-reset-'));
 const driver=fileURLToPath(new URL('./conversation-reset-driver.mjs',import.meta.url)),sourceHashes={};
 for(const name of ['conversation.ts','query.ts','runner.ts','types.ts','args.ts','control.ts','host-controls.ts'])sourceHashes[name]=hash(await readFile(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code',name)));
 const sourceRoot=join(checkout,'packages/default-setup');
 const extraHashes={};
 if(mode==='compiled')for(const name of ['tests/content/actions/claude-code/reset-chat-native.spec.ts','src/content/actions/claude-code/_helpers/stream-consumer.ts','src/content/actions/claude-code/turn-completed.ts'])extraHashes[name]=hash(await readFile(join(sourceRoot,name)));
 const compiledHashes={};
 if(mode==='compiled')for(const name of ['runtime/index.cjs','runtime/content/actions.content.json','runtime/content/flows.content.json'])compiledHashes[name]=hash(await readFile(join(sourceRoot,'dist',name)));
 const run=await createRun(output,'apack-conversation-reset',{mode,extraHashes,compiledHashes,targetSha256:hash(await readFile(executable)),productCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:checkout,encoding:'utf8'}).trim(),sourceHashes,driverSha256:hash(await readFile(driver)),orchestratorSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('../protocol/synthetic-model.mjs',import.meta.url)))});
 let transport;
 try{
  transport=await record({executable:process.execPath,cwd:checkout,args:['--import',join(checkout,'node_modules/tsx/dist/loader.mjs'),driver,checkout,executable,workspace,mode],env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},output,timeoutMs:30000,maxBytes:1024*1024});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);
  const lines=(await readFile(join(transport.directory,'stdout.bin'),'utf8')).split('\n').filter(line=>line.startsWith('{')).map(line=>JSON.parse(line));
  const evidence=lines.find(line=>line.evidence==='apack-native-conversation-reset');assert.ok(evidence);verifyConversationReset(evidence);
  for(const[name,digest]of Object.entries(sourceHashes))assert.equal(hash(await readFile(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code',name))),digest);
  if(mode==='compiled'){assert.equal(evidence.compiledFlow,true);assert.equal(evidence.sameOwner,true);assert.equal(evidence.appMessagesPreserved,true);}
  for(const[name,digest]of Object.entries(extraHashes))assert.equal(hash(await readFile(join(sourceRoot,name))),digest);
  for(const[name,digest]of Object.entries(compiledHashes))assert.equal(hash(await readFile(join(sourceRoot,'dist',name))),digest);
  const data=JSON.stringify(evidence,null,2)+'\n';await writeFile(join(run.directory,'conversation-reset.json'),data);await run.finish({status:'complete',transportRun:transport.directory,outputSha256:hash(Buffer.from(data))});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',transportRun:transport?.directory,error:error.message});throw error;}
}
