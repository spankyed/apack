import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
const [checkout,executable,workspace]=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {query}=await import(pathToFileURL(join(base,'query.ts')).href);
const model=await startSyntheticAgentModel();let native;const events=[],results=[],pending=[],childDeliveredAtResults=[];let first,second;
try{
 native=await query({cliPath:executable,cwd:workspace,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:undefined,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},permissionMode:'acceptEdits',tools:['Agent'],allowedTools:['Agent'],agents:{'status-fixture':{description:'Disposable local status worker',prompt:'NativeStatusChildSystem. Return the requested fixed worker marker without tools.',tools:[],maxTurns:1}},settingSources:[],strictMcpConfig:true,replayUserMessages:true,keepStdinOpen:true,signal:AbortSignal.timeout(25000),settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})});

 await native.initialized;
 first=native.send('NativeSubagentParentFixture: Run the disposable status worker.');
 for await(const event of native.events){
  events.push(event);
  if(event.type!=='result')continue;
  results.push(event);pending.push(native.hasPendingBackgroundTasks(event));childDeliveredAtResults.push(model.calls.some(call=>call.child&&call.delivered));
  if(results.length===1){assert.equal(event.user_message_uuid,first);assert.equal(pending[0],true);assert.equal(childDeliveredAtResults[0],false);second=native.send('Synthetic second host input while the agent is running.');}
  else if(results.length===3)break;
 }
 assert.equal(results.length,3);assert.equal(results[1].user_message_uuid,second);assert.equal(childDeliveredAtResults[1],false);
 assert.equal(results[2].user_message_uuid,undefined);assert.equal(childDeliveredAtResults[2],true);assert.deepEqual(pending,[true,true,false]);
 assert.ok(results.every(result=>result.subtype==='success'));
 const lifecycle=events.filter(event=>event.type==='command_lifecycle').map(event=>({id:event.command_uuid,state:event.state}));
 for(const id of [first,second])assert.ok(lifecycle.some(event=>event.id===id&&event.state==='started'));
 assert.equal(model.calls.filter(call=>call.response==='Agent').length,1);assert.equal(model.calls.filter(call=>call.child&&call.delivered).length,1);
 await native.close();
 console.log(JSON.stringify({evidence:'apack-native-agent-overlap',targetSha256:hash(await readFile(executable)),hostInputs:2,secondInputBeforeChildCompleted:true,secondResultBeforeChildCompleted:true,pendingAtResults:pending,resultInputIds:results.map(result=>result.user_message_uuid??null),lifecycle,costs:results.map(result=>result.total_cost_usd),childCompleted:true,syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{
 await writeFile(join(workspace,'native-agent-overlap-events.json'),JSON.stringify(events,null,2));await writeFile(join(workspace,'synthetic-agent-requests.json'),JSON.stringify(model.requests,null,2));
 console.log(JSON.stringify({diagnostic:'agent-overlap',pending,childDeliveredAtResults,calls:model.calls}));
 try{if(native){native.kill();await native.close().catch(()=>{})}}finally{await model.close()}
}
