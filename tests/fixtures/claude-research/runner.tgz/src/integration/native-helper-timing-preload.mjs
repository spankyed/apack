import assert from 'node:assert/strict';
import {readFileSync,statSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {isMainThread} from 'node:worker_threads';
import {observeNativeHelperTiming} from './native-helper-timing.mjs';
const directory=process.env.CLAUDE_RESEARCH_HELPER_TIMING;
const apiProcess=process.argv.some(arg=>arg==='dist/server.js'||arg.endsWith('/dist/server.js'));
// Electron and Node loader workers can evaluate NODE_OPTIONS imports in several realms of one PID.
// The API main thread alone owns these HTTP servers; other realms must neither patch nor write.
if(directory&&isMainThread&&apiProcess){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.match(directory,/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+\/helper-timing$/);
 const boundary=JSON.parse(readFileSync('/control/offline-verified','utf8'));
 assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
 const stat=statSync(directory);assert.equal(stat.uid,process.getuid());assert.equal(stat.mode&0o077,0);
 const registrationDelayMs=Number(process.env.CLAUDE_RESEARCH_HELPER_REGISTRATION_DELAY_MS??0);assert.ok(Number.isSafeInteger(registrationDelayMs)&&registrationDelayMs>=0&&registrationDelayMs<=1000);
 if(process.env.CLAUDE_RESEARCH_HELPER_ERRORS==='1'){
  const {Session}=await import('node:inspector'),{observeNativeHelperErrors}=await import('./native-helper-errors.mjs');
  const session=new Session();let errors=0;
  await observeNativeHelperErrors(session,value=>writeFileSync(join(directory,'caught-'+process.pid+'-'+(++errors)+'.json'),JSON.stringify(value),{mode:0o600,flag:'wx'}));
  process.once('exit',()=>{try{session.disconnect()}catch{}});
 }
 writeFileSync(join(directory,'observer-ready-'+process.pid+'.json'),JSON.stringify({phase:'observer-ready',apiProcess,registrationDelayMs,observerPid:process.pid,monotonicNs:process.hrtime.bigint().toString()}),{mode:0o600,flag:'wx'});
 let count=0;
 observeNativeHelperTiming(value=>{assert.ok(++count<=256,'Helper timing trace exceeded its bound');writeFileSync(join(directory,process.pid+'-'+count+'.json'),JSON.stringify({...value,observerPid:process.pid}),{mode:0o600,flag:'wx'})},undefined,{registrationDelayMs});
}
