import assert from 'node:assert/strict';
import{readFile,realpath}from'node:fs/promises';
import{join,resolve}from'node:path';
import{pathToFileURL}from'node:url';
import{hash}from'../artifacts/runs.mjs';
import{startSyntheticModel}from'../protocol/synthetic-model.mjs';
const[checkoutArg,executableArg,workspaceArg]=process.argv.slice(2);
const checkout=await realpath(checkoutArg),executable=resolve(executableArg),workspace=resolve(workspaceArg);
assert.notEqual(checkout,await realpath('/Users/spankyed/Develop/Projects/AgentBuddy'));
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const{query}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')));
const{createClaudeConversation}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/conversation.ts')));
const target=new Date(Date.now()+65000);
const cronExpression=`${target.getUTCMinutes()} ${target.getUTCHours()} ${target.getUTCDate()} ${target.getUTCMonth()+1} *`;
const model=await startSyntheticModel(workspace,'CronFire',{cronExpression});
let handle,owner;const ownedTurns=[];
try{
 handle=await query({cliPath:executable,cwd:workspace,env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),
  CLAUDE_CODE_SIMPLE:undefined,CLAUDE_CODE_COORDINATOR_MODE:undefined,TZ:'UTC',ANTHROPIC_BASE_URL:model.url,ENABLE_TOOL_SEARCH:'0',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
  tools:['CronCreate','CronList'],strictMcpConfig:true,settingSources:[],noSessionPersistence:true,permissionMode:'acceptEdits',model:'default',keepStdinOpen:true,surfaceControlRequests:true,replayUserMessages:true,maxTurns:6,
  settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),signal:AbortSignal.timeout(115000),
  onPermissionRequest:async request=>{assert.ok(['CronCreate','CronList'].includes(request.tool_name));return{behavior:'allow',updatedInput:request.input}}});
 const initialized=await handle.initialized;assert.equal(initialized.current_permission_mode,'acceptEdits');
 const pendingAtResults=[],sessionIds=[],jobs=[];
 const consume=async turn=>{ownedTurns.push({inputId:turn.inputId,costBaseline:turn.costBaseline});for await(const event of turn.handle.events){
  console.log(JSON.stringify({diagnostic:'native-event',event}));
  if(event.type==='system'&&event.subtype==='init')for(const name of ['CronCreate','CronList'])assert.ok(event.tools.includes(name),`Required native tool unavailable: ${name}`);
  if(event.type==='control_request'){assert.equal(event.request.subtype,'can_use_tool');assert.ok(['CronCreate','CronList'].includes(event.request.tool_name));handle.respond(event.request_id,{behavior:'allow',updatedInput:event.request.input});}
  if(event.type==='user'&&event.tool_use_result?.jobs)jobs.push(event.tool_use_result.jobs);
  if(event.type==='result'){
   assert.equal(event.subtype,'success');pendingAtResults.push(handle.hasPendingBackgroundTasks(event));sessionIds.push(event.session_id);

  }
 }
 owner.release(turn.handle);};
 owner=createClaudeConversation(handle,consume);
 owner.start('Create the disposable one-shot scheduling fixture and wait for its native scheduled prompt.',consume);
 await new Promise((resolve,reject)=>{const timer=setInterval(()=>{if(pendingAtResults.length===2&&!owner.busy){clearInterval(timer);clearTimeout(deadline);resolve()}},10);const deadline=setTimeout(()=>{clearInterval(timer);reject(Error('Scheduled owned turn did not complete'))},110000)});
 await owner.close();
 assert.deepEqual(pendingAtResults,[false,false]);assert.equal(sessionIds[0],sessionIds[1]);assert.deepEqual(jobs.at(-1),[]);
 assert.equal(ownedTurns.length,2);assert.ok(ownedTurns[0].inputId);assert.equal(ownedTurns[1].inputId,undefined);assert.equal(ownedTurns[0].costBaseline,0);assert.ok(ownedTurns[1].costBaseline>0);
 assert.equal(model.calls.length,4);assert.equal(model.calls.filter(call=>call.scheduledPromptInLatestUser).length,1);
 console.log(JSON.stringify({evidence:'apack-native-owner-cron',targetSha256:hash(await readFile(executable)),ownedTurns,hostTurnCount:1,autonomousTurnCount:1,idleProcessRetained:true,pendingAtResults,sameSession:sessionIds[0]===sessionIds[1],
  autoDeleted:true,permissionMode:initialized.current_permission_mode,coordinatorMode:false,replayUserMessages:true,syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{console.log(JSON.stringify({diagnostic:'synthetic-calls',calls:model.calls}));if(owner)owner.kill();if(handle){handle.kill();await handle.close().catch(()=>{})}await model.close()}
