import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {randomUUID} from 'node:crypto';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
const [checkout,executable,workspace,kind='agent-stop']=process.argv.slice(2);
assert.equal(process.env.HOME,workspace);assert.ok(['agent-stop','agent-exit'].includes(kind));
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const base=join(checkout,'packages/default-setup/src/features/code/be/services/claude-code');
const {spawnStream}=await import(pathToFileURL(join(base,'runner.ts')).href);
const {argsFromOptions}=await import(pathToFileURL(join(base,'args.ts')).href);
const {createHostControls}=await import(pathToFileURL(join(base,'host-controls.ts')).href);
const model=await startSyntheticAgentModel();let stream,controls,pump;const events=[];
const wait=async(predicate,label)=>{const deadline=Date.now()+8000;while(!predicate()){if(Date.now()>deadline)throw Error('Timed out: '+label);await new Promise(resolve=>setTimeout(resolve,10))}};
try{
 const args=argsFromOptions({permissionMode:'acceptEdits',tools:['Agent'],allowedTools:['Agent'],agents:{'status-fixture':{description:'Disposable local status worker',prompt:'NativeStatusChildSystem. Return the requested fixed worker marker without tools.',tools:[],maxTurns:1}},settingSources:[],strictMcpConfig:true,replayUserMessages:true,keepStdinOpen:true,settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})});
 stream=await spawnStream(args,{cliPath:executable,cwd:workspace,env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_SIMPLE:undefined,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},signal:AbortSignal.timeout(18000)});
 controls=createHostControls(value=>stream.write(value));
 pump=(async()=>{try{for await(const line of stream.lines){assert.equal(line.ok,true);const event=line.value;events.push(event);if(event.type==='control_response')controls.receive(event);else if(event.type==='control_request')throw Error('Unexpected permission in allowlisted fixture')}}finally{controls.close(new Error('Owned native process exited'))}})();pump.catch(()=>{});
 await controls.request({subtype:'initialize',hooks:{}});
 stream.write({type:'user',uuid:randomUUID(),message:{role:'user',content:'NativeSubagentParentFixture: Run the disposable status worker.'},parent_tool_use_id:null});
 await wait(()=>events.some(event=>event.type==='result')&&model.calls.some(call=>call.child&&!call.delivered),'active background child');
 const task=events.find(event=>event.type==='system'&&event.subtype==='task_started'&&event.task_type==='local_agent');assert.ok(task);
 let missingTaskReceipt,stopReceipt,repeatReceipt;
 if(kind==='agent-stop'){
  missingTaskReceipt=await controls.request({subtype:'stop_task',task_id:'unknown-research-task'});
  assert.equal(model.calls.some(call=>call.child&&call.delivered),false);
  stopReceipt=await controls.request({subtype:'stop_task',task_id:task.task_id});
  repeatReceipt=await controls.request({subtype:'stop_task',task_id:task.task_id});
  stream.endInput();
 }else stream.kill();
 const exit=await stream.done();await pump;
 await assert.rejects(()=>controls.request({subtype:'stop_task',task_id:task.task_id}),/exited/);
 assert.equal(stream.write({type:'user',message:{role:'user',content:'Late input'}}),false);
 assert.equal(model.calls.some(call=>call.child&&call.delivered),false);
 const terminalTasks=events.filter(event=>event.type==='system'&&event.subtype==='task_notification');
 if(kind==='agent-stop'){assert.deepEqual(stopReceipt,{});assert.deepEqual(repeatReceipt,{});assert.deepEqual(missingTaskReceipt,{});assert.equal(exit.exitCode,0);assert.ok(terminalTasks.some(event=>event.task_id===task.task_id&&event.status==='stopped'));}
 console.log(JSON.stringify({evidence:`apack-native-${kind}`,targetSha256:hash(await readFile(executable)),hostInputs:1,childWasRunning:true,childSuccessNotDelivered:true,taskId:task.task_id,missingTaskReceipt,stopReceipt,repeatReceipt,terminalTasks,exit,controlsRejectedAfterExit:true,lateInputRejected:true,streamDrained:true,syntheticApiRequests:model.calls.length,realModelRequests:0}));
}finally{
 await writeFile(join(workspace,`${kind}-events.json`),JSON.stringify(events,null,2));await writeFile(join(workspace,`${kind}-requests.json`),JSON.stringify(model.requests,null,2));
 console.log(JSON.stringify({diagnostic:kind,calls:model.calls}));
 try{if(stream){stream.kill();await stream.done().catch(()=>{});await pump?.catch(()=>{})}}finally{controls?.close();await model.close()}
}
