import {mkdtemp,mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,dirname,isAbsolute} from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {hash} from '../artifacts/runs.mjs';
const execute=promisify(execFile);
function safePath(path){return typeof path==='string'&&path.length>0&&!isAbsolute(path)&&!path.includes('\\')&&path.split('/').every(p=>p!==''&&p!=='.'&&p!=='..');}
async function pathsAt(root,prefix=''){
 const paths=[];
 for(const item of await readdir(join(root,prefix),{withFileTypes:true})){
  const path=prefix?`${prefix}/${item.name}`:item.name;
  if(item.isDirectory())paths.push(...await pathsAt(root,path));
  else if(item.isFile())paths.push(path);
  else throw Error('Unexpected nonregular patched path: '+path);
 }
 return paths.sort();
}
/** Own-copy verification only. Preserve the directory on success/failure; never apply in a real checkout. */
export async function verifyPatchFiles(patch,files,{temporaryParent=tmpdir()}={}){
 if(!Array.isArray(files)||!files.length)throw Error('Expected a nonempty file manifest');
 const names=new Set();
 for(const file of files){
  if(!safePath(file.path)||names.has(file.path))throw Error('Unsafe or duplicate patch path');
  names.add(file.path);
  for(const side of ['before','after'])if(file[side]!==null&&!(file[side] instanceof Uint8Array))throw Error('Expected bytes or explicit null for '+side);
 }
 const directory=await mkdtemp(join(temporaryParent,'claude-patch-review-')),source=join(directory,'source');await mkdir(source);
 try{
  let enclosingRepo;
  try{enclosingRepo=await execute('git',['rev-parse','--show-toplevel'],{cwd:source,timeout:5000,maxBuffer:4096});}catch(error){if(error.code!==128)throw error;}
  if(enclosingRepo)throw Error('Review copy must be outside a Git repository to avoid silently skipped patches');
  for(const file of files)if(file.before!==null){const path=join(source,file.path);await mkdir(dirname(path),{recursive:true});await writeFile(path,file.before);}
  const patchPath=join(directory,'review.patch');await writeFile(patchPath,patch);
  for(const args of [['apply','--check',patchPath],['apply',patchPath]])await execute('git',args,{cwd:source,timeout:10000,maxBuffer:1024*1024});
  const expected=files.filter(f=>f.after!==null).map(f=>f.path).sort(),actual=await pathsAt(source);
  if(JSON.stringify(actual)!==JSON.stringify(expected))throw Error('Patched file set differs from manifest');
  const checks=[];
  for(const file of files){const actual=file.after===null?null:await readFile(join(source,file.path));
   if(actual!==null&&!actual.equals(Buffer.from(file.after)))throw Error('Patched bytes differ: '+file.path);
   checks.push({path:file.path,beforeSha256:file.before===null?null:hash(file.before),afterSha256:actual===null?null:hash(actual)});
  }
  return {directory,source,patchSha256:hash(patch),files:checks};
 }catch(error){error.reviewDirectory=directory;throw error;}
}
