import {writeNativeNotebookFixture,notebookBefore,notebookAfter,notebookInserted,notebookNotes} from '../protocol/native-notebook-edit-fixture.mjs';
import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {driveChildComposer} from './apack-child-composer-drive.mjs';

export function driveChildNotebook(options) {
 return driveChildComposer({...options,modelTool:'TextOnly',modelOptions:{childNotebookScenario:true},modelRequestLimit:24,journey:notebookJourney,askBeforeNotebookEdit:true,journeyName:'notebook'});
}
export function driveChildNotebookDelete(options) {
 return driveChildComposer({...options,modelTool:'TextOnly',modelOptions:{childNotebookScenario:true},modelRequestLimit:16,journey:args=>notebookJourney({...args,approveDeleteOnly:true}),askBeforeNotebookEdit:true,journeyName:'notebook-delete'});
}
async function notebookJourney({app,page,output,workspace,project,userDataDir,env,expect,phase,model,approveDeleteOnly=false}) {
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 // CHAT_STARTED restores the selected thread after the surface actor exists.
 // Wait for that real startup fact before issuing a new-chat interaction.
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));
 await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const actor=window.applicationState.system.get('default-setup/threads');actor.send({type:'SET_MODE',mode:'Claude Code'});actor.send({type:'SET_PHASE',phase:'Edit'});});
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return [c.mode,c.phase];})).toEqual(['Claude Code','Edit']);
 phase('new-thread-ready');
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:c.nativeUiViews};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');
 await composer.fill('Review the release notes and outline the next steps.');await card.getByRole('button',{name:'Send',exact:true}).click();
 await expect.poll(async()=>(await context()).claude?.turns,{timeout:25000}).toBe(1);
 phase('seed-complete');
 const section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();
 await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');
 const initial=await context(),parentSessionId=initial.claude.sessionId;phase('native-parent-ready');

 await writeNativeNotebookFixture(workspace);
 const notebookPath=join(workspace,'release-review.ipynb');
 const proof={status:'running',parentSessionId,scope:approveDeleteOnly?'Original child Read and approved notebook delete only; prior replace/insert/denied-delete scopes preserved.':'Original child Read, NotebookEdit replace/insert and denied delete; broader permissions and full parity remain open.',captures:[],sizes:[]};
 const save=()=>writeFile(join(output,'child-notebook.json'),JSON.stringify(proof,null,2));
 const hasResult=stage=>model.calls.flatMap(call=>call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]).find(block=>block.type==='tool_result'&&block.tool_use_id===['native_notebook_read','native_notebook_replace','native_notebook_insert','native_notebook_delete','native_notebook_delete_approved'][stage]);
 const result=async(stage,error)=>{await expect.poll(()=>hasResult(stage),{timeout:15000}).toBeTruthy();const value=hasResult(stage);assert.equal(value.is_error===true,error);proof['result'+stage]=value;await save();};
 const capture=async(name)=>{await page.screenshot({path:join(output,name+'.png')});proof.captures.push(name+'.png');await save();};
 const sizes=[['normal',{width:1100,height:900}],['compact',{width:680,height:600}]];
 try {
  await section.getByRole('button',{name:'Back to conversation',exact:true}).click();
  await composer.fill(approveDeleteOnly?'/background ResearchChildNotebook4 Read the notebook and delete its original notes cell.':'/background ResearchChildNotebook1 Read the notebook and review its analysis cell replacement.');await card.getByRole('button',{name:'Send',exact:true}).click();
  const widget=page.getByRole('region',{name:'Background Claude session',exact:true});
  await expect(widget.getByRole('button',{name:'Review request',exact:true})).toBeEnabled({timeout:25000});
  proof.running=await context();proof.target=proof.running.native.background.desktop;assert.ok(proof.target);proof.discoveredWithReplyClosed=true;
  await composer.fill('Keep the parent notebook review notes here.');const parentDraft=await composer.textContent();
  const approval=widget.getByRole('region',{name:'NotebookEdit approval',exact:true});await expect(approval).toHaveCount(0);
  await widget.getByRole('button',{name:'Review request',exact:true}).click();await expect(approval).toBeVisible({timeout:15000});
  const currentApproval=async()=>{const c=await context(),pair=Object.entries(c.ui).find(([,v])=>v.state?.approval?.control?.dialog?.sessionId===proof.target.sessionId);assert.ok(pair);return{mountId:pair[0],frame:pair[1].state.approval};};
  const source=cell=>Array.isArray(cell.source)?cell.source.join(''):cell.source;
  proof.previews=[];proof.notebooks=[];proof.previewReading=[];
  for(const stage of (approveDeleteOnly?[4]:[1,2,3])){
   if(stage>1&&!approveDeleteOnly){const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');await expect(editor).toBeEditable();await editor.fill('ResearchChildNotebook'+stage+(stage===2?' Insert a markdown release summary.':' Review deleting the original notes cell.'));await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(approval).toBeVisible({timeout:15000});}
   const frame=await currentApproval();proof.previews.push(frame);
   if(!proof.firstApproval)proof.firstApproval=frame;
   else{await page.evaluate(({threadId,mountId,frameId})=>window.applicationState.system.get('default-setup/threads').send({type:'CLAUDE_UI_APPROVAL_ANSWER',threadId,mountId,frameId,answer:{approved:false}}),{threadId:proof.running.threadId,mountId:frame.mountId,frameId:proof.firstApproval.frame.id});await expect(approval.getByRole('button',{name:stage===3?'Deny':'Allow once',exact:true})).toBeEnabled();proof.oldDenialReplayed=true;}
   const operation=approval.locator('[data-testid="native-notebook-operation"]');await expect(operation).toContainText(stage===1?'Replace cell':stage===2?'Insert cell':'Delete cell');await expect(operation).toContainText(stage>=3?'notes':'analysis');
   for(const[name,size]of sizes){await page.setViewportSize(size);const details=approval.locator('.details');await details.hover();await page.mouse.wheel(0,-800);await expect(operation).toBeInViewport({ratio:1});const preview=approval.locator(stage>=3?'[data-testid="native-file-before"]':'[data-testid="native-file-after"]');await expect(preview).toHaveText(stage===1?notebookAfter:stage===2?notebookInserted:notebookNotes);const wheelDelta=await preview.evaluate(element=>{const r=element.getBoundingClientRect(),d=element.closest('.details').getBoundingClientRect();return Math.round(r.top+r.height/2-d.top-d.height/2)});await details.hover();await page.mouse.wheel(0,wheelDelta);await expect(preview).toBeInViewport({ratio:1});proof.previewReading.push({stage,name,wheelDelta,...await details.evaluate(element=>({scrollTop:element.scrollTop,clientHeight:element.clientHeight,scrollHeight:element.scrollHeight}))});await expect(approval.getByRole('button',{name:stage===3?'Deny':'Allow once',exact:true})).toBeInViewport({ratio:1});await capture('child-notebook-'+stage+'-'+name);}
   const before=await readFile(notebookPath);proof.notebooks.push({stage,beforeSha256:createHash('sha256').update(before).digest('hex')});
   if(stage===3){await approval.getByText('Add a reason for denying',{exact:true}).click();await approval.getByRole('textbox',{name:'Reason for denying',exact:true}).fill('Keep the original migration notes.');await approval.getByRole('button',{name:'Back to parent notes',exact:true}).click();await expect(composer).toBeFocused();await expect(composer).toHaveText(parentDraft);await widget.getByRole('button',{name:'Review request',exact:true}).click();await expect(approval.getByRole('textbox',{name:'Reason for denying',exact:true})).toHaveValue('Keep the original migration notes.');proof.denialDraftRetained=true;}
   if(approveDeleteOnly){await approval.getByRole('button',{name:'Back to parent notes',exact:true}).click();await expect(composer).toBeFocused();await expect(composer).toHaveText(parentDraft);await widget.getByRole('button',{name:'Review request',exact:true}).click();await expect(approval).toBeVisible();assert.equal((await currentApproval()).frame.id,frame.frame.id);proof.parentDraftRetained=true;}
   await approval.getByRole('button',{name:stage===3?'Deny':'Allow once',exact:true}).click();await expect(approval).toHaveCount(0);await result(stage,stage===3);
   const after=await readFile(notebookPath),notebook=JSON.parse(after);proof.notebooks.at(-1).afterSha256=createHash('sha256').update(after).digest('hex');
   assert.equal(source(notebook.cells.find(cell=>cell.id==='analysis')),approveDeleteOnly?notebookBefore:notebookAfter);
   if(approveDeleteOnly){assert.equal(notebook.cells.length,1);assert.equal(notebook.cells.some(cell=>cell.id==='notes'),false);proof.approvedDelete=true;}else assert.equal(source(notebook.cells.find(cell=>cell.id==='notes')),notebookNotes);
   if(stage>=2&&!approveDeleteOnly){assert.equal(notebook.cells.length,3);assert.equal(source(notebook.cells[1]),notebookInserted);assert.equal(notebook.cells[1].cell_type,'markdown');}
   if(stage===3){assert.deepEqual(after,before);assert.ok(JSON.stringify(proof.result3).includes('Keep the original migration notes.'));}
  }
  await writeFile(join(output,'release-review-final.ipynb'),await readFile(notebookPath));await result(0,false);
  const form=widget.getByRole('form',{name:'Background session message',exact:true}),editor=form.locator('[contenteditable="true"]');await expect(editor).toBeEditable();await editor.fill('Summarize the approved release check.');
  for(const[name,size]of sizes){await page.setViewportSize(size);await expect(form.getByRole('button',{name:'Send message',exact:true})).toBeInViewport({ratio:1});await capture('child-notebook-composer-'+name);}
  await form.getByRole('button',{name:'Send message',exact:true}).click();await expect(editor).toHaveText('',{timeout:20000});await expect.poll(()=>model.calls.some(call=>call.messages?.some(message=>message.role==='user'&&message.content==='Summarize the approved release check.')),{timeout:15000}).toBe(true);proof.finalReplyObserved=true;
  const projects=join(userDataDir,'claude-code-profile/config/projects');proof.transcripts={};
  for(const kind of ['parent','child']){const sid=kind==='parent'?parentSessionId:proof.target.sessionId;for(const directory of(await readdir(projects,{withFileTypes:true})).slice(0,64)){if(!directory.isDirectory())continue;const path=join(projects,directory.name,sid+'.jsonl');let info;try{info=await lstat(path)}catch(error){if(error.code==='ENOENT')continue;throw error}assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=8*1024*1024);const raw=await readFile(path);assert.ok(raw.length<=8*1024*1024);await writeFile(join(output,'native-'+kind+'-transcript.jsonl'),raw);proof.transcripts[kind]={sessionId:sid,path,sha256:createHash('sha256').update(raw).digest('hex')};break;}assert.ok(proof.transcripts[kind]);}
  await widget.getByRole('button',{name:'Stop background session',exact:true}).click();await expect(widget.locator(':scope > header').getByRole('status')).toHaveText('Last reported: stopped',{timeout:20000});
  const stopped=JSON.parse(await readFile(join(userDataDir,'claude-code-profile/config/jobs',proof.target.jobId,'state.json'),'utf8'));assert.equal(stopped.sessionId,proof.target.sessionId);assert.equal(stopped.state,'stopped');proof.nativeStopped={jobId:proof.target.jobId,sessionId:stopped.sessionId,state:stopped.state};proof.final=await context();proof.status='complete';await save();phase('original-child-notebook-complete');
 } catch(error) {
  proof.status='failed';proof.error=String(error.message).slice(0,4096);proof.failureContext=await context().catch(()=>null);
  await page.screenshot({path:join(output,'child-notebook-failure-before-cleanup.png')}).catch(()=>{});
  await save();throw error;
 } finally {
  const state=await context().catch(()=>null),sessionId=proof.target?.sessionId??state?.claude?.nativeContinuation?.continuedInSessionId;
  if(sessionId){const run=promisify(execFile),cliEnv={...env,CLAUDE_CONFIG_DIR:join(userDataDir,'claude-code-profile/config')};const rows=JSON.parse((await run('/frozen-claude/claude',['agents','--json','--all','--cwd',project],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024})).stdout);const owned=rows.find(row=>row.sessionId===sessionId&&row.cwd===project);if(owned&&owned.state!=='stopped'){await run('/frozen-claude/claude',['stop',owned.id],{cwd:project,env:cliEnv,timeout:20000,maxBuffer:2*1024*1024});proof.cleanupStoppedOwnedJob=true;}}
  await save();
 }
}
