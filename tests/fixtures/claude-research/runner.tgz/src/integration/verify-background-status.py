"""Audit saved background-status app evidence and its original child-reply journey."""
from pathlib import Path
import argparse,json,subprocess,sys
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence',type=Path)
parser.add_argument('product_checkout',type=Path)
parser.add_argument('--commit')
parser.add_argument('--research-commit')
parser.add_argument('--capture-profile',choices=['reply','lifecycle'],default='reply')
args=parser.parse_args()
command=[sys.executable,str(Path(__file__).with_name('verify-background-reply.py')),str(args.evidence),str(args.product_checkout)]
for option,value in [('--commit',args.commit),('--research-commit',args.research_commit)]:
 if value:command.extend([option,value])
command.extend(['--capture-profile',args.capture_profile])
subprocess.run(command,check=True,stdout=subprocess.DEVNULL)
evidence=args.evidence.resolve()
paths=list((evidence/'records/workspaces').glob('*/native-background-app-observation.json'));assert len(paths)==1
state=json.loads(paths[0].read_text());status=state['childStatus'];job=state['job'];assert status['remountPreserved']and status['retiredAfterStop']
for field in ['before','after']:
 info=status[field];assert info['sessionId']==job['sessionId']and info['jobId']==job['id']and info['pid']==job['pid'];assert info['turns']>0
 rows=state['childReply']['rows'];models={row.get('message',{}).get('model')for row in rows if row.get('type')=='assistant'};assert info['model']in models,'Public child model must agree with its native assistant journal'
assert status['after']['observedAt']>status['before']['observedAt']
assert status['parentBefore']['messages']==status['parentAfter']['messages']
assert status['parentBefore']['claude']['totalCostUsd']==status['parentAfter']['claude']['totalCostUsd']
reply=json.loads((evidence/'saved-record-verification.json').read_text())
result={**reply,'backgroundStatus':{'exactChildIdentity':True,'originalModelMatchesChildJournal':True,'freshAfterNavigation':True,'retiredAfterStop':True,'parentHistoryAndCostPreserved':True,'before':status['before'],'after':status['after']},'scope':'Original child status through an independently leased transport, navigation recovery and Stop retirement, alongside accepted two completed text replies. No incremental-child cost reconciliation, custom child statusLine, drawing/actions, policy refusal, broker-loss/restart or full F1–F5 acceptance.'}
(evidence/'background-status-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
