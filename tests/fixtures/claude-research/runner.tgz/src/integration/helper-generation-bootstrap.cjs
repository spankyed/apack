const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
const directory=process.env.CLAUDE_RESEARCH_HELPER_READ_HOLD_DIR;
assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
assert.match(directory,/^\/work\/\.claude-research\/apack-terminal-owner-app-background[0-9]+\/helper-read-hold$/);
const boundary=JSON.parse(fs.readFileSync('/control/offline-verified','utf8'));
assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);assert.equal(boundary.requireHelperGenerationOverlap,true);
// Playwright strips NODE_OPTIONS. Restore only this fixture's API preload through the existing main-bootstrap pattern.
process.env.NODE_OPTIONS=(process.env.CLAUDE_RESEARCH_HELPER_API_NODE_OPTIONS??'')+' --import='+pathToFileURL(path.join(__dirname,'owned-helper-generation-read-hold.mjs')).href;
fs.writeFileSync(path.join(directory,'main-bootstrap.json'),JSON.stringify({pid:process.pid,at:Date.now(),scope:'Owned app bootstrap; API hook must separately confirm activation.'}),{mode:0o600,flag:'wx'});
