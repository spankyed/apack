import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir,readFile,writeFile,lstat,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
import {makeNativePageReviewPdf} from '../protocol/native-read-media-fixture.mjs';
import {observeChildGenericShutdown} from './child-generic-profile.mjs';

/** Observe original MCP PDF normalization through the existing product process transport. */
export async function probeMcpPdfQuery({checkout,executable,workspace}){
 assert.equal(process.platform,'linux');assert.equal(process.arch,'arm64');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));assert.ok(boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
 assert.equal(checkout,'/work');assert.equal(executable,'/frozen-claude/claude');assert.match(workspace,/^\/work\/\.claude-research\/mcp-pdf-query[0-9]+$/);
 const sha=b=>createHash('sha256').update(b).digest('hex');assert.equal(sha(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');assert.equal(existsSync(workspace),false);
 for(const p of [workspace,join(workspace,'home'),join(workspace,'config')])await mkdir(p);
 const config=join(workspace,'mcp.json'),server=fileURLToPath(new URL('../protocol/synthetic-mcp-pdf-server.mjs',import.meta.url)),receipts=join(workspace,'mcp-receipts.jsonl'),exits=join(workspace,'mcp-exits.jsonl');
 await writeFile(config,JSON.stringify({mcpServers:{research:{type:'stdio',command:process.execPath,args:[server],env:{APACK_MCP_RECEIPT:receipts,APACK_MCP_EXITS:exits}}}}));await writeFile(join(workspace,'expected-report.pdf'),makeNativePageReviewPdf());
 const {query}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href),model=await startSyntheticModel(workspace,'mcp__research__echo',{captureMessages:true,maxRequests:8});let handle,events=[],result;
 try{
  handle=await query({cliPath:executable,cwd:workspace,env:{HOME:join(workspace,'home'),CLAUDE_CONFIG_DIR:join(workspace,'config'),ANTHROPIC_BASE_URL:model.url},settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),settingSources:[],strictMcpConfig:true,mcpConfig:[config],allowedTools:['mcp__research__echo'],maxTurns:4,prompt:'Return the owned release-report PDF.',signal:AbortSignal.timeout(30000)});
  const initialization=await handle.initialized;for await(const event of handle.events)events.push(event);result=await handle.result;
  const results=model.calls.flatMap(c=>c.messages??[]).flatMap(m=>Array.isArray(m.content)?m.content:[]).filter(b=>b.type==='tool_result');assert.ok(results.length,'Original MCP result was not consumed by the model');
  const expected=makeNativePageReviewPdf(),documents=results.flatMap(r=>Array.isArray(r.content)?r.content:[]).filter(b=>b.type==='document');for(const d of documents){assert.equal(d.source.type,'base64');assert.equal(d.source.media_type,'application/pdf');assert.deepEqual(Buffer.from(d.source.data,'base64'),expected);}
  const saved=[],names=await readdir(workspace,{recursive:true});assert.ok(names.length<=4096);for(const p of names){if(!p.endsWith('.pdf')||p==='expected-report.pdf')continue;const path=join(workspace,p),info=await lstat(path);assert.ok(info.isFile()&&info.uid===process.getuid()&&info.size<=1048576);const bytes=await readFile(path);if(bytes.equals(expected))saved.push({path,sha256:sha(bytes)});}
  assert.ok(documents.length||saved.length,'Neither original inline document nor exact persisted PDF observed');
  await writeFile(join(workspace,'mcp-pdf-query.json'),JSON.stringify({targetSha256:'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10',platform:'linux-arm64',initialization,result,events,calls:model.calls,inlineDocuments:documents.length,saved,pdfSha256:sha(expected),scope:'Original native MCP PDF normalization and product NDJSON transport only; actual app presentation and managed/remote/attached-client contexts unverified.'},null,2));
 }finally{try{await handle?.close();const shutdown=await observeChildGenericShutdown({children:receipts,exits});await writeFile(join(workspace,'mcp-shutdown.json'),JSON.stringify(shutdown,null,2));assert.ok(shutdown.passed,'Owned MCP server/native parent still live');await writeFile(join(workspace,'query-events.json'),JSON.stringify({events,result,calls:model.calls},null,2));}finally{await model.close();}}
}
