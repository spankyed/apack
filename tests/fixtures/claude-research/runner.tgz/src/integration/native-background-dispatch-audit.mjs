import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';

/** Diagnostic in the owned original process; no daemon/client authorization is replaced. */
export async function prepareNativeBackgroundDispatchAudit(workspace,project) {
 assert.ok(isAbsolute(workspace)&&isAbsolute(project));
 const marker=join(workspace,'owned-child-preload-audit.mjs');
 assert.match(marker,/^[A-Za-z0-9_/.:-]+$/u);
 const childSource=`import {writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const binary=createHash('sha256').update((await import('node:fs')).readFileSync(process.execPath)).digest('hex');
if(binary!=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10')throw Error('Unreviewed child executable');
delete process.env.BUN_OPTIONS;
writeFileSync(${JSON.stringify(join(workspace,'child-preload-audit-'))}+process.pid+'.json',JSON.stringify({pid:process.pid,parentPid:process.ppid,binarySha256:binary,sessionIds:process.argv.filter(value=>/^[a-f0-9-]{36}$/i.test(value)),source:'per-job preload',restoredBunOptions:true}),{mode:0o600});
`;
 await writeFile(marker,childSource,{mode:0o600});
 const audit=join(workspace,'native-dispatch-preload-audit.json');
 const source=String.raw`{
 const {writeFileSync}=await import('node:fs');const original=JSON.stringify;let used=false,seen=0;
 JSON.stringify=function(value,...rest){
  const socket=value&&typeof value==='object'&&value.op==='dispatch';
  const d=socket?value.d:value&&typeof value==='object'&&value.launch&&value.short&&value.nonce?value:undefined;
  if(d&&seen<8){seen++;writeFileSync(AUDIT+'.seen-'+seen,original({source:d.source,short:d.short,sessionId:d.sessionId,cwdMatches:d.cwd===PROJECT,launchMode:d.launch?.mode,envKeys:Object.keys(d.env??{})}),{mode:0o600});}
  if(!used&&d&&d.cwd===PROJECT&&(d.source==='slash'||d.source==='fleet')&&d.launch?.mode==='resume'&&/^[a-f0-9]{8}$/i.test(d.short??'')&&/^[a-f0-9-]{36}$/i.test(d.sessionId??'')&&d.env&&typeof d.env==='object'&&d.env.BUN_OPTIONS===undefined){
   used=true;const transformed={...d,env:{...d.env,BUN_OPTIONS:PRELOAD}},next=socket?{...value,d:transformed}:transformed;
   writeFileSync(AUDIT,original({parentPid:process.pid,short:d.short,sessionId:d.sessionId,launchMode:d.launch.mode,producerStack:new Error('owned native dispatch observation').stack?.slice(0,4096),launchObjectPreserved:transformed.launch===d.launch,authPreserved:next.auth===value.auth,noncePreserved:transformed.nonce===d.nonce,route:socket?'native-socket-dispatch':'native-file-dispatch',originalEnvKeys:Object.keys(d.env),mutatedEnvKeys:['BUN_OPTIONS'],scope:'First native slash-or-fleet/resume dispatch in this private project only; not a production interceptor or app acceptance.'}),{mode:0o600});
   return Reflect.apply(original,this,[next,...rest]);
  }
  return Reflect.apply(original,this,[value,...rest]);
 };
}`.replaceAll('PROJECT',JSON.stringify(project)).replaceAll('PRELOAD',JSON.stringify('--preload='+marker)).replaceAll('AUDIT',JSON.stringify(audit));
 return {source,marker,childSource};
}
