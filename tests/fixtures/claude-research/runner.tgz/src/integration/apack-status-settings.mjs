import { nativeManagedFiles } from '../protocol/native-managed-files.mjs';
import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { hash } from '../artifacts/runs.mjs';
const [checkout, executable, workspace] = process.argv.slice(2);
assert.equal(process.env.HOME, workspace);
assert.equal(hash(await readFile(executable)), '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');
const { query } = await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href);
await mkdir(join(workspace,'.claude'),{recursive:true});await mkdir(join(workspace,'policy'));
const user={apiKeyHelper:'/usr/bin/printf research-fixture-key',statusLine:{type:'command',command:'/usr/bin/printf UserMain',args:['MUST_NOT_BE_APPLIED'],padding:3},subagentStatusLine:{type:'command',command:'/usr/bin/printf UserSub',args:['MUST_NOT_BE_APPLIED']}};
await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify(user));
const model=await startSyntheticModel(workspace,'TextOnly');
const env={HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),CLAUDE_CODE_MANAGED_SETTINGS_PATH:join(workspace,'policy'),ANTHROPIC_BASE_URL:model.url,CLAUDE_CODE_SIMPLE:undefined,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
async function settings(extraEnv={}){let handle;try{handle=await query({cliPath:executable,cwd:workspace,env:{...env,...extraEnv},keepStdinOpen:true});await handle.initialized;return await handle.getSettings()}finally{await handle?.close()}}
try {
 const plain=await settings();
 assert.equal(plain.effective.statusLine.command,user.statusLine.command);assert.equal(plain.effective.statusLine.args,undefined);assert.equal(plain.effective.subagentStatusLine.args,undefined);
 const policy={allowManagedHooksOnly:true,statusLine:{type:'command',command:'/usr/bin/printf ManagedMain'},subagentStatusLine:{type:'command',command:'/usr/bin/printf ManagedSub'}};
 await writeFile(join(workspace,'policy/managed-settings.json'),JSON.stringify(policy));
 const managed=await settings();
 const policySelected=managed.effective.statusLine.command===policy.statusLine.command&&managed.effective.subagentStatusLine.command===policy.subagentStatusLine.command;
 const managedSourceVisible=managed.sources.some(source=>/policy|managed/i.test(source.source)&&source.settings.statusLine?.command===policy.statusLine.command);
 const preload=join(workspace,'managed-files-preload.mjs'),receipt=join(workspace,'managed-file-reads.jsonl');
 await writeFile(preload,nativeManagedFiles({directory:join(workspace,'policy'),receipt}));
 const isolatedManaged=await settings({BUN_OPTIONS:'--preload='+preload});
 const isolatedPolicySelected=isolatedManaged.effective.statusLine?.command===policy.statusLine.command&&isolatedManaged.effective.subagentStatusLine?.command===policy.subagentStatusLine.command;
 const isolatedManagedSource=isolatedManaged.sources.find(source=>/policy|managed/i.test(source.source)&&source.settings.statusLine?.command===policy.statusLine.command);
 await writeFile(join(workspace,'native-managed-policy-selection.json'),JSON.stringify({isolatedManaged,isolatedPolicySelected,isolatedManagedSource},null,2));
 assert.ok(isolatedPolicySelected,'Original native policy parser did not select the private mapped managed file');
 assert.ok(isolatedManagedSource,'Native settings did not attribute the selected commands to policy');
 assert.equal(model.calls.length,0);
 await writeFile(join(workspace,'native-status-settings.json'),JSON.stringify({plain,managed},null,2));
 console.log(JSON.stringify({evidence:'apack-native-status-settings',nativeArgsDropped:true,isolatedPolicySelected,isolatedManagedSourceVisible:!!isolatedManagedSource,managedSourceVisible,policySelected,configuredStatusArguments:'shell command string; args stripped by native settings',sourceNames:managed.sources.map(source=>source.source),syntheticApiRequests:0,realModelRequests:0,targetSha256:hash(await readFile(executable))}));
} finally { await model.close() }
