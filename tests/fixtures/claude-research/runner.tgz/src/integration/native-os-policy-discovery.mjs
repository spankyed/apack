import {nativeOsPolicyFiles} from '../protocol/native-os-policy-files.mjs';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {hash} from '../artifacts/runs.mjs';

const [binaryPath,directory,fixture]=process.argv.slice(2);
assert.ok(binaryPath&&directory,'Expected pinned binary, new private directory and optional fixture');
const binary=resolve(binaryPath),workspace=resolve(directory);
assert.ok(!fixture||['device','user','malformed','unreadable'].includes(fixture));
assert.equal(hash(await readFile(binary)),'5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');
await mkdir(workspace,{mode:0o700});
const output=join(workspace,'os-policy-discovery.json'),preload=join(workspace,'os-policy-discovery-preload.mjs');
let mapping='';
if(fixture){
 const policy=join(workspace,'policy');await mkdir(policy,{recursive:true});
 const plist=command=>'<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>allowManagedHooksOnly</key><true/><key>statusLine</key><dict><key>type</key><string>command</string><key>command</key><string>'+command+'</string></dict></dict></plist>';
 await writeFile(join(policy,'device.plist'),plist('/usr/bin/printf MdmDevice'));
 if(fixture==='user')await writeFile(join(policy,'user.plist'),plist('/usr/bin/printf MdmUser'));
 if(fixture==='malformed')await writeFile(join(policy,'user.plist'),'not a valid property list');
 mapping=nativeOsPolicyFiles({directory:policy,receipt:join(workspace,'os-policy-io.jsonl'),unreadableUser:fixture==='unreadable'});
}
await writeFile(preload,mapping+`const {writeFileSync}=await import('node:fs');
const {createHash}=await import('node:crypto');
const {BVs,v$o,NVs,FVs,$Vs,i$r}=await import('/$bunfs/root/chunk-bk0cajy4.js');
const {d8n}=await import('/$bunfs/root/chunk-ngbj2eny.js');
const sources=BVs(),result=await d8n();
const rows=result.plistStdouts?.map(({stdout,...facts})=>({...facts,bytes:stdout===null?null:Buffer.byteLength(stdout),sha256:stdout===null?null:createHash('sha256').update(stdout).digest('hex'),...${JSON.stringify(!!fixture)}&&{stdout}}));
writeFileSync(${JSON.stringify(output)},JSON.stringify({sources,converter:{executable:v$o,convert:NVs,lint:FVs,timeout:$Vs,maxBuffer:i$r},rows,registryRequested:result.outcomes.hklm!==null||result.outcomes.hkcu!==null},null,2));
process.exit(0);`);
const child=spawn(binary,['--version'],{cwd:workspace,env:{...process.env,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),BUN_OPTIONS:'--preload='+preload,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},stdio:['ignore','pipe','pipe']});
let stdout='',stderr='';child.stdout.on('data',d=>stdout+=d);child.stderr.on('data',d=>stderr+=d);
let hardStop;
const timer=setTimeout(()=>{child.kill('SIGTERM');hardStop=setTimeout(()=>child.kill('SIGKILL'),1000);},15000);
let exit;try{exit=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});}finally{clearTimeout(timer);clearTimeout(hardStop);}
await writeFile(join(workspace,'process.json'),JSON.stringify({...exit,stdout,stderr},null,2));assert.equal(exit.code,0,stderr);
const evidence=JSON.parse(await readFile(output,'utf8'));assert.equal(evidence.converter.executable,'/usr/bin/plutil');assert.ok(evidence.sources.every(s=>s.path.startsWith('/Library/Managed Preferences/')));assert.equal(evidence.registryRequested,false);
if(fixture){const selected=evidence.rows.find(row=>row.stdout!==null);assert.ok(selected);if(fixture==='user')assert.match(selected.stdout,/MdmUser/);if(fixture==='device')assert.match(selected.stdout,/MdmDevice/);if(fixture==='unreadable'){assert.equal(evidence.rows[0].unreadErrno,'EACCES');assert.match(selected.stdout,/MdmDevice/);}if(fixture==='malformed'){assert.equal(evidence.rows.length,1);assert.equal(selected.stdout,'');}const io=(await readFile(join(workspace,'os-policy-io.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert.ok(io.some(row=>row.operation==='execFile'&&row.executable==='/usr/bin/plutil'));if(fixture==='malformed')assert.ok(io.some(row=>row.args?.includes('-lint')));}
const report={observedAt:new Date().toISOString(),workspace,fixture:fixture??null,target:'2.1.302',targetSha256:hash(await readFile(binary)),sourceHashes:{driver:hash(await readFile(new URL(import.meta.url))),privateIo:hash(await readFile(new URL('../protocol/native-os-policy-files.mjs',import.meta.url)))},nativeDiscovery:true,machinePolicyModified:false,modelRequests:0,evidence};
await writeFile(join(workspace,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
