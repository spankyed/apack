import assert from 'node:assert/strict';
import {mkdtemp,realpath,readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkoutArg,executable,workspace]=process.argv.slice(2);
const checkout=await realpath(checkoutArg);
assert.notEqual(checkout,await realpath('/Users/spankyed/Develop/Projects/apack/monorepo'));
assert.equal(process.env.HOME,workspace);
const {query}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')));
const cases=[];
for(const coordinatorMode of [false,true])for(const constrained of [false,true]){
 const cwd=await mkdtemp(join(workspace,'availability-'));
 const model=await startSyntheticModel(cwd,'TextOnly');
 let handle;
 try{
  handle=await query({cliPath:executable,cwd,env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),CLAUDE_CODE_SIMPLE:undefined,
   CLAUDE_CODE_COORDINATOR_MODE:coordinatorMode?'1':undefined,ANTHROPIC_BASE_URL:model.url,ENABLE_TOOL_SEARCH:'0',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
   ...(constrained?{tools:['CronCreate','CronList']}:{}),strictMcpConfig:true,settingSources:[],noSessionPersistence:true,permissionMode:'acceptEdits',model:'default',
   surfaceControlRequests:true,replayUserMessages:true,maxTurns:1,signal:AbortSignal.timeout(20000),settings:JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})});
  await handle.initialized;
  handle.send('Reply with fixture text only. Do not call any tools.');
  let advertised;
  for await(const event of handle.events){
   if(event.type==='system'&&event.subtype==='init')advertised=event.tools;
   assert.notEqual(event.type,'control_request','Text-only fixture must not request tool permissions');
   if(event.type==='result'){assert.equal(event.subtype,'success');break;}
  }
  await handle.close();assert.ok(Array.isArray(advertised));assert.equal(model.calls.length,1);
  cases.push({coordinatorMode,constrained,advertised,modelTools:model.calls[0].toolNames});
 }finally{if(handle){handle.kill();await handle.close().catch(()=>{})}await model.close()}
}
assert.ok(cases[0].advertised.includes('CronCreate'));
assert.deepEqual(cases[1].advertised,['CronCreate','CronList']);
assert.deepEqual(cases[3].advertised,[]);
console.log(JSON.stringify({evidence:'apack-native-tool-availability',targetSha256:hash(await readFile(executable)),cases,syntheticApiRequests:4,realModelRequests:0}));
