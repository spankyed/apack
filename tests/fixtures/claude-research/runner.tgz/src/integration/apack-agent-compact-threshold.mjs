import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { hash } from '../artifacts/runs.mjs';

const [checkout, executable, workspace, ceilingArg] = process.argv.slice(2);
assert.equal(process.argv.length, 6, 'Expected checkout, pinned executable, a new private directory and worker ceiling');
assert.equal(process.env.HOME, workspace);
for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN']) {
  assert.equal(process.env[key], undefined);
}
const ceiling = Number(ceilingArg);
assert.ok([100_000, 200_000].includes(ceiling));
const targetSha256 = hash(await readFile(executable));
assert.equal(targetSha256, '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');
const expectedCompact = ceiling === 100_000;
const agent = 'compact-reviewer';
const agentToolId = 'research_worker';
const readToolPrefix = 'research_worker_read';
const taskInstruction = 'InlineWorkerInstructionMarker';
const fileContents = ['Check scope', 'Check recovery', 'Check release notes'];
const summary = 'The recovered checklist requires scope, recovery and release-note review.';
const finalWorkerReply = 'Worker review complete.';
const highUsage = 110_000;

await mkdir(workspace);
const files = await Promise.all(fileContents.map(async (content, index) => {
  const path = join(workspace, 'checklist-' + (index + 1) + '.txt');
  await writeFile(path, content + '\n');
  return path;
}));
const debugPath = join(workspace, 'native-debug.log');
const launcher = join(workspace, 'claude-observed');
const quote = value => "'" + value.replaceAll("'", "'\\''") + "'";
await writeFile(launcher, '#!/bin/sh\nexec ' + quote(executable) + ' --debug-file ' + quote(debugPath) + ' "$@"\n', { mode: 0o700 });
const { query } = await import(pathToFileURL(join(checkout,
  'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href);

const events = [], calls = [], errors = [];

function reply(res, payload) {
  res.setHeader('content-type', 'application/json');
  res.end(JSON.stringify(payload));
}

async function respond(req, res) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    assert.ok(size <= 2 * 1024 * 1024);
    chunks.push(chunk);
  }
  const data = JSON.parse(Buffer.concat(chunks));
  if (req.url?.includes('/count_tokens')) return reply(res, { input_tokens: 20 });
  if (!req.url?.startsWith('/v1/messages')) {
    res.writeHead(404);
    return res.end();
  }
  assert.ok(calls.length < 16);
  const transcript = JSON.stringify(data.messages ?? []);
  const child = JSON.stringify(data.system).includes(taskInstruction);
  const compacting = /create a detailed summary of the conversation|summarize the conversation|continuing development work without losing context/i.test(transcript);
  const previousReads = calls.filter(call => call.child && call.tool === 'Read').length;
  const text = value => ({ type: 'text', text: value });
  const tool = (id, name, input) => ({ type: 'tool_use', id, name, input });
  let block;
  if (compacting) {
    block = text('<summary>' + summary + '</summary>');
  } else if (child) {
    block = previousReads === files.length ? text(finalWorkerReply)
      : tool(readToolPrefix + (previousReads + 1), 'Read', { file_path: files[previousReads] });
  } else {
    block = transcript.includes(agentToolId) ? text('Parent review complete.')
      : tool(agentToolId, 'Agent', { description: 'Review release notes',
        prompt: 'Read the release checklist, then report.', subagent_type: agent });
  }
  const inputTokens = child && block.name === 'Read' && previousReads === files.length - 1 ? highUsage : 20;
  calls.push({ child, compacting, tool: block.name, inputTokens, model: data.model,
    receivedSummary: transcript.includes(summary), receivedFinalRead: transcript.includes(fileContents.at(-1)) });
  const stop = block.type === 'tool_use' ? 'tool_use' : 'end_turn';
  const usage = { input_tokens: inputTokens, output_tokens: 10 };
  const message = { id: 'msg_research_' + calls.length, type: 'message', role: 'assistant',
    model: data.model, content: [block], stop_reason: stop, stop_sequence: null, usage };
  if (!data.stream) return reply(res, message);
  res.setHeader('content-type', 'text/event-stream');
  const send = (type, payload) => res.write('event: ' + type + '\ndata: ' + JSON.stringify({ type, ...payload }) + '\n\n');
  const toolUse = block.type === 'tool_use';
  send('message_start', { message: { ...message, content: [], stop_reason: null, usage: { ...usage, output_tokens: 0 } } });
  send('content_block_start', { index: 0, content_block: toolUse ? { ...block, input: {} } : { type: 'text', text: '' } });
  send('content_block_delta', { index: 0, delta: toolUse
    ? { type: 'input_json_delta', partial_json: JSON.stringify(block.input) }
    : { type: 'text_delta', text: block.text } });
  send('content_block_stop', { index: 0 });
  send('message_delta', { delta: { stop_reason: stop, stop_sequence: null }, usage });
  send('message_stop', {});
  res.end();
}

const server = createServer((req, res) => respond(req, res).catch(error => {
  errors.push(error.message);
  if (!res.headersSent) res.writeHead(400);
  res.end('{}');
}));
await new Promise((resolve, reject) => {
  server.once('error', reject);
  server.listen(0, '127.0.0.1', resolve);
});

let handle;
try {
  handle = await query({
    cliPath: launcher, cwd: workspace, model: 'sonnet', permissionMode: 'acceptEdits',
    tools: ['Agent', 'Read'], allowedTools: ['Agent', 'Read'],
    agents: { [agent]: { description: 'Private release worker',
      prompt: taskInstruction + '. Read the checklist and report.', tools: ['Read'], maxTurns: 5, autoCompactWindow: ceiling } },
    env: { HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'),
      ANTHROPIC_BASE_URL: 'http://127.0.0.1:' + server.address().port,
      DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
    settingSources: [], settings: JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' }),
    strictMcpConfig: true, keepStdinOpen: true, replayUserMessages: true, signal: AbortSignal.timeout(40000),
  });
  const initialized = await handle.initialized;
  assert.ok(initialized.agents.some(row => row.name === agent));
  handle.send('Review the release checklist using the private release worker.');
  for await (const event of handle.events) {
    events.push(event);
    if (event.type === 'result' && !handle.hasPendingBackgroundTasks(event)
      && events.some(row => row.subtype === 'task_notification' && row.tool_use_id === agentToolId)) {
      assert.equal(event.subtype, 'success');
      break;
    }
  }
  const started = events.find(row => row.subtype === 'task_started' && row.tool_use_id === agentToolId);
  assert.ok(started?.task_id && events.some(row => row.subtype === 'task_notification'
    && row.task_id === started.task_id && row.status === 'completed'));
  const pid = handle.pid;
  await handle.close();
  handle = undefined;
  assert.throws(() => process.kill(pid, 0), { code: 'ESRCH' });
  assert.deepEqual(errors, []);
  const workerCalls = calls.filter(row => row.child);
  assert.deepEqual(workerCalls.filter(row => row.tool === 'Read').map(row => row.inputTokens), [20, 20, highUsage]);
  assert.equal(workerCalls.filter(row => row.compacting).length, Number(expectedCompact));
  assert.equal(workerCalls.at(-1).receivedSummary, expectedCompact);
  assert.equal(workerCalls.at(-1).receivedFinalRead, true);
  assert.ok(!calls.some(row => !row.child && (row.compacting || row.receivedSummary)));

  const projects = join(workspace, '.claude/projects');
  const filesInProfile = await readdir(projects, { recursive: true });
  const path = filesInProfile.find(file => file.endsWith('/subagents/agent-' + started.task_id + '.jsonl'));
  assert.ok(path, 'Expected the completed worker’s own journal');
  const journal = (await readFile(join(projects, path), 'utf8')).trim().split('\n').map(JSON.parse);
  const compact = journal.filter(row => row.subtype === 'compact_boundary');
  assert.equal(compact.length, Number(expectedCompact));
  const workerReplyIndex = journal.findIndex(row => row.type === 'assistant' && row.message?.content?.some(block => block.text === finalWorkerReply));
  assert.ok(workerReplyIndex >= 0);
  if (expectedCompact) {
    assert.equal(compact[0].compactMetadata.trigger, 'auto');
    assert.ok(compact[0].compactMetadata.preTokens >= highUsage);
    const summaryIndex = journal.findIndex(row => row.isCompactSummary && JSON.stringify(row.message).includes(summary));
    assert.ok(journal.indexOf(compact[0]) < summaryIndex && summaryIndex < workerReplyIndex);
  }
  const debug = await readFile(debugPath, 'utf8');
  assert.match(debug, new RegExp('level=' + (expectedCompact ? 'compact' : 'ok') + ' effectiveWindow=' + (ceiling - 20_000)));
  assert.equal(debug.includes('[API REQUEST] /v1/messages source=compact'), expectedCompact);
  const result = { status: 'verified-native-inline-agent-threshold', targetSha256, ceiling, workerReportedUsageTokens: highUsage,
    workerTaskId: started.task_id, workerCompacted: expectedCompact, workerResumedWithSummary: workerCalls.at(-1).receivedSummary,
    originalBoundary: compact[0]?.compactMetadata ?? null, workerCompleted: true, processRetired: true, syntheticRequests: calls.length };
  await writeFile(join(workspace, 'proof.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
} finally {
  if (handle) {
    handle.kill();
    await handle.close().catch(() => {});
  }
  server.closeAllConnections();
  await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
  await writeFile(join(workspace, 'observations.json'), JSON.stringify({ calls, errors, events }, null, 2) + '\n');
}
