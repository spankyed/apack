"""Verify saved original-native/app clipboard receipts without executing Claude."""
from pathlib import Path
import argparse, hashlib, json, subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence', type=Path)
parser.add_argument('product', type=Path)
parser.add_argument('--commit', required=True)
parser.add_argument('--research-commit', required=True)
args = parser.parse_args()
evidence = args.evidence.resolve()
research = Path(__file__).resolve().parents[2]

def load(path):
    assert path.stat().st_size < 32 * 1024**2, path
    return json.loads(path.read_text())

def digest(value):
    return hashlib.sha256(value).hexdigest()

for repo, commit, name in [(args.product, args.commit, 'source-inputs.json'), (research, args.research_commit, 'authored-inputs.json')]:
    inputs = load(evidence / name)
    assert inputs
    for path, expected in inputs.items():
        assert not Path(path).is_absolute() and '..' not in Path(path).parts
        actual = subprocess.check_output(['git', 'show', commit + ':' + path], cwd=repo)
        assert digest(actual) == expected, path
compiled = load(evidence / 'compiled-before.json')
assert compiled == load(evidence / 'compiled-after.json')
boundary = load(evidence / 'offline-boundary.json')
assert boundary['networkDisabled'] and boundary['pinnedExecutableReadOnly']
assert set(boundary['networks']) == {'none'}
assert boundary['memory'] == boundary['memorySwap'] == 6 * 1024**3
assert boundary['nanoCpus'] == 2 * 10**9
proofs = list((evidence / 'records/workspaces').glob('*/native-large-copy-proof.json'))
assert len(proofs) == 1
workspace = proofs[0].parent
copies = load(workspace / 'native-copy-receipts.json')
assert len(copies) == 7
assert copies[0]['result'] == copies[2]['result'] == {'isCopied': True}
assert copies[1]['result'] == copies[3]['result'] == {'isCopied': False, 'reason': 'no-clipboard'}
assert copies[3]['textLength'] == 1000001
samples = [('cjk', '漢' * 1000000, 1000000), ('astral', '👋' * 500000, 1000000), ('escaped', chr(92) + chr(10), 1000000)]
samples[-1] = ('escaped', samples[-1][1] * 500000, 1000000)
large = load(proofs[0])
assert len(large) == len(samples)
for index, (observed, (name, text, units)) in enumerate(zip(large, samples), 4):
    assert copies[index] == {'textLength': units, 'result': {'isCopied': True}}
    assert observed == {'name': name, 'length': units, 'bytes': len(text.encode()), 'sha256': digest(text.encode()), 'nativeResult': {'isCopied': True}}
app = load(workspace / 'native-terminal-app-evidence.json')
assert app['actualAppGui'] and app['nativeClipboard'] and app['nativeClipboardSameSessionRecovery']
assert app['sameNativeOwner'] and app['resumedPrintSameSession'] and not app['browserErrors']
assert app['sessionId'] == app['finalSessionId']
proof = load(workspace / 'native-clipboard-app-proof.json')
assert proof['copyBefore']['messages'] == proof['copyAfter']['messages']
assert proof['copyBefore']['turns'] == proof['copyAfter']['turns']
assert proof['copyBefore']['claude']['totalCostUsd'] == proof['copyAfter']['claude']['totalCostUsd']
assert proof['copyAfter']['native']['state']['nativePid'] == proof['sent']['native']['state']['nativePid'] == app['boundNativePid']
assert proof['sent']['sessionId'] == proof['final']['sessionId'] == app['sessionId']
journals = list((workspace / '.claude/projects').glob('*/' + app['sessionId'] + '.jsonl'))
assert len(journals) == 1
rows = [json.loads(line) for line in journals[0].read_text().splitlines() if line]
humans = [row for row in rows if row.get('type') == 'user' and not row.get('isMeta') and not row.get('isVirtual')]
assert len(humans) == 3
for text in [proof['submitted'], proof['recovery']]:
    matches = [row for row in humans if row.get('message', {}).get('content') == text]
    assert len(matches) == 1 and matches[0]['sessionId'] == app['sessionId']
for text in [proof['submitted'], proof['recovery']]:
    assert len([message for message in proof['final']['messages'] if message['sender'] == 'user' and message['text'] == text]) == 1
stdout = next((evidence / 'records/output/runs').glob('*/stdout.bin')).read_text()
markers = [json.loads(line) for line in stdout.splitlines() if line.startswith('{"evidence":"apack-native-terminal-owner-app"')]
assert len(markers) == 1
marker = markers[0]
assert marker['ownedShutdown'] and marker['nativeProcesses'] == 3
assert marker['nativeClipboardSameSessionRecovery'] and marker['nativeStructuredPrompt'] is False
assert marker['syntheticApiRequests'] == 3 and marker['realModelRequests'] == 0
assert marker['targetSha256'] == '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
children = [json.loads(line) for line in (workspace / 'native-children.jsonl').read_text().splitlines() if line]
exits = [json.loads(line) for line in (workspace / 'native-exits.jsonl').read_text().splitlines() if line]
assert len(children) == 3 and app['boundNativePid'] == children[1]['pid']
assert all(any(exit['pid'] == child['pid'] for exit in exits) for child in children)
assert '--print' in children[0]['args'] and '--resume' in children[1]['args'] and '--print' in children[2]['args']
assert exits[0]['at'] <= children[1]['at']
screens = list((workspace / 'electron-results').rglob('*.png'))
expected = {'native-' + kind + '-' + width + '.png' for kind in ['clipboard', 'large-clipboard', 'clipboard-sent'] for width in ['1100', '680']}
assert len(screens) == len(expected) and {path.name for path in screens} == expected
calls = load(workspace / 'model-calls.json')
assert len(calls['seed']) + len(calls['agent']) == 3
summary = {'status': 'passed', 'runtimeCommit': args.commit, 'researchCommit': args.research_commit, 'sessionId': app['sessionId'], 'samples': large, 'captures': len(screens), 'ownedNativeExits': len(children), 'compiledFilesUnchanged': len(compiled['files']), 'syntheticRequests': 3, 'realModelRequests': 0, 'scope': 'Main-owner original clipboard copies at the native character limit, refusal/recovery, retained everyday composing/Send and same-session continuation. Large actual-app selection, other owners/OS/lifetimes and full F1–F5 remain unverified.'}
(evidence / 'saved-record-verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
