"""Verify saved original child Bash evidence; never execute Claude or the app."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile


def verify(root, product):
    read = lambda name: json.loads((root / name).read_text())
    stage, post, boundary = map(read, ['receipt.json', 'post-inputs.json', 'boundary.json'])
    assert read('result.json')['exitCode'] == stage['exitCode'] == 0
    assert boundary['network'] == 'none' and boundary['networkDisabled']
    assert boundary['pinnedExecutableReadOnly']
    assert boundary['memoryBytes'] == 6 * 1024 ** 3 and boundary['cpus'] == 2
    assert boundary['productCommit'] == stage['productCommit']
    assert boundary['researchCommit'] == stage['researchCommit']
    assert post['passed'] and post['nativeOnly']
    for name, count in post['counts'].items():
        assert count == len(read(name))
    research = Path(__file__).resolve().parents[2]
    for name, checkout, commit in [
        ('source-inputs.json', product, stage['productCommit']),
        ('authored-inputs.json', research, stage['researchCommit']),
    ]:
        manifest = read(name)
        refs = ''.join(commit + ':' + path + '\n' for path in manifest)
        blobs = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=checkout, input=refs.encode())
        offset = 0
        for path, expected in manifest.items():
            end = blobs.index(b'\n', offset)
            header = blobs[offset:end].split()
            assert len(header) == 3 and header[1] == b'blob', path
            size = int(header[2])
            value = blobs[end + 1:end + 1 + size]
            assert len(value) == size and blobs[end + 1 + size:end + 2 + size] == b'\n'
            assert hashlib.sha256(value).hexdigest() == expected, path
            offset = end + 2 + size
        assert offset == len(blobs)
    assert not any(int(line.split()[1]) for line in (root / 'memory.events').read_text().splitlines()
                   if line.split()[0].startswith('oom'))
    with tarfile.open(root / 'results.tar.gz') as archive:
        def read_member(name):
            member = archive.getmember(name)
            assert member.isfile() and member.size <= 16 * 1024 ** 2
            return json.load(archive.extractfile(member))
        proof = read_member('results/product-child-bash.json')
        calls = read_member('results/model-calls.json')
    assert proof['status'] == 'complete' and proof['syntheticAuthSettingsRestored'] and proof['ownerRetired']
    for key in ['readWithoutDesktopClient', 'foreignParentRefused', 'invalidChoiceRefused', 'duplicateRefused']:
        assert proof[key], key
    assert proof['originalAnswer'] == {'answered': True}
    job, dialog, decision = proof['job'], proof['dialog'], proof['decision']
    assert job['sessionId'] != proof['parentSessionId'] and job['pid'] > 1
    assert dialog['sessionId'] == job['sessionId'] and dialog['toolName'] == 'Bash'
    sent = proof['submitted']
    assert sent['id'] == dialog['id'] and sent['revision'] == dialog['revision'] and sent['session_id'] == job['sessionId']
    assert sent['decision'] == decision
    tool_result = proof['originalToolResult']
    assert tool_result['type'] == 'tool_result' and tool_result['tool_use_id'] == dialog['requestId']
    assert (tool_result.get('is_error') is True) == (decision == 'deny')
    if decision == 'allow':
        assert proof['fileEffect'] == 'synthetic protocol fixture\n'
        if proof['mountedChoicesAvailable']:
            yes = next(choice for choice in dialog['choices'] if choice['value'] == 'yes')
            assert sent['choice'] == 'yes' and sent['choiceToken'] == yes['token']
        else:
            assert 'choice' not in sent and 'choiceToken' not in sent
    else:
        assert decision == 'deny' and proof['deniedFileAbsent']
    assert any(block == tool_result for call in calls for message in call.get('messages', [])
               for block in (message.get('content') if isinstance(message.get('content'), list) else []))
    assert any('Bash' in call.get('toolNames', []) for call in calls)
    stopped = proof['stopped']
    assert stopped['id'] == job['id'] and stopped['sessionId'] == job['sessionId'] and stopped['state'] == 'stopped'
    assert proof['terminalInputWrites'] == proof['realModelRequests'] == 0
    assert not any(row['foreignKey'] for row in proof['requests'])
    models = [call for call in calls if call['path'].split('?')[0] == '/v1/messages']
    assert 1 <= len(models) <= 12
    return {'passed': True, 'productCommit': stage['productCommit'], 'researchCommit': stage['researchCommit'],
            'counts': post['counts'], 'job': job, 'dialog': dialog, 'decision': decision, 'mountedChoicesAvailable': proof['mountedChoicesAvailable'], 'readWithoutDesktopClient': proof['readWithoutDesktopClient'],
            'originalToolResult': tool_result, 'foreignParentAndDuplicateRefused': True,
            'nativeStopAndOwnerRetirement': True, 'syntheticSettingsRestored': True,
            'syntheticHttpRequests': len(calls), 'syntheticTlsRequests': len(proof['requests']),
            'syntheticApiRequests': len(calls) + len(proof['requests']), 'syntheticModelRequests': len(models),
            'metadataNote': 'Original syntheticApiRequests counts model-fixture HTTP calls only; total here also includes recorded TLS startup requests.',
            'realModelRequests': 0, 'oom': False,
            'scope': 'Original owned child Bash approval authority and native effects/refusal boundaries only. No mounted app or other approval-family acceptance.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('evidence', type=Path)
    parser.add_argument('--product', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(verify(args.evidence, args.product), indent=2))
