import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,rename,lstat} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';

/** Move only this run's synthetic account into a profile created by the normal app constructor. */
export async function prepareNativeAppCliProfile({checkout,workspace,account,owned}){
 const external=join(workspace,'.claude');
 if(!owned)return external;
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-[a-z0-9-]+$/);
 const {prepareClaudeOwnedProfile}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/owned-profile.ts')).href);
 const userDataDir=join(workspace,'app-data'),profile=await prepareClaudeOwnedProfile({userDataDir});
 assert.equal(profile.configDir,join(userDataDir,'claude-code-profile/config'));
 const settings=JSON.parse(await readFile(join(profile.configDir,'settings.json'),'utf8'));
 for(const name of await readdir(external)){
  assert.ok(['.claude.json','settings.json'].includes(name),'Only fresh synthetic account files may be transferred');
  const source=join(external,name);assert.ok((await lstat(source)).isFile());
  if(name==='settings.json')await writeFile(join(profile.configDir,name),JSON.stringify({...JSON.parse(await readFile(source,'utf8')),...settings}),{mode:0o600});
  else await rename(source,join(profile.configDir,name));
 }
 account.CLAUDE_CONFIG_DIR=profile.configDir;
 await writeFile(join(workspace,'cli-profile.json'),JSON.stringify({mode:'app-owned',userDataDir,configDir:profile.configDir,constructor:'prepareClaudeOwnedProfile',syntheticAccountOnly:true}));
 return profile.configDir;
}
