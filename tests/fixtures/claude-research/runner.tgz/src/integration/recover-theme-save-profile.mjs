import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,writeFile,rename,lstat,chmod,rmdir} from 'node:fs/promises';
import {join,resolve,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';

/** Run only after the owned app container is gone and the recovery runner holds its work-volume lock. */
export async function recoverThemeSaveProfile(workspace) {
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);
 assert.ok(existsSync('/.dockerenv')&&existsSync('/control/offline-verified'));
 assert.match(workspace,/^\/work\/\.claude-research\/theme-save-failure-app[0-9]+$/);
 const config='/work/.claude-research/profile-setup-app10/app-data/claude-code-profile/config';
 const ledger=JSON.parse(await readFile(join(workspace,'theme-save-profile.json'),'utf8'));
 assert.equal(ledger.directory,join(config,'themes'));assert.match(ledger.slug,/^release-save-theme-save-failure-app[0-9]+$/);
 assert.equal(ledger.themePath,join(ledger.directory,ledger.slug+'.json'));
 assert.ok(Number.isInteger(ledger.directoryMode)&&ledger.directoryMode>=0&&ledger.directoryMode<=0o7777);
 assert.ok(Number.isInteger(ledger.settingsMode)&&ledger.settingsMode>=0&&ledger.settingsMode<=0o7777);
 const sha=b=>createHash('sha256').update(b).digest('hex'),before=await readFile(join(workspace,'profile-preimages/settings.json'));
 assert.equal(sha(before),'5eb7b71763d6c0fc454f048fe69cb174724f161d2f4cdc50a8776c83cbc2e128');assert.equal(sha(before),ledger.settingsSha256);
 const settings=join(config,'settings.json');
 if(existsSync(ledger.directory)){const s=await lstat(ledger.directory);assert.ok(s.isDirectory()&&!s.isSymbolicLink()&&s.uid===1000);await chmod(ledger.directory,ledger.directoryMode);}
 assert.ok(Array.isArray(ledger.createdThemes)&&ledger.createdThemes.length<=2);
 for(const [index,path]of ledger.createdThemes.entries()){
  assert.equal(path,join(ledger.directory,basename(path)));assert.match(basename(path),new RegExp('^release-creation-'+basename(workspace)+'(?:-[0-9]+)?\\.json$'));
  if(existsSync(path)){const stat=await lstat(path);assert.ok(stat.isFile()&&!stat.isSymbolicLink()&&stat.uid===1000);const dest=join(workspace,'preserved-recovery-created-theme-'+index+'.json');assert.ok(!existsSync(dest));await rename(path,dest);}
 }
 if(existsSync(ledger.themePath)){const dest=join(workspace,'preserved-recovery-theme.json');assert.ok(!existsSync(dest));await rename(ledger.themePath,dest);}
 let unchanged=false;
 if(existsSync(settings)) {const s=await lstat(settings);assert.ok(s.isFile()&&!s.isSymbolicLink()&&s.uid===1000);unchanged=sha(await readFile(settings))===sha(before);if(!unchanged){const dest=join(workspace,'preserved-recovery-settings.json');assert.ok(!existsSync(dest));await rename(settings,dest);}}
 if(!unchanged)await writeFile(settings,before,{mode:ledger.settingsMode,flag:'wx'});
 await chmod(settings,ledger.settingsMode);
 if(!ledger.directoryExisted&&existsSync(ledger.directory))await rmdir(ledger.directory);
 assert.equal(sha(await readFile(settings)),sha(before));assert.ok(!existsSync(ledger.themePath));
 if(ledger.directoryExisted)assert.equal((await lstat(ledger.directory)).mode&0o7777,ledger.directoryMode);else assert.ok(!existsSync(ledger.directory));
 const result={restored:true,emergencyRecovery:true,settingsSha256:sha(before),directoryExisted:ledger.directoryExisted,directoryMode:ledger.directoryMode,fixtureThemeRemoved:true,createdThemesRemoved:ledger.createdThemes.every(path=>!existsSync(path))};
 const report=join(workspace,'theme-save-profile-recovery.json');if(existsSync(report))assert.deepEqual(JSON.parse(await readFile(report,'utf8')),result);else await writeFile(report,JSON.stringify(result),{mode:0o600,flag:'wx'});
 return result;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){assert.equal(process.argv.length,3);console.log(JSON.stringify(await recoverThemeSaveProfile(process.argv[2])));}
