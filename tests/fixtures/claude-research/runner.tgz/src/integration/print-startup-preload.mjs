import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {observePrintStartup} from './print-startup-observer.mjs';
if(!process.versions.electron&&process.argv[1]?.endsWith('/server.js')){
 const directory=process.env.CLAUDE_RESEARCH_PRINT_STARTUP_TRACE;assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(directory,/^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+\/print-startup$/);
 observePrintStartup({target:'/frozen-claude/claude',directory});
 writeFileSync(join(directory,'observer-ready-'+process.pid+'.json'),JSON.stringify({pid:process.pid,entry:process.argv[1],source:'production Node child_process.spawn; emit observation only',maxChildren:4,maxBytesPerStream:262144})+'\n',{mode:0o600,flag:'wx'});
}
