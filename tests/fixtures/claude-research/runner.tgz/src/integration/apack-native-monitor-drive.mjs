import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { startNativeMonitorFixture, prompt } from '../protocol/native-monitor-rollout-journey.mjs'
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs'
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs'

const executable = '/frozen-claude/claude'
const pin = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
export async function driveNativeMonitor({checkout,workspace,env,approve=false,standing=false,cancelFeedback=false,lifecycle=false,freshSession=false}) {
  assert.equal(process.platform,'linux')
  assert.equal(process.getuid(),1000)
  assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-monitor[0-9]+$/)
  const boundary=JSON.parse(await readFile('/control/offline-verified'))
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly && boundary.requireMonitorDesktop)
  assert.equal(boundary.approveMonitor===true,approve)
  assert.equal(boundary.standingMonitor===true,standing)
  assert.equal(boundary.requireMonitorCancelFeedback===true,cancelFeedback)
  assert.equal(boundary.requireMonitorLifecycle===true,lifecycle)
  assert.equal(boundary.requireMonitorFreshSession===true,freshSession)
  assert.equal(digest(await readFile(executable)),pin)
  const project=join(workspace,'project')
  await mkdir(project)
  await writeFile(join(project,'release-notes.md'),'# Release notes\n\nReview the rollback checklist.\n')
  execFileSync('/usr/bin/git',['init','--quiet','-b','main'],{cwd:project,env:{PATH:'/usr/bin:/bin',HOME:workspace,
    GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000})
  const fixture=await startNativeMonitorFixture(workspace,project,{approve,standing,cancelFeedback,lifecycle,freshSession})
  try {
    const launchEnv={...env,...fixture.account,NODE_EXTRA_CA_CERTS:fixture.tls.ca,ANTHROPIC_BASE_URL:'https://api.anthropic.com',
      DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project}
    for (const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','DISABLE_TELEMETRY','DISABLE_ERROR_REPORTING',
      'DISABLE_GROWTHBOOK','CLAUDE_INTERNAL_FC_OVERRIDES','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC']) delete launchEnv[key]
    await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-native-monitor-approval',journeyBudgetMs:freshSession?165000:125000,
      journey:args=>monitorApproval({...args,fixture,approve,standing,cancelFeedback,lifecycle,freshSession})})
  } finally {
    await fixture.billing.close()
    assert.equal(fixture.billing.state.purchases.length,0)
    assert.equal(fixture.billing.state.adminRequests.length,0)
    await writeFile(join(workspace,'monitor-model-calls.json'),JSON.stringify(fixture.calls,null,2))
    await writeFile(join(workspace,'monitor-evaluation.json'),JSON.stringify(fixture.exchanges,null,2))
  }
}

async function monitorApproval({app,page,output,project,userDataDir,expect,phase,fixture,approve,standing,cancelFeedback,lifecycle,freshSession}) {
  const proof = {status:'running',decision:freshSession?'fresh-session':lifecycle?'lifecycle':cancelFeedback?'cancel-feedback':standing?'standing':approve?'allow':'deny',captures:[]}
  const recovery = fixture.continuation
  const save = () => writeFile(join(output,'monitor-approval.json'),JSON.stringify(proof,null,2))
  const context = () => page.evaluate(()=>{
    const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context
    const view=Object.values(c.nativeTerminalViews).find(entry=>entry.threadId===c.currentThread?.id)
    return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,native:view?.state,
      answer:view?.noticeAnswer,messages:c.currentThread?.messages}
  })
  const card = page.locator('[data-onboarding-id="agent-chat-input"]')
  const composer = card.locator('[contenteditable="true"]')
  const send = card.getByRole('button',{name:'Send',exact:true})
  const region = page.getByRole('region',{name:'Claude native interface',exact:true})
  const panel = page.getByTestId('native-monitor-approval')
  const deny = panel.getByRole('button',{name:'Deny',exact:true})
  const yes = panel.getByRole('button',{name:'Yes',exact:true})
  const cancel = panel.getByRole('button',{name:'Cancel',exact:true})
  const submit = async text => {
    await composer.fill(text)
    await expect(composer).toHaveText(text)
    await send.click({timeout:12000})
  }

  const openConversation = async firstPrompt => {
    await page.evaluate(directory=>{
      const threads=window.applicationState.system.get('default-setup/threads')
      threads.send({type:'VIEW_DASHBOARD'})
      threads.send({type:'NEW_THREAD_IN_PROJECT',directory})
      threads.send({type:'SET_MODE',mode:'Claude Code'})
      threads.send({type:'SET_PHASE',phase:'Edit'})
    },project)
    await expect(composer).toBeVisible({timeout:15000})
    await submit(firstPrompt)
    await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1)
    await region.getByRole('button',{name:'Use native interface',exact:true}).click({timeout:10000})
    const completed = new Set()
    for (let attempt=0;attempt<100;attempt++) {
      if ((await context()).native?.status==='live') break
      const screen=await region.locator('[data-terminal-text]').innerText().catch(()=>'')
      const step=recognizeOnboardingPrompt(screen,project)
      if (step && !completed.has(step)) {
        completed.add(step)
        await region.locator('[aria-label="Terminal input"]').focus()
        await page.waitForTimeout(200)
        await page.keyboard.press(step==='workspace-trust'?'ArrowDown':'Enter')
      }
      await page.waitForTimeout(100)
    }
    await expect.poll(async()=>(await context()).native?.status,{timeout:20000}).toBe('live')
    const initial=await context()
    const owner={threadId:initial.threadId,sessionId:initial.native.sessionId,ownerId:initial.native.ownerId,pid:initial.native.nativePid}
    await region.getByRole('button',{name:'Back to conversation',exact:true}).click({timeout:10000})
    return owner
  }
  const stopSession = async owner => {
    await region.getByRole('button',{name:'Use native interface',exact:true}).click({timeout:10000})
    await region.getByRole('button',{name:'Stop session',exact:true}).click({timeout:10000})
    await expect.poll(()=>readFile('/proc/'+owner.pid+'/stat','utf8').then(text=>!text.includes(') Z '),()=>false),{timeout:15000}).toBe(false)
  }

  try {
    const compiled=JSON.parse(await readFile('/control/producer-pack-inputs.json'))
    for (const file of ['runtime/fe.js','runtime/index.cjs']) {
      assert.equal(digest(await readFile(join(userDataDir,'apack/packs/default-setup',file))),compiled[file])
    }
    await app.waitForSurface('default-setup/threads')
    await app.navigate('host/settings')
    await page.evaluate(()=>{
      const settings=window.applicationState.system.get('host/settings')
      settings.send({type:'TAB.SELECT',tab:'general'})
      settings.send({type:'GENERAL_NAV.SELECT',item:'secrets'})
    })
    await page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..')
      .getByPlaceholder('Path override (auto-detected if empty)').fill(executable)
    await page.waitForTimeout(700)
    await app.navigate('default-setup/threads')
    await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.modes.some(mode=>mode.name==='Claude Code')),{timeout:15000}).toBe(true)
    proof.owner=await openConversation('Read the release checklist.')
    await expect.poll(()=>fixture.exchanges.some(row=>row.enabled),{timeout:12000}).toBe(true)
    await save()

    await submit(prompt)
    await expect(panel).toBeVisible({timeout:22000})
    await expect(deny).toBeEnabled({timeout:12000})
    await expect(yes).toBeEnabled({timeout:12000})
    await expect(panel.getByRole('heading',{name:'Monitor',exact:true})).toBeVisible()
    await expect(panel).toContainText('Watch the disposable release review marker')
    await expect(panel).toContainText(approve?'monitor-execution-marker':'must-not-create-monitor-marker')
    let allow=yes
    if (standing) {
      const select=panel.getByRole('combobox',{name:'Monitor approval choice',exact:true})
      await select.selectOption('yes-apply-suggestions',{timeout:10000})
      const grant=panel.getByTestId('native-tool-permission-choice-description')
      await expect(grant).toContainText(fixture.grantDirectory)
      await expect(grant).toContainText('for this session')
      proof.grant=(await grant.innerText()).trim()
      allow=panel.getByRole('button',{name:'Continue',exact:true})
    }
    for (const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
      await page.setViewportSize(viewport)
      await page.evaluate(()=>document.fonts.ready)
      await expect(panel).toBeInViewport({ratio:0.8})
      await expect(deny).toBeInViewport({ratio:1})
      if (cancelFeedback) await expect(cancel).toBeInViewport({ratio:1})
      await expect(allow).toBeInViewport({ratio:1})
      if (standing) {
        const choice=panel.getByRole('combobox',{name:'Monitor approval choice',exact:true})
        await choice.scrollIntoViewIfNeeded()
        await expect(choice).toBeInViewport({ratio:0.95})
      }
      const name='monitor-approval-'+size+'.png'
      await page.screenshot({path:join(output,name),animations:'disabled'})
      proof.captures.push(name)
    }
    await assert.rejects(readFile(fixture.marker),{code:'ENOENT'})
    await (cancelFeedback?cancel:approve?allow:deny).click({timeout:10000})
    await expect(panel).toBeHidden({timeout:12000})
    await expect.poll(async()=>(await context()).native?.busy,{timeout:20000}).toBe(false)
    if (approve && !lifecycle) {
      await expect.poll(()=>readFile(fixture.marker,'utf8').catch(error=>{if(error.code==='ENOENT')return null;throw error}),{timeout:12000}).toBe('owned monitor fixture\n')
    } else if (!approve) await assert.rejects(readFile(fixture.marker),{code:'ENOENT'})
    const expectedMarker='owned monitor fixture\n'+(standing?'owned monitor reuse\n':'')
    if (standing) {
      await expect.poll(()=>fixture.calls.some(call=>call.result&&!call.result.is_error),{timeout:12000}).toBe(true)
      await submit(fixture.reuse.prompt)
      await expect.poll(()=>readFile(fixture.marker,'utf8'),{timeout:15000}).toBe(expectedMarker)
      await expect(panel).toBeHidden()
      await expect.poll(()=>fixture.calls.some(call=>call.result?.tool_use_id===fixture.reuse.id && !call.result.is_error),{timeout:12000}).toBe(true)
      await expect.poll(async()=>(await context()).native?.busy,{timeout:15000}).toBe(false)
      await submit(fixture.outside.prompt)
      await expect(panel).toBeVisible({timeout:18000})
      await expect(panel).toContainText('monitor-outside-marker')
      await deny.click({timeout:10000})
      await expect(panel).toBeHidden({timeout:12000})
      await expect.poll(async()=>(await context()).native?.busy,{timeout:15000}).toBe(false)
      await assert.rejects(readFile(fixture.outsideMarker),{code:'ENOENT'})
    }
    if (cancelFeedback) {
      await submit(fixture.feedback.prompt)
      await expect(panel).toBeVisible({timeout:18000})
      await expect(panel).toContainText('must-not-create-feedback-marker')
      const toggle=panel.getByRole('button',{name:'Add feedback',exact:true})
      await expect(toggle).toBeEnabled()
      await toggle.click({timeout:10000})
      const field=panel.getByRole('textbox',{name:'Feedback for Claude',exact:true})
      await field.fill(fixture.feedback.reason)
      await expect(field).toHaveValue(fixture.feedback.reason)
      for (const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
        await page.setViewportSize(viewport)
        await field.scrollIntoViewIfNeeded()
        await expect(field).toBeInViewport({ratio:0.9})
        await expect(deny).toBeInViewport({ratio:1})
        const name='monitor-feedback-'+size+'.png'
        await page.screenshot({path:join(output,name),animations:'disabled'})
        proof.captures.push(name)
      }
      await deny.click({timeout:10000})
      await expect(panel).toBeHidden({timeout:12000})
      await expect.poll(async()=>(await context()).native?.busy,{timeout:15000}).toBe(false)
      await assert.rejects(readFile(fixture.feedbackMarker),{code:'ENOENT'})
    }
    if (lifecycle) {
      const activeId = async id => {
        const result = () => fixture.calls.flatMap(call=>call.results).find(row=>row.tool_use_id===id)
        await expect.poll(()=>JSON.stringify(result()??{}),{timeout:10000}).toContain('Monitor started (task ')
        const match = JSON.stringify(result()).match(/Monitor started \(task ([a-zA-Z0-9_-]+),/)
        assert.ok(match)
        assert.equal(Boolean(result().is_error),false)
        return match[1]
      }
      const background=page.getByRole('region',{name:'Background commands',exact:true})
      const rowFor=id=>background.locator('[data-native-shell-id="'+id+'"]')
      const stopId=await activeId('toolu_monitor_owned_review')
      const row=rowFor(stopId)
      const stop=row.getByRole('button',{name:'Stop command',exact:true})
      await expect(stop).toBeEnabled({timeout:8000})
      await expect.poll(()=>readFile(fixture.marker,'utf8').catch(error=>{if(error.code==='ENOENT')return null;throw error}),{timeout:5000}).toBe('started\n')
      for (const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
        await page.setViewportSize(viewport)
        await stop.scrollIntoViewIfNeeded()
        await expect(stop).toBeInViewport({ratio:1})
        const name='monitor-stop-'+size+'.png'
        await page.screenshot({path:join(output,name),animations:'disabled'})
        proof.captures.push(name)
      }
      await stop.click({timeout:5000})
      await expect.poll(async()=>(await context()).native?.tasks?.find(task=>task.id===stopId)?.status,{timeout:10000}).toBe('killed')
      await expect(stop).toBeDisabled()
      proof.stopped={id:stopId,marker:await readFile(fixture.marker,'utf8')}
      await save()

      await submit(fixture.expiry.prompt)
      await expect(panel).toContainText(fixture.expiry.description,{timeout:12000})
      await assert.rejects(readFile(fixture.expiryMarker),{code:'ENOENT'})
      await yes.click({timeout:5000})
      const expiryId=await activeId(fixture.expiry.id)
      assert.notEqual(expiryId,stopId)
      await expect.poll(async()=>(await context()).native?.tasks?.find(task=>task.id===expiryId)?.status,{timeout:10000}).toBe('killed')
      await expect(rowFor(expiryId).getByRole('button',{name:'Stop command',exact:true})).toBeDisabled()
      await expect.poll(()=>fixture.calls.some(call=>call.expiryNotice),{timeout:15000}).toBe(true)
      await expect.poll(async()=>(await context()).native?.busy,{timeout:10000}).toBe(false)
      proof.expired={id:expiryId,marker:await readFile(fixture.expiryMarker,'utf8'),notice:true}
      assert.equal(proof.expired.marker,'started\n')
      await save()
    }
    await submit(recovery)
    await expect.poll(async()=>{
      const c=await context()
      const canonical=c.messages?.some(message=>message.sender==='user' && message.text===recovery && message.context?.cliUuid)
      return canonical && fixture.calls.some(call=>call.recovery) && c.native?.busy===false && c.claude?.chatState==='success'
    },{timeout:20000}).toBe(true)
    const current=await context()
    assert.equal(current.threadId,proof.owner.threadId)
    assert.equal(current.native.sessionId,proof.owner.sessionId)
    assert.equal(current.native.ownerId,proof.owner.ownerId)
    const humans=current.messages.filter(message=>message.sender==='user' && message.text===recovery)
    assert.equal(humans.length,1)
    assert.ok(humans[0].context?.cliUuid)
    proof.followup={sessionId:current.native.sessionId,cliUuid:humans[0].context.cliUuid}
    assert.ok(fixture.calls.some(call=>call.request && call.tools.includes('Monitor')))
    const result=fixture.calls.flatMap(call=>call.results).find(row=>row.tool_use_id==='toolu_monitor_owned_review')
    if (cancelFeedback) {
      const feedback=fixture.calls.find(call=>call.result?.tool_use_id===fixture.feedback.id)?.result
      assert.ok(feedback?.is_error && JSON.stringify(feedback.content).includes(fixture.feedback.reason))
      proof.feedback=feedback
      assert.equal(fixture.calls.filter(call=>call.request).length,2)
      await assert.rejects(readFile(fixture.feedbackMarker),{code:'ENOENT'})
    }
    assert.ok(result)
    assert.equal(Boolean(result.is_error),!approve)
    proof.result=result
    if (standing) {
      const outside=fixture.calls.find(call=>call.result?.tool_use_id===fixture.outside.id)?.result
      assert.ok(outside?.is_error)
      proof.outside=outside
    }
    if (approve) assert.equal(await readFile(fixture.marker,'utf8'),lifecycle?'started\n':expectedMarker)
    else await assert.rejects(readFile(fixture.marker),{code:'ENOENT'})
    await stopSession(proof.owner)
    if (freshSession) {
      const second=await openConversation('Open a fresh release-review conversation.')
      assert.ok(second.threadId && second.sessionId && second.ownerId && second.pid)
      assert.notEqual(second.threadId,proof.owner.threadId)
      assert.notEqual(second.sessionId,proof.owner.sessionId)
      assert.notEqual(second.ownerId,proof.owner.ownerId)
      proof.fresh={owner:second}
      await save()

      await submit(fixture.fresh.prompt)
      await expect(panel).toBeVisible({timeout:22000})
      await expect(panel).toContainText('monitor-execution-marker')
      await expect(deny).toBeEnabled({timeout:12000})
      assert.equal(await readFile(fixture.marker,'utf8'),expectedMarker)
      const name='monitor-fresh-session-compact.png'
      await expect(deny).toBeInViewport({ratio:1})
      await page.screenshot({path:join(output,name),animations:'disabled'})
      proof.captures.push(name)
      await deny.click({timeout:10000})
      await expect(panel).toBeHidden({timeout:12000})
      await expect.poll(async()=>(await context()).native?.busy,{timeout:15000}).toBe(false)
      await submit(fixture.fresh.continuation)
      await expect.poll(async()=>{
        const c=await context()
        return c.messages?.some(msg=>msg.sender==='user'&&msg.text===fixture.fresh.continuation&&msg.context?.cliUuid)
          && fixture.calls.some(call=>call.freshRecovery) && c.native?.busy===false
      },{timeout:20000}).toBe(true)
      const after=await context()
      assert.equal(after.native.sessionId,second.sessionId)
      assert.equal(after.native.ownerId,second.ownerId)
      const followups=after.messages.filter(msg=>msg.sender==='user'&&msg.text===fixture.fresh.continuation)
      assert.equal(followups.length,1)
      proof.fresh.followup=followups[0].context.cliUuid
      const secondResult=fixture.calls.flatMap(call=>call.results).find(row=>row.tool_use_id===fixture.fresh.id)
      assert.ok(secondResult?.is_error)
      proof.fresh.result=secondResult
      await stopSession(second)
    }
    if (approve) proof.marker=await readFile(fixture.marker,'utf8')
    if (approve) assert.equal(proof.marker,lifecycle?'started\n':expectedMarker)
    if (lifecycle) assert.equal(await readFile(fixture.expiryMarker,'utf8'),'started\n')
    proof.status='complete'
    phase('native-monitor-approval-complete')
  } catch (error) {
    proof.status='failed'
    proof.error=error.message
    proof.observed=await context().catch(()=>null)
    throw error
  } finally {
    await save()
  }
}
