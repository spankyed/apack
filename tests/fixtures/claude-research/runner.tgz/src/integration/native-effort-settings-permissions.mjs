import assert from 'node:assert/strict';
import {lstat,readFile,writeFile,rename,chown,chmod} from 'node:fs/promises';
import {join} from 'node:path';

/** Deny the disposable native writer real OS access; never patch native writer/eligibility code. */
export async function serveNativeEffortSettingsPermissions(workspace){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),0);
 assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-effort[0-9]+$/);
 const request=join(workspace,'effort-settings-protect.request'),release=join(workspace,'effort-settings-release.request'),statePath=join(workspace,'effort-settings-permissions.json');
 const config=join(workspace,'app-data/claude-code-profile/config'),settings=join(config,'settings.json');
 let interrupted=false;process.once('SIGTERM',()=>{interrupted=true});
 const wait=async path=>{for(let i=0;i<6000;i++){assert.ok(!interrupted,'Disposable settings permission helper cancelled');try{const s=await lstat(path);assert.ok(s.isFile()&&!s.isSymbolicLink());return}catch(e){if(e.code!=='ENOENT')throw e}await new Promise(r=>setTimeout(r,50))}throw Error('Disposable settings permission handshake expired')};
 const record=async value=>{const temporary=statePath+'.tmp';await writeFile(temporary,JSON.stringify(value),{flag:'wx',mode:0o644});await rename(temporary,statePath)};
 await wait(request);
 for(const path of [workspace,join(workspace,'app-data'),join(workspace,'app-data/claude-code-profile'),config]){const s=await lstat(path);assert.ok(s.isDirectory()&&!s.isSymbolicLink());assert.equal(s.uid,1000)}
 const file=await lstat(settings),directory=await lstat(config);assert.ok(file.isFile()&&!file.isSymbolicLink());assert.equal(file.uid,1000);
 const before=await readFile(settings);let protectedFile=false;
 try{
  await chown(settings,0,0);protectedFile=true;await chmod(settings,0o444);
  // The sticky directory still permits this user to update its own global config,
  // but refuses replacing the root-owned settings file through atomic rename.
  await chown(config,0,0);await chmod(config,0o1777);
  await record({status:'protected',settingsUid:0,settingsMode:0o444,directoryUid:0,directoryMode:0o1777,globalConfigUid:(await lstat(join(config,'.claude.json'))).uid});
  await wait(release);assert.deepEqual(await readFile(settings),before,'Failed write must leave settings bytes unchanged');
 }finally{
  if(protectedFile){await chown(settings,file.uid,file.gid);await chmod(settings,file.mode&0o7777);await chown(config,directory.uid,directory.gid);await chmod(config,directory.mode&0o7777);await record({status:'restored',settingsUid:(await lstat(settings)).uid,settingsMode:(await lstat(settings)).mode&0o7777,directoryUid:(await lstat(config)).uid,directoryMode:(await lstat(config)).mode&0o7777,settingsBytesUnchanged:(await readFile(settings)).equals(before)})}
 }
}
