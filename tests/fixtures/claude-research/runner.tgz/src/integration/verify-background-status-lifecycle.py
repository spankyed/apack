"""Audit original child reload, controlled socket interruption and recovery from saved app records."""
from pathlib import Path
import argparse,json,re,subprocess,sys
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence',type=Path);parser.add_argument('product_checkout',type=Path)
parser.add_argument('--commit');parser.add_argument('--research-commit')
args=parser.parse_args();evidence=args.evidence.resolve()
command=[sys.executable,str(Path(__file__).with_name('verify-background-status.py')),str(evidence),str(args.product_checkout),'--capture-profile','lifecycle']
for name,value in [('--commit',args.commit),('--research-commit',args.research_commit)]:
 if value:command.extend([name,value])
subprocess.run(command,check=True,stdout=subprocess.DEVNULL)
paths=list((evidence/'records/workspaces').glob('*/native-background-app-observation.json'));assert len(paths)==1
workspace=paths[0].parent;state=json.loads(paths[0].read_text());life=state['childStatusLifecycle'];job=state['job']
assert life['restored']and life['worker']['start']==state['childReply']['workerBefore']['start']and life['worker']['state']!='Z'
wire=[json.loads(line)for line in (workspace/'background-broker-audit.jsonl').read_text().splitlines()if line]
assert wire[:len(life['brokerRows'])]==life['brokerRows']and len(wire)<1024
for row in wire:
 assert set(row)=={'at','pid','path','status','leaseHash'}
 assert row['leaseHash']is None or re.fullmatch('[a-f0-9]{64}',row['leaseHash'])
http=[json.loads(path.read_text())for path in workspace.glob('native-background-http-'+job['sessionId']+'-*.json')]
assert 1<len(http)<100
for row in http:
 assert row['sessionId']==job['sessionId']and row['pid']==job['pid'];assert not(set(row)&{'token','headers','body'})
reloads=[]
for key in ['firstReload','recovery']:
 step=life[key];before,after=step['before'],step['after'];assert before in wire and after in wire
 assert before['leaseHash']!=after['leaseHash']and before['at']<after['at']and before['pid']==after['pid']
 info=step['info'];assert info['sessionId']==job['sessionId']and info['jobId']==job['id']and info['pid']==job['pid']and info['observedAt']>after['at']
 change=step['moduleChange'];assert change['commentOnly']and change['beforeSha256']!=change['afterSha256']
 posts=sorted((row for row in http if row['at']>=after['at']and row['path'].endswith('/background-status')),key=lambda row:row['at']);assert posts and posts[0]['sequence']==1
 assert any(row['path']=='/background-status'and row['status']==200 and posts[0]['at']<=row['at']<=info['observedAt']+100 for row in wire)
 reloads.append({'newLeaseHash':after['leaseHash'],'firstPublishedSequence':posts[0]['sequence'],'sameWorker':True,'freshStatusObservedAt':info['observedAt'],'commentOnlyOwnedModuleRefresh':True})
cut=life['disconnected'];assert cut['infoRetired']and cut['worker']['start']==life['worker']['start']and cut['worker']['state']!='Z'
canonical=lambda rows:sorted(json.dumps(row,sort_keys=True)for row in rows)
assert canonical(cut['httpBefore'])==canonical(cut['httpAfter'])
assert all(row in http for row in cut['httpBefore'])
assert cut['checkedAt']-cut['quietAt']>=2200
assert any(row['at']>=cut['at']and row['path'].endswith('/background-status')for row in cut['httpBefore'])
assert not any(cut['quietAt']<row['at']<=cut['checkedAt']for row in http)
assert life['recovery']['after']['at']>cut['checkedAt']
assert life['parent']['messages']==state['childReply']['parentBefore']['messages']
assert life['parent']['claude']['totalCostUsd']==state['childReply']['parentBefore']['claude']['totalCostUsd']
journals=list((workspace/'.claude/projects').glob('*/'+job['sessionId']+'.jsonl'));assert len(journals)==1
rows=[json.loads(line)for line in journals[0].read_text().splitlines()if line]
commands=[row for row in rows if row.get('type')=='user'and '<command-name>/reload-plugins</command-name>'in str(row.get('message',{}).get('content'))]
assert len(commands)==2 and all('<command-args>--force</command-args>'in row['message']['content']for row in commands)
report=json.loads((evidence/'background-status-verification.json').read_text())
report.update({'lifecycle':{'originalReloadCommands':2,'reloads':reloads,'nativeHttpAttemptsObserved':len(http),'quietAfterDisconnectMs':cut['checkedAt']-cut['quietAt'],'sameWorkerThroughSocketLossAndRecovery':True,'parentHistoryAndCostPreserved':True,'uiUsageRetired':True,'originalStopRetiredWorker':True},'scope':'Original same-worker hook reload/counter recovery, controlled broker-socket loss with pooled-connection cut, observed publication quiescence and explicit original reload recovery. No full API/app restart, independent child broker lifetime, managed-policy, multiple-window, pending-registration race, rich/media/drawing/action or combined F1–F5 acceptance.'})
(evidence/'background-status-lifecycle-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
