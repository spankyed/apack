import assert from 'node:assert/strict';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';
import { createHash } from 'node:crypto';
import { readFile, realpath } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// Launch this script with the isolated worktree's tsx loader and a minimal environment.
const [checkoutArg, executableArg, workspaceArg] = process.argv.slice(2);
if (!checkoutArg || !executableArg || !workspaceArg) {
  throw new Error('Expected isolated-apack-worktree, pinned-Claude-executable, disposable-workspace');
}
const checkout = await realpath(checkoutArg);
const primary = await realpath('/Users/spankyed/Develop/Projects/AgentBuddy');
assert.notEqual(checkout, primary, 'Refusing to load product code from the shared primary checkout');
const executable = resolve(executableArg);
const workspace = resolve(workspaceArg);
assert.equal(process.env.HOME, workspace, 'Use an isolated HOME for the probe');
assert.equal(process.env.CLAUDE_CODE_SIMPLE, '1', 'Bare-mode environment is required for this probe');
for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN']) {
  assert.equal(process.env[key], undefined, `Do not supply credentials: ${key}`);
}
const { query } = await import(pathToFileURL(join(checkout,
  'packages/default-setup/src/features/code/be/services/claude-code/query.ts')).href);
const model = await startSyntheticModel(workspace, 'ExitPlanMode');
let hookCount = 0;
let handle, contextWhilePermissionPending = false, permissionCount = 0, bypassDuringPermissionCallback = false;
try {
  handle = await query({ cliPath: executable, cwd: workspace, env: {
    PATH: process.env.PATH, HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'),
    CLAUDE_CODE_SIMPLE: undefined, ENABLE_TOOL_SEARCH: 'true', ANTHROPIC_BASE_URL: model.url,
    DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1',
  }, tools: 'default', strictMcpConfig: true, noSessionPersistence: true,
  settings: JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' }), settingSources: [],
  permissionMode: 'plan', allowDangerouslySkipPermissions: true, model: 'claude-sonnet-4-6', maxTurns: 3,
  signal: AbortSignal.timeout(20000),
  onPermissionRequest: async request => {
    permissionCount++;
    const context = await handle.getContextUsage();
    assert.ok(context.maxTokens > 0);
    contextWhilePermissionPending = true;
    assert.equal(request.tool_name, 'ExitPlanMode');
    return { behavior: 'allow', updatedInput: request.input };
  } });
  const initialized = await handle.initialized;
  assert.equal(initialized.current_permission_mode, 'plan');
  handle.send('Create fixture.txt with literal content synthetic protocol fixture.');
  for await (const event of handle.events) { if (event.type === 'result') break; }
  await handle.result;
  assert.equal(permissionCount, 1);
  assert.equal(contextWhilePermissionPending, true);
  assert.equal(model.calls.length, 3);
  assert.ok(model.calls[0].toolNames.includes('ToolSearch'));
  assert.ok(!model.calls[0].toolNames.includes('ExitPlanMode'));
  assert.ok(model.calls[1].toolNames.includes('ExitPlanMode'));
  console.log(JSON.stringify({ evidence: 'apack-native-tool-search',
    targetSha256: createHash('sha256').update(await readFile(executable)).digest('hex'),
    checkout, version: initialized.claude_code_version, permissionCount, contextWhilePermissionPending, bypassDuringPermissionCallback,
    deferredThenLoaded: true, syntheticApiRequests: model.calls.length, realModelRequests: 0, userPromptsSent: 1,
    qualification: 'Actual CLI and product wrapper against a local synthetic model API; no real model.' }));
} finally {
  try { if (handle) await handle.close(); } finally { await model.close(); }
}
