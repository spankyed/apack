import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,lstat,mkdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {driveChildComposer} from './apack-child-composer-drive.mjs';
import {prepareCombinedEverydayProfile} from './combined-everyday-profile.mjs';
const sha=data=>createHash('sha256').update(data).digest('hex');
async function processStart(pid){try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return fields[0]==='Z'?undefined:fields[19]}catch(error){if(error.code==='ENOENT')return;throw error}}

/** Real everyday screens; captures/geometry are observations until individually reviewed. */
export async function driveEverydayLayout(options){
 const output=join(options.workspace,'electron-results');await mkdir(output,{recursive:true});const profile=await prepareCombinedEverydayProfile(options);
 try{await driveChildComposer({...options,modelRequestLimit:12,modelOptions:{textReply:'The release review is ready. I can check the checklist next.'},journey:args=>layoutJourney({...args,profile}),journeyName:'everyday-layout'});}
 finally{await profile.restore();await writeFile(join(output,'combined-agent-restoration.json'),await readFile(join(options.workspace,'combined-agent-restoration.json')));await writeFile(join(output,'status-helper.mjs'),await readFile(profile.helper));for(const name of ['before','after','restored'])await writeFile(join(output,'combined-settings-'+name+'.json'),await readFile(join(options.workspace,'combined-settings-'+name+'.json')));}
}
async function layoutJourney({app,page,electronApp,output,project,userDataDir,expect,phase,profile}){
 await app.waitForSurface('default-setup/threads');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.modes.some(mode=>mode.name==='Claude Code');}),{timeout:15000}).toBe(true);
 await app.navigate('host/settings');await page.evaluate(()=>{const a=window.applicationState.system.get('host/settings');a.send({type:'FEATURE.SELECT',featureId:'default-setup/code'});a.send({type:'TAB.SELECT',tab:'features'});});await expect(page.locator('#claude-profile')).toHaveValue('app');await app.navigate('default-setup/threads');
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !!c.currentThread?.id&&c.tabs.every(tab=>c.tabsRead.includes(tab.id));}),{timeout:15000}).toBe(true);
 await page.evaluate(()=>window.applicationState.system.get('default-setup/threads').send({type:'VIEW_DASHBOARD'}));await page.evaluate(project=>window.applicationState.system.get('default-setup/threads').send({type:'NEW_THREAD_IN_PROJECT',directory:project}),project);
 await expect.poll(()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return !c.currentThread?.id&&c.pendingThreadCwd;})).toBe(project);
 await page.evaluate(()=>{const a=window.applicationState.system.get('default-setup/threads');a.send({type:'SET_MODE',mode:'Claude Code'});a.send({type:'SET_PHASE',phase:'Edit'});});
 const context=()=>page.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id),ui:Object.values(c.nativeUiViews).find(v=>v.threadId===c.currentThread?.id)};});
 const card=page.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]'),send=card.getByRole('button',{name:'Send',exact:true}),section=page.getByRole('region',{name:'Claude native interface',exact:true});
 await composer.fill('Help me review the release notes and checklist.');await send.click();await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1);
 await section.getByRole('button',{name:'Use native interface',exact:true}).click();await expect.poll(async()=>(await context()).native?.state?.status,{timeout:25000}).toBe('live');const initial=await context(),pid=initial.native.state.nativePid,start=await processStart(pid);assert.ok(start);
 await section.getByRole('button',{name:'Back to conversation',exact:true}).click();await expect(composer).toBeVisible();
 let initialUiRecovery;
 await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toMatch(/^(live|error)$/);
 if((await context()).ui?.state?.status==='error'){
  const before=await context();initialUiRecovery={before};await writeFile(join(output,'initial-ui-recovery.json'),JSON.stringify(initialUiRecovery,null,2));
  await card.getByRole('button',{name:'Reconnect controls',exact:true}).click({timeout:5000});
  await expect.poll(async()=>(await context()).ui?.state?.status,{timeout:25000}).toBe('live');
  const after=await context();assert.equal(after.native.state.nativePid,pid);assert.equal(after.native.state.sessionId,initial.native.state.sessionId);assert.equal(after.native.state.ownerId,before.native.state.ownerId);assert.equal(await processStart(pid),start);
  initialUiRecovery.after=after;await writeFile(join(output,'initial-ui-recovery.json'),JSON.stringify(initialUiRecovery,null,2));
 }
 await expect.poll(async()=>(await context()).native?.state?.mainStatus,{timeout:15000}).toContain('Release review');
 const window=await electronApp.browserWindow(page);await window.evaluate(w=>{w.show();w.focus();});await expect.poll(()=>page.evaluate(()=>document.hasFocus())).toBe(true);
 const draft='Keep the release checklist wording unchanged.',selectionTrace=[];
 const traceSelection=async label=>{selectionTrace.push({label,...await composer.evaluate(el=>{const s=getSelection();return {text:el.textContent,focused:document.activeElement===el,documentFocused:document.hasFocus(),selected:s?.toString(),anchor:s?.anchorOffset,focus:s?.focusOffset,anchorInside:el.contains(s?.anchorNode),focusInside:el.contains(s?.focusNode)};})});await writeFile(join(output,'selection-setup.json'),JSON.stringify(selectionTrace,null,2));};
 await composer.fill(draft);await traceSelection('filled');await composer.press('Home');await traceSelection('home');for(let i=0;i<5;i++)await composer.press('ArrowRight');await traceSelection('position-five');for(let i=0;i<12;i++)await composer.press('Shift+ArrowRight');await traceSelection('selected');await expect.poll(()=>composer.evaluate(()=>window.getSelection()?.toString())).toBe('the release ');
 const proof={status:'capturing',initialUiRecovery,scope:'Everyday workspace/header, native composer/status and retained draft only. Screenshots require independent visual review; no Agent/tool/rollout/full-parity acceptance.',sessionId:initial.claude.sessionId,pid,processStart:start,captures:[],geometry:[],visualAcceptance:false,readingSpaceRequired:true,expectedDraft:draft,expectedSelection:'the release ',helperSha256:profile.helperSha256,panelSizesBefore:await page.evaluate(()=>window.applicationState.getSnapshot().context.panelSizes)};
 const save=()=>writeFile(join(output,'everyday-layout.json'),JSON.stringify(proof,null,2));
 try{
  for(const size of [{name:'normal',width:1100,height:900},{name:'compact',width:680,height:600}]){
   await page.setViewportSize({width:size.width,height:size.height});await expect(composer).toHaveText(draft);await expect(send).toBeVisible();await expect(send).toBeEnabled();
   await composer.focus();await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
   await expect.poll(()=>page.locator('[data-testid="chat-transcript"] > div').first().evaluate(element=>element.clientHeight),{timeout:5000}).toBeGreaterThanOrEqual(96);
   const toolbar=page.locator('.bubble-menu:visible');await expect(toolbar).toHaveCount(1);await expect(toolbar).toBeVisible();
   const status=card.getByTestId('composer-native-status');await expect(status).toHaveText('Release review\nChecklist and migration notes');
   await expect.poll(()=>status.evaluate(el=>{const r=el.getBoundingClientRect();return [8,r.height-8].every(dy=>el.contains(document.elementFromPoint(r.x+24,r.y+dy)));}),{timeout:5000}).toBe(true);
   await expect.poll(()=>toolbar.evaluate(el=>{const r=el.getBoundingClientRect(),s=getSelection();if(!s?.rangeCount)return false;const selected=s.getRangeAt(0).getBoundingClientRect();return r.bottom<=selected.y||r.y>=selected.bottom;}),{timeout:5000}).toBe(true);
   const toolbarReading=await toolbar.evaluate(el=>{const r=el.getBoundingClientRect(),selection=getSelection(),selected=selection?.rangeCount?selection.getRangeAt(0).getBoundingClientRect():null;return {bounds:{x:r.x,y:r.y,right:r.right,bottom:r.bottom},selection:selected?{x:selected.x,y:selected.y,right:selected.right,bottom:selected.bottom}:null,controls:[...el.querySelectorAll('button')].filter(b=>b.getBoundingClientRect().width>0).map(b=>{const p=b.getBoundingClientRect();return {label:b.getAttribute('aria-label')||b.title||b.textContent,reachable:b.contains(document.elementFromPoint(p.x+p.width/2,p.y+p.height/2))};})};});
   assert.ok(toolbarReading.selection);assert.ok(toolbarReading.bounds.bottom<=toolbarReading.selection.y||toolbarReading.bounds.y>=toolbarReading.selection.bottom);assert.ok(toolbarReading.controls.length&&toolbarReading.controls.every(c=>c.reachable));

   const hintReading=await card.locator('[aria-label="Native keyboard hint"]').evaluateAll(elements=>elements.map(element=>{
    const walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT),characters=[];let node;
    while(node=walker.nextNode())for(let index=0;index<node.textContent.length;index++){
     if(!node.textContent[index].trim())continue;const range=document.createRange();range.setStart(node,index);range.setEnd(node,index+1);
     for(const rect of range.getClientRects())if(rect.width&&rect.height)characters.push({x:rect.x,y:rect.y,right:rect.right,bottom:rect.bottom,reachable:element.contains(document.elementFromPoint(rect.x+rect.width/2,rect.y+rect.height/2))});
    }
    return {text:element.textContent,characters};
   }));
   if(process.env.CLAUDE_RESEARCH_TOOLBAR_HINT==='1')assert.ok(hintReading.length&&hintReading.every(h=>h.characters.length&&h.characters.every(c=>c.reachable)),'Formatting must leave every native shortcut-hint character readable');

   const geometry=await page.evaluate(()=>{
    const rect=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom}};
    const controls=[...document.querySelectorAll('button,input,[role="tab"]')].filter(e=>{const s=getComputedStyle(e),r=e.getBoundingClientRect();return s.visibility!=='hidden'&&s.display!=='none'&&r.width>0&&r.height>0}).map(e=>{
     const r=rect(e),clips=[];let p=e.parentElement;while(p){const s=getComputedStyle(p),b=p.getBoundingClientRect();if(['hidden','auto','scroll','clip'].includes(s.overflowX)&&(r.x<b.left-1||r.right>b.right+1)||['hidden','auto','scroll','clip'].includes(s.overflowY)&&(r.y<b.top-1||r.bottom>b.bottom+1))clips.push({tag:p.tagName,classes:p.className,rect:rect(p),overflowX:s.overflowX,overflowY:s.overflowY});p=p.parentElement}
     return {name:(e.getAttribute('aria-label')||e.getAttribute('title')||e.getAttribute('placeholder')||e.textContent||'').trim().slice(0,200),tag:e.tagName,rect:r,clippedBy:clips,disabled:e.disabled===true};
    });const history=document.querySelector('[data-testid="chat-transcript"] > div'),editor=document.querySelector('[data-onboarding-id="agent-chat-input"] [contenteditable="true"]');return {viewport:{width:innerWidth,height:innerHeight},document:{width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight},controls,history:rect(history),draft:editor.textContent,selection:window.getSelection()?.toString()};
   });
   const name='everyday-layout-'+size.name+'.png';await page.screenshot({path:join(output,name)});proof.captures.push(name);proof.geometry.push({size:size.name,...geometry,toolbarReading,hintReading,statusReadableWhileSelecting:true});await save();phase('everyday-layout-captured',{size:size.name});
   assert.equal(geometry.draft,draft);assert.equal(geometry.selection,'the release ');
   if(size.name==='compact'){
    const trigger=page.getByRole('button',{name:'Open Claude session details',exact:true});await expect(trigger).toBeVisible();await trigger.click();
    const details=page.locator('[aria-label="Claude session details"]');await expect(details).toBeVisible();const model=(await context()).claude.model;await expect(details).toContainText(model);await details.locator('summary').first().click();await expect(details.getByTitle('Copy session id',{exact:true})).toBeVisible();
    const bounds=await details.boundingBox();assert.ok(bounds&&bounds.x>=0&&bounds.y>=0&&bounds.x+bounds.width<=size.width&&bounds.y+bounds.height<=size.height);
    const detailsCapture='everyday-layout-session-details-compact.png';await page.screenshot({path:join(output,detailsCapture)});proof.details={bounds,model,capture:detailsCapture};
    await details.getByRole('button',{name:'Close Claude session details',exact:true}).click();await expect(details).toBeHidden();await composer.focus();await expect(composer).toHaveText(draft);proof.details.selectionAfter=await composer.evaluate(()=>window.getSelection()?.toString());assert.equal(proof.details.selectionAfter,'the release ');
    const nativeStatus=card.getByTestId('composer-native-status');await expect(nativeStatus).toHaveText('Release review\nChecklist and migration notes');
    await expect.poll(()=>nativeStatus.evaluate(el=>{const r=el.getBoundingClientRect();return [8,r.height-8].every(dy=>el.contains(document.elementFromPoint(r.x+24,r.y+dy)));}),{timeout:5000}).toBe(true);
    proof.details.statusReadableAfterReturn=true;proof.details.returnCapture='everyday-layout-session-return-compact.png';await page.screenshot({path:join(output,proof.details.returnCapture)});await save();
   }

  }
  proof.panelSizesAfter=await page.evaluate(()=>window.applicationState.getSnapshot().context.panelSizes);assert.deepEqual(proof.panelSizesAfter,proof.panelSizesBefore);
  proof.beforeStop=await context();assert.equal(proof.beforeStop.claude.sessionId,proof.sessionId);assert.equal(proof.beforeStop.native.state.nativePid,pid);await expect(composer).toHaveText(draft);
  await section.getByRole('button',{name:'Use native interface',exact:true}).click();await section.getByRole('button',{name:'Stop session',exact:true}).click();await expect.poll(()=>processStart(pid),{timeout:15000}).not.toBe(start);proof.nativeWriterRetired=true;
  const root=join(userDataDir,'claude-code-profile/config/projects'),names=await readdir(root,{recursive:true}),matches=names.filter(n=>basename(n)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);const journal=await readFile(join(root,matches[0]));await writeFile(join(output,'native-parent-transcript.jsonl'),journal);proof.journalSha256=sha(journal);const records=journal.toString().split('\n').filter(Boolean).map(JSON.parse);proof.humanMessages=records.filter(r=>r.type==='user'&&!r.isMeta&&!r.isVirtual&&typeof r.message?.content==='string'&&(r.origin===undefined||r.origin.kind==='human'));assert.equal(proof.humanMessages.length,1);assert.equal(proof.humanMessages[0].message.content,'Help me review the release notes and checklist.');proof.persistedCost=records.filter(r=>r.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(proof.persistedCost,proof.beforeStop.claude.totalCostUsd);
  proof.helperInvocations=await profile.invocations();assert.ok(proof.helperInvocations.some(r=>r.kind==='main'&&r.stdout==='Release review\nChecklist and migration notes\n'));assert.ok((await Promise.all(proof.helperInvocations.map(r=>processStart(r.pid)))).every((value,i)=>value!==proof.helperInvocations[i].start));proof.helperWritersRetired=true;proof.status='complete';await save();
 }catch(error){proof.error={name:error.name,message:error.message.slice(0,2000)};await page.screenshot({path:join(output,'everyday-layout-failure.png')}).catch(()=>{});await save();throw error}
}
