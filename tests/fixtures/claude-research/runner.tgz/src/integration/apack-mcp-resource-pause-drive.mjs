import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs';
import { liveOriginals, processStart } from './native-process-state.mjs';
import { heldResourceList, heldResourceRead, resourceText } from '../protocol/mcp-resource-fixture.mjs';
import { configureNativeCreditAccount } from '../protocol/native-credit-account.mjs';
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs';
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs';
import { startSyntheticModel } from '../protocol/synthetic-model.mjs';

const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const readJsonl = text => text.split('\n').filter(Boolean).map(line => JSON.parse(line));
const readReceipts = async path => readJsonl(await readFile(path, 'utf8').catch(error => {
  if (error.code === 'ENOENT') return '';
  throw error;
}));

export async function driveMcpResourcePause({ checkout, workspace, env }) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-everyday[0-9]+$/);
  assert.equal(sha(await readFile('/frozen-claude/claude')), '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
  const stopHeldRead = env.CLAUDE_RESEARCH_MCP_STOP_HELD_READ === '1';
  const verifyPauseControls = env.CLAUDE_RESEARCH_MCP_PAUSE_CONTROLS === '1';
  assert.ok(!verifyPauseControls || stopHeldRead, 'Pause control verification requires the stalled-read Stop journey');
  const holdRead = stopHeldRead || env.CLAUDE_RESEARCH_MCP_HOLD_READ === '1';
  const project = join(workspace, 'project');
  const output = join(workspace, 'electron-results');
  await mkdir(project);
  execFileSync('/usr/bin/git', ['init', '--quiet', project], {
    env: { PATH: '/usr/bin:/bin', HOME: workspace, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_NOSYSTEM: '1' }, timeout: 5000
  });
  const account = await configureNativeCreditAccount(workspace, 'oauth', { featureCache: 'native-defaults' });
  const configPath = join(workspace, '.claude/.claude.json'), settingsPath = join(workspace, '.claude/settings.json');
  const baselineConfig = await readFile(configPath);
  await writeFile(settingsPath, JSON.stringify({ theme: 'dark', model: 'opus' }));
  const baselineSettings = await readFile(settingsPath);
  const config = JSON.parse(baselineConfig);
  assert.ok(!Object.hasOwn(config.mcpServers ?? {}, 'research'));
  const peer = { receipts: join(workspace, 'mcp-receipts.jsonl'), exits: join(workspace, 'mcp-exits.jsonl'), hold: join(workspace, 'list-response') };
  config.hasCompletedOnboarding = true;
  config.mcpServers = { ...config.mcpServers, research: {
    type: 'stdio', command: process.execPath, args: [new URL('../protocol/synthetic-mcp-resource-server.mjs', import.meta.url).pathname],
    env: { APACK_MCP_RECEIPT: peer.receipts, APACK_MCP_EXITS: peer.exits, APACK_MCP_RESOURCE_HOLD: peer.hold, ...(holdRead ? { APACK_MCP_RESOURCE_HOLD_READ: '1' } : {}) }
  }};
  await writeFile(configPath, JSON.stringify(config));
  let model, billing;
  const proof = { status: 'running', captures: [] };
  try {
    model = await startSyntheticModel(workspace, 'ListMcpResourcesTool', { captureMessages: true, maxRequests: 12, mcpResources: true, mcpResourcePause: holdRead ? 'read' : 'list' });
    const tls = await prepareNativeCreditTls(join(workspace, 'account-tls'));
    billing = await startNativeCreditBilling(tls, { allowMutations: false, evidencePath: join(workspace, 'account-live.json') });
    const launchEnv = { ...env, ...account, NODE_EXTRA_CA_CERTS: tls.ca, ANTHROPIC_BASE_URL: model.url,
      DISABLE_AUTOUPDATER: '1', PATH: '/frozen-claude:' + env.PATH, CLAUDE_RESEARCH_PROJECT: project };
    delete launchEnv.ANTHROPIC_API_KEY;
    await driveFreshNativeApp({ checkout, workspace, env: launchEnv, route: 'real-Electron-mcp-resource-pause',
      journeyBudgetMs: 150000, journey: args => run({ ...args, model, peer, proof, holdRead, stopHeldRead, verifyPauseControls }) });
  } finally {
    await mkdir(output, { recursive: true });
    await model?.close();
    await billing?.close();
    if (model) await writeFile(join(workspace, 'model-calls.json'), JSON.stringify(model.calls, null, 2));
    let originals, livePeers;
    for (let attempt = 0; attempt < 120; attempt++) {
      originals = await liveOriginals();
      const seen = new Map((await readReceipts(peer.receipts)).map(row => [row.pid, row.start]));
      livePeers = [];
      for (const [pid, start] of seen) if (start && await processStart(pid) === start) livePeers.push(pid);
      if (!originals.length && !livePeers.length) break;
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    await writeFile(join(output, 'writer-retirement.json'), JSON.stringify({ originals, livePeers }));
    assert.deepEqual(originals, []);
    assert.deepEqual(livePeers, []);
    if (proof.session) {
      const directory = join(workspace, '.claude/projects');
      const files = (await readdir(directory, { recursive: true })).filter(file => basename(file) === proof.session + '.jsonl');
      assert.equal(files.length, 1);
      await writeFile(join(output, 'native-transcript.jsonl'), await readFile(join(directory, files[0])));
    }
    await writeFile(configPath, baselineConfig);
    assert.deepEqual(await readFile(configPath), baselineConfig);
    assert.deepEqual(await readFile(settingsPath), baselineSettings);
    await writeFile(join(output, 'profile-restoration.json'), JSON.stringify({ restored: true, configSha256: sha(baselineConfig), settingsSha256: sha(baselineSettings) }));
  }
}

async function run({ app, page, electronApp, output, project, userDataDir, expect, phase, model, peer, proof, holdRead, stopHeldRead, verifyPauseControls }) {
  const scenario = holdRead ? heldResourceRead : heldResourceList;
  const kind = holdRead ? 'read' : 'list';
  const heldEvent = 'held-resource-' + kind, releasedEvent = 'released-resource-' + kind, expiredEvent = 'expired-resource-' + kind;
  proof.kind = kind;
  if (stopHeldRead) proof.stopHeldRead = true;
  page.setDefaultTimeout(10000);
  const installed = join(userDataDir, 'apack/packs/default-setup');
  const producers = JSON.parse(await readFile('/control/producer-pack-inputs.json'));
  for (const file of ['runtime/fe.js', 'runtime/index.cjs']) assert.equal(sha(await readFile(join(installed, file))), producers[file]);

  const context = () => page.evaluate(() => {
    const threads = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
    return { thread: threads.currentThread?.id, claude: threads.currentThread?.context?.claudeCode,
      messages: threads.currentThread?.messages,
      native: Object.values(threads.nativeTerminalViews).find(view => view.threadId === threads.currentThread?.id)?.state };
  });
  const card = page.locator('[data-onboarding-id="agent-chat-input"]');
  const composer = card.locator('[contenteditable="true"]');
  const send = card.getByRole('button', { name: 'Send', exact: true });
  const pause = card.getByTitle('Pause agent work', { exact: true });
  const pausePending = card.getByText('Pause requested. Claude is still working.', { exact: true });
  const sessionControls = card.getByRole('button', { name: 'Session controls', exact: true });
  const section = page.getByRole('region', { name: 'Claude native interface', exact: true });
  const draft = () => composer.evaluate(el => ({ doc: el.editor.state.doc.toJSON(), selection: el.editor.state.selection.toJSON() }));
  const type = async text => {
    await composer.click();
    await composer.press('ControlOrMeta+a');
    await composer.pressSequentially(text);
    await expect(composer).toHaveText(text);
  };
  const save = () => writeFile(join(output, 'mcp-resource-pause.json'), JSON.stringify(proof, null, 2));
  const capture = async (stage, control) => {
    for (const [size, viewport] of [['normal', { width: 1100, height: 900 }], ['compact', { width: 680, height: 600 }]]) {
      await page.setViewportSize(viewport);
      await page.evaluate(() => document.fonts.ready);
      await expect(composer).toHaveText(proof.draft);
      await expect(composer).toBeInViewport();
      await expect(control).toBeInViewport({ ratio: 1 });
      const name = `mcp-resource-pause-${stage}-${size}.png`;
      await page.screenshot({ path: join(output, name), animations: 'disabled' });
      proof.captures.push(name);
    }
    await save();
  };
  const modelRequests = () => model.calls.filter(call => call.path.split('?')[0] === '/v1/messages');
  try {
    await app.waitForSurface('default-setup/threads');
    await app.navigate('host/settings');
    await page.evaluate(() => {
      const settings = window.applicationState.system.get('host/settings');
      settings.send({ type: 'TAB.SELECT', tab: 'general' });
      settings.send({ type: 'GENERAL_NAV.SELECT', item: 'secrets' });
    });
    const provider = page.getByText('Claude Code CLI', { exact: true }).locator('..').locator('..').locator('..');
    await provider.getByPlaceholder('Path override (auto-detected if empty)').fill('/frozen-claude/claude');
    await page.waitForTimeout(700);
    await app.navigate('default-setup/threads');
    await expect.poll(() => page.evaluate(() => {
      const c = window.applicationState.system.get('default-setup/threads').getSnapshot().context;
      return !!c.currentThread?.id && c.tabs.every(t => c.tabsRead.includes(t.id));
    }), { timeout: 15000 }).toBe(true);
    await page.evaluate(directory => {
      const threads = window.applicationState.system.get('default-setup/threads');
      threads.send({ type: 'NEW_THREAD_IN_PROJECT', directory });
      threads.send({ type: 'SET_MODE', mode: 'Claude Code' });
      threads.send({ type: 'SET_PHASE', phase: 'Edit' });
    }, project);

    proof.seed = 'Review the release checklist with me.';
    await type(proof.seed);
    await send.click();
    await expect.poll(async () => {
      const c = await context();
      return c.claude?.turns === 1 && c.messages.some(m => m.text === 'Ready to review the release.' && m.sender === 'assistant');
    }, { timeout: 30000 }).toBe(true);
    proof.session = (await context()).claude.sessionId;
    await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
    const lastSent = new Map();
    const terminal = section.locator('[data-terminal-text]').first();
    proof.onboarding = [];
    for (let attempt = 0; attempt < 120 && (await context()).native?.status !== 'live'; attempt++) {
      const screen = await terminal.textContent({ timeout: 1000 }).catch(() => '');
      const prompt = recognizeOnboardingPrompt(screen ?? '', project);
      if (prompt && Date.now() - (lastSent.get(prompt) ?? 0) >= 1000) {
        const input = section.locator('[aria-label="Terminal input"]');
        await electronApp.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0]?.focus());
        await input.focus();
        if (prompt.startsWith('workspace-trust')) await page.waitForTimeout(200);
        const key = prompt === 'workspace-trust' ? 'ArrowDown' : 'Enter';
        await input.press(key);
        lastSent.set(prompt, Date.now());
        proof.onboarding.push({ prompt, key });
      }
      await page.waitForTimeout(100);
    }
    proof.lastTerminalText = await terminal.textContent({ timeout: 1000 }).catch(() => '');
    await expect.poll(async () => (await context()).native?.status, { timeout: 25000 }).toBe('live');
    proof.initial = (await context()).native;
    proof.processStart = await processStart(proof.initial.nativePid);
    assert.ok(proof.processStart);
    await section.getByRole('button', { name: 'Back to conversation', exact: true }).click();

    const owned = async () => (await readReceipts(peer.receipts)).filter(row => row.ppid === proof.initial.nativePid);
    await expect.poll(async () => (await owned()).some(row => row.method === 'resources/list')).toBe(true);
    // Original startup discovery must finish before the peer invalidates its list. An
    // unfinished initial connection offers WaitForMcpServers instead of the list tool.
    phase('mcp-resource-arming');
    await writeFile(peer.hold + '.arm', String(proof.initial.nativePid), { flag: 'wx' });
    if (!holdRead) await expect.poll(async () => (await owned()).some(row => row.event === heldEvent), { timeout: 12000 }).toBe(true);
    await type(scenario.prompt);
    await send.click();
    if (holdRead) await expect.poll(async () => (await owned()).some(row => row.event === heldEvent), { timeout: 15000 }).toBe(true);
    const held = (await readReceipts(peer.receipts)).filter(row => row.event === heldEvent);
    assert.equal(held.length, 1);
    [proof.held] = held;
    assert.equal(proof.held.ppid, proof.initial.nativePid);
    await expect.poll(() => modelRequests().some(call => call.heldResourceStep === scenario.step.id && call.fixtureResponse === scenario.step.name)).toBe(true);
    assert.equal((await context()).native.busy, true);
    proof.draft = 'Keep my release notes while Claude is paused.';
    await type(proof.draft);
    await composer.press('Home');
    await composer.press('Shift+ArrowRight');
    await composer.press('Shift+ArrowRight');
    await capture('pending', pause);
    proof.document = await draft();
    proof.beforePauseCalls = modelRequests().length;
    await pause.click();
    const didAbort = async () => {
      const native = (await context()).native;
      return !!native && !native.busy && native.lastTurn?.reason === 'aborted';
    };
    if (holdRead) {
      // An original read may settle later than the cancellation acknowledgement.
      // Observe the live owner before allowing the peer reply through.
      const end = Date.now() + 1800;
      while (Date.now() < end && !await didAbort()) await page.waitForTimeout(50);
    } else await expect.poll(didAbort, { timeout: 8000 }).toBe(true);
    const beforeRelease = await context();
    proof.beforeRelease = { native: beforeRelease.native, claude: beforeRelease.claude, thread: beforeRelease.thread };
    assert.equal(beforeRelease.native.ownerId, proof.initial.ownerId);
    assert.equal(beforeRelease.native.sessionId, proof.session);
    assert.equal(await processStart(proof.initial.nativePid), proof.processStart);
    assert.deepEqual(await draft(), proof.document);
    assert.ok(!(await readReceipts(peer.receipts)).some(row => row.event === releasedEvent || row.event === expiredEvent));
    if (stopHeldRead) {
      assert.equal(beforeRelease.native.busy, true);
      if (verifyPauseControls) {
        await expect(pausePending).toBeVisible();
        await expect(pause).toBeHidden();
        await capture('paused', sessionControls);
        const ending = (await context()).native;
        assert.equal(ending.ownerId, proof.initial.ownerId);
        assert.equal(ending.sessionId, proof.session);
        assert.ok(ending.busy && ending.endingTurnId);
        await sessionControls.click();
        proof.pauseControls = { status: 'Pause requested. Claude is still working.', endingTurnId: ending.endingTurnId, openedSessionControls: true };
      } else {
        await capture('paused', send);
        await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
      }
      await section.getByRole('button', { name: 'Stop session', exact: true }).click();
      await expect.poll(() => processStart(proof.initial.nativePid), { timeout: 15000 }).not.toBe(proof.processStart);
      await expect.poll(() => processStart(proof.held.pid), { timeout: 8000 }).not.toBe(proof.held.start);
      const back = section.getByRole('button', { name: 'Back to conversation', exact: true });
      if (await back.isVisible()) await back.click();
      await expect(composer).toBeEditable();
      await expect(send).toBeEnabled();
      if (verifyPauseControls) {
        await expect(pausePending).toBeHidden();
        await expect(sessionControls).toBeHidden();
        proof.pauseControls.retiredOnStop = true;
      }
      assert.deepEqual(await draft(), proof.document);
      const stopped = await context();
      assert.equal(stopped.claude.sessionId, proof.session);
      assert.equal(stopped.claude.totalCostUsd, beforeRelease.claude.totalCostUsd);
      assert.equal(modelRequests().length, proof.beforePauseCalls);
      const events = await readReceipts(peer.receipts);
      assert.ok(!events.some(row => row.event === releasedEvent || row.event === expiredEvent));
      proof.stopped = { claude: stopped.claude, thread: stopped.thread, retiredNative: true, retiredPeer: true };
      await type(scenario.recoveryPrompt);
      await send.click();
      await expect.poll(async () => {
        const c = await context();
        return c.claude?.chatState === 'success' && c.messages.some(m => m.sender === 'assistant' && m.text === scenario.recoveryReply);
      }, { timeout: 25000 }).toBe(true);
      const recovered = await context();
      assert.equal(recovered.claude.sessionId, proof.session);
      assert.equal(recovered.thread, stopped.thread);
      const humans = recovered.messages.filter(row => row.sender === 'user').map(row => ({ text: row.text, uuid: row.context?.cliUuid }));
      assert.deepEqual(humans.map(row => row.text), [proof.seed, scenario.prompt, scenario.recoveryPrompt]);
      assert.equal(modelRequests().filter(call => call.heldResourceRecovery).length, 1);
      assert.ok(!JSON.stringify(modelRequests()).includes(scenario.retiredLabel));
      proof.recovered = { claude: recovered.claude, thread: recovered.thread, humans };
      await type(proof.draft);
      await capture('continued', send);
      proof.status = 'complete';
      phase('mcp-held-read-stop-recovery-complete');
      return;
    }
    if (!holdRead) await capture('paused', send);

    await writeFile(peer.hold + '.release', '', { flag: 'wx' });
    await expect.poll(async () => (await readReceipts(peer.receipts)).some(row => row.event === releasedEvent && row.id === proof.held.id)).toBe(true);
    await expect.poll(didAbort, { timeout: 8000 }).toBe(true);
    const afterRelease = await context();
    assert.equal(afterRelease.native.lastTurn?.reason, 'aborted');
    proof.paused = { native: afterRelease.native, claude: afterRelease.claude, thread: afterRelease.thread };
    assert.deepEqual(await draft(), proof.document);
    if (holdRead) await capture('paused', send);
    assert.equal(modelRequests().length, proof.beforePauseCalls);
    assert.ok(!JSON.stringify(afterRelease.messages).includes(scenario.retiredLabel));
    await type(scenario.freshPrompt);
    await send.click();
    await expect.poll(async () => {
      const c = await context();
      return c.native && !c.native.busy && c.messages.some(m => m.sender === 'assistant' && m.text === scenario.freshReply);
    }, { timeout: 22000 }).toBe(true);
    const fresh = await context();
    proof.fresh = { native: fresh.native, claude: fresh.claude, thread: fresh.thread,
      humans: fresh.messages.filter(row => row.sender === 'user').map(row => ({text:row.text, uuid:row.context?.cliUuid})) };
    assert.equal(fresh.native.ownerId, proof.initial.ownerId);
    assert.equal(fresh.native.sessionId, proof.session);
    assert.equal(await processStart(proof.initial.nativePid), proof.processStart);
    assert.deepEqual(proof.fresh.humans.map(row => row.text), [proof.seed, scenario.prompt, scenario.freshPrompt]);
    const replies = modelRequests().filter(call => call.heldResourceResult && call.heldResourceStep === scenario.freshStep.id);
    assert.ok(replies.some(call => JSON.stringify(call.heldResourceResult).includes(resourceText.trimEnd().split('\n').at(-1))));
    const receives = await readReceipts(peer.receipts);
    assert.equal(receives.filter(row => row.method === 'resources/read' && row.uri === scenario.freshStep.input.uri).length, 1);
    assert.ok(!JSON.stringify(modelRequests()).includes(scenario.retiredLabel));
    await type(proof.draft);
    await capture('continued', send);
    await section.getByRole('button', { name: 'Use native interface', exact: true }).click();
    await section.getByRole('button', { name: 'Stop session', exact: true }).click();
    await expect.poll(() => processStart(proof.initial.nativePid), { timeout: 15000 }).not.toBe(proof.processStart);
    proof.status = 'complete';
    phase('mcp-resource-pause-complete');
  } catch (error) {
    proof.status = 'failed';
    proof.error = { message: error.message, stack: error.stack };
    proof.failure = await context().catch(() => undefined);
    await page.screenshot({ path: join(output, 'mcp-resource-pause-failure.png') }).catch(() => {});
    throw error;
  } finally {
    await save();
  }
}
