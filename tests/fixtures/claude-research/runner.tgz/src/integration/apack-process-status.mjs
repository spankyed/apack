process.argv[5]='observe-process';
await import('./apack-subagent-status.mjs');
