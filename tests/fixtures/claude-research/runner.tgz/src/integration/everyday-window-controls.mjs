import assert from 'node:assert/strict';
import {join} from 'node:path';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createNativeTestImage} from '../protocol/native-test-image.mjs';

/** Real popout sharing native decisions while keeping its own ordinary composer. */
export async function createEverydayWindowControls({page,electronApp,expect,context,proof,output,userDataDir,readParentJournal,verifyStaleResponses=false,verifyQuestionAttachment=false}) {
 const state={status:'running',draft:'Keep the separate popout release notes.',captures:[],geometry:[],errors:[]};proof.windowControls=state;
 const save=()=>writeFile(join(output,'everyday-window-controls.json'),JSON.stringify(state,null,2));
 const opened=electronApp.waitForEvent('window');await page.evaluate(()=>window.electronAPI.surfaces.popout('default-setup/threads','Threads'));const popout=await opened;
 popout.on('pageerror',error=>state.errors.push(error.message));await popout.waitForLoadState('domcontentloaded');await expect.poll(()=>popout.evaluate(()=>!!window.applicationState?.system.get('default-setup/threads'))).toBe(true);
 const main=await context();state.threadId=main.threadId;state.sessionId=proof.parentSessionId;state.pid=proof.pid;
 await popout.evaluate(threadId=>window.applicationState.system.get('default-setup/threads').send({type:'OPEN_THREAD_CHAT',threadId}),state.threadId);
 const card=popout.locator('[data-onboarding-id="agent-chat-input"]'),composer=card.locator('[contenteditable="true"]');await expect(composer).toBeVisible();await composer.fill(state.draft);
 const snapshot=()=>composer.evaluate(e=>({document:e.editor.state.doc.toJSON(),selection:e.editor.state.selection.toJSON()}));state.composerBefore=await snapshot();
 const other=()=>popout.evaluate(()=>{const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context;return{threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,messages:c.currentThread?.messages,native:Object.values(c.nativeTerminalViews).find(v=>v.threadId===c.currentThread?.id)}});
 const arrivals=async()=>{const log=await readFile(join(userDataDir,'apack/logs/main.log'),'utf8');return [...log.matchAll(/Incoming: "INTERACTIVE_MSG_RESPONSE"/g)].length};
 const replayRetired=async(kind,messageId,response,currentRequest)=>{
  if(kind==='question'){
   const text='I will write the release summary for developers.';
   let checkpoint;
   await expect.poll(async()=>{
    const current=await identity();
    if(current.native.state.busy!==false||current.claude.chatState!=='success')return false;
    const journal=await readParentJournal();
    const complete=journal.subarray(0,journal.lastIndexOf(10)+1);
    const rows=complete.toString().split('\n').filter(Boolean).map(JSON.parse);
    const replyIndex=rows.findIndex(row=>row.type==='assistant'&&Array.isArray(row.message?.content)&&
     row.message.content.some(block=>block.type==='text'&&block.text===text));
    if(replyIndex===-1)return false;
    const cliUuid=rows[replyIndex].uuid;
    const cost=rows.slice(replyIndex+1).find(row=>row.type==='cost-state')?.totalCostUSD;
    if(!cliUuid||!Number.isFinite(cost)||current.claude.totalCostUsd!==cost||
     !current.messages.some(message=>message.text===text&&message.context?.cliUuid===cliUuid))return false;
    checkpoint={cliUuid,cost,text};
    return true;
   },{timeout:15000}).toBe(true);
   state.questionCompletion=checkpoint;
   await save();
  }
  const before=await identity(),messageBefore=before.messages.find(m=>m.id===messageId);assert.ok(messageBefore?.responseTimestamp,'Only a genuinely settled message is replayed');
  const countBefore=await arrivals(),startedAt=Date.now();
  await popout.evaluate(({messageId,response})=>window.applicationState.system.get('default-setup/threads').send({type:'RESPOND_TO_BLOCK_INTERACTION',messageId,response}),{messageId,response});
  await expect.poll(arrivals,{timeout:10000}).toBe(countBefore+1);
  const after=await identity(),messageAfter=after.messages.find(m=>m.id===messageId);assert.deepEqual(messageAfter,messageBefore);
  assert.deepEqual(after.claude.pendingControlRequest,currentRequest);assert.equal(after.claude.turns,before.claude.turns);assert.equal(after.claude.totalCostUsd,before.claude.totalCostUsd);
  (state.staleResponses??=[]).push({kind,messageId,response,messageBefore,messageAfter,currentRequest:currentRequest??null,pendingAfter:after.claude.pendingControlRequest??null,countBefore,countAfter:await arrivals(),startedAt,observedAt:Date.now(),beforeAccounting:{turns:before.claude.turns,cost:before.claude.totalCostUsd},afterAccounting:{turns:after.claude.turns,cost:after.claude.totalCostUsd},sessionId:after.claude.sessionId,pid:after.native.state.nativePid});await save();
 };
 const identity=async()=>{const value=await other();assert.equal(value.claude.sessionId,state.sessionId);assert.equal(value.native.state.nativePid,state.pid);return value};
 const capture=async(kind,panel,controls)=>{
  for(const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]){
   await popout.setViewportSize(viewport);
   await expect(panel).toBeInViewport({ratio:1});
   if(kind==='question-attachment') await controls[0].scrollIntoViewIfNeeded();
   const boxes=[];
   for(const control of controls){
    if(kind==='question-custom-answer'&&control===controls[0]){
     await control.evaluate(element=>element.scrollIntoView({block:'center'}));
    }
    await expect(control).toBeInViewport({ratio:1});
    boxes.push(await control.evaluate(e=>{
     const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);
     return {x:r.x,y:r.y,width:r.width,height:r.height,reachable:!!hit&&(e===hit||e.contains(hit))};
    }));
   }
   state.geometry.push({kind,size,boxes});
   const name='everyday-window-'+kind+'-'+size+'.png';
   await popout.screenshot({path:join(output,name),animations:'disabled'});
   state.captures.push(name);
   await save();
  }
 };
 return {
  async approvalReady(){const panel=popout.getByTestId('native-read-approval');await expect(panel).toBeVisible();state.approval={main:(await context()).claude.pendingControlRequest,other:(await identity()).claude.pendingControlRequest};assert.equal(state.approval.main.approvalMessageId,state.approval.other.approvalMessageId);assert.equal(state.approval.main.nativeTerminal.ownerId,state.approval.other.nativeTerminal.ownerId);await expect(composer).toBeHidden();await capture('approval',panel,[panel.getByTestId('native-read-path'),panel.getByRole('button',{name:'Approve',exact:true})]);},
  async afterApproval(){await expect(popout.getByTestId('native-read-approval')).toBeHidden();await expect(composer).toHaveText(state.draft);state.composerAfterApproval=await snapshot();assert.deepEqual(state.composerAfterApproval,state.composerBefore);state.afterApproval=await identity();await save();},
  async questionReady(){
   const panel=popout.getByTestId('native-question-panel');
   await expect(panel).toBeVisible();
   state.question={main:(await context()).claude.pendingControlRequest,other:(await identity()).claude.pendingControlRequest};
   assert.equal(state.question.main.approvalMessageId,state.question.other.approvalMessageId);
   assert.equal(state.question.main.nativeTerminal.ownerId,state.question.other.nativeTerminal.ownerId);
   await expect(composer).toBeHidden();
   if(verifyStaleResponses) await replayRetired('approval',state.approval.main.approvalMessageId,{approved:false,cancelled:true},(await identity()).claude.pendingControlRequest);
   const choice=panel.getByRole('radio',{name:'Developers People integrating the updated behavior',exact:true});
   const submit=panel.getByRole('button',{name:'Submit answers',exact:true});
   await choice.check();
   if(verifyQuestionAttachment) {
    const custom=panel.getByRole('button',{name:'Write your own answer',exact:true});
    const field=panel.getByRole('textbox',{name:'Your answer',exact:true});
    await expect(field).toHaveCount(0);
    await capture('question',panel,[choice,custom,submit]);
    await custom.click();
    await expect(field).toBeFocused();
    await field.fill('Developers');
    await expect(choice).not.toBeChecked();
    await capture('question-custom-answer',panel,[field,submit]);
    const name='Migration-timeline.png';
    const buffer=createNativeTestImage([115,84,212,255]);
    await panel.getByLabel('Attach image',{exact:true}).setInputFiles({name,mimeType:'image/png',buffer});
    const remove=panel.getByRole('button',{name:'Remove '+name,exact:true});
    await expect(remove).toBeVisible();
    await capture('question-attachment',panel,[remove,submit]);
    await expect(field).toHaveValue('Developers');
    state.question.customAnswer={answer:'Developers',fromPopout:true};
    state.question.attachment={name,sha256:createHash('sha256').update(buffer).digest('hex')};
   }else await capture('question',panel,[choice,submit]);
   await submit.click();
  },
  async afterQuestion(){await expect(popout.getByTestId('native-question-panel')).toBeHidden();await expect(composer).toHaveText(state.draft);state.composerAfterQuestion=await snapshot();assert.deepEqual(state.composerAfterQuestion,state.composerBefore);state.afterQuestion=await identity();if(verifyStaleResponses)await replayRetired('question',state.question.main.approvalMessageId,{cancelled:true},undefined);await popout.close();state.closed=true;state.mainAfterClose=await context();assert.equal(state.mainAfterClose.native.state.nativePid,state.pid);assert.deepEqual(state.errors,[]);state.status='complete';await save();}
 };
}
