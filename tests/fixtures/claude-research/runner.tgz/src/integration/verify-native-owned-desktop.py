"""Verify saved original-worker desktop drawing/action proof; no actual-app acceptance."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence', type=Path)
parser.add_argument('product', type=Path)
parser.add_argument('--expect-prompt-host', action='store_true')
parser.add_argument('--expect-user-launcher', action='store_true')
a = parser.parse_args()
research = Path(__file__).resolve().parents[2]
load = lambda path: json.loads(path.read_text())
boundary = load(a.evidence / 'offline-boundary.json')
assert boundary['networkDisabled'] and boundary['pinnedExecutableReadOnly']
assert set(boundary['networks']) == {'none'}
assert boundary['memoryBytes'] == boundary['memorySwapBytes'] == 6 * 1024**3
assert boundary['cpus'] == 2
assert load(a.evidence / 'result.json')['exitCode'] == 0
stage = load(a.evidence / 'receipt.json')
assert stage['exitCode'] == 0
# The staged archive is the executable source identity; a later docs-only HEAD may be
# recorded by the controller. Require byte-identical runtime inputs under both pins.
metadata_delta = []
if stage['researchCommit'] != boundary['researchCommit']:
    metadata_delta = subprocess.check_output(['git', 'diff', '--name-only', stage['researchCommit'], boundary['researchCommit']], cwd=research, text=True).splitlines()
    assert metadata_delta and all(path.startswith('docs/') and Path(path).suffix in ['.md', '.json'] for path in metadata_delta), 'Unverified research runtime delta after staging'
assert stage['productCommit'] == boundary['productCommit']

def verify_git(root, commit, inputs):
    proc = subprocess.run(['git', 'cat-file', '--batch'], cwd=root,
                          input=''.join(commit + ':' + path + '\n' for path in inputs).encode(),
                          stdout=subprocess.PIPE, check=True)
    data = proc.stdout; offset = 0
    for path, expected in inputs.items():
        end = data.index(b'\n', offset)
        header = data[offset:end].split()
        assert len(header) == 3 and header[1] == b'blob', path
        size = int(header[2]); content = data[end + 1:end + 1 + size]
        assert hashlib.sha256(content).hexdigest() == expected, path
        offset = end + 2 + size
    assert offset == len(data)

product_inputs = load(a.evidence / 'source-inputs.json')
research_inputs = load(a.evidence / 'authored-inputs.json')
verify_git(a.product, boundary['productCommit'], product_inputs)
verify_git(research, stage['researchCommit'], research_inputs)
if metadata_delta:
    verify_git(research, boundary['researchCommit'], research_inputs)
assert hashlib.sha256((research / 'output/runtime-targets/linux-arm64-2.1.302/claude').read_bytes()).hexdigest() == '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
with tarfile.open(a.evidence / 'workspace-records.tar.gz') as archive:
    files = {}
    for member in archive:
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts
        if member.isfile():
            key = str(path)
            assert key not in files
            files[key] = member
    def read(path):
        member = files[path]
        assert member.size < 16 * 1024**2
        return archive.extractfile(member).read()
    def record(name):
        return json.loads(read('output/' + name))
    proof = record('owned-worker-desktop.json')
    native = record('leftarrow-evidence.json')
    job = native['forkJob']; child = job['sessionId']; pid = job['pid']
    workspace = 'workspaces/apack-terminal-owner-app-desktop1'
    project = workspace + '/project/'
    assert proof['status'] == 'complete' and proof['pid'] == pid and proof['sessionId'] == child
    assert proof['steps'] == ['capabilities', 'attached', 'rendered', 'pressed', 'released']
    assert native['verifyFork'] and native['verifyAttach'] and native['stopped']
    assert native['realModelRequests'] == 0
    assert record('original-parent-trust-persistence.json')['trusted']
    registry = proof['hookRegistration']
    assert registry['registered'] and not registry['awaitTrust'] and not registry['inFlight']
    assert registry['unknown'] is None and registry['abovePrompt'] == {'terminal': True, 'desktop': True}
    assert any(row['name'] == 'research-child-host-audit' for row in registry['loadedModules'])
    assert proof['frame']['hooked'] and proof['frame']['drawn_by'] == ['research-child-host-audit']
    button = next(row for row in proof['frame']['tree']['children'] if row.get('type') == 'Button')
    action = proof['action']
    assert action == {**button['press'], 'key': button['props']['key']}
    assert action['plugin'] == 'research-child-host-audit' and action['key'] == 'child-drawing-proof'
    assert proof['press'] == {'handled': True, 'element': action['key']}
    callback = json.loads(read(project + 'native-child-drawing-press-' + child + '.json'))
    dispatch = json.loads(read(project + 'native-child-drawing-dispatch-' + child + '.json'))
    assert callback == proof['callback'] and callback['callback'] and callback['sessionId'] == child
    if a.expect_prompt_host:
        host = proof['promptHost']; prompt = callback['prompt']
        assert host['calls'].count('fill') == 1 and 3 <= len(host['calls']) <= 8
        assert host['calls'][0] == host['calls'][-1] == 'read'
        assert all(value in ['read', 'fill'] for value in host['calls'])
        assert host['initialDraft'] == 'Owned child desktop draft あ🙂'
        assert host['finalDraft'] == 'Owned child desktop replacement あ🙂'
        for name, text in [('before', host['initialDraft']), ('after', host['finalDraft'])]:
            assert prompt[name] == {'text': text, 'cursor': len(text.encode('utf-16-le')) // 2}
        assert prompt['filled']['isFilled'] is True

    assert dispatch['sessionId'] == child and dispatch['event'] == {
        'plugin': action['plugin'], 'element': action['key'], 'component': 'AbovePrompt',
        'requestId': 'owned-worker-desktop:above-prompt', 'surface': 'desktop'}
    assert dispatch['result'] == {'element': action['key']} and dispatch['at'] >= callback['at']
    assert proof['staleAction'] == {'handled': False} and proof['sameOriginalWorker']
    attach = record('original-child-attach-observation.json')
    assert attach['frameSeen'] and attach['run']['reason'] == 'owned-attach-frame-observed'
    assert attach['jobBefore']['pid'] == attach['jobAfter']['pid'] == pid
    assert attach['jobBefore']['sessionId'] == attach['jobAfter']['sessionId'] == child
    assert attach['processBefore']['startTime'] == attach['processAfter']['startTime'] == proof['processStart']
    assert attach['processAfter']['state'] != 'Z'
    events = [path for path in files if path.startswith('output/original-child-attach/runs/') and path.endswith('/events.jsonl')]
    assert len(events) == 1
    assert not any(row['kind'] == 'stdin' for row in map(json.loads, read(events[0]).decode().splitlines())), 'Desktop callback must not use terminal keys'
    audit = record('owned-launcher-audit.json'); worker = audit['worker']
    assert worker['pid'] == pid and worker['processStart'] == proof['processStart']
    assert worker['binarySha256'] == '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
    assert worker['restoredBunOptions']
    remote = job['cwd'].removesuffix('/project')
    if a.expect_user_launcher:
        selected = record('owned-launcher-selection.json')
        assert selected['source'] == 'userSettings' and selected['environmentOverride'] is False
        assert selected['path'] == remote + '/.claude/settings.json'
        settings_bytes = read(workspace + '/.claude/settings.json')
        assert hashlib.sha256(settings_bytes).hexdigest() == selected['sha256']
        settings = json.loads(settings_bytes)
        assert settings['processWrapper'] == remote + '/owned-launcher/launcher.sh'
        assert settings['processWrapper'] in audit['sources']
    for name, digest in audit['sources'].items():
        assert name.startswith(remote + '/owned-launcher/')
        assert hashlib.sha256(read(workspace + name[len(remote):])).hexdigest() == digest
    boot = [path for path in files if '/managed-security-bootstrap/runs/' in path and path.endswith('/manifest.json')]
    assert len(boot) == 1
    boot_result = json.loads(read(boot[0]))
    assert boot_result['status'] == 'complete' and boot_result['code'] == 0
    for name, digest in record('source-inputs.json').items():
        if name.startswith('/research/'):
            inputs, relative = research_inputs, name.removeprefix('/research/')
        else:
            assert name.startswith('/work/')
            inputs, relative = product_inputs, name.removeprefix('/work/')
        if relative in inputs:
            assert inputs[relative] == digest
        else:
            verify_git(a.product, boundary['productCommit'], {relative: digest})
telemetry = [json.loads(line) for line in (a.evidence / 'memory-telemetry.jsonl').read_text().splitlines()]
assert telemetry
for row in telemetry:
    events = dict(line.split() for line in row['memory.events'].splitlines())
    assert events['oom'] == events['oom_kill'] == '0'
    assert int(row['memory.swap.current']) == 0
result = {'status': 'passed-native-owned-desktop-only', 'productCommit': boundary['productCommit'],
          'researchCommit': stage['researchCommit'], 'researchMetadataCommit': boundary['researchCommit'], 'verifiedDocsOnlyDelta': metadata_delta, 'verifiedProductInputs': len(product_inputs),
          'verifiedResearchInputs': len(research_inputs), 'workerPid': pid, 'childSessionId': child,
          'originalDesktopCallback': True, 'terminalInputBytes': 0, 'releasedActionRefused': True,
          'sameWorkerAfterAttach': True, 'originalStop': True, 'gracefulCredentialBootstrap': True,
          'originalTrustPersisted': True, 'originalUserLauncherVerified': a.expect_user_launcher, 'reversePromptHostVerified': a.expect_prompt_host, 'syntheticRequests': native['syntheticRequests'], 'realModelRequests': 0,
          'noOom': True, 'scope': 'Fresh owned original cold-worker desktop drawing/callback/retirement, plus reverse prompt read/fill/read only when explicitly required. No actual-app, rich/media prompt, production profile or warm-spare acceptance.'}
(a.evidence / 'owned-desktop-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
