import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {startSyntheticModel} from '../protocol/synthetic-model.mjs';
const [checkout,executable,workspace,mode='raw']=process.argv.slice(2);
assert.ok(['raw','owner','compiled'].includes(mode));
assert.equal(process.env.HOME,workspace);
for(const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_CODE_OAUTH_TOKEN'])assert.equal(process.env[key],undefined);
const {query}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/query.ts')));
const cwd=join(workspace,'project'),config=join(workspace,'.claude');
await mkdir(cwd);await mkdir(config,{recursive:true});
await writeFile(join(config,'settings.json'),JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}));
const model=await startSyntheticModel(cwd,'TextOnly');let native,owner,child,deadline,escalation,childExited=false;
const events=[];
try{
 if(mode==='compiled'){
  child=spawn(process.execPath,[join(checkout,'node_modules/vitest/vitest.mjs'),'run','--config','vitest.config.ts','--project','@app/default-setup:backend','tests/content/actions/claude-code/reset-chat-native.spec.ts','--pool=threads','--maxWorkers=1','--minWorkers=1','--no-file-parallelism'],{cwd:join(checkout,'packages/default-setup'),env:{...process.env,CLAUDE_RESEARCH_EXECUTABLE:executable,CLAUDE_RESEARCH_WORKSPACE:workspace,CLAUDE_RESEARCH_MODEL_URL:model.url},stdio:['ignore','pipe','pipe']});
  child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);
  deadline=setTimeout(()=>{child.kill('SIGTERM');escalation=setTimeout(()=>{if(!childExited)child.kill('SIGKILL')},1000)},25000);
  const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',code=>{childExited=true;resolve(code)})});
  assert.equal(code,0,'Compiled reset Chat fixture failed');
  const inferenceRequests=model.calls.filter(call=>!call.path.includes('count_tokens')).length;assert.equal(inferenceRequests,2);
  const evidence=JSON.parse(await readFile(join(workspace,'compiled-reset-evidence.json'),'utf8'));
  console.log(JSON.stringify({...evidence,inferenceRequests,localApiRequests:model.calls.length,realModelRequests:0}));
 }else{
 native=await query({cliPath:executable,cwd,env:{HOME:workspace,CLAUDE_CONFIG_DIR:config,ANTHROPIC_BASE_URL:model.url},tools:[],strictMcpConfig:true,settingSources:['user'],model:'sonnet',replayUserMessages:true,keepStdinOpen:true,signal:AbortSignal.timeout(20000)});
 await native.initialized;
 function observed(event){
  const row={type:event.type,...event.subtype&&{subtype:event.subtype},...event.session_id&&{sessionId:event.session_id},...event.user_message_uuid&&{inputId:event.user_message_uuid},...event.new_conversation_id&&{newConversationId:event.new_conversation_id},...event.command_uuid&&{commandId:event.command_uuid},...event.state&&{state:event.state},...event.type==='result'&&{totalCostUsd:event.total_cost_usd}};
  assert.ok(events.length<1000,'bounded event count');events.push(row);console.log(JSON.stringify({event:row}));return row;
 }
 if(mode==='owner'){
  const {createClaudeConversation}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/conversation.ts')));
  owner=createClaudeConversation(native,async()=>{throw new Error('unexpected autonomous fixture turn')});
  const turns=[];
  async function input(text){
   let inputId;
   await new Promise((resolve,reject)=>{inputId=owner.start(text,async turn=>{try{
    let result;
    for await(const event of turn.handle.events){observed(event);if(event.type==='result')result=event;}
    await turn.handle.result;assert.ok(result);
    turns.push({inputId:turn.inputId,baseline:turn.costBaseline,totalCostUsd:result.total_cost_usd,chargedCostUsd:Math.max(0,result.total_cost_usd-turn.costBaseline)});
    owner.release(turn.handle);resolve();
   }catch(error){reject(error);}});});
   return inputId;
  }
  const firstId=await input('First fixed synthetic text before clear.');const firstSessionId=owner.sessionId;
  const clearId=await input('/clear');const reset=events.find(event=>event.type==='conversation_reset');assert.ok(reset);
  const nextId=await input('Second fixed synthetic text after clear.');const nextSessionId=owner.sessionId;
  await owner.close();
  const inferenceRequests=model.calls.filter(call=>!call.path.includes('count_tokens')).length;assert.equal(inferenceRequests,2);
  const expectedCost=turns[0].totalCostUsd+turns[2].totalCostUsd;
  const chargedCost=turns.reduce((sum,turn)=>sum+turn.chargedCostUsd,0);
  console.log(JSON.stringify({evidence:'apack-native-conversation-reset',owner:true,firstInputId:firstId,clearInputId:clearId,nextInputId:nextId,firstSessionId,nextSessionId,resetSessionId:reset.sessionId,newConversationId:reset.newConversationId,newConversationMatchesSession:reset.newConversationId===nextSessionId,clearResults:events.filter(event=>event.type==='result'&&event.inputId===clearId).length,events,turns,expectedCost,chargedCost,costAccountingMatches:Math.abs(expectedCost-chargedCost)<1e-12,inferenceRequests,localApiRequests:model.calls.length,realModelRequests:0,closed:true,qualification:'Actual native query and retained owner with metadata/cost collection; app stream consumer, compiled Chat, renderer and persisted transcript policy are not verified.'}));
 }else{
 const iterator=native.events[Symbol.asyncIterator]();
 async function until(predicate){
  for(;;){
   assert.ok(events.length<1000,'bounded event count');
   const {value:event,done}=await iterator.next();assert.equal(done,false,'native stream ended before expected event');
   observed(event);
   if(predicate(event))return event;
  }
 }
 const firstId=native.send('First fixed synthetic text before clear.');
 const first=await until(event=>event.type==='result'&&event.user_message_uuid===firstId);
 assert.equal(first.is_error,false);
 const clearId=native.send('/clear');
 const reset=await until(event=>event.type==='conversation_reset'||event.type==='result'&&event.user_message_uuid===clearId);
 assert.equal(reset.type,'conversation_reset','clear result arrived without the expected reset');
 const nextId=native.send('Second fixed synthetic text after clear.');
 const next=await until(event=>event.type==='result'&&event.user_message_uuid===nextId);
 assert.equal(next.is_error,false);
 assert.notEqual(next.session_id,first.session_id);
 const inferenceRequests=model.calls.filter(call=>!call.path.includes('count_tokens')).length;
 assert.equal(inferenceRequests,2);
 await native.close();
 console.log(JSON.stringify({evidence:'apack-native-conversation-reset',firstInputId:firstId,clearInputId:clearId,nextInputId:nextId,firstSessionId:first.session_id,nextSessionId:next.session_id,resetSessionId:reset.session_id,newConversationId:reset.new_conversation_id,newConversationMatchesSession:reset.new_conversation_id===next.session_id,clearResults:events.filter(event=>event.type==='result'&&event.inputId===clearId).length,events,inferenceRequests,localApiRequests:model.calls.length,realModelRequests:0,closed:true,qualification:'One private native query, raw event consumption and fixed clear/follow-up input. No app owner, compiled Chat, renderer or persisted transcript policy is verified.'}));
}
}
}finally{clearTimeout(deadline);clearTimeout(escalation);if(child&&!childExited){child.kill('SIGTERM');setTimeout(()=>{if(!childExited)child.kill('SIGKILL')},1000).unref();}owner?.kill();native?.kill();await native?.close().catch(()=>{});await model.close();}
