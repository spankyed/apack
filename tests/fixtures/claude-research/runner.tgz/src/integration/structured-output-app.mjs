import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,realpath,stat,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createRun,hash} from '../artifacts/runs.mjs';
import {record} from '../protocol/record.mjs';

export async function probeStructuredOutputApp(checkout,executable,root,output,{mode='repair',chat=false,compiled=false}={}){
 assert.ok(['valid','repair','exhaust','queued'].includes(mode));
 assert.ok(!compiled||chat,'Compiled mode requires Chat');
 assert.ok(mode!=='queued'||chat,'Queued mode requires source Chat action');
 checkout=await realpath(checkout);assert.ok((await stat(join(checkout,'.git'))).isFile(),'Use the isolated linked worktree');
 assert.equal(await realpath(join(checkout,'node_modules')),join(checkout,'node_modules'),'Do not share node_modules');
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'structured-output-app-'));await mkdir(join(workspace,'.claude'));
 const driver=fileURLToPath(new URL('./structured-output-app-driver.mjs',import.meta.url)),sourceHashes={};
 const sourceRoot=join(checkout,'packages/default-setup');
 for(const name of ['src/content/actions/claude-code/cc-command.ts','src/content/actions/claude-code/_helpers/thread-context.ts','src/features/code/be/services/claude-code/background-tasks.ts','src/features/code/be/services/claude-code/handle-store.ts','src/features/code/be/services/claude-code/query.ts','src/features/code/be/services/claude-code/runner.ts','src/features/code/be/services/claude-code/host-controls.ts','src/features/code/be/services/claude-code/nested-activity.ts','src/features/code/be/services/claude-code/conversation.ts','src/content/actions/claude-code/_helpers/stream-consumer.ts','src/content/actions/claude-code/_helpers/tool-activity-writer.ts','src/content/actions/claude-code/chat.ts','src/content/actions/claude-code/handle-directory-select.ts','src/content/flows/claude-code-flow.ts','tests/content/actions/claude-code/structured-output-native.spec.ts','tests/content/actions/claude-code/structured-chat-native.spec.ts'])sourceHashes[name]=hash(await readFile(join(sourceRoot,name)));
 const compiledHashes={};if(compiled)for(const name of ['actions.content.json','flows.content.json'])compiledHashes[name]=hash(await readFile(join(sourceRoot,'dist/runtime/content',name)));
 const run=await createRun(output,compiled?'apack-structured-chat-compiled':chat?'apack-structured-chat-app':'apack-structured-output-app',{targetSha256:hash(await readFile(executable)),mode,chat,compiled,compiledHashes,baseCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:checkout,encoding:'utf8'}).trim(),sourceHashes,driverSha256:hash(await readFile(driver)),orchestratorSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('../protocol/synthetic-model.mjs',import.meta.url)))});
 let transport;
 try{
  transport=await record({executable:process.execPath,cwd:checkout,args:['--import',join(checkout,'node_modules/tsx/dist/loader.mjs'),driver,checkout,executable,workspace,mode,...(compiled?['compiled']:chat?['chat']:[])],env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},output,timeoutMs:65000});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);
  const stdout=await readFile(join(transport.directory,'stdout.bin'),'utf8'),evidence=stdout.split('\n').filter(line=>line.startsWith('{')).map(line=>JSON.parse(line)).find(value=>value.evidence==='apack-native-structured-output');
  assert.ok(evidence);for(const key of [compiled?'compiledFlow':'sourceConsumer','nativeOwner','terminalMapped','presentationVerified','closed'])assert.equal(evidence[key],true);assert.equal(evidence.localModelRequests,mode==='valid'?1:2);assert.equal(evidence.mode,mode);if(chat&&!compiled)assert.equal(evidence.sourceChat,true);if(mode==='queued')assert.equal(evidence.queuedSchemaRestart,true);assert.equal(evidence.realModelRequests,0);
  for(const[name,sha]of Object.entries(sourceHashes))assert.equal(hash(await readFile(join(sourceRoot,name))),sha);
  for(const[name,sha]of Object.entries(compiledHashes))assert.equal(hash(await readFile(join(sourceRoot,'dist/runtime/content',name))),sha);
  await writeFile(join(run.directory,'structured-output-app.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message,...(transport?{transportRun:transport.directory}:{})});throw error;}
}
