import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile,readdir,lstat,rename} from 'node:fs/promises';
import {join,basename,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {record} from '../protocol/record.mjs';
import {createClientPointerFixture} from '../protocol/native-client-pointer-fixture.mjs';
import {driveFreshNativeApp} from './apack-fresh-native-drive.mjs';
import {configureNativeCreditAccount} from '../protocol/native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from '../protocol/native-credit-billing.mjs';
import {startSyntheticAgentModel} from '../protocol/synthetic-agent-model.mjs';
import {clientPointerJourney} from './client-pointer-journey.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');
async function alive(pid,start){try{const s=await readFile('/proc/'+pid+'/stat','utf8'),f=s.slice(s.lastIndexOf(')')+2).split(' ');return f[0]!=='Z'&&f[19]===start}catch(e){if(e.code==='ENOENT')return false;throw e}}

/** Fresh actual app plus ordinary original local plugin installation; no native gate overrides. */
export async function driveFreshClientPointer({checkout,workspace,env}){
 assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-client[0-9]+$/);
 const project=join(workspace,'project');await mkdir(project);await writeFile(join(project,'release-notes.md'),'# Release notes\n\nReview the release timeline.\n');execFileSync('/usr/bin/git',['init','--quiet',project],{env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000});
 const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'}),configDir=join(workspace,'.claude'),configPath=join(configDir,'.claude.json'),settingsPath=join(configDir,'settings.json'),config=JSON.parse(await readFile(configPath,'utf8'));config.hasCompletedOnboarding=true;await writeFile(configPath,JSON.stringify(config));await writeFile(settingsPath,JSON.stringify({theme:'dark',model:'opus'}));
 const before=new Map();for(const name of ['.claude.json','settings.json','plugins/known_marketplaces.json','plugins/installed_plugins.json']){try{const path=join(configDir,name),stat=await lstat(path);assert.ok(stat.isFile()&&stat.uid===1000&&stat.size<=1048576);before.set(name,await readFile(path))}catch(e){if(e.code!=='ENOENT')throw e;before.set(name,undefined)}}
 await writeFile(join(workspace,'profile-inputs.json'),JSON.stringify({accountIsSynthetic:true,featureInputsSeeded:false,config,settings:JSON.parse(before.get('settings.json'))}));
 const market=basename(workspace),marketplace=join(workspace,'marketplace'),plugin=join(marketplace,'plugins/release-timeline');await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:market,owner:{name:'Local release timeline'},plugins:[{name:'release-timeline',source:'./plugins/release-timeline'}]}));
 const fixture=await createClientPointerFixture(plugin,project),model=await startSyntheticAgentModel({launchAgent:false,parentLaunchOnce:true,everydayProbe:true,captureMessages:true,requestLimit:8}),tls=await prepareNativeCreditTls(join(workspace,'account-tls')),billing=await startNativeCreditBilling(tls,{allowMutations:false,evidencePath:join(workspace,'account-live.json')});
 const launchEnv={...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project};delete launchEnv.ANTHROPIC_API_KEY;
 try{
  const runs=[];for(const args of [['--setting-sources','','plugin','validate',plugin],['--setting-sources','','plugin','marketplace','add',marketplace],['--setting-sources','','plugin','install','release-timeline@'+market]]){const run=await record({executable:'/frozen-claude/claude',cwd:project,output:join(workspace,'installation'),env:launchEnv,args,timeoutMs:20000,maxBytes:1048576});runs.push(run);assert.equal(run.code,0);assert.equal(run.status,'complete')}
  const registry=JSON.parse(await readFile(join(configDir,'plugins/installed_plugins.json'),'utf8')),entries=registry.plugins?.['release-timeline@'+market];assert.ok(entries?.length===1&&entries[0].scope==='user');for(const[name,hash]of Object.entries(fixture.hashes))assert.equal(sha(await readFile(join(entries[0].installPath,name))),hash);
  await writeFile(join(workspace,'client-pointer-installation.json'),JSON.stringify({runs,installation:entries[0],hashes:fixture.hashes,originalBinarySha256:sha(await readFile('/frozen-claude/claude')),scope:'Original local validate/marketplace add/install; no manually fabricated registry, private policy or wrapper.'}));
  await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-client-pointer-retirement',journeyBudgetMs:150000,journey:args=>clientPointerJourney({...args,model})});
 }finally{
  await model.close();await billing.close();await writeFile(join(workspace,'model-calls.json'),JSON.stringify(model.calls,null,2));await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2));
  const output=join(workspace,'electron-results');await mkdir(output,{recursive:true});let proof;try{proof=JSON.parse(await readFile(join(output,'client-pointer.json'),'utf8'))}catch(e){if(e.code!=='ENOENT')throw e}
  const live=proof?.pid&&await alive(proof.pid,proof.processStart);assert.ok(!live,'Native writer must retire before profile restoration');
  const files=[];for(const[name,bytes]of before){const path=join(configDir,name);try{await rename(path,join(workspace,'preserved-'+name.replaceAll('/','-')))}catch(e){if(e.code!=='ENOENT')throw e}if(bytes!==undefined){await mkdir(dirname(path),{recursive:true});await writeFile(path,bytes,{mode:0o600,flag:'wx'});assert.deepEqual(await readFile(path),bytes)}else await assert.rejects(lstat(path),{code:'ENOENT'});files.push({path:name,present:bytes!==undefined,sha256:bytes===undefined?null:sha(bytes)})}
  await writeFile(join(output,'profile-restoration.json'),JSON.stringify({restored:true,files}));
  if(proof?.sessionId){const root=join(configDir,'projects'),files=await readdir(root,{recursive:true}),matches=files.filter(name=>basename(name)===proof.sessionId+'.jsonl');assert.equal(matches.length,1);await writeFile(join(output,'native-parent-transcript.jsonl'),await readFile(join(root,matches[0])))}
 }
}
