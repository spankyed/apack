import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { configureNativeCreditAccount, CREDIT_ACCOUNT_ID, CREDIT_ORGANIZATION_ID, CREDIT_SYNTHETIC_TOKEN } from '../protocol/native-credit-account.mjs'
import { prepareNativeCreditTls, startNativeCreditBilling } from '../protocol/native-credit-billing.mjs'
import { recognizeOnboardingPrompt } from '../protocol/pty-onboarding.mjs'
import { driveFreshNativeApp } from './apack-fresh-native-drive.mjs'

const cli = '/frozen-claude/claude'
const linuxCliHash = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
const predicateHash = 'a6498868900f4dd4eae91a7f9dae12ab9527f0dd0364d30dc273a91bd7a6a2e2'
const title = "You've spent $5 on the Anthropic API this session."
const startPrompt = 'Read the release notes before reviewing the rollout.'
const billedPrefix = 'Review the next rollout item, number '
const followup = 'Summarize the rollout checks.'
const sha = bytes => createHash('sha256').update(bytes).digest('hex')

function modelRoute(calls) {
  return async (req, res) => {
    const path = new URL(req.url,'https://api.anthropic.com').pathname
    if (req.method !== 'POST' || !['/v1/messages','/v1/messages/count_tokens'].includes(path)) return false
    assert.equal(req.headers.host,'api.anthropic.com')
    assert.equal(req.headers.authorization,'Bearer '+CREDIT_SYNTHETIC_TOKEN)
    const chunks = []
    let bytes = 0
    for await (const chunk of req) {
      bytes += chunk.length
      assert.ok(bytes <= 512*1024)
      chunks.push(chunk)
    }
    const input = JSON.parse(Buffer.concat(chunks).toString())
    assert.ok(calls.length < 32)
    const latest = input.messages?.findLast(message=>message.role==='user')?.content
    const text = typeof latest === 'string' ? latest : latest?.map(block=>block.text??'').join('\n')
    const match = new RegExp('^'+billedPrefix+'([1-8])\\.$').exec(text?.trim()??'')
    const item = path === '/v1/messages' && match ? Number(match[1]) : null
    const firstBilledCall = item !== null && !calls.some(call=>call.item===item && call.billed)
    const usage = {input_tokens:10, output_tokens:firstBilledCall?10000:5,
      cache_creation_input_tokens:firstBilledCall?140000:0, cache_read_input_tokens:0}
    calls.push({path,model:input.model,stream:input.stream===true,item,billed:firstBilledCall,
      seed:text===startPrompt,followup:text===followup,usage})
    const message = {id:'msg_owned_cost_'+calls.length,type:'message',role:'assistant',model:input.model,
      content:[{type:'text',text:'This rollout item is ready for review.'}],stop_reason:'end_turn',stop_sequence:null,usage}
    if (path.endsWith('/count_tokens') || !input.stream) {
      res.writeHead(200,{'content-type':'application/json'})
      res.end(JSON.stringify(path.endsWith('/count_tokens')?{input_tokens:10}:message))
    } else {
      res.writeHead(200,{'content-type':'text/event-stream'})
      const event = (name,fields) => res.write('event: '+name+'\ndata: '+JSON.stringify({type:name,...fields})+'\n\n')
      event('message_start',{message:{...message,content:[],stop_reason:null,usage:{...usage,output_tokens:0}}})
      event('content_block_start',{index:0,content_block:{type:'text',text:''}})
      event('content_block_delta',{index:0,delta:{type:'text_delta',text:message.content[0].text}})
      event('content_block_stop',{index:0})
      event('message_delta',{delta:{stop_reason:'end_turn',stop_sequence:null},usage:{output_tokens:usage.output_tokens}})
      event('message_stop',{})
      res.end()
    }
    return true
  }
}

export async function driveNativeCostWarning({checkout,workspace,env,choice}) {
  assert.equal(process.platform,'linux')
  assert.equal(process.getuid(),1000)
  assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-cost-threshold[0-9]+$/)
  assert.ok(['click','escape'].includes(choice))
  const boundary = JSON.parse(await readFile('/control/offline-verified'))
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly)
  assert.equal(boundary.costWarningChoice,choice)
  assert.equal(sha(await readFile(cli)),linuxCliHash)
  assert.match(await readFile('/etc/hosts','utf8'),/^127\.0\.0\.1\s+api\.anthropic\.com(?:\s|$)/m)
  const project = join(workspace,'project')
  await mkdir(project)
  await writeFile(join(project,'release-notes.md'),'# Release notes\n\nAn isolated rollout review.\n')
  execFileSync('/usr/bin/git',['init','--quiet','-b','main'],{cwd:project,env:{PATH:'/usr/bin:/bin',HOME:workspace,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'},timeout:5000})
  const account = await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'})
  const configPath = join(account.CLAUDE_CONFIG_DIR,'.claude.json')
  const config = JSON.parse(await readFile(configPath,'utf8'))
  config.oauthAccount.billingType = 'usage_based'
  config.hasCompletedOnboarding = true
  config.projects = {[project]:{hasTrustDialogAccepted:true}}
  await writeFile(configPath,JSON.stringify(config))

  const tls = await prepareNativeCreditTls(join(workspace,'account-tls'))
  const calls = [], serveModel = modelRoute(calls)
  const billing = await startNativeCreditBilling(tls,{allowMutations:false,managedConnector:async (req,res)=>{
    if (req.method==='GET' && req.url==='/api/oauth/profile') {
      assert.equal(req.headers.authorization,'Bearer '+CREDIT_SYNTHETIC_TOKEN)
      res.writeHead(200,{'content-type':'application/json'})
      res.end(JSON.stringify({account:{uuid:CREDIT_ACCOUNT_ID,email:'credit-review@example.test'},
        organization:{uuid:CREDIT_ORGANIZATION_ID,billing_type:'usage_based',has_extra_usage_enabled:false,subscription_type:'pro'}}))
      return true
    }
    return serveModel(req,res)
  }})
  try {
    const launchEnv = {...env,...account,NODE_EXTRA_CA_CERTS:tls.ca,ANTHROPIC_BASE_URL:'https://api.anthropic.com',
      DISABLE_AUTOUPDATER:'1',DISABLE_TELEMETRY:'1',DISABLE_ERROR_REPORTING:'1',
      PATH:'/frozen-claude:'+env.PATH,CLAUDE_RESEARCH_PROJECT:project}
    for (const key of ['ANTHROPIC_API_KEY','ANTHROPIC_AUTH_TOKEN','CLAUDE_INTERNAL_FC_OVERRIDES','DISABLE_COST_WARNINGS']) delete launchEnv[key]
    const preload = join(workspace,'read-cost-warning-gate.mjs')
    const gatePath = join(workspace,'linux-cost-warning-gate.json')
    await writeFile(preload,`
import { createHash } from 'node:crypto'
import { writeFileSync } from 'node:fs'
const { Et, jht }=await import('/$bunfs/root/chunk-tm94jfk2.js')
const { pIr, FL }=await import('/$bunfs/root/chunk-9gw2deqq.js')
const predicateSha256=createHash('sha256').update(Function.prototype.toString.call(pIr)).digest('hex')
if(predicateSha256!==${JSON.stringify(predicateHash)})throw Error('Pinned cost-warning predicate changed')
await jht()
writeFileSync(${JSON.stringify(gatePath)},JSON.stringify({predicateSha256,oauth:Et(),metered:FL(),admitted:pIr()}))
`)
    execFileSync(cli,['--version'],{cwd:project,env:{...launchEnv,BUN_OPTIONS:'--preload='+preload},timeout:12000})
    const gate = JSON.parse(await readFile(gatePath,'utf8'))
    assert.deepEqual(gate,{predicateSha256:predicateHash,oauth:true,metered:true,admitted:true})
    await driveFreshNativeApp({checkout,workspace,env:launchEnv,route:'real-Electron-cost-threshold',journeyBudgetMs:165000,
      journey:args=>costWarningJourney({...args,choice,configPath,calls,gate})})
  } finally {
    await billing.close()
    assert.equal(billing.state.purchases.length,0)
    assert.equal(billing.state.adminRequests.length,0)
    await writeFile(join(workspace,'account-final.json'),JSON.stringify(billing.state,null,2))
    await writeFile(join(workspace,'model-calls.json'),JSON.stringify(calls,null,2))
  }
}

async function costWarningJourney({app,page,output,project,userDataDir,expect,phase,choice,configPath,calls,gate}) {
  const proof = {status:'running',choice,gate,steps:[],captures:[]}
  const save = () => writeFile(join(output,'cost-warning.json'),JSON.stringify(proof,null,2))
  const context = () => page.evaluate(()=>{
    const c=window.applicationState.system.get('default-setup/threads').getSnapshot().context
    const v=Object.values(c.nativeTerminalViews).find(view=>view.threadId===c.currentThread?.id)
    return {threadId:c.currentThread?.id,claude:c.currentThread?.context?.claudeCode,
      native:v?.state,answer:v?.noticeAnswer,messages:c.currentThread?.messages}
  })
  const acknowledged = async () => JSON.parse(await readFile(configPath,'utf8')).hasAcknowledgedCostThreshold===true
  const composer = page.locator('[data-onboarding-id="agent-chat-input"] [contenteditable="true"]')
  const send = page.locator('[data-onboarding-id="agent-chat-input"]').getByRole('button',{name:'Send',exact:true})
  const region = page.getByRole('region',{name:'Claude native interface',exact:true})
  const dialog = page.getByRole('dialog',{name:title,exact:true})
  const button = dialog.getByRole('button',{name:'Got it, thanks!',exact:true})
  const link = dialog.getByRole('link',{name:'Monitor API spending',exact:true})
  const submit = async text => {
    await composer.fill(text)
    await expect(composer).toHaveText(text)
    await send.click()
  }
  try {
    const compiled = JSON.parse(await readFile('/control/producer-pack-inputs.json'))
    for (const part of ['runtime/fe.js','runtime/index.cjs']) {
      assert.equal(sha(await readFile(join(userDataDir,'apack/packs/default-setup',part))),compiled[part])
    }
    await app.waitForSurface('default-setup/threads')
    await app.navigate('host/settings')
    await page.evaluate(()=>{
      const settings=window.applicationState.system.get('host/settings')
      settings.send({type:'TAB.SELECT',tab:'general'})
      settings.send({type:'GENERAL_NAV.SELECT',item:'secrets'})
    })
    const provider = page.getByText('Claude Code CLI',{exact:true}).locator('..').locator('..').locator('..')
    await provider.getByPlaceholder('Path override (auto-detected if empty)').fill(cli)
    await page.waitForTimeout(700)
    await app.navigate('default-setup/threads')
    await expect.poll(()=>page.evaluate(()=>window.applicationState.system.get('default-setup/threads').getSnapshot().context.modes.some(mode=>mode.name==='Claude Code')),{timeout:15000}).toBe(true)
    await page.evaluate(directory=>{
      const threads=window.applicationState.system.get('default-setup/threads')
      threads.send({type:'VIEW_DASHBOARD'})
      threads.send({type:'NEW_THREAD_IN_PROJECT',directory})
      threads.send({type:'SET_MODE',mode:'Claude Code'})
      threads.send({type:'SET_PHASE',phase:'Edit'})
    },project)
    await submit(startPrompt)
    await expect.poll(async()=>(await context()).claude?.turns,{timeout:30000}).toBe(1)
    await region.getByRole('button',{name:'Use native interface',exact:true}).click()
    const seen = new Set()
    for (let attempt=0;attempt<100;attempt++) {
      if ((await context()).native?.status==='live') break
      const screen = await region.locator('[data-terminal-text]').innerText().catch(()=>'')
      const step = recognizeOnboardingPrompt(screen,project)
      if (step && !seen.has(step)) {
        seen.add(step)
        await region.locator('[aria-label="Terminal input"]').focus()
        await page.waitForTimeout(200)
        await page.keyboard.press(step==='workspace-trust'?'ArrowDown':'Enter')
      }
      await page.waitForTimeout(100)
    }
    await expect.poll(async()=>(await context()).native?.status,{timeout:25000}).toBe('live')
    const initial = await context()
    proof.owner={threadId:initial.threadId,sessionId:initial.native.sessionId,ownerId:initial.native.ownerId,pid:initial.native.nativePid}
    assert.ok(proof.owner.threadId && proof.owner.sessionId && proof.owner.ownerId && proof.owner.pid)
    await region.getByRole('button',{name:'Back to conversation',exact:true}).click()
    assert.equal(await acknowledged(),false)
    await expect(dialog).toBeHidden()
    await save()
    for (let item=1;item<=8;item++) {
      await submit(billedPrefix+item+'.')
      await expect.poll(async()=>{
        const c=await context()
        return calls.some(call=>call.item===item && call.billed) && c.native?.busy===false
          && (c.claude?.chatState==='success' || c.native.notice?.kind==='cost_threshold')
      },{timeout:20000}).toBe(true)
      await expect.poll(async()=>(await context()).claude?.totalCostUsd??0,{timeout:10000}).toBeGreaterThan(proof.steps.at(-1)?.usd??0)
      const c=await context()
      proof.steps.push({item,usd:c.claude.totalCostUsd})
      await save()
      if (c.claude.totalCostUsd>=5) break
      await expect(dialog).toBeHidden()
    }
    await expect(dialog).toBeVisible({timeout:12000})
    assert.ok(proof.steps.at(-1).usd>=5)
    const warn = await context()
    proof.notice=warn.native.notice
    assert.equal(proof.notice?.kind,'cost_threshold')
    assert.equal(proof.notice.sessionId,proof.owner.sessionId)
    await expect(link).toHaveAttribute('href','https://code.claude.com/docs/en/costs')
    for (const [size,viewport] of [['normal',{width:1100,height:900}],['compact',{width:680,height:600}]]) {
      await page.setViewportSize(viewport)
      await page.evaluate(()=>document.fonts.ready)
      await expect(dialog).toBeInViewport({ratio:0.9})
      await expect(button).toBeInViewport({ratio:1})
      await expect(link).toBeInViewport({ratio:1})
      const name='cost-warning-'+size+'.png'
      await page.screenshot({path:join(output,name),animations:'disabled'})
      proof.captures.push(name)
    }
    assert.equal(await acknowledged(),false)
    if(choice==='click') await button.click()
    else {
      await button.focus()
      await button.press('Escape')
    }
    await expect(dialog).toBeHidden({timeout:12000})
    await expect.poll(acknowledged,{timeout:10000}).toBe(true)
    const answered=await context()
    assert.equal(answered.answer?.status,'done')
    assert.equal(answered.answer?.revision,proof.notice.revision)
    proof.acknowledgement=answered.answer
    await submit(followup)
    await expect.poll(async()=>{
      const c=await context()
      return calls.some(call=>call.followup) && c.claude?.chatState==='success' && c.native?.busy===false
    },{timeout:22000}).toBe(true)
    const returned=await context()
    assert.equal(returned.threadId,proof.owner.threadId)
    assert.equal(returned.native.sessionId,proof.owner.sessionId)
    assert.equal(returned.native.ownerId,proof.owner.ownerId)
    const messages=returned.messages.filter(message=>message.sender==='user' && message.text===followup)
    assert.equal(messages.length,1)
    assert.ok(messages[0].context?.cliUuid)
    proof.followup={sessionId:returned.native.sessionId,cliUuid:messages[0].context.cliUuid}
    await expect(dialog).toBeHidden()
    await region.getByRole('button',{name:'Use native interface',exact:true}).click({timeout:10000})
    const reopened=await context()
    assert.equal(reopened.native?.sessionId,proof.owner.sessionId)
    assert.equal(reopened.native?.nativePid,proof.owner.pid)
    await region.getByRole('button',{name:'Stop session',exact:true}).click({timeout:10000})
    await expect.poll(()=>readFile('/proc/'+proof.owner.pid+'/stat','utf8').then(text=>!text.includes(') Z '),()=>false),{timeout:15000}).toBe(false)
    proof.status='complete'
    phase('native-cost-warning-'+choice+'-complete')
  } catch (error) {
    proof.error=error.message
    proof.observed=await context().catch(()=>null)
    throw error
  } finally {
    await save()
  }
}
