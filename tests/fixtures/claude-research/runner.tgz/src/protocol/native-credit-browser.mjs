import assert from 'node:assert/strict';
import {writeFile,access} from 'node:fs/promises';
import {join,isAbsolute,basename} from 'node:path';
export const NATIVE_CREDIT_USAGE_URL='https://claude.ai/settings/usage?from=cc_cli_limit_message';
/** A user-configured BROWSER process, recording only its argv/exit; never opens a real browser. */
export async function prepareNativeCreditBrowser(workspace,outcome){
 assert.ok(isAbsolute(workspace));assert.match(basename(workspace),/^(apack-terminal-owner-app-mid-credit\d+|native-credit-browser-.+)$/);assert.ok(['success','failure'].includes(outcome));
 const command=join(workspace,'owned-credit-browser.py'),receiptPath=join(workspace,'browser-handoff.jsonl'),exitCode=outcome==='success'?0:1;
 await assert.rejects(access(receiptPath),{code:'ENOENT'});
 const source=`#!/usr/bin/python3\nimport json,os,sys\nargs=sys.argv[1:]\nif args!=[${JSON.stringify(NATIVE_CREDIT_USAGE_URL)}]: raise SystemExit(78)\nwith open(${JSON.stringify(receiptPath)},'a') as output:\n output.write(json.dumps({'pid':os.getpid(),'parentPid':os.getppid(),'url':args[0],'exitCode':${exitCode}})+'\\n')\nraise SystemExit(${exitCode})\n`;
 await writeFile(command,source,{mode:0o700,flag:'wx'});return {command,receiptPath};
}
