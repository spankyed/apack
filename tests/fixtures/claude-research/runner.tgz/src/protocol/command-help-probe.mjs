import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {createRun,hash} from '../artifacts/runs.mjs';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';

export function inspectCommandHelp(stdout,path) {
  const text=stdout.replace(/\x1b\[[0-9;]*m/g,'');
  const usage=text.match(/^Usage:\s+(.+)$/m)?.[1]??null;
  const words=usage?.split(/\s+/)??[];
  const matched=['claude',...path].every((part,index)=>(words[index]??'').split('|').includes(part));
  const section=text.split(/^Commands:\s*$/m)[1]?.split(/^\S[^\n]*:\s*$/m)[0]??'';
  const commands=section.split('\n').flatMap(line=>{
    const match=line.match(/^\s{2,}(\S.*?)(?:\s{2,})(\S.*)$/);
    return match?[{declaration:match[1],description:match[2]}]:[];
  });
  return {usage,matched,commands};
}

export async function probeCommandHelp(executable,workspace,output) {
  executable=resolve(executable);workspace=resolve(workspace);
  await mkdir(workspace,{recursive:true});
  const cwd=await mkdtemp(join(workspace,'command-help-'));
  const paths=[['auth'],['auth','login'],['auto-mode'],['plugin'],['plugin','eval'],['plugin','marketplace'],['mcp'],['mcp','xaa'],['sandbox'],['project'],['edit-hook'],['edit-permission-rules']];
  const suite=await createRun(output,'command-help',{targetSha256:hash(await readFile(executable)),paths,
    driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
  const model=await startSyntheticModel(cwd,'TextOnly');
  try {
    const cases=[];
    for(const path of paths) {
      const run=await record({executable,cwd,output,timeoutMs:10000,maxBytes:1024*1024,
        args:['--setting-sources','','--strict-mcp-config','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),...path,'--help'],
        env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),ANTHROPIC_BASE_URL:model.url,
          DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}});
      const stdout=await readFile(join(run.directory,'stdout.bin'),'utf8');
      cases.push({path,run:run.directory,status:run.status,code:run.code,signal:run.signal,reason:run.reason,...inspectCommandHelp(stdout,path)});
    }
    const result={cases,modelRequests:model.calls.length,qualification:'Matching namespace help verifies parser/help access only, not command execution, account entitlement or app support.'};
    await writeFile(join(suite.directory,'command-help.json'),JSON.stringify(result,null,2)+'\n');
    assert.equal(model.calls.length,0,'Help must not invoke a model');
    const complete=cases.every(value=>!value.reason&&value.signal===null&&Number.isInteger(value.code));
    await suite.finish({status:complete?'complete':'failed',matched:cases.filter(value=>value.matched).length,modelRequests:0});
    return {directory:suite.directory,status:complete?'complete':'failed',...result};
  } catch(error) {await suite.finish({status:'failed',error:error.message});throw error}
  finally {await model.close()}
}
