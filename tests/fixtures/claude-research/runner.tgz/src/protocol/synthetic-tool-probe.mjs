import { fileURLToPath } from 'node:url';
import { mkdir, writeFile, readFile, mkdtemp } from 'node:fs/promises';
import { join } from 'node:path';
import { record } from './record.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

/** Actual CLI tools against a loopback-only synthetic Anthropic API; never a real model. */
export async function probeSyntheticTool(executable, workspace, output, decision = 'allow', profile = 'bare') {
  if (!['bare', 'full', 'full-context', 'full-search'].includes(profile)) throw new Error('Expected bare, full or full-context profile');
  if (!['allow', 'deny', 'interrupt', 'interrupt-resume', 'interrupt-queue', 'cancel-queued', 'ask-question', 'approve-plan', 'hook-callback', 'hook-deny', 'mcp-echo', 'background', 'background-close'].includes(decision)) throw new Error('Expected allow, deny, interrupt, interrupt-resume, interrupt-queue or cancel-queued');
  await mkdir(workspace, { recursive: true });
  const cwd = await mkdtemp(join(workspace, `${profile}-${decision}-`));
  const home = profile === 'full-context' ? join(cwd, 'isolated-home') : cwd;
  await mkdir(home, { recursive: true });
  if (profile === 'full-context') {
    await writeFile(join(cwd, 'CLAUDE.md'), 'Research fixture: keep responses concise. This is disposable context evidence.\n');
    await mkdir(join(cwd, '.claude', 'skills', 'research-context-fixture'), { recursive: true });
    await writeFile(join(cwd, '.claude', 'skills', 'research-context-fixture', 'SKILL.md'),
      '---\nname: research-context-fixture\ndescription: Synthetic skill for context inventory verification only.\n---\nWhen explicitly invoked, reply with the fixture confirmation.\n');
  }
  const model = await startSyntheticModel(cwd, decision.startsWith('background') ? 'BashBackground' : decision === 'mcp-echo' ? 'mcp__research__echo' : decision === 'approve-plan' ? 'ExitPlanMode' : decision === 'ask-question' ? 'AskUserQuestion' : 'Bash');
  const request = (id, payload) => JSON.stringify({ type: 'control_request', request_id: id, request: payload }) + '\n';
  let pending = '', terminalResult, contextResponse, permissionWaiting, toolResult, interruptResponse, cancelQueuedResponse, mcpStatus;
  const cancelledRequests = [];
  const lifecycle = [];
  const hookCallbacks = [];
  const backgroundEvents = [];
  const results = [];
  const interrupts = decision.startsWith('interrupt');
  const permissions = [];
  try {
    const run = await record({ executable, cwd, output, timeoutMs: 30000,
      args: ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json',
        ...(profile === 'bare' ? ['--bare'] : []), '--setting-sources', profile === 'full-context' ? 'project' : '', '--settings', JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' }),
        '--strict-mcp-config', ...(decision === 'mcp-echo' ? ['--mcp-config', JSON.stringify({ mcpServers: { research: {
          type: 'stdio', command: process.execPath, args: [fileURLToPath(new URL('./synthetic-mcp-server.mjs', import.meta.url))],
        } } })] : []), '--tools', profile === 'bare' ? 'Bash' : 'default', '--permission-mode', decision === 'approve-plan' ? 'plan' : 'default', '--model', profile === 'bare' ? 'claude-sonnet-4-6' : 'default',
        '--no-session-persistence', '--max-turns', '3', '--permission-prompt-tool', 'stdio'],
      env: { PATH: process.env.PATH, HOME: home, CLAUDE_CONFIG_DIR: join(home, '.claude'),
        ANTHROPIC_BASE_URL: model.url, ...(profile === 'full-search' ? { ENABLE_TOOL_SEARCH: 'true' } : {}), DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
      input: [request('initialize', { subtype: 'initialize', hooks: ['hook-callback', 'hook-deny', 'mcp-echo', 'background', 'background-close'].includes(decision)
        ? { PreToolUse: [{ matcher: 'Bash', hookCallbackIds: ['research-pre-tool'] }] } : {} })],
      onStdout(bytes, transport) {
        pending += bytes.toString();
        while (pending.includes('\n')) {
          const at = pending.indexOf('\n');
          const line = pending.slice(0, at); pending = pending.slice(at + 1);
          let value; try { value = JSON.parse(line); } catch { continue; }
          if (value.type === 'control_response' && value.response?.request_id === 'initialize') {
            transport.send(JSON.stringify({ type: 'user', uuid: '22222222-2222-4222-8222-222222222222', message: { role: 'user',
              content: 'Create fixture.txt with the literal content synthetic protocol fixture.' }, parent_tool_use_id: null }) + '\n');
          }
          if (value.type === 'control_request' && value.request?.subtype === 'hook_callback') {
            hookCallbacks.push(value);
            transport.send(JSON.stringify({ type: 'control_response', response: { subtype: 'success',
              request_id: value.request_id, response: decision === 'hook-deny'
                ? { hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny',
                  permissionDecisionReason: 'Synthetic hook denies execution' } } : {} } }) + '\n');
          }
          if (value.type === 'control_request' && value.request?.subtype === 'can_use_tool') {
            permissions.push(value); permissionWaiting = value;
            transport.send(decision === 'mcp-echo' ? request('paused-mcp', { subtype: 'mcp_status' })
              : request('paused-context', { subtype: 'get_context_usage', detail: 'summary' }));
          }
          if (value.type === 'control_response' && value.response?.request_id === 'paused-mcp') {
            mcpStatus = value.response;
            transport.send(request('paused-context', { subtype: 'get_context_usage', detail: 'summary' }));
          }
          if (value.type === 'control_response' && value.response?.request_id === 'paused-context') {
            contextResponse = value.response;
            if (decision === 'cancel-queued') {
              transport.send(JSON.stringify({ type: 'user', uuid: '11111111-1111-4111-8111-111111111111',
                message: { role: 'user', content: 'Queued fixture to cancel without interrupting.' }, parent_tool_use_id: null }) + '\n');
              transport.send(request('cancel-queued-input', { subtype: 'cancel_async_message',
                message_uuid: '11111111-1111-4111-8111-111111111111' }));
              continue;
            }
            if (interrupts) {
              if (decision === 'interrupt-queue') {
                transport.send(JSON.stringify({ type: 'user', uuid: '11111111-1111-4111-8111-111111111111',
                  message: { role: 'user', content: 'Queued fixture message that must be cancelled.' },
                  parent_tool_use_id: null }) + '\n');
              }
              transport.send(request('interrupt-pending', { subtype: 'interrupt',
                ...(decision === 'interrupt-queue' ? { cancel_queued: true } : {}) }));
              continue;
            }
            transport.send(JSON.stringify({ type: 'control_response', response: { subtype: 'success',
              request_id: permissionWaiting.request_id, response: ['allow', 'ask-question', 'approve-plan', 'hook-callback', 'hook-deny', 'mcp-echo', 'background', 'background-close'].includes(decision)
                ? { behavior: 'allow', updatedInput: decision === 'ask-question'
                  ? { ...permissionWaiting.request.input, answers: { 'Which synthetic fixture should be selected?': 'Alpha' } }
                  : permissionWaiting.request.input }
                : { behavior: 'deny', message: 'Synthetic fixture denies this tool' } } }) + '\n');
          }
          if (value.type === 'command_lifecycle') lifecycle.push(value);
          if (value.type === 'control_response' && value.response?.request_id === 'cancel-queued-input') {
            cancelQueuedResponse = value.response;
            transport.send(JSON.stringify({ type: 'control_response', response: { subtype: 'success',
              request_id: permissionWaiting.request_id, response: { behavior: 'allow', updatedInput: permissionWaiting.request.input } } }) + '\n');
          }
          if (value.type === 'control_cancel_request') cancelledRequests.push(value.request_id);
          if (value.type === 'control_response' && value.response?.request_id === 'interrupt-pending') interruptResponse = value.response;
          if (value.type === 'user' && Array.isArray(value.message?.content)) {
            toolResult ??= value.message.content.find(block => block.type === 'tool_result'
              && block.tool_use_id === 'toolu_research_fixture');
          }
          if (value.type === 'system' && value.subtype?.startsWith('task_')) {
            backgroundEvents.push({ ...value, afterResult: results.length > 0 });
            if (decision === 'background' && value.subtype === 'task_notification' && results.length) transport.closeInput();
          }
          if (value.type === 'result') {
            results.push(value); terminalResult = value;
            if (decision === 'interrupt-resume' && results.length === 1) {
              transport.send(JSON.stringify({ type: 'user', message: { role: 'user',
                content: 'Continue with a short fixture confirmation. Do not use tools.' }, parent_tool_use_id: null }) + '\n');
            } else if (decision !== 'background') transport.closeInput();
          }
        }
      },
    });
    let file;
    try { file = await readFile(join(cwd, 'fixture.txt'), 'utf8'); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
    const interrupted = results[0]?.terminal_reason === 'aborted_tools' && results[0]?.is_error === true;
    const populatedContext = profile !== 'full-context' || (
      contextResponse?.response?.memoryFiles?.some(file => file.path.endsWith('/CLAUDE.md'))
      && contextResponse?.response?.skills?.skillFrontmatter?.some(skill => skill.name === 'research-context-fixture'));
    const verified = decision.startsWith('background')
      ? run.status === 'complete' && permissions.length === 1 && file === 'synthetic protocol fixture\n'
        && backgroundEvents.some(event => event.subtype === 'task_notification' && event.afterResult && event.status === 'completed')
        && results.length === 2 && results.every(result => result.subtype === 'success') && model.calls.length === 3
      : decision === 'hook-deny'
      ? run.status === 'complete' && permissions.length === 0 && file === undefined
        && hookCallbacks.length === 1 && hookCallbacks[0].request.callback_id === 'research-pre-tool'
        && toolResult?.is_error === true && terminalResult?.subtype === 'success' && model.calls.length === 2
      : populatedContext && (interrupts
      ? run.reason === undefined && run.code === (decision === 'interrupt-resume' ? 0 : 1) && permissions.length === 1 && file === undefined
        && contextResponse?.subtype === 'success' && interruptResponse?.subtype === 'success'
        && cancelledRequests.includes(permissionWaiting.request_id)
        && interrupted
        && (decision !== 'interrupt-queue'
          || (interruptResponse.response?.cancelled?.length === 1
            && interruptResponse.response.cancelled[0] === '11111111-1111-4111-8111-111111111111'
            && interruptResponse.response.still_queued?.length === 0
            && terminalResult.queued_turn_count === 0))
        && (decision !== 'interrupt-resume' ? model.calls.length === 1 && results.length === 1
          : model.calls.length === 2 && results.length === 2 && terminalResult?.subtype === 'success'
            && results[0].session_id === terminalResult.session_id)
      : run.status === 'complete' && permissions.length === 1
      && contextResponse?.subtype === 'success' && terminalResult?.subtype === 'success'
      && model.calls.length === (profile === 'full-search' ? 3 : 2) && toolResult !== undefined
      && (decision === 'mcp-echo'
        ? file === undefined && !toolResult.is_error && permissions[0].request.tool_name === 'mcp__research__echo'
          && mcpStatus?.subtype === 'success'
          && mcpStatus.response?.mcpServers?.some(server => server.name === 'research' && server.status === 'connected')
          && JSON.stringify(toolResult.content).includes('synthetic MCP echo')
        : decision === 'hook-callback'
        ? file === 'synthetic protocol fixture\n' && !toolResult.is_error && hookCallbacks.length === 1
          && hookCallbacks[0].request.callback_id === 'research-pre-tool'
          && hookCallbacks[0].request.input.hook_event_name === 'PreToolUse'
        : decision === 'approve-plan'
        ? file === undefined && !toolResult.is_error && permissions[0].request.tool_name === 'ExitPlanMode'
        : decision === 'ask-question'
        ? file === undefined && !toolResult.is_error && permissions[0].request.tool_name === 'AskUserQuestion'
          && JSON.stringify(toolResult.content).includes('Alpha')
        : decision === 'cancel-queued'
        ? file === 'synthetic protocol fixture\n' && !toolResult.is_error
          && cancelQueuedResponse?.subtype === 'success' && cancelQueuedResponse.response?.cancelled === true
          && results.length === 1
          && JSON.stringify(lifecycle.filter(event => event.command_uuid === '22222222-2222-4222-8222-222222222222').map(event => event.state)) === JSON.stringify(['queued', 'started', 'completed'])
          && cancelledRequests.length === 0
          && JSON.stringify(lifecycle.filter(event => event.command_uuid === '11111111-1111-4111-8111-111111111111').map(event => event.state)) === JSON.stringify(['queued', 'cancelled'])
        : decision === 'allow' ? file === 'synthetic protocol fixture\n' && !toolResult.is_error
        : file === undefined && toolResult.is_error === true));
    const summary = { ...run, status: verified ? 'complete' : 'failed', transportStatus: run.status, decision, profile, verified,
      permissionCount: permissions.length, contextWhilePermissionPending: contextResponse?.subtype === 'success',
      fileCreated: file !== undefined, observedTools: model.calls.find(call => call.toolNames)?.toolNames ?? [], syntheticApiRequests: model.calls.length, realModelRequests: 0 };
    await writeFile(join(run.directory, 'synthetic-server.json'), JSON.stringify({
      ...summary, backgroundEvents, mcpStatus, hookCallbacks, results, lifecycle, cancelQueuedResponse, calls: model.calls, permissions, file, terminalResult, contextResponse, toolResult, interruptResponse, cancelledRequests,
      qualification: 'Actual CLI protocol against a local synthetic model API; no real model or user credentials.',
    }, null, 2) + '\n');
    if (!verified) {
      const path = join(run.directory, 'manifest.json');
      const manifest = JSON.parse(await readFile(path, 'utf8'));
      await writeFile(path, JSON.stringify({ ...manifest, status: 'failed', reason: 'synthetic-tool-verification-failed' }, null, 2) + '\n');
    }
    return summary;
  } finally { await model.close(); }
}
