import assert from 'node:assert/strict';
import { access, mkdir, readFile, writeFile } from 'node:fs/promises';
import { isAbsolute, join } from 'node:path';
import { hash } from '../artifacts/runs.mjs';
import { makeNativePageReviewPdf } from './native-read-media-fixture.mjs';
import { record } from './record.mjs';

const [executable, workspace, output, mode = 'decode'] = process.argv.slice(2);
const target = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10';
const functions = {
  PG: '154a89de1fc7b39bd010cc76ce6d2eab253bac6e786f905297d810dca18c7e29',
  Oye: '47f1555b64a8aedef42ed71b3b2b539dd44e2302c257a7ee221f882e66040d76',
};

assert.equal(process.platform, 'linux');
await access('/.dockerenv');
assert.equal((await readFile('/proc/net/route', 'utf8')).trim().split('\n').length, 1);
assert.ok([executable, workspace, output].every(path => path && isAbsolute(path)));
assert.equal(hash(await readFile(executable)), target);
await mkdir(workspace);
assert.ok(['decode', 'local-admission'].includes(mode));
if (mode === 'local-admission') await probeLocalAdmission();
else await probeResultEnvelope();

async function probeResultEnvelope() {
  const pdf = makeNativePageReviewPdf();
  const pdfPath = join(workspace, 'review.pdf');
  const reportPath = join(workspace, 'native-results.json');
  const preloadPath = join(workspace, 'result-fixture.mjs');
  await writeFile(pdfPath, pdf);

  const preload = String.raw`
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const sha = data => createHash('sha256').update(data).digest('hex');
assert.equal(sha(readFileSync(process.execPath)), ${JSON.stringify(target)});
const schema = await import('/$bunfs/root/chunk-3bwt2mt1.js');
const { Oye } = await import('/$bunfs/root/chunk-m60stpyf.js');
const read = await import('/$bunfs/root/chunk-k1sx7h4r.js');
assert.equal(read.Qe, 'Read');
const functions = { PG: schema.PG, Oye };
const hashes = Object.fromEntries(Object.entries(functions).map(([name, fn]) => [name, sha(Function.prototype.toString.call(fn))]));
assert.deepEqual(hashes, ${JSON.stringify(functions)});

const pdf = readFileSync(${JSON.stringify(pdfPath)});
const placeholder = schema.G2n + 'review-host, example fixture)';
const text = text => ({type: 'text', text});
const doc = (at, bytes = pdf) => ({at, media_type: 'application/pdf', data: bytes.toString('base64')});
const target = {name: 'review-host', working_dir: '/read-fixture'};
const host = {name: target.name, description: {working_dir: target.working_dir}, transport: {kind: 'session'}};
const variant = Buffer.from(pdf.toString().replace('Release review page', 'Release report page'));
const padded = size => Buffer.concat([pdf, Buffer.alloc(size - pdf.length, 32)]);
const cases = [];
function observe(name, {content = [text(placeholder)], documents, tool = read.Qe, afterReconnect = false, envelope = true} = {}) {
  const original = {outcome: 'completed', v: schema.cu, target, is_error: false, content, documents};
  const wire = {
    content: [text('fallback')],
    ...(envelope ? {structuredContent: {[schema.EM]: original}} : {}),
  };
  const parsed = schema.PG(wire);
  const receipt = parsed.envelope;
  const {outcome} = Oye({name: tool}, host, {
    kind: 'result', isError: parsed.isError, content: parsed.content,
    ...(receipt.status === 'present' ? {envelope: receipt.envelope} : {}),
  }, {afterReconnect});
  assert.equal(outcome.kind, 'completed', name);
  const rendered = typeof outcome.content === 'string' ? outcome.content : outcome.content.map(block => block.type === 'document'
    ? {type: 'document', length: block.source.data.length, sha256: sha(Buffer.from(block.source.data, 'base64')), mediaType: block.source.media_type}
    : block);
  cases.push({name, envelope: receipt.status, candidates: receipt.envelope?.documents?.length ?? 0, delivery: outcome.delivery, rendered});
}
observe('fresh', {content: [text('before'), text(placeholder), text('after')], documents: [doc(1)]});
observe('reconnected', {documents: [doc(0)], afterReconnect: true});
observe('other-tool', {documents: [doc(0)], tool: 'Grep'});
observe('wrong-index', {documents: [doc(1)]});
observe('wrong-placeholder', {content: [text('plain result')], documents: [doc(0)]});
observe('wrong-signature', {documents: [doc(0, Buffer.from('not a PDF'))]});
observe('malformed-wire', {documents: [{...doc(0), data: '@@@'}]});
observe('first-duplicate-wins', {documents: [doc(0), doc(0, variant)]});
observe('string-result', {content: placeholder, documents: [doc(0)]});
observe('missing-envelope', {documents: [doc(0)], envelope: false});
observe('aggregate-budget', {content: [text(placeholder), text(placeholder)], documents: [doc(0, padded(4 * 1024 * 1024)), doc(1, padded(3 * 1024 * 1024))]});
observe('oversized-candidate', {documents: [doc(0, padded(6 * 1024 * 1024 + 1))]});
observe('wire-entry-cap', {content: Array.from({length: 5}, () => text(placeholder)), documents: Array.from({length: 5}, (_, index) => doc(index))});
writeFileSync(${JSON.stringify(reportPath)}, JSON.stringify({hashes, target: sha(readFileSync(process.execPath)), placeholder, cases}));
`;
  await writeFile(preloadPath, preload);
  const run = await record({
    executable, args: ['--version'], cwd: workspace, output,
    env: { HOME: workspace, PATH: process.env.PATH, CLAUDE_CONFIG_DIR: join(workspace, '.claude'),
      BUN_OPTIONS: '--preload=' + preloadPath, DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
    timeoutMs: 15000,
  });
  assert.equal(run.code, 0);
  const result = JSON.parse(await readFile(reportPath, 'utf8'));
  const rendered = Object.fromEntries(result.cases.map(row => [row.name, row.rendered]));
  const placeholder = {type: 'text', text: result.placeholder};
  const document = {type: 'document', sha256: hash(pdf), length: pdf.toString('base64').length, mediaType: 'application/pdf'};
  assert.equal(result.target, target);
  assert.deepEqual(rendered.fresh, [{type:'text', text:'before'}, document, {type:'text', text:'after'}]);
  assert.deepEqual(rendered.reconnected, [document]);
  assert.equal(result.cases.find(row => row.name === 'reconnected').delivery, 'after_reconnect');
  for (const name of ['other-tool','wrong-index','wrong-signature','malformed-wire','oversized-candidate']) {
    assert.deepEqual(rendered[name], [placeholder], name);
  }
  assert.deepEqual(rendered['wrong-placeholder'], [{type: 'text', text: 'plain result'}]);
  assert.equal(result.cases.find(row => row.name === 'malformed-wire').candidates, 0);
  assert.deepEqual(rendered['first-duplicate-wins'], [document]);
  assert.equal(rendered['string-result'], result.placeholder);
  assert.deepEqual(rendered['missing-envelope'], [{type: 'text', text: 'fallback'}]);
  assert.equal(rendered['aggregate-budget'][0].type, 'document');
  assert.equal(rendered['aggregate-budget'][0].length, Math.ceil(4 * 1024 * 1024 / 3) * 4);
  assert.deepEqual(rendered['aggregate-budget'][1], placeholder);
  assert.deepEqual(rendered['wire-entry-cap'], [document, document, document, document, placeholder]);
  assert.equal(result.cases.find(row => row.name === 'wire-entry-cap').candidates, 4);
  await writeFile(join(run.directory, 'attached-read-results.json'), JSON.stringify({
    ...result, run, modelRequests: 0,
    scope: 'Original completed-envelope parser and Read result projection on synthetic owned payloads.',
  }, null, 2) + '\n');
  console.log(JSON.stringify({ ...run, cases: result.cases.length }));
}

async function probeLocalAdmission() {
  const request = (id, payload) => JSON.stringify({type: 'control_request', request_id: id, request: payload}) + '\n';
  let pending = '', initialization, announcement;
  const run = await record({
    executable, cwd: workspace, output, timeoutMs: 15000,
    args: ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json',
      '--strict-mcp-config', '--setting-sources', '', '--no-session-persistence',
      '--settings', JSON.stringify({apiKeyHelper: '/usr/bin/printf research-fixture-key'})],
    env: {HOME: workspace, PATH: process.env.PATH, CLAUDE_CONFIG_DIR: join(workspace, '.claude'),
      DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1'},
    input: [request('initialize', {subtype: 'initialize', hooks: {}})],
    onStdout(bytes, transport) {
      pending += bytes.toString('utf8');
      while (pending.includes('\n')) {
        const end = pending.indexOf('\n'), line = pending.slice(0, end);
        pending = pending.slice(end + 1);
        const row = JSON.parse(line);
        if (row.type !== 'control_response') continue;
        if (row.response.request_id === 'initialize') {
          initialization = row.response;
          assert.equal(initialization.subtype, 'success');
          transport.send(request('attached-read', {
            subtype: 'remote_tools_announce',
            instance_id: 'fixturehost123456789',
            host: {name: 'review-host', kind: 'personal_machine', platform: 'linux', working_dir: workspace,
              project_sync: 'off', limits: {}, claude_code_version: '2.1.302', epoch: 1},
            tools: [{name: 'Read', refused_input_fields: [], protocol_versions: [1]}],
            passthrough: [], plumbing: [],
          }));
        } else if (row.response.request_id === 'attached-read') {
          announcement = row.response;
          transport.closeInput();
        }
      }
    },
  });
  await writeFile(join(run.directory, 'local-attached-read-admission.json'), JSON.stringify({
    target, run, initialized: initialization?.subtype, announcement, submittedPrompts: 0,
    scope: 'Ordinary local print session, original announcement admission.',
  }, null, 2) + '\n');
  assert.equal(initialization?.subtype, 'success');
  assert.equal(announcement?.subtype, 'error');
  assert.equal(announcement.error, 'remote_tools_disabled: not_managed_cloud_worker');
  assert.equal(run.code, 0);
  console.log(JSON.stringify({ ...run, refusal: announcement.error }));
}
