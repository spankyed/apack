import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Extends the original print Client journey with original settings, prompt hooks and theme watcher. */
export async function addNativePrintThemeFixture(plugin,workspace){
 const file=join(plugin,'hooks/register.ts');let source=await readFile(file,'utf8');
 source=source.replace('export function register(on){',`export function register(on){let fills=0;const edits=[];on('prompt.edit',async($,e,next)=>{const original=await next(e);const result={...original,decorations:original.text.length?[{start:0,end:Math.min(6,original.text.length),color:'warning',backgroundColor:'inverseText'}]:[]};edits.push({text:e.text,result});await $.fs.write('native-print-theme-edits.json',JSON.stringify(edits));return result;});`);
 source=source.replace('const {Client}=$.ui.resolve(e);return Client(',"const {Box,Text,Button,Client}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Text({color:'warning',children:['Release review']}),Button({key:'review-template',label:'Use review template',onPress:async()=>{const call=++fills;const before=await $.prompt.read();const result=await $.prompt.fill({text:'Review release notes before merging.',decorations:[{start:0,end:6,color:'warning',backgroundColor:'inverseText'}]});const after=await $.prompt.read();await $.fs.write('native-print-theme-fill.json',JSON.stringify({call,before,result,after}));}}),Client(").replace("width:48,height:14});});", "width:48,height:14})]});});");
 await writeFile(file,source);
 const module=join(plugin,'hooks/print-status.ts');await writeFile(module,(await readFile(module,'utf8')).replace("Text({children:[props.label", "Text({color:'success',children:[props.label"));
 const settings=join(workspace,'.claude/settings.json');await writeFile(settings,JSON.stringify({...JSON.parse(await readFile(settings,'utf8')),theme:'custom:research'}));
 await mkdir(join(workspace,'.claude/themes'),{recursive:true});await writeFile(join(workspace,'.claude/themes/research.json'),JSON.stringify({name:'Research',base:'dark',overrides:{text:'#e0e0e0',inverseText:'#263241',warning:'#abcdef',success:'#83c9a1'}}));
}
