import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';
/** Trust attestation is restricted to this newly created synthetic folder/private HOME. */
export async function probePermissionCatalogTrust(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'permission-trust-')),cwd=join(workspace,'project'),config=join(workspace,'home','.claude');await mkdir(join(cwd,'.claude'),{recursive:true});await mkdir(config,{recursive:true});
 await writeFile(join(cwd,'.claude','settings.json'),JSON.stringify({permissions:{allow:['Read(./fixture.txt)'],deny:['Bash']}}));
 const run=await createRun(output,'permission-catalog-trust',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url)))});const cases=[];
 try{
  for(const attest of [false,true]){
   let pending='';const replies=[],requests=[{subtype:'initialize',hooks:{},...attest?{workspaceTrust:{accepted:true,directory:cwd}}:{}},{subtype:'get_settings'},{subtype:'list_permission_rules'}];
   const line=i=>JSON.stringify({type:'control_request',request_id:`trust-${i}`,request:requests[i]})+'\n';
   const transport=await record({executable,cwd,output,timeoutMs:10000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--no-session-persistence'],env:{PATH:process.env.PATH,HOME:join(workspace,'home'),CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[line(0)],onStdout(bytes,channel){pending+=bytes.toString();while(pending.includes('\n')){const i=pending.indexOf('\n'),text=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(text)}catch{continue}if(value.type!=='control_response'||value.response?.request_id!==`trust-${replies.length}`)continue;replies.push(value.response);if(replies.length<requests.length)channel.send(line(replies.length));else channel.closeInput()}}});
   assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(replies.length,3);for(const reply of replies)assert.equal(reply.subtype,'success');
   const permissions=replies[1].response.effective.permissions,state=replies[2].response.state;
   assert.ok(permissions.allow.includes('Read(./fixture.txt)'));assert.ok(state.rules.some(rule=>rule.source==='projectSettings'&&rule.rule==='Bash'&&rule.behavior==='deny'));
   assert.equal(state.rules.some(rule=>rule.source==='projectSettings'&&rule.rule==='Read(./fixture.txt)'&&rule.behavior==='allow'),attest);
   if(attest)assert.equal(replies[0].response.workspace_trust_recorded,true);
   cases.push({attestationSent:attest,trustRecorded:replies[0].response.workspace_trust_recorded??null,effectivePermissions:permissions,state,transportRun:transport.directory});
  }
  const normalized=JSON.parse(JSON.stringify(cases).split(workspace).join('${WORKSPACE}'));await writeFile(join(run.directory,'permission-catalog-trust.json'),JSON.stringify({cases:normalized,modelPrompts:0,qualification:'Synthetic owned-folder protocol attestation only, not a real user dialog or app trust workflow. Effective settings and native permission context differ; repo roots, policy, live updates and actual tool effects are separate.'},null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',cases:2,modelPrompts:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
