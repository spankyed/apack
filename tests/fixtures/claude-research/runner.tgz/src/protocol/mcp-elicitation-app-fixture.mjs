import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
export const mcpElicitationSteps = ['form-accept','form-decline','form-cancel','url-accept','url-decline','url-cancel','form-interrupt'].map((scenario,index)=>({scenario,phase:index+1,prompt:'Review release input '+(index+1)+'.'}));
export const mcpReleaseForm = {type:'object',properties:{title:{type:'string',title:'Release title',minLength:3,default:'Migration notes'},enabled:{type:'boolean',title:'Include archived notes',default:false},count:{type:'integer',title:'Additional reviewers',minimum:0,maximum:5,default:0},email:{type:'string',title:'Reviewer email',format:'email'},date:{type:'string',title:'Review date',format:'date',default:'2026-10-22'},audience:{type:'string',title:'Audience',oneOf:[{const:'internal',title:'Internal team'},{const:'public',title:'Public release'}],default:'internal'},sections:{type:'array',title:'Sections to review',items:{type:'string',enum:['migration','compatibility']},minItems:1,default:['migration']}},required:['title','enabled','count','email','date','audience','sections']};
export async function addMcpElicitationAppFixture(workspace){
 const path=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(path,'utf8'));
 settings.permissions.ask=[...new Set([...(settings.permissions.ask??[]),'mcp__research__echo'])];
 await writeFile(path,JSON.stringify(settings));await writeFile(join(workspace,'mcp-elicitation-steps.json'),JSON.stringify(mcpElicitationSteps));
}
export async function verifyMcpElicitationApp(workspace,calls){
 const proof=JSON.parse(await readFile(join(workspace,'mcp-elicitation-app-proof.json'),'utf8'));
 assert.equal(proof.steps.length,7);assert.equal(proof.retainedDraft,true);assert.equal(proof.recoveredSameSession,true);
 const frames=(await readFile(join(workspace,'mcp-elicitation-receipts.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 for(const step of mcpElicitationSteps){
  const answer=frames.find(value=>value.id==='research-elicitation-'+step.phase&&value.result)?.result;
  assert.ok(answer,'Missing original server answer for '+step.scenario);
  assert.equal(answer.action,step.scenario==='form-interrupt'?'cancel':step.scenario.split('-')[1]);
  if(step.scenario==='form-accept')assert.deepEqual(answer.content,{title:'Migration notes',enabled:false,count:0,email:'reviewer@example.invalid',date:'2026-10-22',audience:'internal',sections:['migration']});
  else assert.equal(answer.content,undefined);
 }
 const interruptedCall=frames.find(value=>value.method==='tools/call'&&value.params.arguments.scenario==='form-interrupt');
 assert.ok(frames.some(value=>value.method==='notifications/cancelled'&&value.params.requestId===interruptedCall.id));
 assert.ok(calls.some(call=>JSON.stringify(call.messages??[]).includes('Continue after cancelling the release input.')));
 const children=(await readFile(join(workspace,'mcp-children.jsonl'),'utf8')).trim().split('\n').map(JSON.parse),exits=(await readFile(join(workspace,'mcp-exits.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 for(const child of children)assert.ok(exits.some(row=>row.pid===child.pid),'Owned MCP process did not exit');
 return {originalFormAndUrlActions:true,typedFalseAndZero:true,originalInterruptCancellation:true,ownedMcpShutdown:true,qualification:'Print-owner app interaction; native terminal form/waiting/URL hosts remain separate.'};
}
