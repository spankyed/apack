import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
export const mcpElicitationSteps = ['form-accept','form-decline','form-cancel','url-accept','url-decline','url-cancel','form-interrupt'].map((scenario,index)=>({scenario,phase:index+1,prompt:'Review release input '+(index+1)+'.'}));
export const mcpElicitationModelRequests = 2 + mcpElicitationSteps.reduce((total,step)=>total+(step.scenario==='form-interrupt'?1:2),0);
export const mcpReleaseForm = {type:'object',properties:{title:{type:'string',title:'Release title',minLength:3,default:'Migration notes'},enabled:{type:'boolean',title:'Include archived notes',default:false},count:{type:'integer',title:'Additional reviewers',minimum:0,maximum:5,default:0},email:{type:'string',title:'Reviewer email',format:'email'},date:{type:'string',title:'Review date',format:'date',default:'2026-10-22'},audience:{type:'string',title:'Audience',oneOf:[{const:'internal',title:'Internal team'},{const:'public',title:'Public release'}],default:'internal'},sections:{type:'array',title:'Sections to review',items:{type:'string',enum:['migration','compatibility']},minItems:1,default:['migration']}},required:['title','enabled','count','email','date','audience','sections']};
export async function addMcpElicitationAppFixture(workspace){
 const path=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(path,'utf8'));
 settings.permissions.ask=[...new Set([...(settings.permissions.ask??[]),'mcp__research__echo'])];
 await writeFile(path,JSON.stringify(settings));await writeFile(join(workspace,'mcp-elicitation-steps.json'),JSON.stringify(mcpElicitationSteps));
}
export async function verifyMcpElicitationApp(workspace,calls){
 assert.equal(calls.length,mcpElicitationModelRequests,'Initial/recovery prompts plus six completed tool turns and one interrupted turn');
 const proof=JSON.parse(await readFile(join(workspace,'mcp-elicitation-app-proof.json'),'utf8'));
 assert.equal(proof.steps.length,7);assert.equal(proof.retainedDraft,true);assert.equal(proof.recoveredSameSession,true);
 const frames=(await readFile(join(workspace,'mcp-elicitation-receipts.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 for(const step of mcpElicitationSteps){
  const answer=frames.find(value=>value.id==='research-elicitation-'+step.phase&&value.result)?.result;
  assert.ok(answer,'Missing original server answer for '+step.scenario);
  assert.equal(answer.action,step.scenario==='form-interrupt'?'cancel':step.scenario.split('-')[1]);
  if(step.scenario==='form-accept')assert.deepEqual(answer.content,{title:'Migration notes',enabled:false,count:0,email:'reviewer@example.invalid',date:'2026-10-22',audience:'internal',sections:['migration']});
  else assert.equal(answer.content,undefined);
 }
 const interruptedCall=frames.find(value=>value.method==='tools/call'&&value.params.arguments.scenario==='form-interrupt');
 assert.ok(frames.some(value=>value.method==='notifications/cancelled'&&value.params.requestId===interruptedCall.id));
 assert.ok(calls.some(call=>JSON.stringify(call.messages??[]).includes('Continue after cancelling the release input.')));
 const children=(await readFile(join(workspace,'mcp-children.jsonl'),'utf8')).trim().split('\n').map(JSON.parse),exits=(await readFile(join(workspace,'mcp-exits.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 for(const child of children)assert.ok(exits.some(row=>row.pid===child.pid),'Owned MCP process did not exit');
 const evidence=JSON.parse(await readFile(join(workspace,'native-terminal-app-evidence.json'),'utf8'));
 for(const key of ['actualAppGui','mcpElicitationApp','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true);
 assert.equal(evidence.sessionId,proof.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);assert.deepEqual(evidence.browserErrors,[]);
 assert.deepEqual(proof.steps.map(step=>step.scenario),mcpElicitationSteps.map(step=>step.scenario));assert.equal(proof.captures.length,6);
 const natives=(await readFile(join(workspace,'native-children.jsonl'),'utf8')).trim().split('\n').map(JSON.parse),nativeExits=(await readFile(join(workspace,'native-exits.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 assert.equal(natives.length,4,'Seed, terminal, print interactions and recovered print');
 for(const child of natives)assert.ok(nativeExits.some(exit=>exit.pid===child.pid),'Owned original native process did not exit');
 assert.ok(natives[0].args.includes('--print'));assert.ok(natives[1].args.includes('--resume'));assert.equal(natives[1].pid,evidence.boundNativePid);
 for(const child of natives.slice(2)){assert.ok(child.args.includes('--print'));assert.equal(child.args[child.args.indexOf('--resume')+1],evidence.sessionId);}
 for(let i=0;i<3;i++)assert.ok(nativeExits.find(exit=>exit.pid===natives[i].pid).at<=natives[i+1].at,'Original owner must retire before the next starts');
 const retirement=JSON.parse(await readFile(join(workspace,'mcp-elicitation-retirement.json'),'utf8'));
 assert.equal(retirement.nativePid,natives[2].pid);assert.ok(retirement.ancestors.includes(retirement.ownerPid)&&retirement.ancestors.includes(retirement.nativePid));
 assert.ok(children.some(child=>child.pid===retirement.serverPid&&child.ancestors.includes(retirement.ownerPid)&&child.ancestors.includes(retirement.nativePid)));
 assert.ok(proof.steps.every(step=>step.ownerPid===retirement.ownerPid),'All seven requests must retain the same original print owner');
 assert.equal(retirement.exitedAt,nativeExits.find(exit=>exit.pid===retirement.nativePid).at);assert.ok(retirement.exitedAt>=retirement.stoppedAt);
 const preload=(await readFile(join(workspace,'user-preload-calls.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 for(const child of natives)assert.ok(preload.some(row=>row.pid===child.pid),'Original user preload must be retained');
 const prints=(await readFile(join(workspace,'native-print-results.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);assert.equal(prints.at(-1).sessionId,evidence.finalSessionId);
 return {originalFormAndUrlActions:true,typedFalseAndZero:true,originalInterruptCancellation:true,ownedMcpShutdown:true,ownedNativeShutdown:true,nativeProcesses:natives.length,nativePreloadPreserved:true,syntheticApiRequests:calls.length,realModelRequests:0,retirement,qualification:'Print-owner app interaction; native terminal form/waiting/URL hosts remain separate.'};
}
