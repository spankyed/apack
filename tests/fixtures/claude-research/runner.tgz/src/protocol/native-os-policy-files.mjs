/** Private research I/O mapping only; native discovery, conversion, parsing and precedence are unchanged. */
export function nativeOsPolicyFiles({directory,receipt,unreadableUser=false}) {
 return `{
const {createRequire,syncBuiltinESMExports}=await import('node:module');
const require=createRequire(import.meta.url),fs=require('node:fs'),cp=require('node:child_process');
const {BVs}=await import('/$bunfs/root/chunk-bk0cajy4.js');
const sources=BVs(),mapping=new Map(sources.map(source=>[source.path,${JSON.stringify(directory)}+'/'+(source.label==='per-user managed preferences'?'user':'device')+'.plist']));
const record=value=>fs.appendFileSync(${JSON.stringify(receipt)},JSON.stringify({pid:process.pid,...value})+'\\n');
for(const name of ['accessSync','openSync']){const original=fs[name];fs[name]=function(path,...args){
 if(!mapping.has(path))return Reflect.apply(original,this,[path,...args]);
 record({operation:name,path,mapped:mapping.get(path)});
 if(${JSON.stringify(unreadableUser)}&&path===sources.find(source=>source.label==='per-user managed preferences')?.path){const error=Object.assign(new Error('Private policy fixture: permission denied'),{code:'EACCES'});throw error;}
 return Reflect.apply(original,this,[mapping.get(path),...args]);
};}
const exec=cp.execFile;cp.execFile=function(executable,args,...options){
 if(executable!=='/usr/bin/plutil')return Reflect.apply(exec,this,[executable,args,...options]);
 const mapped=args.map(value=>mapping.get(value)??value);record({operation:'execFile',executable,args,mapped});
 return Reflect.apply(exec,this,[executable,mapped,...options]);
};
syncBuiltinESMExports();

}
`;
}
