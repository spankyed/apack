import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {randomBytes,randomUUID,createHash} from 'node:crypto';
import {readFile,writeFile,mkdir,readdir,lstat,unlink} from 'node:fs/promises';
import {join} from 'node:path';

/** Private native IDE lock and loopback MCP peer; no real editor, installer or client replacement. */
export async function prepareNativeIdeFixture({checkout,setupWorkspace,workspace,fullscreen=false}) {
 assert.equal(process.platform,'linux');assert.match(workspace,/^\/work\/\.claude-research\/combined-everyday-app[0-9]+$/);assert.equal(setupWorkspace,'/work/.claude-research/profile-setup-app10');
 assert.ok((await lstat('/control/offline-verified')).isFile());
 const {WebSocketServer}=createRequire(join(checkout,'package.json'))('ws'),token=randomBytes(32).toString('hex'),receipts=[],sockets=new Set();
 let overflow=false;const log=entry=>{if(receipts.length>=256){overflow=true;return;}receipts.push({at:Date.now(),...entry});};
 const server=createServer((_req,res)=>{res.writeHead(404);res.end();}),ws=new WebSocketServer({noServer:true,handleProtocols:protocols=>protocols.has('mcp')?'mcp':false});
 server.on('upgrade',(req,socket,head)=>{const authorized=req.headers['x-claude-code-ide-authorization']===token,protocols=String(req.headers['sec-websocket-protocol']??'').split(',').map(s=>s.trim());log({kind:'upgrade',authorized,mcpProtocol:protocols.includes('mcp'),url:req.url});if(!authorized||!protocols.includes('mcp')||sockets.size>=2){socket.end('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');return;}ws.handleUpgrade(req,socket,head,client=>ws.emit('connection',client,req));});
 ws.on('connection',client=>{sockets.add(client);client.on('close',()=>{sockets.delete(client);log({kind:'closed'});});client.on('error',error=>log({kind:'socket-error',message:error.message.slice(0,200)}));client.on('message',raw=>{try{assert.ok(raw.length<=1024*1024);const request=JSON.parse(raw.toString());log({kind:'rpc',method:request.method,...(request.method==='ide_connected'?{pid:request.params?.pid}:request.method==='tools/call'?{toolName:request.params?.name}:{})});if(request.id===undefined)return;let result,error;
  if(request.method==='initialize')result={protocolVersion:request.params.protocolVersion,capabilities:{tools:{}},serverInfo:{name:'Owned release review IDE',version:'1.0.0'}};
  else if(request.method==='tools/list')result={tools:[]};
  else if(request.method==='ping')result={};
  else if(request.method==='resources/list')result={resources:[]};
  else if(request.method==='prompts/list')result={prompts:[]};
  else error={code:-32601,message:'Method not provided by owned IDE fixture'};
  client.send(JSON.stringify({jsonrpc:'2.0',id:request.id,...(error?{error}:{result})}));
 }catch(error){log({kind:'protocol-error',message:error.message.slice(0,200)});client.close(1008);}});});
 let lock,lockBytes,settingsPath,settingsBefore,preferencesPath,preferencesBefore;const files=new Map(),created=new Set();let lockCreated=false,settingsWritten=false;
 async function cleanup(){for(const client of sockets)client.terminate();await new Promise(resolve=>ws.close(resolve));if(server.listening)await new Promise(resolve=>server.close(resolve));if(lockCreated){assert.deepEqual(await readFile(lock),lockBytes);await unlink(lock);}for(const path of created){assert.equal(await readFile(path,'utf8'),files.get(path));await unlink(path);}if(preferencesBefore){await writeFile(preferencesPath,preferencesBefore);assert.deepEqual(await readFile(preferencesPath),preferencesBefore);}if(settingsWritten){await writeFile(settingsPath,settingsBefore);assert.deepEqual(await readFile(settingsPath),settingsBefore);}}
 try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 const port=server.address().port,config=join(setupWorkspace,'app-data/claude-code-profile/config'),directory=join(config,'ide');await mkdir(directory,{recursive:true});const info=await lstat(directory);assert.ok(info.isDirectory()&&!info.isSymbolicLink()&&info.uid===process.getuid());assert.deepEqual((await readdir(directory)).filter(n=>n.endsWith('.lock')),[],'Private IDE root must have no other lock');
 preferencesPath=join(config,'.claude.json');preferencesBefore=await readFile(preferencesPath);assert.ok((await lstat(preferencesPath)).isFile());await writeFile(join(workspace,'ide-preferences-before.json'),preferencesBefore,{mode:0o600,flag:'wx'});
 lock=join(directory,port+'.lock');const project=join(setupWorkspace,'project'),id=randomUUID(),allowed=join(project,'ide-release-'+id+'.txt'),denied=join(project,'ide-denied-'+id+'.txt'),marker='IDE_RELEASE_SELECTION_'+id.replaceAll('-',''),deniedMarker='IDE_DENIED_SELECTION_'+id.replaceAll('-','');
 files.set(allowed,marker+'\n');files.set(denied,deniedMarker+'\n');for(const[path,text]of files){await writeFile(path,text,{mode:0o600,flag:'wx'});created.add(path);}
 settingsPath=join(config,'settings.json');settingsBefore=await readFile(settingsPath);const settings=JSON.parse(settingsBefore);await writeFile(settingsPath,JSON.stringify({...settings,...(fullscreen?{tui:'fullscreen'}:{}),permissions:{...settings.permissions,deny:[...(settings.permissions?.deny??[]),'Read(/'+denied+')']}}));settingsWritten=true;await writeFile(join(workspace,'ide-settings-applied.json'),await readFile(settingsPath),{mode:0o600,flag:'wx'});
 lockBytes=Buffer.from(JSON.stringify({workspaceFolders:[project],pid:process.pid,ideName:'Owned release review IDE',transport:'ws',authToken:token}));await writeFile(lock,lockBytes,{mode:0o600,flag:'wx'});lockCreated=true;
 let restored=false;
 return {port,allowed,denied,fullscreenRequested:fullscreen,marker,markerReturn:marker+'_RETURN',deniedMarker,deniedRule:'Read(/'+denied+')',receipts,settingsBeforeSha256:createHash('sha256').update(settingsBefore).digest('hex'),
  async select(kind){assert.ok(['allowed','allowed-return','denied','opened','opened-denied'].includes(kind));if(kind==='allowed-return'){await writeFile(allowed,marker+'_RETURN\n');files.set(allowed,marker+'_RETURN\n');}const path=kind==='denied'||kind==='opened-denied'?denied:allowed,text=kind==='denied'?deniedMarker:kind.startsWith('opened')?'':kind==='allowed-return'?marker+'_RETURN':marker;const params={filePath:path,text,selection:{start:{line:0,character:0},end:{line:0,character:text.length}}};assert.ok(sockets.size);for(const client of sockets)client.send(JSON.stringify({jsonrpc:'2.0',method:'selection_changed',params}));log({kind:'selection-sent',selection:kind,filePath:path,text});},
  async preferences(){const raw=await readFile(preferencesPath),value=JSON.parse(raw);return {autoConnectIde:value.autoConnectIde??false,rawAutoConnectIdePresent:Object.hasOwn(value,'autoConnectIde'),defaultSource:'pinned native preferences default autoConnectIde:false',hasIdeAutoConnectDialogBeenShown:value.hasIdeAutoConnectDialogBeenShown,sha256:createHash('sha256').update(raw).digest('hex')};},
  get overflow(){return overflow;},
  async restore(){if(restored)return;await cleanup();await writeFile(join(workspace,'ide-preferences-restored.json'),await readFile(preferencesPath),{mode:0o600,flag:'wx'});await writeFile(join(workspace,'ide-fixture-restoration.json'),JSON.stringify({restored:true,preferencesRestored:preferencesBefore!==undefined,preferencesSha256:createHash('sha256').update(preferencesBefore).digest('hex'),settingsSha256:createHash('sha256').update(settingsBefore).digest('hex'),lockRemoved:true,filesRemoved:true,socketsClosed:sockets.size===0,receipts},null,2));restored=true;},
 };
 }catch(error){try{await cleanup();}catch(cleanupError){throw new AggregateError([error,cleanupError],'IDE fixture setup and restoration failed');}throw error;}
}
