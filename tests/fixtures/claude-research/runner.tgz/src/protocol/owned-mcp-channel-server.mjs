import {createInterface} from 'node:readline';
import {appendFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
/** Legacy channel producer; the original client decides whether to register ingress. */
export function createOwnedMcpChannelServer(){
 let requests=0,emitted=false;
 return request=>{
  if(request.id===undefined)return [];
  const reply=value=>({jsonrpc:'2.0',id:request.id,...value});
  if(++requests>64)return [reply({error:{code:-32602,message:'Owned request budget exhausted'}})];
  const {method,params={}}=request;
  if(method==='server/discover')return [reply({error:{code:-32601,message:'Owned legacy channel requires initialize'}})];
  if(method==='initialize')return [reply({result:{protocolVersion:params.protocolVersion,serverInfo:{name:'owned-channel',version:'0.0.1'},capabilities:{tools:{},experimental:{'claude/channel':{}}}}})];
  if(method==='ping')return [reply({result:{}})];
  if(method==='tools/list')return [reply({result:{tools:[{name:'echo',description:'Emit one owned channel notification and finish the requested tool',inputSchema:{type:'object',properties:{message:{type:'string'}},required:['message']}}]}})];
  if(method==='tools/call'&&params.name==='echo'){
   if(emitted)return [reply({error:{code:-32602,message:'Owned notification already emitted'}})];
   emitted=true;return [{jsonrpc:'2.0',method:'notifications/claude/channel',params:{content:'OWNED_CHANNEL_NOTIFICATION: review only; do not execute tools.',meta:{fixture:'owned-channel'}}},reply({result:{content:[{type:'text',text:'Owned echo finished.'}]}})];
  }
  return [reply({error:{code:-32601,message:'Unsupported owned method'}})];
 };
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const receipt=process.env.APACK_MCP_TASK_RECEIPT;if(!receipt)throw Error('Explicit owned receipt path required');
 const handle=createOwnedMcpChannelServer(),input=createInterface({input:process.stdin});let bytes=0;
 input.on('line',line=>{bytes+=Buffer.byteLength(line);if(bytes>1048576){input.close();process.stdin.destroy();process.exitCode=1;return;}let request;try{request=JSON.parse(line);}catch{return;}appendFileSync(receipt,JSON.stringify({direction:'in',value:request})+'\n');for(const reply of handle(request)){appendFileSync(receipt,JSON.stringify({direction:'out',value:reply})+'\n');process.stdout.write(JSON.stringify(reply)+'\n');}});
}
