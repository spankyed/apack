import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
/** Require original interruption and a distinct recovered answer, not merely a removed dialog. */
export async function verifyNativeQuestionOwnerFailure(workspace,calls){
 const proof=JSON.parse(await readFile(join(workspace,'native-question-owner-failure-proof.json'),'utf8'));
 assert.ok(proof.sessionId);assert.notEqual(proof.boundNativePid,proof.reopenedNativePid);
 assert.notEqual(proof.retired.nativeTerminal.ownerId,proof.fresh.nativeTerminal.ownerId);
 assert.notEqual(proof.retired.requestId,proof.fresh.requestId);
 assert.equal(proof.retiredHistory.blockResponse.cancelled,true);
 for(const key of ['retainedDraft','staleAnswerRefused','sameSessionRecovery'])assert.equal(proof[key],true,key);
 const results=proof.journal.flatMap(row=>row.type==='user'&&Array.isArray(row.message?.content)?row.message.content:[]).filter(block=>block.type==='tool_result');
 assert.ok(results.some(block=>block.tool_use_id==='native_question_fixture'&&block.is_error===true),'Original interrupted question result missing');
 assert.equal(results.filter(block=>block.tool_use_id==='native_question_recovery_fixture'&&block.is_error!==true).length,1,'Fresh original question must settle exactly once');
 assert.ok(calls.some(call=>(call.messages??[]).some(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='tool_result'&&block.tool_use_id==='native_question_fixture'&&block.is_error===true))),'Interrupted native context never reached the model');
 assert.ok(calls.some(call=>(call.messages??[]).some(message=>Array.isArray(message.content)&&message.content.some(block=>block.type==='tool_result'&&block.tool_use_id==='native_question_recovery_fixture'&&block.is_error!==true&&JSON.stringify(block.content??'').includes('Developers')))),'Fresh original answer missing from model context');
 assert.equal(proof.nativePrintResult.sessionId,proof.sessionId);assert.equal(proof.nativePrintResult.totalCostUsd,proof.continuedCost);assert.ok(proof.continuedCost>proof.recoveredCost);
 assert.equal(proof.captures.length,6);
 return {originalQuestionInterrupted:true,retiredAnswerRefused:true,freshOriginalQuestion:true,sameSessionRecovery:true};
}
