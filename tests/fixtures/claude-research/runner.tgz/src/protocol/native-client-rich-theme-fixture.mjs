/** Ordinary original Client: a small release workspace, not a theme-selector replacement. */
export const clientRichThemePalettes = {
 dark: {name:'Release workspace',base:'dark',overrides:{text:'#e2e8f0',inverseText:'#263241',success:'#86efac',warning:'#fbbf24',suggestion:'#93c5fd'}},
 light: {name:'Release workspace',base:'light',overrides:{text:'#0f172a',inverseText:'#f3f4f6',success:'#166534',warning:'#92400e',suggestion:'#1d4ed8'}},
};
export function nativeClientRichThemeHook(){return `export function register(on){let writes=Promise.resolve(),rows=[];on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const base=await next(e);if(e.surface!=='desktop'||e.view?.agentId)return base;const {Box,Client}=$.ui.resolve(e);return Box({flexDirection:'column',children:[base,Client({key:'release-workspace',module:'./release-workspace.ts',props:{color:'success'},width:'100%',height:12})]});});on('ui.message',async($,e,next)=>{if(e.data?.richTheme!==true)return next(e);if(rows.length>=256)throw Error('Release workspace receipt bound exceeded');rows.push({...e.data,surface:e.surface,component:e.component,element:e.element});const bytes=JSON.stringify(rows);writes=writes.then(()=>$.fs.write('native-client-rich-theme-receipts.json',bytes));await writes;return next(e);});}`;}
export function nativeClientRichThemeModule(){return `export default function(props,s){
 const {Box,Text,Button,Input,Select,Markdown,Code}=s.elements;
 if(s.state===undefined)s.setState({notes:'Ready for review',audience:'team',saves:0});
 const update=(operation,change)=>{const state={...s.state,...change};s.setState(state);s.post({richTheme:true,operation,...state,privateColor:props.color});};
 return Box({flexDirection:'column',padding:1,backgroundColor:'inverseText',children:[
  Text({color:'success',children:['Release workspace']}),
  Box({flexDirection:'row',gap:1,children:[
   Box({width:'65%',children:[Input({key:'release-notes',label:'Release notes',rows:1,value:s.state.notes,onInput:value=>update('notes',{notes:value}),onSubmit:value=>update('submit-notes',{notes:value})})]}),
   Box({width:'35%',children:[Select({key:'release-audience',label:'Audience',value:s.state.audience,options:[{value:'team',label:'Team'},{value:'public',label:'Public'}],onSelect:value=>update('audience',{audience:value})})]})
  ]}),
  Markdown({text:'**Before publishing:** review the notes and audience.'}),
  Code({source:'const audience = '+JSON.stringify(s.state.audience)+';',language:'javascript'}),
  Box({flexDirection:'row',gap:1,children:[Button({key:'save-review',label:'Save review',variant:'primary',onPress:()=>update('save',{saves:s.state.saves+1})}),Text({dimColor:true,children:['Saved reviews: '+s.state.saves]})]})
 ]});
}`;}
