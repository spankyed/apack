import assert from 'node:assert/strict'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { stripVTControlCharacters } from 'node:util'
import { configureNativeCreditAccount, CREDIT_ACCOUNT_ID, CREDIT_ORGANIZATION_ID, CREDIT_SYNTHETIC_TOKEN } from './native-credit-account.mjs'
import { prepareNativeCreditTls, startNativeCreditBilling } from './native-credit-billing.mjs'
import { EFFORT_EVAL_ROUTE } from './native-effort-rollout.mjs'
import { hash } from '../artifacts/runs.mjs'
import { record } from './record.mjs'

const cli = '/frozen-claude/claude'
const pin = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
const requestId = 'toolu_monitor_owned_review'
const searchId = 'toolu_monitor_owned_search'
export const prompt = 'Check for the disposable release review marker.'
export const recovery = 'Continue the review without starting the monitor.'
const description = 'Watch the disposable release review marker'
const bridge = fileURLToPath(new URL('./pty_bridge.py',import.meta.url))

export async function startNativeMonitorFixture(workspace,project,{approve=false,standing=false,cancelFeedback=false,lifecycle=false,freshSession=false}={}) {
  assert.ok(!standing||approve)
  assert.ok(!freshSession||standing)
  assert.ok(!cancelFeedback||!approve)
  assert.ok(!lifecycle||(approve&&!standing&&!cancelFeedback))
  const grantDirectory=join(workspace,'monitor-granted')
  const outsideDirectory=join(workspace,'monitor-outside')
  if (standing) await Promise.all([mkdir(grantDirectory),mkdir(outsideDirectory)])
  const marker=join(standing?grantDirectory:workspace,approve?'monitor-execution-marker':'must-not-create-monitor-marker')
  const outsideMarker=join(outsideDirectory,'monitor-outside-marker')
  const markerCommand=(text,redirect,path)=>"printf '%s\\n' '"+text+"' "+redirect+" '"+path+"'"
  const hold=(file,seconds)=>[
    markerCommand('started','>>',file),
    '/usr/bin/sleep '+seconds,
    markerCommand('finished','>>',file),
  ].join('; ')
  const command=lifecycle?hold(marker,48):markerCommand('owned monitor fixture',approve?'>>':'>',marker)
  const expiryMarker=join(workspace,'monitor-expiry-marker')
  const expiry={prompt:'Run the short-deadline release watch.',id:'toolu_monitor_owned_expiry',
    command:hold(expiryMarker,15),timeout:3000,description:'Watch briefly for the release marker'}
  const reuse={prompt:'Run another local monitor in the approved directory.',id:'toolu_monitor_owned_reuse',
    command:markerCommand('owned monitor reuse','>>',marker)}
  const fresh={prompt:'Run the same release watch in this new conversation.',id:'toolu_monitor_owned_fresh',
    command:reuse.command,continuation:'Summarize this new conversation without starting the watch.'}
  const outside={prompt:'Review a monitor from a different local directory.',id:'toolu_monitor_owned_outside',
    command:markerCommand('outside fixture','>>',outsideMarker)}
  const feedbackMarker=join(workspace,'must-not-create-feedback-marker')
  const feedback={prompt:'Review the alternate monitor and wait for my decision.',id:'toolu_monitor_owned_feedback',
    command:markerCommand('feedback fixture','>',feedbackMarker),reason:'Wait for the release lead before watching this source.'}
  const steps=[{prompt,id:requestId,command,timeout:lifecycle?45000:2000},...(lifecycle?[expiry]:[]),...(standing?[reuse,outside]:[]),...(cancelFeedback?[feedback]:[]),...(freshSession?[fresh]:[])]
  const continuation=approve?'Summarize the local review after the monitor ran.':recovery
  const account=await configureNativeCreditAccount(workspace,'oauth',{featureCache:'native-defaults'})
  const configPath=join(account.CLAUDE_CONFIG_DIR,'.claude.json')
  const config=JSON.parse(await readFile(configPath,'utf8'))
  config.hasCompletedOnboarding=true
  config.projects={[project]:{hasTrustDialogAccepted:true}}
  assert.equal(config.cachedGrowthBookFeatures,undefined)
  await writeFile(configPath,JSON.stringify(config))
  await writeFile(join(dirname(configPath),'settings.json'),JSON.stringify({
    theme:'dark',...(!standing?{permissions:{ask:steps.map(step=>'Bash('+step.command+')')}}:{}),
  }))
  const tls=await prepareNativeCreditTls(join(workspace,'account-tls'))
  const exchanges=[], calls=[]
  const billing=await startNativeCreditBilling(tls,{allowMutations:false,managedConnector:async (req,res)=>{
    const path=new URL(req.url,'https://api.anthropic.com').pathname
    if (req.method!=='POST'||![EFFORT_EVAL_ROUTE,'/v1/messages','/v1/messages/count_tokens'].includes(path)) return false
    assert.equal(req.headers.host,'api.anthropic.com')
    const chunks=[]
    let length=0
    for await (const chunk of req) {
      length+=chunk.length
      assert.ok(length<=512*1024)
      chunks.push(chunk)
    }
    const body=JSON.parse(Buffer.concat(chunks).toString('utf8'))
    const json=data=>{res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(data));return true}
    if (path===EFFORT_EVAL_ROUTE) {
      assert.ok(exchanges.length<20)
      const owned=body.attributes?.accountUUID===CREDIT_ACCOUNT_ID && body.attributes?.organizationUUID===CREDIT_ORGANIZATION_ID
      exchanges.push({kind:'evaluation',owned,enabled:owned})
      return json({features:owned?{tengu_amber_sentinel:{defaultValue:true}}:{}})
    }
    assert.equal(req.headers.authorization,'Bearer '+CREDIT_SYNTHETIC_TOKEN)
    if (path.endsWith('/count_tokens')) return json({input_tokens:10})
    assert.ok(calls.length<(standing||cancelFeedback||lifecycle?24:10))
    const blocks=(body.messages??[]).flatMap(row=>Array.isArray(row.content)?row.content:[])
    const input=JSON.stringify(body.messages)
    const step=steps.findLast(candidate=>input.includes(candidate.prompt))
    const results=blocks.filter(row=>row.type==='tool_result' && steps.some(candidate=>candidate.id===row.tool_use_id))
    const result=results.find(row=>row.tool_use_id===step?.id)
    const tools=body.tools?.map(tool=>tool.name)??[]
    const request=!!step && tools.includes('Monitor') && !result && !calls.some(call=>call.request&&call.monitorId===step.id)
    const discoveryId=step===fresh?'toolu_monitor_owned_search_fresh':searchId
    const discovery=blocks.find(row=>row.type==='tool_result' && row.tool_use_id===discoveryId)
    const search=!!step && !tools.includes('Monitor') && tools.includes('ToolSearch') && !discovery
      && !calls.some(call=>call.search && (call.monitorId===fresh.id)===(step===fresh))
    calls.push({model:body.model,tools,targeted:!!step,monitorId:step?.id,request,search,result,results,discovery,expiryNotice:lifecycle&&input.includes('Monitor expired after'),recovery:input.includes(continuation),freshRecovery:freshSession&&input.includes(fresh.continuation)})
    const content=request?{type:'tool_use',id:step.id,name:'Monitor',input:{command:step.command,description:step.description??description,timeout_ms:step.timeout??2000}}
      :search?{type:'tool_use',id:discoveryId,name:'ToolSearch',input:{query:'select:Monitor',max_results:1}}
      :{type:'text',text:'The local review continued.'}
    const usage={input_tokens:10,output_tokens:5}
    const message={id:'msg_owned_monitor_'+calls.length,type:'message',role:'assistant',model:body.model,
      content:[content],stop_reason:content.type==='tool_use'?'tool_use':'end_turn',stop_sequence:null,usage}
    if (body.stream!==true) return json(message)
    res.writeHead(200,{'content-type':'text/event-stream'})
    const event=(name,data)=>res.write('event: '+name+'\ndata: '+JSON.stringify({type:name,...data})+'\n\n')
    event('message_start',{message:{...message,content:[],stop_reason:null,usage:{...usage,output_tokens:0}}})
    if (content.type==='tool_use') {
      event('content_block_start',{index:0,content_block:{...content,input:{}}})
      event('content_block_delta',{index:0,delta:{type:'input_json_delta',partial_json:JSON.stringify(content.input)}})
    } else {
      event('content_block_start',{index:0,content_block:{type:'text',text:''}})
      event('content_block_delta',{index:0,delta:{type:'text_delta',text:content.text}})
    }
    event('content_block_stop',{index:0})
    event('message_delta',{delta:{stop_reason:message.stop_reason,stop_sequence:null},usage:{output_tokens:5}})
    event('message_stop',{})
    res.end()
    return true
  }})
  return {account,tls,billing,exchanges,calls,marker,command,continuation,grantDirectory,outsideMarker,reuse,outside,feedbackMarker,feedback,expiryMarker,expiry,fresh}
}

async function monitorJourney(workspace) {
  assert.equal(process.platform,'linux')
  assert.equal(process.getuid(),1000)
  assert.match(workspace,/^\/work\/\.claude-research\/apack-terminal-owner-app-monitor[0-9]+$/)
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'))
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly && boundary.requireMonitorRollout)
  assert.equal(hash(await readFile(cli)),pin)
  assert.match(await readFile('/etc/hosts','utf8'),/^127\.0\.0\.1\s+api\.anthropic\.com(?:\s|$)/m)
  const project=join(workspace,'project')
  await mkdir(project)
  const {account,tls,billing,exchanges,calls,marker}=await startNativeMonitorFixture(workspace,project)
  let ready=false, requestSeen=false, cancelled=false, interrupted=false, returned=false
  let run, terminal=''
  const timers=[]
  const later=(fn,delay)=>timers.push(setTimeout(fn,delay))
  try {
    run=await record({executable:'/usr/bin/python3',args:[bridge,cli,'--strict-mcp-config','--permission-mode','default'],
      cwd:project,output:join(workspace,'recording'),timeoutMs:55000,maxBytes:2*1024**2,
      env:{...account,PATH:'/usr/bin:/bin',TMPDIR:workspace,TERM:'xterm-256color',NODE_EXTRA_CA_CERTS:tls.ca,
        ANTHROPIC_BASE_URL:'https://api.anthropic.com',DISABLE_AUTOUPDATER:'1'},onStdout(bytes,controls){
        terminal+=bytes.toString('utf8')
        const screen=stripVTControlCharacters(terminal).replace(/\s/g,'')
        if (!ready && (screen.includes('forshortcuts')||screen.includes('shift+tabtocycle'))) {
          ready=true
          later(()=>controls.send(prompt+'\r'),1700)
        }
        if (ready && !cancelled && screen.includes(description.replace(/\s/g,'')) && screen.includes('must-not-create-monitor-marker')) {
          requestSeen=true
          cancelled=true
          later(()=>controls.send('\x1b'),650)
        }
        if (cancelled && !interrupted && screen.includes('Interrupted·WhatshouldClaudedoinstead?')) {
          interrupted=true
          later(()=>controls.send(recovery+'\r'),650)
        }
        if (interrupted && !returned && screen.includes('Thelocalreviewcontinued.')) {
          returned=true
          later(()=>controls.send('\x04'),400)
          later(()=>controls.send('\x04'),760)
        }
      }})
  } finally {
    for (const timer of timers) clearTimeout(timer)
    await billing.close()
    const markerExists=await readFile(marker).then(()=>true,error=>{if(error.code==='ENOENT')return false;throw error})
    const proof={run,pin,ready,requestSeen,cancelled,interrupted,returned,markerExists,exchanges,calls}
    await writeFile(join(workspace,'monitor-rollout.json'),JSON.stringify(proof,null,2)+'\n')
    console.log(JSON.stringify({status:run?.status,ready,requestSeen,cancelled,interrupted,returned,markerExists,exchanges,tools:calls.map(c=>c.tools)}))
    assert.equal(run?.status,'complete')
    assert.equal(markerExists,false)
    assert.ok(exchanges.some(exchange=>exchange.enabled))
    assert.ok(calls.some(call=>call.request&&call.tools.includes('Monitor')))
    assert.ok(requestSeen && cancelled && interrupted && returned)
    assert.ok(calls.some(call=>call.recovery))
  }
}

if (process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)) await monitorJourney(process.argv[2])
