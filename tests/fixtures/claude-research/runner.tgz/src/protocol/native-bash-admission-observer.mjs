import { join } from 'node:path';

/** Observe original Bash admission and owned control replies without delaying or answering them. */
export function nativeBashAdmissionObserver(workspace) {
  return `{
 const http=(await import('node:http')).default,fs=await import('node:fs'),crypto=await import('node:crypto');
 const roots=await import('/$bunfs/root/chunk-pg10s5g1.js'),runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js');
 let count=0,previous='',lastProjection='';
 const record=row=>{if(count>=256)return;const text=JSON.stringify({at:Date.now(),pid:process.pid,...row});if(Buffer.byteLength(text)>65536)return;count++;fs.appendFileSync(${JSON.stringify(join(workspace,'native-bash-admission.jsonl'))},text+'\\n',{mode:0o600});};
 const inspect=()=>{
  const binding=runtime.ey();if(binding?.surface!=='terminal')return;
  const context=binding.toolContext(new AbortController()),dialog=context.dialogStore.getState().open.find(item=>item.kind==='permission_bash');
  if(!dialog)return {dialog:null};
  const pending=[roots.ai().get(process.stdout)?.container?.current],seen=new Set(),matches=[];
  while(pending.length){
   const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('Bash admission observation traversal exceeded bound');seen.add(fiber);
   if(typeof fiber.type==='function'&&fiber.type.name==='Tst'&&fiber.memoizedProps?.payload===dialog.payload){
    const hash=crypto.createHash('sha256').update(Function.prototype.toString.call(fiber.type)).digest('hex');
    if(hash!=='a1c816cf807cd385354df0a915bea27b7ade8b971aca77ac266d0af49522686a')throw Error('Bash admission renderer changed');
    const fitted=fiber.updateQueue?.memoCache?.data?.map(cache=>cache?.[23]).filter(value=>value&&typeof value.noteFocus==='function'&&value.body&&typeof value.body.isStandingHeld==='boolean');
    const children=[fiber.child],visited=new Set(),controls=[];
    while(children.length){
     const child=children.pop();if(!child||visited.has(child))continue;if(visited.size>=2048)throw Error('Bash admission controls exceeded bound');visited.add(child);
     const props=child.memoizedProps;
     if(typeof child.type==='function'&&child.type.name==='Xe'&&Array.isArray(props?.options)&&typeof props.onChange==='function')controls.push(props.options.map(option=>({value:option.value,label:typeof option.label==='string'?option.label:'[native element]',disabled:option.disabled===true,initialValue:option.initialValue})));
     if(child.sibling)children.push(child.sibling);if(child.child)children.push(child.child);
    }
    matches.push({hash,wouldTakeAnswer:typeof fiber.memoizedProps.wouldTakeAnswer==='function'?fiber.memoizedProps.wouldTakeAnswer():null,fitted:fitted?.map(value=>({offersStanding:value.body.offersStanding,isStandingHeld:value.body.isStandingHeld})),controls});
   }
   if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);
  }
  return {sessionId:context.session.id,dialog:{id:dialog.id,requestId:dialog.payload.requestId},matches};
 };
 const snapshot=()=>{try{return inspect()}catch(error){return {observationError:String(error)}}};
 const timer=setInterval(()=>{const value=snapshot(),text=JSON.stringify(value);if(value&&text!==previous){previous=text;record({phase:'state',native:value});}},25);timer.unref();
 const original=http.createServer;
 http.createServer=function(...args){
  const index=args.findIndex(value=>typeof value==='function');if(index<0)return Reflect.apply(original,this,args);
  const handler=args[index];args[index]=function(request,response){
   if(request.url==='/control'){
    let bytes=0,body;const chunks=[];
    request.on('data',chunk=>{bytes+=chunk.length;if(bytes<=1048576)chunks.push(chunk);});
    request.on('end',()=>{try{body=bytes<=1048576?JSON.parse(Buffer.concat(chunks)):undefined;if(body?.ownerPid!==process.pid||!['apack_bash_dialogs','apack_answer_bash_dialog'].includes(body.request?.subtype)){body=undefined;return}if(body.request.subtype==='apack_answer_bash_dialog')record({phase:'request',id:body.id,request:body.request,native:snapshot()});}catch{body=undefined}});
    const end=response.end;
    response.end=function(...values){
     if(body)try{const reply=JSON.parse(String(values[0]));if(body.request.subtype==='apack_answer_bash_dialog'||reply.error)record({phase:'response',id:body.id,status:response.statusCode,reply,native:snapshot()});else{const dialogs=reply.result?.dialogs??[],text=JSON.stringify(dialogs);if(dialogs.length&&text!==lastProjection){lastProjection=text;record({phase:'projection',id:body.id,dialogs,native:snapshot()});}}}catch{}
     return Reflect.apply(end,this,values);
    };
   }
   return Reflect.apply(handler,this,[request,response]);
  };
  return Reflect.apply(original,this,args);
 };
}`;
}
