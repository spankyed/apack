import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

/** Owned desktop fields on the original user-message producer; no vendor gates are changed. */
export async function addNativeFieldLifetimeFixture(plugin){
 await mkdir(join(plugin,'hooks'),{recursive:true});
 await writeFile(join(plugin,'hooks/register.ts'),String.raw`export function register(on){
 const values=new Map();
 on('ui.render',{component:'UserMessage'},async($,e,next)=>{
  if(e.surface!=='desktop')return next(e);
  const{Box,Text,Input,Select,Button}=$.ui.resolve(e);
  const id=e.requestId;
  if(!values.has(id))values.set(id,{input:'',select:'summary',revision:0});
  const state=values.get(id);
  await $.fs.write('native-form-render.json',JSON.stringify({id,surface:e.surface,component:e.component??'UserMessage',...state}));
  async function update(kind,value){
   const arms=JSON.parse(await $.fs.read('native-form-arm-'+kind+'.json').catch(()=>'{}'));
   const nonce=arms[value];
   if(nonce){
    const record={id,kind,value,nonce,revision:state.revision};
    await $.fs.write('native-form-'+nonce+'-started.json',JSON.stringify(record));
    for(let attempt=0;attempt<200;attempt++){
     if((await $.fs.read('native-form-'+nonce+'-release.txt').catch(()=>''))===nonce){
      await $.fs.write('native-form-'+nonce+'-rejected.json',JSON.stringify(record));
      throw Error('Owned retired '+kind+' callback '+nonce);
     }
     await $.clock.sleep(50);
    }
    throw Error('Owned field hold expired '+nonce);
   }
   const current=values.get(id);
   current[kind]=value;current.revision++;
   await $.fs.write('native-form-'+kind+'-value.json',JSON.stringify({id,kind,value,revision:current.revision}));
   $.ui.invalidate('ui.render');
  }
  return Box({flexDirection:'column',gap:'sm',children:[
   Text({children:['Review preferences']}),
   Box({flexDirection:'row',gap:'sm',children:[
    Box({flexGrow:1,minWidth:18,children:[Input({key:'review-note',label:'Review note',value:state.input,onInput:value=>update('input',value),onSubmit:async()=>{}})]}),
    Box({width:18,children:[Select({key:'review-scope',label:'Review scope',value:state.select,options:[{value:'summary',label:'Summary'},{value:'files',label:'Changed files'},{value:'project',label:'Whole project'}],onSelect:value=>update('select',value)})]})
   ]}),
   Button({key:'reset-review',label:'Reset review preferences',onPress:async()=>{values.set(id,{input:'',select:'summary',revision:values.get(id).revision+1});await $.fs.write('native-form-reset.json',JSON.stringify({id,...values.get(id)}));$.ui.invalidate('ui.render');}}),
   await next(e)
  ]});
 });
}`);
}

/** Reconcile app receipts with the original session journal, not just the app's success flag. */
export async function verifyNativeFieldLifetime(workspace,evidence){
 assert.equal(evidence.nativeFieldLifetime,true);
 const proof=JSON.parse(await readFile(join(workspace,'native-field-lifetime-proof.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.deepEqual(proof.cases.map(row=>[row.kind,row.replacement]),[['input','edit'],['input','reset'],['select','edit'],['select','reset']]);
 const identities=new Set();
 for(const row of proof.cases){
  const nonce=row.kind+'-'+row.replacement;
  const read=async suffix=>JSON.parse(await readFile(join(workspace,'native-form-'+nonce+'-'+suffix+'.json'),'utf8'));
  assert.deepEqual(await read('started'),row.started);assert.deepEqual(await read('rejected'),row.rejected);
  assert.equal(row.started.kind,row.kind);assert.equal(row.started.nonce,nonce);
  assert.equal(row.rejected.id,row.started.id);assert.equal(row.freshInput.id,row.started.id);assert.equal(row.freshSelect.id,row.started.id);
  assert.equal(row.freshInput.value,'Confirmed '+nonce);assert.equal(row.freshSelect.value,'project');
  identities.add(row.started.id);
 }
 assert.equal(identities.size,1);
 assert.deepEqual(proof.captures.map(row=>[row.width,row.part]),[[1100,'fields'],[1100,'reset'],[680,'fields'],[680,'reset']]);
 const root=join(workspace,'.claude/projects');
 const paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');
 assert.equal(paths.length,1);
 const rows=new Map();for(const line of (await readFile(join(root,paths[0]),'utf8')).trim().split('\n')){const row=JSON.parse(line);if(row.uuid)rows.set(row.uuid,row);}
 const text=content=>typeof content==='string'?content:(content??[]).filter(block=>block.type==='text').map(block=>block.text).join('\n');
 const humans=[...rows.values()].filter(row=>row.type==='user'&&row.isMeta!==true);
 assert.deepEqual(humans.map(row=>text(row.message?.content)),[proof.seed,proof.continuation]);
 assert.equal(humans[0].uuid,[...identities][0]);
 for(const message of proof.addedMessages){
  const uuid=message.context?.cliUuid;const original=rows.get(uuid);
  assert.equal(original?.type,'system','Any appended callback diagnostic must be an original system record');
  assert.equal(typeof original.content,'string');assert.ok(message.text.includes(original.content),'Original diagnostic text must be retained');
 }
 return {sessionId:proof.sessionId,userMessageUuid:humans[0].uuid,cases:proof.cases.map(({kind,replacement})=>({kind,replacement})),humanUuids:humans.map(row=>row.uuid),captures:proof.captures,scope:'Desktop UserMessage Input/Select late-failure ownership after edits and reset, retained composing and same-session continuation; not everyday interface or combined parity acceptance.'};
}
