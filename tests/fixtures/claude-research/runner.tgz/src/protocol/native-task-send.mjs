import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile,copyFile} from 'node:fs/promises';
import {existsSync,writeFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from './record.mjs';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticAgentModel} from './synthetic-agent-model.mjs';
const targetSha256='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37';
export async function probeNativeTaskSend(executable,parent,output,checkout,delivery='coordinator'){
 if(delivery==='adapter-resume')throw Error('Adapter resume requires the terminal live queue; use research CLI apack-terminal-agent-view instead of the print probe');
 assert.ok(['coordinator','human','human-resume','adapter-human'].includes(delivery));
 assert.equal(hash(await readFile(executable)),targetSha256);await mkdir(parent,{recursive:true});
 const workspace=await mkdtemp(join(parent,'native-task-send-')),reportPath=join(workspace,'native-task-send.json'),preload=join(workspace,'send.mjs');
 const adapter=await readFile(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-task-runtime.ts'),'utf8');
 const helper=adapter.slice(adapter.indexOf('String.raw`')+11,adapter.lastIndexOf('`'));
 const source=`${helper}\nimport {randomUUID} from 'node:crypto';import {writeFileSync} from 'node:fs';
let active=false;const timer=setInterval(async()=>{if(active)return;try{
 const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js');const binding=runtime.ey();if(!binding)return;
 const context=binding.toolContext(new AbortController());const task=Object.values(context.taskRegistry.all()).find(task=>task.type==='local_agent'&&task.status===${JSON.stringify(delivery.endsWith('resume')?'completed':'running')});if(active||!task)return;
 active=true;clearInterval(timer);const report={taskId:runtime.flt(task).id};try{
 const n={runtime,taskControls:await import('/$bunfs/root/chunk-nmzacz4p.js'),taskResume:await import('/$bunfs/root/chunk-jg0h78vk.js'),taskInputGate:await import('/$bunfs/root/chunk-ysbnj2tj.js')};const abort=new AbortController();report.nativeLiveQueueAvailable=typeof context.messageQueue?.getCommandQueueSnapshot==='function'&&typeof context.getMessages==='function';
 if(['human','human-resume'].includes(${JSON.stringify(delivery)})){
  const beforeStatus=context.taskRegistry.get(task.id)?.status;
  if(beforeStatus!==${JSON.stringify(delivery.endsWith('resume')?'completed':'running')})throw Error('Selected Agent changed before human input');
  report.beforeStatus=beforeStatus;
  const text='NativeAgentSteerFixture: acknowledge this human instruction in the same Agent.';
  runtime.Dhs(task.id,context.taskRegistry);
  const message=runtime.Ae({content:text,origin:{kind:'human'}});
  runtime.WXt(task.id,message,context.taskRegistry);
  if(${JSON.stringify(delivery)}==='human-resume'){
   const resume=await import('/$bunfs/root/chunk-jg0h78vk.js');
   const result=await resume.MQ({agentId:task.id,prompt:text,promptIsMeta:true,promptOrigin:{kind:'human'},toolUseContext:context,canUseTool:binding.canUseTool,userInitiated:true});
   if(resume.Y$(result))throw Error('Native resume denied: '+result.deniedByPlugin);
   report.resumeResult=result;
  }else runtime.jXt(task.id,text,context.taskRegistry,{isMeta:true,origin:{kind:'human'},shownAs:message.uuid});
  report.receipt={queued:true};report.nativeHumanTranscriptUUID=message.uuid;
 }else{
  report.receipt=await nativeTaskControl(n,binding,{task_id:report.taskId,operation:${JSON.stringify(delivery.startsWith('adapter-')?'input':'send')},text:'NativeAgentSteerFixture: acknowledge this instruction in the same Agent.'},abort,()=>abort.signal.throwIfAborted());
 }
 report.inspection=await nativeTaskControl(n,binding,{task_id:report.taskId,operation:'inspect'},abort,()=>abort.signal.throwIfAborted());
 report.parentHumanReceivedMessage=binding.messages().some(row=>row.type==='user'&&row.isMeta!==true&&row.isVirtual!==true&&JSON.stringify(row.message.content).includes('NativeAgentSteerFixture'));
 }catch(error){report.error=String(error);}writeFileSync(${JSON.stringify(reportPath)},JSON.stringify(report,null,2));
 }catch(error){if(active)writeFileSync(${JSON.stringify(reportPath)},JSON.stringify({error:String(error)}));}},25);timer.unref();`;
 await writeFile(preload,source);
 const model=await startSyntheticAgentModel({steeringProbe:true,childDelayMs:7500});let run,observer,buffer='';
 try{
 const agents={'status-fixture':{description:'Disposable native message recipient',prompt:'NativeStatusChildSystem. Respond to the private task instruction.',tools:[],maxTurns:4}};
 run=await record({executable,cwd:workspace,output,timeoutMs:30000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--tools','Agent,SendMessage','--allowedTools','Agent,SendMessage','--agents',JSON.stringify(agents),'--permission-mode','acceptEdits','--setting-sources','','--strict-mcp-config','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})],env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),PATH:'/usr/bin:/bin',BUN_OPTIONS:'--preload='+preload,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[JSON.stringify({type:'control_request',request_id:'task-send-init',request:{subtype:'initialize',hooks:{}}})+'\n'],onStdout(bytes,transport){
  buffer+=bytes;while(buffer.includes('\n')){const at=buffer.indexOf('\n'),line=buffer.slice(0,at);buffer=buffer.slice(at+1);let row;try{row=JSON.parse(line)}catch{continue}
  if(row.type==='control_response'&&row.response.request_id==='task-send-init'&&!observer){
   transport.send(JSON.stringify({type:'user',message:{role:'user',content:'Run the disposable status-fixture Agent.'},parent_tool_use_id:null})+'\n');
   observer=(async()=>{const deadline=Date.now()+22000;while(Date.now()<deadline){if(existsSync(reportPath)){const report=JSON.parse(await readFile(reportPath,'utf8'));if(report.error||model.calls.some(call=>call.steeringObserved&&call.delivered)){transport.closeInput();return}}await new Promise(resolve=>setTimeout(resolve,25));}transport.stop('task-send-observation-timeout');})();
  }}
 }});if(observer)await observer;
 }finally{await model.close();}
 const report=existsSync(reportPath)?JSON.parse(await readFile(reportPath,'utf8')):{error:'No native task observation was produced'};
 await copyFile(preload,join(run.directory,'authored-task-send-preload.mjs'));await writeFile(join(run.directory,'native-task-send.json'),JSON.stringify(report,null,2));await writeFile(join(run.directory,'model-calls.json'),JSON.stringify(model.calls,null,2));await writeFile(join(run.directory,'model-requests.json'),JSON.stringify(model.requests,null,2));
 const evidence={delivery,targetSha256,authoredAdapterSha256:hash(Buffer.from(adapter)),authoredPreloadSha256:hash(Buffer.from(source)),nativeReceipt:report.receipt,agentObservedMessage:model.calls.some(call=>call.steeringObserved&&call.delivered),parentHumanReceivedMessage:report.parentHumanReceivedMessage,syntheticApiRequests:model.calls.length,realModelRequests:0,complete:false,qualification:delivery.startsWith('adapter-')?'Authored adapter using original native human input/resume and transcript exports; no foreground app or live-queue forwarding acceptance.':delivery==='human-resume'?'Original user-initiated MQ resume with native context/permission authority; no foreground app or live-queue forwarding acceptance.':delivery==='human'?'Original running-Agent human transcript/queue exports used by submitToAgent; no terminal selection, ended-Agent resume or actual app acceptance.':'Original native tool runner/SendMessage behavior; no actual app acceptance.'};
 try{assert.equal(run.status,'complete');assert.equal(report.error,undefined);assert.equal(delivery.startsWith('adapter-')?!!report.receipt.input:delivery!=='coordinator'?report.receipt.queued:report.receipt.sent,true);assert.equal(evidence.agentObservedMessage,true);assert.equal(report.parentHumanReceivedMessage,false);evidence.complete=true;}catch(error){evidence.failure=String(error);const p=join(run.directory,'manifest.json'),m=JSON.parse(await readFile(p,'utf8'));await writeFile(p,JSON.stringify({...m,status:'failed',verificationFailure:'native-task-send'},null,2));throw error;}finally{await writeFile(join(run.directory,'integration.json'),JSON.stringify(evidence,null,2));}
 return {...run,evidence};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))console.log(JSON.stringify(await probeNativeTaskSend(...process.argv.slice(2,6).map(value=>resolve(value)),process.argv[6]),null,2));
