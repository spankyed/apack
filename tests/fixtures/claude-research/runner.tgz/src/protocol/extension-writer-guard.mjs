import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';
/** Exercise the common early child-session guard; never request a valid settings mutation. */
export async function probeExtensionWriterGuard(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'extension-guard-')),config=join(workspace,'.claude');await mkdir(config,{recursive:true});
 const settings=join(config,'settings.json');await writeFile(settings,JSON.stringify({language:'research-preserve'}));const before=await readFile(settings);
 const run=await createRun(output,'extension-writer-guard',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),childSessionMarker:true});const cases=[];
 try{
  for(const command of ['edit-permission-rules','edit-memory-settings','edit-skill-overrides','edit-sandbox-settings','edit-chrome-settings','drop-worktree-registrations']){
   const transport=await record({executable,cwd:workspace,output,timeoutMs:10000,args:[command,'--json'],input:['{}\n'],env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:config,CLAUDE_CODE_CHILD_SESSION:'1',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}});
   const stderr=(await readFile(join(transport.directory,'stderr.bin'),'utf8')).trim();assert.notEqual(transport.code,0);assert.match(stderr,/inside a Claude Code session/);assert.deepEqual(await readFile(settings),before);
   cases.push({command,code:transport.code,childSessionRefused:true,settingsUnchanged:true,stderr,transportRun:transport.directory});
  }
  await writeFile(join(run.directory,'extension-writer-guard.json'),JSON.stringify({cases,modelPrompts:0,qualification:'Early guard only, using invalid empty mutation payloads; schema acceptance, actual changes, other access paths and descendant sessions not proven.'},null,2)+'\n');await run.finish({status:'complete',cases:cases.length});return{directory:run.directory,status:'complete',cases:cases.length,modelPrompts:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
