import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {mkdirSync,writeFileSync,unlinkSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Private file discovery only: no prompts, accounts, plugins or model calls. */
export async function probeSkillDiscovery(executable,root,output,{reload=false,states=false,editRefresh=false}={}){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'skill-discovery-'));
 const cwd=join(workspace,'project'),home=join(workspace,'home');
 await mkdir(cwd,{recursive:true});await mkdir(join(home,'.claude'),{recursive:true});
 execFileSync('/usr/bin/git',['init','-q',cwd]);
 const definitions=[
  {scope:'user',name:'research-user-skill',kind:'skill',front:'description: User discovery fixture\nargument-hint: "<user-value>"\n'},
  {scope:'project',name:'research-project-skill',kind:'skill',front:'description: Project discovery fixture\nargument-hint: "<project-value>"\n'},
  {scope:'project',name:'research-manual-skill',kind:'skill',front:'description: Manual discovery fixture\ndisable-model-invocation: true\n'},
  {scope:'project',name:'research-hidden-skill',kind:'skill',front:'description: Hidden discovery fixture\nuser-invocable: false\n'},
  {scope:'project',name:'research-legacy-command',kind:'command',front:'description: Legacy discovery fixture\nargument-hint: "<legacy-value>"\n'},
 ];
 if(states){
  await mkdir(join(cwd,'.claude'),{recursive:true});
  for(const state of ['on','name-only','user-invocable-only','off'])definitions.push({scope:'project',name:`research-state-${state}`,kind:'skill',front:`description: State ${state} fixture\n`});
  await writeFile(join(cwd,'.claude','settings.local.json'),JSON.stringify({skillOverrides:{...Object.fromEntries(['on','name-only','user-invocable-only','off'].map(state=>[`research-state-${state}`,state])),'research-manual-skill':'on'}}));
 }
 for(const item of definitions){
  const base=join(item.scope==='user'?home:cwd,'.claude');
  const path=item.kind==='skill'?join(base,'skills',item.name,'SKILL.md'):join(base,'commands',`${item.name}.md`);
  await mkdir(item.kind==='skill'?join(base,'skills',item.name):join(base,'commands'),{recursive:true});
  await writeFile(path,`---\nname: ${item.name}\n${item.front}---\nReturn the synthetic fixture token only when explicitly invoked.\n`);
 }
 const run=await createRun(output,editRefresh?'skill-edit-refresh':states?'skill-states':reload?'skill-reload':'skill-discovery',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),definitions});
 try{
  let pending='';const replies=[];
  const requests=[{subtype:'initialize',hooks:{}},{subtype:'get_skills_dialog'},{subtype:'get_context_usage',detail:'full'}];
  if(reload)requests.push({subtype:'reload_skills'},{subtype:'get_skills_dialog'},{subtype:'reload_skills'},{subtype:'get_skills_dialog'});
  if(states)requests.push({subtype:'update_settings',source:'localSettings',settings:{skillOverrides:{'research-state-on':'off'}}},{subtype:'get_settings'});
  if(editRefresh)requests.push({subtype:'reload_skills'},{subtype:'get_skills_dialog'},{subtype:'reload_skills'},{subtype:'get_skills_dialog'});
  const edits=[];
  const privateEnv={PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
  const livePath=join(cwd,'.claude','skills','research-live-added','SKILL.md');
  const line=i=>JSON.stringify({type:'control_request',request_id:`discovery-${i}`,request:requests[i]})+'\n';
  const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user,project,local','--strict-mcp-config','--no-session-persistence'],env:privateEnv,input:[line(0)],onStdout(bytes,channel){
   pending+=bytes.toString('utf8');while(pending.includes('\n')){
    const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type!=='control_response'||value.response?.request_id!==`discovery-${replies.length}`)continue;
    replies.push({request:requests[replies.length],response:value.response});
    if(editRefresh&&[3,5].includes(replies.length)){
     const edit={name:'research-project-skill',state:replies.length===3?'off':'on'};
     const bytes=execFileSync(executable,['edit-skill-overrides','--json'],{cwd,env:privateEnv,input:JSON.stringify(edit)+'\n',timeout:5000,maxBuffer:65536});
     const response=JSON.parse(bytes.toString('utf8'));assert.equal(response.ok,true);edits.push({edit,response});
    }
    if(reload&&replies.length===3){mkdirSync(join(cwd,'.claude','skills','research-live-added'),{recursive:true});writeFileSync(livePath,'---\nname: research-live-added\ndescription: Live discovery fixture\n---\nSynthetic live body.\n')}
    if(reload&&replies.length===5)unlinkSync(livePath);
    if(replies.length<requests.length)channel.send(line(replies.length));else channel.closeInput();
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(replies.length,requests.length);
  for(const reply of replies)assert.equal(reply.response.subtype,reply.request.subtype==='update_settings'?'error':'success');
  const commands=replies[0].response.response.commands;
  const skills=replies[1].response.response.skills;
  const context=replies[2].response.response.skills.skillFrontmatter;
  const names=items=>items.map(item=>item.name);
  for(const name of ['research-user-skill','research-project-skill','research-manual-skill','research-legacy-command'])assert.ok(names(commands).includes(name));
  assert.ok(!names(commands).includes('research-hidden-skill'));
  assert.equal(skills.find(item=>item.name==='research-hidden-skill')?.advertised,false);
  assert.equal(skills.find(item=>item.name==='research-manual-skill')?.state,'user-invocable-only');
  assert.equal(skills.find(item=>item.name==='research-manual-skill')?.locked_by,'author');
  assert.ok(names(context).includes('research-hidden-skill'));assert.ok(!names(context).includes('research-manual-skill'));
  if(states){
   for(const state of ['on','name-only','user-invocable-only','off'])assert.equal(skills.find(item=>item.name===`research-state-${state}`)?.state,state);
   assert.ok(!names(commands).includes('research-state-off'));
   assert.ok(names(commands).includes('research-state-user-invocable-only'));
   assert.ok(!names(context).includes('research-state-off'));
   assert.ok(!names(context).includes('research-state-user-invocable-only'));
   assert.ok(names(context).includes('research-state-name-only'));
   assert.match(replies[3].response.error,/keys not allowed: skillOverrides/);
   assert.equal(replies[4].response.response.effective.skillOverrides['research-state-on'],'on');
   const saved=JSON.parse(await readFile(join(cwd,'.claude','settings.local.json'),'utf8'));
   assert.equal(saved.skillOverrides['research-state-on'],'on');
  }
  if(reload){
   assert.ok(replies[4].response.response.skills.some(item=>item.name==='research-live-added'));
   assert.ok(!replies[6].response.response.skills.some(item=>item.name==='research-live-added'));
  }
  if(editRefresh){
   assert.equal(replies[4].response.response.skills.find(item=>item.name==='research-project-skill')?.state,'off');
   assert.equal(replies[4].response.response.skills.find(item=>item.name==='research-project-skill')?.advertised,false);
   assert.equal(replies[6].response.response.skills.find(item=>item.name==='research-project-skill')?.state,'on');
   assert.equal(replies[6].response.response.skills.find(item=>item.name==='research-project-skill')?.advertised,true);
   assert.equal(edits.length,2);
  }
  const normalize=value=>JSON.parse(JSON.stringify(value).split(workspace).join('${WORKSPACE}'));
  const result={reload,states,editRefresh,edits,definitions,replies:normalize(replies),transportRun:transport.directory,modelPrompts:0,qualification:'Discovery and metadata only; invocation, precedence, reload and terminal menu behavior require separate evidence.'};
  await writeFile(join(run.directory,'skill-discovery.json'),JSON.stringify(result,null,2)+'\n');
  await run.finish({status:'complete',transportRun:transport.directory});
  return{directory:run.directory,status:'complete',responses:replies.length,modelPrompts:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
