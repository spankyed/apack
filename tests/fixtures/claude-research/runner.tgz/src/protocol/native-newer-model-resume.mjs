import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { fileURLToPath } from 'node:url';
import { stripVTControlCharacters } from 'node:util';
import { hash } from '../artifacts/runs.mjs';
import { EFFORT_EVAL_ROUTE } from './native-effort-rollout.mjs';
import { CREDIT_SYNTHETIC_TOKEN, configureNativeCreditAccount } from './native-credit-account.mjs';
import { prepareNativeCreditTls, startNativeCreditBilling } from './native-credit-billing.mjs';
import { record } from './record.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

const executable = '/frozen-claude/claude';
const pin = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10';
const older = 'claude-opus-5';
const newer = 'claude-opus-5-5';
const seedPrompt = 'Review the release note in this disposable project.';
const bridge = fileURLToPath(new URL('./pty_bridge.py', import.meta.url));
const parseRows = bytes => bytes.toString('utf8').split('\n').filter(Boolean).map(JSON.parse);
const firstParty = 'https://api.anthropic.com';

export async function serveSyntheticInference(req, res, model) {
  const target = new URL(req.url, firstParty);
  if (req.method !== 'POST' || target.origin !== firstParty || req.headers.host !== 'api.anthropic.com' ||
    !['/v1/messages', '/v1/messages/count_tokens'].includes(target.pathname)) return false;

  const send = status => { res.writeHead(status); res.end(); return true; };
  if (req.headers.authorization !== 'Bearer ' + CREDIT_SYNTHETIC_TOKEN) {
    req.resume();
    return send(401);
  }
  const chunks = [];
  let bytes = 0;
  for await (const chunk of req) {
    bytes += chunk.length;
    if (bytes > 4 * 1024 ** 2) return send(413);
    chunks.push(chunk);
  }
  const reply = await fetch(new URL(target.pathname + target.search, model.url), {
    method: 'POST', body: Buffer.concat(chunks), headers: { 'content-type': 'application/json' },
    redirect: 'error', signal: AbortSignal.timeout(8000),
  });
  res.writeHead(reply.status, { 'content-type': reply.headers.get('content-type') ?? 'application/json' });
  await pipeline(Readable.fromWeb(reply.body), res);
  return true;
}

export function ageNewerModelResumeJournal(original) {
  const rows = parseRows(original);
  const offsetMs = 3 * 60 * 60 * 1000;
  for (const row of rows) {
    if (typeof row.timestamp === 'string' && Number.isFinite(Date.parse(row.timestamp))) {
      row.timestamp = new Date(Date.parse(row.timestamp) - offsetMs).toISOString();
    }
  }
  assert.ok(rows.some(row => row.type === 'assistant' && row.message?.model === older));
  assert.ok(!rows.some(row => row.type === 'assistant' && row.message?.model === newer));
  return { offsetMs, aged: Buffer.from(rows.map(row => JSON.stringify(row)).join('\n') + '\n') };
}

/** Exercise original native admission on a generated conversation with a controlled historical timestamp. */
export async function probeNativeNewerModelResume(workspace, form) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  assert.match(workspace, /^\/work\/\.claude-research\/apack-terminal-owner-app-newermodel[0-9]+$/);
  assert.ok(['dialog', 'line'].includes(form));
  const boundary = JSON.parse(await readFile('/control/offline-verified', 'utf8'));
  assert.ok(boundary.networkDisabled && boundary.pinnedExecutableReadOnly);
  assert.equal(boundary.newerModelOfferForm, form);
  assert.match(await readFile('/etc/hosts', 'utf8'), /^127\.0\.0\.1\s+api\.anthropic\.com(?:\s|$)/m);
  assert.equal(hash(await readFile(executable)), pin);

  const project = join(workspace, 'project');
  await mkdir(project);
  execFileSync('/usr/bin/git', ['init', '--quiet', '-b', 'main'], {
    cwd: project, timeout: 5000,
    env: { PATH: '/usr/bin:/bin', HOME: workspace, GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_NOSYSTEM: '1' },
  });
  const account = await configureNativeCreditAccount(workspace, 'oauth', { featureCache: 'native-defaults' });
  const config = join(account.CLAUDE_CONFIG_DIR, '.claude.json');
  const input = JSON.parse(await readFile(config, 'utf8'));
  assert.equal(input.cachedGrowthBookFeatures, undefined);
  assert.equal(input.growthBookOverrides, undefined);
  await writeFile(config, JSON.stringify({ ...input, hasCompletedOnboarding: true, projects: {
    [project]: { hasTrustDialogAccepted: true, hasCompletedProjectOnboarding: true },
  } }));
  await writeFile(join(account.CLAUDE_CONFIG_DIR, 'settings.json'), JSON.stringify({
    theme: 'dark', model: newer,
  }));
  const tls = await prepareNativeCreditTls(join(workspace, 'account-tls'));
  const proof = { form, targetSha256: pin, older, newer, status: 'running' };
  const timers = [];
  let billing, model;
  try {
    model = await startSyntheticModel(workspace, 'TextOnly', { textReply: 'The release note is ready.', captureMessages: true, maxRequests: 10 });
    // Admission checks the first-party base URL before it considers the rollout.
    billing = await startNativeCreditBilling(tls, {
      newerModelOfferForm: form, managedConnector: (req, res) => serveSyntheticInference(req, res, model),
    });
    const env = { ...account, PATH: '/usr/bin:/bin', TMPDIR: workspace, TERM: 'xterm-256color',
      COLUMNS: '125', LINES: '32', NODE_EXTRA_CA_CERTS: tls.ca, ANTHROPIC_BASE_URL: firstParty, DISABLE_AUTOUPDATER: '1' };
    const output = join(workspace, 'recording');
    const seed = await record({ executable, cwd: project, env, output, timeoutMs: 30000, maxBytes: 2 * 1024**2,
      args: ['--print', '--verbose', '--output-format', 'stream-json', '--strict-mcp-config', '--model', older, seedPrompt] });
    proof.seedRun = seed;
    assert.equal(seed.status, 'complete');
    const seedRows = parseRows(await readFile(join(seed.directory, 'stdout.bin')));
    const init = seedRows.find(row => row.type === 'system' && row.subtype === 'init');
    assert.match(init.session_id, /^[a-f0-9-]{36}$/);
    assert.ok(model.calls.some(row => row.model === older && row.messages?.some(message => JSON.stringify(message.content).includes(seedPrompt))));
    proof.sessionId = init.session_id;
    const sessions = join(account.CLAUDE_CONFIG_DIR, 'projects');
    const journalPaths = (await readdir(sessions, { recursive: true }))
      .filter(path => basename(path) === proof.sessionId + '.jsonl');
    assert.equal(journalPaths.length, 1);
    const journal = join(sessions, journalPaths[0]);
    const original = await readFile(journal);
    await writeFile(join(workspace, 'seed-journal.jsonl'), original);
    const { offsetMs, aged } = ageNewerModelResumeJournal(original);
    await writeFile(journal, aged);
    proof.age = { offsetMs, originalSha256: hash(original), agedSha256: hash(aged) };

    let visible = '';
    const resume = await record({ executable: '/usr/bin/python3', cwd: project, env, output,
      args: [bridge, executable, '--strict-mcp-config', '--resume', proof.sessionId],
      timeoutMs: 30000, maxBytes: 2 * 1024**2, onStdout(bytes, controls) {
        visible = (visible + stripVTControlCharacters(bytes.toString('utf8'))).slice(-20000);
        const normalized = visible.replace(/\s/g, '');
        const offered = form === 'dialog' ? normalized.includes('1.KeepOpus5') && normalized.includes('2.ContinuewithOpus5.5')
          : /Press[^.]*tocontinuewithOpus5\.5/.test(normalized);
        if (offered && !proof.offerSeen) {
          proof.offerSeen = true;
          if (form === 'dialog') timers.push(setTimeout(() => controls.send('\x1b'), 700));
          timers.push(setTimeout(() => controls.send('\x04'), 1300));
          timers.push(setTimeout(() => controls.send('\x04'), 1800));
        }
      } });
    proof.resumeRun = resume;
    assert.equal(proof.offerSeen, true, 'Original resume offer did not appear in the PTY capture');
    assert.equal(resume.status, 'complete', 'Original CLI did not exit cleanly after the offer');
    proof.status = 'complete';
  } catch (error) {
    proof.status = 'failed';
    proof.error = error.message;
    throw error;
  } finally {
    for (const timer of timers) clearTimeout(timer);
    proof.evaluations = billing?.state.requests.filter(row => row.path === EFFORT_EVAL_ROUTE)
      .map(({ syntheticAuth, status }) => ({ syntheticAuth, status })) ?? [];
    await writeFile(join(workspace, 'newer-model-proof.json'), JSON.stringify(proof, null, 2) + '\n');
    await Promise.all([model?.close(), billing?.close()]);
  }
}
