import assert from 'node:assert/strict';
import{mkdir,mkdtemp,readFile,writeFile,access}from'node:fs/promises';
import{join,resolve}from'node:path';
import{record}from'./record.mjs';
import{startSyntheticModel}from'./synthetic-model.mjs';
import{hash}from'../artifacts/runs.mjs';
export async function probeScheduling(executable,workspace,output,{mode='CronLifecycle',resumeSessionId,expectedJobId,cwd:existingCwd}={}){
 assert.ok(['WakeupFire','WakeupLifecycle','CronLifecycle','CronCreateOnly','CronListOnly','CronResumeCleanup','CronFire'].includes(mode));
 executable=resolve(executable);workspace=resolve(workspace);output=resolve(output);
 await mkdir(workspace,{recursive:true});const cwd=existingCwd??await mkdtemp(join(workspace,'cron-'));
 const target=new Date(Date.now()+65000);
 const cronExpression=mode==='CronFire'?`${target.getUTCMinutes()} ${target.getUTCHours()} ${target.getUTCDate()} ${target.getUTCMonth()+1} *`:undefined;
 const model=await startSyntheticModel(cwd,mode,{expectedCronJobId:expectedJobId,cronExpression});
 const tools=[],results=[],permissions=[],terminals=[];let buffer='',terminal;
 try{
  const run=await record({executable,cwd,output,timeoutMs:mode==='WakeupFire'?180000:mode==='CronFire'?120000:30000,
   args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--setting-sources','',
    '--strict-mcp-config','--tools',['WakeupLifecycle','WakeupFire'].includes(mode)?'ScheduleWakeup':'CronCreate,CronList,CronDelete','--permission-prompt-tool','stdio','--permission-mode','default','--model','default',
    ...(['CronCreateOnly','CronResumeCleanup'].includes(mode)?[]:['--no-session-persistence']),...(resumeSessionId?['--resume',resumeSessionId]:[]),'--max-turns','6','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})],
   env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),ANTHROPIC_BASE_URL:model.url,TZ:'UTC',
    ENABLE_TOOL_SEARCH:'0',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
   input:[JSON.stringify({type:'control_request',request_id:'initialize',request:{subtype:'initialize',hooks:{}}})+'\n'],
   onStdout(bytes,transport){buffer+=bytes;while(buffer.includes('\n')){
    const at=buffer.indexOf('\n'),line=buffer.slice(0,at);buffer=buffer.slice(at+1);let value;try{value=JSON.parse(line)}catch{continue}
    if(value.type==='control_response'&&value.response.request_id==='initialize')transport.send(JSON.stringify({type:'user',message:{role:'user',content:mode==='WakeupFire'?'Arm a disposable dynamic wakeup and wait for its native prompt before stopping the loop.':mode==='WakeupLifecycle'?'Arm a disposable dynamic wakeup; the next host turn will stop it.':'Create a future session-only scheduling fixture, list it, delete it, then list again.'}})+'\n');
    if(value.type==='assistant')for(const block of value.message.content??[])if(block.type==='tool_use')tools.push(block);
    if(value.type==='user')for(const block of value.message.content??[])if(block.type==='tool_result')results.push({block,data:value.tool_use_result});
    if(value.type==='control_request'&&value.request.subtype==='can_use_tool'){
     permissions.push(value.request.tool_name);transport.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:{behavior:'allow',updatedInput:value.request.input}}})+'\n');
    }
    if(value.type==='result'){terminal=value;terminals.push(value);if(mode==='WakeupLifecycle'&&terminals.length===1)transport.send(JSON.stringify({type:'user',message:{role:'user',content:'Stop the disposable dynamic wakeup now.'}})+'\n');else if(!['CronFire','WakeupLifecycle','WakeupFire'].includes(mode)||terminals.length>=2)transport.closeInput()}
   }}});
  let durableFileExists=true;try{await access(join(cwd,'.claude','scheduled_tasks.json'))}catch(error){if(error.code==='ENOENT')durableFileExists=false;else throw error}
  const names=tools.map(tool=>tool.name),errors=results.filter(result=>result.block.is_error);
  const listing=results.find(result=>result.block.tool_use_id===(mode==='CronFire'?'cron_fired_list_fixture':mode==='CronResumeCleanup'?'cron_resumed_list_fixture':'cron_list_fixture'));
  const empty=results.find(result=>result.block.tool_use_id===(mode==='CronResumeCleanup'?'cron_resumed_empty_fixture':'cron_empty_fixture'));
  const lifecycle=JSON.stringify(names)==='["CronCreate","CronList","CronDelete","CronList"]'&&listing?.data?.jobs?.length===1&&empty?.data?.jobs?.length===0;
  const createOnly=JSON.stringify(names)==='["CronCreate"]'&&results[0]?.data?.durable===false;
  const listedExpected=expectedJobId?listing?.data?.jobs?.length===1&&listing.data.jobs[0].id===expectedJobId:listing?.data?.jobs?.length===0;
  const listOnly=JSON.stringify(names)==='["CronList"]'&&listedExpected;
  const cleanup=JSON.stringify(names)==='["CronList","CronDelete","CronList"]'&&listedExpected&&empty?.data?.jobs?.length===0;
  const timedFire=JSON.stringify(names)==='["CronCreate","CronList"]'&&listing?.data?.jobs?.length===0&&terminals.length===2&&terminals.every(value=>value.subtype==='success')&&model.calls.some(call=>call.scheduledPromptInLatestUser);
  const wakeup=JSON.stringify(names)==='["ScheduleWakeup","ScheduleWakeup"]'&&results[0]?.data?.clampedDelaySeconds===60&&results[0]?.data?.wasClamped===true&&results[1]?.data?.stopped===true&&results[1]?.data?.cancelledWakeups===(mode==='WakeupFire'?0:1)&&terminals.length===2&&terminals.every(value=>value.subtype==='success'&&value.session_id===terminals[0].session_id)&&(mode!=='WakeupFire'||model.calls.some(call=>call.scheduledPromptInLatestUser));
  const evidence={mode,expectedJobId,cronExpression,resultCount:terminals.length,scheduledPromptRequests:model.calls.filter(call=>call.scheduledPromptInLatestUser).length,cwd,sessionId:terminal?.session_id,transportStatus:run.status,transportReason:run.reason,verified:run.status==='complete'&&terminal?.subtype==='success'&&errors.length===0&&(['WakeupLifecycle','WakeupFire'].includes(mode)?wakeup:mode==='CronLifecycle'?lifecycle:mode==='CronCreateOnly'?createOnly:mode==='CronResumeCleanup'?cleanup:mode==='CronFire'?timedFire:listOnly)&&!durableFileExists,
   tools,results,permissions,durableFileExists,syntheticApiRequests:model.calls.length,realModelRequests:0,
   driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))};
  await writeFile(join(run.directory,'scheduling.json'),JSON.stringify(evidence,null,2)+'\n');
  if(!evidence.verified){const path=join(run.directory,'manifest.json');const manifest=JSON.parse(await readFile(path));await writeFile(path,JSON.stringify({...manifest,status:'failed',verificationFailure:'scheduling-verification-failed'},null,2)+'\n')}
  assert.equal(evidence.verified,true,`Scheduling verification failed: ${run.directory}`);return{...run,...evidence};
 }finally{await model.close()}
}

export async function probeSchedulingResume(executable,workspace,output){
 const created=await probeScheduling(executable,workspace,output,{mode:'CronCreateOnly'});
 const expectedJobId=created.results[0].data.id;
 const restored=await probeScheduling(executable,workspace,output,{mode:'CronResumeCleanup',cwd:created.cwd,resumeSessionId:created.sessionId,expectedJobId});
 const empty=await probeScheduling(executable,workspace,output,{mode:'CronListOnly',cwd:created.cwd,resumeSessionId:created.sessionId});
 assert.equal(restored.sessionId,created.sessionId);assert.equal(empty.sessionId,created.sessionId);
 const evidence={verified:true,createdRun:created.directory,restoredAndDeletedRun:restored.directory,emptyAfterResumeRun:empty.directory,expectedJobId,
  syntheticApiRequests:created.syntheticApiRequests+restored.syntheticApiRequests+empty.syntheticApiRequests,realModelRequests:0};
 await writeFile(join(empty.directory,'scheduling-resume.json'),JSON.stringify(evidence,null,2)+'\n');
 return evidence;
}
