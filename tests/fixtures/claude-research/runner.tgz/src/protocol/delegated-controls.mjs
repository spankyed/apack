import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Validate safe no-op/refusal cases; never request title generation, attachment fetch or peer delivery. */
export async function probeDelegatedControls(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'delegated-controls-')),home=join(workspace,'home'),cwd=join(workspace,'project');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(cwd);
 const settings=join(home,'.claude','settings.json'),before=JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',model:'sonnet',language:'preserve'});await writeFile(settings,before);
 const requests=[{subtype:'initialize'},{subtype:'send_task_message'},{subtype:'mcp_tasks_changed'},{subtype:'prefetch_attachments',files:Array.from({length:17},()=>({})),issued_at:0},{subtype:'generate_session_title',description:42,persist:false}],replies=[];let pending='',index=0;
 const run=await createRun(output,'delegated-controls',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
 const input=()=>JSON.stringify({type:'control_request',request_id:'catalog-'+index,request:requests[index]})+'\n';
 let model;
 try{
  model=await startSyntheticModel(cwd,'TextOnly');
  const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','','--no-session-persistence'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[input()],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type==='control_response'&&value.response?.request_id==='catalog-'+index){replies.push({request:requests[index],response:value.response});index++;if(index<requests.length)channel.send(input());else channel.closeInput();}
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(index,requests.length);assert.equal(model.calls.length,0);assert.equal(await readFile(settings,'utf8'),before);
  assert.deepEqual(replies.map(value=>value.response.subtype),['success','error','success','error','error']);
  assert.match(replies[1].response.error,/Unsupported control request subtype: send_task_message/);
  assert.match(replies[3].response.error,/prefetch_attachments: files must be a list of at most 16/);
  assert.match(replies[4].response.error,/generate_session_title: description must be a string/);
  const evidence={replies:replies.slice(1),settingsUnchanged:true,localModelRequests:0,realModelRequests:0,qualification:'Private initialized process: send_task_message refusal, mcp_tasks_changed no-op receipt, deliberately invalid attachment/title input refusal only. No peer delivery, valid attachment download, title generation, every mode/provider or app UI claim.'};
  await writeFile(join(run.directory,'delegated-controls.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}finally{await model?.close();}
}
