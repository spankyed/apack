import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

export async function probeMcpCommandOutput(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'mcp-command-output-')),cwd=join(workspace,'project'),home=join(workspace,'home');await mkdir(cwd,{recursive:true});await mkdir(join(home,'.claude'),{recursive:true});execFileSync('/usr/bin/git',['init','-q',cwd]);
 const server=fileURLToPath(new URL('./synthetic-mcp-health-server.mjs',import.meta.url)),userMarker=join(workspace,'user-started'),projectMarker=join(workspace,'project-started');
 const run=await createRun(output,'mcp-command-output',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),serverSha256:hash(await readFile(server)),implementationSha256:hash(await readFile(new URL('./synthetic-mcp-server.mjs',import.meta.url)))}),cases=[];
 const count=async path=>{try{return(await readFile(path,'utf8')).trim().split('\n').filter(Boolean).length;}catch(error){if(error.code==='ENOENT')return 0;throw error;}};
 async function invoke(label,args,exitCode=0){const before={user:await count(userMarker),project:await count(projectMarker)},transport=await record({executable,cwd,output,args,timeoutMs:15000,env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}});assert.equal(transport.code,exitCode);assert.equal(transport.reason,undefined);
  const stdout=await readFile(join(transport.directory,'stdout.bin'),'utf8'),stderr=await readFile(join(transport.directory,'stderr.bin'),'utf8'),after={user:await count(userMarker),project:await count(projectMarker)};
  cases.push({label,exitCode,stdout:stdout.split(workspace).join('${WORKSPACE}').split(server).join('${HEALTH_SERVER}').split(process.execPath).join('${NODE}'),stderr:stderr.split(workspace).join('${WORKSPACE}'),serverStarts:{user:after.user-before.user,project:after.project-before.project}});return{stdout,stderr};}
 try{
  await invoke('empty list',['mcp','list']);
  const config=marker=>JSON.stringify({type:'stdio',command:process.execPath,args:[server,marker]});
  await invoke('add user',['mcp','add-json','research-user',config(userMarker),'--scope','user']);
  await invoke('user list',['mcp','list']);await invoke('user get',['mcp','get','research-user']);await invoke('missing get',['mcp','get','research-missing'],1);
  await invoke('add project',['mcp','add-json','research-project',config(projectMarker),'--scope','project']);
  await invoke('mixed list',['mcp','list']);await invoke('project get',['mcp','get','research-project']);
  await invoke('list JSON flag',['mcp','list','--json'],1);await invoke('get JSON flag',['mcp','get','research-user','--json'],1);
  for(const item of cases){assert.equal(item.serverStarts.project,0);assert.equal(item.serverStarts.user,['user list','user get','mixed list'].includes(item.label)?1:0);}
  assert.ok(cases.find(value=>value.label==='empty list').stdout.includes('No MCP servers configured.'));
  assert.ok(cases.find(value=>value.label==='user list').stdout.includes('Checking MCP server health'));
  assert.ok(cases.find(value=>value.label==='user get').stdout.includes('Scope: User config'));
  assert.ok(cases.find(value=>value.label==='project get').stdout.includes('Pending approval'));
  for(const label of ['list JSON flag','get JSON flag'])assert.ok(cases.find(value=>value.label===label).stderr.includes("unknown option '--json'"));
  const evidence={cases,modelPrompts:0,qualification:'Native human-readable MCP commands; private stdio server health checks may start fixture processes. No model prompt, auth flow, remote server or app parser claim.'};await writeFile(join(run.directory,'mcp-command-output.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
