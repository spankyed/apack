import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from './record.mjs';
import {recognizeOnboardingPrompt} from './pty-onboarding.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {hash} from '../artifacts/runs.mjs';

/** Observe native frame callbacks and data producers; never serialize credentials or invoke callbacks. */
export function nativeSettingsFrameInspector(outputPath){
 return `
{
 const {readFileSync,writeFileSync}=await import('node:fs');
 const {createHash}=await import('node:crypto');
 const sha=value=>createHash('sha256').update(value).digest('hex');
 if(process.platform==='linux'&&sha(readFileSync(process.execPath))==='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'){
  let busy=false,attempts=0;const captures={};
  const timer=setInterval(async()=>{if(busy)return;busy=true;try{
   if(++attempts>450){clearInterval(timer);return;}
   const runtime=await import('/$bunfs/root/'+'chunk-a7b8k0bt.js'),binding=runtime.Zh();if(binding?.surface!=='terminal')return;
   const context=binding.toolContext(new AbortController());
   writeFileSync(${JSON.stringify(outputPath+'.ready')},JSON.stringify({surface:binding.surface,busy:context.turnActivity.getSnapshot()===true}),{mode:0o600});
   const roots=await import('/$bunfs/root/'+'chunk-f7hx5xpd.js');
   const pending=[roots.ai().get(process.stdout)?.container?.current],seen=new Set(),matches=[],data=[];let frame,statsTab,range='all',loading=false;
   while(pending.length){
    const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('Native Settings frame traversal exceeded bound');seen.add(fiber);
    const p=fiber.memoizedProps,type=fiber.type;
    if(typeof type==='function'&&p&&typeof p==='object'){
     const titles=Array.isArray(p.children)?p.children.map(child=>child?.props?.title).filter(title=>typeof title==='string'):[];
     const isFrame=p.title==='Settings'&&typeof p.onTabChange==='function';
     const isStatsTabs=p.title===null&&typeof p.onTabChange==='function'&&titles.includes('Overview')&&titles.includes('Models');
     const isStatsData=p.stats&&typeof p.stats.modelUsage==='object';
     const isStatsLoader=p.allTimePromise&&p.activeTimePromise;
     const isStatus=Object.hasOwn(p,'accountStatusRead')&&Object.hasOwn(p,'machineStatusRead');
     if(isFrame||isStatsTabs||isStatsData||isStatsLoader||isStatus||typeof p.defaultTab==='string'&&typeof p.onClose==='function'){
      const ancestors=[];for(let a=fiber.return;a&&ancestors.length<8;a=a.return)ancestors.push({name:typeof a.type==='function'?a.type.name:typeof a.type,keys:Object.keys(a.memoizedProps??{}),nodeId:a.memoizedProps?.nodeId});
      const value={name:type.name,sha256:sha(Function.prototype.toString.call(type)),keys:Object.keys(p),titles,selectedTab:p.selectedTab,hidden:p.hidden,defaultTab:p.defaultTab,ancestors};
      matches.push(value);
      if(isFrame)frame={...value,title:p.title};
      if(isStatsTabs)statsTab=p.selectedTab;
      if(isStatsData){range=p.selectorRange??p.dateRange??'all';loading||=p.isLoading===true;data.push({name:type.name,range,dateRange:p.dateRange,loading:p.isLoading===true,stats:p.stats,allTimeStats:p.allTimeStats});}
      if(isStatsLoader){const outcome=await p.allTimePromise;value.loadResult=outcome?.type;value.dataKeys=outcome?.data?Object.keys(outcome.data):[];}
      if(isStatus){const caches=fiber.updateQueue?.memoCache?.data??[];value.cacheRows=caches.filter(cache=>Array.isArray(cache)&&cache.length===17).map(cache=>cache[10]).filter(Array.isArray).map(groups=>groups.map(group=>Array.isArray(group)?group.map(row=>({label:row.label,type:typeof row.value,...(typeof row.value==='string'?{value:row.value}:{})})):[]));}
     }
    }
    if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);
   }
   if(!frame)return;
   const key=frame.selectedTab==='Stats'?'Stats-'+(statsTab??'pending')+'-'+range:frame.selectedTab;
   const value={key,frame,statsTab,range,loading,matches,data,open:context.dialogStore.getState().open.map(item=>({id:item.id,kind:item.kind,nodeId:item.payload?.nodeId,payloadKeys:Object.keys(item.payload??{})})),visited:seen.size};
   captures[key]=value;const body=JSON.stringify({current:key,captures},null,2);if(Buffer.byteLength(body)>524288)throw Error('Native Settings frame evidence exceeds bound');writeFileSync(${JSON.stringify(outputPath)},body,{mode:0o600});
  }catch(error){writeFileSync(${JSON.stringify(outputPath+'.error')},String(error),{mode:0o600});clearInterval(timer);}finally{busy=false;}},100);timer.unref();
 }
}
`;
}

/** Original native keys discover the frame; the product will expose desktop tabs, not terminal navigation. */
export async function probeNativeSettingsFrame(executable,parent,output){
 assert.equal(process.platform,'linux','Native execution belongs to the owned Linux container');
 const targetSha256=hash(await readFile(executable));assert.equal(targetSha256,'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 await mkdir(parent,{recursive:true});const workspace=await mkdtemp(join(resolve(parent),'settings-frame-'));
 await mkdir(join(workspace,'.claude'),{recursive:true});
 await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}));
 const observation=join(workspace,'native-settings-frame.json'),preload=join(workspace,'settings-frame-preload.mjs');await writeFile(preload,nativeSettingsFrameInspector(observation),{mode:0o600});
 const model=await startSyntheticModel(workspace,'TextOnly',{maxRequests:3,captureMessages:true});
 const bridge=fileURLToPath(new URL('./pty_bridge.py',import.meta.url));
 let terminal='',transport,theme=false,security=false,navigated=false,trusted=false,stage='boot',exiting=0,run,pollBusy=false;
 const timers=[];const send=(text,delay=150)=>timers.push(setTimeout(()=>transport?.send(text),delay));
 const poll=setInterval(async()=>{if(pollBusy||!transport)return;pollBusy=true;try{
  const compact=terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');
  const ready=JSON.parse(await readFile(observation+'.ready','utf8').catch(()=>'null'));
  if(stage==='boot'&&trusted&&ready?.surface==='terminal'&&ready.busy===false){stage='turn';send('Review this owned Settings research session.\r',400);}
  if(stage==='turn'&&model.calls.length&&ready?.busy===false){stage='config';send('/config\r');}
  const evidence=JSON.parse(await readFile(observation,'utf8').catch(()=>'null'));if(!evidence)return;
  if(stage==='config'&&evidence.current==='Config'){stage='status';send('\x1b[A');send('\x1b[D',400);}
  else if(stage==='status'&&evidence.current==='Status'&&evidence.captures.Status.matches.some(row=>row.cacheRows?.length)){stage='usage';send('\x1b[C');send('\x1b[C',400);}
  else if(stage==='usage'&&evidence.current==='Usage'){stage='stats';send('\x1b[C',400);}
  else if(stage==='stats'&&evidence.current==='Stats-Overview-all'&&evidence.captures[evidence.current].data.length&&!evidence.captures[evidence.current].loading){stage='models';send('\x1b[B');send('\x1b[C',400);}
  else if(stage==='models'&&evidence.current==='Stats-Models-all'&&evidence.captures[evidence.current].data.length){stage='range';send('r');}
  else if(stage==='range'&&evidence.current==='Stats-Models-7d'&&!evidence.captures[evidence.current].loading){stage='done';send('\x1b');send('\x04',500);send('\x04',1000);exiting=2;}
 }catch(error){if(error.code!=='ENOENT')terminal+='\nPROBE_READ_ERROR '+String(error);}finally{pollBusy=false;}},100);
 try{
  run=await record({executable:'/usr/bin/python3',cwd:workspace,output,timeoutMs:50000,maxBytes:4*1024*1024,args:[bridge,resolve(executable),'--setting-sources','user','--strict-mcp-config','--tools','Read','--permission-mode','default'],env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),TERM:'xterm-256color',COLUMNS:'120',LINES:'50',BUN_OPTIONS:'--preload='+preload,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},onStdout(bytes,channel){
   transport=channel;terminal+=bytes.toString('utf8');const screen=recognizeOnboardingPrompt(terminal,workspace),compact=terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');
   if(screen==='theme'&&!theme){theme=true;send('\r');}else if(screen==='security-notes'&&theme&&!security){security=true;send('\r');}else if(screen==='workspace-trust'&&!navigated){navigated=true;send('\x1b[B');}else if(screen==='workspace-trust-selected'&&!trusted){trusted=true;send('\r');}else if(trusted&&stage==='boot'&&compact.includes('shift+tabtocycle')){stage='turn';send('Review this owned Settings research session.\r');}
  }});
  const frame=JSON.parse(await readFile(observation,'utf8').catch(()=>'null'));
  const proof={workspace,run,targetSha256,stage,exiting,modelRequests:model.calls.length,realModelRequests:0,frame,scope:'Original native frame/callback/data discovery only. No product Settings frame acceptance or settings write.'};
  await writeFile(join(run.directory,'native-settings-frame-proof.json'),JSON.stringify(proof,null,2)+'\n');
  await writeFile(join(run.directory,'model-calls.json'),JSON.stringify(model.calls,null,2)+'\n');
  assert.equal(stage,'done','Inspect preserved frame discovery before selecting an adapter');assert.equal(run.code,0);assert.equal(run.reason,undefined);return proof;
 }finally{clearInterval(poll);for(const timer of timers)clearTimeout(timer);await model.close();}
}
