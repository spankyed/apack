import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Separate settings discovery, instruction discovery and trust in no-prompt startup reads. */
export async function probeSettingsDirectories(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'settings-directories-')),repo=join(workspace,'repo'),child=join(repo,'subfolder');await mkdir(join(repo,'.claude'),{recursive:true});await mkdir(child,{recursive:true});
 const gitHome=join(workspace,'git-home');await mkdir(gitHome,{recursive:true});const gitEnv={PATH:process.env.PATH,HOME:gitHome,GIT_CONFIG_NOSYSTEM:'1'};execFileSync('/usr/bin/git',['init','-q','--template=',repo],{env:gitEnv});
 const layer=label=>({language:`research-${label}`,env:{[`CLAUDE_RESEARCH_${label.toUpperCase()}`]:label},...label==='root_local'?{permissions:{ask:['Read']}}:label==='child_local'?{permissions:{ask:['Glob']}}:{}});
 await writeFile(join(repo,'.claude','settings.json'),JSON.stringify(layer('root_project')));await writeFile(join(repo,'.claude','settings.local.json'),JSON.stringify(layer('root_local')));
 await writeFile(join(repo,'CLAUDE.md'),'Synthetic repository root instruction.\n');await writeFile(join(child,'CLAUDE.md'),'Synthetic subfolder instruction.\n');
 const scenarios=[{name:'root-default',cwd:repo},{name:'child-default',cwd:child},{name:'child-trusted',cwd:child,trust:repo},{name:'child-explicit-sources',cwd:child,sources:'user,project,local'},{name:'child-own-settings',cwd:child,ownSettings:true},{name:'root-after-child-settings',cwd:repo}];
 const run=await createRun(output,'settings-directories',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),gitVersion:execFileSync('/usr/bin/git',['--version'],{env:gitEnv}).toString().trim()});const cases=[];
 try{
  for(const scenario of scenarios){
   if(scenario.ownSettings){await mkdir(join(child,'.claude'),{recursive:true});await writeFile(join(child,'.claude','settings.json'),JSON.stringify(layer('child_project')));await writeFile(join(child,'.claude','settings.local.json'),JSON.stringify(layer('child_local')))}
   const home=join(workspace,`home-${scenario.name}`),config=join(home,'.claude');await mkdir(config,{recursive:true});await writeFile(join(config,'settings.json'),JSON.stringify(layer('user')));await writeFile(join(config,'CLAUDE.md'),'Synthetic user instruction.\n');
   let pending='';const replies=[],requests=[{subtype:'initialize',hooks:{},...scenario.trust?{workspaceTrust:{accepted:true,directory:scenario.trust}}:{}},{subtype:'get_settings'},{subtype:'get_memory_dialog'},{subtype:'get_context_usage',detail:'full'},{subtype:'get_settings'}];const line=i=>JSON.stringify({type:'control_request',request_id:`directories-${i}`,request:requests[i]})+'\n';
   const transport=await record({executable,cwd:scenario.cwd,output,timeoutMs:12000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--strict-mcp-config','--tools','','--no-session-persistence',...scenario.sources?['--setting-sources',scenario.sources]:[]],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[line(0)],onStdout(bytes,channel){pending+=bytes.toString();while(pending.includes('\n')){const i=pending.indexOf('\n'),text=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(text)}catch{continue}if(value.type!=='control_response'||value.response?.request_id!==`directories-${replies.length}`)continue;replies.push(value.response);if(replies.length<requests.length)channel.send(line(replies.length));else channel.closeInput()}}});
   assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(replies.length,5);for(const reply of replies)assert.equal(reply.subtype,'success');
   cases.push({...scenario,trustRecorded:replies[0].response.workspace_trust_recorded??null,before:replies[1].response,dialog:replies[2].response,contextMemoryFiles:replies[3].response.memoryFiles,after:replies[4].response,transportRun:transport.directory});
  }
  for(const item of cases){
   assert.equal(item.before.effective.language,'research-root_local');assert.deepEqual(item.after,item.before);
   const env=item.before.effective.env,childCase=item.name.startsWith('child-');
   assert.equal(Object.hasOwn(env,'CLAUDE_RESEARCH_ROOT_PROJECT'),!childCase);
   assert.equal(Object.hasOwn(env,'CLAUDE_RESEARCH_CHILD_PROJECT'),item.name==='child-own-settings');
   assert.equal(Object.hasOwn(env,'CLAUDE_RESEARCH_CHILD_LOCAL'),item.name==='child-own-settings');
   assert.equal(env.CLAUDE_RESEARCH_ROOT_LOCAL,'root_local');
   assert.ok(item.contextMemoryFiles.some(file=>file.path===join(repo,'CLAUDE.md')));
   assert.equal(item.contextMemoryFiles.some(file=>file.path===join(child,'CLAUDE.md')),childCase);
   if(item.trust)assert.equal(item.trustRecorded,true);
  }
  const writerCases=[],rootLocal=join(repo,'.claude','settings.local.json'),childLocal=join(child,'.claude','settings.local.json'),writerHome=join(workspace,'home-child-own-settings');
  for(const rule of ['Glob','Read']){
   const beforeRoot=await readFile(rootLocal),beforeChild=await readFile(childLocal);
   const transport=await record({executable,cwd:child,output,timeoutMs:10000,args:['edit-permission-rules','--json'],input:[JSON.stringify({op:'remove',rule,behavior:'ask',source:'localSettings'})+'\n'],env:{PATH:process.env.PATH,HOME:writerHome,CLAUDE_CONFIG_DIR:join(writerHome,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}});
   const afterRoot=await readFile(rootLocal),afterChild=await readFile(childLocal),stderr=(await readFile(join(transport.directory,'stderr.bin'),'utf8')).trim();
   assert.equal(transport.code,rule==='Glob'?1:0);assert.deepEqual(afterChild,beforeChild);
   if(rule==='Glob'){assert.deepEqual(afterRoot,beforeRoot);assert.match(stderr,/launch directory/)}
   else{assert.ok(!JSON.parse(afterRoot).permissions.ask.includes('Read'));assert.equal(JSON.parse(afterRoot).language,'research-root_local')}
   writerCases.push({rule,code:transport.code,rootFileChanged:!afterRoot.equals(beforeRoot),childFileUnchanged:afterChild.equals(beforeChild),stderr,rootSettings:JSON.parse(afterRoot),childSettings:JSON.parse(afterChild),transportRun:transport.directory});
  }
  const normalized=JSON.parse(JSON.stringify(cases).split(workspace).join('${WORKSPACE}'));await writeFile(join(run.directory,'settings-directories.json'),JSON.stringify({cases:normalized,writerCases:JSON.parse(JSON.stringify(writerCases).split(workspace).join('${WORKSPACE}')),modelPrompts:0,qualification:'No-prompt startup only, inert markers and owned-folder trust attestation. No instruction effects, model turns, symlinks/worktrees/managed sources or real app consent workflow.'},null,2)+'\n');await run.finish({status:'complete',cases:cases.length});return{directory:run.directory,status:'complete',cases:cases.map(item=>({name:item.name,before:item.before.effective.language,after:item.after.effective.language,beforeEnv:Object.keys(item.before.effective.env??{}),afterEnv:Object.keys(item.after.effective.env??{}),instructionPaths:item.contextMemoryFiles?.map(file=>file.path.replace(workspace,'${WORKSPACE}'))})),modelPrompts:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
