import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';
export const LINE_RESET_BASE='Review notes and rollout across the complete desktop release checklist with the team';
export const LINE_RESET_TEXTS=[LINE_RESET_BASE,LINE_RESET_BASE+' before publishing.',LINE_RESET_BASE+' before publishing. Confirmed.'];
export const LINE_RESET_PLUGIN=`export function register(on){on('prompt.edit',async($,e,next)=>{const result=await next(e),start=result.text.indexOf('Review notes');if(start<0)return result;const retired=result.text.endsWith('Confirmed.'),strike=result.text.includes('before publishing.');return {...result,decorations:retired?[]:[{start,end:start+12,underline:false,strikethrough:strike}]};});}`;
export async function verifyPromptLineResets(workspace,evidence,calls){
 assert.equal(evidence.nativePromptLineResets,true);assert.equal(evidence.sessionId,evidence.finalSessionId);
 const proof=JSON.parse(await readFile(join(workspace,'native-line-reset-proof.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.boundNativePid,evidence.boundNativePid);
 assert.deepEqual(proof.stages.map(row=>[row.stage,row.text]),['reset','strike','retired'].map((stage,index)=>[stage,LINE_RESET_TEXTS[index]]));
 const controls=(await readFile(join(workspace,'native-font-reset-controls.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 for(const stage of proof.stages){
  const control=controls.find(row=>row.reply?.id===stage.nativeReplyId);
  assert.ok(control,'Missing original normalized native reply');assert.equal(control.status,200);assert.equal(control.pid,proof.boundNativePid);assert.equal(control.request.ownerPid,proof.boundNativePid);assert.equal(control.request.sessionId,proof.sessionId);assert.equal(control.reply.id,control.request.id);assert.equal(control.reply.pid,proof.boundNativePid);assert.equal(control.reply.sessionId,proof.sessionId);assert.equal(control.request.request.surface,'desktop');assert.equal(control.request.request.subtype,'ui_prompt_edit');assert.equal(typeof proof.nativeClientId,'string');assert.ok(proof.nativeClientId.length>0);assert.equal(control.request.request.client_id,proof.nativeClientId);
  assert.equal(control.reply.result.text,stage.text);assert.equal(control.reply.result.cursor,stage.text.length);
  const runs=control.reply.result.decorations??[];
  if(stage.stage==='retired')assert.equal(runs.length,0);else assert.ok(runs.some(run=>run.start===0&&run.end===12&&run.underline===false&&run.strikethrough===(stage.stage==='strike')),'Original native line flags changed');
 }
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width]),['reset','strike','retired'].flatMap(stage=>[1100,680].map(width=>[stage,width])));
 for(const capture of proof.captures){
  const stage=proof.stages.find(row=>row.stage===capture.stage);assert.deepEqual(capture.selection,stage.selection);assert.equal(capture.parentText,stage.text);assert.ok(capture.horizontalFits);
  if(capture.stage==='retired'){assert.equal(capture.paintCount,0);assert.equal(capture.parentLine,'underline');}
  else {assert.equal(capture.parentLine,'none');assert.equal(capture.nativeLine,capture.stage==='reset'?'none':'line-through');assert.equal(capture.inheritedLine,'underline');assert.equal(capture.nativeDisplay,'inline');assert.equal(capture.inheritedDisplay,'inline');}
 }
 assert.ok(proof.captures.some(row=>row.width===680&&row.lineRects>1),'Compact long draft did not exercise natural line wrapping');
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.equal(paths.length,1);
 const rows=(await readFile(join(root,paths[0]),'utf8')).trim().split('\n').map(JSON.parse),text=content=>typeof content==='string'?content:(content??[]).filter(block=>block.type==='text').map(block=>block.text).join('\n');
 const humans=rows.filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'));
 assert.deepEqual(humans.map(row=>text(row.message.content)),['Review the release notes for this project.',LINE_RESET_TEXTS[2],'Continue after reviewing native line styles.']);assert.equal(humans[1].uuid,proof.sentUuid);
 assert.ok(calls.agent.some(call=>(call.messages??[]).some(message=>message.role==='user'&&text(message.content)===LINE_RESET_TEXTS[2])),'Original model request lost the exact draft');assert.equal(calls.seed.length,2);
 return {sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),nativeReplyIds:proof.stages.map(row=>row.nativeReplyId),captures:proof.captures,scope:'Main-owner native line reset/strike/clear over the actual chat Underline mark, adjacent inheritance, inline wrapping, exact plain-text serialization and same-session recovery. Existing HTML-disabled serialization does not transfer the underline mark; other owners/marks/lifetimes remain separate.'};
}
