import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, copyFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { record } from './record.mjs';
import { hash } from '../artifacts/runs.mjs';
import { existsSync, writeFileSync } from 'node:fs';
import { startSyntheticModel } from './synthetic-model.mjs';

const targetSha256 = '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37';
export async function probeNativeClient(executable, workspaceParent, output, apackCheckout) {
  assert.equal(hash(await readFile(executable)), targetSha256);
  await mkdir(workspaceParent, { recursive: true });
  const workspace = await mkdtemp(join(workspaceParent, 'native-client-'));
  const config=join(workspace,'.claude'),plugin=join(workspace,'client-fixture');
  await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
  await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'research-client-fixture',version:'0.0.1'}));
  await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
  await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){const fields=[],completed=[];on('ui.input',async($,e,next)=>{fields.push(e);await $.fs.write('native-client-field-events.json',JSON.stringify(fields));const before=await $.clock.now();await $.clock.sleep(60,{signal:next.signal});completed.push({value:e.value,elapsed:(await $.clock.now())-before});await $.fs.write('native-client-field-completed.json',JSON.stringify(completed));if(e.value==='ReturnOnlyField')return {element:e.element,value:e.value};return next(e.value==='RewriteField'?{...e,value:'NativeRewritten'}:e);});on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const{Box,Client}=$.ui.resolve(e);return Box({flexDirection:'row',children:[Client({key:'counter',module:'./surface.ts',props:{label:'initial'},width:'49%',height:14,flexGrow:1}),Client({key:'peer',module:'./surface.ts',props:{label:'other'},width:'49%',height:14})]});});on('ui.message',async($,e,next)=>{await $.fs.write('native-client-message.json',JSON.stringify(e));return {props:{label:'reply'}};});}`);
  await writeFile(join(plugin,'hooks/surface.ts'),`export default function(props,s){const{Box,Text,Button,Input,Select}=s.elements;if(s.state===undefined){s.setState({count:0,ticks:0,key:'none',pointer:'none'});s.every(25,()=>s.setState({...s.state,ticks:s.state.ticks+1}));}s.onKey(e=>{s.setState({...s.state,key:e.key});s.post({kind:'key',key:e.key});});s.onPointer(e=>s.setState({...s.state,pointer:e.x+','+e.y}));return Box({children:[Text({children:['NativeClient '+props.label+' count='+s.state.count+' tick='+s.state.ticks+' key='+s.state.key+' xy='+s.state.pointer+' room='+s.columns+'x'+s.rows+' process='+typeof process+' submitted='+(s.state.submitted??'')]}),Button({key:'increment',label:'Increment',onPress:()=>s.setState({...s.state,count:s.state.count+1})}),Input({key:'draft',label:'Native draft',value:s.state.draft??'',onInput:value=>s.setState({...s.state,draft:value}),onSubmit:value=>s.setState({...s.state,submitted:value})}),Select({key:'choice',label:'Native choice',value:s.state.choice??'a',options:[{value:'a',label:'Alpha'},{value:'b',label:'Beta'}],onSelect:value=>s.setState({...s.state,choice:value})})]});}`);
  const reportPath=join(workspace,'native-client.json'),preload=join(workspace,'client.mjs'),trigger=join(workspace,'initialized');
  const adapter=apackCheckout?await readFile(join(apackCheckout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-client-runtime.ts'),'utf8'):undefined;
  const adapterSource=adapter?adapter.slice(adapter.indexOf('String.raw`')+11,adapter.lastIndexOf('`')):'';
  const source=`${adapterSource}\nimport {randomUUID} from 'node:crypto';\nimport {writeFileSync,existsSync} from 'node:fs';
async function probe(){const report={};try{
 const gate=await import('/$bunfs/root/chunk-wn0572jb.js');
 const engine=await import('/$bunfs/root/chunk-c7wcn77x.js');
 const clients=await import('/$bunfs/root/chunk-e980bbar.js');
 await gate._Jo('desktop');
 const drawing=await engine.I9e.run({surface:'desktop',component:'AbovePrompt',requestId:'native-client-probe',props:{}});
 report.drawing=drawing;report.nativeClientRegistry=typeof clients.x3r==='function';
 report.module=engine.I9e.clientModule('research-client-fixture');
 const node=drawing.tree.children[0],registry=clients.x3r();
 const wait=async(predicate,label)=>{const deadline=Date.now()+3000;while(!predicate()){if(Date.now()>deadline)throw Error('Client observation timeout: '+label);await new Promise(resolve=>setTimeout(resolve,10));}};
 const timers=new Set(),clock={every(ms,fn){const timer=setInterval(fn,ms);timers.add(timer);return()=>{clearInterval(timer);timers.delete(timer);}}};
 let instance;
 try{
 instance=registry.acquire({plugin:node.client.plugin,component:'AbovePrompt',requestId:'native-client-probe',surface:'desktop',key:node.props.key,module:node.props.module,props:node.props.props,clock});
 instance.resize(30,3);
 await wait(()=>instance.getSnapshot().status!=='loading','initial draw');
 report.initial=instance.getSnapshot();
 if(report.initial.status!=='drawn')throw Error('Native Client failed: '+JSON.stringify(report.initial));
 instance.setProps({label:'changed'});
 await wait(()=>JSON.stringify(instance.getSnapshot()).includes('changed'),'props redraw');
 report.changed=instance.getSnapshot();
 const find=node=>node.type==='Button'?node:(node.children??[]).map(find).find(Boolean);
 const button=find(report.changed.tree);
 report.button=button;
 report.press=await engine.I9e.press({plugin:node.client.plugin,handle:button.press.handle,surface:'desktop',element:'increment',component:'AbovePrompt',requestId:'native-client-probe'});
 await wait(()=>JSON.stringify(instance.getSnapshot()).includes('changed count=1'),'native held callback');
 report.incremented=instance.getSnapshot();
 const field=(type)=>{const walk=node=>node.type===type?node:(node.children??[]).map(walk).find(Boolean);return walk(instance.getSnapshot().tree);};
 const nativeField=async(type,value,kind='change')=>{
  const drawn=field(type);
  const result=await engine.I9e.clientPress({plugin:node.client.plugin,module:node.props.module,key:node.props.key,component:'AbovePrompt',requestId:'native-client-probe',element:drawn.props.key,event:type==='Input'?{type:'input',kind,value}:{type:'select',value}});
  if(!result.reached)throw Error('Native Client field was not reached');
  const current=field(type),held=engine.r5.heldPress(node.client.plugin,current.press.handle,current.props.key);
  const callback=held&&engine.tut.runnerFor(node.client.plugin,held.handle);
  if(!callback)throw Error('Native Client field callback unavailable');
  callback(result.reached);return result;
 };
 report.nativeInput=field('Input');
 report.nativeInputResult=await nativeField('Input','OriginalFieldValue');
 await wait(()=>field('Input').props.value==='OriginalFieldValue','native input callback');
 report.nativeSelect=field('Select');
 report.nativeSelectResult=await nativeField('Select','b');
 await wait(()=>field('Select').props.value==='b','native select callback');
 report.nativeSubmitResult=await nativeField('Input','SubmittedFieldValue','submit');
 await wait(()=>JSON.stringify(instance.getSnapshot()).includes('submitted=SubmittedFieldValue'),'native input submit');
 report.nativeFieldFrame=instance.getSnapshot();

 instance.key({key:'x',ctrl:true});
 await wait(()=>JSON.stringify(instance.getSnapshot()).includes('key=x'),'native key');
 await wait(()=>JSON.stringify(instance.getSnapshot()).includes('NativeClient reply'),'native message reply');
 report.messageReply=instance.getSnapshot();
 instance.pointer({type:'move',x:-1,y:4,fine:{x:-0.5,y:4.25},button:'left'});
 await wait(()=>JSON.stringify(instance.getSnapshot()).includes('xy=-1,4'),'native pointer');
 instance.resize(42,5);
 await wait(()=>JSON.stringify(instance.getSnapshot()).includes('room=42x5'),'native resize');
 await wait(()=>!JSON.stringify(instance.getSnapshot()).includes('tick=0 '),'native clock');
 report.interactive=instance.getSnapshot();
 report.messageReceipt=JSON.parse(await (await import('node:fs/promises')).readFile(${JSON.stringify(join(workspace,'native-client-message.json'))},'utf8'));

 }finally{instance?.release();try{await wait(()=>timers.size===0,'released Client timers');}finally{registry.dispose();report.liveTimersBeforeFallbackCleanup=timers.size;for(const timer of timers)clearInterval(timer);}}
 report.disposed=true;report.liveTimersAfterDispose=timers.size;
 ${apackCheckout?`const host=createNativeClientHost(clients.x3r,()=>{},clients.R3r,{dispatch:value=>engine.I9e.clientPress(value),run:value=>{const held=engine.r5.heldPress(value.plugin,value.handle,value.key);if(!held||held.component!==value.component||held.requestId!==value.requestId)return false;const fn=engine.tut.runnerFor(value.plugin,held.handle);if(!fn)return false;fn(value.event);return true;}});
 const raw=drawing.tree;
 const get=()=>host.render('view-a','AbovePrompt','native-client-probe',raw);
 try{
 let frame=get();const id=frame.children[0].props.id;
 await wait(()=>JSON.stringify(get()).includes('NativeClient initial'),'adapter mount');
 host.event('view-a',id,1,{kind:'resize',columns:40,rows:6});
 host.event('view-a',id,2,{kind:'key',key:'x'});
 await wait(()=>JSON.stringify(get()).includes('NativeClient reply'),'adapter post reply retained across redraws');
 report.adapterFrame=get();
 report.foreignRefused=!host.event('view-b',id,3,{kind:'key',key:'z'}).handled;
 report.staleRefused=!host.event('view-a',id,1,{kind:'key',key:'z'}).handled;
 host.suspend();report.suspendedRefused=!host.event('view-a',id,3,{kind:'key',key:'z'}).handled;
 get();host.event('view-a',id,3,{kind:'pointer',type:'move',x:-2,y:7,fine:{x:-1.5,y:7.2}});
 await wait(()=>JSON.stringify(get()).includes('xy=-2,7'),'adapter pointer');
 report.adapterInteractive=get();
 const findButton=node=>node.type==='Button'?node:(node.children??[]).map(findButton).find(Boolean);
 const oldButton=findButton(report.adapterInteractive);
 host.event('view-a',id,4,{kind:'pointer',type:'move',x:4,y:2});
 await new Promise(resolve=>setTimeout(resolve,30));
 get(); // Export a newer frame before the delivered older action reaches the host.
 const resolved=await host.dispatchAction('view-a',{subtype:'ui_press',plugin:oldButton.press.plugin,handle:oldButton.press.handle,key:'increment'});
 if(!resolved?.handled)throw Error('Native Client keyed callback was not resolved');
 await wait(()=>JSON.stringify(get()).includes('count=1'),'adapter callback after pointer redraw');
 report.reboundCallback=get();
 const fieldOf=(tree,type)=>{const visit=node=>node.type===type?node:(node.children??[]).map(visit).find(Boolean);return visit(tree);};
 const sendField=async(view,tree,type,value)=>{
  const field=fieldOf(tree,type),subtype=type==='Input'?'ui_input':'ui_select';
  return host.dispatchAction(view,{subtype,plugin:field.press.plugin,handle:field.press.handle,key:field.props.key,...(type==='Input'?{kind:'change'}:{}),value});
 };
 await sendField('view-a',get(),'Input','AdapterDraft');
 await wait(()=>fieldOf(get(),'Input').props.value==='AdapterDraft','adapter input');
 await sendField('view-a',get(),'Select','b');
 await wait(()=>fieldOf(get(),'Select').props.value==='b','adapter select');
 report.adapterFields=get();
 const peerRaw=structuredClone(raw);peerRaw.children[0].props.key='peer';peerRaw.children[0].props.props={label:'peer'};
 const pair={type:'Box',children:[raw.children[0],peerRaw.children[0]]};
 const pairFrame=()=>host.render('view-a','AbovePrompt','native-client-probe',pair);
 await wait(()=>JSON.stringify(pairFrame()).includes('NativeClient peer'),'peer fields');
 const left=pairFrame().children[0],right=pairFrame().children[1];
 await Promise.all([sendField('view-a',left,'Input','LeftDraft'),sendField('view-a',right,'Input','RightDraft')]);
 await wait(()=>fieldOf(pairFrame().children[0],'Input').props.value==='LeftDraft'&&fieldOf(pairFrame().children[1],'Input').props.value==='RightDraft','same-key Client input isolation');
 await Promise.all([sendField('view-a',pairFrame().children[0],'Select','a'),sendField('view-a',pairFrame().children[1],'Select','b')]);
 await wait(()=>fieldOf(pairFrame().children[0],'Select').props.value==='a'&&fieldOf(pairFrame().children[1],'Select').props.value==='b','same-key Client select isolation');
 report.isolatedFields=pairFrame();
 report.withheldField=await sendField('view-a',pairFrame().children[0],'Input','ReturnOnlyField');
 if(report.withheldField.handled)throw Error('Withheld Client field callback ran');if(fieldOf(pairFrame().children[0],'Input').props.value!=='LeftDraft')throw Error('Withheld Client field changed state');
 report.rewrittenField=await sendField('view-a',pairFrame().children[0],'Input','RewriteField');
 await wait(()=>fieldOf(pairFrame().children[0],'Input').props.value==='NativeRewritten','Client input hook rewrite');
 report.rewrittenFieldFrame=pairFrame();
 const leaving=sendField('view-a',pairFrame().children[0],'Input','DetachedField');
 host.render('view-a','AbovePrompt','native-client-probe',{type:'Box',children:[pair.children[1]]});
 report.detachedField=await leaving;if(report.detachedField.handled)throw Error('Detached Client field callback ran');

 report.fieldEvents=JSON.parse(await (await import('node:fs/promises')).readFile(${JSON.stringify(join(workspace,'native-client-field-events.json'))},'utf8'));
 report.fieldWaits=JSON.parse(await (await import('node:fs/promises')).readFile(${JSON.stringify(join(workspace,'native-client-field-completed.json'))},'utf8'));if(!report.fieldWaits.some(wait=>wait.value==='LeftDraft'&&wait.elapsed>=50)||!report.fieldWaits.some(wait=>wait.value==='RightDraft'&&wait.elapsed>=50))throw Error('Queued field delay was not observed');


 const other=host.render('view-b','AbovePrompt','native-client-probe',raw);
 await wait(()=>JSON.stringify(host.render('view-b','AbovePrompt','native-client-probe',raw)).includes('NativeClient initial'),'independent view');
 report.independentView=host.render('view-b','AbovePrompt','native-client-probe',raw);
 report.distinctTokens=id!==other.children[0].props.id;
 host.render('view-a','AbovePrompt','native-client-probe',{type:'Box',children:[]});
 report.removedRefused=!host.event('view-a',id,5,{kind:'key',key:'z'}).handled;
 }finally{host.detach();report.adapterRemaining=host.count();await new Promise(resolve=>setTimeout(resolve,10));}`:''}

}catch(error){report.error=String(error);}writeFileSync(${JSON.stringify(reportPath)},JSON.stringify(report,null,2));}
let started=false;const timer=setInterval(()=>{if(started||!existsSync(${JSON.stringify(trigger)}))return;started=true;clearInterval(timer);probe();},25);timer.unref();`;
  await writeFile(preload,source);
  const model = await startSyntheticModel(workspace,'TextOnly');
  let buffer='',observation;
  let run;
  try {
    run = await record({ executable, args: ['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--tools','','--plugin-dir',plugin,'--strict-mcp-config','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})], cwd: workspace, output, timeoutMs: 15000,
      env: { HOME: workspace, CLAUDE_CONFIG_DIR: config, PATH: '/usr/bin:/bin', DISABLE_AUTOUPDATER: '1',
        CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1', ANTHROPIC_BASE_URL:model.url, BUN_OPTIONS: '--preload=' + preload },
      input:[JSON.stringify({type:'control_request',request_id:'client-init',request:{subtype:'initialize',hooks:{}}})+'\n'],
      onStdout(bytes,transport){
        buffer+=bytes;
        while(buffer.includes('\n')){
          const at=buffer.indexOf('\n'),line=buffer.slice(0,at);buffer=buffer.slice(at+1);let row;try{row=JSON.parse(line)}catch{continue}
          if(row.type==='control_response'&&row.response.request_id==='client-init'&&!observation){
            writeFileSync(trigger,'ready');
            observation=(async()=>{const deadline=Date.now()+10000;while(!existsSync(reportPath)){if(Date.now()>deadline){transport.stop('client-observation-timeout');return}await new Promise(resolve=>setTimeout(resolve,25))}transport.closeInput()})();
          }
        }
      }
    });
    if(observation)await observation;
    assert.equal(model.calls.length,0);
  } finally { await model.close(); }
  const report=JSON.parse(await readFile(reportPath,'utf8'));
  await copyFile(preload,join(run.directory,'authored-client-preload.mjs'));
  await copyFile(reportPath,join(run.directory,'native-client.json'));
  const evidence={targetSha256,authoredPreloadSha256:hash(Buffer.from(source)),nativeClientRegistry:report.nativeClientRegistry,...(adapter?{authoredAdapterSha256:hash(Buffer.from(adapter))}:{}),importsEmbeddedNativeModules:true,recoveredSourceExecuted:false,modelRequests:model.calls.length,complete:false,qualification:'Original native desktop Client drawing, sandbox registry and authored module instance. No actual app acceptance.'};
  await writeFile(join(run.directory,'integration.json'),JSON.stringify(evidence,null,2)+'\n');
  try {
  assert.equal(run.status,'complete');assert.equal(report.error,undefined);assert.equal(report.nativeClientRegistry,true);
  assert.ok(JSON.stringify(report.drawing.tree).includes('Client'));assert.ok(report.module);assert.equal(report.disposed,true);assert.equal(report.liveTimersBeforeFallbackCleanup,0);assert.equal(report.messageReceipt.data.key,'x');assert.ok(JSON.stringify(report.interactive).includes('process=undefined'));assert.ok(JSON.stringify(report.incremented).includes('changed count=1'));
    if(adapter){for(const key of ['foreignRefused','staleRefused','suspendedRefused','distinctTokens','removedRefused'])assert.equal(report[key],true,key);assert.equal(report.adapterRemaining,0);assert.ok(JSON.stringify(report.adapterFrame).includes('NativeClient reply'));assert.ok(JSON.stringify(report.independentView).includes('NativeClient initial'));}
    evidence.complete=true;
    await writeFile(join(run.directory,'integration.json'),JSON.stringify(evidence,null,2)+'\n');
  } catch(error) {
    evidence.failure=String(error);
    await writeFile(join(run.directory,'integration.json'),JSON.stringify(evidence,null,2)+'\n');
    const manifestPath=join(run.directory,'manifest.json'),manifest=JSON.parse(await readFile(manifestPath,'utf8'));
    await writeFile(manifestPath,JSON.stringify({...manifest,status:'failed',verificationFailure:'native-client-contract'},null,2)+'\n');
    throw error;
  }
  return { ...run, evidence };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  assert.ok(process.argv.length===5||process.argv.length===6, 'Usage: node src/protocol/native-client.mjs <pinned-binary> <private-root> <output> ');
  console.log(JSON.stringify(await probeNativeClient(...process.argv.slice(2).map(value => resolve(value))), null, 2));
}
