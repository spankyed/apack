import {isAbsolute,join} from 'node:path';
/** Read original terminal draft/task rows; never alter native media, dispatch or policy. */
export function nativeAgentMediaBoundaryObserver(workspace){
 if(!isAbsolute(workspace))throw Error('Agent media observation requires an owned absolute workspace');
 return `{
 const {writeFileSync}=await import('node:fs'),{createHash}=await import('node:crypto');
 let observing=false,taskId,previous;const deadline=Date.now()+120000;
 const timer=setInterval(()=>{if(Date.now()>deadline){clearInterval(timer);return}if(observing)return;observing=true;(async()=>{
  const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),binding=runtime.ey();if(binding?.surface!=='terminal'||typeof binding.toolContext!=='function')return;
  const context=binding.toolContext(new AbortController()),selected=context.getAppState().viewingAgentTaskId;
  if(typeof selected==='string')taskId=selected;if(!taskId)return;
  const draft=await binding.composer.read(),task=context.taskRegistry.all()[taskId],messages=context.taskRegistry.getTranscript(taskId)?.messages??await binding.savedAgentMessages(taskId)??[];
  const observed=messages.filter(row=>row.type==='user'&&JSON.stringify(row.message?.content??'').includes('NativeAgentMediaBoundary')).slice(-4).map(row=>({uuid:row.uuid,type:row.type,origin:row.origin,content:typeof row.message?.content==='string'?row.message.content.slice(0,8192):Array.isArray(row.message?.content)?row.message.content.map(block=>block.type==='image'?{type:'image',mediaType:block.source?.media_type,sha256:typeof block.source?.data==='string'?createHash('sha256').update(Buffer.from(block.source.data,'base64')).digest('hex'):null}:block.type==='text'?{type:'text',text:block.text.slice(0,8192)}:{type:block.type}):null}));
  const snapshot={selected,taskId,status:task?.status,draft,observed},serialized=JSON.stringify(snapshot);if(serialized!==previous){previous=serialized;writeFileSync(${JSON.stringify(join(workspace,'native-agent-media-observation.json'))},serialized,{mode:0o600});}
 })().catch(error=>{try{writeFileSync(${JSON.stringify(join(workspace,'native-agent-media-observation-error.json'))},JSON.stringify({message:String(error)}),{mode:0o600})}catch{}}).finally(()=>{observing=false})},100);timer.unref();
}\n`;
}
