import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {recognizeOnboardingPrompt} from './pty-onboarding.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Native legacy channel ingress, with no feature injection or app-support claim. */
export async function probeMcpChannelTerminal(executable,root,output){
 assert.equal(process.platform,'linux');const targetSha256=hash(await readFile(executable));assert.equal(targetSha256,'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 await mkdir(root,{recursive:true});const cwd=await mkdtemp(join(root,'mcp-channel-terminal-')),config=join(cwd,'config'),receipt=join(cwd,'tasks.jsonl');await mkdir(config);
 const server=fileURLToPath(new URL('./owned-mcp-channel-server.mjs',import.meta.url));
 const run=await createRun(output,'mcp-channel-terminal',{targetSha256,driverSha256:hash(await readFile(new URL(import.meta.url))),serverSha256:hash(await readFile(server)),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),platform:process.platform,arch:process.arch,nodeVersion:process.version,ptyBridgeSha256:hash(await readFile(new URL('./pty_bridge.py',import.meta.url))),scope:'Unmodified interactive terminal admission; not app acceptance'});
 const model=await startSyntheticModel(cwd,'mcp__research__echo',{mcpChannelScenario:true,captureMessages:true,maxRequests:6});
 let transport,screen='',theme=false,security=false,navigated=false,trusted=false,exiting=false;
 const timers=[];let checking=false;
 const results=()=>model.calls.flatMap(call=>(call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[])).filter(block=>block.type==='tool_result'&&block.tool_use_id==='toolu_research_fixture');
 const interval=setInterval(async()=>{if(checking||!transport||exiting)return;checking=true;try{if(results().length){exiting=true;timers.push(setTimeout(()=>transport.send('\x04'),500),setTimeout(()=>transport.send('\x04'),1200));}}finally{checking=false;}},100);
 try{
  const probe=await record({executable:'/usr/bin/python3',cwd,output,timeoutMs:35000,maxBytes:1048576,args:[fileURLToPath(new URL('./pty_bridge.py',import.meta.url)),executable,'--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--strict-mcp-config','--mcp-config',JSON.stringify({mcpServers:{research:{type:'stdio',command:process.execPath,args:[server],env:{APACK_MCP_TASK_RECEIPT:receipt}}}}),'--channels','server:research','--debug-file',join(cwd,'native-debug.log'),'--allowed-tools','mcp__research__echo','--','Run the owned channel echo once.'],env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:config,TERM:'xterm-256color',ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},onStdout(bytes,controls){transport=controls;screen+=bytes.toString();const kind=recognizeOnboardingPrompt(screen,cwd);let key;if(kind==='theme'&&!theme){theme=true;key='\r';}else if(kind==='security-notes'&&!security){security=true;key='\r';}else if(kind==='workspace-trust'&&!navigated){navigated=true;key='\x1b[B';}else if(kind==='workspace-trust-selected'&&!trusted){trusted=true;key='\r';}if(key)timers.push(setTimeout(()=>controls.send(key),150));}});
  assert.equal(probe.status,'complete','Original interactive terminal must exit cleanly');
  const frames=(await readFile(receipt,'utf8')).trim().split('\n').map(JSON.parse),incoming=frames.filter(x=>x.direction==='in').map(x=>x.value),calls=incoming.filter(x=>x.method==='tools/call');
  assert.equal(calls.length,1);assert.ok(results().length,'Original correlated result must reach subsequent model context');
  const report={targetSha256,transport:{status:probe.status,code:probe.code},notificationEmitted:frames.some(x=>x.direction==='out'&&x.value.method==='notifications/claude/channel'),notificationSeenByModel:model.calls.some(call=>JSON.stringify(call.messages??[]).includes('OWNED_CHANNEL_NOTIFICATION')),nativeChannelDiagnostics:(await readFile(join(cwd,'native-debug.log'),'utf8')).split('\n').filter(line=>/channel/i.test(line)).slice(-80),results:results(),frames,syntheticModelRequests:model.calls.length,realModelRequests:0,qualification:'Original terminal channel selection and ingress observation only; no development-channel bypass or feature override. Does not establish positive allowed-plugin provenance, permission relay, app exposure or combined F1–F5.'};await writeFile(join(run.directory,'mcp-channel-terminal.json'),JSON.stringify(report,null,2)+'\n');await run.finish({status:'complete'});return {directory:run.directory,...report};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}finally{clearInterval(interval);for(const timer of timers)clearTimeout(timer);try{await writeFile(join(run.directory,'model-calls.json'),JSON.stringify(model.calls,null,2));try{await writeFile(join(run.directory,'server-receipts.jsonl'),await readFile(receipt));}catch(error){if(error.code!=='ENOENT')throw error;}}finally{await model.close();}}
}
