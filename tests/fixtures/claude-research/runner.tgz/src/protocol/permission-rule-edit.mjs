import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Native durable rule edits in disposable user/project/local settings; never execute a tool. */
export async function probePermissionRuleEdit(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'permission-edit-')),cwd=join(workspace,'project'),home=join(workspace,'home');
 await mkdir(join(cwd,'.claude'),{recursive:true});await mkdir(join(home,'.claude'),{recursive:true});execFileSync('/usr/bin/git',['init','-q',cwd]);
 const paths={userSettings:join(home,'.claude','settings.json'),projectSettings:join(cwd,'.claude','settings.json'),localSettings:join(cwd,'.claude','settings.local.json')};
 for(const [source,path] of Object.entries(paths))await writeFile(path,JSON.stringify({language:`research-${source}`,...source==='localSettings'?{permissions:{ask:['Glob']}}:{}}));
 const env={PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
 const edits=[
  {op:'add',rules:['Read(./fixture.txt)'],behavior:'allow',destination:'userSettings'},
  {op:'add',rules:['Read(./fixture.txt)'],behavior:'allow',destination:'userSettings'},
  {op:'add',rules:['Bash(*)'],behavior:'deny',destination:'projectSettings'},
  {op:'add',rules:['Edit(./notes.md)'],behavior:'ask',destination:'localSettings'},
  {op:'add',rules:['Read'],behavior:'allow',destination:'policySettings'},
  {op:'remove',rule:'Read(./fixture.txt)',behavior:'allow',source:'userSettings'},
  {op:'remove',rule:'Read(./missing.txt)',behavior:'allow',source:'userSettings'},
  {op:'remove',rule:'Bash(*)',behavior:'deny',source:'projectSettings'},
  {op:'remove',rule:'Bash',behavior:'deny',source:'projectSettings'},
  {op:'remove',rule:'Edit(./notes.md)',behavior:'ask',source:'localSettings'},
  {op:'add',rules:['Read(./disabled-source.txt)'],behavior:'allow',destination:'projectSettings'},
 ];
 const run=await createRun(output,'permission-rule-edit',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),edits});const cases=[];
 const snapshot=async()=>Object.fromEntries(await Promise.all(Object.entries(paths).map(async([source,path])=>[source,await readFile(path,'utf8')])));
 const readRules=async()=>{
  let pending='',reply;const line=(id,request)=>JSON.stringify({type:'control_request',request_id:id,request})+'\n';
  const transport=await record({executable,cwd,output,timeoutMs:10000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user,project,local','--strict-mcp-config','--no-session-persistence'],env,input:[line('init',{subtype:'initialize',hooks:{}})],onStdout(bytes,channel){
   pending+=bytes.toString('utf8');while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type!=='control_response')continue;
    if(value.response.request_id==='init'){assert.equal(value.response.subtype,'success');channel.send(line('rules',{subtype:'list_permission_rules'}))}
    else if(value.response.request_id==='rules'){reply=value.response;channel.closeInput()}
   }
  }});assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(reply?.subtype,'success');return reply.response;
 };
 let populatedRules;
 try{
  for(const edit of edits){
   const before=await snapshot();const disabledSourceCase=cases.length===10;const transport=await record({executable,cwd,output,timeoutMs:10000,args:[...disabledSourceCase?['--setting-sources','user']:[],'edit-permission-rules','--json'],input:[JSON.stringify(edit)+'\n'],env});
   const after=await snapshot();const stdout=(await readFile(join(transport.directory,'stdout.bin'),'utf8')).trim(),stderr=(await readFile(join(transport.directory,'stderr.bin'),'utf8')).trim();let response;try{response=JSON.parse(stdout)}catch{response=null}
   if(cases.length===3)populatedRules=await readRules();
   cases.push({edit,settingSources:disabledSourceCase?['user']:undefined,code:transport.code,response,stderr:stderr.split(workspace).join('${WORKSPACE}'),allSettingsUnchanged:JSON.stringify(before)===JSON.stringify(after),settings:Object.fromEntries(Object.entries(after).map(([source,text])=>[source,JSON.parse(text)])),transportRun:transport.directory});
  }
  const finalRules=await readRules();
  const expected=[0,1,0,0,1,0,1,1,0,0,1];for(const [index,item] of cases.entries()){
   assert.equal(item.code,expected[index]);if(item.code===0)assert.equal(item.response?.ok,true);else assert.equal(item.allSettingsUnchanged,true);
   for(const [source,value] of Object.entries(item.settings))assert.equal(value.language,`research-${source}`);
  }
  const tuples=value=>value.state.rules.map(rule=>[rule.behavior,rule.source,rule.rule,rule.editability]);
  assert.deepEqual(tuples(populatedRules),[['allow','userSettings','Read(./fixture.txt)','persistent'],['ask','localSettings','Glob','persistent'],['ask','localSettings','Edit(./notes.md)','persistent'],['deny','projectSettings','Bash','persistent']]);
  assert.deepEqual(tuples(finalRules),[['ask','localSettings','Glob','persistent']]);
  assert.match(cases[10].stderr,/not loaded here/);
  assert.match(cases[1].stderr,/already in the allow rules/);assert.match(cases[4].stderr,/destination must be one of/);
  for(const index of [6,7])assert.match(cases[index].stderr,/rule not found.*exact value/);
  assert.deepEqual(cases[0].response.stored,['Read(./fixture.txt)']);assert.deepEqual(cases[2].response.stored,['Bash']);assert.ok(cases[2].response.warnings.length>0);
  assert.deepEqual(cases.at(-1).settings.localSettings.permissions.ask,['Glob']);
  assert.ok(!cases.at(-1).settings.userSettings.permissions.allow.includes('Read(./fixture.txt)'));assert.ok(!cases.at(-1).settings.projectSettings.permissions.deny.includes('Bash'));
  const normalize=value=>JSON.parse(JSON.stringify(value).split(workspace).join('${WORKSPACE}'));
  const result={cases,populatedRules:normalize(populatedRules),finalRules:normalize(finalRules),modelPrompts:0,toolExecutions:0,qualification:'Native persistence, normalization and rejection only; actual permission enforcement, live session refresh, policy/account gates, alias collisions and races require separate evidence.'};
  await writeFile(join(run.directory,'permission-rule-edit.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete',cases:cases.length});return{directory:run.directory,status:'complete',cases:cases.length,modelPrompts:0,toolExecutions:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
