import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Validate retained original read replies against process and backend delivery journals. */
export async function verifyPromptProcessReplacement(workspace){
 const json=async name=>JSON.parse(await readFile(join(workspace,name),'utf8'));
 const lines=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const evidence=await json('native-terminal-app-evidence.json'),reply=evidence.retiredPromptReply;
 assert.equal(reply.backendDelivered,true);assert.equal(reply.freshReadVerified,true);
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl');
 assert.equal(children.length,5);
 const old=children[1],fresh=children[3];
 assert.equal(old.pid,evidence.boundNativePid);assert.equal(fresh.pid,evidence.reopenedNativePid);assert.notEqual(old.pid,fresh.pid);
 const oldExit=exits.find(row=>row.pid===old.pid);assert.ok(oldExit.at<=fresh.at);
 const events=await lines('app-data/apack/logs/app-events.log');
 const delivered=events.filter(row=>row.meta?.from&&row.meta?.event?.type==='CLAUDE_PROMPT_HOST_RESPONSE'&&row.meta.event.kind==='read'&&row.meta.event.requestId===reply.requestId&&row.meta.event.mountId===reply.mountId&&row.meta.event.threadId===reply.threadId);
 assert.equal(delivered.length,1);assert.deepEqual(delivered[0].meta.event.box,reply.box);
 assert.ok(Date.parse(delivered[0].timestamp)>=fresh.at,'Old addressed reply must reach backend after replacement native starts');
 const reads=await json('native-resume-draft-receipts.json'),freshRead=evidence.resumedDraftRead;
 assert.deepEqual(reads.at(-1),freshRead);
 assert.equal(freshRead.result.text,'Continue after importing the saved native conversation.');
 assert.equal(freshRead.result.cursor,freshRead.result.text.length);
 assert.ok(!evidence.shutdownReads.some(row=>row.requestId===freshRead.requestId));
 assert.equal(evidence.finalSessionId,evidence.sessionId);assert.equal(evidence.resumedPrintSameSession,true);assert.deepEqual(evidence.browserErrors,[]);
 for(const child of children)assert.ok(exits.some(row=>row.pid===child.pid));
 return {addressedRetiredReadDeliveries:1,oldNativePid:old.pid,newNativePid:fresh.pid,freshReadExact:true,ownedNativeExits:5,sameSessionRecovery:true};
}
