/** Read-only producer discovery in the pinned live terminal tree; diagnostic evidence only. */
export function nativeToolSites(outputPath) {
 return `
const toolSitesFs=await import('node:fs'),toolSitesCrypto=await import('node:crypto');
if(toolSitesCrypto.createHash('sha256').update(toolSitesFs.readFileSync(process.execPath)).digest('hex')==='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37'){
 const samples=[];let previous,busy=false;const deadline=Date.now()+100000;
 const timer=setInterval(async()=>{if(busy)return;if(Date.now()>deadline){clearInterval(timer);return;}busy=true;try{
  const roots=await import('/$bunfs/root/chunk-pg10s5g1.js'),rendering=await import('/$bunfs/root/chunk-r2k35jby.js'),background=await import('/$bunfs/root/chunk-6f1afc3k.js'),runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),transcripts=await import('/$bunfs/root/chunk-tnpfcesk.js');
  const binding=runtime.ey();if(binding?.surface!=='terminal')return;
  const state=binding.toolContext(new AbortController()).getAppState(),live=state.transcripts[transcripts.vws(undefined)]??transcripts.wOt;
  const root=roots.ai().get(process.stdout)?.container?.current,pending=root?[root]:[],seen=new Set(),groups=[],hints=[];
  while(pending.length){const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('Tool site traversal bound');seen.add(fiber);
   const props=fiber.memoizedProps;
   if((fiber.type===rendering.h3||fiber.elementType===rendering.h3||fiber.type===rendering.h3.type)&&props?.message?.type==='collapsed_read_search'){
    const m=props.message;groups.push({uuid:m.uuid,type:m.type,active:props.isActiveCollapsedGroup===true,expanded:props.verbose===true||props.isTranscriptMode===true,messages:m.messages.map(row=>({uuid:row.uuid,type:row.type,toolIds:row.type==='assistant'?row.message.content.filter(block=>block.type==='tool_use').map(block=>block.id):row.type==='grouped_tool_use'?row.messages.flatMap(message=>message.message.content.filter(block=>block.type==='tool_use').map(block=>block.id)):[]}))});
   }
   if(fiber.type===background.ntr){const child=fiber.child?.memoizedProps;hints.push({toolUseId:props?.toolUseId,keyOnly:props?.keyOnly===true,child:child&&{toolUseId:child.toolUseId,hint:child.hint}});}
   if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);
  }
  const value={groups,hints,running:[...live.inProgressToolUseIDs],selectedAgent:state.viewingAgentTaskId??null},key=JSON.stringify(value);
  if(previous!==key&&samples.length<64){previous=key;samples.push(value);toolSitesFs.writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({samples,readOnly:true,maximumFibers:4096},null,2),{mode:0o600});}
 }catch(error){if(samples.length<64)toolSitesFs.writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({samples,error:String(error)}),{mode:0o600});}finally{busy=false}},100);timer.unref();
}
`;
}
