import { isAbsolute } from 'node:path';
/** Observe original terminal-owned handback state without changing its registry or delivery. */
export function nativeHandbackStateFixture(directory) {
 if(!isAbsolute(directory))throw Error('Handback observer needs a private absolute directory');
 return `{
 const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),fs=await import('node:fs'),path=await import('node:path');
 const deadline=Date.now()+100000;let previous='';
 const timer=setInterval(()=>{if(Date.now()>deadline){clearInterval(timer);return}try{
  const binding=runtime.ey();if(binding?.surface!=='terminal')return;
  const tasks=Object.values(binding.toolContext(new AbortController()).taskRegistry.all()).filter(task=>task.type==='local_agent').slice(0,16).map(task=>({registryId:task.id,id:runtime.flt(task)?.id,status:task.status,handbackReport:task.handbackReport}));
  const encoded=JSON.stringify({tasks});if(encoded!==previous&&encoded.length<=1048576){previous=encoded;fs.writeFileSync(path.join(${JSON.stringify(directory)},'native-handback-state.json'),encoded,{mode:0o600});}
 }catch{}},50);timer.unref();
}\n`;
}
