import assert from 'node:assert/strict';
import {createServer,request} from 'node:http';
import {writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {startSyntheticModel} from './synthetic-model.mjs';
import {startSyntheticAgentModel} from './synthetic-agent-model.mjs';

/** Reuse the accepted seed/Agent providers behind one bounded, loopback-only app endpoint. */
export async function startCombinedEverydayModel({workspace,project,maxRequests,agentReadingProbe=false}) {
 assert.equal(process.platform,'linux');assert.ok(Number.isInteger(maxRequests)&&maxRequests>=16&&maxRequests<=32);
 assert.match(workspace,/^\/work\/\.claude-research\/(?:combined-everyday-app[0-9]+|apack-terminal-owner-app-everyday[0-9]+)$/);
 const referenceFile=join(workspace,'release-checklist.md');
 await writeFile(referenceFile,'# Release checklist\n\n- Describe behavior changes.\n- Keep migration guidance.\n- Confirm interruption recovery.\n');
 const seed=await startSyntheticModel(workspace,'TextOnly',{captureMessages:true,maxRequests:4,textReply:'Ready to review the release notes. Your session is saved.'});
 let decision,releaseDecision,decisionSequence=0;
 const beforeDecision=tool=>{assert.ok(['Read','AskUserQuestion'].includes(tool)&&!releaseDecision);decision={tool,sequence:++decisionSequence,held:true};return new Promise(resolve=>{releaseDecision=resolve})};
 let agent;
 try{agent=await startSyntheticAgentModel({beforeDecision,referenceFile,questionProbe:true,everydayProbe:true,parentLaunchOnce:true,...(agentReadingProbe?{everydayAgentReport:'The release notes cover behavior changes and migration guidance.\n\n'+Array.from({length:28},(_,i)=>`${i+1}. Check the documented behavior and migration guidance before publishing.`).join('\n\n')} : {}),captureMessages:true,requestLimit:Math.min(maxRequests,16),childDelayMs:7500,onPauseRequest:async()=>{}})}catch(error){await seed.close();throw error}
 const calls=[],pending=new Set();let seeded=false,closed=false;
 const server=createServer(async(req,res)=>{
  try{
   const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>4*1024*1024)throw Error('Owned request body limit exceeded');chunks.push(chunk)}
   const raw=Buffer.concat(chunks),body=JSON.parse(raw.toString()),path=req.url??'/';
   if(!path.startsWith('/v1/messages')){res.writeHead(404);res.end('{}');return}
   if(calls.length>=maxRequests){res.writeHead(429);res.end('{}');return}
   const messageCall=path.split('?')[0]==='/v1/messages',route=!seeded?'seed':'agent';
   if(messageCall)seeded=true;
   calls.push({path,route,model:body.model,messages:body.messages});
   const target=new URL(path,route==='seed'?seed.url:agent.url);
   const upstream=request(target,{method:'POST',headers:{'content-type':'application/json'}},response=>{res.writeHead(response.statusCode??502,response.headers);response.pipe(res)});
   pending.add(upstream);upstream.once('close',()=>pending.delete(upstream));upstream.once('error',()=>{if(!res.headersSent)res.writeHead(502);res.end('{}')});
   res.once('close',()=>upstream.destroy());upstream.end(raw);
  }catch{if(!res.headersSent)res.writeHead(400);res.end('{}')}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 return {url:`http://127.0.0.1:${server.address().port}`,calls,agentCalls:agent.calls,seedCalls:seed.calls,referenceFile,get decision(){return decision},releaseDecision(tool){assert.equal(decision?.tool,tool);assert.ok(releaseDecision);const done=releaseDecision;releaseDecision=undefined;decision={...decision,held:false};done()},async close(){if(closed)return;closed=true;releaseDecision?.();releaseDecision=undefined;for(const item of pending)item.destroy();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await Promise.all([seed.close(),agent.close()])}};
}
