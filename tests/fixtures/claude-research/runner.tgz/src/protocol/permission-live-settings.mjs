import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Observe a retained native catalog immediately after durable writer add/remove. No model input. */
export async function probePermissionLiveSettings(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'permission-live-')),cwd=join(workspace,'project'),home=join(workspace,'home'),config=join(home,'.claude');await mkdir(cwd,{recursive:true});await mkdir(config,{recursive:true});
 const settings=join(config,'settings.json');await writeFile(settings,JSON.stringify({language:'research-preserve'}));const env={PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
 const run=await createRun(output,'permission-live-settings',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url)))});
 try{
  let pending='';const replies=[],edits=[];
  const requests=[{subtype:'initialize',hooks:{}},{subtype:'list_permission_rules'},{subtype:'get_settings'},{subtype:'list_permission_rules'},{subtype:'get_settings'},{subtype:'list_permission_rules'},{subtype:'get_settings'}];const line=i=>JSON.stringify({type:'control_request',request_id:`permission-live-${i}`,request:requests[i]})+'\n';
  const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user,project,local','--strict-mcp-config','--no-session-persistence'],env,input:[line(0)],onStdout(bytes,channel){pending+=bytes.toString();while(pending.includes('\n')){
   const i=pending.indexOf('\n'),text=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(text)}catch{continue}if(value.type!=='control_response'||value.response?.request_id!==`permission-live-${replies.length}`)continue;replies.push(value.response);
   if([3,5].includes(replies.length)){
    const edit=replies.length===3?{op:'add',rules:['Bash'],behavior:'deny',destination:'userSettings'}:{op:'remove',rule:'Bash',behavior:'deny',source:'userSettings'};
    const stdout=execFileSync(executable,['edit-permission-rules','--json'],{cwd,env,input:JSON.stringify(edit)+'\n',timeout:5000,maxBuffer:65536});const response=JSON.parse(stdout.toString());assert.equal(response.ok,true);
    const saved=JSON.parse(readFileSync(settings,'utf8'));assert.equal(saved.language,'research-preserve');edits.push({edit,response,settings:saved});
   }
   if(replies.length<requests.length)channel.send(line(replies.length));else channel.closeInput();
  }}});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(replies.length,7);for(const reply of replies)assert.equal(reply.subtype,'success');
  assert.ok(edits[0].settings.permissions.deny.includes('Bash'));assert.ok(!edits[1].settings.permissions.deny.includes('Bash'));
  const catalogPresence=[1,3,5].map(index=>replies[index].response.state.rules.some(rule=>rule.behavior==='deny'&&rule.source==='userSettings'&&rule.rule==='Bash'));
  const effectivePresence=[2,4,6].map(index=>replies[index].response.effective.permissions?.deny?.includes('Bash')??false);
  assert.deepEqual(catalogPresence,[false,false,false]);
  assert.deepEqual(effectivePresence,[false,true,false]);
  const normalized=JSON.parse(JSON.stringify(replies.slice(1)).split(workspace).join('${WORKSPACE}'));
  const result={catalogPresence,effectivePresence,edits,replies:normalized,modelPrompts:0,qualification:'Immediate no-prompt catalog/settings reads after external user edits. Not model-turn enforcement, watcher latency bounds, other sources/modes or app editor behavior.'};await writeFile(join(run.directory,'permission-live-settings.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',catalogPresence,effectivePresence,modelPrompts:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
