import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, realpath, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { recognizeOnboardingPrompt } from './pty-onboarding.mjs';
import { hash } from '../artifacts/runs.mjs';
import { record } from './record.mjs';
import { startSyntheticAgentModel } from './synthetic-agent-model.mjs';

const [binary, parent, output, mode = 'print'] = process.argv.slice(2);
assert.ok(binary && parent && output, 'Usage: node src/protocol/native-agent-question-availability.mjs <pinned Darwin binary> <private parent> <output> [print|interactive]');
assert.ok(['print','interactive'].includes(mode));
const interactive=mode==='interactive';
assert.equal(process.platform, 'darwin');
const executable = resolve(binary), targetSha256 = hash(await readFile(executable));
assert.equal(targetSha256, '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');
await mkdir(parent, { recursive: true });
const workspace = await mkdtemp(join(await realpath(parent), 'agent-question-tools-'));
const model = await startSyntheticAgentModel({ parentLaunchOnce: true, requestLimit: 8 });
const agentTools = ['Read', 'AskUserQuestion'];
const agents = { 'status-fixture': {
  description: 'Disposable tool inventory worker',
  prompt: 'NativeStatusChildSystem. Return a release review marker.',
  tools: agentTools,
  maxTurns: 2,
} };
const line = row => JSON.stringify(row) + '\n';
let pending = '';
const results = [], taskNotifications = [];
const cliArgs = ['--setting-sources', '', '--strict-mcp-config', '--tools', ['Agent', ...agentTools].join(','),
  '--allowedTools', 'Agent', '--agents', JSON.stringify(agents), '--settings',
  JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' })];
const env = { PATH: '/usr/bin:/bin', HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'),
  ANTHROPIC_BASE_URL: model.url, DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' };
const prompt = 'Review the release notes with the disposable worker.';
const base = { cwd: workspace, output: resolve(output), timeoutMs: 25000, env };
try {
  const run = interactive ? await runInteractive() : await record({
    ...base, executable,
    args: ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json',
      '--permission-prompt-tool', 'stdio', ...cliArgs],
    input: [line({ type: 'control_request', request_id: 'initialize', request: { subtype: 'initialize', hooks: {} } })],
    onStdout(bytes, transport) {
      pending += bytes.toString();
      while (pending.includes('\n')) {
        const end = pending.indexOf('\n'), row = JSON.parse(pending.slice(0, end));
        pending = pending.slice(end + 1);
        if (row.type === 'control_response' && row.response?.request_id === 'initialize' && row.response.subtype === 'success') {
          transport.send(line({ type: 'user', uuid: '22222222-2222-4222-8222-222222222222', parent_tool_use_id: null,
            message: { role: 'user', content: prompt } }));
        }
        if (row.type === 'result') {
          results.push({ subtype: row.subtype, isError: row.is_error, sessionId: row.session_id });
          if (row.is_error) transport.closeInput();
        }
        if (row.type === 'system' && row.subtype === 'task_notification') {
          taskNotifications.push({ status: row.status, taskId: row.task_id });
          transport.closeInput();
        }
      }
    },
  });
  const parentCalls = model.calls.filter(call => !call.child);
  const childCalls = model.calls.filter(call => call.child);
  const evidence = { mode, targetSha256, driverSha256: hash(await readFile(new URL(import.meta.url))), agentTools,
    parentOffered: parentCalls.map(call => call.toolNames), agentOffered: childCalls.map(call => call.toolNames),
    results, taskNotifications, process: run.status, syntheticRequests: model.calls.length, realModelRequests: 0 };
  await writeFile(join(run.directory, 'agent-question-tools.json'), JSON.stringify(evidence, null, 2) + '\n');
  try {
    assert.equal(run.status, 'complete');
    assert.ok(parentCalls.some(call => call.toolNames?.includes('AskUserQuestion')));
    assert.ok(childCalls.some(call => call.toolNames?.includes('Read')));
    if (interactive) assert.ok(parentCalls.some(call => call.hasAgentResult && !call.agentResultError && call.delivered));
    else assert.ok(taskNotifications.some(row => row.status === 'completed'));
  } catch (error) {
    const manifest = join(run.directory, 'manifest.json'), metadata = JSON.parse(await readFile(manifest, 'utf8'));
    await writeFile(manifest, JSON.stringify({ ...metadata, status: 'failed', verificationFailure: error.message }, null, 2) + '\n');
    throw error;
  }
  console.log(JSON.stringify({ directory: run.directory, ...evidence }));
} finally {
  await model.close();
}


async function runInteractive() {
  const bridge = fileURLToPath(new URL('./pty_bridge.py', import.meta.url));
  let terminal = '', theme = false, security = false, navigated = false, trusted = false, drafted = false, submitted = false, exits = 0;
  const timers = [];
  try {
    return await record({
      ...base, executable: '/usr/bin/python3', args: [bridge, executable, ...cliArgs, '--permission-mode', 'acceptEdits'],
      env: { ...env, TERM: 'xterm-256color', COLUMNS: '100', LINES: '30' },
      onStdout(bytes, transport) {
        terminal += bytes.toString('utf8');
        const screen = recognizeOnboardingPrompt(terminal, workspace);
        const compact = terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '').replace(/\s/g, '');
        let input;
        if (screen === 'theme' && !theme) { theme = true; input = '\r'; }
        else if (screen === 'security-notes' && theme && !security) { security = true; input = '\r'; }
        else if (screen === 'workspace-trust' && !navigated) { navigated = true; input = '\x1b[B'; }
        else if (screen === 'workspace-trust-selected' && navigated && !trusted) { trusted = true; input = '\r'; }
        else if (trusted && !drafted && compact.includes('APIUsageBilling') && compact.includes('shift+tabtocycle')) {
          drafted = true;
          input = prompt;
        } else if (drafted && !submitted && compact.includes(prompt.replace(/\s/g, ''))) {
          submitted = true;
          input = '\r';
        } else if (submitted && exits === 0 && model.calls.some(call => call.hasAgentResult && call.delivered) && compact.includes('ParentSubagentFixtureComplete') && compact.includes('Agent"Disposablestatusfixture"finished')) {
          exits++;
          input = '\x04';
        } else if (exits === 1 && /pressctrl[+-]dagaintoexit/i.test(compact)) {
          exits++;
          input = '\x04';
        }
        if (input !== undefined) timers.push(setTimeout(() => transport.send(input), 150));
      },
    });
  } finally {
    for (const timer of timers) clearTimeout(timer);
  }
}
