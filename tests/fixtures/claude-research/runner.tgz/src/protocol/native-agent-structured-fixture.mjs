import assert from 'node:assert/strict';

export const agentStructuredSteps = [
  { label: 'Use review outline', mode: 'replace', text: '# Worker release review\n\n```ts\nconst ready = true\n```\n\nReview changes.', paint: 'Review changes.' },
  { label: 'Add release checklist', mode: 'append', text: '\n\n* Verify behavior\n* Document migration', paint: 'Verify behavior' },
  { label: 'Add review note', mode: 'insert', text: 'Please ', paint: 'Please' },
];

/** An owned native extension uses the original view-scoped reverse prompt APIs. */
export function nativeAgentStructuredHook() {
  return `export function register(on) {
    let phase=0;const receipts=[],reads=[],edits=[],steps=${JSON.stringify(agentStructuredSteps)};
    on('prompt.edit',async($,e,next)=>{const result=await next(e);edits.push({text:result.text,cursor:result.cursor,origin:e.origin,inputText:e.inputText});await $.fs.write('native-agent-structured-edits.json',JSON.stringify(edits.slice(-128)));return result;});
    on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
      if(e.surface!=='desktop')return next(e);
      const {Box,Button}=$.ui.resolve(e),step=e.props.view?.agentId?steps[phase]:undefined;
      return Box({children:[...(step?[Button({key:'prepare-agent-review',label:step.label,onPress:async()=>{
        const before=await $.prompt.read(),at=step.text.indexOf(step.paint),input={mode:step.mode,text:step.text,decorations:[{start:at,end:at+step.paint.length,bold:true,color:'warning'}]},result=await $.prompt.fill(input),after=await $.prompt.read();
        receipts.push({view:e.props.view,input,before,result,after});await $.fs.write('native-agent-structured-receipts.json',JSON.stringify(receipts));if(result.isFilled){phase++;$.ui.invalidate('ui.render');}
      }})]:[]),Button({key:'read-agent-review',label:'Read review draft',onPress:async()=>{reads.push({view:e.props.view,value:await $.prompt.read()});await $.fs.write('native-agent-structured-reads.json',JSON.stringify(reads));}})]});
    });
  }`;
}

export function verifyAgentStructuredProof(proof, modelCalls) {
  assert.equal(proof.receipts.length,3);
  assert.deepEqual(proof.receipts.map(row=>row.input.mode),['replace','append','insert']);
  for(const row of proof.receipts){assert.equal(row.view.agentId,proof.taskId);assert.equal(row.result.isFilled,true);assert.ok(row.after.text.includes('const ready = true'));}
  const inserted=proof.receipts[2];assert.equal(inserted.before.cursor,inserted.before.text.indexOf('Review changes.'));
  assert.equal(inserted.after.text,inserted.before.text.slice(0,inserted.before.cursor)+'Please '+inserted.before.text.slice(inserted.before.cursor));
  assert.deepEqual(proof.finalNative.value,{text:proof.finalCanonical,cursor:inserted.after.cursor});assert.equal(proof.finalNative.view.agentId,proof.taskId);
  assert.equal(proof.parentNative.value.text,proof.parentDraft);assert.equal(proof.parentNative.view?.agentId,undefined);
  assert.ok(proof.finalCanonical.includes('Please Review changes.'));assert.ok(!proof.finalCanonical.includes('**Please**'));
  assert.ok(proof.nativeUuid);assert.equal(proof.nativeHumanMatches,1);assert.equal(proof.noPhantomTurn,true);
  const text=call=>(call.messages??[]).flatMap(message=>typeof message.content==='string'?[message.content]:(message.content??[]).filter(block=>block.type==='text').map(block=>block.text)).join('\n');assert.ok(modelCalls.some(call=>call.child&&text(call).includes(proof.finalCanonical)),'Canonical review did not reach its original worker request');
  return {threeNativeFillModes:true,agentOwned:true,parentIndependent:true,decorationIsPresentation:true,originalHumanUuid:proof.nativeUuid};
}
