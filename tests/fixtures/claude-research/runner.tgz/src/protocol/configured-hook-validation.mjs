import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Observe file-loader acceptance separately from internal runtime hook type names. No model input. */
export async function probeConfiguredHookValidation(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'hook-validation-'));
 const run=await createRun(output,'configured-hook-validation',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url)))});const cases=[];
 try{
  for(const event of ['SessionStart','PreToolUse']){
   const cwd=join(workspace,event),home=join(cwd,'home');await mkdir(join(home,'.claude'),{recursive:true});execFileSync('/usr/bin/git',['init','-q',cwd]);
   await writeFile(join(home,'.claude','settings.json'),JSON.stringify({language:'research-hook-validation',permissions:{allow:['Read']},hooks:{[event]:[{hooks:[{type:'script',script:'return {}'}]}]}}));
   let buffered='',reply;
   const line=(id,request)=>JSON.stringify({type:'control_request',request_id:id,request})+'\n';
   const transport=await record({executable,cwd,output,timeoutMs:12000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user','--strict-mcp-config','--tools','','--no-session-persistence'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[line('init',{subtype:'initialize',hooks:{}})],onStdout(bytes,channel){
    buffered+=bytes.toString('utf8');while(buffered.includes('\n')){
     const at=buffered.indexOf('\n'),text=buffered.slice(0,at);buffered=buffered.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
     if(value.type!=='control_response')continue;
     if(value.response.request_id==='init')channel.send(line('settings',{subtype:'get_settings'}));
     else if(value.response.request_id==='settings'){reply=value.response;channel.closeInput()}
    }
   }});
   cases.push({event,type:'script',transportStatus:transport.status,code:transport.code,reply:reply??null,transportRun:transport.directory});
  }
  for(const item of cases){assert.equal(item.transportStatus,'complete');assert.equal(item.code,0);assert.equal(item.reply?.subtype,'success')}
  const ordinary=cases.find(item=>item.event==='SessionStart').reply.response;
  const guarded=cases.find(item=>item.event==='PreToolUse').reply.response;
  assert.equal(ordinary.effective.language,'research-hook-validation');assert.deepEqual(ordinary.effective.hooks.SessionStart[0].hooks,[]);
  assert.notEqual(guarded.effective.language,'research-hook-validation');
  assert.ok(guarded.sources.every(source=>source.source!=='userSettings'||source.settings?.language!=='research-hook-validation'));
  const result={cases,noncriticalHookStripped:true,guardedUserLayerExcluded:true,modelPrompts:0,qualification:'File loader only; script/callback/function internal producers and other feature gates are not established.'};await writeFile(join(run.directory,'hook-validation.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete',cases:cases.length});return{directory:run.directory,status:'complete',...result};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
