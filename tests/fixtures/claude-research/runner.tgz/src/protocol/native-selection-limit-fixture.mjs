import {writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Exercise original selection callbacks without echoing megabytes into a drawing. */
export async function addNativeSelectionLimitFixture(plugin){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){
 const receipts=[];let retired=false;
 on('prompt.submit',async($,e,next)=>{retired=true;await $.ui.invalidate('ui.render');return next(e);});
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
  if(e.surface!=='desktop'||retired)return next(e);
  const {Box,Input,Button}=$.ui.resolve(e);
  return Box({flexDirection:'column',children:[await next(e),Input({key:'selection-notes',label:'Selection review notes',rows:2,value:'Current release notes',onInput:()=>{},onSubmit:()=>{}}),Button({key:'selection-review',label:'Read current selection',onPress:async()=>{const value=await $.ui.selection();const file='native-selection-limit-receipt-'+receipts.length+'.json';await $.fs.write(file,JSON.stringify({selected:value!==undefined,...(value?{value}:{})}));receipts.push(file);await $.fs.write('native-selection-limit-receipts.json',JSON.stringify(receipts));}})]});
 });
}`);
}
