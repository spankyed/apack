import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Preserve original question dispatch; do not render the notice text in a fixture drawing. */
export async function addNativeQuestionToolNoticeFixture(workspace,plugin){
 const path=join(plugin,'hooks/register.ts'),source=await readFile(path,'utf8');
 const anchor=/export function register\(on\)\s*\{/;
 assert.match(source,anchor);
 await writeFile(join(workspace,'native-question-tool-notice-command.json'),JSON.stringify({sequence:0}));
 const hook=`let lastQuestionId;on('prompt.submit',async($,e,next)=>{if(lastQuestionId&&e.text==='Draft the release summary while I review the checklist.'){let accepted=false,error;try{await $.ui.notice(lastQuestionId,'Closed-question notice must not appear.');accepted=true;}catch(cause){error=String(cause);}await $.fs.write('native-question-tool-notice-closed-refusal.json',JSON.stringify({toolUseId:lastQuestionId,accepted,error}));}return next(e);});on('tool.call',{tool:'AskUserQuestion'},async($,e,next)=>{lastQuestionId=e.tool_use_id;const text='Release policy reviewed this question.';let accepted=false,error;try{await $.ui.notice(e.tool_use_id,text);accepted=true;}catch(cause){error=String(cause);}await $.fs.write('native-question-tool-notice-native.json',JSON.stringify({toolUseId:e.tool_use_id,text,accepted,error}));let sequence=0,busy=false,active=true;const tick=$.clock.every(100,()=>{if(busy||!active)return;busy=true;(async()=>{const command=JSON.parse(await $.fs.read('native-question-tool-notice-command.json'));if(!active||command.sequence<=sequence)return;if(command.action==='non-open'){let accepted=false,error;const target='native_missing_notice_call';try{await $.ui.notice(target,'Nonexistent-call notice must not appear.');accepted=true;}catch(cause){error=String(cause);}sequence=command.sequence;await $.fs.write('native-question-tool-notice-command-result.json',JSON.stringify({sequence,action:command.action,toolUseId:target,accepted,error}));return;}if(!['update','clear','restore'].includes(command.action))throw Error('Unknown notice command');const value=command.action==='clear'?undefined:command.action==='restore'?text:'Release policy updated this question.';await $.ui.notice(e.tool_use_id,value);sequence=command.sequence;$.ui.invalidate('ui.render');await $.fs.write('native-question-tool-notice-command-result.json',JSON.stringify({sequence,action:command.action,toolUseId:e.tool_use_id,text:value,accepted:true}));})().catch(async error=>{await $.fs.write('native-question-tool-notice-command-result.json',JSON.stringify({error:String(error)}));}).finally(()=>{busy=false;});});try{return await next(e);}finally{active=false;tick.cancel();}});`;

 await writeFile(path,source.replace(anchor,match=>match+hook));
}
export async function verifyNativeQuestionToolNoticeFixture(workspace){
 const receipt=JSON.parse(await readFile(join(workspace,'native-question-tool-notice-native.json'),'utf8'));
 assert.equal(receipt.accepted,true);assert.ok(receipt.toolUseId);assert.equal(receipt.text,'Release policy reviewed this question.');
 const proof=JSON.parse(await readFile(join(workspace,'native-question-tool-notice-app.json'),'utf8'));
 assert.deepEqual(proof.liveUpdates.map(row=>row.action),['update','clear','restore']);
 for(const row of proof.liveUpdates){assert.equal(row.receipt.accepted,true);assert.equal(row.receipt.toolUseId,receipt.toolUseId);assert.equal(row.answerRetained,true);assert.equal(row.nativePaint,true);assert.deepEqual(row.widths,[1100,680]);}
 assert.equal(proof.missingCallRefusal.accepted,false);assert.match(proof.missingCallRefusal.error,/no call with that tool_use_id is open/);
 assert.equal(proof.closedRefusal.accepted,false);assert.equal(proof.closedRefusal.toolUseId,receipt.toolUseId);assert.match(proof.closedRefusal.error,/no call with that tool_use_id is open/);
 assert.deepEqual(proof.receipt,receipt);assert.equal(proof.nativeScreenIncludesNotice,true);assert.equal(proof.appVisible,true);assert.equal(proof.retired,true);
 const inspection=JSON.parse(await readFile(join(workspace,'native-dialog-shapes.json'),'utf8'));
 assert.ok(inspection.events.flatMap(event=>event.value?.open??[]).some(row=>row.kind==='permission_ask_user_question'&&row.payload?.requestId===receipt.toolUseId));
 return{originalQuestion:true,nativePaint:true,appVisible:true,liveUpdates:true,nonOpenRefusal:true,closedCallRefusal:true,retired:true};
}
