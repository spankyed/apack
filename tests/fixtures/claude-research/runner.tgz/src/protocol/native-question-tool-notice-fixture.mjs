import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Preserve original question dispatch; do not render the notice text in a fixture drawing. */
export async function addNativeQuestionToolNoticeFixture(workspace,plugin){
 const path=join(plugin,'hooks/register.ts'),source=await readFile(path,'utf8');
 const anchor=/export function register\(on\)\s*\{/;
 assert.match(source,anchor);
 const hook=`on('tool.call',{tool:'AskUserQuestion'},async($,e,next)=>{const text='Release policy reviewed this question.';let accepted=false,error;try{await $.ui.notice(e.tool_use_id,text);accepted=true;}catch(cause){error=String(cause);}await $.fs.write('native-question-tool-notice-native.json',JSON.stringify({toolUseId:e.tool_use_id,text,accepted,error}));return next(e);});`;
 await writeFile(path,source.replace(anchor,match=>match+hook));
}
export async function verifyNativeQuestionToolNoticeFixture(workspace){
 const receipt=JSON.parse(await readFile(join(workspace,'native-question-tool-notice-native.json'),'utf8'));
 assert.equal(receipt.accepted,true);assert.ok(receipt.toolUseId);assert.equal(receipt.text,'Release policy reviewed this question.');
 const proof=JSON.parse(await readFile(join(workspace,'native-question-tool-notice-app.json'),'utf8'));
 assert.deepEqual(proof.receipt,receipt);assert.equal(proof.nativeScreenIncludesNotice,true);assert.equal(proof.appVisible,true);assert.equal(proof.retired,true);
 const inspection=JSON.parse(await readFile(join(workspace,'native-dialog-shapes.json'),'utf8'));
 assert.ok(inspection.events.flatMap(event=>event.value?.open??[]).some(row=>row.kind==='permission_ask_user_question'&&row.payload?.requestId===receipt.toolUseId));
 return{originalQuestion:true,nativePaint:true,appVisible:true,retired:true};
}
