import { appendFileSync } from 'node:fs';
import { createInterface } from 'node:readline';
// Disposable stdio-only MCP fixture. Never opens sockets or reads user files.
const input = createInterface({ input: process.stdin });
input.on('line', line => {
  let request;
  try { request = JSON.parse(line); } catch { return; }
  if(process.env.APACK_MCP_RECEIPT)appendFileSync(process.env.APACK_MCP_RECEIPT,JSON.stringify({pid:process.pid,method:request.method,tool:request.params?.name})+'\n');
  if (request.id === undefined) return;
  let result;
  switch (request.method) {
    case 'initialize': result = { protocolVersion: request.params?.protocolVersion ?? '2024-11-05',
      capabilities: { tools: {} }, serverInfo: { name: 'research-fixture', version: '1.0.0' } }; break;
    case 'ping': result = {}; break;
    case 'tools/list': result = { tools: [{ name: 'echo', description: 'Return a disposable synthetic message',
      inputSchema: { type: 'object', properties: { message: { type: 'string' } }, required: ['message'] } }] }; break;
    case 'tools/call':
      if (request.params?.name !== 'echo' || typeof request.params?.arguments?.message !== 'string') break;
      result = { content: [{ type: 'text', text: request.params.arguments.message }] }; break;
  }
  console.log(JSON.stringify({ jsonrpc: '2.0', id: request.id, ...(result === undefined
    ? { error: { code: -32601, message: 'Unsupported synthetic operation' } } : { result }) }));
});
