import assert from 'node:assert/strict';
import {join} from 'node:path';

/** Synthetic wire verdicts consumed by the original classifier, never an injected denial store. */
export function nativeRecentDenialStep(body, workspace) {
  const messages=body.messages??[],blocks=messages.flatMap(m=>Array.isArray(m.content)?m.content:[]);
  const text=messages.filter(m=>m.role==='user').flatMap(m=>typeof m.content==='string'?[m.content]:m.content?.filter(b=>b.type==='text').map(b=>b.text)??[]).join('\n');
  const requested=body.safeguards?.filter(s=>s.type==='dangerous_tool_use')??[];
  assert.ok(requested.length<=1,'Ambiguous original classifier request');
  const result=id=>blocks.some(b=>b.type==='tool_result'&&b.tool_use_id===id);
  const marker=[...text.matchAll(/ResearchRecentDenied(Alpha|Beta)|ResearchAutoReviewed(Gamma)/g)].at(-1);
  const name=marker?.[1]??marker?.[2],autoApproved=name==='Gamma';
  const grant=text.slice(text.lastIndexOf('Permission granted for:'));
  const retry=name==='Beta'&&grant.startsWith('Permission granted for:')&&grant.includes('native-recent-beta.txt');
  const id=retry?'native_recent_retry_beta':autoApproved?'native_auto_reviewed_gamma':name?'native_recent_denied_'+name.toLowerCase():undefined;
  const useTool=!!id&&!result(id);
  if(useTool){
    assert.equal(requested.length,1,'Original Auto mode request did not advertise dangerous_tool_use classification');
    assert.ok(body.tools?.some(t=>t.name==='Bash'),'Original Bash tool was not advertised');
  }
  const leaf=name?.toLowerCase();
  const block=useTool?{type:'tool_use',id,name:'Bash',input:{command:'/usr/bin/printf NATIVE_RECENT_'+leaf.toUpperCase()+" > '"+join(workspace,'native-recent-'+leaf+'.txt').replaceAll("'","'\\''")+"'",description:'Write native-recent-'+leaf+'.txt in the owned review workspace'}}:{type:'text',text:'The local permission decision review is complete.'};
  const safeguardResults=requested.length?[{type:'dangerous_tool_use',status:{type:'available',tool_uses:useTool?{[id]:{type:'evaluated',outcome:retry||autoApproved?'not_flagged':'flagged',explanation:retry?'Explicit original retry permission.':autoApproved?'Owned harmless release-review marker.':'Owned local classifier denial for '+name+' review.'}}:{}}}]:undefined;
  return {useTool,block,safeguardResults,observation:{classifierRequested:requested.length===1,marker:name??null,retry,useTool,toolUseId:id??null}};
}
