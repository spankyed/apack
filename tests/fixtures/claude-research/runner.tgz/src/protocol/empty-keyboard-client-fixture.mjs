import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** Original native Client with keyboard input and deliberately no drawn text or controls. */
export async function addEmptyKeyboardClientFixture(plugin) {
  await writeFile(join(plugin, 'hooks/register.ts'), `
export function register(on) {
  const receipts = [];
  let retired = false;
  on('ui.render', {component:'AbovePrompt'}, async ($, event, next) => {
    if (event.surface !== 'desktop') return next(event);
    const {Box, Client} = $.ui.resolve(event);
    return retired ? Box({children:[]}) : Client({key:'keyboard-only', module:'./empty-keyboard-client.ts', props:{}, width:36, height:2});
  });
  on('ui.message', async ($, event, next) => {
    if (event.data?.emptyKeyboardClient !== true) return next(event);
    if (event.data.key === 'r') retired = true;
    receipts.push({...event.data, surface:event.surface, component:event.component, retired, at:await $.clock.now()});
    await $.fs.write('native-empty-client-events.json', JSON.stringify(receipts));
    if (retired) await $.ui.invalidate('ui.render');
    return {props:{}};
  });
}
`);
  await writeFile(join(plugin, 'hooks/empty-keyboard-client.ts'), `
export default function(_props, surface) {
  if (surface.state === undefined) surface.setState({count:0});
  surface.onKey(event => {
    surface.setState({count:surface.state.count + 1});
    surface.post({emptyKeyboardClient:true, key:event.key, count:surface.state.count});
  });
  return surface.elements.Box({width:36, height:2, children:[]});
}
`);
}
