import { spawn } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createRun, hash } from '../artifacts/runs.mjs';

/** Record raw transport chunks independently of message parsing. No shell or inherited stdin. */
export async function record({ executable, args, cwd, env, output, input = [], timeoutMs = 15000,
  maxBytes = 8 * 1024 * 1024, onStdout }) {
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || !Number.isSafeInteger(maxBytes) || maxBytes < 1) {
    throw new Error('timeoutMs and maxBytes must be positive integers');
  }
  const targetSha256 = hash(await readFile(executable));
  const run = await createRun(output, 'probe', { executable, targetSha256, recorderSha256: hash(await readFile(new URL(import.meta.url))), args, cwd,
    timeoutMs, maxBytes, environmentKeys: Object.keys(env).sort() });
  const events = [];
  const started = process.hrtime.bigint();
  let sequence = 0, total = 0, reason, child, timeout, killTimer;
  const buffers = { stdout: [], stderr: [] };
  function event(kind, fields = {}) {
    events.push({ sequence: sequence++, elapsedNs: String(process.hrtime.bigint() - started), kind, ...fields });
  }
  function stop(why) {
    if (reason) return;
    reason = why;
    event('signal', { signal: 'SIGTERM', reason: why });
    signal('SIGTERM');
    killTimer = setTimeout(() => {
      event('signal', { signal: 'SIGKILL' }); signal('SIGKILL');
      // A detached descendant can retain these pipes after the root exits. Do not let
      // its descriptors prevent a failed probe from saving evidence and returning.
      event('stdio-close-request', { reason: 'cleanup-deadline' });
      child?.stdin.destroy(); child?.stdout.destroy(); child?.stderr.destroy();
    }, 500);
  }
  function signal(name) {
    if (!child?.pid) return;
    try { process.kill(process.platform === 'win32' ? child.pid : -child.pid, name); }
    catch (error) { if (error.code !== 'ESRCH') event('signal-error', { message: error.message }); }
  }
  const send = bytes => {
    const data = Buffer.from(bytes);
    if (total + data.length > maxBytes) { stop('output-limit'); return; }
    total += data.length;
    event('stdin', { base64: data.toString('base64') });
    child.stdin.write(data);
  };
  try {
    const outcome = await new Promise((resolve, reject) => {
      child = spawn(executable, args, { cwd, env, shell: false, detached: process.platform !== 'win32', stdio: 'pipe' });
      child.once('error', reject);
      child.stdin.on('error', error => event('stdin-error', { message: error.message }));
      for (const kind of ['stdout', 'stderr']) child[kind].on('data', bytes => {
        const remaining = maxBytes - total;
        const accepted = bytes.subarray(0, Math.max(0, remaining));
        total += accepted.length;
        if (accepted.length) {
          buffers[kind].push(accepted);
          event(kind, { base64: accepted.toString('base64') });
          if (kind === 'stdout' && onStdout) {
            try { onStdout(accepted, { send, closeInput: () => child.stdin.end(), stop }); }
            catch (error) { event('handler-error', { message: error.message }); stop('handler-error'); }
          }
        }
        if (bytes.length > remaining) stop('output-limit');
      });
      child.once('spawn', () => {
        event('spawn', { pid: child.pid });
        timeout = setTimeout(() => stop('timeout'), timeoutMs);
        for (const bytes of input) send(bytes);
        if (!onStdout) child.stdin.end();
      });
      child.once('exit', (code, signal) => event('process-exit', { code, signal }));
      child.once('close', (code, signal) => { event('exit', { code, signal }); resolve({ code, signal }); });
    });
    const status = reason || outcome.code !== 0 ? 'failed' : 'complete';
    await run.finish({ status, ...outcome, reason, byteCount: total });
    return { directory: run.directory, status, ...outcome, reason };
  } catch (error) {
    await run.finish({ status: 'failed', error: error.message });
    throw error;
  } finally {
    clearTimeout(timeout); clearTimeout(killTimer);
    // Terminate remaining process-group members. The caller isolation boundary owns
    // detached descendants; closing their inherited pipes does not prove they exited.
    signal('SIGKILL');
    for (const kind of ['stdout', 'stderr']) await writeFile(join(run.directory, `${kind}.bin`), Buffer.concat(buffers[kind]));
    await writeFile(join(run.directory, 'events.jsonl'), events.map(e => JSON.stringify(e)).join('\n') + '\n');
  }
}
