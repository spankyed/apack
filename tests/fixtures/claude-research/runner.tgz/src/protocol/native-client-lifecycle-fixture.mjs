import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** Native module environments own acquisition, held replies and failures throughout this fixture. */
export async function addNativeClientLifecycleFixture(plugin, workspace) {
  await writeFile(join(workspace, 'native-client-mode.txt'), 'a');
  const path = join(plugin, 'hooks/register.ts');
  const support = `const receipts=[];let writes=Promise.resolve();function record($,value){receipts.push(value);const text=JSON.stringify(receipts);writes=writes.then(()=>$.fs.write('native-client-lifecycle-receipts.json',text));return writes;}`;
  const hook = `let mode='a';
    on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
      if(e.surface!=='desktop')return next(e);
      const {Box,Client}= $.ui.resolve(e);
      const body=mode==='a'?Client({key:'extension',module:'./extension-a.ts',props:{name:'Extension A'},width:'100%',height:3}):mode==='b'?Client({key:'extension',module:'./extension-b.ts',props:{name:'Extension B'},width:'100%',height:3}):mode==='failure'?Client({key:'extension',module:'./extension-failure.ts',width:'100%',height:3}):mode==='load-failure'?Client({key:'extension',module:'./extension-load-failure.ts',width:'100%',height:3}):undefined;
      return Box({flexDirection:'column',children:[await next(e),Client({key:'controller',module:'./extension-controller.ts',height:1}),...(body?[body]:[])]});
    });
    on('ui.message',async($,e,next)=>{
      if(e.data?.clientLifecycle!==true)return next(e);
      if(e.data.operation==='pulse'){
        const requested=(await $.fs.read('native-client-mode.txt')).trim();
        if(requested!==mode){mode=requested;await record($,{operation:'mode',mode,at:Date.now(),surface:e.surface,component:e.component});$.ui.invalidate('ui.render');}
        return;
      }
      await record($,{...e.data,at:Date.now(),surface:e.surface,component:e.component,element:e.element});
      if(e.data.operation==='held-start'){
        await $.clock.sleep(2000);
        await record($,{operation:'held-finished',at:Date.now(),surface:e.surface,component:e.component});
        return {props:{name:'Retired extension reply'}};
      }
    });`;
  const source=await readFile(path,'utf8');
  if(!source.includes('export function register(on){'))throw Error('Native hook entry not found');
  // This opt-in private profile owns its hook entry; forwarding keeps the second plugin eligible.
  await writeFile(path,support+'export function register(on){'+hook+'}');
  await writeFile(join(plugin,'hooks/extension-controller.ts'),`export default function(props,s){const {Text}=s.elements;if(s.state===undefined){s.setState({ready:true});s.every(100,()=>s.post({clientLifecycle:true,operation:'pulse'}));}return Text({children:['Workspace extension status']});}`);
  for(const name of ['a','b']) await writeFile(join(plugin,'hooks/extension-'+name+'.ts'),`export default function(props,s){const {Box,Text,Button}=s.elements;if(s.state===undefined)s.setState({count:0});return Box({flexDirection:'column',children:[Text({children:[props.name+' count='+s.state.count]}),Button({key:'extension-action',label:${JSON.stringify(name==='a'?'Refresh workspace extension':'Apply workspace extension')},onPress:()=>{s.setState({count:s.state.count+1});s.post({clientLifecycle:true,operation:${JSON.stringify(name==='a'?'held-start':'applied')},name:props.name,count:s.state.count});}})]});}`);
  await writeFile(join(plugin,'hooks/extension-failure.ts'),`export default function(){throw Error('Intentional workspace extension failure');}`);
  await writeFile(join(plugin,'hooks/extension-load-failure.ts'),`throw Error('Intentional workspace module load failure');export default function(props,s){return s.elements.Text({children:['Must never mount failed module']});}`);

  // A separate plugin keeps its genuine environment acquisition cold until the app selects it.
  const pending=join(workspace,'pending-client-fixture');
  await mkdir(join(pending,'.claude-plugin'),{recursive:true});await mkdir(join(pending,'hooks'));
  await writeFile(join(pending,'.claude-plugin/plugin.json'),JSON.stringify({name:'pending-client-fixture',version:'0.0.1'}));
  await writeFile(join(pending,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
  await writeFile(join(pending,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const base=await next(e);if(e.surface!=='desktop'||(await $.fs.read('native-client-mode.txt')).trim()!=='pending')return base;const {Box,Client}=$.ui.resolve(e);return Box({flexDirection:'column',children:[base,Client({key:'pending-extension',module:'./pending-extension.ts',width:'100%',height:3})]});});on('ui.message',async($,e,next)=>{if(e.data?.pendingExtension!==true)return next(e);await $.fs.write('native-client-pending-action.json',JSON.stringify({...e.data,surface:e.surface,component:e.component}));});}`);
  await writeFile(join(pending,'hooks/pending-extension.ts'),`console.log('ResearchPendingEnvironmentEvaluated');export default function(props,s){console.log('ResearchPendingClientMounted');const {Box,Text,Button}=s.elements;if(s.state===undefined)s.setState({count:0});return Box({flexDirection:'column',children:[Text({children:['Loaded workspace extension count='+s.state.count]}),Button({key:'loaded-action',label:'Use loaded workspace extension',onPress:()=>{s.setState({count:s.state.count+1});s.post({pendingExtension:true,count:s.state.count});}})]});}`);
  return pending;
}
