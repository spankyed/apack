import {appendFileSync} from 'node:fs';
import {createInterface} from 'node:readline';
import {resourceText,resourceBlob,resourceUris} from './mcp-resource-fixture.mjs';
let refreshed=false;
createInterface({input:process.stdin}).on('line',line=>{
  let request;try{request=JSON.parse(line)}catch{return}
  if(process.env.APACK_MCP_RECEIPT)appendFileSync(process.env.APACK_MCP_RECEIPT,JSON.stringify({pid:process.pid,method:request.method,uri:request.params?.uri})+'\n');
  if(request.id===undefined)return;
  let result,error;
  switch(request.method){
    case 'initialize':result={protocolVersion:request.params?.protocolVersion??'2024-11-05',capabilities:{tools:{},resources:{listChanged:true},...(process.env.APACK_MCP_DIRECTORY==='1'?{extensions:{'io.modelcontextprotocol/skills':{directoryRead:true}}}:{})},serverInfo:{name:'research-resource-fixture',version:'1.0.0'}};break;
    case 'ping':result={};break;
    case 'tools/list':result={tools:[]};break;
    case 'resources/directory/read':result={resources:[{uri:resourceUris.text,name:'Release notes',mimeType:'text/markdown'}]};break;
    case 'resources/templates/list':result={resourceTemplates:[]};break;
    case 'resources/list':result={resources:[{uri:resourceUris.text,name:refreshed?'Current release notes':'Release notes',mimeType:'text/markdown'},{uri:resourceUris.binary,name:'Release evidence',mimeType:'application/octet-stream'}]};break;
    case 'resources/read':
      if(request.params?.uri===resourceUris.text)result={contents:[{uri:resourceUris.text,mimeType:'text/markdown',text:resourceText}]};
      else if(request.params?.uri===resourceUris.binary)result={contents:[{uri:resourceUris.binary,mimeType:'application/octet-stream',blob:resourceBlob.toString('base64')}]};
      else{refreshed=true;error={code:-32002,message:'Synthetic resource no longer exists'}}
      break;
    default:error={code:-32601,message:'Unsupported synthetic operation'};
  }
  console.log(JSON.stringify({jsonrpc:'2.0',id:request.id,...(error?{error}:{result})}));
});
