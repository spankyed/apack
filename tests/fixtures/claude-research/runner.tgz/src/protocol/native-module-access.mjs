import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, copyFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { record } from './record.mjs';
import { hash } from '../artifacts/runs.mjs';

const targetSha256 = '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37';
const modules = [
  { path: '/$bunfs/root/chunk-c7wcn77x.js', export: 'I9e' },
  { path: '/$bunfs/root/chunk-nkxb8t4d.js', export: 'Kw' },
  { path: '/$bunfs/root/chunk-wn0572jb.js', export: '_Jo' },
];

/** Import only modules embedded in the unchanged binary; never execute recovered JavaScript files. */
export async function probeNativeModuleAccess(executable, workspaceParent, output) {
  assert.equal(hash(await readFile(executable)), targetSha256, 'This reviewed export map is pinned to 2.1.302');
  await mkdir(workspaceParent, { recursive: true });
  const workspace = await mkdtemp(join(workspaceParent, 'native-module-access-'));
  const reportPath = join(workspace, 'module-access.json');
  const preload = join(workspace, 'module-access.mjs');
  const source = `import { writeFileSync } from 'node:fs';
const report = [];
for (const entry of ${JSON.stringify(modules)}) {
  try {
    const native = await import(entry.path), value = native[entry.export];
    report.push({ ...entry, type: typeof value, keys: value && typeof value === 'object' ? Object.keys(value).sort() : [] });
  } catch (error) { report.push({ ...entry, error: String(error) }); }
}
writeFileSync(${JSON.stringify(reportPath)}, JSON.stringify(report, null, 2));
`;
  await writeFile(preload, source);
  const result = await record({ executable, args: ['--version'], cwd: workspace, output, timeoutMs: 15000,
    env: { HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'), PATH: '/usr/bin:/bin',
      DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1', BUN_OPTIONS: '--preload=' + preload } });
  const report = JSON.parse(await readFile(reportPath, 'utf8'));
  await copyFile(preload, join(result.directory, 'authored-preload.mjs'));
  await copyFile(reportPath, join(result.directory, 'module-access.json'));
  const evidence = { targetSha256, authoredPreloadSha256: hash(Buffer.from(source)), importsEmbeddedNativeModules: true,
    recoveredSourceExecuted: false, modelRequests: 0, report, qualification: 'Export accessibility only; no session admission, UI render or policy behavior acceptance.' };
  await writeFile(join(result.directory, 'integration.json'), JSON.stringify(evidence, null, 2) + '\n');
  assert.equal(result.status, 'complete');
  assert.ok(report.every(entry => !entry.error));
  assert.ok(['run', 'press', 'input', 'select', 'onInvalidate'].every(key => report[0].keys.includes(key)));
  assert.equal(report[2].type, 'function');
  return { ...result, evidence };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  assert.equal(process.argv.length, 5, 'Usage: node src/protocol/native-module-access.mjs <pinned-binary> <private-root> <output>');
  console.log(JSON.stringify(await probeNativeModuleAccess(...process.argv.slice(2).map(value => resolve(value))), null, 2));
}
