import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Original plugin-owned theme plus an ordinary desktop preview of native semantic roles. */
export async function addNativeThemeCreateResetFixture(plugin,workspace){
 const manifest=join(plugin,'.claude-plugin/plugin.json');await writeFile(manifest,JSON.stringify({...JSON.parse(await readFile(manifest,'utf8')),themes:'./theme-packs'}));
 await mkdir(join(plugin,'theme-packs'));await writeFile(join(plugin,'theme-packs/team.json'),JSON.stringify({name:'Team Review',base:'dark',overrides:{success:'#55aa66',warning:'#cc9944'}}));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'AbovePrompt'},($,e,next)=>{if(e.surface!=='desktop')return next(e);const {Box,Text}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Text({color:'success',children:['Workspace ready']}),Text({color:'warning',children:['Theme details']})]});});}`);
 await writeFile(join(workspace,'main.py'),"import json,sys\njson.load(sys.stdin)\nprint('Workspace ready')\nprint('Theme preview active')\n");
}
