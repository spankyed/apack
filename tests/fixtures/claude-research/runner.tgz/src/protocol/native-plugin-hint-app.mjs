import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,access} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {record} from './record.mjs';
export const PLUGIN_HINT_COMMAND="/usr/bin/printf '%s\\n' 'Release check complete.' '<claude-code-hint v=1 type=plugin value=document-skills@anthropic-agent-skills />'";
const pluginId='document-skills@anthropic-agent-skills';
export async function addNativePluginHintAppFixture(executable,workspace,output,snapshot){
 assert.equal(process.platform,'linux');assert.ok(isAbsolute(snapshot??''));
 await access('/.dockerenv');const interfaces=[];for(const entry of await readdir('/sys/class/net',{withFileTypes:true})){if(!entry.isDirectory()&&!entry.isSymbolicLink())continue;const flags=Number.parseInt(await readFile('/sys/class/net/'+entry.name+'/flags','utf8'),16);if(flags&1)interfaces.push(entry.name)}assert.deepEqual(interfaces.sort(),['lo'],'Plugin-hint acceptance requires loopback as the only UP interface');assert.equal((await readFile('/proc/net/route','utf8')).trim().split('\n').length,1,'Plugin-hint acceptance requires no IPv4 routes');
 const provenance=JSON.parse(await readFile(join(snapshot,'provenance.json'),'utf8'));
 assert.equal(provenance.repository,'https://github.com/anthropics/skills.git');assert.equal(provenance.commit,'dbd4588f9e1033efb41dad4bef2f7947c8993d44');assert.equal(provenance.completeGitObjectClosure,true);
 const repository=join(snapshot,'repository');
 assert.equal(createHash('sha256').update(await readFile(join(repository,'.claude-plugin/marketplace.json'))).digest('hex'),provenance.manifestSha256);
 const gitConfig=join(workspace,'.gitconfig');await writeFile(gitConfig,'[url '+JSON.stringify('file://'+repository)+']\n\tinsteadOf = https://github.com/anthropics/skills.git\n\tinsteadOf = https://github.com/anthropics/skills\n[protocol "file"]\n\tallow = always\n');
 const env={PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),GIT_CONFIG_GLOBAL:gitConfig,GIT_CONFIG_NOSYSTEM:'1',GIT_TERMINAL_PROMPT:'0',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
 const registration=await record({executable,cwd:workspace,output,env,args:['--setting-sources','','plugin','marketplace','add','anthropics/skills'],timeoutMs:20000,maxBytes:1024*1024});assert.equal(registration.status,'complete');
 const cache=JSON.parse(await readFile(join(workspace,'.claude/plugins/known_marketplaces.json'),'utf8'))['anthropic-agent-skills'];assert.deepEqual(cache.source,{source:'github',repo:'anthropics/skills'});
 const cachedCommit=execFileSync('/usr/bin/git',['-C',cache.installLocation,'rev-parse','HEAD'],{env,encoding:'utf8',timeout:2000,maxBuffer:4096}).trim();assert.equal(cachedCommit,provenance.commit);
 assert.equal(createHash('sha256').update(await readFile(join(cache.installLocation,'.claude-plugin/marketplace.json'))).digest('hex'),provenance.manifestSha256);
 await writeFile(join(workspace,'native-plugin-hint-fixture.json'),JSON.stringify({registration,provenance,cachedCommit,pluginId},null,2)+'\n');
}
export async function verifyNativePluginHintApp(workspace,calls,evidence,decision){
 assert.equal(evidence.nativePluginHint,true);assert.equal(evidence.actualAppGui,true);assert.equal(evidence.resumedPrintSameSession,true);
 const proof=JSON.parse(await readFile(join(workspace,'native-plugin-hint-app.json'),'utf8'));
 assert.equal(proof.decision,decision);assert.deepEqual(proof.shown.choices.map(choice=>choice.value),['yes','no','disable']);assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.boundNativePid,evidence.boundNativePid);assert.equal(proof.draftRetained,true);assert.equal(proof.selectionRetained,true);assert.equal(proof.captures.length,decision==='timeout'?6:4);
 const global=JSON.parse(await readFile(join(workspace,'.claude/.claude.json'),'utf8'));assert.ok(global.claudeCodeHints?.plugin?.includes(pluginId));
 if(decision==='disable')assert.equal(global.claudeCodeHints.disabled,true);
 const settings=JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8'));if(decision==='yes')assert.equal(settings.enabledPlugins?.[pluginId],true);else assert.notEqual(settings.enabledPlugins?.[pluginId],true);
 const model=calls.filter(call=>call.path.startsWith('/v1/messages'));assert.equal(model.length,2);
 const blocks=model.at(-1).messages.flatMap(message=>Array.isArray(message.content)?message.content:[]),tool=blocks.find(block=>block.type==='tool_use'&&block.name==='Bash');assert.equal(tool?.input.command,PLUGIN_HINT_COMMAND);
 const result=blocks.find(block=>block.type==='tool_result'&&block.tool_use_id===tool.id);assert.equal(result?.is_error,false);assert.match(JSON.stringify(result.content),/Release check complete/);assert.doesNotMatch(JSON.stringify(result.content),/claude-code-hint/);
 const verified={decision,persisted:global.claudeCodeHints,enabled:settings.enabledPlugins?.[pluginId]??false,originalToolResult:result,scope:'Actual-app original plugin recommendation and retained composing/recovery at normal/compact sizes; other outcomes, suppression, policy/window/lifecycle and original combined F1–F5 remain open.'};
 await writeFile(join(workspace,'native-plugin-hint-verified.json'),JSON.stringify(verified,null,2)+'\n');return verified;
}

/** Read only original queue/gates; never consumes submitted hints or answers a dialog. */
export function nativePluginHintObserver(workspace){return `{const fs=await import('node:fs'),runtime=await import('/$bunfs/root/chunk-a7b8k0bt.js'),eligibility=await import('/$bunfs/root/chunk-3hjmzaak.js');let previous='',count=0,submitted=0,bound;const snapshot=(event='snapshot')=>{if(count>=200)return;try{const binding=runtime.Zh();if(binding?.surface!=='terminal')return;const context=binding.toolContext(new AbortController()),hint=context.session.pendingHint;if(bound!==hint){bound=hint;hint.subscribeSubmitted(()=>{submitted++;snapshot('submitted')})}const row={event,pid:process.pid,sourceEligibilitySuppressed:eligibility.gy(),hasAgentId:!!context.agentId,submitted,shownThisSession:hint.shownThisSession,pending:hint.getSnapshot(),dialogs:context.dialogStore.getState().open.map(item=>({id:item.id,kind:item.kind,...item.kind==='plugin_hint'?{payload:item.payload}:{}}))},encoded=JSON.stringify(row);if(encoded!==previous){previous=encoded;count++;fs.appendFileSync(${JSON.stringify(join(workspace,'native-plugin-hint-state.jsonl'))},encoded+'\\n')}}catch(error){fs.writeFileSync(${JSON.stringify(join(workspace,'native-plugin-hint-state-error.txt'))},String(error))}};setInterval(snapshot,25).unref();}`;}
