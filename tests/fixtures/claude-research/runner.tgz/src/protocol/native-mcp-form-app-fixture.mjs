import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
const json = path => readFile(path, 'utf8').then(JSON.parse);
const rows = async path => (await readFile(path, 'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
/** Actual native-owner form evidence; this does not accept the independent URL/waiting lane. */
export async function verifyNativeMcpFormApp(workspace, calls) {
  const proof = await json(join(workspace, 'native-mcp-form-app-proof.json'));
  assert.deepEqual(proof.steps.map(step => step.phase), [1, 2, 3, 7]);
  for (const key of ['retainedDraft', 'originalNativeRecovery', 'recoveredSameSession']) assert.equal(proof[key], true);
  assert.equal(proof.captures.length, 4); assert.deepEqual(proof.geometry.map(row => [row.width, row.height]), [[1100, 900], [680, 600]]);
  for (const step of proof.steps) { assert.equal(step.nativePid, proof.boundNativePid); assert.equal(step.retainedDraft, true); }
  if (proof.cursorReturns !== undefined) {
    assert.deepEqual(proof.cursorReturns.map(row => [row.width, row.height]), [[1100, 900], [680, 600]]);
    assert.deepEqual(proof.cursorCaptures, ['native-mcp-form-1100-cursor-return.png', 'native-mcp-form-680-cursor-return.png']);
    for (const row of proof.cursorReturns) {
      assert.equal(row.id, proof.steps[0].id); assert.equal(row.revision, proof.steps[0].revision);
      assert.equal(row.nativePid, proof.boundNativePid); assert.equal(row.value, 'A😀yxBC'); assert.equal(row.cursorOffset, 4);
      assert.equal(row.retainedDraft, true); assert.equal(row.retainedSelection, true);
      assert.equal(row.pendingInputBlocked, true); assert.equal(row.valuesUnchangedByFocus, true);
      assert.equal(row.collapsedNativeAccordionOnReturn, true);
      assert.deepEqual(row.focusedFields, ['enabled', 'count', 'audience', 'sections', 'title']);
    }
  }
  const frames = await rows(join(workspace, 'mcp-elicitation-receipts.jsonl'));
  const expected = new Map([[1, 'accept'], [2, 'decline'], [3, 'cancel'], [7, 'cancel']]);
  for (const [phase, action] of expected) {
    const replies = frames.filter(row => row.id === 'research-elicitation-' + phase && row.result);
    assert.equal(replies.length, 1); assert.equal(replies[0].result.action, action);
    if (phase === 1) assert.deepEqual(replies[0].result.content, { title: 'Migration notes', enabled: false, count: 0, email: 'reviewer@example.invalid', date: '2026-10-22', audience: 'internal', sections: ['migration'] });
    else assert.equal(replies[0].result.content, undefined);
  }
  const interrupted = frames.find(row => row.method === 'tools/call' && row.params.arguments.phase === 7);
  assert.ok(interrupted); assert.ok(frames.some(row => row.method === 'notifications/cancelled' && row.params.requestId === interrupted.id));
  assert.ok(calls.some(call => JSON.stringify(call.messages ?? []).includes('Continue after cancelling the release input.')));
  assert.ok(calls.every(call => !call.fixtureError && ['/v1/messages', '/v1/messages/count_tokens'].includes(call.path?.split('?')[0])));
  const natives = await rows(join(workspace, 'native-children.jsonl')), exits = await rows(join(workspace, 'native-exits.jsonl'));
  assert.equal(natives.length, 3); assert.equal(natives[1].pid, proof.boundNativePid);
  for (const native of natives) assert.ok(exits.some(exit => exit.pid === native.pid));
  for (let i = 0; i < 2; i++) assert.ok(exits.find(exit => exit.pid === natives[i].pid).at <= natives[i + 1].at);
  const children = await rows(join(workspace, 'mcp-children.jsonl')), childExits = await rows(join(workspace, 'mcp-exits.jsonl'));
  assert.ok(children.some(child => child.ancestors.includes(proof.boundNativePid)));
  for (const child of children) assert.ok(childExits.some(exit => exit.pid === child.pid));
  const preloads = await rows(join(workspace, 'user-preload-calls.jsonl'));
  for (const native of natives) assert.ok(preloads.some(row => row.pid === native.pid));
  const evidence = await json(join(workspace, 'native-terminal-app-evidence.json'));
  assert.equal(evidence.boundNativePid, proof.boundNativePid); assert.equal(evidence.sessionId, proof.sessionId); assert.equal(evidence.finalSessionId, proof.sessionId); assert.deepEqual(evidence.browserErrors, []);
  return { originalNativeCursorReturn: proof.cursorReturns !== undefined, originalNativeFormActions: true, originalValidationAndTypedValues: true, originalPauseCancellation: true, originalNativeRecovery: true, ownedNativeShutdown: true, ownedMcpShutdown: true, nativePreloadPreserved: true, nativeProcesses: natives.length, qualification: 'Main terminal owner only. URL/waiting, natural-language dates and other owner/window/policy/task contexts remain separate.' };
}
