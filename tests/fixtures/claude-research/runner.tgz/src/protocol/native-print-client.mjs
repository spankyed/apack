import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { randomUUID } from 'node:crypto';
import { record } from './record.mjs';
import { hash } from '../artifacts/runs.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

export async function probeNativePrintClient(checkout, executable, parent, output) {
  const targetSha256='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37';
  assert.equal(hash(await readFile(executable)),targetSha256);
  await mkdir(parent,{recursive:true});const workspace=await mkdtemp(join(parent,'native-print-client-')),plugin=join(workspace,'plugin');
  await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));await mkdir(join(workspace,'.claude'));
  await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'print-client-fixture',version:'0.0.1'}));
  await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
  await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'AbovePrompt'},($,e)=>{const {Client}=$.ui.resolve(e);return Client({key:'counter',module:'./surface.ts',props:{name:'Print extension'},width:40,height:6});});on('ui.message',async($,e)=>{await $.fs.write('native-print-message.json',JSON.stringify(e));return {props:{name:'Original print reply'}};});on('ui.input',($,e,next)=>next(e.value==='rewrite'?{...e,value:'Original print input'}:e));}`);
  await writeFile(join(plugin,'hooks/surface.ts'),`export default function(props,s){const {Box,Text,Button,Input,Select}=s.elements;if(s.state===undefined){s.setState({count:0,key:'none',note:'',choice:'a',ticks:0});s.every(200,()=>s.setState({...s.state,ticks:s.state.ticks+1}));}s.onKey(e=>{s.setState({...s.state,key:e.key});s.post({key:e.key});});return Box({flexDirection:'column',children:[Text({children:[props.name+' count='+s.state.count+' key='+s.state.key+' note='+s.state.note+' choice='+s.state.choice+' room='+s.columns+'x'+s.rows+' tick='+s.state.ticks]}),Button({key:'apply',label:'Apply print extension',onPress:()=>s.setState({...s.state,count:s.state.count+1})}),Input({key:'note',label:'Print note',value:s.state.note,onInput:note=>s.setState({...s.state,note}),onSubmit:note=>s.setState({...s.state,note})}),Select({key:'choice',label:'Print choice',value:s.state.choice,options:[{value:'a',label:'Alpha'},{value:'b',label:'Beta'}],onSelect:choice=>s.setState({...s.state,choice})})]});}`);
  const {prepareClaudePrintClients}=await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/print-client-bridge.ts')).href);
  let alive=true;const bridge=await prepareClaudePrintClients({currentPid:()=>alive?process.pid:undefined});
  const model=await startSyntheticModel(workspace,'TextOnly'),responses=new Map(),waiting=new Map(),events=[],report={};let buffer='',task,problem;
  const find=(node,type)=>node?.type===type?node:(node?.children??[]).map(child=>find(child,type)).find(Boolean);
  const client={client_id:'research-print-client',surface:'desktop'},site={...client,component:'AbovePrompt',instance_id:'print-above',props:{}};
  try {
    const run=await record({executable,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--tools','','--plugin-dir',plugin,'--strict-mcp-config','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})],cwd:workspace,output,timeoutMs:20000,
      env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),PATH:'/usr/bin:/bin',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',ANTHROPIC_BASE_URL:model.url,BUN_OPTIONS:bridge.bunOptions},
      input:[JSON.stringify({type:'control_request',request_id:'initialize',request:{subtype:'initialize',hooks:{}}})+'\n'],
      onStdout(bytes,transport){
        buffer+=bytes;while(buffer.includes('\n')){
          const at=buffer.indexOf('\n'),line=buffer.slice(0,at);buffer=buffer.slice(at+1);let value;try{value=JSON.parse(line);}catch{continue;}
          if(value.type==='system'){events.push(value);continue;}
          if(value.type!=='control_response')continue;const response=value.response;responses.set(response.request_id,response);
          const pending=waiting.get(response.request_id);if(pending){waiting.delete(response.request_id);response.subtype==='success'?pending.resolve(response.response):pending.reject(Error(JSON.stringify(response)));}
          if(response.request_id!=='initialize'||task)continue;
          const call=request=>new Promise((resolve,reject)=>{const id=randomUUID();waiting.set(id,{resolve,reject});transport.send(JSON.stringify({type:'control_request',request_id:id,request})+'\n');});
          task=(async()=>{
            assert.equal(response.subtype,'success');assert.ok(response.response.capabilities.includes('ui_surface_v1'));
            await call({subtype:'ui_attach',...client,answers:[]});
            const module=await call({subtype:'ui_client_module',plugin:'print-client-fixture'});report.module={plugin:module.plugin,hash:module.hash,fileCount:module.files.length};
            let frame,revision=1;
            const render=async()=>{const raw=await call({subtype:'ui_render',...site});assert.equal(raw.client_modules['print-client-fixture'],module.hash);frame=await bridge.projection.project({...site,instance_revision:revision},raw);return frame;};
            const wait=async(predicate,label)=>{const deadline=Date.now()+4000;do{await render();if(predicate(frame))return;await new Promise(resolve=>setTimeout(resolve,30));}while(Date.now()<deadline);throw Error('Print Client timeout: '+label+' '+JSON.stringify(frame));};
            await wait(value=>JSON.stringify(value.tree).includes('Print extension count=0'),'initial native module');
            const token=frame.tree.props.id;report.initial=frame.tree;
            assert.equal((await bridge.projection.event({client_id:client.client_id,id:token,sequence:1,event:{kind:'resize',columns:40,rows:6}})).handled,true);
            await bridge.projection.event({client_id:client.client_id,id:token,sequence:2,event:{kind:'key',key:'x'}});
            await wait(value=>JSON.stringify(value.tree).includes('Original print reply count=0 key=x')&&JSON.stringify(value.tree).includes('room=40x6'),'native key/message/resize');
            const action=async(type,value)=>{const node=find(frame.tree,type);return bridge.projection.action({...client,component:site.component,instance_id:site.instance_id,instance_revision:revision,plugin:node.press.plugin,handle:node.press.handle,key:node.props.key,subtype:type==='Button'?'ui_press':type==='Input'?'ui_input':'ui_select',...(type==='Input'?{kind:'change',value}:type==='Select'?{value}:{})});};
            assert.equal((await action('Button')).handled,true);await wait(value=>JSON.stringify(value.tree).includes('count=1'),'native button');
            assert.equal((await action('Input','rewrite')).handled,true);await wait(value=>JSON.stringify(value.tree).includes('note=Original print input'),'native field hook');
            assert.equal((await action('Select','b')).handled,true);await wait(value=>JSON.stringify(value.tree).includes('choice=b'),'native select');
            report.interactive=frame.tree;
            assert.equal((await bridge.projection.event({client_id:'foreign-client',id:token,sequence:3,event:{kind:'key',key:'foreign'}})).handled,false);
            assert.equal((await bridge.projection.release({...site,instance_revision:revision})).released,true);
            assert.equal((await bridge.projection.event({client_id:client.client_id,id:token,sequence:4,event:{kind:'key',key:'old'}})).handled,false);
            revision++;
            await wait(value=>JSON.stringify(value.tree).includes('Print extension count=0 key=none'),'fresh native acquisition');assert.notEqual(frame.tree.props.id,token);report.reopened=frame.tree;
            await bridge.projection.detach(client.client_id);await call({subtype:'ui_detach',client_id:client.client_id});
            report.nativeMessage=JSON.parse(await readFile(join(workspace,'native-print-message.json'),'utf8'));report.nativeSnapshotEvents=events.filter(event=>event.client_snapshot===true).length;
            assert.ok(report.nativeSnapshotEvents>0);assert.equal(model.calls.length,0);transport.closeInput();
          })().catch(error=>{problem=error;transport.stop('print-client-proof-failed');});
        }
      }
    });
    await task;
    if(problem||run.status!=='complete'){
      await writeFile(join(run.directory,'native-print-client-failure.json'),JSON.stringify({verified:false,problem:String(problem??run.status),report,events:events.length},null,2)+'\n');
      console.log(JSON.stringify({directory:run.directory,status:'failed',problem:String(problem??run.status)}));
    }
    assert.ifError(problem);assert.equal(run.status,'complete');
    const evidence={verified:true,targetSha256,runtimeCheckout:checkout,workspace,report,syntheticApiRequests:model.calls.length,realModelRequests:0,userPromptsSent:0,qualification:'Original print protocol render/module admission with native sandbox projection, controls, hook/message/resize, scoped release and fresh acquisition; not actual-app acceptance.'};
    await writeFile(join(run.directory,'native-print-client.json'),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify({directory:run.directory,status:'complete',nativeSnapshotEvents:report.nativeSnapshotEvents,modelRequests:model.calls.length}));return evidence;
  }finally{alive=false;await bridge.close();await model.close();}
}
if(process.argv[1]===new URL(import.meta.url).pathname)await probeNativePrintClient(...process.argv.slice(2).map(value=>resolve(value)));
