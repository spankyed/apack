import {mkdir,mkdtemp,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {nativeManagedFiles} from './native-managed-files.mjs';
import {hash} from '../artifacts/runs.mjs';

/** Same owned managed/ordinary document fixtures for raw and product-query transport. */
export async function prepareNativeDocumentMediaFixture(workspace,{sourceRefusals=false}={}){
  await mkdir(workspace, { recursive: true });
  const cwd = await mkdtemp(join(workspace, 'document-media-'));
  const marketplace = join(cwd, 'marketplace'), managed = join(marketplace, 'plugins/document-media');
  const ordinary = join(cwd, 'ordinary'), policy = join(cwd, 'policy'), preload = join(cwd, 'preload.mjs');
  for (const path of [join(marketplace, '.claude-plugin'), policy, ...[managed, ordinary].flatMap(p => [join(p, '.claude-plugin'), join(p, 'hooks')])]) await mkdir(path, { recursive: true });
  await writeFile(join(marketplace, '.claude-plugin/marketplace.json'), JSON.stringify({ name: 'document-research', owner: { name: 'Private research' }, plugins: [{ name: 'document-media', source: './plugins/document-media' }] }));
  await writeFile(join(policy, 'managed-settings.json'), JSON.stringify({ extraKnownMarketplaces: { 'document-research': { source: { source: 'directory', path: marketplace } } }, enabledPlugins: { 'document-media@document-research': true } }));
  await writeFile(preload, nativeManagedFiles({ directory: policy, receipt: join(cwd, 'policy-reads.jsonl'), platform: 'linux' }));
  const source = (isManaged) => `export function register(on){on('prompt.submit',async($,e,next)=>{
    const rows=[];for(const item of e.attachments??[]){if(item.type==='document')rows.push({id:item.id,result:await $.prompt.media({id:item.id})});}
    if(!rows.length)return next(e);
    const unlisted=await $.prompt.media({id:'unlisted_document_fixture'});
    await $.fs.write(${JSON.stringify(isManaged ? 'managed-documents.json' : 'ordinary-documents.json')},JSON.stringify({rows,unlisted}));
    return next(e);
  });${isManaged ? `on('turn.complete',async($,e,next)=>{const receipt=JSON.parse(await $.fs.read('managed-documents.json'));const rows=[];for(const item of receipt.rows)rows.push({id:item.id,result:await $.prompt.media({id:item.id})});await $.fs.write('settled-documents.json',JSON.stringify({rows}));return next(e);});` : ''}}`;
  for (const [path, isManaged] of [[managed, true], [ordinary, false]]) {
    await writeFile(join(path, '.claude-plugin/plugin.json'), JSON.stringify({ name: isManaged ? 'document-media' : 'ordinary-document-media', version: '0.0.1' }));
    await writeFile(join(path, 'hooks/hooks.json'), JSON.stringify({ modules: ['./register.ts'] }));
    await writeFile(join(path, 'hooks/register.ts'), source(isManaged));
  }
  const text = 'Document byte fixture: café\n第二行\n';
  const content = [{ type: 'text', text: 'Acknowledge the owned document fixture without tools.' },
    { type: 'document', source: { type: 'text', media_type: 'text/plain', data: text } },
    { type: 'document', source: { type: 'base64', media_type: 'text/plain', data: Buffer.from(text).toString('base64') } }];
  if (sourceRefusals) content.push(
    { type: 'document', source: { type: 'url', url: 'http://127.0.0.1:9/owned-document-missing' } },
    { type: 'document', source: { type: 'file', file_id: 'owned-document-missing' } },
    { type: 'document', source: { type: 'content', content: [{ type: 'text', text: 'Nested owned document fixture' }] } });
  return {cwd,ordinary,preload,content,managedSourceSha256:hash(Buffer.from(source(true)))};
}
