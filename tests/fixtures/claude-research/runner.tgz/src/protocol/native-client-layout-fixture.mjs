import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** Original Client modules draw ordinary status labels; geometry stays observable through native posts. */
export async function addNativeClientLayoutFixture(plugin) {
  const register = join(plugin, 'hooks/register.ts');
  const hook = `on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
    const {Box,Client}=$.ui.resolve(e);
    return Box({flexDirection:'column',children:[await next(e),
      Box({flexDirection:'row',gap:1,children:[
        Client({key:'layout-fixed',module:'./client-layout.ts',props:{label:'Session'},width:12,height:1}),
        Client({key:'layout-intrinsic',module:'./client-layout.ts',props:{label:'Ready'}}),
        Client({key:'layout-flexible',module:'./client-layout.ts',props:{label:'Workspace connected'},height:1,flexGrow:1})]}),
      Client({key:'layout-percent',module:'./client-layout.ts',props:{label:'Context available'},width:'50%',height:2}),
      Box({flexDirection:'column',height:6,children:[
        Client({key:'layout-height-fixed',module:'./client-layout.ts',props:{label:'Height fixed'},height:1}),
        Client({key:'layout-height-percent',module:'./client-layout.ts',props:{label:'Height percent'},height:'50%'}),
        Client({key:'layout-height-grow',module:'./client-layout.ts',props:{label:'Height flexible'},flexGrow:1})]})]});
  });
  const layoutReceipts=[];let layoutWrites=Promise.resolve();
  on('ui.message',async($,e,next)=>{if(e.data?.clientLayout!==true)return next(e);layoutReceipts.push({...e.data,surface:e.surface,component:e.component});layoutReceipts.splice(0,Math.max(0,layoutReceipts.length-128));const snapshot=JSON.stringify(layoutReceipts);layoutWrites=layoutWrites.then(()=>$.fs.write('native-client-layout-regions.json',snapshot));await layoutWrites;return next(e);});`;
  const source = await readFile(register, 'utf8');
  if (!source.includes('export function register(on){')) throw Error('Native hook entry not found');
  await writeFile(register, source.replace('export function register(on){', 'export function register(on){'+hook));
  await writeFile(join(plugin, 'hooks/client-layout.ts'), `export default function(props,s){
    const {Text}=s.elements;
    if(s.state===undefined){s.setState({ready:true});s.every(250,()=>s.post({clientLayout:true,label:props.label,columns:s.columns,rows:s.rows}));}
    return Text({children:[props.label]});
  }`);
}
