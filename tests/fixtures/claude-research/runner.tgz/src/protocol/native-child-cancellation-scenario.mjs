import assert from 'node:assert/strict';

/** Two distinct original questions expose interrupted-turn retirement and same-worker recovery. */
export function nativeChildCancellationStep(body) {
 const messages=body.messages??[];
 const text=messages.flatMap(message=>typeof message.content==='string'?[message.content]:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text):[]).join('\n');
 const round=text.match(/ResearchChildCancel[12]/g)?.at(-1)?.slice(-1);
 if(!round)return;
 const id='toolu_child_cancellation_'+round;
 const result=messages.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[]).find(block=>block.tool_use_id===id);
 if(result)return {round,result,block:{type:'text',text:result.is_error?'The release question was interrupted.':'The release branch review is recorded.'}};
 assert.ok(body.tools?.some(tool=>tool.name==='AskUserQuestion'),'Original question tool is unavailable');
 return {round,block:{type:'tool_use',id,name:'AskUserQuestion',input:{questions:[{question:'Which release branch should be reviewed first?',header:'Release review',options:[{label:'Stable',description:'Review the current release'},{label:'Next',description:'Review the upcoming release'}],multiSelect:false}]}}};
}
