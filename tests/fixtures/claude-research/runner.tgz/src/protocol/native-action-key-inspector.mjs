/** Source identities for the live original keybinding provider and event dispatcher. */
export const nativeActionKeySignatures = Object.freeze({
  nvt: '6edf8bd3b931a479f0396aaba3c24e95d024688ff923fdeb4786595753da185c',
  Yt: 'e5fe403fa1df1d1a78036cc6c000de59e2f1fd60f012b324b1fd5ce1ea7f6ad9',
});

/** Observe only completed action-key replies; forward native HTTP writes unchanged. */
export function observeNativeActionKeyReplies(prototype, record) {
  const original = prototype.end;
  const observed = function (...args) {
    try {
      if (this.req?.url === '/control' && typeof args[0] === 'string' && args[0].length <= 2 * 1048576) {
        const reply = JSON.parse(args[0]);
        if (typeof reply.result?.handled === 'boolean' && reply.result.action_keys) {
          record({ status: this.statusCode, handled: reply.result.handled,
            revision: reply.result.action_keys.revision, bindings: reply.result.action_keys.bindings?.length });
        }
      }
    } catch { /* Observation cannot change native response delivery. */ }
    return Reflect.apply(original, this, args);
  };
  prototype.end = observed;
  return () => { if (prototype.end === observed) prototype.end = original; };
}

/** Observe live original bindings/registrations; never dispatch keys or register handlers. */
export function nativeActionKeyInspector(outputPath, { observeDispatch = false } = {}) {
  return `
{
 const fs=await import('node:fs'),crypto=await import('node:crypto'),http=await import('node:http');
 const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
 if(hash(fs.readFileSync(process.execPath))!=='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37')throw Error('Native action inspector requires pinned 2.1.302');
 const roots=await import('/$bunfs/root/chunk-pg10s5g1.js'),runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),events=await import('/$bunfs/root/chunk-174fh6cj.js');
 const signatures=${JSON.stringify(nativeActionKeySignatures)},samples=[],keyEvents=[],controlReplies=[],functions=new WeakMap(),observeDispatch=${JSON.stringify(observeDispatch)};
 const keybindings=observeDispatch?await import('/$bunfs/root/chunk-tvszjqy2.js'):undefined;
 let restoreDispatch=()=>{},restoreReplies=()=>{};
 let previous,busy=false;const deadline=Date.now()+100000;
 const text=value=>{if(typeof value!=='string'||value.length>256)throw Error('Native key string bound');return value;};
 const chord=value=>{
  if(!Array.isArray(value)||value.length>8)throw Error('Native chord shape changed');
  return value.map(key=>{if(!key||typeof key!=='object')throw Error('Native key shape changed');const out={key:text(key.key)};for(const flag of ['ctrl','alt','shift','meta','super']){if(typeof key[flag]!=='boolean')throw Error('Native key modifiers changed');out[flag]=key[flag];}return out;});
 };
 const save=error=>{
  const data=JSON.stringify({readOnly:!observeDispatch,observationOnly:true,wrappedOriginalDispatch:observeDispatch,keyEvents,controlReplies,targetSha256:'5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37',nativePid:process.pid,signatures,samples,...(error?{error:String(error).slice(0,512)}:{})},null,2);
  if(Buffer.byteLength(data)>8388608)throw Error('Native action inspector output bound');
  fs.writeFileSync(${JSON.stringify(outputPath)},data,{mode:0o600});
 };
 if(observeDispatch){
  restoreReplies=(${observeNativeActionKeyReplies.toString()})(http.ServerResponse.prototype,entry=>{if(controlReplies.length<64){controlReplies.push(entry);save();}});
  const original=events.R8.dispatchDiscrete;
  const observed=function(target,event){
   let entry;
   if(event?.type==='keydown'&&keyEvents.length<64){entry={key:String(event.key).slice(0,64),name:String(event.name).slice(0,64),sequence:String(event.sequence).slice(0,64),ctrl:event.ctrl,shift:event.shift,meta:event.meta,superKey:event.superKey,normalized:keybindings.Xwe(event)};keyEvents.push(entry);}
   try{return Reflect.apply(original,this,arguments);}finally{if(entry){entry.defaultPrevented=event.defaultPrevented;entry.propagationStopped=event._isPropagationStopped();save();}}
  };
  events.R8.dispatchDiscrete=observed;
  restoreDispatch=()=>{if(events.R8.dispatchDiscrete===observed)events.R8.dispatchDiscrete=original;};
 }
 const timer=setInterval(()=>{
  if(busy)return;if(Date.now()>deadline){clearInterval(timer);restoreDispatch();restoreReplies();return;}busy=true;
  try{
   if(runtime.ey()?.surface!=='terminal')return;
   const owner=roots.ai().get(process.stdout),pending=owner?.container?.current?[owner.container.current]:[],seen=new Set(),found=[];
   while(pending.length){
    const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('Native key fiber bound');seen.add(fiber);
    if(typeof fiber.type==='function'&&Object.hasOwn(signatures,fiber.type.name)){
     let identity=functions.get(fiber.type);if(!identity){identity=hash(Function.prototype.toString.call(fiber.type));functions.set(fiber.type,identity);}
     if(identity!==signatures[fiber.type.name])throw Error('Original keybinding producer identity changed');
     found.push({name:fiber.type.name,props:fiber.memoizedProps});
    }
    if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);
   }
   if(!found.length)return;
   if(found.filter(item=>item.name==='nvt').length!==1||found.filter(item=>item.name==='Yt').length!==1)throw Error('Original keybinding owner is ambiguous');
   const provider=found.find(item=>item.name==='nvt').props,dispatcher=found.find(item=>item.name==='Yt').props;
   if(provider.bindings!==dispatcher.bindings||provider.handlerRegistryRef!==dispatcher.handlerRegistryRef)throw Error('Original keybinding ownership differs');
   if(!Array.isArray(provider.bindings)||provider.bindings.length>1024)throw Error('Native bindings bound');
   const bindings=provider.bindings.map(binding=>({context:text(binding.context),action:binding.action===null?null:text(binding.action),chord:chord(binding.chord)}));
   const registry=provider.handlerRegistryRef?.current;if(!(registry instanceof Map)||registry.size>1024)throw Error('Native handler registry shape changed');
   const handlers=[];
   for(const [action,entries]of registry){
    if(!(entries instanceof Set)||entries.size>128)throw Error('Native handler registration bound');
    for(const entry of entries){if(handlers.length>=2048)throw Error('Native handler total bound');handlers.push({action:text(action),context:text(entry.context),fallback:entry.fallback===true,singleKey:entry.singleKey===true});}
   }
   if(!(provider.activeContexts instanceof Set)||provider.activeContexts.size>64)throw Error('Native active contexts changed');
   const scopes=[];let target=owner.focusManager?.activeElement;
   for(let node=target;node;node=node.parentNode){if(scopes.length>=64)throw Error('Native active scope bound');scopes.push({node:text(node.nodeName),scope:node.attributes?.keybindingScope===undefined?null:text(node.attributes.keybindingScope),textEntry:node.attributes?.textEntry===true});}
   const context=runtime.ey().toolContext(new AbortController()),state=context.getAppState(),open=context.dialogStore.getState().open;
   if(!Array.isArray(open)||open.length>64)throw Error('Native dialog registry bound');
   const sample={swallowAll:provider.keyHandlerRegistry?.swallowAll?.size??null,preemptiveScopes:[...(provider.keyHandlerRegistry?.preemptiveScopes?.keys()??[])].map(text),expandedView:typeof state.expandedView==='string'?text(state.expandedView):null,dialogCount:open.length,fibers:seen.size,bindings,handlers,activeContexts:[...provider.activeContexts].map(text),pendingChord:provider.pendingChordRef?.current===null?null:chord(provider.pendingChordRef?.current),scopes,nativeKeyboardEventAvailable:typeof events.zDe==='function',nativeDiscreteDispatchAvailable:typeof events.R8?.dispatchDiscrete==='function',nativeRootKeyboardDispatchAvailable:typeof owner.dispatchKeyboardEvent==='function'};
   const key=JSON.stringify({...sample,fibers:undefined});if(key!==previous&&samples.length<32){previous=key;samples.push(sample);save();}
  }catch(error){clearInterval(timer);restoreDispatch();restoreReplies();save(error);}finally{busy=false;}
 },100);timer.unref();
}
`;
}
