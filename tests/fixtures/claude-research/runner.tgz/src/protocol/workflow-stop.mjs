import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel,WORKFLOW_WAIT_SCRIPT} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** An inert promise keeps only the local fixture task pending until a specific stop. */
export async function probeWorkflowStop(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'workflow-stop-')),home=join(workspace,'home'),temporary=join(workspace,'tmp');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(temporary,{mode:0o700});
 const model=await startSyntheticModel(workspace,'WorkflowWait'),run=await createRun(output,'workflow-stop',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),scriptSha256:hash(Buffer.from(WORKFLOW_WAIT_SCRIPT))});
 const first='11111111-1111-4111-8111-111111111111',next='22222222-2222-4222-8222-222222222222',tasks=[],results=[],replies=[],permissions=[];let pending='',taskId,stopping=false,followup=false;
 const control=(id,task)=>JSON.stringify({type:'control_request',request_id:id,request:{subtype:'stop_task',task_id:task}})+'\n';
 const input=(id,text)=>JSON.stringify({type:'user',uuid:id,message:{role:'user',content:text}})+'\n';
 try{
  const transport=await record({executable,cwd:workspace,output,timeoutMs:30000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--replay-user-messages','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--strict-mcp-config','--permission-mode','default','--tools','default','--model','default','--no-session-persistence','--max-turns','4'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),CLAUDE_CODE_TMPDIR:temporary,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[JSON.stringify({type:'control_request',request_id:'init',request:{subtype:'initialize'}})+'\n'],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type==='control_response'){
     const r=value.response;if(r?.request_id==='init'){assert.equal(r.subtype,'success');channel.send(input(first,'Launch only the fixed inert local Workflow fixture.'));}
     if(['missing','stop','repeat'].includes(r?.request_id)){assert.equal(r.subtype,'success');assert.deepEqual(r.response,{});replies.push({request:r.request_id,response:r.response});if(r.request_id==='missing')channel.send(control('stop',taskId));if(r.request_id==='stop')channel.send(control('repeat',taskId));}
    }
    if(value.type==='control_request'&&value.request?.subtype==='can_use_tool'){
     assert.equal(value.request.tool_name,'Workflow');assert.equal(value.request.input.script,WORKFLOW_WAIT_SCRIPT);permissions.push(value.request.tool_name);channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:{behavior:'allow',updatedInput:value.request.input}}})+'\n');
    }
    if(value.type==='system'&&['task_started','task_progress','task_notification'].includes(value.subtype)){
     tasks.push(value);if(value.subtype==='task_started'){assert.equal(value.task_type,'local_workflow');taskId=value.task_id;}
     if(value.subtype==='task_progress'&&!stopping){assert.equal(value.task_id,taskId);stopping=true;channel.send(control('missing','unknown-research-workflow'));}
    }
    if(value.type==='result'){results.push(value);if(value.user_message_uuid===next)channel.closeInput();}
    if(!followup&&results.length&&replies.some(r=>r.request==='repeat')&&tasks.some(t=>t.subtype==='task_notification'&&t.status==='stopped')){followup=true;channel.send(input(next,'Return only the fixed text fixture; do not use tools.'));}
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(permissions.length,1);assert.deepEqual(replies.map(r=>r.request),['missing','stop','repeat']);assert.equal(tasks.filter(t=>t.subtype==='task_started').length,1);assert.equal(tasks.filter(t=>t.subtype==='task_notification'&&t.status==='stopped').length,1);assert.ok(followup);assert.ok(results.some(r=>r.user_message_uuid===next&&r.subtype==='success'&&!r.is_error));assert.equal(new Set(results.map(r=>r.session_id)).size,1);assert.ok(model.calls.length<=4);
  const evidence=JSON.parse(JSON.stringify({replies,tasks,results,modelCalls:model.calls.length,sameSession:true,followupAccepted:true,realModelRequests:0,qualification:'Fixed inert local Workflow task; missing/repeated stop acknowledgements are not stop proof. Stopped notification and correlated next host result establish this case only; app/UI, other tasks and races remain separate.'}).split(workspace).join('${WORKSPACE}'));
  await writeFile(join(run.directory,'workflow-stop.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}finally{await model.close();}
}
