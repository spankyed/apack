import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { hash } from '../artifacts/runs.mjs';

/** Verify saved original receipts; transport completion alone never establishes media support. */
export async function verifyNativeDocumentMedia(directory, { requireSettled = true, requireSourceRefusals = false } = {}) {
  const bytes = await readFile(join(directory, 'document-media.json'));
  const evidence = JSON.parse(bytes), manifest = JSON.parse(await readFile(join(directory, 'manifest.json'), 'utf8'));
  const expected = Buffer.from('Document byte fixture: café\n第二行\n');
  const target = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10';
  assert.equal(manifest.status, 'complete'); assert.equal(manifest.code, 0); assert.equal(manifest.signal, null);
  assert.equal(manifest.host.platform, 'linux'); assert.equal(manifest.inputs.targetSha256, target); assert.equal(evidence.targetSha256, target);
  assert.equal(evidence.initialization.subtype, 'success'); assert.equal(evidence.result.subtype, 'success');
  assert.deepEqual(evidence.unexpected, []); assert.equal(evidence.calls.length, 1); assert.equal(evidence.realModelRequests, 0);
  const { managed, ordinary, settled } = evidence.observations;
  assert.equal(managed.rows.length, requireSourceRefusals ? 5 : 2);
  const ids = managed.rows.map(row => row.id);
  assert.equal(new Set(ids).size, requireSourceRefusals ? 5 : 2); assert(ids.every(id => typeof id === 'string' && id.length > 0));
  for (const { result } of managed.rows.slice(0, 2)) {
    assert.equal(result.type, 'document'); assert.equal(result.mediaType, 'text/plain'); assert.equal(result.size, expected.length);
    assert.equal(result.base64, expected.toString('base64'));
  }
  const deny = value => { assert.equal(typeof value.deny, 'string'); assert(value.deny.length > 0); assert.equal(value.base64, undefined); assert.equal(value.bytes, undefined); };
  deny(managed.unlisted); deny(ordinary.unlisted);
  if (requireSourceRefusals) {
    assert.equal(evidence.sourceRefusals, true);
    assert.deepEqual(evidence.input.slice(3).map(block => block.source.type), ['url', 'file', 'content']);
    for (const row of managed.rows.slice(2)) deny(row.result);
  }
  assert.deepEqual(ordinary.rows.map(row => row.id), ids);
  for (const row of ordinary.rows) deny(row.result);
  if (requireSettled) {
    assert.deepEqual(settled.rows.map(row => row.id), ids);
    for (const row of settled.rows) deny(row.result);
  }
  return { verified: true, targetSha256: target, evidenceSha256: hash(bytes), verifierSha256: hash(await readFile(new URL(import.meta.url))),
    documents: 2, bytesPerDocument: expected.length, managedBytesExact: true, ordinaryAndUnlistedDenied: true,
    settledDenied: requireSettled, sourceRefusals: requireSourceRefusals, nativeExit: 0, syntheticRequests: 1, realModelRequests: 0,
    limits: ['No app upload/UI acceptance', ...requireSourceRefusals ? [] : ['No URL/file/nested-source acceptance'], 'Private policy mapping is not OS/MDM acceptance'] };
}
