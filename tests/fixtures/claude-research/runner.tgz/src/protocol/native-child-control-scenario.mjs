import {genericPermissionSteps} from './native-generic-permission-fixture.mjs';
import {toolPermissionSteps} from './native-tool-permission-fixture.mjs';
import {nativeNotebookSteps} from './native-notebook-edit-fixture.mjs';
import {join} from 'node:path';

/** Four bounded original interactions: parent question, child deny/allow, child question. */
export function nativeChildControlStep(body, workspace) {
 const text=(body.messages??[]).flatMap(message=>typeof message.content==='string'?[message.content]:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text):[]).join('\n');
 const stage=Number(text.match(/ResearchChildControl[1234]/g)?.at(-1)?.slice(-1));
 if(!stage)return;
 const question=stage===1||stage===4,name=question?'AskUserQuestion':'Bash',id='toolu_child_control_'+stage;
 if(!body.tools?.some(tool=>tool.name===name))return;
 const results=(body.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[]);
 const result=results.find(block=>block.tool_use_id===id);
 const quote=value=>"'"+value.replaceAll("'","'\"'\"'")+"'";
 const command="/usr/bin/printf 'release review approved\\n' > "+quote(join(workspace,'release-review-approved.txt'));
 const input=question?{questions:[{question:'Which release branch should be reviewed first?',header:'Release review',options:[{label:'Stable',description:'Review the current release'},{label:'Next',description:'Review the upcoming release'}],multiSelect:false}]}:{command,description:'Write the approved release marker'};
 return {stage,id,result,block:result?{type:'text',text:'Release review recorded.'}:{type:'tool_use',id,name,input}};
}

/** File decisions use original Write/Read/Edit tools, never synthesized disk effects. */
export function nativeChildFileStep(body, workspace) {
 const messages=body.messages??[];
 const text=messages.flatMap(message=>typeof message.content==='string'?[message.content]:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text):[]).join('\n');
 const stage=Number(text.match(/ResearchChildFile[123]/g)?.at(-1)?.slice(-1));
 if(!stage)return;
 const results=messages.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[]);
 const file_path=join(workspace,'release-review.md');
 const readId='toolu_child_file_read',id='toolu_child_file_'+stage;
 const result=results.find(block=>block.tool_use_id===id);
 const read=results.find(block=>block.tool_use_id===readId);
 // Edit must follow an original successful Read; a failed read ends the fixture.
 const needsRead=stage===3&&!read;
 const name=needsRead?'Read':stage===3?'Edit':'Write';
 if(!body.tools?.some(tool=>tool.name===name))return;
 if(stage===3&&read?.is_error)return {stage,id,result:read,block:{type:'text',text:'Release review could not be read.'}};
 const input=needsRead?{file_path}:stage===3?{file_path,old_string:'Status: pending',new_string:'Status: reviewed'}:{file_path,content:'# Release review\n\nStatus: pending\n'};
 return {stage,id:needsRead?readId:id,result,block:result?{type:'text',text:'Release file decision recorded.'}:{type:'tool_use',id:needsRead?readId:id,name,input}};
}

/** Original Workflow decisions followed by explicit plan-entry decisions. */
export function nativeChildWorkflowStep(body) {
 const messages=body.messages??[];
 const text=messages.flatMap(message=>typeof message.content==='string'?[message.content]:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text):[]).join('\n');
 const stage=Number(text.match(/ResearchChildWorkflow[1234]/g)?.at(-1)?.slice(-1));
 if(!stage)return;
 const name=stage<=2?'Workflow':'EnterPlanMode',id='toolu_child_workflow_'+stage;
 if(!body.tools?.some(tool=>tool.name===name))return;
 const results=messages.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[]),result=results.find(block=>block.tool_use_id===id);
 const script='export const meta = {name: "release-review", description: "Review release checklist", phases: [{title:"Review"}]};\nphase("Review");\nlog("RELEASE_REVIEW_CHECKED");\nreturn {reviewed:true,marker:"RELEASE_REVIEW_CHECKED"};\n';
 return {stage,id,result,block:result?{type:'text',text:'Release workflow decision recorded.'}:{type:'tool_use',id,name,input:name==='Workflow'?{script}:{}}};
}

export const CHILD_REVIEW_PLAN = '# Release review plan\n\n1. Review the release notes.\n2. Confirm the selected branch.\n3. Report the review outcome.\n';
/** Write only the plan file advertised by the original native planning reminder. */
export function nativeChildPlanStep(body, planDirectory) {
 const messages=body.messages??[];
 const text=messages.flatMap(message=>typeof message.content==='string'?[message.content]:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text):[]).join('\n');
 const stage=Number(text.match(/ResearchChildPlan[123]/g)?.at(-1)?.slice(-1));
 if(!stage)return;
 const results=messages.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[]);
 const id='toolu_child_plan_'+stage,result=results.find(block=>block.tool_use_id===id),writeId='toolu_child_plan_write';
 if(result)return {stage,id,result,block:{type:'text',text:'Release plan decision recorded.'}};
 let name=stage===1?'EnterPlanMode':'ExitPlanMode',input={};
 if(stage===2&&!results.some(block=>block.tool_use_id===writeId)){
  const candidates=[...new Set((JSON.stringify(body).match(/\/[A-Za-z0-9_./-]+\/plans\/[A-Za-z0-9_-]+\.md/g)??[]).filter(path=>path.startsWith(planDirectory+'/')&&path.slice(planDirectory.length+1).match(/^[A-Za-z0-9_-]+\.md$/)))];
  if(candidates.length!==1)throw Error('Expected one original advertised plan path in the disposable plan directory');
  name='Write';input={file_path:candidates[0],content:CHILD_REVIEW_PLAN};
 }else if(stage>1)input={allowedPrompts:[]};
 const written=results.find(block=>block.tool_use_id===writeId);
 if(stage===2&&written?.is_error)throw Error('Original plan Write failed');
 if(!body.tools?.some(tool=>tool.name===name))throw Error('Original planning tool unavailable: '+name);
 return {stage,id:name==='Write'?writeId:id,block:{type:'tool_use',id:name==='Write'?writeId:id,name,input}};
}

/** Child notebook steps stop on a failed original Read and never synthesize notebook effects. */
export function nativeChildNotebookStep(body,workspace) {
 const messages=body.messages??[];
 const text=messages.flatMap(message=>typeof message.content==='string'?[message.content]:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text):[]).join('\n');
 const stage=Number(text.match(/ResearchChildNotebook[1234]/g)?.at(-1)?.slice(-1));
 if(!stage)return;
 const results=messages.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[]);
 const steps=nativeNotebookSteps(workspace),read=results.find(block=>block.tool_use_id===steps[0].id);
 const requiresRead=stage===1||stage===4;
 const step=requiresRead&&!read?steps[0]:stage===4?{...steps[3],id:"native_notebook_delete_approved"}:steps[stage];
 if(requiresRead&&read?.is_error)return {stage,id:read.tool_use_id,result:read,block:{type:'text',text:'The notebook could not be read; no edit was attempted.'}};
 if(!body.tools?.some(tool=>tool.name===step.name))return;
 const result=results.find(block=>block.tool_use_id===step.id);
 return {stage,id:step.id,result,block:result?{type:'text',text:'Notebook review decision recorded.'}:{type:'tool_use',...step}};
}

/** Child permission decisions retain original tool discovery and tool outcomes. */
export function nativeChildPermissionStep(body) {
 const messages=body.messages??[],text=messages.flatMap(message=>typeof message.content==='string'?[message.content]:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text):[]).join('\n');
 const stage=Number(text.match(/ResearchChildPermission[1234]/g)?.at(-1)?.slice(-1));if(!stage)return;
 const steps=[toolPermissionSteps[0],toolPermissionSteps[1],toolPermissionSteps[3],toolPermissionSteps[4]],step=steps[stage-1];
 const input=step.tool==='Skill'?{skill:'research-child-'+step.input.skill}:step.input;
 const results=messages.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[]),id='native_child_permission_'+stage,result=results.find(block=>block.tool_use_id===id);
 const searchId='native_child_permission_search_'+stage,search=results.find(block=>block.tool_use_id===searchId);
 if(result)return {stage,id,result,block:{type:'text',text:'Release permission review recorded.'}};
 if(search?.is_error)return {stage,id:searchId,result:search,block:{type:'text',text:'Original tool discovery failed; no permission tool was attempted.'}};
 if(!body.tools?.some(tool=>tool.name===step.tool)&&!search){if(!body.tools?.some(tool=>tool.name==='ToolSearch'))throw Error('Original permission tool discovery unavailable');return{stage,id:searchId,block:{type:'tool_use',id:searchId,name:'ToolSearch',input:{query:'select:'+step.tool,max_results:1}}};}
 return {stage,id,block:{type:'tool_use',id,name:step.tool,input}};
}

/** Original generic/MCP permission inputs include real structured and withheld requests. */
export function nativeChildGenericStep(body) {
 const messages=body.messages??[],text=messages.flatMap(message=>typeof message.content==='string'?[message.content]:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text):[]).join('\n');
 const stage=Number(text.match(/ResearchChildGeneric[12345]/g)?.at(-1)?.slice(-1));if(!stage)return;
 const step=genericPermissionSteps[stage-1],id='native_child_generic_'+stage;
 const results=messages.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[]),result=results.find(block=>block.tool_use_id===id);
 if(result)return {stage,id,result,block:{type:'text',text:'Connected release review decision recorded.'}};
 const searchId='native_child_generic_search_'+stage,search=results.find(block=>block.tool_use_id===searchId);
 if(search?.is_error)return {stage,id:searchId,result:search,block:{type:'text',text:'Original connected tool discovery failed; no tool was attempted.'}};
 if(!body.tools?.some(tool=>tool.name===step.tool)&&!search){if(!body.tools?.some(tool=>tool.name==='ToolSearch'))throw Error('Original MCP tool discovery unavailable');return{stage,id:searchId,block:{type:'tool_use',id:searchId,name:'ToolSearch',input:{query:'select:'+step.tool,max_results:1}}};}
 return {stage,id,block:{type:'tool_use',id,name:step.tool,input:step.input}};
}
