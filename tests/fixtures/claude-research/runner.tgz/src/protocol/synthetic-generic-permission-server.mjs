import { appendFileSync } from 'node:fs';
import { createInterface } from 'node:readline';
import { genericPermissionDescription } from './native-generic-permission-fixture.mjs';
// Disposable stdio MCP server: no sockets, subprocesses or user-file access.
createInterface({ input: process.stdin }).on('line', line => {
  let request;try { request = JSON.parse(line); } catch { return; }
  if (process.env.APACK_MCP_RECEIPT) appendFileSync(process.env.APACK_MCP_RECEIPT, JSON.stringify({ pid: process.pid, method: request.method, tool: request.params?.name, arguments: request.params?.arguments })+'\n');
  if(request.id===undefined)return;
  let result;
  switch(request.method){
    case 'initialize': result={protocolVersion:request.params?.protocolVersion??'2024-11-05',capabilities:{tools:{}},serverInfo:{name:'research-release-review',version:'1.0.0'}};break;
    case 'ping':result={};break;
    case 'tools/list':result={tools:[{name:'echo',description:genericPermissionDescription,inputSchema:{type:'object',properties:{message:{type:'string'},count:{type:'number'},flags:{type:'object',properties:{preserveOriginal:{type:'boolean'}}},deadline:{type:'string',format:'date-time'}},required:['message']}}]};break;
    case 'tools/call':if(request.params?.name==='echo'&&typeof request.params?.arguments?.message==='string')result={content:[{type:'text',text:JSON.stringify(request.params.arguments)}]};break;
  }
  console.log(JSON.stringify({jsonrpc:'2.0',id:request.id,...(result===undefined?{error:{code:-32601,message:'Unsupported synthetic operation'}}:{result})}));
});
