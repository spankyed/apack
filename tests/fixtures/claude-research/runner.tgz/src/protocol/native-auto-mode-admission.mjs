import assert from 'node:assert/strict';
import {isAbsolute} from 'node:path';

/** Observe original Linux admission only; never set a flag, mount a dialog or write native settings. */
export function nativeAutoModeAdmissionObserver(outputPath, hashes) {
 assert.ok(isAbsolute(outputPath));
 const expectedNames=['E','ue','et','ID','DYe','ey','bse','S_','me'];
 assert.deepEqual(Object.keys(hashes).sort(),expectedNames.sort());
 for(const value of Object.values(hashes))assert.match(value,/^[a-f0-9]{64}$/);
 return `{
 const {readFileSync,writeFileSync}=await import('node:fs');
 const {createHash}=await import('node:crypto');
 const sha=value=>createHash('sha256').update(value).digest('hex');
 if(process.platform!=='linux'||sha(readFileSync(process.execPath))!=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10')throw Error('Pinned Linux auto-mode target required');
 const expected=${JSON.stringify(hashes)};let attempts=0,busy=false,last;
 const timer=setInterval(async()=>{if(busy)return;busy=true;try{
  if(++attempts>160){clearInterval(timer);writeFileSync(${JSON.stringify(outputPath+'.error')},JSON.stringify({attempts,error:last}));return;}
  const source=await import('/$bunfs/root/chunk-tm94jfk2.js');source.ue();
  const auto=await import('/$bunfs/root/chunk-a7b8k0bt.js');
  const config=await import('/$bunfs/root/chunk-m86ay9q5.js');
  const settings=await import('/$bunfs/root/chunk-x1ap3wr2.js');
  for(const [name,fn]of Object.entries({E:source.E,ue:source.ue,et:source.et,ID:source.ID,DYe:auto.DYe,ey:auto.ey,bse:auto.bse,S_:config.S_,me:settings.me})){
   if(typeof fn!=='function'||sha(Function.prototype.toString.call(fn))!==expected[name])throw Error('Original auto-mode admission changed: '+name);
  }
  const model=source.et(),nativeConfig=config.S_(),classifier=auto.DYe(),profile=source.ue();
  const sources=['userSettings','projectSettings','localSettings','flagSettings','policySettings'];
  const defaults=Object.fromEntries(sources.map(name=>[name,settings.me(name)?.permissions?.defaultMode??null]));
  const receipt={pid:process.pid,uid:process.getuid(),attempts,binarySha256:sha(readFileSync(process.execPath)),model,classifier,modelSupported:source.ID(model),autoModeAllowed:auto.ey(),setupSkillEligible:auto.bse(),envOnboarding:nativeConfig?.envOnboarding===true,nudgeCohort:source.E('tengu_maple_pier',true),hasCompletedOnboarding:profile.hasCompletedOnboarding===true,hasSeenAutoDefaultNudge:profile.hasSeenAutoDefaultNudge===true,defaults,functionHashes:expected,scope:'Original read-only admission inputs. No toolPermissionContext supplied; this does not establish hz/nudge eligibility or app acceptance. No native setters, config overrides, account/model requests or dialog producers called.'};
  writeFileSync(${JSON.stringify(outputPath)},JSON.stringify(receipt,null,2));clearInterval(timer);
 }catch(error){last=String(error);}finally{busy=false;}},50);timer.unref();
}`;
}
