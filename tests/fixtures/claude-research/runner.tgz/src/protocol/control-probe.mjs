import { record } from './record.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** Exercise non-model, read-only controls. No user prompt or credentials are supplied. */
export async function probeControls(executable, cwd, output) {
  const requests = [
    { subtype: 'initialize', hooks: {} },
    { subtype: 'get_context_usage', detail: 'summary' },
    { subtype: 'get_settings' },
    { subtype: 'get_status' },
    { subtype: 'background_tasks' },
    { subtype: 'mcp_status' },
    { subtype: 'get_hooks_listing' },
    { subtype: 'get_plan' },
    { subtype: 'list_permission_rules' },
    { subtype: 'get_binary_version' },
    { subtype: 'get_session_cost' },
    { subtype: 'list_models' },
    { subtype: 'get_memory_dialog' },
    { subtype: 'get_skills_dialog' },
    { subtype: 'get_sandbox_dialog' },
    { subtype: 'get_chrome_dialog' },
    { subtype: 'get_chrome_browsers' },
    { subtype: 'export_conversation' },
  ];
  let pending = '', next = 1;
  const responses = [];
  const message = index => JSON.stringify({ type: 'control_request', request_id: `research-${index}`,
    request: requests[index] }) + '\n';
  const run = await record({ executable, cwd, output, timeoutMs: 20000, input: [message(0)],
    args: ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json',
      '--bare', '--setting-sources', '', '--settings', '{}', '--strict-mcp-config', '--tools', '',
      '--no-session-persistence', '--permission-prompt-tool', 'stdio'],
    env: { PATH: process.env.PATH, HOME: cwd, CLAUDE_CONFIG_DIR: `${cwd}/.claude`,
      DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
    onStdout(bytes, transport) {
      pending += bytes.toString('utf8');
      while (pending.includes('\n')) {
        const at = pending.indexOf('\n');
        const line = pending.slice(0, at); pending = pending.slice(at + 1);
        let value; try { value = JSON.parse(line); } catch { continue; }
        if (value.type === 'control_response' && value.response?.request_id === `research-${next - 1}`) {
          responses.push({ request: requests[next - 1].subtype, outcome: value.response.subtype,
            error: value.response.error ?? null });
          if (next < requests.length) transport.send(message(next++));
          else transport.closeInput();
        }
      }
    },
  });
  const complete = responses.length === requests.length;
  await writeFile(join(run.directory, 'control-summary.json'), JSON.stringify({
    expectedResponses: requests.length, complete, responses }, null, 2) + '\n');
  if (!complete && run.status === 'complete') {
    const path = join(run.directory, 'manifest.json');
    const manifest = JSON.parse(await readFile(path, 'utf8'));
    Object.assign(manifest, { status: 'failed', reason: 'missing-control-responses' });
    await writeFile(path, JSON.stringify(manifest, null, 2) + '\n');
    return { ...run, status: 'failed', reason: 'missing-control-responses' };
  }
  return { ...run, responses: responses.length };
}
