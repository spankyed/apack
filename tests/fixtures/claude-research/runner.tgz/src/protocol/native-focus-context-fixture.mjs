/** Read only the original committed duration renderer's message facts. */
export function nativeFocusContextObserver(path){return `{
 const {writeFileSync}=await import('node:fs'),{createHash}=await import('node:crypto'),roots=await import('/$bunfs/root/chunk-pg10s5g1.js');
 const hashes=new WeakMap(),deadline=Date.now()+100000;let previous;
 const timer=setInterval(()=>{if(Date.now()>deadline){clearInterval(timer);return}try{const pending=[roots.ai().get(process.stdout)?.container?.current],seen=new Set(),frames=[];let display;
 while(pending.length){const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('Native focus traversal exceeds bound');seen.add(fiber);
 if(typeof fiber.type==='function'&&fiber.type.name==='Eg'){let hash=hashes.get(fiber.type);if(!hash){hash=createHash('sha256').update(Function.prototype.toString.call(fiber.type)).digest('hex');hashes.set(fiber.type,hash)}if(hash!=='bae302522b9c14ab6c8c71b843f47f1c52e70b334e7a32d51b1f9e8c4132e451')throw Error('Original duration renderer changed');const message=fiber.memoizedProps?.message;if(message?.type==='system'&&message.subtype==='turn_duration')frames.push({uuid:message.uuid,hiddenCount:message.briefHiddenCount??0,durationMs:message.durationMs});}
 if(typeof fiber.type==='function'&&fiber.type.name==='Xx'&&fiber.memoizedProps?.screen!=='transcript'){let hash=hashes.get(fiber.type);if(!hash){hash=createHash('sha256').update(Function.prototype.toString.call(fiber.type)).digest('hex');hashes.set(fiber.type,hash)}if(hash!=='c9216d60891ddbee9f6c3b4b737f771eda26ce91860b0a6d92aecb21e4490477')throw Error('Original transcript selector changed');const cache=fiber.updateQueue?.memoCache?.data?.[0],copy=rows=>rows?.slice(0,256).map(row=>({uuid:row.uuid,type:row.type,...row.agentCount!==undefined?{agentCount:row.agentCount}:{},...row.bashCount!==undefined?{bashCount:row.bashCount}:{},...row.thoughtForMs!==undefined?{thoughtForMs:row.thoughtForMs}:{},...typeof row.latestThinkingSummary==='string'?{latestThinkingSummary:row.latestThinkingSummary.slice(0,2048)}:{},...row.subtype?{subtype:row.subtype}:{},...Array.isArray(row.messages)?{members:row.messages.map(member=>({uuid:member.uuid,type:member.type}))}:{}}));if(Array.isArray(cache?.[56])&&Array.isArray(cache?.[83])&&Array.isArray(cache?.[85]))display={conversationId:fiber.memoizedProps.conversationId,active:cache[56]!==cache[83],base:copy(cache[56]),selected:copy(cache[83]),rows:copy(cache[85])};}
 if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);}
 const next=JSON.stringify({readOnly:true,frames,display});if(next!==previous){writeFileSync(${JSON.stringify(path)},next,{mode:0o600});previous=next}
 }catch(error){writeFileSync(${JSON.stringify(path)},JSON.stringify({readOnly:true,error:String(error)}),{mode:0o600})}},100);timer.unref();
 }`;}

/** Observe original task/notification admission without modifying its queue or registry. */
export function nativeQueuedCompletionObserver(path){return `{
 const {writeFileSync}=await import('node:fs'),runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),rendering=await import('/$bunfs/root/chunk-r2k35jby.js');
 const snapshots=[];let previous,binding;const deadline=Date.now()+100000;
 const timer=setInterval(()=>{if(Date.now()>deadline){clearInterval(timer);return}try{
  binding??=runtime.ey();if(binding?.surface!=='terminal')return;
  const context=binding.toolContext(new AbortController()),all=context.taskRegistry.all(),queued=context.messageQueue.getCommandQueueSnapshot();
  const tasks=Object.values(all).map(task=>({id:task.id,type:task.type,status:task.status,notified:task.notified,isBackgrounded:task.isBackgrounded})),queue=queued.map(command=>({mode:command.mode,taskId:command.taskId}));
  if(tasks.length>256||queue.length>256)throw Error('Native queue observation exceeds bound');
  const counts=rendering.bDe({tasks:all,queuedCommands:queued}),next=JSON.stringify({tasks,queue,counts});if(next===previous)return;previous=next;
  if(snapshots.length>=128)throw Error('Native queue snapshot limit');snapshots.push({at:Date.now(),tasks,queue,counts});writeFileSync(${JSON.stringify(path)},JSON.stringify({readOnly:true,snapshots}),{mode:0o600});
 }catch(error){writeFileSync(${JSON.stringify(path)},JSON.stringify({readOnly:true,error:String(error),snapshots}),{mode:0o600})}},50);timer.unref();
 }`;}
