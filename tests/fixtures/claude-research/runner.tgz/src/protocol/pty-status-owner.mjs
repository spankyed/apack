import { startNativeUiEngineProbe } from './native-ui-engine-bridge.mjs';
import { startTerminalPluginBridge } from './terminal-plugin-bridge.mjs';
import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { readFileSync, lstatSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { hash } from '../artifacts/runs.mjs';
import { record } from './record.mjs';
import { recognizeOnboardingPrompt } from './pty-onboarding.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

/** Establish same-session terminal status/conversation ownership before designing an app bridge. */
export async function probePtyStatusOwner(executable, parent, output, { bridgePrompt = false, bridgeApprovals = false, inspectRuntime = false, thinkingKind, mirrorStatus = false, nativeUiProbe = false } = {}) {
  assert.equal(process.platform, 'darwin');
  const targetSha256 = hash(await readFile(executable));
  assert.equal(targetSha256, '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');
  await mkdir(parent, { recursive: true });
  const workspace = await mkdtemp(join(parent, 'pty-status-owner-'));
  const inspectorSocket = inspectRuntime ? join(await mkdtemp('/private/tmp/cc-inspect-'), 'inspect.sock') : undefined;
  let inspectorSocketObserved = false;
  const uiEngineProbe = nativeUiProbe ? await startNativeUiEngineProbe(workspace) : undefined;
  const marker = join(workspace, 'status-invocations.jsonl');
  const helper = join(workspace, 'status-fixture.py');
  const helperSource = `import json,sys,time\npayload=json.load(sys.stdin)\nwith open(${JSON.stringify(marker)},'a') as output:\n    output.write(json.dumps({'input':payload,'at':time.time()})+chr(10))\nprint('NativeOwnerStatus '+payload['session_id'])\nprint('Second native status line')\n`;
  await writeFile(helper, helperSource);
  const helperCommand = `/usr/bin/python3 '${helper.replaceAll("'", "'\\''")}'`;
  const pluginBridge = bridgePrompt ? await startTerminalPluginBridge(workspace, { approvals: bridgeApprovals, observeNarration: !!thinkingKind, observeUiEngine: nativeUiProbe, ...(mirrorStatus ? { statusCommands: { [helperCommand]: 'main' } } : {}) }) : undefined;
  const model = await startSyntheticModel(workspace, bridgeApprovals ? 'Bash' : 'TextOnly', { maxRequests: 8, captureMessages: true, ...(thinkingKind ? { thinkingBlock: true, narration: thinkingKind === 'narration' } : {}), ...(bridgeApprovals ? { forceBash: true, bashPerInput: true } : {}) });
  const settings = { ...(bridgeApprovals ? { permissions: { ask: ['Bash'] } } : {}), apiKeyHelper: '/usr/bin/printf research-fixture-key', statusLine: { type: 'command', command: helperCommand, refreshInterval: 1, padding: 0 } };
  const bridge = fileURLToPath(new URL('./pty_bridge.py', import.meta.url));
  let terminal = '', theme = false, security = false, navigated = false, trusted = false, transport;
  let promptsSent = 0, exitKeys = 0, exitScheduled = false, transcriptRows = [], pollFailure;
  const timers = [];
  const payloads = () => { try { return readFileSync(marker, 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse); } catch (error) { if (error.code === 'ENOENT') return []; throw error; } };
  let nativeUiEngineResult;
  const sendPrompt = () => {
    const turn = ++promptsSent, text = bridgeApprovals ? `ResearchPermissionTurn${turn}: exercise the disposable fixture only.` : `Synthetic terminal owner turn ${turn}.`;
    if (!pluginBridge) { transport.send(text + '\r'); return; }
    void (async () => {
      if (uiEngineProbe && turn === 1) nativeUiEngineResult = await uiEngineProbe.probe();
      if (bridgeApprovals && turn === 2) {
        await writeFile(join(workspace, 'allowed-turn-output.txt'), await readFile(join(workspace, 'fixture.txt')));
        await writeFile(join(workspace, 'fixture.txt'), 'Denied turn must preserve this sentinel.');
      }
      await pluginBridge.preparePrompt(text); transport.send('\r');
    })().catch(error => { pollFailure = error; transport.stop('terminal-prompt-bridge-failure'); });
  };
  const poll = setInterval(() => {
    if (!transport || !trusted || exitKeys || pollFailure) return;
    try {
      if (inspectorSocket && !inspectorSocketObserved) { try { inspectorSocketObserved = lstatSync(inspectorSocket).isSocket(); } catch (error) { if (error.code !== 'ENOENT') throw error; } }
      const samples = payloads(), last = samples.at(-1)?.input;
      if (!last?.transcript_path) return;
      const transcript = resolve(last.transcript_path), local = relative(workspace, transcript);
      assert.ok(local && !local.startsWith('..') && !local.startsWith('/'), 'Transcript must belong to the private native owner');
      try { transcriptRows = readFileSync(transcript, 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse); } catch (error) { if (error.code === 'ENOENT') return; throw error; }
      const replies = transcriptRows.filter(row => row.type === 'assistant' && row.message?.content?.some(block => block.type === 'text' && block.text === 'Fixture completed.'));
      if (promptsSent === 1 && replies.length === 1) sendPrompt();
      if (promptsSent === 2 && replies.length === 2 && !exitScheduled) {
        exitScheduled = true;
        timers.push(setTimeout(() => { exitKeys++; transport.send('\x04'); }, 1400));
      }
    } catch (error) { pollFailure = error; transport.stop('terminal-owner-evidence-failure'); }
  }, 100);
  let run;
  try {
    run = await record({ executable: '/usr/bin/python3', cwd: workspace, output, timeoutMs: 30000,
      args: [bridge, executable, ...(pluginBridge ? ['--plugin-dir', pluginBridge.pluginRoot] : []), '--setting-sources', '', '--strict-mcp-config', '--tools', bridgeApprovals ? 'Bash' : '', ...(bridgeApprovals ? ['--permission-mode', 'default'] : []), '--settings', JSON.stringify(settings)],
      env: { ...(uiEngineProbe ? {BUN_OPTIONS:uiEngineProbe.bunOptions} : {}), ...(inspectorSocket ? { BUN_INSPECT: inspectorSocket } : {}), ...(pluginBridge?.statusPrefix ? { CLAUDE_CODE_SHELL_PREFIX: pluginBridge.statusPrefix.path } : {}), PATH: process.env.PATH, HOME: workspace, CLAUDE_CONFIG_DIR: join(workspace, '.claude'), TERM: 'xterm-256color', COLUMNS: '100', LINES: '30', ANTHROPIC_BASE_URL: model.url, DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
      onStdout(bytes, channel) {
        transport = channel; terminal += bytes.toString('utf8');
        const screen = recognizeOnboardingPrompt(terminal, workspace);
        const compact = terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '').replace(/\s/g, '');
        let input;
        if (screen === 'theme' && !theme) { theme = true; input = '\r'; }
        else if (screen === 'security-notes' && theme && !security) { security = true; input = '\r'; }
        else if (screen === 'workspace-trust' && !navigated) { navigated = true; input = '\x1b[B'; }
        else if (screen === 'workspace-trust-selected' && navigated && !trusted) { trusted = true; input = '\r'; }
        else if (trusted && !promptsSent && compact.includes('NativeOwnerStatus') && compact.includes('Secondnativestatusline')) { sendPrompt(); }
        else if (exitKeys === 1 && /pressctrl[+-]dagaintoexit/i.test(compact)) { exitKeys++; input = '\x04'; }
        if (input !== undefined) timers.push(setTimeout(() => channel.send(input), 150));
      } });
    if (pollFailure) throw pollFailure;
    assert.equal(run.status, 'complete'); assert.ok(model.calls.length >= 2 && model.calls.length <= 8); assert.equal(promptsSent, 2);
    const samples = payloads(), sessions = new Set(samples.map(row => row.input.session_id));
    assert.equal(sessions.size, 1); assert.ok(samples.length >= 2);
    const sessionId = samples[0].input.session_id;
    const users = transcriptRows.filter(row => row.type === 'user' && typeof row.message?.content === 'string' && row.message.content.startsWith(bridgeApprovals ? 'ResearchPermissionTurn' : 'Synthetic terminal owner turn '));
    const assistants = transcriptRows.filter(row => row.type === 'assistant' && row.message?.content?.some(block => block.type === 'text' && block.text === 'Fixture completed.'));
    assert.equal(users.length, 2); assert.equal(assistants.length, 2);
    assert.ok([...users, ...assistants].every(row => row.sessionId === sessionId));
    assert.ok(samples.every(row => row.input.cwd === workspace && row.input.version === '2.1.302'));
    const lastReplyAt = Date.parse(assistants.at(-1).timestamp) / 1000;
    const statusAfterConversation = samples.some(row => row.at > lastReplyAt && row.input.cost?.total_cost_usd > 0);
    assert.ok(statusAfterConversation, 'Native status must refresh after the second owned assistant reply');
    assert.ok(terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '').replace(/\s/g, '').includes('Fixturecompleted.'));
    await writeFile(join(run.directory, 'status-payloads.json'), JSON.stringify(samples, null, 2) + '\n');
    await writeFile(join(run.directory, 'owned-transcript-turns.json'), JSON.stringify([...users, ...assistants], null, 2) + '\n');
    if (bridgeApprovals) {
      assert.deepEqual(pluginBridge.permissionEvidence.map(item => item.decision), ['allow', 'deny']);
      assert.equal(await readFile(join(workspace, 'fixture.txt'), 'utf8'), 'Denied turn must preserve this sentinel.');
      assert.equal(await readFile(join(workspace, 'allowed-turn-output.txt'), 'utf8'), 'synthetic protocol fixture\n');
      const results = transcriptRows.flatMap(row => Array.isArray(row.message?.content) ? row.message.content : []).filter(block => block.type === 'tool_result');
      assert.equal(results.find(item => item.tool_use_id === 'toolu_research_fixture_1')?.is_error ?? false, false);
      assert.equal(results.find(item => item.tool_use_id === 'toolu_research_fixture_2')?.is_error, true);
    }
    let nativeSummaryFrames;
    if (thinkingKind) {
      nativeSummaryFrames=JSON.parse(await readFile(join(workspace,'terminal-message-frames.json'),'utf8')).filter(frame=>frame.isSummary===true);
      assert.equal(nativeSummaryFrames.length,thinkingKind === 'narration' ? 2 : 0);
      const thinkingRows=transcriptRows.filter(row=>row.type==='assistant'&&row.message?.content?.some(block=>block.type==='thinking'&&block.thinking?.startsWith('Synthetic thinking summary ')));assert.equal(thinkingRows.length,2);
      for(const frame of nativeSummaryFrames){assert.ok(frame.text.startsWith('Synthetic thinking summary '));assert.ok(transcriptRows.some(row=>row.uuid===frame.id&&row.message?.content?.some(block=>block.type==='thinking'&&block.signature==='Eg0KC0IJbmFycmF0aW9u')));}
      await writeFile(join(run.directory,'native-summary-producer.json'),JSON.stringify(nativeSummaryFrames,null,2)+'\n');
    }
    if(mirrorStatus){
      assert.ok(pluginBridge.nativeStatusEvidence.length >= 2, 'Native shell prefix must export refreshed status output');
      assert.ok(pluginBridge.nativeStatusEvidence.every(value => value.sessionId === sessionId && value.kind === 'main' && value.code === 0 && !value.truncated && value.stdout === 'NativeOwnerStatus '+sessionId+'\nSecond native status line\n'));
      await writeFile(join(run.directory,'native-status-export.json'),JSON.stringify(pluginBridge.nativeStatusEvidence,null,2)+'\n');
    }
    if(nativeUiProbe){await writeFile(join(run.directory,'native-terminal-ui-engine.json'),JSON.stringify(nativeUiEngineResult,null,2)+'\n');await writeFile(join(run.directory,'authored-ui-preload.mjs'),uiEngineProbe.source);assert.equal(JSON.parse(await readFile(join(workspace,'native-engine-clicks.json'),'utf8')).clicks,1);assert.ok(JSON.stringify(nativeUiEngineResult.after).includes('NativeTerminalUi 1'));}
    const evidence = { ...(nativeUiProbe ? {nativeUiEngineResult} : {}), ...(mirrorStatus ? { nativeStatusExport: true, nativeStatusExports: pluginBridge.nativeStatusEvidence.length, statusPrefix: pluginBridge.statusPrefix } : {}), ...(nativeSummaryFrames ? { nativeThinkingKind: thinkingKind, nativeSummaryProducer: thinkingKind === 'narration', nativeThinkingClassificationVerified: true, nativeSummaryFrames } : {}), targetSha256, driverSha256: hash(await readFile(new URL(import.meta.url))), bridgeSha256: hash(await readFile(bridge)), helperSha256: hash(Buffer.from(helperSource)), workspace, sessionId, promptsSent, syntheticApiRequests: model.calls.length, realModelRequests: 0, transcriptUsers: users.length, transcriptAssistants: assistants.length, statusAfterConversation, nativeStatusInvocations: samples.length, terminalStatusRendered: terminal.includes('NativeOwnerStatus'), multilineStatusRendered: terminal.replace(/\s/g, '').includes('Secondnativestatusline'), nativeExit: run.code, ...(inspectorSocket ? { inspectorSocket, inspectorSocketObserved } : {}), ...(pluginBridge ? { terminalPromptBridge: true, promptBridgeCommands: pluginBridge.evidence.length, pluginSourceSha256: pluginBridge.pluginSourceSha256, ...(bridgeApprovals ? { nativeDelegatedAllow: true, nativeDelegatedDeny: true, denyPreservedSentinel: true } : {}) } : {}), scope: pluginBridge ? 'Same terminal owner prompt bridge and native status proof; approval delegation only when explicitly selected. App status and subagent delivery remain unfinished.' : 'Same native terminal owner conversation/status proof only. No structured control bridge, app status delivery or subagent delivery is established.' };
    if (pluginBridge) { assert.equal(pluginBridge.evidence.length, 6); assert.ok(pluginBridge.evidence.every(item => item.sessionId === sessionId)); await writeFile(join(run.directory, 'terminal-bridge-evidence.json'), JSON.stringify({ commands: pluginBridge.evidence, permissions: pluginBridge.permissionEvidence }, null, 2) + '\n'); }
    await writeFile(join(run.directory, 'pty-status-owner.json'), JSON.stringify(evidence, null, 2) + '\n');
    return { ...run, ...evidence };
  } catch (error) {
    if (run) {
      const path = join(run.directory, 'manifest.json'), manifest = JSON.parse(await readFile(path, 'utf8'));
      await writeFile(path, JSON.stringify({ ...manifest, status: 'failed', verificationFailure: error.message }, null, 2) + '\n');
    }
    throw error;
  } finally { clearInterval(poll); for (const timer of timers) clearTimeout(timer); await writeFile(join(workspace, 'synthetic-calls.json'), JSON.stringify(model.calls, null, 2) + '\n'); if (run) await writeFile(join(run.directory, 'synthetic-calls.json'), JSON.stringify(model.calls, null, 2) + '\n'); await model.close(); if (pluginBridge) await pluginBridge.close(); }
}
