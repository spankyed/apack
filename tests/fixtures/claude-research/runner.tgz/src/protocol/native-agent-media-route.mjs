import assert from 'node:assert/strict';
import {isAbsolute} from 'node:path';
import {createHash} from 'node:crypto';
import {createNativeTestImage} from './native-test-image.mjs';

/** Read-only original draft/image observations; image admission itself uses native bracketed file paste. */
export function nativeAgentMediaRouteObserver(output){
 assert.ok(isAbsolute(output));
 return `{
 const fs=await import('node:fs'),{createHash}=await import('node:crypto');
 const sha=value=>createHash('sha256').update(value).digest('hex');
 if(process.platform!=='linux'||sha(fs.readFileSync(process.execPath))!=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10')throw Error('Pinned Linux Agent media observer required');
 let reading=false,previous='',count=0;
 const timer=setInterval(async()=>{if(reading||count>=100)return;reading=true;try{
  const runtime=await import('/$bunfs/root/chunk-a7b8k0bt.js'),roots=await import('/$bunfs/root/chunk-f7hx5xpd.js'),binding=runtime.Zh();
  if(binding?.surface!=='terminal')return;
  const context=binding.toolContext(new AbortController()),state=context.getAppState(),draft=await binding.composer.read();
  const stack=[roots.ai().get(process.stdout)?.container?.current],seen=new Set(),images=new Map();
  while(stack.length){const fiber=stack.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('Original input tree exceeds bound');seen.add(fiber);const props=fiber.memoizedProps;
   if(props?.multiline===true&&typeof props.getPastedContents==='function'&&typeof props.onImagePaste==='function')for(const item of Object.values(props.getPastedContents()??{}))if(item?.type==='image'&&typeof item.content==='string')images.set(item.id,{id:item.id,mediaType:item.mediaType,filename:item.filename,sourcePath:item.sourcePath,bytes:Buffer.from(item.content,'base64').length,sha256:sha(Buffer.from(item.content,'base64'))});
   if(fiber.sibling)stack.push(fiber.sibling);if(fiber.child)stack.push(fiber.child);
  }
  const value={pid:process.pid,taskId:state.viewingAgentTaskId??null,draft:draft.text,images:[...images.values()]},encoded=JSON.stringify(value);if(encoded!==previous){previous=encoded;count++;fs.appendFileSync(${JSON.stringify(output)},encoded+'\\n');}
 }catch(error){fs.writeFileSync(${JSON.stringify(output+'.error')},String(error));}finally{reading=false;}},50);timer.unref();
}`;
}

/** Native non-delivery is established from admitted bytes, worker requests and original journal, not an app flag. */
export function verifyNativeAgentMediaRoute(evidence,workerRows,shutdown){
 const sha=value=>createHash('sha256').update(value).digest('hex');
 assert.equal(evidence.targetSha256,'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');assert.equal(evidence.realModelRequests,0);assert.match(evidence.sessionId,/^[a-f0-9-]{36}$/);assert.equal(shutdown.nativePid,evidence.nativePid);assert.equal(shutdown.nativeExit,143);assert.equal(shutdown.ownerReleased,true);
 assert.deepEqual(evidence.receipts.map(row=>row.stage),['running','resumed']);
 const humans=workerRows.filter(row=>row.type==='user'&&row.origin?.kind==='human');assert.equal(humans.length,2);assert.equal(new Set(humans.map(row=>row.uuid)).size,2);
 const imageBlocks=value=>{if(!value||typeof value!=='object')return 0;return(value.type==='image'?1:0)+Object.values(value).reduce((sum,item)=>sum+(Array.isArray(item)?item.reduce((n,x)=>n+imageBlocks(x),0):imageBlocks(item)),0)};
 for(const[index,row]of evidence.receipts.entries()){
  const bytes=createNativeTestImage(index?[0,0,255,255]:[255,0,0,255]),digest=sha(bytes);assert.equal(row.imageSha256,digest);assert.equal(row.taskId,evidence.taskId);assert.equal(row.before.pid,evidence.nativePid);assert.equal(row.before.taskId,evidence.taskId);assert.equal(row.before.images.length,1);assert.equal(row.before.images[0].sha256,digest);assert.equal(row.before.images[0].bytes,bytes.length);assert.equal(row.before.images[0].mediaType,'image/png');assert.ok(row.before.images[0].sourcePath.endsWith('/'+row.stage+'.png'));assert.ok(row.before.draft.endsWith('[Image #'+row.before.images[0].id+']'));
  assert.ok(row.requests.length>0);assert.ok(row.requests.some(item=>item.call.child&&item.call.steeringObserved&&item.call.delivered));
  for(const item of row.requests){assert.ok(item.call.child);assert.ok(item.call.requestIndex>=row.requestIndex);assert.deepEqual(item.request,evidence.modelRequests[item.call.requestIndex]);assert.deepEqual(item.call,evidence.modelCalls.find(call=>call.requestIndex===item.call.requestIndex));assert.ok(JSON.stringify(item.request.messages).includes(row.before.draft));assert.equal(imageBlocks(item.request),0);assert.ok(!JSON.stringify(item.request).includes(bytes.toString('base64')));}
  assert.equal(row.imageBlocks,0);assert.equal(row.exactImageDelivered,false);assert.ok(humans[index].message.content.includes(row.before.draft));assert.equal(typeof humans[index].message.content,'string');assert.equal(imageBlocks(humans[index]),0);
 }
 return {verified:true,nativePasteAdmitted:true,originalWorkerJournal:true,humanUuids:humans.map(row=>row.uuid),runningImageBytesForwarded:false,resumedImageBytesForwarded:false,nativePid:evidence.nativePid,taskId:evidence.taskId,ownedShutdown:true,scope:'Pinned Linux selected local Agent with no tools: native file paste admits exact PNG bytes, but running/resumed worker requests and original human journal carry markers without image blocks. Not all Agents/providers or an app attachment UI acceptance.'};
}
