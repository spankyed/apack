import assert from 'node:assert/strict';
import { createServer } from 'node:http';

export const warmPrompt = 'Load the project release checklist into this conversation.';
export const idleSummary = 'The saved release checklist covers review, recovery, and publication.';
export const idleReply = 'The release checklist is ready.';

export async function startIdleCompactionModel() {
  const calls = [], errors = [];
  let warmed = false;
  async function respond(req, res) {
    const path = req.url?.split('?')[0];
    if (req.method !== 'POST' || !['/v1/messages', '/v1/messages/count_tokens'].includes(path)) {
      req.resume();
      res.writeHead(path === '/api/hello' ? 200 : 404);
      return res.end('{}');
    }
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      assert.ok(size <= 2 * 1024 * 1024, 'Inference request exceeded fixture limit');
      chunks.push(chunk);
    }
    const body = JSON.parse(Buffer.concat(chunks));
    if (path.endsWith('/count_tokens')) {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end('{"input_tokens":10}');
    }
    assert.ok(calls.length < 12, 'Inference request count exceeded fixture limit');
    const messages = JSON.stringify(body.messages ?? []);
    const t = [body.system, body.tools, body.messages].flatMap(value => Array.isArray(value) ? value : [])
      .flatMap(block => Array.isArray(block?.content) ? [block, ...block.content] : [block]);
    const cacheTtls = [...new Set(t.map(block => block?.cache_control?.ttl).filter(value => typeof value === 'string'))];
    const summarize = /create a detailed summary of the conversation|summarize the conversation|continuing development work without losing context/i.test(messages);
    const isWarmRequest = !warmed && messages.includes(warmPrompt) && Array.isArray(body.tools);
    if (isWarmRequest) {
      assert.ok(cacheTtls.includes('1h'), 'Original main request did not ask for one-hour prompt caching');
      warmed = true;
    }
    const usage = { input_tokens: 10, output_tokens: 5, cache_read_input_tokens: 0,
      cache_creation_input_tokens: isWarmRequest ? 110000 : 0,
      cache_creation: { ephemeral_1h_input_tokens: isWarmRequest ? 110000 : 0, ephemeral_5m_input_tokens: 0 } };
    calls.push({ path, toolNames: body.tools?.map(tool => tool.name), at: Date.now(),
      kind: summarize ? 'summary' : isWarmRequest ? 'warm' : 'reply', cacheTtls,
      receivedSummary: messages.includes(idleSummary), receivedWarmPrompt: messages.includes(warmPrompt), usage });
    const block = { type: 'text', text: summarize ? '<summary>' + idleSummary + '</summary>' : idleReply };
    const message = { id: 'msg_idle_review_' + calls.length, type: 'message', role: 'assistant', model: body.model,
      content: [block], stop_reason: 'end_turn', stop_sequence: null, usage };
    if (!body.stream) {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify(message));
    }
    res.writeHead(200, { 'content-type': 'text/event-stream' });
    const send = (type, payload) => res.write('event: ' + type + '\ndata: ' + JSON.stringify({ type, ...payload }) + '\n\n');
    send('message_start', { message: { ...message, content: [], stop_reason: null, usage: { ...usage, output_tokens: 0 } } });
    send('content_block_start', { index: 0, content_block: { type: 'text', text: '' } });
    send('content_block_delta', { index: 0, delta: { type: 'text_delta', text: block.text } });
    send('content_block_stop', { index: 0 });
    send('message_delta', { delta: { stop_reason: 'end_turn', stop_sequence: null }, usage });
    send('message_stop', {});
    res.end();
  }
  const server = createServer((req, res) => respond(req, res).catch(error => {
    errors.push(error.message);
    if (!res.headersSent) res.writeHead(400, { 'content-type': 'application/json' });
    res.end('{"error":{"type":"invalid_request_error","message":"Invalid owned fixture request"}}');
  }));
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  return { url: 'http://127.0.0.1:' + server.address().port, calls, errors,
    async close() {
      server.closeAllConnections();
      await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
    } };
}
