import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Verify saved app/native receipts without treating an outer metadata failure as a passing run. */
export async function verifyNativeSettingsBrokerLoss(root){
 const json=async file=>JSON.parse(await readFile(file,'utf8'));
 const names=await readdir(join(root,'workspaces'));assert.equal(names.length,1);const workspace=join(root,'workspaces',names[0]);
 const lines=async file=>(await readFile(join(workspace,file),'utf8')).trim().split('\n').map(JSON.parse);
 const proof=await json(join(workspace,'native-settings-broker-proof.json')),evidence=await json(join(workspace,'native-terminal-app-evidence.json'));
 assert.equal(evidence.nativeSettingsBrokerLoss,true);assert.equal(evidence.actualAppGui,true);assert.equal(evidence.sessionId,proof.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);assert.equal(evidence.reopenedNativePid,proof.freshPid);
 assert.notEqual(proof.old.input.panel.id,proof.fresh.input.panel.id);assert.notEqual(proof.boundNativePid,proof.freshPid);
 assert.equal(proof.afterStale.input.panel.id,proof.fresh.input.panel.id);assert.equal(proof.fresh.input.settings.snapshot.frame.selectedTab,'Config');assert.equal(proof.afterStale.input.settings.snapshot.frame.selectedTab,'Config');assert.equal(proof.staleRequests.length,2);assert.ok(!proof.staleRequests.includes(proof.afterStale.input.settings.requestId));assert.equal(proof.beforeReturn.turns,1);
 const text=node=>(node.text??'')+(node.content??[]).map(text).join('');assert.equal(text(proof.retained.doc),proof.draft);
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),prints=await lines('native-print-results.jsonl');assert.equal(children.length,5);assert.equal(children[1].pid,proof.boundNativePid);assert.equal(children[3].pid,proof.freshPid);
 assert.equal(proof.failure.kind,'broker');assert.equal(proof.failure.nativePid,proof.boundNativePid);assert.ok(proof.failure.retiredAt>=proof.failure.at);assert.ok(proof.failure.retiredAt<=children[2].at);assert.ok(children[2].args.includes('--no-session-persistence'));assert.ok(children[3].args.includes('--resume'));
 // Killing the broker can kill its native child before the launch wrapper records an exit.
 const recorded=children.filter(row=>row.pid!==proof.boundNativePid);assert.equal(exits.length,recorded.length);
 for(const child of recorded){const exit=exits.find(row=>row.pid===child.pid);assert.ok(exit);assert.ok([0,143].includes(exit.code));assert.ok(exit.at>=child.at)}
 for(const [before,after]of [[0,1],[2,3],[3,4]])assert.ok(exits.find(row=>row.pid===children[before].pid).at<=children[after].at);
 assert.equal(prints.length,2);assert.ok(prints.every(row=>row.sessionId===proof.sessionId));
 const journals=await readdir(join(workspace,'.claude/projects'),{recursive:true}),parent=journals.find(file=>file.endsWith('/'+proof.sessionId+'.jsonl'));assert.ok(parent);
 const rows=(await readFile(join(workspace,'.claude/projects',parent),'utf8')).trim().split('\n').map(JSON.parse);
 const humans=rows.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&typeof row.message?.content==='string'&&(!row.origin||row.origin.kind==='human'));
 assert.deepEqual(humans.map(row=>row.message.content),['Review the release notes for this project.','Continue the release review after reconnecting Settings.']);
 const cost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,prints.at(-1).totalCostUsd);assert.equal(cost,proof.final.claude.totalCostUsd);
 const app=await json(join(root,'app-query.stdout')),threads=app.threads.filter(row=>row.claude?.sessionId===proof.sessionId);assert.equal(threads.length,1);assert.equal(threads[0].claude.totalCostUsd,cost);assert.equal(threads[0].claude.chatState,'success');
 for(const row of humans){const matches=app.messages.filter(message=>message.sender==='user'&&message.context?.cliUuid===row.uuid);assert.equal(matches.length,1);assert.equal(matches[0].text,row.message.content)}
 const pictures=await readdir(join(workspace,'electron-results'),{recursive:true});assert.equal(proof.captures.length,6);
 for(const file of proof.captures){const matches=pictures.filter(path=>path.endsWith('/'+file));assert.equal(matches.length,1);const bytes=await readFile(join(workspace,'electron-results',matches[0]));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),file.endsWith('-680.png')?680:1100)}
 const calls=await json(join(workspace,'model-calls.json'));assert.equal(calls.seed.filter(row=>row.path==='/v1/messages?beta=true').length,2);assert.equal(calls.agent.length,0);
 assert.deepEqual(await json(join(root,'compiled-before.json')),await json(join(root,'compiled-after.json')));
 const boundary=await json(join(root,'offline-boundary.json'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);assert.equal(boundary.memory,6*1024**3);assert.equal(boundary.memorySwap,boundary.memory);assert.equal(boundary.nanoCpus,2*10**9);assert.deepEqual(Object.keys(boundary.networks),['none']);
 return {settingsBrokerRecovery:true,retiredPanelActionsIgnored:true,oldNativeDeathObservedBeforeReplacement:true,ownedNativeStarts:5,nativeExitRecords:exits.length,exactAppNativeHistory:true,appNativePrintCost:cost,screenshots:6,qualification:'App journey and independent saved verification pass; original outer run failed its missing scenario label. No claim of a passing outer replay.'};
}
