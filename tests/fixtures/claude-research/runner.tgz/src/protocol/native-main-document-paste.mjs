import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Native ordinary file paste is distinct from the already verified block-array document API. */
export async function verifyNativeMainDocumentPaste(root){
 const json=async path=>JSON.parse(await readFile(path,'utf8')),names=await readdir(join(root,'workspaces'));assert.equal(names.length,1);const workspace=join(root,'workspaces',names[0]);
 const route=await json(join(workspace,'route.json')),shutdown=await json(join(workspace,'shutdown.json')),boundary=await json(join(root,'offline-boundary.json'));
 assert.equal(route.targetSha256,'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');assert.equal(route.realModelRequests,0);
 assert.notEqual(route.nativePid,route.oldPid);assert.equal(route.before.pid,route.nativePid);assert.equal(route.before.taskId,null);assert.deepEqual(route.before.images,[]);
 assert.equal(route.fileSha256,'0210304d007600bb9168b221f50d2d2a52d711c9e3588bb4d3db4a78e0557c9b');assert.ok(route.file.endsWith('/release-notes.pdf'));assert.equal(route.before.draft,'Review this document: '+route.file);assert.equal(route.submission.text,route.before.draft);assert.deepEqual(route.submission.attachments,[]);
 const calls=route.modelCalls.filter(call=>call.path.startsWith('/v1/messages'));assert.equal(calls.length,1);
 const documents=value=>!value||typeof value!=='object'?0:(value.type==='document'?1:0)+Object.values(value).reduce((sum,item)=>sum+(Array.isArray(item)?item.reduce((n,x)=>n+documents(x),0):documents(item)),0);
 assert.equal(documents(calls[0].messages),0);assert.ok(calls[0].messages.some(row=>row.role==='user'&&Array.isArray(row.content)&&row.content.some(block=>block.type==='text'&&block.text===route.before.draft)));
 const files=await readdir(join(workspace,'.claude/projects'),{recursive:true}),journals=files.filter(file=>file.endsWith('/'+route.sessionId+'.jsonl'));assert.equal(journals.length,1);
 const rows=(await readFile(join(workspace,'.claude/projects',journals[0]),'utf8')).trim().split('\n').map(JSON.parse),humans=rows.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&(!row.origin||row.origin.kind==='human'));
 assert.equal(humans.length,2);assert.equal(humans[0].message.content,'Seed the owned document paste review.');assert.equal(humans[1].message.content,route.before.draft);assert.match(humans[1].uuid,/^[a-f0-9-]{36}$/);assert.notEqual(humans[0].uuid,humans[1].uuid);
 assert.equal(shutdown.nativePid,route.nativePid);assert.equal(shutdown.nativeExit,143);assert.equal(shutdown.ownerReleased,true);
 assert.equal(boundary.networkDisabled,true);assert.deepEqual(Object.keys(boundary.networks),['none']);assert.equal(boundary.pinnedExecutableReadOnly,true);assert.equal(boundary.memory,2*1024**3);assert.equal(boundary.memorySwap,boundary.memory);assert.equal(boundary.nanoCpus,2*10**9);
 return {verified:true,originalFilePasteIsPathText:true,originalPromptHookDocumentAttachments:0,originalModelDocumentBlocks:0,originalHumanUuid:humans[1].uuid,nativePid:route.nativePid,ownedShutdown:true,modelRequests:1,realModelRequests:0,scope:'Pinned Linux ordinary main-composer PDF path paste only. Other original block-array/remote/tool producers and app inline-document presentation are separate contracts.'};
}
