import assert from 'node:assert/strict';
/** Native results supply the saved path; never synthesize a native persistence result. */
export function nativeMcpPdfStep(body){
 const messages=body.messages??[],blocks=messages.flatMap(m=>Array.isArray(m.content)?m.content:[]),results=blocks.filter(b=>b.type==='tool_result');
 const result=results.find(b=>b.tool_use_id==='toolu_research_fixture');
 if(!result)return {type:'tool_use',id:'toolu_research_fixture',name:'mcp__research__echo',input:{message:'Return the release report PDF.'}};
 assert.notEqual(result.is_error,true);
 const texts=messages.flatMap(m=>m.role==='user'?(typeof m.content==='string'?[m.content]:m.content?.filter(b=>b.type==='text').map(b=>b.text)??[]):[]);
 if(texts.includes('Read the saved release report PDF.')){
  const read=results.find(b=>b.tool_use_id==='native_mcp_pdf_read');
  if(!read){const text=typeof result.content==='string'?result.content:result.content?.filter(b=>b.type==='text').map(b=>b.text).join('\n');const path=text?.match(/saved to (\/[^\s]+\.pdf)/)?.[1];assert.ok(path);assert.match(path,/^\/work\/\.claude-research\/profile-setup-app10\/app-data\/claude-code-profile\/config\/projects\/[^/]+\/[a-f0-9-]+\/tool-results\/[^/]+\.pdf$/);return {type:'tool_use',id:'native_mcp_pdf_read',name:'Read',input:{file_path:path}};}
  assert.notEqual(read.is_error,true);return {type:'text',text:'The saved release report is available for review.'};
 }
 return {type:'text',text:'The release report PDF has been saved.'};
}
