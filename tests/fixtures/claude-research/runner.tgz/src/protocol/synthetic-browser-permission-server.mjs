import assert from 'node:assert/strict';
import {appendFileSync,readFileSync,existsSync,statSync} from 'node:fs';
import {createInterface} from 'node:readline';
assert.equal(process.platform,'linux');assert.equal(process.getuid(),1000);assert.ok(existsSync('/.dockerenv'));
const output=process.env.APACK_BROWSER_APPROVAL_RECEIPTS;assert.match(output??'',/^\/work\/\.claude-research\/browser-permission-app[0-9]+\/mcp-receipts.jsonl$/);
const state=pid=>{const raw=readFileSync('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return{pid,start:fields[19],parent:Number(fields[1])}};
const self=state(process.pid),ancestry=[];let parent=process.ppid;for(let i=0;parent>1&&i<16;i++){const row=state(parent);ancestry.push(row);parent=row.parent;}
function record(value){let size=0;try{size=statSync(output).size}catch(error){if(error.code!=='ENOENT')throw error}assert.ok(size<1048576);appendFileSync(output,JSON.stringify({pid:process.pid,start:self.start,...value})+'\n',{mode:0o600});}
record({event:'start',ancestry});process.once('exit',code=>record({event:'exit',code}));process.once('SIGTERM',()=>process.exit(0));
createInterface({input:process.stdin}).on('line',line=>{
 if(Buffer.byteLength(line)>1048576)process.exit(65);let request;try{request=JSON.parse(line)}catch{return}record({event:'request',method:request.method,tool:request.params?.name,arguments:request.params?.arguments});if(request.id===undefined)return;
 let result;
 switch(request.method){
  case'initialize':result={protocolVersion:request.params?.protocolVersion??'2024-11-05',capabilities:{tools:{}},serverInfo:{name:'research-browser-approval-peer',version:'1.0.0'}};break;
  case'ping':result={};break;
  case'tools/list':result={tools:[{name:'navigate',description:'Synthetic browser approval contract: return the requested release URL without opening a browser, fetching a page, or reading user files.',inputSchema:{type:'object',properties:{url:{type:'string'}},required:['url'],additionalProperties:false}}]};break;
  case'tools/call':if(request.params?.name==='navigate'&&typeof request.params.arguments?.url==='string'){const url=new URL(request.params.arguments.url);assert.ok(['release-review.example','cancel-review.example'].includes(url.hostname));result={content:[{type:'text',text:'Original browser approval peer accepted '+url.href}]};}break;
 }
 process.stdout.write(JSON.stringify({jsonrpc:'2.0',id:request.id,...(result===undefined?{error:{code:-32601,message:'Unsupported browser approval fixture operation'}}:{result})})+'\n');
});
