import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Revalidate original saved native helper transport; never execute a configured command. */
export async function verifyAgentStatusRecovery(workspace){
 const json=async name=>JSON.parse(await readFile(join(workspace,name),'utf8'));
 const lines=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const proof=await json('native-window-agent-proof.json'),evidence=await json('native-terminal-app-evidence.json');
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.equal(proof.boundNativePid,evidence.boundNativePid);
 const transitions=proof.statusTransitions,posts=await lines('status-startup-posts.jsonl');
 assert.deepEqual(transitions.map(({width,mode})=>[width,mode]),[1100,680].flatMap(width=>['empty','normal','failure','normal'].map(mode=>[width,mode])));
 for(const transition of transitions){
  assert.equal(transition.taskId,proof.taskId);
  const receipts=transition.helperExits.filter(row=>row.kind==='subagent'&&row.parentPid===proof.boundNativePid&&row.sessionId===proof.sessionId&&row.httpStatus===200&&row.code===(transition.mode==='failure'?7:0));
  assert.ok(receipts.length,'Each transition needs an original native helper result');
  for(const receipt of receipts)assert.ok(posts.some(row=>JSON.stringify(row)===JSON.stringify(receipt)));
  if(transition.mode==='normal'){
   assert.ok(receipts.some(row=>row.stdout.split('\n').some(line=>{try{const value=JSON.parse(line);return value.id===proof.taskId&&value.content===transition.status}catch{return false}})));
   assert.ok(transition.status.includes('AppNativeAgent completed'));
  }else{
   assert.equal(transition.status,null);
   assert.ok(receipts.some(row=>transition.mode==='empty'?row.stdout==='':row.stdout.includes('FailedAgentHelperMustNotBecomeCaption')));
  }
 }
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl');
 assert.equal(children.length,3);
 for(const child of children)assert.ok(exits.some(row=>row.pid===child.pid));
 assert.equal(evidence.resumedPrintSameSession,true);assert.deepEqual(evidence.browserErrors,[]);
 return {statusTransitions:8,taskId:proof.taskId,sessionId:proof.sessionId,nativePid:proof.boundNativePid,ownedNativeExits:3,sameSessionRecovery:true};
}
