import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Explicit print-owner baseline; does not establish interactive task admission. */
export async function probeMcpTaskAdmission(executable,root,output){
 assert.equal(process.platform,'linux');assert.equal(hash(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 await mkdir(root,{recursive:true});const cwd=await mkdtemp(join(root,'mcp-task-')),home=join(cwd,'home'),receipt=join(cwd,'tasks.jsonl');await mkdir(home);
 const server=fileURLToPath(new URL('./owned-mcp-task-server.mjs',import.meta.url));
 const run=await createRun(output,'mcp-task-admission',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),serverSha256:hash(await readFile(server)),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),platform:process.platform,arch:process.arch,nodeVersion:process.version,scope:'Original print-owner baseline only',workspace:cwd});
 const model=await startSyntheticModel(cwd,'mcp__research__review',{mcpTaskScenario:'complete',captureMessages:true,maxRequests:4});
 let pending='',terminal;const results=[],permissions=[];
 try{
  const transport=await record({executable,cwd,output,timeoutMs:25000,maxBytes:1048576,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--strict-mcp-config','--mcp-config',JSON.stringify({mcpServers:{research:{type:'stdio',command:process.execPath,args:[server],env:{APACK_MCP_TASK_RECEIPT:receipt}}}}),'--tools','default','--permission-mode','default','--no-session-persistence','--max-turns','3','--permission-prompt-tool','stdio'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[JSON.stringify({type:'control_request',request_id:'initialize',request:{subtype:'initialize',hooks:{}}})+'\n'],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),line=pending.slice(0,at);pending=pending.slice(at+1);let v;try{v=JSON.parse(line);}catch{continue;}
    if(v.type==='control_response'&&v.response?.request_id==='initialize')channel.send(JSON.stringify({type:'user',message:{role:'user',content:'Run the owned task review once.'}})+'\n');
    if(v.type==='control_request'){if(v.request.subtype!=='can_use_tool')throw Error('Unexpected native control '+v.request.subtype);permissions.push(v.request);channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:v.request_id,response:{behavior:'allow',updatedInput:v.request.input}}})+'\n');}
    if(v.type==='user'&&Array.isArray(v.message?.content))results.push(...v.message.content.filter(x=>x.type==='tool_result'));
    if(v.type==='result'){terminal=v;channel.closeInput();}
   }
  }});
  const frames=(await readFile(receipt,'utf8')).trim().split('\n').map(JSON.parse),incoming=frames.filter(x=>x.direction==='in').map(x=>x.value),taskCalls=incoming.filter(x=>x.method==='tools/call'),polls=incoming.filter(x=>x.method==='tasks/get');
  assert.equal(taskCalls.length,1,'Must reach original tool once before any admission conclusion');assert.equal(results.length,1);assert.ok(terminal);assert.equal(transport.status,'complete');
  const evidence={scope:'Print-owner native task admission baseline; not terminal-owner or actual-app acceptance',transport:{status:transport.status,code:transport.code},terminal,permissions,results,taskCalls,polls,taskHandleOffered:frames.some(x=>x.direction==='out'&&x.value.result?.resultType==='task'),nativeTaskPollingObserved:polls.length>0,syntheticModelRequests:model.calls.length,realModelRequests:0};
  await writeFile(join(run.directory,'mcp-task-admission.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete'});return {directory:run.directory,...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}finally{await model.close();}
}
