import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { nativeManagedFiles } from './native-managed-files.mjs';

/** Private original policy discovery and local marketplace; never assign the native tier ourselves. */
export async function addNativeManagedMediaFixture(workspace, userPreload, ordinaryPlugin) {
  const marketplace=join(workspace,'media-marketplace'),plugin=join(marketplace,'plugins/managed-media'),policy=join(workspace,'media-policy');
  await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'),{recursive:true});await mkdir(policy,{recursive:true});
  await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:'media-research',owner:{name:'Private research'},plugins:[{name:'managed-media',source:'./plugins/managed-media',description:'Private original media contract fixture'}]}));
  await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'managed-media',version:'0.0.1'}));
  await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
  await writeFile(join(policy,'managed-settings.json'),JSON.stringify({extraKnownMarketplaces:{'media-research':{source:{source:'directory',path:marketplace}}},enabledPlugins:{'managed-media@media-research':true}}));
  await writeFile(userPreload,(await readFile(userPreload,'utf8'))+nativeManagedFiles({directory:policy,receipt:join(workspace,'managed-media-policy-reads.jsonl')}));
  await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('prompt.submit',async($,e,next)=>{const item=e.attachments?.find(item=>item.id&&item.type==='image');if(!item)return next(e);const listed=await $.prompt.media({id:item.id}),unlisted=await $.prompt.media({id:'unlisted_fixture'});await $.fs.write('native-managed-media.json',JSON.stringify({id:item.id,listed,unlisted}));return next(e);});on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const tree=await next(e);if(e.surface!=='desktop')return tree;const{Box,Button}=$.ui.resolve(e);return Box({children:[tree,Button({key:'media-receipt',label:'Review attachment access',onPress:async()=>{const receipt=JSON.parse(await $.fs.read('native-managed-media.json'));const result=await $.prompt.media({id:receipt.id});await $.fs.write('native-managed-media-settled.json',JSON.stringify(result));}})]});});}`);
  const file=join(ordinaryPlugin,'hooks/register.ts'),text=await readFile(file,'utf8'),needle='export function register(on){';
  if(!text.includes(needle))throw Error('Original ordinary media fixture changed');
  await writeFile(file,text.replace(needle,needle+`on('prompt.submit',async($,e,next)=>{const item=e.attachments?.find(item=>item.id&&item.type==='image');if(item)await $.fs.write('native-unmanaged-media.json',JSON.stringify({id:item.id,result:await $.prompt.media({id:item.id})}));return next(e);});`));
}
