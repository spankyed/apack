import {appendFileSync,readFileSync,existsSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';

/** Byte-oriented LSP framing; original native clients may split either headers or UTF-8 bodies. */
export function createLspDecoder(receive,{maxBytes=1048576}={}){
 let pending=Buffer.alloc(0),length;
 return chunk=>{
  pending=Buffer.concat([pending,Buffer.from(chunk)]);
  if(pending.length>maxBytes+4096)throw Error('Owned LSP input exceeded bound');
  while(pending.length){
   if(length===undefined){
    const end=pending.indexOf('\r\n\r\n');
    if(end<0){if(pending.length>4096)throw Error('Owned LSP header exceeded bound');return;}
    const headers=pending.subarray(0,end).toString('ascii').split('\r\n');
    const lengths=headers.filter(line=>/^content-length:/i.test(line));
    if(lengths.length!==1||!/^content-length: ?[0-9]+$/i.test(lengths[0]))throw Error('Invalid owned LSP content length');
    length=Number(lengths[0].split(':')[1].trim());
    if(!Number.isSafeInteger(length)||length<2||length>maxBytes)throw Error('Invalid owned LSP body size');
    pending=pending.subarray(end+4);
   }
   if(pending.length<length)return;
   const message=JSON.parse(pending.subarray(0,length).toString('utf8'));
   pending=pending.subarray(length);length=undefined;
   if(!message||typeof message!=='object'||Array.isArray(message)||message.jsonrpc!=='2.0')throw Error('Invalid owned LSP envelope');
   receive(message);
  }
 };
}
export function encodeLsp(message){const body=Buffer.from(JSON.stringify(message));return Buffer.concat([Buffer.from('Content-Length: '+body.length+'\r\n\r\n'),body]);}

/** Fixed language semantics for two private fixture documents; no filesystem or network operations. */
export function createOwnedLspProtocol(workspace,emit,record,exit,{beforeInitialize,beforeNavigation}={}){
 const source=pathToFileURL(join(workspace,'release.review')).href,target=pathToFileURL(join(workspace,'definitions.review')).href;
 const documents=new Map();let initialized=false,shutdown=false,requests=0;
 const range={start:{line:0,character:13},end:{line:0,character:20}};
 const notify=(method,params)=>emit({jsonrpc:'2.0',method,params});
 return message=>{
  const {id,method,params}=message;
  if(typeof method!=='string')throw Error('Owned LSP requires a client method');
  if(++requests>96)throw Error('Owned LSP request limit');
  record({method,id,uri:params?.textDocument?.uri,version:params?.textDocument?.version,position:params?.position});
  const reply=result=>{if(id!==undefined)emit({jsonrpc:'2.0',id,result});};
  const refuse=(code,text)=>{if(id!==undefined)emit({jsonrpc:'2.0',id,error:{code,message:text}});};
  if(method==='initialize'){
   if(beforeInitialize?.()===false)return;
   if(initialized){refuse(-32600,'Already initialized');return;}
   initialized=true;reply({capabilities:{textDocumentSync:1,definitionProvider:true,hoverProvider:true},serverInfo:{name:'owned-release-review-lsp',version:'1.0.0'}});return;
  }
  if(!initialized){refuse(-32002,'Server not initialized');return;}
  if(method==='exit'){exit(shutdown?0:1);return;}
  if(shutdown){refuse(-32600,'Server is shutting down');return;}
  if(method==='shutdown'){shutdown=true;reply(null);return;}
  if(method==='initialized'||method==='workspace/didChangeConfiguration'||method==='$/cancelRequest')return;
  const document=params?.textDocument;
  if(document&&![source,target].includes(document.uri)){refuse(-32602,'Document is outside the owned fixture');return;}
  if(method==='textDocument/didClose'){documents.delete(document?.uri);return;}
  if(method==='textDocument/didOpen'||method==='textDocument/didChange'){
   if(!document||!Number.isInteger(document.version)){refuse(-32602,'Document version required');return;}
   const prior=documents.get(document.uri);if(prior!==undefined&&document.version<=prior)return;
   documents.set(document.uri,document.version);
   if(document.uri===source){
    const diagnostics=[{range:{start:{line:1,character:0},end:{line:1,character:7}},severity:2,source:'owned-release-review-lsp',code:'REVIEW',message:'OwnedReleaseDiagnostic: review before publishing.'}];
    notify('textDocument/publishDiagnostics',{uri:source,version:document.version,diagnostics});
    notify('textDocument/publishDiagnostics',{uri:source,version:document.version-1,diagnostics:[{...diagnostics[0],message:'OwnedStaleDiagnostic: must not reach the model.'}]});
    record({event:'diagnostics',uri:source,currentVersion:document.version,staleVersion:document.version-1});
   }
   return;
  }
  if(method==='textDocument/definition'||method==='textDocument/hover'){
   if(!document||!documents.has(document.uri)||!Number.isInteger(params.position?.line)||params.position.line<0||!Number.isInteger(params.position?.character)||params.position.character<0){refuse(-32602,'Open owned document and valid position required');return;}
   const complete=()=>reply(method==='textDocument/definition'?[{uri:target,range}]:{contents:{kind:'markdown',value:'**release**: string\n\nOwnedReleaseDefinition'},range});
   if(beforeNavigation?.({id,method,complete})===false)return;
   complete();return;
  }
  refuse(-32601,'Unsupported owned LSP method');
 };
}

function main(){
 if(process.platform!=='linux'||!existsSync('/.dockerenv'))throw Error('Owned native LSP replay requires the Linux container');
 const [workspaceArg,owner]=process.argv.slice(2);if(!workspaceArg||!owner||process.argv.length!==4)throw Error('Explicit owned LSP workspace and identity required');
 const workspace=resolve(workspaceArg),marker=JSON.parse(readFileSync(join(workspace,'native-lsp-owner.json'),'utf8'));
 if(marker.owner!==owner||marker.workspace!==workspace)throw Error('Owned LSP identity mismatch');
 const receipt=join(workspace,'native-lsp-receipts.jsonl');
 const record=row=>appendFileSync(receipt,JSON.stringify({pid:process.pid,at:Date.now(),...row})+'\n',{mode:0o600});
 record({event:'start'});let finished=false;
 const finish=code=>{if(finished)return;finished=true;record({event:'exit',code});process.exit(code);};
 const fault=()=>{try{const text=readFileSync(join(workspace,'native-lsp-fault.json'),'utf8');if(text.length>4096)throw Error('Owned LSP fault marker exceeded bound');const value=JSON.parse(text);return value?.owner===owner?value:undefined;}catch(error){if(error.code==='ENOENT')return;throw error;}};
 const crash=reason=>{record({event:'crash',reason});finish(7);};
 let held;
 const protocol=createOwnedLspProtocol(workspace,message=>process.stdout.write(encodeLsp(message)),record,finish,{beforeInitialize:()=>{if(fault()?.failInitialization===true){crash('initialization');return false;}return true;},beforeNavigation:request=>{const value=fault();if(value?.action!=='hold'||value.pid!==process.pid)return true;if(held)throw Error('Owned LSP already has a held request');held=request;record({event:'held',id:request.id,method:request.method});return false;}});
 setInterval(()=>{try{const value=fault();if(value?.action==='crash'&&value.pid===process.pid)crash('controlled-runtime');if(value?.action==='release'&&value.pid===process.pid&&held){const request=held;held=undefined;record({event:'released',id:request.id,method:request.method});request.complete();}}catch(error){record({event:'failure',message:error.message});finish(1);}},50).unref();
 const decode=createLspDecoder(protocol);
 process.stdin.on('data',chunk=>{try{decode(chunk);}catch(error){record({event:'failure',message:error.message});finish(1);}});
 process.stdin.on('end',()=>finish(0));
 process.on('SIGTERM',()=>finish(0));process.on('SIGINT',()=>finish(0));
 setTimeout(()=>{record({event:'deadline'});finish(1);},180000).unref();
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)main();
