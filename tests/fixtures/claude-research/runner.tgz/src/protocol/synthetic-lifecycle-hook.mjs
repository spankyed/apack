import {appendFileSync} from 'node:fs';
const [capture]=process.argv.slice(2);if(!capture)throw Error('Private capture path required');
let input='';for await(const bytes of process.stdin){input+=bytes.toString();if(input.length>65536)throw Error('Fixture input bound exceeded');}
const value=JSON.parse(input);appendFileSync(capture,JSON.stringify({event:value.hook_event_name,sessionIdPresent:typeof value.session_id==='string'})+'\n');
process.stdout.write('{}\n');
