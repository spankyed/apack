import assert from 'node:assert/strict';
import http from 'node:http';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import { existsSync, appendFileSync } from 'node:fs';
import { mkdir, writeFile, rename } from 'node:fs/promises';
import { join } from 'node:path';
import { createRequire } from 'node:module';

/** Real isolated browser effects for native MCP URL callbacks, never the user's browser or account. */
export async function startOwnedMcpUrlBrowser({ checkout, workspace, completionMode = 'confirm' }) {
  assert.ok(['confirm', 'notify', 'retry'].includes(completionMode));
  const [firstPhase, lastPhase] = { confirm: [19, 23], notify: [8, 13], retry: [14, 18] }[completionMode];
  const token = randomUUID(), launches = new Map(), events = [];
  let origin, closed = false, launchesStarted = 0;
  const record = value => { events.push(value); appendFileSync(join(workspace, 'owned-mcp-browser-events.jsonl'), JSON.stringify(value) + '\n'); };
  const main = join(workspace, 'owned-mcp-browser-main.cjs');
  await writeFile(main, `const {app,BrowserWindow,session}=require('electron');
const c=JSON.parse(process.env.APACK_OWNED_REVIEW_CONFIG);app.setPath('userData',c.profile);
const report=path=>fetch(c.origin+path,{method:'POST',headers:{authorization:'Bearer '+c.token,'content-type':'application/json'},body:JSON.stringify({id:c.id,url:c.url})}).then(r=>{if(!r.ok)throw Error('Browser receipt refused');});
app.whenReady().then(async()=>{
 session.defaultSession.setPermissionRequestHandler((_w,_p,answer)=>answer(false));
 session.defaultSession.webRequest.onBeforeRequest((request,answer)=>{let allowed=false;try{allowed=new URL(request.url).origin===c.origin;}catch{}answer({cancel:!allowed});});
 session.defaultSession.webRequest.onBeforeSendHeaders((request,answer)=>answer({requestHeaders:{...request.requestHeaders,'X-Owned-Review':c.id}}));
 const window=new BrowserWindow({width:1100,height:900,show:true,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
 window.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 window.webContents.on('will-navigate',(event,url)=>{if(new URL(url).origin!==c.origin)event.preventDefault();});
 await window.loadURL(c.url);await report('/loaded');
}).catch(error=>{console.error(error);app.exit(1);});
app.on('window-all-closed',()=>app.quit());
`);
  const stop = async launch => {
    if (launch.exited) return;
    try { process.kill(-launch.child.pid, 'SIGTERM'); } catch (error) { if (error.code !== 'ESRCH') throw error; }
    const timer = setTimeout(() => { if (!launch.exited) try { process.kill(-launch.child.pid, 'SIGKILL'); } catch {} }, 1500);
    try { await launch.done; } finally { clearTimeout(timer); }
  };
  const server = http.createServer((request, response) => {
    void respond(request, response).catch(error => { record({ kind: 'refused', message: error.message }); if (!response.headersSent) response.writeHead(400); response.end(); });
  });
  async function respond(request, response) {
    const url = new URL(request.url, origin);
    const json = value => { response.writeHead(200, { 'content-type': 'application/json' }); response.end(JSON.stringify(value)); };
    let body = '';
    for await (const chunk of request) { body += chunk; assert.ok(Buffer.byteLength(body) <= 4096, 'Browser request exceeds bound'); }
    if (url.pathname === '/launch') {
      assert.equal(request.method, 'POST'); assert.equal(request.headers.authorization, 'Bearer ' + token);
      const input = JSON.parse(body), target = new URL(input.url), phase = Number(input.phase);
      assert.equal(target.origin, origin); assert.equal(target.pathname, '/release-review');
      assert.ok(Number.isSafeInteger(phase) && phase >= firstPhase && phase <= lastPhase);
      assert.equal(target.searchParams.get('phase'), String(phase));
      const normalizedReview = completionMode === 'confirm' && target.searchParams.get('title') === 'release notes';
      assert.equal([...target.searchParams].length, normalizedReview ? 2 : 1);
      if (!normalizedReview) assert.equal(target.searchParams.has('title'), false);
      assert.ok(launchesStarted++ < 4, 'Browser launch budget exceeded');
      assert.ok(process.platform === 'linux' && existsSync('/.dockerenv'), 'Real browser replay requires the owned Linux container');
      const id = randomUUID(), profile = join(workspace, 'owned-browser-profiles', id); await mkdir(profile, { recursive: true });
      const executable = createRequire(join(checkout, 'package.json'))('electron');
      const env = { ...process.env, APACK_OWNED_REVIEW_CONFIG: JSON.stringify({ id, profile, origin, token, url: target.href }) };
      delete env.ELECTRON_RUN_AS_NODE; delete env.NODE_OPTIONS;
      let resolveReady, rejectReady, resolveDone;
      const ready = new Promise((resolve, reject) => { resolveReady = resolve; rejectReady = reject; });
      const done = new Promise(resolve => { resolveDone = resolve; });
      const child = spawn(executable, ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--remote-debugging-port=0', main], { env, cwd: workspace, detached: true, stdio: ['ignore', 'ignore', 'pipe'] });
      const launch = { id, phase, url: target.href, child, done, exited: false, loaded: false, endpoint: undefined, completed: false };
      launches.set(id, launch); record({ kind: 'launch', id, phase, url: target.href, pid: child.pid });
      const publish = () => { if (launch.loaded && launch.endpoint) resolveReady(); };
      launch.loadedReceipt = () => { launch.loaded = true; publish(); };
      let stderr = '';
      child.stderr.on('data', chunk => {
        stderr = (stderr + chunk).slice(-65536);
        const endpoint = stderr.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:\d+\/devtools\/browser\/[^\s]+)/)?.[1];
        if (endpoint) { launch.endpoint = endpoint; publish(); }
      });
      child.once('error', error => { launch.exited = true; record({ kind: 'launch-error', id, phase, message: error.message }); rejectReady(error); resolveDone(); });
      child.once('exit', (code, signal) => { launch.exited = true; record({ kind: 'exit', id, phase, pid: child.pid, code, signal }); rejectReady(new Error('Owned browser exited before readiness')); resolveDone(); });
      const deadline = setTimeout(() => rejectReady(new Error('Owned browser readiness expired: ' + stderr.slice(-1500))), 10000);
      try { await ready; } catch (error) { await stop(launch); throw error; } finally { clearTimeout(deadline); }
      const descriptor = { id, phase, url: target.href, pid: child.pid, endpoint: launch.endpoint };
      const temporary = join(workspace, 'owned-mcp-browser-' + id + '.tmp');
      await writeFile(temporary, JSON.stringify(descriptor)); await rename(temporary, join(workspace, 'owned-mcp-browser-latest.json'));
      return json(descriptor);
    }
    if (url.pathname === '/loaded') {
      assert.equal(request.method, 'POST'); assert.equal(request.headers.authorization, 'Bearer ' + token);
      const input = JSON.parse(body), launch = launches.get(input.id); assert.ok(launch); assert.equal(input.url, launch.url);
      record({ kind: 'loaded', id: launch.id, phase: launch.phase, url: launch.url }); launch.loadedReceipt(); return json({ loaded: true });
    }
    if (url.pathname === '/favicon.ico') { response.writeHead(404); response.end(); return; }
    const launch = launches.get(request.headers['x-owned-review']); assert.ok(launch, 'Unknown browser owner');
    assert.equal(url.searchParams.get('phase'), String(launch.phase));
    if (url.pathname === '/release-review') {
      assert.equal(request.method, 'GET'); record({ kind: 'navigation', id: launch.id, phase: launch.phase, url: launch.url });
      const nonce = randomUUID();
      const completionText = completionMode === 'confirm' ? 'Review complete. Return to apack and confirm to continue.' : completionMode === 'retry' ? 'Review complete. Return to apack and retry the request.' : 'Review complete. Return to apack to continue your session.';
      response.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'content-security-policy': `default-src 'none'; script-src 'nonce-${nonce}'; style-src 'unsafe-inline'; connect-src 'self'` });
      response.end(`<!doctype html><html lang="en"><meta charset="utf-8"><title>Release review</title><style>body{margin:0;background:#18191b;color:#eee;font:18px system-ui}main{max-width:36rem;margin:10vh auto;padding:2rem}button{padding:.75rem 1.2rem;border:0;border-radius:.5rem;background:#3766ec;color:white;font:inherit}p{line-height:1.6}</style><main><h1>Release review</h1><p>Confirm the migration notes, then return to apack to continue your session.</p><button>Finish review</button><p role="status">Review is waiting for your confirmation.</p></main><script nonce="${nonce}">document.querySelector('button').onclick=async()=>{const reply=await fetch('/complete?phase=${launch.phase}',{method:'POST'});if(!reply.ok)throw Error('Review refused');document.querySelector('[role=status]').textContent=${JSON.stringify(completionText)};document.querySelector('button').disabled=true;};</script></html>`); return;
    }
    if (url.pathname === '/complete') {
      assert.equal(request.method, 'POST'); assert.ok(launch.loaded && !launch.completed);
      launch.completed = true; record({ kind: 'complete', id: launch.id, phase: launch.phase });
      if (completionMode === 'notify') {
        const destination = join(workspace, 'mcp-url-completion-' + launch.phase), temporary = destination + '.' + launch.id;
        await writeFile(temporary, 'release-review-' + launch.phase); await rename(temporary, destination);
      }
      return json({ completed: true });
    }
    response.writeHead(404); response.end();
  }
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  origin = 'http://127.0.0.1:' + server.address().port;
  await writeFile(join(workspace, 'owned-mcp-browser.json'), JSON.stringify({ origin }));
  await writeFile(join(workspace, 'native-mcp-url-browser.mjs'), `#!${process.execPath}
import {appendFileSync,readFileSync} from 'node:fs';
const phase=Number(readFileSync(${JSON.stringify(join(workspace,'mcp-elicitation-phase.txt'))},'utf8')),url=process.argv[2];
appendFileSync(${JSON.stringify(join(workspace,'native-mcp-url-browser.jsonl'))},JSON.stringify({phase,url,pid:process.pid,ppid:process.ppid})+'\\n');
const reply=await fetch(${JSON.stringify(origin+'/launch')},{method:'POST',headers:{authorization:${JSON.stringify('Bearer '+token)},'content-type':'application/json'},body:JSON.stringify({phase,url})});
if(!reply.ok)throw Error('Owned browser launch refused: '+reply.status);
`, { mode: 0o700 });
  return { origin, events, close: async () => {
    if (closed) return; closed = true;
    try { await Promise.all([...launches.values()].map(stop)); } finally { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
  } };
}
