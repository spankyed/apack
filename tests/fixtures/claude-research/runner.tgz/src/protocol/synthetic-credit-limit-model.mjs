import assert from 'node:assert/strict';
import {createServer} from 'node:http';
/** One provider-origin credit limit, then ordinary synthetic replies. No upstream requests. */
export async function startSyntheticCreditLimitModel({trigger,maxRequests=12,disabledReason='overage_not_provisioned'}){
 assert.ok(typeof trigger==='string'&&trigger.length>0&&trigger.length<=4096);
 assert.ok(disabledReason===null||disabledReason==='overage_not_provisioned');
 const calls=[];let limited=false;
 const server=createServer(async(req,res)=>{
  try{
   const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;assert.ok(size<=4*1024*1024);chunks.push(chunk)}
   const body=size?JSON.parse(Buffer.concat(chunks).toString()):{};
   assert.ok(calls.length<maxRequests);const call={path:req.url,model:body.model,messages:body.messages??[],at:Date.now()};calls.push(call);
   if(req.url==='/api/hello'){res.writeHead(200,{'content-type':'application/json'});res.end('{"ok":true}');return}
   if(!req.url?.startsWith('/v1/messages')){res.writeHead(404);res.end('{}');return}
   if(!limited&&JSON.stringify(body.messages??[]).includes(trigger)){
    limited=true;call.outcome='credits_required';res.writeHead(429,{'content-type':'application/json',...(disabledReason?{'anthropic-ratelimit-unified-overage-disabled-reason':disabledReason}:{})});
    res.end(JSON.stringify({type:'error',error:{type:'rate_limit_error',message:'Usage credits are required to continue on this model.',details:{error_code:'credits_required',...(disabledReason?{disabled_reason:disabledReason}:{}),can_user_purchase_credits:true,has_chargeable_saved_payment_method:true}}}));return;
   }
   call.outcome='answer';const message={id:'msg_owned_credit_'+calls.length,type:'message',role:'assistant',model:body.model,content:[{type:'text',text:'The release review can continue on the selected model.'}],stop_reason:'end_turn',stop_sequence:null,usage:{input_tokens:10,output_tokens:5}};
   if(body.stream){res.writeHead(200,{'content-type':'text/event-stream'});for(const event of [{type:'message_start',message:{...message,content:[],stop_reason:null}},{type:'content_block_start',index:0,content_block:{type:'text',text:''}},{type:'content_block_delta',index:0,delta:{type:'text_delta',text:message.content[0].text}},{type:'content_block_stop',index:0},{type:'message_delta',delta:{stop_reason:'end_turn',stop_sequence:null},usage:{output_tokens:5}},{type:'message_stop'}])res.write('event: '+event.type+'\ndata: '+JSON.stringify(event)+'\n\n');res.end();return}
   res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(message));
  }catch(error){if(!res.headersSent)res.writeHead(400);res.end(JSON.stringify({error:String(error)}))}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 return {url:'http://127.0.0.1:'+server.address().port,calls,get limited(){return limited},async close(){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}};
}
