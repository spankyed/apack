export const completionNavigationRows=[
 {text:'#release-public',label:'Public release',description:'Notes for customers'},
 {text:'#release-internal',label:'Internal release',description:'Notes for teammates'},
 {text:'#release-checklist',label:'Release checklist',description:'Checks before publishing'},
];

/** Supply original autocomplete rows and record the original callback without extra UI controls. */
export function nativeCompletionNavigationHook(){
 return `export function register(on){const rows=${JSON.stringify(completionNavigationRows)},events=[];on('prompt.autocomplete',{token:/^#release/},async($,e,next)=>{const suggestions=rows.filter(row=>row.text.startsWith(e.token)&&row.text!==e.token);events.push({token:e.token,text:e.text,cursor:e.cursor,start:e.start,suggestions});await $.fs.write('native-completion-events.json',JSON.stringify(events.slice(-128)));return {suggestions};});}`;
}
