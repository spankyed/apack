import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Native writer touches only a new private user settings file; no prompt/model/account traffic. */
export async function probeEffortSettings(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'effort-settings-')),home=join(workspace,'home'),cwd=join(workspace,'project'),config=join(home,'.claude');await mkdir(config,{recursive:true});await mkdir(cwd);
 const settings=join(config,'settings.json'),seed={apiKeyHelper:'/usr/bin/printf research-fixture-key',model:'sonnet',language:'preserve',env:{CLAUDE_RESEARCH_MARKER:'preserve'}};await writeFile(settings,JSON.stringify(seed));
 const steps=[{subtype:'initialize'},{subtype:'get_settings'},...['low','xhigh','max','invalid'].flatMap(effortLevel=>[{subtype:'update_settings',source:'userSettings',settings:{effortLevel}},{subtype:'get_settings'}]),{subtype:'update_settings',source:'projectSettings',settings:{effortLevel:'high'}},{subtype:'get_settings'},{user:'Fixed synthetic effort preference fixture.'},{subtype:'get_settings'}],replies=[],results=[];let index=0,pending='',model;
 const run=await createRun(output,'effort-settings',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
 const input=()=>JSON.stringify(steps[index].user?{type:'user',message:{role:'user',content:steps[index].user}}:{type:'control_request',request_id:'effort-'+index,request:steps[index]})+'\n';
 try{
  model=await startSyntheticModel(cwd,'TextOnly',{captureEffort:true});
  const options={executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','','--no-session-persistence'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}};
  const transport=await record({...options,input:[input()],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type==='result'&&steps[index]?.user){results.push({subtype:value.subtype,is_error:value.is_error??false});index++;if(index<steps.length)channel.send(input());else channel.closeInput();}
    else if(value.type==='control_response'&&value.response?.request_id==='effort-'+index){const request=steps[index],snapshot=JSON.parse(readFileSync(settings,'utf8'));replies.push({step:index,request,response:value.response,privateSettings:snapshot});index++;if(index<steps.length)channel.send(input());else channel.closeInput();}
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(index,steps.length);assert.equal(model.calls.length,1);assert.deepEqual(results,[{subtype:'success',is_error:false}]);
  for(const reply of replies){for(const key of ['apiKeyHelper','model','language','env'])assert.deepEqual(reply.privateSettings[key],seed[key]);}
  const get=(step)=>replies.find(reply=>reply.step===step),canonical=get(1).response.response.applied.model;
  assert.equal(get(1).response.response.applied.effort,'medium');
  for(const [step,level] of [[2,'low'],[4,'xhigh']]){assert.equal(get(step).response.subtype,'success');assert.equal(get(step).privateSettings.modelSettings[canonical].effortLevel,level);assert.equal(get(step+1).response.response.effective.modelSettings[canonical].effortLevel,level);assert.equal(get(step+1).response.response.applied.effort,'medium');}
  assert.equal(get(6).response.subtype,'success');for(const step of [6,8,10])assert.deepEqual(get(step).privateSettings,get(4).privateSettings);
  assert.equal(get(8).response.subtype,'error');assert.equal(get(10).response.subtype,'error');assert.equal(model.calls[0].effort,'medium');
  let freshPending='',freshReply;
  const fresh=await record({...options,input:[JSON.stringify({type:'control_request',request_id:'fresh-init',request:{subtype:'initialize'}})+'\n'],onStdout(bytes,channel){
   freshPending+=bytes.toString();while(freshPending.includes('\n')){const at=freshPending.indexOf('\n'),text=freshPending.slice(0,at);freshPending=freshPending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type!=='control_response')continue;
    if(value.response?.request_id==='fresh-init'){assert.equal(value.response.subtype,'success');channel.send(JSON.stringify({type:'control_request',request_id:'fresh-settings',request:{subtype:'get_settings'}})+'\n');}
    else if(value.response?.request_id==='fresh-settings'){freshReply=value.response;channel.closeInput();}
   }
  }});
  assert.equal(fresh.status,'complete');assert.equal(fresh.code,0);assert.equal(freshReply?.subtype,'success');assert.equal(freshReply.response.applied.effort,'xhigh');assert.equal(model.calls.length,1);assert.deepEqual(JSON.parse(await readFile(settings,'utf8')),get(4).privateSettings);
  const evidence={replies,results,freshConfiguration:freshReply.response,freshTransportRun:fresh.directory,modelCalls:model.calls,localModelRequests:model.calls.length,realModelRequests:0,qualification:'Private direct native userSettings effort update/readback and invalid source/value only. One synthetic next-turn outgoing effort field; not real reasoning, app persistence, remote/policy cases or mounted UI.'};
  await writeFile(join(run.directory,'effort-settings.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return {directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}finally{await model?.close();}
}
