import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {verifyNativePluginHintAppEvidence} from './native-plugin-hint-app-proof.mjs';
export async function verifyNativeTranscriptViewportAppEvidence(root) {
const original=await verifyNativePluginHintAppEvidence(root);
const names=await readdir(join(root,'records/workspaces'));assert.equal(names.length,1);
const metrics=JSON.parse(await readFile(join(root,'records/workspaces',names[0],'native-transcript-resize-app.json'),'utf8'));
assert.equal(metrics.readingSamples.length,2);
assert.deepEqual(metrics.readingSamples.map(({width,height})=>[width,height]),[[1100,900],[680,600]]);
for(const {geometry:{reply,viewport,composer}} of metrics.readingSamples){assert.ok(reply.y>=viewport.y-1);assert.ok(reply.y+reply.height<=Math.min(viewport.y+viewport.height,composer.y)+1)}
assert.equal(metrics.readingAnchor.id,metrics.afterRetirement.id);
assert.deepEqual(metrics.retained,JSON.parse(await readFile(join(root,'records/workspaces',names[0],'native-plugin-hint-app.json'),'utf8')).retained);
const result={original,metrics,limits:['Top-of-history reader position only; arbitrary reflow anchors remain unverified.','Reply text reading, not a claim of whole-screen polish or a larger compact reading area.','Other owners/windows, policy variants and combined F1–F5 remain open.']};
return result;
}
