import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {verifyNativePluginHintAppEvidence} from './native-plugin-hint-app-proof.mjs';
export async function verifyNativeTranscriptViewportAppEvidence(root) {
const original=await verifyNativePluginHintAppEvidence(root);
const names=await readdir(join(root,'records/workspaces'));assert.equal(names.length,1);
const metrics=JSON.parse(await readFile(join(root,'records/workspaces',names[0],'native-transcript-resize-app.json'),'utf8'));
assert.equal(metrics.readingSamples.length,2);
assert.deepEqual(metrics.readingSamples.map(({width,height})=>[width,height]),[[1100,900],[680,600]]);
for(const {geometry:{reply,viewport,composer}} of metrics.readingSamples){assert.ok(reply.y>=viewport.y-1);assert.ok(reply.y+reply.height<=Math.min(viewport.y+viewport.height,composer.y)+1)}
assert.equal(metrics.readingAnchor.id,metrics.afterRetirement.id);
assert.deepEqual(metrics.retained,JSON.parse(await readFile(join(root,'records/workspaces',names[0],'native-plugin-hint-app.json'),'utf8')).retained);
const result={original,metrics,limits:['Top-of-history reader position only; arbitrary reflow anchors remain unverified.','Reply text reading, not a claim of whole-screen polish or a larger compact reading area.','Other owners/windows, policy variants and combined F1–F5 remain open.']};
return result;
}

/** Pending native decisions must leave usable compact reading space, including the original footer. */
export async function verifyNativeRecommendationLayoutAppEvidence(root) {
  const result = await verifyNativeTranscriptViewportAppEvidence(root)
  const compact = result.metrics.readingSamples.find(sample => sample.width === 680)
  assert.ok(compact.geometry.viewport.height >= 100)
  assert.ok(compact.duration && compact.duration.height > 0)
  assert.ok(compact.duration.y >= compact.geometry.viewport.y - 1)
  assert.ok(compact.duration.y + compact.duration.height <= compact.geometry.viewport.y + compact.geometry.viewport.height + 1)
  return { ...result, compactReadingHeight: compact.geometry.viewport.height,
    limits: ['Top-of-history reader position only; arbitrary reflow anchors and focus return remain unverified.',
      'Other native decisions, owners/windows and policy/lifecycle combinations remain open.',
      'This ordinary recommendation layout does not close whole-screen UI-12 or original F1–F5.'],
    scope: 'Ordinary main-owner recommendation, complete compact reply/footer reading, original defer or expiry and same-session recovery; other native decisions and broader F1–F5 remain open.' }
}
