import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRun, hash } from '../artifacts/runs.mjs';
import { record } from './record.mjs';
import { recognizeOnboardingPrompt } from './pty-onboarding.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';
import { nativeMcpRendererInspector, nativeMcpRendererIdentities } from './native-mcp-renderer-inspector.mjs';

/** Account for native session naming independently of the actual conversation. */
export function verifyMcpTerminalModelCalls(calls, phase = 1) {
  const messages = calls.filter(call => call.path?.split('?')[0] === '/v1/messages');
  const titles = messages.filter(call => call.toolNames?.length === 0 && call.messages?.length === 1 && call.messages[0].role === 'user' && call.messages[0].content?.length === 1 && call.messages[0].content[0].type === 'text' && call.messages[0].content[0].text.startsWith('<session>\nReview release input ' + phase + '.\n</session>\n\nWrite the title in the predominant language of the session'));
  assert.equal(titles.length, 1, 'Expected the original new-session title request');
  const conversation = messages.filter(call => !titles.includes(call));
  const searched = conversation.some(call => call.messages?.some(message => Array.isArray(message.content) && message.content.some(block => block.type === 'tool_use' && block.name === 'ToolSearch' && block.id === 'native_mcp_search_' + phase)));
  assert.equal(conversation.length, searched ? 3 : 2);
  const auxiliary = calls.filter(call => !messages.includes(call));
  assert.ok(auxiliary.length <= 1 && auxiliary.every(call => call.path?.split('?')[0] === '/v1/messages/count_tokens'), 'Unexpected synthetic endpoint');
  return { messageRequests: conversation.length, titleRequests: titles.length, tokenCountRequests: auxiliary.length };
}

/** Explicit original-terminal observation, separate from app acceptance. Linux native container only. */
export async function probeMcpTerminalRenderer(executable, workspaceRoot, output, { phase = 1 } = {}) {
  assert.ok([1, 4, 6].includes(phase), 'Only original form, URL cancellation or URL waiting observation is supported');
  assert.equal(process.platform, 'linux', 'Native execution belongs in the Linux container');
  const targetSha256 = hash(await readFile(executable));
  assert.equal(targetSha256, nativeMcpRendererIdentities.linux.binarySha256);
  await mkdir(workspaceRoot, { recursive: true });
  const workspace = await mkdtemp(join(workspaceRoot, 'mcp-terminal-renderer-'));
  const run = await createRun(output, 'mcp-terminal-renderer', { targetSha256,
    phase, driverSha256: hash(await readFile(new URL(import.meta.url))),
    inspectorSha256: hash(await readFile(new URL('./native-mcp-renderer-inspector.mjs', import.meta.url))),
    serverSha256: hash(await readFile(new URL('./synthetic-app-elicitation-server.mjs', import.meta.url))),
    modelSha256: hash(await readFile(new URL('./synthetic-model.mjs', import.meta.url))), workspace });
  const configDir = join(workspace, 'config'), plugin = join(workspace, 'observer-plugin');
  const inspectionPath = join(workspace, 'mounted-mcp-renderer.json');
  const receipt = join(workspace, 'mcp-input.jsonl'), preload = join(workspace, 'observe.mjs');
  const browserReceipt = join(workspace, 'browser-opens.jsonl'), browser = join(workspace, 'private-browser.mjs');
  let model, interval, transport, checking = false, observation, cancelled = false, exitRequested = false;
  const timers = [];
  try {
    await mkdir(configDir); await mkdir(join(plugin, '.claude-plugin'), { recursive: true }); await mkdir(join(plugin, 'hooks'));
    await writeFile(join(plugin, '.claude-plugin/plugin.json'), JSON.stringify({ name: 'mcp-terminal-observer', version: '0.0.1' }));
    await writeFile(join(plugin, 'hooks/hooks.json'), JSON.stringify({ modules: ['./register.ts'] }));
    await writeFile(join(plugin, 'hooks/register.ts'), "export function register(on){on('session.start',async($,e,next)=>next(e));}");
    await writeFile(preload, nativeMcpRendererInspector(inspectionPath));
    if (phase === 4) await writeFile(browser, '#!/usr/bin/env node\nimport {appendFileSync} from \'node:fs\';appendFileSync(' + JSON.stringify(browserReceipt) + ',JSON.stringify(process.argv.slice(2))+\'\\n\');\n', { mode: 0o700 });
    await writeFile(join(workspace, 'mcp-elicitation-phase.txt'), String(phase));
    await writeFile(join(workspace, 'mcp-elicitation-model-release-' + phase), 'Explicit native renderer observation');
    const server = fileURLToPath(new URL('./synthetic-app-elicitation-server.mjs', import.meta.url));
    const mcp = join(workspace, 'mcp.json');
    await writeFile(mcp, JSON.stringify({ mcpServers: { research: { type: 'stdio', command: process.execPath, args: [server], env: { APACK_MCP_ELICITATION_RECEIPT: receipt } } } }));
    model = await startSyntheticModel(workspace, 'TextOnly', { mcpElicitations: true, captureMessages: true, maxRequests: 4 });
    let terminal = '', theme = false, security = false, navigated = false, trusted = false;
    interval = setInterval(async () => {
      if (checking || !transport) return; checking = true;
      try {
        if (!observation) {
          let current; try { current = JSON.parse(await readFile(inspectionPath, 'utf8')); } catch (error) { if (error.code === 'ENOENT') return; throw error; }
          if (current.status === 'failed') throw Error(current.error);
          const fact = current.observations?.flatMap(row => row.facts).find(row => row.kind === 'mcp_elicitation' && row.mode === (phase === 1 ? 'form' : 'url') && row.renderer.verified);
          if (!fact) return;
          let fieldState;
          if (phase === 1) {
            fieldState = fact.controls.find(control => Array.isArray(control.state.schemaFields))?.state;
            assert.ok(fieldState, 'Original mounted field control missing');
            assert.equal(fieldState.schemaFields.length, 7);
            assert.equal(fieldState.formValues.enabled, false); assert.equal(fieldState.formValues.count, 0);
            assert.ok(fact.controls.some(control => control.callbacks.handleTextInputChange));
          } else {
            assert.equal(fact.urlPresentation?.initialPhase, 'prompt');
            assert.ok(fact.urlPresentation.panels.some(panel => panel.title.includes('wants to open a URL')));
            assert.ok(fact.urlPresentation.renderedText.some(row => row.text.includes('Decline')));
            assert.ok(fact.controls.some(control => control.callbacks.onKeyDown));
          }
          assert.ok(fact.controls.some(control => control.callbacks.onCancel));
          observation = { fact, ...(fieldState ? { fieldState } : {}) };
          if (phase === 4) timers.push(setTimeout(() => transport.send('\r'), 300));
          else { transport.send('\x1b'); cancelled = true; }
        }
        if (phase === 4 && !cancelled) {
          const current = JSON.parse(await readFile(inspectionPath, 'utf8'));
          if (current.status === 'failed') throw Error(current.error);
          const waiting = current.observations?.flatMap(row => row.facts).find(row => row.kind === 'mcp_elicitation_waiting' && row.renderer.verified);
          if (!waiting) return;
          assert.equal(waiting.urlPresentation?.initialPhase, 'waiting');
          assert.ok(waiting.urlPresentation.renderedText.some(row => row.text.includes('Skip confirmation')));
          observation.waiting = waiting; transport.send('\x1b'); cancelled = true;
        }
        const receipts = (await readFile(receipt, 'utf8')).trim().split('\n').map(JSON.parse);
        const answer = receipts.find(row => row.id === 'research-elicitation-' + phase && row.result);
        if (answer && model.calls.length >= 2 && !exitRequested) {
          assert.deepEqual(answer.result, { action: phase === 4 ? 'accept' : 'cancel' }); exitRequested = true;
          timers.push(setTimeout(() => transport.send('\x04'), 300));
          timers.push(setTimeout(() => transport.send('\x04'), 1000));
        }
      } catch (error) { observation = { ...observation, error: error.message }; transport.stop('native-mcp-observation-failed'); }
      finally { checking = false; }
    }, 100);
    const probe = await record({ executable: '/usr/bin/python3', cwd: workspace, output, timeoutMs: 45000,
      args: [fileURLToPath(new URL('./pty_bridge.py', import.meta.url)), executable,
        '--setting-sources', '', '--settings', JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' }),
        '--plugin-dir', plugin, '--strict-mcp-config', '--mcp-config', mcp,
        '--allowed-tools', 'mcp__research__echo', 'ToolSearch', '--', 'Review release input ' + phase + '.'],
      env: { PATH: process.env.PATH, ...(phase === 4 ? { BROWSER: browser } : {}), HOME: workspace, CLAUDE_CONFIG_DIR: configDir, TERM: 'xterm-256color',
        BUN_OPTIONS: '--preload=' + preload, ANTHROPIC_BASE_URL: model.url, DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
      onStdout(bytes, controls) {
        transport = controls; terminal += bytes.toString('utf8');
        const screen = recognizeOnboardingPrompt(terminal, workspace); let key;
        if (screen === 'theme' && !theme) { theme = true; key = '\r'; }
        else if (screen === 'security-notes' && !security) { security = true; key = '\r'; }
        else if (screen === 'workspace-trust' && !navigated) { navigated = true; key = '\x1b[B'; }
        else if (screen === 'workspace-trust-selected' && !trusted) { trusted = true; key = '\r'; }
        if (key) timers.push(setTimeout(() => controls.send(key), 150));
      } });
    assert.equal(probe.status, 'complete', observation?.error ?? 'Original terminal did not exit cleanly');
    assert.ok(observation?.fact && cancelled && exitRequested, 'Original form observation/cancellation was incomplete');
    const counts = verifyMcpTerminalModelCalls(model.calls, phase);
    const browserInvocations = phase === 4 ? (await readFile(browserReceipt, 'utf8')).trim().split('\n').map(JSON.parse) : [];
    if (phase === 4) assert.deepEqual(browserInvocations, [['https://example.invalid/release-review']]);
    const report = { targetSha256, workspace, probe, observation, browserInvocations, syntheticApiRequests: model.calls.length,
      ...counts, realModelRequests: 0, qualification: phase === 1 ? 'Original terminal mounted form/defaults and Escape cancellation only. No app host, URL/waiting or arbitrary field editing acceptance.' : phase === 4 ? 'Original URL prompt/accept, one original invocation of a private inert BROWSER, separate mounted waiting dialog and Escape dismissal. No real browser navigation, completion notification, modern explicit confirmation or app host acceptance.' : 'Original terminal mounted URL prompt, original control fingerprints and Escape cancellation only. No URL opening, waiting/completion, app host or policy/other-owner acceptance.' };
    await writeFile(join(run.directory, 'mcp-terminal-renderer.json'), JSON.stringify(report, null, 2) + '\n');
    await run.finish({ status: 'complete' }); return { directory: run.directory, status: 'complete', ...report };
  } catch (error) {
    await writeFile(join(run.directory, 'failure.json'), JSON.stringify({ error: error.message, observation, syntheticApiRequests: model?.calls.length }));
    await run.finish({ status: 'failed', error: error.message }); throw error;
  } finally {
    clearInterval(interval); for (const timer of timers) clearTimeout(timer);
    try { if (model) await writeFile(join(run.directory, 'model-calls.json'), JSON.stringify(model.calls, null, 2)); }
    finally { await model?.close(); }
  }
}
