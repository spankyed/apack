import http from 'node:http';
import {randomUUID,createHash} from 'node:crypto';
import {appendFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Private authorization/resource server; all credentials exist only for this owned run. */
export async function startOwnedMcpOAuthServer(workspace){
 const clients=new Map(),codes=new Map(),tokens=new Set(),events=[];let origin;
 const record=async event=>{events.push(event);await appendFile(join(workspace,'owned-mcp-oauth-events.jsonl'),JSON.stringify(event)+'\n');};
 const server=http.createServer((req,res)=>{void respond(req,res).catch(async error=>{await record({kind:'error',message:error.message});if(!res.headersSent)res.writeHead(400);res.end();});});
 async function respond(req,res){
  const url=new URL(req.url,origin);let bytes=0;const chunks=[];
  for await(const chunk of req){bytes+=chunk.length;if(bytes>65536){res.writeHead(413);res.end();return;}chunks.push(chunk);}
  const body=Buffer.concat(chunks).toString();
  const json=(value,status=200,headers={})=>{res.writeHead(status,{'content-type':'application/json',...headers});res.end(JSON.stringify(value));};
  if(url.pathname.startsWith('/.well-known/oauth-protected-resource'))return json({resource:origin+'/mcp',authorization_servers:[origin],scopes_supported:['tools']});
  if(url.pathname==='/.well-known/oauth-authorization-server')return json({issuer:origin,authorization_endpoint:origin+'/authorize',token_endpoint:origin+'/token',registration_endpoint:origin+'/register',response_types_supported:['code'],grant_types_supported:['authorization_code','refresh_token'],token_endpoint_auth_methods_supported:['none'],code_challenge_methods_supported:['S256'],scopes_supported:['tools']});
  if(url.pathname==='/register'){
   const input=JSON.parse(body);if(!Array.isArray(input.redirect_uris)||!input.redirect_uris.length)throw Error('Missing redirects');
   for(const value of input.redirect_uris){const redirect=new URL(value);if(redirect.protocol!=='http:'||!['127.0.0.1','localhost'].includes(redirect.hostname))throw Error('Only owned loopback redirects allowed');}
   const client_id='owned-'+randomUUID();clients.set(client_id,input);await record({kind:'registered',clientId:client_id,redirects:input.redirect_uris});return json({...input,client_id,client_id_issued_at:Math.floor(Date.now()/1000)},201);
  }
  if(url.pathname==='/authorize'){
   const client=clients.get(url.searchParams.get('client_id')),redirect=url.searchParams.get('redirect_uri'),state=url.searchParams.get('state'),challenge=url.searchParams.get('code_challenge');
   if(!client?.redirect_uris.includes(redirect)||!state||!challenge||url.searchParams.get('code_challenge_method')!=='S256')throw Error('Invalid owned authorization');
   const code=randomUUID();codes.set(code,{clientId:url.searchParams.get('client_id'),redirect,challenge});const callback=new URL(redirect);callback.searchParams.set('code',code);callback.searchParams.set('state',state);
   await record({kind:'authorized',state,clientId:url.searchParams.get('client_id')});res.writeHead(302,{location:callback.href});res.end();return;
  }
  if(url.pathname==='/token'){
   const input=new URLSearchParams(body),code=input.get('code'),grant=codes.get(code),challenge=createHash('sha256').update(input.get('code_verifier')??'').digest('base64url');
   if(input.get('grant_type')!=='authorization_code'||!grant||grant.clientId!==input.get('client_id')||grant.redirect!==input.get('redirect_uri')||grant.challenge!==challenge)return json({error:'invalid_grant'},400);
   codes.delete(code);const token='owned-'+randomUUID();tokens.add(token);await record({kind:'token',pkceVerified:true,clientId:grant.clientId});return json({access_token:token,token_type:'Bearer',expires_in:3600,scope:'tools'});
  }
  if(url.pathname==='/mcp'){
   if(!tokens.has(req.headers.authorization?.replace(/^Bearer /,''))){await record({kind:'unauthorized'});return json({error:'unauthorized'},401,{'www-authenticate':'Bearer resource_metadata="'+origin+'/.well-known/oauth-protected-resource"'});}
   if(req.method==='GET'){res.writeHead(405);res.end();return;}
   if(req.method==='DELETE'){res.writeHead(200);res.end();return;}
   const rpc=JSON.parse(body);await record({kind:'rpc',method:rpc.method,authorized:true});if(rpc.id===undefined){res.writeHead(202);res.end();return;}
   const result=rpc.method==='initialize'?{protocolVersion:rpc.params.protocolVersion,capabilities:{tools:{}},serverInfo:{name:'owned-oauth-fixture',version:'1.0.0'}}:rpc.method==='tools/list'?{tools:[{name:'echo',description:'Return owned test text',inputSchema:{type:'object',properties:{message:{type:'string'}},required:['message']}}]}:rpc.method==='tools/call'?{content:[{type:'text',text:rpc.params.arguments.message}]}:{};
   return json({jsonrpc:'2.0',id:rpc.id,result});
  }
  res.writeHead(404);res.end();
 }
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});origin='http://127.0.0.1:'+server.address().port;
 await writeFile(join(workspace,'owned-mcp-oauth-server.json'),JSON.stringify({origin,mcpUrl:origin+'/mcp'}));
 return {origin,events,close:()=>new Promise(resolve=>{server.closeAllConnections();server.close(resolve);})};
}
