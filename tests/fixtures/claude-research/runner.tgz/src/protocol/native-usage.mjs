import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Private no-account usage and cost shapes; behavior analytics explicitly excluded. */
export async function probeNativeUsage(executable,root,output,mode='empty'){
 if(!['empty','turn'].includes(mode))throw new Error('Unknown usage fixture mode');
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'native-usage-')),home=join(workspace,'home'),cwd=join(workspace,'project');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(cwd);
 const settings=join(home,'.claude','settings.json'),before=JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',model:'sonnet',language:'preserve'});await writeFile(settings,before);
 const requests=[{subtype:'initialize'},{subtype:'get_usage',skip_behaviors:true},{subtype:'get_session_cost'},{subtype:'get_usage',skip_behaviors:'invalid'}],replies=[],results=[];
 if(mode==='turn')requests.push({user:'Synthetic usage accounting fixture.'},{subtype:'get_usage',skip_behaviors:true},{subtype:'get_session_cost'});
 let pending='',index=0;
 const run=await createRun(output,'native-usage',{mode,targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
 const input=()=>JSON.stringify(requests[index].user?{type:'user',message:{role:'user',content:requests[index].user}}:{type:'control_request',request_id:'catalog-'+index,request:requests[index]})+'\n';
 let model;
 try{
  model=await startSyntheticModel(cwd,'TextOnly');
  const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','','--no-session-persistence'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[input()],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type==='result'&&requests[index]?.user){results.push({subtype:value.subtype,is_error:value.is_error??false,total_cost_usd:value.total_cost_usd,modelUsage:value.modelUsage});index++;if(index<requests.length)channel.send(input());else channel.closeInput();}
    else if(value.type==='control_response'&&value.response?.request_id==='catalog-'+index){replies.push({request:requests[index],response:value.response});index++;if(index<requests.length)channel.send(input());else channel.closeInput();}
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(index,requests.length);assert.equal(model.calls.length,mode==='turn'?1:0);assert.equal(await readFile(settings,'utf8'),before);
  assert.deepEqual(replies.map(value=>value.response.subtype),mode==='turn'?['success','success','success','error','success','success']:['success','success','success','error']);
  const usage=replies[1].response.response,cost=replies[2].response.response;
  assert.equal(usage.rate_limits_available,false);assert.equal(usage.rate_limits,null);assert.equal(usage.behaviors,null);
  assert.equal(usage.session.total_cost_usd,0);assert.equal(typeof cost.text,'string');
  const populatedUsage=mode==='turn'?replies[4].response.response:null;
  if(mode==='turn'){assert.equal(results.length,1);assert.equal(results[0].subtype,'success');assert.equal(results[0].is_error,false);assert.equal(populatedUsage.session.total_cost_usd,results[0].total_cost_usd);assert.ok(populatedUsage.session.total_cost_usd>0);assert.deepEqual(populatedUsage.session.model_usage,results[0].modelUsage);assert.equal(populatedUsage.rate_limits_available,false);}
  const evidence={mode,usage,cost,populatedUsage,results,invalidRequest:replies[3].response,settingsUnchanged:true,localModelRequests:model.calls.length,realModelRequests:0,qualification:'Private no-account initialized process and explicit skip_behaviors only. No authenticated account limits, populated behavior analytics, real model accounting, app or mounted UI claim. Turn mode compares synthetic native session cost/model usage with its terminal result.'};
  await writeFile(join(run.directory,'native-usage.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}finally{await model?.close();}
}
