import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from './record.mjs';
import {recognizeOnboardingPrompt} from './pty-onboarding.mjs';
import {hash} from '../artifacts/runs.mjs';

/** Observe the original rollout getter only after an interactive runtime binding exists. */
export function nativeMonitorAdmissionInspector(outputPath){
 return `{
 const fs=await import('node:fs'),crypto=await import('node:crypto');
 const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
 if(process.platform==='linux'&&sha(fs.readFileSync(process.execPath))==='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'){
  let busy=false,attempts=0;const timer=setInterval(async()=>{if(busy)return;busy=true;try{
   if(++attempts>450){clearInterval(timer);return;}if(!fs.existsSync(${JSON.stringify(outputPath+'.armed')}))return;
   const runtime=await import('/$bunfs/root/chunk-a7b8k0bt.js'),binding=runtime.Zh();if(binding?.surface!=='terminal')return;
   const feature=await import('/$bunfs/root/chunk-jtdxvd2c.js');
   const sourceHash=sha(Function.prototype.toString.call(feature.Q6));
   if(sourceHash!=='1cfe39689dc92a732f4aa068faa1895aa0e57a0577dfcd24b5ba49d9c38e412d')throw Error('Original monitor gate getter changed');
   const enabled=feature.Q6();if(typeof enabled!=='boolean')throw Error('Original monitor admission is not boolean');
   fs.writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({surface:binding.surface,feature:'tengu_amber_sentinel',enabled,sourceHash,originalBinarySha256:sha(fs.readFileSync(process.execPath)),observation:'Original getter read only; no flag override, plugin installation or command arming'}),{mode:0o600});clearInterval(timer);
  }catch(error){fs.writeFileSync(${JSON.stringify(outputPath+'.error')},String(error),{mode:0o600});clearInterval(timer);}finally{busy=false;}},100);timer.unref();
 }
}`;
}

export async function probeNativeMonitorAdmission(executable,parent,output){
 assert.equal(process.platform,'linux');assert.equal(hash(await readFile(executable)),'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 await mkdir(parent,{recursive:true});const workspace=await mkdtemp(join(resolve(parent),'monitor-admission-'));await mkdir(join(workspace,'.claude'));await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}));
 const observation=join(workspace,'monitor-admission.json'),preload=join(workspace,'monitor-admission-preload.mjs');await writeFile(preload,nativeMonitorAdmissionInspector(observation),{mode:0o600});
 const bridge=fileURLToPath(new URL('./pty_bridge.py',import.meta.url));let transport,terminal='',theme=false,security=false,navigated=false,trusted=false,exiting=false,inputReady=false,armed=false,pollBusy=false;const timers=[];const send=(text,delay=150)=>timers.push(setTimeout(()=>transport?.send(text),delay));
 const poll=setInterval(async()=>{if(pollBusy||!transport||exiting)return;pollBusy=true;try{if(inputReady&&!armed){await writeFile(observation+'.armed','Original prompt ready after trust');armed=true;}const evidence=JSON.parse(await readFile(observation,'utf8').catch(()=>'null'));if(evidence?.surface==='terminal'&&trusted){exiting=true;send('\x04');send('\x04',800);}}finally{pollBusy=false;}},100);
 try{
  const run=await record({executable:'/usr/bin/python3',cwd:workspace,output,timeoutMs:50000,maxBytes:4*1024*1024,args:[bridge,resolve(executable),'--setting-sources','user','--strict-mcp-config','--tools','Read','--permission-mode','default'],env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),TERM:'xterm-256color',COLUMNS:'120',LINES:'40',BUN_OPTIONS:'--preload='+preload,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},onStdout(bytes,channel){transport=channel;terminal+=bytes.toString('utf8');const screen=recognizeOnboardingPrompt(terminal,workspace);if(screen==='theme'&&!theme){theme=true;send('\r');}else if(screen==='security-notes'&&theme&&!security){security=true;send('\r');}else if(screen==='workspace-trust'&&!navigated){navigated=true;send('\x1b[B');}else if(screen==='workspace-trust-selected'&&!trusted){trusted=true;send('\r');}const compact=terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');if(trusted&&(compact.includes('shift+tabtocycle')||compact.includes('manualmodeon')))inputReady=true;}});
  const evidence=JSON.parse(await readFile(observation,'utf8').catch(()=>'null')),error=await readFile(observation+'.error','utf8').catch(()=>'');const proof={run,evidence,error,trusted,inputReady,exiting,workspace,modelRequests:0,realModelRequests:0,scope:'Original interactive getter under an isolated offline helper-backed profile; not account-wide admission or app monitor delivery.'};await writeFile(join(run.directory,'monitor-admission-proof.json'),JSON.stringify(proof,null,2)+'\n');assert.equal(run.code,0);assert.equal(run.reason,undefined);assert.equal(error,'');assert.ok(evidence&&trusted&&inputReady&&exiting);return proof;
 }finally{clearInterval(poll);for(const timer of timers)clearTimeout(timer);}
}
