import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {join,resolve} from 'node:path';

/** Only the selected disposable plugin and workspace are written; original plugin admission stays native. */
export async function addNativeLspFixture(workspace,plugin){
 workspace=resolve(workspace);plugin=resolve(plugin);const owner=randomUUID();
 await writeFile(join(workspace,'native-lsp-owner.json'),JSON.stringify({workspace,owner}),{mode:0o600});
 await writeFile(join(workspace,'release.review'),'import { release } from "./definitions.review";\nrelease;\n');
 await writeFile(join(workspace,'unmapped.txt'),'No language server owns this extension.\n');
 await writeFile(join(workspace,'definitions.review'),'export const release = "2.1.302";\n');
 await writeFile(join(plugin,'owned-lsp-server.mjs'),await readFile(new URL('./owned-lsp-server.mjs',import.meta.url)));
 await writeFile(join(plugin,'.lsp.json'),JSON.stringify({review:{command:process.execPath,args:[join(plugin,'owned-lsp-server.mjs'),workspace,owner],extensionToLanguage:{'.review':'typescript'},transport:'stdio',startupTimeout:5000,requestTimeout:5000,shutdownTimeout:1500,restartOnCrash:true,maxRestarts:1}}));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&/^native_lsp_[1-7]$/.test(e.props.tool_use_id))await $.fs.write('native-lsp-result-'+e.props.tool_use_id+'.json',JSON.stringify({props:e.props}));return next(e);});}`);
 return {source:join(workspace,'release.review'),target:join(workspace,'definitions.review')};
}

export async function verifyNativeLspFixture(workspace,calls,{checkProcessLiveness=true,lifecycle=false,lifetime=false}={}){
 assert.ok(calls.length>0&&!calls.some(row=>row.error),'Owned LSP model failed');
 const results=calls.filter(row=>row.lspResult).map(row=>row.lspResult);
 for(const phase of lifetime?[1,7]:lifecycle?[1,2,3,4,5,6,7]:[1,2,3]){
  const result=results.find(row=>row.tool_use_id==='native_lsp_'+phase);assert.ok(result,'Original LSP result missing: '+phase);
  if(![5,6].includes(phase))assert.notEqual(result.is_error,true);
  if(phase===5)assert.match(JSON.stringify(result.content),/crash|connection|closed|start|initializ|disposed/i);
  if(phase===6)assert.match(JSON.stringify(result.content),/exceeded max crash recovery attempts \(1\)/);
  if(phase===3)assert.equal(result.content,'No LSP server available for file type: .txt');
  const text=JSON.stringify(result.content);if([1,4,7].includes(phase))assert.match(text,/definitions\.review/);if(phase===2)assert.match(text,/OwnedReleaseDefinition/);
 }
 const receipts=(await readFile(join(workspace,'native-lsp-receipts.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 const navigation=receipts.filter(row=>['textDocument/definition','textDocument/hover'].includes(row.method));
 assert.equal(navigation.length,lifetime?3:lifecycle?4:2);for(const row of navigation){assert.deepEqual(row.position,{line:1,character:0});assert.ok(row.uri.endsWith('/release.review'));}
 const messages=JSON.stringify(calls.map(row=>row.messages));assert.match(messages,/OwnedReleaseDiagnostic/);assert.doesNotMatch(messages,/OwnedStaleDiagnostic/);
 const starts=receipts.filter(row=>row.event==='start');assert.ok(starts.length>0);
 for(const start of starts){if(lifecycle&&receipts.some(row=>row.event==='crash'&&row.pid===start.pid)){assert.ok(receipts.some(row=>row.event==='exit'&&row.pid===start.pid&&row.code===7),'Controlled LSP crash exit missing');}else{assert.ok(receipts.some(row=>row.method==='shutdown'&&row.pid===start.pid),'Original LSP graceful shutdown request missing');assert.ok(receipts.some(row=>row.event==='exit'&&row.pid===start.pid&&row.code===0),'Owned LSP exit receipt missing');assert.ok(receipts.findIndex(row=>row.method==='shutdown'&&row.pid===start.pid)<receipts.findIndex(row=>row.event==='exit'&&row.pid===start.pid),'Owned LSP exited before original shutdown');}if(checkProcessLiveness){try{process.kill(start.pid,0);assert.fail('Owned LSP process remains live');}catch(error){if(error.code!=='ESRCH')throw error;}}}
 if(lifetime){
  for(const call of calls)for(const message of call.messages??[])for(const block of Array.isArray(message.content)?message.content:[])if(block.type==='tool_result'&&block.tool_use_id==='native_lsp_4')assert.doesNotMatch(JSON.stringify(block.content),/definitions\.review/,'Late held navigation replaced the interrupted result');
  assert.equal(starts.length,1);const held=receipts.find(row=>row.event==='held'),released=receipts.find(row=>row.event==='released');assert.ok(held&&released);assert.equal(held.id,released.id);
  const proof=JSON.parse(await readFile(join(workspace,'native-lsp-app-proof.json'),'utf8'));assert.equal(proof.lateResponseIsolated,true);assert.equal(proof.freshNavigationAfterInterruption,true);assert.equal(proof.steps.length,3);
 }
 if(lifecycle){
  assert.equal(starts.length,4);assert.equal(receipts.filter(row=>row.event==='crash').length,3);assert.equal(receipts.filter(row=>row.event==='crash'&&row.reason==='initialization').length,1);
  assert.ok(receipts.some(row=>row.pid===starts[1].pid&&row.method==='textDocument/didOpen'&&row.version===2),'Recovered server did not receive reopened document version');
  assert.ok(receipts.some(row=>row.pid===starts[3].pid&&row.method==='textDocument/didOpen'&&row.version===1),'Reloaded manager did not reset document generation');
  const proof=JSON.parse(await readFile(join(workspace,'native-lsp-app-proof.json'),'utf8'));assert.equal(proof.localReloadNoModelRequest,true);assert.equal(proof.localReloadHumanInputDelta,1);assert.equal(proof.budgetStartCount,3);assert.equal(proof.steps.length,7);
 }
 const debug=await readFile(join(workspace,'native-debug.log'),'utf8');assert.ok(debug.split('\n').some(line=>line.includes('plugin:native-history-fixture:review')&&line.includes("Received response 'shutdown -")),'Original LSP shutdown acknowledgement missing');assert.ok(!debug.split('\n').filter(line=>!lifecycle||Date.parse(line.slice(0,24))>=starts.at(-1).at).some(line=>line.includes('plugin:native-history-fixture:review')&&/stop failed|timed out/.test(line)),'Original LSP shutdown failed');
 return {originalHeldRequestInterruption:lifetime,originalCrashRecovery:lifecycle,originalCrashBudget:lifecycle,originalPluginReload:lifecycle,processLivenessChecked:checkProcessLiveness,originalDefinition:true,originalHover:true,unmappedFileRefused:true,currentDiagnosticDelivered:true,staleDiagnosticRefused:true,ownedServerShutdown:true,gracefulServerShutdown:true,serverStarts:starts.length};
}
