import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {join,resolve} from 'node:path';

/** Only the selected disposable plugin and workspace are written; original plugin admission stays native. */
export async function addNativeLspFixture(workspace,plugin){
 workspace=resolve(workspace);plugin=resolve(plugin);const owner=randomUUID();
 await writeFile(join(workspace,'native-lsp-owner.json'),JSON.stringify({workspace,owner}),{mode:0o600});
 await writeFile(join(workspace,'release.review'),'import { release } from "./definitions.review";\nrelease;\n');
 await writeFile(join(workspace,'unmapped.txt'),'No language server owns this extension.\n');
 await writeFile(join(workspace,'definitions.review'),'export const release = "2.1.302";\n');
 await writeFile(join(plugin,'owned-lsp-server.mjs'),await readFile(new URL('./owned-lsp-server.mjs',import.meta.url)));
 await writeFile(join(plugin,'.lsp.json'),JSON.stringify({review:{command:process.execPath,args:[join(plugin,'owned-lsp-server.mjs'),workspace,owner],extensionToLanguage:{'.review':'typescript'},transport:'stdio',startupTimeout:5000,requestTimeout:5000,shutdownTimeout:1500,restartOnCrash:true,maxRestarts:1}}));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&/^native_lsp_[123]$/.test(e.props.tool_use_id))await $.fs.write('native-lsp-result-'+e.props.tool_use_id+'.json',JSON.stringify({props:e.props}));return next(e);});}`);
 return {source:join(workspace,'release.review'),target:join(workspace,'definitions.review')};
}

export async function verifyNativeLspFixture(workspace,calls){
 assert.ok(calls.length>0&&!calls.some(row=>row.error),'Owned LSP model failed');
 const results=calls.filter(row=>row.lspResult).map(row=>row.lspResult);
 for(const phase of [1,2,3]){
  const result=results.find(row=>row.tool_use_id==='native_lsp_'+phase);assert.ok(result,'Original LSP result missing: '+phase);
  if(phase<3)assert.notEqual(result.is_error,true);else assert.equal(result.is_error,true);
  const text=JSON.stringify(result.content);if(phase===1)assert.match(text,/definitions\.review/);if(phase===2)assert.match(text,/OwnedReleaseDefinition/);
 }
 const receipts=(await readFile(join(workspace,'native-lsp-receipts.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 const navigation=receipts.filter(row=>['textDocument/definition','textDocument/hover'].includes(row.method));
 assert.equal(navigation.length,2);for(const row of navigation){assert.deepEqual(row.position,{line:1,character:0});assert.ok(row.uri.endsWith('/release.review'));}
 const messages=JSON.stringify(calls.map(row=>row.messages));assert.match(messages,/OwnedReleaseDiagnostic/);assert.doesNotMatch(messages,/OwnedStaleDiagnostic/);
 const starts=receipts.filter(row=>row.event==='start');assert.ok(starts.length>0);
 for(const start of starts){assert.ok(receipts.some(row=>row.method==='shutdown'&&row.pid===start.pid),'Original LSP graceful shutdown request missing');assert.ok(receipts.some(row=>row.method==='exit'&&row.pid===start.pid),'Original LSP exit notification missing');assert.ok(receipts.some(row=>row.event==='exit'&&row.pid===start.pid&&row.code===0),'Owned LSP exit receipt missing');try{process.kill(start.pid,0);assert.fail('Owned LSP process remains live');}catch(error){if(error.code!=='ESRCH')throw error;}}
 return {originalDefinition:true,originalHover:true,unmappedFileRefused:true,currentDiagnosticDelivered:true,staleDiagnosticRefused:true,ownedServerShutdown:true,gracefulServerShutdown:true,serverStarts:starts.length};
}
