"""Verify saved native recommendation evidence; this is not actual-app acceptance."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile


def verify(directory):
    directory = Path(directory)
    route = json.loads((directory / 'route.json').read_text())
    shutdown = json.loads((directory / 'shutdown.json').read_text())
    boundary = json.loads((directory / 'offline-boundary.json').read_text())
    states = [json.loads(line) for line in (directory / 'hint-state.jsonl').read_text().splitlines()]
    assert boundary['networkDisabled'] and set(boundary['networks']) == {'none'}
    assert boundary['pinnedExecutableReadOnly']
    assert boundary['memory'] == boundary['memorySwap'] == 2 * 1024 ** 3
    assert boundary['nanoCpus'] == 2 * 10 ** 9
    assert route['targetSha256'] == '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'
    assert route['decision'] == 'no' and route['realModelRequests'] == 0
    shown = route['projected']
    assert shown['kind'] == 'plugin_hint' and shown['sessionId'] == route['sessionId']
    assert [choice['value'] for choice in shown['choices']] == ['yes', 'no', 'disable']
    assert shown['pluginName'] == 'document-skills'
    assert shown['marketplaceName'] == 'anthropic-agent-skills'
    assert shown['sourceCommand'] == '/usr/bin/printf'
    assert any(dialog['id'] == shown['id'] and dialog['kind'] == 'plugin_hint'
               for state in states for dialog in state['dialogs'])
    assert not states[-1]['dialogs']
    assert shutdown['ownerReleased'] and shutdown['nativeExit'] == 143
    assert shutdown['nativePid'] == route['nativePid']
    calls = [call for call in route['modelCalls'] if call['path'].startswith('/v1/messages')]
    assert len(calls) == 2
    blocks = [block for message in calls[-1]['messages']
              if isinstance(message.get('content'), list) for block in message['content']]
    tool = next(block for block in blocks if block.get('type') == 'tool_use' and block.get('name') == 'Bash')
    assert tool['input']['command'] == route['command']
    result = next(block for block in blocks if block.get('type') == 'tool_result' and block['tool_use_id'] == tool['id'])
    assert result['is_error'] is False and result['content'] == 'Release check complete.'
    provenance = route['officialProvenance']
    assert provenance['repository'] == 'https://github.com/anthropics/skills.git'
    assert provenance['commit'] == 'dbd4588f9e1033efb41dad4bef2f7947c8993d44'
    archive = directory / 'native-evidence.tgz'
    with tarfile.open(archive) as tar:
        members = [member for member in tar.getmembers() if member.isfile()]
        def read_suffix(suffix):
            matches = [member for member in members if member.name.endswith(suffix)]
            assert len(matches) == 1, suffix
            return tar.extractfile(matches[0]).read()
        assert json.loads(read_suffix('/route.json')) == route
        assert read_suffix('/.git/refs/heads/main').decode().strip() == provenance['commit']
        manifest = read_suffix('/marketplaces/anthropic-agent-skills/.claude-plugin/marketplace.json')
        assert hashlib.sha256(manifest).hexdigest() == provenance['manifestSha256']
        registration = json.loads(read_suffix('/known_marketplaces.json'))['anthropic-agent-skills']
        assert registration['source'] == {'source': 'github', 'repo': 'anthropics/skills'}
        settings = json.loads(read_suffix('/.claude/.claude.json'))
        assert 'document-skills@anthropic-agent-skills' in settings['claudeCodeHints']['plugin']
        journal = [json.loads(line) for line in read_suffix('/' + route['sessionId'] + '.jsonl').decode().splitlines()]
        humans = [entry for entry in journal if entry.get('type') == 'user' and isinstance(entry.get('message', {}).get('content'), str)]
        assert [entry['message']['content'] for entry in humans] == ['Seed the owned plugin recommendation review.', 'Run the private release check and report its result.']
        assert len({entry['uuid'] for entry in humans}) == 2
    return {'scope': 'Native admission, typed projection/defer, persisted dismissed candidate and owned shutdown only; no actual-app, installation, disable, repeated-session suppression or combined F1–F5 acceptance.', 'sessionId': route['sessionId'], 'nativePid': route['nativePid'], 'humanUuids': [entry['uuid'] for entry in humans], 'nativeModelRequests': len(calls), 'realModelRequests': 0, 'originalToolResultStrippedHint': True, 'officialCachedCommitVerified': True, 'deferPersisted': True, 'ownedShutdown': True, 'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest()}


if __name__ == '__main__':
    result = verify(sys.argv[1])
    (Path(sys.argv[1]) / 'independent-verification.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(result, ensure_ascii=False))
