import { mkdtemp, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';
import http from 'node:http';

/** Research only: native embedded engine calls under one unchanged interactive process. */
export async function startNativeUiEngineProbe(workspace) {
  const directory = await mkdtemp('/private/tmp/cc-ui-');
  const socketPath = join(directory, 'native.sock'), token = randomBytes(24).toString('hex');
  const preload = join(directory, 'engine.mjs');
  const source = `import http from 'node:http';
import {writeFileSync} from 'node:fs';
delete process.env.BUN_OPTIONS;
const server=http.createServer(async(req,res)=>{
  const reply=(code,value)=>{res.writeHead(code,{'content-type':'application/json'});res.end(JSON.stringify(value));};
  if(req.method!=='POST'||req.url!=='/probe'||req.headers['x-research-token']!==${JSON.stringify(token)})return reply(403,{});
  try{
    const {ioe}=await import('/$bunfs/root/chunk-wn0572jb.js');
    if(!ioe({isRemoteTransport:false,redactsWhatItPersists:false}))throw Error('Native local UI eligibility refused');
    const {I9s,d2t}=await import('/$bunfs/root/chunk-a32bd1ts.js');
    const {I9e}=await import('/$bunfs/root/chunk-c7wcn77x.js');
    await import('/$bunfs/root/chunk-rpe8kh25.js');
    const clientId='research-terminal-desktop';
    await I9s({surface:'desktop',clientId,viewport:{columns:100,rows:30}},[]);
    try{
      const before=await I9e.run({surface:'desktop',component:'AbovePrompt',requestId:'research-terminal-composer',props:{}});
      writeFileSync(${JSON.stringify(join(workspace,'native-engine-before.json'))},JSON.stringify(before));
      const candidates=[];const visit=value=>{if(!value||typeof value!=='object')return;if(typeof value.plugin==='string'&&Number.isInteger(value.handle))candidates.push(value);for(const child of Object.values(value))visit(child);};visit(before.tree);
      const button=candidates.find(value=>value.key==='native-engine-button')??candidates[0];
      let pressed;if(button)pressed=await I9e.press({plugin:button.plugin,handle:button.handle,surface:'desktop',...(button.key?{key:button.key}:{})});
      await new Promise(resolve=>setTimeout(resolve,150));
      const after=await I9e.run({surface:'desktop',component:'AbovePrompt',requestId:'research-terminal-composer',props:{}});
      reply(200,{nativePid:process.pid,nativeLocalEligibility:true,before,after,button,pressed});
    }finally{await d2t(clientId,'detach');}
  }catch(error){reply(500,{error:String(error)});}
});
await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(${JSON.stringify(socketPath)},resolve);});server.unref();
`;
  await writeFile(preload, source);
  return { preload, source, bunOptions: '--preload=' + preload,
    probe() { return new Promise((resolve,reject)=>{
      const req=http.request({socketPath,path:'/probe',method:'POST',headers:{'x-research-token':token}},res=>{
        let text='';res.setEncoding('utf8');res.on('data',chunk=>{text+=chunk;if(text.length>1048576)res.destroy(Error('UI probe response too large'));});
        res.on('end',()=>{try{const value=JSON.parse(text);if(res.statusCode!==200)reject(Error(JSON.stringify(value)));else resolve(value);}catch(error){reject(error);}});res.on('error',reject);
      });req.setTimeout(5000,()=>req.destroy(Error('Native UI probe timed out')));req.on('error',reject);req.end();
    }); }
  };
}
