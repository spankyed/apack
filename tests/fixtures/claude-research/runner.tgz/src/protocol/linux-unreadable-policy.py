"""Explicit pinned-native Linux policy probe; invoke only in a disposable owned container.

The source and binary are read-only mounts. /evidence is a new private output directory.
Only a bounded loopback synthetic endpoint is available; this is native startup evidence only.
"""
import hashlib
import http.server
import threading
import json
import os
from pathlib import Path
import pwd
import signal
import subprocess
import sys
import tempfile
import time

TARGET = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'


def main():
    if sys.platform != 'linux' or not Path('/.dockerenv').is_file() or os.getuid() != 0:
        raise RuntimeError('Requires root setup inside a newly owned Linux container')
    if len(sys.argv) != 2:
        raise RuntimeError('Supply the explicit immutable native executable')
    binary = Path(sys.argv[1]).resolve(strict=True)
    digest = hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest()
    if digest != TARGET:
        raise RuntimeError('Native executable does not match the pinned Linux target')
    output = Path('/evidence')
    output.mkdir(exist_ok=True)
    if any(output.iterdir()):
        raise RuntimeError('Evidence destination must be empty')
    policy_dir = Path('/etc/claude-code')
    policy_dir.mkdir(mode=0o755)  # Never overwrite a pre-existing policy installation.
    policy = policy_dir / 'managed-settings.json'
    with policy.open('x') as stream:
        json.dump({'allowManagedHooksOnly': True}, stream)
    policy.chmod(0)
    account = pwd.getpwnam('node')
    with tempfile.TemporaryDirectory(prefix='claude-policy-unreadable-') as private:
        home = Path(private)
        home.chmod(0o700)
        os.chown(home, account.pw_uid, account.pw_gid)
        requests = []
        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass
            def do_POST(self):
                length = int(self.headers.get('Content-Length', '0'))
                if length > 2097152 or len(requests) >= 4:
                    self.send_error(413)
                    return
                body = self.rfile.read(length)
                requests.append({'path': self.path, 'bodySha256': hashlib.sha256(body).hexdigest()})
                parsed = json.loads(body)
                if 'count_tokens' in self.path:
                    reply = {'input_tokens': 10}
                else:
                    reply = {'id': 'msg_owned_policy', 'type': 'message', 'role': 'assistant',
                             'model': parsed.get('model'), 'content': [{'type': 'text', 'text': 'Owned policy startup observed.'}],
                             'stop_reason': 'end_turn', 'stop_sequence': None,
                             'usage': {'input_tokens': 10, 'output_tokens': 10}}
                if parsed.get('stream') and 'count_tokens' not in self.path:
                    start = {**reply, 'content': [], 'stop_reason': None, 'usage': {'input_tokens': 10, 'output_tokens': 0}}
                    events = [('message_start', {'type': 'message_start', 'message': start}),
                              ('content_block_start', {'type': 'content_block_start', 'index': 0, 'content_block': {'type': 'text', 'text': ''}}),
                              ('content_block_delta', {'type': 'content_block_delta', 'index': 0, 'delta': {'type': 'text_delta', 'text': reply['content'][0]['text']}}),
                              ('content_block_stop', {'type': 'content_block_stop', 'index': 0}),
                              ('message_delta', {'type': 'message_delta', 'delta': {'stop_reason': 'end_turn', 'stop_sequence': None}, 'usage': {'output_tokens': 10}}),
                              ('message_stop', {'type': 'message_stop'})]
                    data = ''.join('event: ' + name + '\ndata: ' + json.dumps(event) + '\n\n' for name, event in events).encode()
                    content_type = 'text/event-stream'
                else:
                    data = json.dumps(reply).encode()
                    content_type = 'application/json'
                self.send_response(200)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(len(data)))
                self.end_headers()
                self.wfile.write(data)
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        server.daemon_threads = True
        threading.Thread(target=server.serve_forever, daemon=True).start()
        args = ['runuser', '-u', 'node', '--', 'env', '-i',
                'PATH=/usr/local/bin:/usr/bin:/bin', 'HOME=' + str(home),
                'CLAUDE_CONFIG_DIR=' + str(home / '.claude'), 'TERM=dumb',
                'ANTHROPIC_API_KEY=owned-policy-fixture',
                'ANTHROPIC_BASE_URL=http://127.0.0.1:' + str(server.server_port),
                'DISABLE_NON_ESSENTIAL_TRAFFIC=1',
                str(binary), '--print', '--output-format', 'json',
                '--permission-mode', 'default', 'Inspect policy startup only.']
        started = time.monotonic()
        reason = None
        stdout_path, stderr_path = output / 'stdout.txt', output / 'stderr.txt'
        with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
            child = subprocess.Popen(args, cwd=home, stdout=stdout, stderr=stderr,
                                     start_new_session=True)
            try:
                while child.poll() is None:
                    if time.monotonic() - started > 15:
                        reason = 'deadline'
                    if max(stdout_path.stat().st_size, stderr_path.stat().st_size) > 1048576:
                        reason = 'output-bound'
                    if reason:
                        os.killpg(child.pid, signal.SIGKILL)
                        break
                    time.sleep(0.05)
                code = child.wait(timeout=3)
            finally:
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=3)
        # Keep the native output untouched, including failures that contradict source inference.
        texts = [path.read_bytes()[:1048576].decode('utf-8', errors='replace')
                 for path in [stdout_path, stderr_path]]
        combined = '\n'.join(texts)
        server.shutdown(); server.server_close()
        observed = (reason is None
                    and str(policy) in combined
                    and any(term in combined.lower() for term in ['eacces', 'permission denied', 'could not be read']))
        result = {'targetSha256': digest, 'sourceSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'scope': 'Original native startup only; actual-app refusal/recovery unverified',
                  'policy': {'path': str(policy), 'uid': policy.stat().st_uid,
                             'mode': oct(policy.stat().st_mode & 0o777)},
                  'argv': args, 'exitCode': code, 'terminationReason': reason,
                  'durationSeconds': round(time.monotonic() - started, 3),
                  'nativeUnreadablePolicyDiagnosticObserved': observed,
                  'nativeStartupRefused': reason is None and code != 0 and not requests,
                  'syntheticRequests': requests, 'realModelRequests': 0,
                  'network': 'Container launched with --network none; bounded synthetic endpoint is loopback only',
                  'outputs': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                              for path in [stdout_path, stderr_path]}}
        (output / 'manifest.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({'exitCode': code, 'terminationReason': reason,
                          'nativeUnreadablePolicyDiagnosticObserved': observed, 'nativeStartupRefused': result['nativeStartupRefused']}))
        return 0 if observed else 1


if __name__ == '__main__':
    sys.exit(main())
