import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {record} from './record.mjs';
import {hash} from '../artifacts/runs.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';

/** Observe the original non-React theme resolver in a private original print process. */
export async function probeNativePrintTheme(executable,parent,output,checkout){
 const targetSha256='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37';assert.equal(hash(await readFile(executable)),targetSha256);
 await mkdir(parent,{recursive:true});const workspace=await mkdtemp(join(parent,'native-print-theme-')),plugin=join(workspace,'plugin'),receipt=join(workspace,'theme-receipt.json'),trigger=join(workspace,'inspect-theme');
 await mkdir(join(workspace,'.claude/themes'),{recursive:true});await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
 await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'print-theme-fixture',version:'0.0.1'}));
 await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'AbovePrompt'},($,e)=>{const {Box,Text}=$.ui.resolve(e);return Box({children:[Text({color:'warning',children:['Review needed']}),Text({children:['Workspace ready']})]});});}`);
 await writeFile(join(workspace,'.claude/themes/research.json'),JSON.stringify({name:'Research',base:'light',overrides:{text:'#123456',warning:'#abcdef'}}));
 const settings={theme:'custom:research',apiKeyHelper:'/usr/bin/printf research-fixture-key'};await writeFile(join(workspace,'.claude/settings.json'),JSON.stringify(settings));
 const preload=join(workspace,'observe-theme.mjs');
 await writeFile(preload,`import {existsSync,writeFileSync} from 'node:fs';delete process.env.BUN_OPTIONS;let active=false;const timer=setInterval(async()=>{if(active||!existsSync(${JSON.stringify(trigger)}))return;active=true;clearInterval(timer);try{const preferences=await import('/$bunfs/root/chunk-c7857g1z.js'),themes=await import('/$bunfs/root/chunk-5feck2gp.js'),resolver=await import('/$bunfs/root/chunk-4z4q4qvr.js');await themes.ETt();const setting=preferences.Ss('theme','dark');writeFileSync(${JSON.stringify(receipt)},JSON.stringify({setting,palette:resolver.UKe(setting.value),customThemes:themes.wcr().map(theme=>({slug:theme.slug,base:theme.base,overrides:theme.overrides}))}));}catch(error){writeFileSync(${JSON.stringify(receipt)},JSON.stringify({error:String(error)}));}},25);timer.unref();`);
 let alive=true;const bridge=checkout?await (await import(pathToFileURL(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/print-client-bridge.ts')).href)).prepareClaudePrintClients({currentPid:()=>alive?process.pid:undefined,bunOptions:'--preload='+preload}):undefined;
 const events=[];
 const model=await startSyntheticModel(workspace,'TextOnly'),waiting=new Map();let buffer='',task,problem,observed;
 try{
  const run=await record({executable,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--tools','','--plugin-dir',plugin,'--strict-mcp-config'],cwd:workspace,output,timeoutMs:15000,
   env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),PATH:'/usr/bin:/bin',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',BUN_OPTIONS:bridge?.bunOptions??'--preload='+preload,ANTHROPIC_BASE_URL:model.url},
   input:[JSON.stringify({type:'control_request',request_id:'initialize',request:{subtype:'initialize',hooks:{}}})+'\n'],
   onStdout(bytes,transport){buffer+=bytes;while(buffer.includes('\n')){const end=buffer.indexOf('\n'),line=buffer.slice(0,end);buffer=buffer.slice(end+1);let value;try{value=JSON.parse(line)}catch{continue}if(value.type==='system')events.push(value);if(value.type!=='control_response')continue;const response=value.response,pending=waiting.get(response.request_id);if(pending){waiting.delete(response.request_id);response.subtype==='success'?pending.resolve(response.response):pending.reject(Error(JSON.stringify(response)))}if(response.request_id!=='initialize'||task)continue;
    const call=request=>new Promise((resolve,reject)=>{const id=randomUUID();waiting.set(id,{resolve,reject});transport.send(JSON.stringify({type:'control_request',request_id:id,request})+'\n')});
    task=(async()=>{assert.equal(response.subtype,'success');await call({subtype:'ui_attach',client_id:'print-theme',surface:'desktop',answers:[]});const frame=await call({subtype:'ui_render',client_id:'print-theme',surface:'desktop',component:'AbovePrompt',instance_id:'theme-above',props:{}});await writeFile(trigger,'inspect');const deadline=Date.now()+4000;while(Date.now()<deadline){try{observed=JSON.parse(await readFile(receipt,'utf8'));break}catch(error){if(error.code!=='ENOENT')throw error}await new Promise(resolve=>setTimeout(resolve,25))}assert.ok(observed,'Native theme resolver did not answer');assert.equal(observed.error,undefined);assert.equal(observed.setting.value,'custom:research');assert.equal(observed.palette.text,'#123456');assert.equal(observed.palette.warning,'#abcdef');assert.ok(JSON.stringify(frame.tree).includes('warning'),'Original public print drawing should retain semantic role');observed.frame=frame;
      if(bridge){
       const site={client_id:'print-theme',surface:'desktop',component:'AbovePrompt',instance_id:'theme-above',instance_revision:1,props:{}};
       const projected=await bridge.projection.project(site,frame);assert.equal(projected.tree.children[0].props.color,'#abcdef');assert.equal(projected.tree.children[1].props.color,'#123456');observed.projected=projected;
       const decorations=await bridge.projection.prompt('print-theme',[{start:0,end:6,color:'warning',backgroundColor:'text'}]);assert.deepEqual(decorations,[{start:0,end:6,color:'#abcdef',backgroundColor:'#123456',_apackThemeColor:'warning',_apackThemeBackgroundColor:'text'}]);observed.decorations=decorations;
       await writeFile(join(workspace,'.claude/themes/research.json'),JSON.stringify({name:'Research',base:'light',overrides:{text:'#123456',warning:'#997755'}}));
       const reloadDeadline=Date.now()+4000;let reloaded;while(Date.now()<reloadDeadline){reloaded=await bridge.projection.project(site,frame);if(reloaded.tree.children[0].props.color==='#997755')break;await new Promise(resolve=>setTimeout(resolve,50));}
       assert.equal(reloaded.tree.children[0].props.color,'#997755');observed.reloaded=reloaded;assert.ok(events.some(event=>event.subtype==='ui_prompt_theme'&&event.palette?.warning==='#997755'));observed.nativeThemeEvents=events.filter(event=>event.subtype==='ui_prompt_theme').length;
       await bridge.projection.detach('print-theme');
      }
      await call({subtype:'ui_detach',client_id:'print-theme'});transport.closeInput();})().catch(error=>{problem=error;transport.stop('print-theme-proof-failed')});
   }} });
  await task;const evidence={verified:!problem&&run.status==='complete',targetSha256,workspace,observed,problem:problem?String(problem):undefined,syntheticApiRequests:model.calls.length,realModelRequests:0,userPromptsSent:0,sourceToolSha256:hash(await readFile(new URL(import.meta.url))),runtimeSourceHashes:checkout?Object.fromEntries(await Promise.all(['print-client-bridge.ts','print-client-runtime.ts','native-theme-runtime.ts'].map(async name=>[name,hash(await readFile(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code',name)))]))):undefined,qualification:bridge?'Original print resolver plus product native palette/tree/decoration mapping and custom-file watcher reload; not actual-app acceptance.':'Original non-React print settings/custom-theme resolver observation. No app acceptance or theme adaptation claimed.'};await writeFile(join(run.directory,'native-print-theme.json'),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify({directory:run.directory,status:evidence.verified?'complete':'failed',problem:evidence.problem}));assert.ifError(problem);assert.equal(run.status,'complete');return evidence;
 }finally{alive=false;await bridge?.close();await model.close();}
}
if(process.argv[1]===new URL(import.meta.url).pathname)await probeNativePrintTheme(...process.argv.slice(2).map(value=>resolve(value)));
