import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
export const nativeMcpUrlSteps = ['url-decline','url-cancel','url-skip','url-waiting-cancel','url-complete','url-pause'].map((scenario,index)=>({phase:index+8,scenario}));
export const nativeMcpUrlRetrySteps = ['url-retry','url-retry-decline','url-retry-cancel','url-retry-waiting-cancel','url-retry-pause'].map((scenario,index)=>({phase:index+14,scenario}));
export const nativeMcpModernUrlSteps = ['modern-confirm','modern-decline','modern-cancel','modern-open-cancel','modern-pause'].map((scenario,index)=>({phase:index+19,scenario}));
const rows = async path => (await readFile(path,'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
/** The interactive MCP tool returns native decision text as data, without a model is_error bit. */
export function verifyNativeMcpUrlDeclineResults(results){
 for(const [phase,action] of [[15,'declined'],[16,'canceled'],[17,'canceled']]){
  const expected='URL elicitation was '+action+' by the user. The tool "echo" could not complete because it requires the user to open a URL.';
  assert.ok(results.some(block=>block.tool_use_id==='native_mcp_input_'+phase&&!Object.hasOwn(block,'is_error')&&block.content===expected),'Original interactive MCP decision envelope missing for phase'+phase);
 }
}
export async function verifyNativeMcpUrlApp(workspace,calls,{retry=false,modern=false,realBrowser=false}={}){
 assert.ok(!(retry&&modern));assert.ok(!realBrowser||modern);
 const browserOrigin=realBrowser?JSON.parse(await readFile(join(workspace,'owned-mcp-browser.json'),'utf8')).origin:undefined;
 const reviewUrl=phase=>realBrowser?browserOrigin+'/release-review?phase='+phase:'https://example.invalid/release-review';
 const expected=modern?nativeMcpModernUrlSteps:retry?nativeMcpUrlRetrySteps:nativeMcpUrlSteps;
 const proof=JSON.parse(await readFile(join(workspace,'native-mcp-url-app-proof.json'),'utf8'));
 assert.deepEqual(proof.steps.map(({phase,scenario})=>({phase,scenario})),expected);
 for(const key of ['retainedDraft','originalNativeRecovery','recoveredSameSession',...(modern?['originalModern']:retry?['originalRetry']:['wrongCompletionIgnored'])])assert.equal(proof[key],true);
 assert.equal(proof.captures.length,4);assert.deepEqual(proof.geometry.map(row=>[row.phase,row.width,row.height]),[['prompt',1100,900],['prompt',680,600],[modern?'opened':'waiting',1100,900],[modern?'opened':'waiting',680,600]]);
 for(const step of proof.steps){assert.equal(step.nativePid,proof.boundNativePid);assert.equal(step.retainedDraft,true);}
 const frames=await rows(join(workspace,'mcp-elicitation-receipts.jsonl'));
 if(modern){
  assert.ok(frames.some(row=>row.method==='server/discover'));assert.equal(frames.some(row=>row.method==='initialize'),false);
  const results=calls.flatMap(call=>(call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[])).filter(block=>block.type==='tool_result');
  for(const step of expected){
   const phaseCalls=frames.filter(row=>row.method==='tools/call'&&row.params.arguments.phase===step.phase);assert.equal(phaseCalls.length,step.scenario==='modern-pause'?1:2);
   for(const call of phaseCalls)assert.equal(call.params._meta['io.modelcontextprotocol/protocolVersion'],'2026-07-28');
   assert.equal(phaseCalls[0].params.inputResponses,undefined);
   if(step.scenario!=='modern-pause'){
    const action=step.scenario==='modern-confirm'?'accept':step.scenario==='modern-decline'?'decline':'cancel';
    assert.equal(phaseCalls[1].params.requestState,'modern-release-'+step.phase);assert.deepEqual(phaseCalls[1].params.inputResponses,{'release-review':{action}});
    const block=results.find(block=>block.tool_use_id==='native_mcp_input_'+step.phase);assert.ok(block);
    const text=typeof block.content==='string'?block.content:block.content.filter(item=>item.type==='text').map(item=>item.text).join('');assert.deepEqual(JSON.parse(text),{elicitation:{action}});
   }
  }
  assert.equal(proof.steps.find(step=>step.phase===23).nativeInterrupted,true);assert.equal(proof.openedWithoutAnswer,true);
  const browser=await rows(join(workspace,'native-mcp-url-browser.jsonl'));assert.deepEqual(browser.map(row=>({phase:row.phase,url:row.url})),[19,19,22].map(phase=>({phase,url:reviewUrl(phase)})));
 }else if(retry){
  for(const step of expected){const callsForPhase=frames.filter(row=>row.method==='tools/call'&&row.params.arguments.phase===step.phase);assert.equal(callsForPhase.length,step.scenario==='url-retry'?2:1);const errors=frames.filter(row=>row.fixtureOutgoing?.error?.data?.elicitations?.[0]?.elicitationId==='release-retry-'+step.phase);assert.equal(errors.length,1);assert.equal(errors[0].fixtureOutgoing.error.code,-32042);}
  assert.equal(frames.some(row=>typeof row.id==='string'&&row.id.startsWith('research-elicitation-')),false);
  const results=calls.flatMap(call=>(call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[])).filter(block=>block.type==='tool_result');
  assert.ok(results.some(block=>block.tool_use_id==='native_mcp_input_14'&&JSON.stringify(block.content).includes('Original retry completed for phase14')));
  verifyNativeMcpUrlDeclineResults(results);
  assert.equal(proof.steps.find(step=>step.phase===18).nativeInterrupted,true);
  const browser=await rows(join(workspace,'native-mcp-url-browser.jsonl'));assert.deepEqual(browser.map(row=>({phase:row.phase,url:row.url})),[14,17].map(phase=>({phase,url:'https://example.invalid/release-review'})));
 }else{
 for(const step of nativeMcpUrlSteps){const replies=frames.filter(row=>row.id==='research-elicitation-'+step.phase&&row.result);assert.equal(replies.length,1);assert.deepEqual(replies[0].result,{action:step.scenario==='url-decline'?'decline':['url-cancel','url-pause'].includes(step.scenario)?'cancel':'accept'});}
 const cancelled=frames.find(row=>row.method==='tools/call'&&row.params.arguments.phase===13);assert.ok(cancelled);assert.ok(frames.some(row=>row.method==='notifications/cancelled'&&row.params.requestId===cancelled.id));
 const notifications=frames.filter(row=>row.fixtureOutgoing?.method==='notifications/elicitation/complete').map(row=>row.fixtureOutgoing.params.elicitationId);assert.deepEqual(notifications,['release-review-foreign','release-review-12']);
 const browser=await rows(join(workspace,'native-mcp-url-browser.jsonl'));assert.deepEqual(browser.map(row=>({phase:row.phase,url:row.url})),[10,10,11,12].map(phase=>({phase,url:'https://example.invalid/release-review'})));
 }
 if(realBrowser){
  assert.deepEqual(proof.browserReturns.map(row=>[row.phase,row.width,row.height,row.completed]),[[19,1100,900,true],[19,680,600,true],[22,1100,900,false]]);
  assert.equal(proof.browserCaptures.length,2);
  const browserEvents=await rows(join(workspace,'owned-mcp-browser-events.jsonl')),launches=browserEvents.filter(row=>row.kind==='launch');assert.equal(launches.length,3);
  for(const row of proof.browserReturns){
   const launch=launches.find(launch=>launch.id===row.browserId);assert.ok(launch);assert.equal(launch.phase,row.phase);assert.equal(launch.url,reviewUrl(row.phase));
   assert.equal(row.nativePid,proof.boundNativePid);assert.equal(row.retainedDraft,true);assert.equal(row.retainedSelection,true);assert.equal(row.openedWithoutAnswer,true);
   assert.ok(browserEvents.some(event=>event.kind==='navigation'&&event.id===launch.id));assert.ok(browserEvents.some(event=>event.kind==='loaded'&&event.id===launch.id));
   assert.equal(browserEvents.filter(event=>event.kind==='complete'&&event.id===launch.id).length,row.completed?1:0);
   assert.ok(browserEvents.some(event=>event.kind==='exit'&&event.id===launch.id&&event.pid===launch.pid));
  }
  assert.equal(browserEvents.some(row=>['refused','launch-error'].includes(row.kind)),false);
 }
 assert.ok(calls.every(call=>!call.fixtureError&&['/v1/messages','/v1/messages/count_tokens'].includes(call.path?.split('?')[0])));
 assert.ok(calls.some(call=>JSON.stringify(call.messages??[]).includes('Continue after cancelling the release input.')));
 const natives=await rows(join(workspace,'native-children.jsonl')),exits=await rows(join(workspace,'native-exits.jsonl'));assert.equal(natives.length,3);assert.equal(natives[1].pid,proof.boundNativePid);
 for(const native of natives)assert.ok(exits.some(exit=>exit.pid===native.pid));for(let i=0;i<2;i++)assert.ok(exits.find(exit=>exit.pid===natives[i].pid).at<=natives[i+1].at);
 const children=await rows(join(workspace,'mcp-children.jsonl')),childExits=await rows(join(workspace,'mcp-exits.jsonl'));assert.ok(children.some(child=>child.ancestors.includes(proof.boundNativePid)));for(const child of children)assert.ok(childExits.some(exit=>exit.pid===child.pid));
 const preloads=await rows(join(workspace,'user-preload-calls.jsonl'));for(const native of natives)assert.ok(preloads.some(row=>row.pid===native.pid));
 const evidence=JSON.parse(await readFile(join(workspace,'native-terminal-app-evidence.json'),'utf8'));assert.equal(evidence.boundNativePid,proof.boundNativePid);assert.equal(evidence.sessionId,proof.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);assert.deepEqual(evidence.browserErrors,[]);
 return{originalRealBrowserReturn:realBrowser,originalNativeUrlActions:true,originalWaitingAndCompletion:!retry&&!modern,originalToolRetry:retry,originalModernInput:modern,originalBrowserInvocation:true,originalPauseCancellation:true,originalNativeRecovery:true,ownedNativeShutdown:true,ownedMcpShutdown:true,nativePreloadPreserved:true,nativeProcesses:3,qualification:realBrowser?'Original modern input-required URL open/reopen, real owned loopback browser navigation and return. Third-party account flows, OS default-browser integration and other owner/window/policy/task contexts remain separate.':modern?'Original modern2026-07-28 input_required and explicit URL confirmation in the main terminal composer. Inert BROWSER only; real navigation, task/channel and other owner/window/policy contexts remain separate.':retry?'Main terminal-owner -32042 retry flow with original tool retry/decline/cancel/Pause. Inert BROWSER only; no real web navigation, modern explicit confirmation or other owner/window/policy acceptance.':'Main legacy terminal-owner URL/waiting only. Original opener invokes an inert private BROWSER: no real web navigation/return, modern explicit confirmation, retry producer or other owner/window/task/policy acceptance.'};
}
