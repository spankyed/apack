import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
export const nativeMcpUrlSteps = ['url-decline','url-cancel','url-skip','url-waiting-cancel','url-complete','url-pause'].map((scenario,index)=>({phase:index+8,scenario}));
export const nativeMcpUrlRetrySteps = ['url-retry','url-retry-decline','url-retry-cancel','url-retry-waiting-cancel','url-retry-pause'].map((scenario,index)=>({phase:index+14,scenario}));
const rows = async path => (await readFile(path,'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
/** The interactive MCP tool returns native decision text as data, without a model is_error bit. */
export function verifyNativeMcpUrlDeclineResults(results){
 for(const [phase,action] of [[15,'declined'],[16,'canceled'],[17,'canceled']]){
  const expected='URL elicitation was '+action+' by the user. The tool "echo" could not complete because it requires the user to open a URL.';
  assert.ok(results.some(block=>block.tool_use_id==='native_mcp_input_'+phase&&!Object.hasOwn(block,'is_error')&&block.content===expected),'Original interactive MCP decision envelope missing for phase'+phase);
 }
}
export async function verifyNativeMcpUrlApp(workspace,calls,{retry=false}={}){
 const expected=retry?nativeMcpUrlRetrySteps:nativeMcpUrlSteps;
 const proof=JSON.parse(await readFile(join(workspace,'native-mcp-url-app-proof.json'),'utf8'));
 assert.deepEqual(proof.steps.map(({phase,scenario})=>({phase,scenario})),expected);
 for(const key of ['retainedDraft','originalNativeRecovery','recoveredSameSession',...(retry?['originalRetry']:['wrongCompletionIgnored'])])assert.equal(proof[key],true);
 assert.equal(proof.captures.length,4);assert.deepEqual(proof.geometry.map(row=>[row.phase,row.width,row.height]),[['prompt',1100,900],['prompt',680,600],['waiting',1100,900],['waiting',680,600]]);
 for(const step of proof.steps){assert.equal(step.nativePid,proof.boundNativePid);assert.equal(step.retainedDraft,true);}
 const frames=await rows(join(workspace,'mcp-elicitation-receipts.jsonl'));
 if(retry){
  for(const step of expected){const callsForPhase=frames.filter(row=>row.method==='tools/call'&&row.params.arguments.phase===step.phase);assert.equal(callsForPhase.length,step.scenario==='url-retry'?2:1);const errors=frames.filter(row=>row.fixtureOutgoing?.error?.data?.elicitations?.[0]?.elicitationId==='release-retry-'+step.phase);assert.equal(errors.length,1);assert.equal(errors[0].fixtureOutgoing.error.code,-32042);}
  assert.equal(frames.some(row=>typeof row.id==='string'&&row.id.startsWith('research-elicitation-')),false);
  const results=calls.flatMap(call=>(call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[])).filter(block=>block.type==='tool_result');
  assert.ok(results.some(block=>block.tool_use_id==='native_mcp_input_14'&&JSON.stringify(block.content).includes('Original retry completed for phase14')));
  verifyNativeMcpUrlDeclineResults(results);
  assert.equal(proof.steps.find(step=>step.phase===18).nativeInterrupted,true);
  const browser=await rows(join(workspace,'native-mcp-url-browser.jsonl'));assert.deepEqual(browser.map(row=>({phase:row.phase,url:row.url})),[14,17].map(phase=>({phase,url:'https://example.invalid/release-review'})));
 }else{
 for(const step of nativeMcpUrlSteps){const replies=frames.filter(row=>row.id==='research-elicitation-'+step.phase&&row.result);assert.equal(replies.length,1);assert.deepEqual(replies[0].result,{action:step.scenario==='url-decline'?'decline':['url-cancel','url-pause'].includes(step.scenario)?'cancel':'accept'});}
 const cancelled=frames.find(row=>row.method==='tools/call'&&row.params.arguments.phase===13);assert.ok(cancelled);assert.ok(frames.some(row=>row.method==='notifications/cancelled'&&row.params.requestId===cancelled.id));
 const notifications=frames.filter(row=>row.fixtureOutgoing?.method==='notifications/elicitation/complete').map(row=>row.fixtureOutgoing.params.elicitationId);assert.deepEqual(notifications,['release-review-foreign','release-review-12']);
 const browser=await rows(join(workspace,'native-mcp-url-browser.jsonl'));assert.deepEqual(browser.map(row=>({phase:row.phase,url:row.url})),[10,10,11,12].map(phase=>({phase,url:'https://example.invalid/release-review'})));
 }
 assert.ok(calls.every(call=>!call.fixtureError&&['/v1/messages','/v1/messages/count_tokens'].includes(call.path?.split('?')[0])));
 assert.ok(calls.some(call=>JSON.stringify(call.messages??[]).includes('Continue after cancelling the release input.')));
 const natives=await rows(join(workspace,'native-children.jsonl')),exits=await rows(join(workspace,'native-exits.jsonl'));assert.equal(natives.length,3);assert.equal(natives[1].pid,proof.boundNativePid);
 for(const native of natives)assert.ok(exits.some(exit=>exit.pid===native.pid));for(let i=0;i<2;i++)assert.ok(exits.find(exit=>exit.pid===natives[i].pid).at<=natives[i+1].at);
 const children=await rows(join(workspace,'mcp-children.jsonl')),childExits=await rows(join(workspace,'mcp-exits.jsonl'));assert.ok(children.some(child=>child.ancestors.includes(proof.boundNativePid)));for(const child of children)assert.ok(childExits.some(exit=>exit.pid===child.pid));
 const preloads=await rows(join(workspace,'user-preload-calls.jsonl'));for(const native of natives)assert.ok(preloads.some(row=>row.pid===native.pid));
 const evidence=JSON.parse(await readFile(join(workspace,'native-terminal-app-evidence.json'),'utf8'));assert.equal(evidence.boundNativePid,proof.boundNativePid);assert.equal(evidence.sessionId,proof.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);assert.deepEqual(evidence.browserErrors,[]);
 return{originalNativeUrlActions:true,originalWaitingAndCompletion:!retry,originalToolRetry:retry,originalBrowserInvocation:true,originalPauseCancellation:true,originalNativeRecovery:true,ownedNativeShutdown:true,ownedMcpShutdown:true,nativePreloadPreserved:true,nativeProcesses:3,qualification:retry?'Main terminal-owner -32042 retry flow with original tool retry/decline/cancel/Pause. Inert BROWSER only; no real web navigation, modern explicit confirmation or other owner/window/policy acceptance.':'Main legacy terminal-owner URL/waiting only. Original opener invokes an inert private BROWSER: no real web navigation/return, modern explicit confirmation, retry producer or other owner/window/task/policy acceptance.'};
}
