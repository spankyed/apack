import assert from 'node:assert/strict';

/** Correlate current product input, original lifecycle/hooks and the model-facing document envelope. */
export function verifyApackDocumentMedia(evidence,expectedQuerySourceSha256){
 assert.equal(evidence.targetSha256,'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');assert.equal(evidence.querySourceSha256,expectedQuerySourceSha256);assert.equal(evidence.realModelRequests,0);assert.equal(evidence.exit.code,0);
 const {input,events,result,observations}=evidence;assert.match(input.uuid,/^[a-f0-9-]{36}$/);assert.equal(input.message.role,'user');
 const original=events.filter(row=>row.type==='user');assert.equal(original.length,1);assert.equal(original[0].uuid,input.uuid);assert.deepEqual(original[0].message.content,input.message.content);
 const lifecycle=events.filter(row=>row.type==='command_lifecycle');assert.deepEqual(lifecycle.map(row=>row.state),['queued','started','completed']);for(const row of lifecycle){assert.equal(row.command_uuid,input.uuid);assert.equal(row.session_id,result.sessionId);}
 const results=events.filter(row=>row.type==='result');assert.equal(results.length,1);assert.equal(results[0].subtype,'success');assert.equal(results[0].session_id,result.sessionId);assert.equal(result.numTurns,1);
 assert.deepEqual(evidence.calls.map(row=>row.path),['/api/hello','/v1/messages?beta=true']);const call=evidence.calls[1];assert.equal(call.toolNames.length,0);
 const documents=input.message.content.filter(block=>block.type==='document');assert.deepEqual(documents.map(block=>block.source.type),['text','base64','url','file','content']);
 const modelDocs=call.messages.filter(row=>row.role==='user').flatMap(row=>Array.isArray(row.content)?row.content.filter(block=>block.type==='document'):[]);assert.equal(modelDocs.length,documents.length);for(const[index,block]of documents.entries())assert.deepEqual(modelDocs[index].source,block.source);
 const expected=Buffer.from('Document byte fixture: café\n第二行\n'),{managed,ordinary,settled}=observations;assert.equal(managed.rows.length,5);const ids=managed.rows.map(row=>row.id);assert.equal(new Set(ids).size,5);
 const denied=value=>{assert.equal(typeof value.deny,'string');assert.ok(value.deny.length);assert.equal(value.base64,undefined);assert.equal(value.bytes,undefined)};
 for(const row of managed.rows.slice(0,2)){assert.equal(row.result.type,'document');assert.equal(row.result.mediaType,'text/plain');assert.equal(row.result.size,expected.length);assert.equal(row.result.base64,expected.toString('base64'));}
 for(const row of managed.rows.slice(2))denied(row.result);denied(managed.unlisted);denied(ordinary.unlisted);
 for(const receipt of [ordinary,settled]){assert.deepEqual(receipt.rows.map(row=>row.id),ids);for(const row of receipt.rows)denied(row.result);}
 return {verified:true,currentProductQuery:true,nativeUserUuid:input.uuid,sessionId:result.sessionId,sourceKinds:documents.map(block=>block.source.type),modelDocumentSourcesPreserved:true,managedInlineDocumentBytesExact:true,ordinaryUnlistedUnsupportedAndSettledDenied:true,nativeExit:0,modelRequests:1,realModelRequests:0,scope:'Current direct-query document block transport, original media admission and lifetime only; no composer inline-upload producer, real provider acceptance or installed OS/MDM claim.'};
}
