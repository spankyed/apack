import assert from 'node:assert/strict';
import http from 'node:http';
import {readFileSync,appendFileSync} from 'node:fs';
import {join} from 'node:path';

/** Passive capture of owned control replies; never delays, replaces or fabricates native operations. */
export function observeOwnedTurnControls({directory,workspace}){
 assert.match(directory,/^\/(?:private\/)?tmp\/cc-app-[A-Za-z0-9_-]+$/);
 const config=JSON.parse(readFileSync(join(directory,'observer.json'),'utf8'));
 assert.equal(config.uiSocketPath,join(directory,'ui.sock'));
 const original=http.createServer;let count=0;
 http.createServer=function(...args){
  const index=args.findIndex(value=>typeof value==='function');if(index<0)return Reflect.apply(original,this,args);
  const handler=args[index];let owned=false;
  args[index]=function(request,response){
   if(owned&&request.url==='/control'){
    const chunks=[];let bytes=0;request.on('data',chunk=>{bytes+=chunk.length;if(bytes<=1048576)chunks.push(chunk)});
    const end=response.end;
    response.end=function(...values){
     try{
      const body=JSON.parse(Buffer.concat(chunks)),reply=JSON.parse(String(values[0])),subtype=body.request?.subtype;
      if(['apack_turn_state','apack_abort_turn','apack_owner_snapshot'].includes(subtype)&&count++<256){
       const result=subtype==='apack_owner_snapshot'?{turn:reply.result?.turn,busy:reply.result?.busy}:reply.result;
       appendFileSync(join(workspace,'native-pause-controls.jsonl'),JSON.stringify({subtype,status:response.statusCode,at:Date.now(),turnId:body.request.turn_id,result,error:reply.error})+'\n');
      }
     }catch{}
     return Reflect.apply(end,this,values);
    };
   }
   return Reflect.apply(handler,this,[request,response]);
  };
  const server=Reflect.apply(original,this,args),listen=server.listen;
  server.listen=function(...values){owned=values[0]===config.uiSocketPath;return Reflect.apply(listen,this,values)};
  return server;
 };
}
