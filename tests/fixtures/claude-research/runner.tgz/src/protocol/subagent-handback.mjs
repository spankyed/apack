import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticAgentModel,HANDBACK_CALLER_REPORT,HANDBACK_LATE_REPORT} from './synthetic-agent-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** One private native agent reports only to its actual caller; no peer, shell tool or remote API. */
export async function probeSubagentHandback(executable,root,output,{profile='default'}={}){
 assert.ok(['default','child-auto','auto-hook','auto-continue','auto-duplicate','auto-nested','auto-blocked','auto-refused'].includes(profile));
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'subagent-handback-')),home=join(workspace,'home'),cwd=join(workspace,'project');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(cwd);
 const run=await createRun(output,'subagent-handback',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-agent-model.mjs',import.meta.url))),profile});
 const enabled=profile.startsWith('auto-');
 const events=[],permissions=[];let model,pending='',initialized=false;
 try{
  model=await startSyntheticAgentModel({handbackProbe:true,...(['auto-continue','auto-duplicate','auto-nested','auto-blocked','auto-refused'].includes(profile)?{requestLimit:16,parentLaunchOnce:true,captureMessages:true,...(['auto-blocked','auto-refused'].includes(profile)?{handbackClassifierOutcome:profile==='auto-blocked'?'blocked':'refused'}:profile==='auto-nested'?{handbackNested:true,handbackClassifierSafe:true}:profile==='auto-duplicate'?{handbackDuplicate:true,handbackClassifierSafe:true}:{handbackClassifierUnavailable:true})}:{})});
  const transport=await record({executable,cwd,output,timeoutMs:25000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--permission-mode',enabled?'auto':'default','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','Agent','--allowedTools','Agent','--agents',JSON.stringify({'status-fixture':{description:'Private handback fixture',prompt:'NativeStatusChildSystem. Return only the fixed worker report.',tools:profile==='auto-nested'?['Agent']:[],maxTurns:5,...(profile!=='default'?{permissionMode:'auto'}:{})},...(profile==='auto-nested'?{'late-fixture':{description:'Private late handback fixture',prompt:'NativeStatusGrandchildSystem. Return the late migration report.',tools:[],maxTurns:3,permissionMode:'auto'}}:{})}),'--model','sonnet','--no-session-persistence','--max-turns','6'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',...(enabled?{CLAUDE_CODE_SENDMESSAGE_HANDBACK:'1'}:{})},input:[JSON.stringify({type:'control_request',request_id:'handback-init',request:{subtype:'initialize',...(enabled?{hooks:{PreToolUse:[{matcher:'Agent|SubagentHandback',hookCallbackIds:['handback-fixed-fixture']}]}}:{})}})+'\n'],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let event;try{event=JSON.parse(text)}catch{continue}events.push(event);
    if(event.type==='control_response'&&event.response?.request_id==='handback-init'){assert.equal(event.response.subtype,'success');initialized=true;channel.send(JSON.stringify({type:'user',message:{role:'user',content:'NativeSubagentParentFixture: Run the disposable status worker.'}})+'\n');}
    if(event.type==='control_request'&&event.request?.subtype==='hook_callback'){
     assert.equal(enabled,true);assert.equal(event.request.callback_id,'handback-fixed-fixture');
     const input=event.request.input;assert.equal(input.hook_event_name,'PreToolUse');
     if(input.tool_name==='Agent'){if(profile==='auto-nested'&&input.tool_input.subagent_type==='late-fixture')assert.equal(input.tool_input.prompt,'Return the late migration report.');else{assert.equal(input.tool_input.subagent_type,'status-fixture');assert.equal(input.tool_input.prompt,'Return the synthetic worker marker only.');}}
     else{assert.equal(input.tool_name,'SubagentHandback');assert.ok((profile==='auto-nested'?[HANDBACK_CALLER_REPORT,HANDBACK_LATE_REPORT]:['HAND_BACK_FIXTURE']).includes(input.tool_input.message));assert.deepEqual(Object.keys(input.tool_input),['message']);}
     channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:event.request_id,response:{hookSpecificOutput:{hookEventName:'PreToolUse',permissionDecision:'allow'}}}})+'\n');
    }
    if(event.type==='control_request'&&event.request?.subtype==='can_use_tool'){
     permissions.push(event.request.tool_name);
     if(event.request.tool_name==='Agent'){assert.equal(event.request.input.subagent_type,'status-fixture');assert.equal(event.request.input.prompt,'Return the synthetic worker marker only.');assert.ok(Object.keys(event.request.input).every(key=>['subagent_type','prompt','description','run_in_background'].includes(key)));}
     else{assert.equal(event.request.tool_name,'SubagentHandback');assert.deepEqual(event.request.input,{message:'HAND_BACK_FIXTURE'});}
     channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:event.request_id,response:{behavior:'allow',updatedInput:event.request.input}}})+'\n');
    }
    if(profile==='auto-nested'&&event.type==='system'&&event.subtype==='task_notification'&&event.handback_report?.text===HANDBACK_CALLER_REPORT)model.releaseGrandchild();
    if(profile==='auto-hook'&&event.type==='system'&&event.subtype==='task_notification'&&event.handback_report?.text==='HAND_BACK_FIXTURE')channel.stop('handback-observed');
    if(event.type==='result'){
     const results=events.filter(value=>value.type==='result');if(results.length===1)model.releaseChild();
     if(profile==='auto-nested'?model.requests.some((request,index)=>!model.calls[index].child&&JSON.stringify(request.messages).includes(HANDBACK_LATE_REPORT)):results.length===2)channel.closeInput();
    }
   }
  }});
  if(profile==='auto-hook'){assert.equal(transport.status,'failed');assert.equal(transport.reason,'handback-observed');}
  else{assert.equal(transport.status,'complete');assert.equal(transport.code,0);}
  assert.equal(initialized,true);
  const results=events.filter(event=>event.type==='result');if(profile==='auto-nested')assert.ok(results.length>=3);else assert.equal(results.length,profile==='auto-hook'?1:['auto-continue','auto-duplicate','auto-blocked','auto-refused'].includes(profile)?3:2);if(profile==='auto-continue')assert.equal(results.at(-1).result,'','Only the final additional native result may be empty');assert.ok(results.every(result=>result.subtype==='success'&&result.is_error===false));
  const children=model.calls.filter(call=>call.child);assert.ok(children.length>=1);const offered=children[0].handbackOffered;
  const launches=events.filter(event=>event.type==='system'&&event.subtype==='task_started'&&event.task_type==='local_agent'),completions=events.filter(event=>event.type==='system'&&event.subtype==='task_notification'&&event.status==='completed');
  assert.equal(launches.length,profile==='auto-nested'?2:1);assert.ok(completions.some(done=>done.task_id===launches[0].task_id));
  const childToolEvents=events.filter(event=>event.type==='assistant'&&event.parent_tool_use_id!=null).flatMap(event=>event.message?.content??[]).filter(block=>block.type==='tool_use');
  const parentReceived=model.requests.some((request,index)=>!model.calls[index].child&&model.calls[index].toolNames?.includes('Agent')&&JSON.stringify(request.messages).includes(profile==='auto-nested'?HANDBACK_LATE_REPORT:'HAND_BACK_FIXTURE'));
  const receipts=events.filter(event=>event.type==='user'&&event.parent_tool_use_id!=null).flatMap(event=>event.message?.content??[]).filter(block=>block.type==='tool_result'&&['child_permission_fixture','child_handback_duplicate'].includes(block.tool_use_id)).flatMap(block=>{const text=Array.isArray(block.content)?block.content.filter(value=>value.type==='text').map(value=>value.text).join(''):block.content;try{return[JSON.parse(text)]}catch{return[]}});
  const handback=completions.find(event=>event.handback_report?.text===(profile==='auto-nested'?HANDBACK_LATE_REPORT:'HAND_BACK_FIXTURE'));
  if(enabled){
   assert.equal(offered,true);assert.equal(childToolEvents.filter(block=>block.name==='SubagentHandback').length,['auto-duplicate','auto-nested'].includes(profile)?2:1);assert.equal(children.length,profile==='auto-nested'?3:1);
   assert.ok(receipts.some(receipt=>receipt.success===true&&receipt.message==='Report delivered to your caller.'));assert.equal(handback?.handback,['auto-blocked','auto-refused'].includes(profile)?'flagged':'send');
  }else{assert.equal(offered,false);assert.equal(childToolEvents.length,0);}
  if(['auto-blocked','auto-refused'].includes(profile)){assert.ok(handback?.handback_report.warning?.includes(profile==='auto-blocked'?'auto mode blocked':'UNREVIEWED'));assert.ok(model.calls.some(call=>call.classifierOutcome===(profile==='auto-blocked'?'blocked':'refused')));}
  let nestedProof;
  if(profile==='auto-nested'){
   const caller=launches.find(event=>event.spawn_depth===1),leaf=launches.find(event=>event.spawn_depth===2);assert.ok(caller&&leaf);assert.equal(leaf.parent_task_id,caller.task_id);
   const callerClosed=events.findIndex(event=>event.type==='system'&&event.subtype==='task_notification'&&event.task_id===caller.task_id&&event.status==='completed');
   const lateCall=events.findIndex(event=>event.type==='assistant'&&event.parent_tool_use_id===leaf.tool_use_id&&event.message?.content?.some(block=>block.type==='tool_use'&&block.input?.message===HANDBACK_LATE_REPORT));
   assert.ok(callerClosed>=0&&lateCall>callerClosed,'Late call must follow the actual caller completion');
   assert.ok(results.some(event=>event.origin?.kind==='peer'&&event.origin.senderTaskId===leaf.task_id&&event.origin.handback===true),'Original root result must be attributed to the late child');
   nestedProof={callerTaskId:caller.task_id,leafTaskId:leaf.task_id,leafParentTaskId:leaf.parent_task_id,callerCompletionIndex:callerClosed,lateCallIndex:lateCall,rootReceivedLateReport:true};
   assert.equal(completions.filter(event=>[HANDBACK_CALLER_REPORT,HANDBACK_LATE_REPORT].includes(event.handback_report?.text)).length,2);assert.equal(receipts.filter(receipt=>receipt.success===true).length,2);}
  if(profile==='auto-duplicate'){
   assert.equal(receipts.length,2);assert.equal(receipts.filter(receipt=>receipt.success===true).length,1);
   assert.equal(receipts.find(receipt=>receipt.success===false)?.message,'Nothing was sent: your report was already delivered (SubagentHandback delivers one report). Use SendMessage for anything further, then stop.');
   assert.equal(completions.filter(event=>event.handback_report?.text==='HAND_BACK_FIXTURE').length,1);
   assert.equal(handback.handback_report.warning,undefined);assert.ok(model.calls.some(call=>call.classifierSeverity===0));
  }
  await writeFile(join(run.directory,'model-requests.json'),JSON.stringify(model.requests,null,2)+'\n');
  if(['auto-continue','auto-duplicate','auto-nested','auto-blocked','auto-refused'].includes(profile))assert.equal(parentReceived,true,'Original parent did not receive the report');
  const hookTools=events.filter(event=>event.type==='control_request'&&event.request?.subtype==='hook_callback').map(event=>event.request.input.tool_name);
  const evidence={profile,...(nestedProof?{nestedProof}:{}),initialized,offered,childRequests:children.length,childCatalogues:children.map(call=>call.toolNames),enabledGates:enabled?{CLAUDE_CODE_SENDMESSAGE_HANDBACK:true}:{},childToolCalls:childToolEvents.map(block=>({name:block.name,input:block.input})),parentReceived,handbackReceipt:receipts[0]??null,handbackReceipts:receipts,classifierOutcomes:model.calls.filter(call=>call.classifierOutcome).map(call=>call.classifierOutcome),classifierResponses:model.calls.filter(call=>call.classifierSeverity!==undefined).map(call=>call.classifierSeverity),handbackReport:handback?{text:handback.handback_report.text,warningPresent:typeof handback.handback_report.warning==='string',...(typeof handback.handback_report.warning==='string'?{warning:handback.handback_report.warning}:{})}:null,controlledStop:profile==='auto-hook',hookTools,taskIdsMatched:true,resultCount:results.length,permissions,localModelRequests:model.messageRequestCount(),fixtureResponses:model.calls.length,realModelRequests:0,qualification:['auto-blocked','auto-refused'].includes(profile)?'Original native classification and warning construction consume a fixed synthetic blocked/refused response. Original report/warning reach parent; no real classifier quality or app acceptance is established by this probe.':profile==='auto-nested'?'Original caller launches an original background child, reports and completes before the held child reports. Root continuation receives the late report through original native routing; no fabricated registry identity or recipient. Fixed severity zero proves parsing/control flow, not classifier quality; app projection remains separate.':profile==='auto-duplicate'?'Two original eligible tool calls in one native assistant response produce exactly one admitted report and one original duplicate refusal; parent receives it. Native classifier parser consumes fixed synthetic severity zero, not real classifier accuracy. Closed-caller/resumer and app duplicate presentation remain unverified.':profile==='auto-continue'?'Original report/warning and parent continuation verified with a locally unavailable synthetic classifier. An additional empty native success result is recorded separately; no claim that EOF caused it. No duplicate/closed-caller, mounted app or team parity claim.':'Private child/caller fixture only. Auto-hook stops the owned process after receipt and notification; synthetic safety classification and parent continuation are not verified. No duplicate/closed-caller, app/mounted or team parity claim.'};
  await writeFile(join(run.directory,'subagent-handback.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await writeFile(join(run.directory,'failed-observations.json'),JSON.stringify({events,calls:model?.calls??[],requests:model?.requests??[]},null,2)+'\n');await run.finish({status:'failed',error:error.message});throw error;}finally{await model?.close();}
}
