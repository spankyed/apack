import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Fixed loopback Bash request under native user allow/deny/ask rules; private marker only. */
export async function probePermissionRuleEnforcement(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'permission-enforcement-'));
 const run=await createRun(output,'permission-rule-enforcement',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});const cases=[];
 try{
  for(const scenario of [{rule:'allow',hostDecision:'deny'},{rule:'deny',hostDecision:'allow'},{rule:'ask',hostDecision:'allow'},{rule:'ask',hostDecision:'deny'}]){
   const cwd=join(workspace,`${scenario.rule}-${scenario.hostDecision}`),home=join(cwd,'home'),config=join(home,'.claude');await mkdir(config,{recursive:true});
   await writeFile(join(config,'settings.json'),JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}));
   const env={PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
   const writer=await record({executable,cwd,output,timeoutMs:10000,args:['edit-permission-rules','--json'],input:[JSON.stringify({op:'add',rules:['Bash'],behavior:scenario.rule,destination:'userSettings'})+'\n'],env});assert.equal(writer.code,0);
   const model=await startSyntheticModel(cwd,'Bash',{forceBash:true});let pending='',catalog;const permissions=[],toolResults=[],results=[];
   const request=(id,value)=>JSON.stringify({type:'control_request',request_id:id,request:value})+'\n';let transport;
   try{
    transport=await record({executable,cwd,output,timeoutMs:20000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--permission-mode','default','--setting-sources','user','--strict-mcp-config','--tools','Bash','--no-session-persistence','--max-turns','3'],env:{...env,ANTHROPIC_BASE_URL:model.url},input:[request('init',{subtype:'initialize',hooks:{}})],onStdout(bytes,channel){
     pending+=bytes.toString('utf8');while(pending.includes('\n')){
      const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
      if(value.type==='control_response'&&value.response?.request_id==='init'){assert.equal(value.response.subtype,'success');channel.send(request('rules',{subtype:'list_permission_rules'}))}
      if(value.type==='control_response'&&value.response?.request_id==='rules'){assert.equal(value.response.subtype,'success');catalog=value.response.response;channel.send(JSON.stringify({type:'user',message:{role:'user',content:'Write only the disposable synthetic fixture marker.'}})+'\n')}
      if(value.type==='control_request'&&value.request?.subtype==='can_use_tool'){
       assert.equal(value.request.tool_name,'Bash');permissions.push(value.request);
       const response=scenario.hostDecision==='allow'?{behavior:'allow',updatedInput:value.request.input}:{behavior:'deny',message:'Private permission enforcement fixture refuses this tool.'};
       channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response}})+'\n');
      }
      if(value.type==='user'&&Array.isArray(value.message?.content))toolResults.push(...value.message.content.filter(block=>block.type==='tool_result'));
      if(value.type==='result'){results.push(value);channel.closeInput()}
     }
    }});
   }finally{await model.close()}
   let marker;try{marker=await readFile(join(cwd,'fixture.txt'),'utf8')}catch(error){if(error.code!=='ENOENT')throw error}
   assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(results.length,1);
   assert.ok(catalog.state.rules.some(rule=>rule.behavior===scenario.rule&&rule.source==='userSettings'&&rule.rule==='Bash'));
   assert.equal(permissions.length,scenario.rule==='ask'?1:0);
   assert.equal(model.calls[0].toolNames.includes('Bash'),scenario.rule!=='deny');
   if(scenario.rule==='deny')assert.ok(toolResults.some(result=>/No such tool available: Bash/.test(String(result.content))));
   const executed=scenario.rule==='allow'||(scenario.rule==='ask'&&scenario.hostDecision==='allow');
   assert.equal(marker,executed?'synthetic protocol fixture\n':undefined);
   assert.ok(toolResults.some(result=>result.tool_use_id==='toolu_research_fixture'&&Boolean(result.is_error)===!executed));
   assert.equal(model.calls.filter(call=>call.path.startsWith('/v1/messages')&&!call.path.includes('count_tokens')).length,2);
   const normalize=value=>JSON.parse(JSON.stringify(value).split(cwd).join('${CASE}').split(workspace).join('${WORKSPACE}'));
   cases.push(normalize({scenario,permissionMode:'default',forcedBashRequest:true,bashAdvertised:model.calls[0]?.toolNames?.includes('Bash')??false,catalog,permissions,toolResults,markerWritten:executed,resultCount:results.length,syntheticApiRequests:model.calls.length,realModelRequests:0,writerRun:writer.directory,transportRun:transport.directory}));
  }
  const result={cases,qualification:'Fixed Bash tool, user rule and default permission mode only. Ask responses are host choices; other rule precedence, live edits, bypass/plan modes, hooks and app approvals are not proven.'};await writeFile(join(run.directory,'permission-rule-enforcement.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete',cases:cases.length});return{directory:run.directory,status:'complete',cases:cases.length,syntheticApiRequests:cases.reduce((n,item)=>n+item.syntheticApiRequests,0),realModelRequests:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
