import assert from 'node:assert/strict';
import http from 'node:http';
import { readFileSync, writeFileSync, unlinkSync, appendFileSync } from 'node:fs';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { randomUUID, createHash } from 'node:crypto';

const armPath = workspace => join(workspace, 'native-ui-delay-arm.json');
const casePath = (workspace, id) => join(workspace, 'native-ui-delay-' + id + '.json');
const releasePath = (workspace, id) => join(workspace, 'native-ui-delay-' + id + '.release');
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

/** Research-only preload, installed before the authored native adapter opens any connection. */
export function installOwnedUiDelay({ directory, workspace }) {
  assert.match(directory, /^\/(?:private\/)?tmp\/cc-app-[A-Za-z0-9_-]+$/);
  const config = JSON.parse(readFileSync(join(directory, 'observer.json'), 'utf8'));
  assert.equal(config.socketPath, join(directory, 'bridge.sock'));
  const originalRequest = http.request, originalCreateServer = http.createServer;
  function claim(kind, body) {
    let arm;
    try { arm = JSON.parse(readFileSync(armPath(workspace), 'utf8')); } catch { return; }
    if (arm.kind !== kind || kind !== 'read' && body.request?.text !== arm.text) return;
    assert.match(arm.id, /^[a-f0-9-]{36}$/);
    unlinkSync(armPath(workspace));
    const receipt = { id: arm.id, kind, subtype: body.request.subtype, heldAt: Date.now(), clientSha256: createHash('sha256').update(body.request.client_id).digest('hex') };
    const save = () => writeFileSync(casePath(workspace, arm.id), JSON.stringify(receipt));
    save();
    return { receipt, save, async deliver(send) {
      const deadline = Date.now() + 3000;
      let released = false;
      while (Date.now() < deadline) { try { readFileSync(releasePath(workspace, arm.id)); released = true; break; } catch {} await pause(10); }
      Object.assign(receipt, { releasedAt: Date.now(), reason: released ? 'explicit' : 'deadline' });
      save(); send();
    } };
  }
  http.request = function (...args) {
    const request = Reflect.apply(originalRequest, this, args), options = args[0];
    if (options?.socketPath !== config.socketPath || options.path !== '/ui-host') return request;
    const end = request.end;
    request.end = function (...values) {
      let body; try { body = JSON.parse(String(values[0])); } catch { return Reflect.apply(end, this, values); }
      const kind = { ui_prompt_fill: 'fill', ui_prompt_read: 'read', ui_prompt_suggest: 'suggest' }[body.request?.subtype];
      if (!kind) return Reflect.apply(end, this, values);
      const held = claim(kind, body);
      if (!held) return Reflect.apply(end, this, values);
      request.on('response', response => {
        const chunks = []; let bytes = 0;
        response.on('data', chunk => { bytes += chunk.length; if (bytes <= 2 * 1048576) chunks.push(chunk); });
        response.on('end', () => { let value; try { value = JSON.parse(Buffer.concat(chunks)); } catch {} Object.assign(held.receipt, { respondedAt: Date.now(), status: response.statusCode, result: kind === 'read' ? { text: value?.result?.text, cursor: value?.result?.cursor } : kind === 'suggest' ? { shown: value?.result?.shown === true } : { filled: value?.result?.filled === true } }); held.save(); });
      });
      void held.deliver(() => Reflect.apply(end, request, values));
      return request;
    };
    return request;
  };
  http.createServer = function (...args) {
    const index = args.findIndex(value => typeof value === 'function');
    if (index < 0) return Reflect.apply(originalCreateServer, this, args);
    const handler = args[index]; let owned = false;
    args[index] = function (request, response) {
      if (owned && request.url === '/control') {
        const chunks = []; let bytes = 0;
        request.on('data', chunk => { bytes += chunk.length; if (bytes <= 1048576) chunks.push(chunk); });
        const end = response.end;
        response.end = function (...values) {
          let body, result;
          try { body = JSON.parse(Buffer.concat(chunks)); result = JSON.parse(String(values[0])); } catch { return Reflect.apply(end, this, values); }
          if (['ui_attach', 'ui_detach'].includes(body.request?.subtype) && response.statusCode === 200 && typeof body.request.client_id === 'string') {
            appendFileSync(join(workspace, 'native-ui-attachments.jsonl'), JSON.stringify({ subtype: body.request.subtype, at: Date.now(), clientSha256: createHash('sha256').update(body.request.client_id).digest('hex'), taskId: body.request.native_view?.agent_id ?? null, detached: result.result?.detached === true }) + '\n');
          }
          const kind = { ui_prompt_autocomplete: 'completion', ui_prompt_edit: 'edit' }[body.request?.subtype];
          if (!kind) return Reflect.apply(end, this, values);
          const held = claim(kind, body);
          if (!held) return Reflect.apply(end, this, values);
          Object.assign(held.receipt, { respondedAt: Date.now(), status: response.statusCode, result: kind === 'completion' ? { suggestions: result.result?.suggestions ?? [] } : { frame: result.result } }); held.save();
          response.once('finish', () => { held.receipt.deliveredAt = Date.now(); held.save(); });
          void held.deliver(() => Reflect.apply(end, response, values));
          return response;
        };
      }
      return Reflect.apply(handler, this, [request, response]);
    };
    const server = Reflect.apply(originalCreateServer, this, args), listen = server.listen;
    server.listen = function (...values) { owned = values[0] === config.uiSocketPath; return Reflect.apply(listen, this, values); };
    return server;
  };
  return () => { http.request = originalRequest; http.createServer = originalCreateServer; };
}

/** Private fixture controller. It cannot forge a native request or change its destination. */
export async function delayOwnedUiHost({ directory, sessionId, holdText, kind = 'fill', workspace }) {
  const config = JSON.parse(await readFile(join(directory, 'observer.json'), 'utf8'));
  assert.equal(config.sessionId, sessionId);
  assert.ok(['fill', 'completion', 'read', 'suggest', 'edit'].includes(kind));
  const receipts = []; let current, closed = false;
  async function arm(text) {
    assert.ok(!closed && typeof text === 'string' && text.length > 0);
    current = { id: randomUUID() }; receipts.push(current);
    await writeFile(armPath(workspace), JSON.stringify({ id: current.id, kind, text }));
  }
  async function refresh() {
    try { Object.assign(current, JSON.parse(await readFile(casePath(workspace, current.id), 'utf8'))); } catch {}
    return current;
  }
  await arm(holdText);
  return { receipts, arm,
    async waitHeld() { const deadline = Date.now() + 3500; while (Date.now() < deadline) { if ((await refresh()).heldAt) return current; await pause(10); } throw Error('No matching original ' + kind + ' reached the preload'); },
    async release() { await writeFile(releasePath(workspace, current.id), 'release'); const deadline = Date.now() + 3500; while (Date.now() < deadline) { if ((await refresh()).releasedAt) return true; await pause(10); } return false; },
    refresh,
    async close() { if (closed) return; closed = true; if ((await refresh()).heldAt && !current.releasedAt) await this.release(); },
  };
}
