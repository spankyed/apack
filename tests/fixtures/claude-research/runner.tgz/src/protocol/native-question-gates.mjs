import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, writeFile, copyFile } from 'node:fs/promises';
import { writeFileSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { record } from './record.mjs';
import { hash } from '../artifacts/runs.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

const targetSha256='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37';
export async function probeNativeQuestionGates(executable,parent,output) {
 assert.equal(hash(await readFile(executable)),targetSha256);
 await mkdir(parent,{recursive:true});
 const results=[];
 for(const profile of ['print-default','print-flags','desktop-flags']) {
  const workspace=await mkdtemp(join(parent,'native-question-gates-')),config=join(workspace,'.claude'),reportPath=join(workspace,'question-gates.json'),trigger=join(workspace,'initialized'),preload=join(workspace,'probe.mjs');
  await mkdir(config);await writeFile(join(config,'settings.json'),JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}));
  const source=`import {writeFileSync,existsSync} from 'node:fs';
let started=false;const timer=setInterval(async()=>{if(started||!existsSync(${JSON.stringify(trigger)}))return;started=true;clearInterval(timer);const report={};try{
 const options=await import('/$bunfs/root/chunk-hdxpvbx1.js'),tool=(await import('/$bunfs/root/chunk-at6jwec6.js')).yQ;
 const choice={question:'Which workspace?',header:'Workspace',options:[{label:'Current',description:'Use this workspace'},{label:'New',description:'Create a workspace'}],multiSelect:false};
 const optional={...choice,options:choice.options.map(({description,...option})=>option)};
 const extended={title:'Project setup',questions:[{question:'What should this project be called?',header:'Name',kind:'text',placeholder:'Project name',multiSelect:false},{question:'How many examples should be included?',header:'Examples',kind:'number',min:1,max:10,step:1,defaultValue:3,unit:'examples',multiSelect:false}]};
 const parse=input=>{const value=tool.inputSchema.safeParse(input);return {success:value.success,...(value.success?{shown:tool.shownCardInput(value.data)}:{issues:value.error.issues.map(issue=>({path:issue.path,message:issue.message}))})}};
 report.clientType=options.Dgn();report.flags={extendedQuestions:options.ZCe(),optionalDescriptions:options.Hzo()};report.basic=parse({questions:[choice]});report.optional=parse({questions:[optional]});report.extended=parse(extended);
 const shown=tool.shownCardInput({questions:[choice]});report.basicResponse=tool.admitCardAnswer(shown,{response:'Use the current workspace.'});report.basicFollowUp=tool.admitCardAnswer(shown,{followUp:true});
 if(report.extended.success){const shown=report.extended.shown;report.extendedFollowUp=tool.admitCardAnswer(shown,{answers:{[shown.questions[0].question]:'Notebook',[shown.questions[1].question]:'4'},response:'Keep the examples short.',followUp:true});report.hostField=tool.admitCardAnswer(shown,{afkTimeoutMs:1});}
 }catch(error){report.error=String(error)}writeFileSync(${JSON.stringify(reportPath)},JSON.stringify(report,null,2));},25);timer.unref();`;
  await writeFile(preload,source);
  const model=await startSyntheticModel(workspace,'TextOnly');let buffer='',observation,run;
  try {
   run=await record({executable,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--tools','','--strict-mcp-config','--setting-sources',''],cwd:workspace,output,timeoutMs:15000,
    env:{HOME:workspace,CLAUDE_CONFIG_DIR:config,PATH:'/usr/bin:/bin',ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',BUN_OPTIONS:'--preload='+preload,...(profile!=='print-default'?{CLAUDE_CODE_QUESTION_EXTENDED:'1',CLAUDE_CODE_QUESTION_OPTIONAL_DESCRIPTIONS:'1'}:{}),CLAUDE_CODE_ENTRYPOINT:profile==='desktop-flags'?'claude-desktop':'cli'},
    input:[JSON.stringify({type:'control_request',request_id:'question-gates-init',request:{subtype:'initialize',hooks:{}}})+'\n'],
    onStdout(bytes,transport){buffer+=bytes;while(buffer.includes('\n')){const at=buffer.indexOf('\n'),line=buffer.slice(0,at);buffer=buffer.slice(at+1);let row;try{row=JSON.parse(line)}catch{continue}if(row.type==='control_response'&&row.response.request_id==='question-gates-init'&&!observation){writeFileSync(trigger,'ready');observation=(async()=>{const deadline=Date.now()+10000;while(!existsSync(reportPath)){if(Date.now()>deadline){transport.stop('question-gates-timeout');return}await new Promise(resolve=>setTimeout(resolve,25))}transport.closeInput()})();}}}
   });
   if(observation)await observation;
   assert.equal(model.calls.length,0);
  }finally{await model.close()}
  const report=JSON.parse(await readFile(reportPath,'utf8'));
  const evidence={profile,targetSha256,authoredPreloadSha256:hash(Buffer.from(source)),report,modelRequests:0,recoveredSourceExecuted:false,scope:'Original shipped module exports after native launch initialization; no actual app acceptance or default entrypoint change.'};
  await copyFile(preload,join(run.directory,'authored-question-gates-preload.mjs'));await writeFile(join(run.directory,'integration.json'),JSON.stringify(evidence,null,2)+'\n');
  assert.equal(run.status,'complete');assert.equal(report.error,undefined);assert.equal(report.basic.success,true);assert.equal(report.basicResponse.kind,'admitted');assert.equal(report.basicFollowUp.kind,profile!=='print-default'?'admitted':'refused');
  const eligible=profile!=='print-default';assert.equal(report.flags.extendedQuestions,eligible);assert.equal(report.flags.optionalDescriptions,eligible);assert.equal(report.optional.success,eligible);assert.equal(report.extended.success,eligible);
  if(eligible){assert.equal(report.extendedFollowUp.kind,'admitted');assert.equal(report.hostField.kind,'refused');}
  results.push({profile,directory:run.directory,flags:report.flags});
 }
 return results;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 assert.equal(process.argv.length,5,'Usage: node src/protocol/native-question-gates.mjs <pinned-binary> <private-parent> <output>');
 console.log(JSON.stringify(await probeNativeQuestionGates(...process.argv.slice(2).map(value=>resolve(value))),null,2));
}
