/** Research-only filesystem mapping; the original native policy parser/precedence/runner stay intact. */
export function nativeManagedFiles({ directory, receipt, watchPolicy = false, platform = 'darwin' }) {
  if (!['darwin', 'linux'].includes(platform)) throw Error('Unreviewed managed-policy fixture platform');
  const files = platform === 'linux' ? 'chunk-yrbmj4b9.js' : 'chunk-s093jfzw.js';
  const watcher = platform === 'linux' ? 'chunk-82dv83tn.js' : 'chunk-tcq9m4d4.js';
  const watcherExport = platform === 'linux' ? 'Lv' : 'NE';
  const virtual = platform === 'linux' ? '/etc/claude-code' : '/Library/Application Support/ClaudeCode';
  return `{
if(process.platform!==${JSON.stringify(platform)})throw Error('Managed-policy fixture target platform differs');
const {appendFileSync}=await import('node:fs');
const filesModule=${JSON.stringify('/$bunfs/root/')}+${JSON.stringify(files)};
const {se}=await import(filesModule);
const fs=se(),physical=${JSON.stringify(directory)},virtual=${JSON.stringify(virtual)};
const mapped=path=>typeof path==='string'&&(path===virtual||path.startsWith(virtual+'/'));
const move=path=>physical+path.slice(virtual.length);
for(const name of ['existsSync','stat','lstat','openDirNoFollow','openDirNoFollowSync','lstatBigint','statBigint','readdir','readFile','readlink','statSync','lstatSync','readFileSync','readSync','readlinkSync','readdirSync','readFileBytes','readFileFdGated']){
 const original=fs[name];if(typeof original!=='function')continue;
 fs[name]=function(path,...args){if(!mapped(path))return original.call(this,path,...args);appendFileSync(${JSON.stringify(receipt)},JSON.stringify({name,path})+'\\n');return original.call(this,move(path),...args);};
}
for(const name of ['realpath','realpathSync']){
 const original=fs[name];const back=result=>typeof result==='string'&&(result===physical||result.startsWith(physical+'/'))?virtual+result.slice(physical.length):result;
 fs[name]=function(path,...args){if(!mapped(path))return original.call(this,path,...args);const result=original.call(this,move(path),...args);return result&&typeof result.then==='function'?result.then(back):back(result);};
}
if(${JSON.stringify(watchPolicy)}){
 const watcherModule=${JSON.stringify('/$bunfs/root/')}+${JSON.stringify(watcher)};
 const {${watcherExport}:NE}=await import(watcherModule),{statSync}=await import('node:fs');
 const originalWatch=NE.watch,back=path=>typeof path==='string'&&(path===physical||path.startsWith(physical+'/'))?virtual+path.slice(physical.length):path;
 NE.watch=function(paths,options){
  let policyWatch=false;try{policyWatch=options?.depth===0&&typeof options.ignored==='function'&&!!options.awaitWriteFinish;statSync(physical+'/managed-settings.json');}catch{}
  if(!policyWatch)return originalWatch.call(this,paths,options);
  const roots=[...new Set([...(Array.isArray(paths)?paths:[paths]).map(path=>mapped(path)?move(path):path),physical])];
  const watcher=originalWatch.call(this,roots,{...options,ignored:(path,...args)=>{const canonical=back(path);return canonical===virtual||canonical===virtual+'/managed-settings.json'?false:options.ignored(canonical,...args);}}),emit=watcher.emit;
  watcher.emit=function(event,...args){if(event==='all')args[1]=back(args[1]);else if(['change','add','unlink','addDir','unlinkDir'].includes(event))args[0]=back(args[0]);if(['change','add','unlink'].includes(event)&&args[0]?.startsWith(virtual+'/'))appendFileSync(${JSON.stringify(receipt)},JSON.stringify({name:'native-watch-event',event,path:args[0]})+'\\n');return emit.call(this,event,...args);};
  appendFileSync(${JSON.stringify(receipt)},JSON.stringify({name:'native-watch-roots',roots})+'\\n');return watcher;
 };
}
for(const name of ['unlink','rmdir','rm','mkdir','rename','copyFile','appendFile','symlink','link','chmod','appendFileSync','unlinkSync','renameSync','mkdirSync','rmSync','createWriteStream']){
 const original=fs[name];if(typeof original!=='function')continue;
 fs[name]=function(...args){if(args.some(mapped))throw Error('Research managed policy writes refused');return original.apply(this,args);};
}
}
`;
}
