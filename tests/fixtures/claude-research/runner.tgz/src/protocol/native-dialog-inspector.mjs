/** Read-only shape evidence from the frozen binary; synthetic fixture data only; never answers dialogs or mutates policy. */
export function nativeDialogInspector(outputPath, { questionContracts = false, bashChoices = false, fileChoices = false, recommendationChoices = false, promptRestoration = false, maxSnapshotBytes = 200000 } = {}) {
  if(!Number.isSafeInteger(maxSnapshotBytes)||maxSnapshotBytes<200000||maxSnapshotBytes>1000000)throw new Error('Invalid bounded native snapshot size');
  return `
import {writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
if(createHash('sha256').update(readFileSync(process.execPath)).digest('hex')==='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37'){
 const events=[];
 const snapshot=value=>{const seen=new WeakSet();return JSON.parse(JSON.stringify(value,(key,item)=>{
  if(typeof item==='function')return '[function]';
  if(typeof item==='symbol')return '[symbol]';
  if(typeof item==='bigint')return String(item);
  if(item&&typeof item==='object'){if(seen.has(item))return '[cycle]';seen.add(item);}
  return item;
 }).slice(0,${maxSnapshotBytes}));};
 const describe=value=>value&&typeof value==='object'?{keys:Object.keys(value).sort(),prototype:Object.getOwnPropertyNames(Object.getPrototypeOf(value)??{}).sort(),symbols:Object.getOwnPropertySymbols(value).map(symbol=>symbol.description??'')}:typeof value;
 let busy=false;
 const timer=setInterval(async()=>{if(busy)return;busy=true;try{
  const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),binding=runtime.ey();
  if(binding?.surface!=='terminal')return;
  const context=binding.toolContext(new AbortController());
  const questionTool=${questionContracts ? "(await import('/$bunfs/root/chunk-at6jwec6.js')).yQ" : "undefined"};
  const questionOptions=${questionContracts ? "await import('/$bunfs/root/chunk-hdxpvbx1.js')" : "undefined"};
  const questionPresentation=questionOptions?{previewFormat:questionOptions.yjr()??null,extendedQuestions:questionOptions.ZCe(),optionalDescriptions:questionOptions.Hzo()}:undefined;
  const questionText=${questionContracts ? "await import('/$bunfs/root/chunk-xh5v0djg.js')" : "undefined"};
  const previewSamples=questionText?['**Native bold**\\nconst value = 1;','\\x1b[31mNative color\\x1b[0m','\\u202eHidden direction',' '.repeat(2)].map(value=>({value,visible:questionText.zL(value),withheld:questionText.VL(value),markdown:questionText._gt(value)})):undefined;
  const shownQuestions=new Map(),questionContracts=[];
  const state=context.getAppState();
  const report={binding:describe(binding),conversation:describe(binding.conversation),commands:describe(binding.commands),conversationSource:typeof binding.conversation==='function'?String(binding.conversation).slice(0,4000):undefined,commandsSource:typeof binding.commands==='function'?String(binding.commands).slice(0,4000):undefined,context:describe(context),options:describe(context.options),state:describe(state),session:describe(context.session),host:describe(context.session?.host),dialogStore:describe(context.dialogStore),events,questionContracts,questionPresentation,previewSamples};
  const save=()=>writeFileSync(${JSON.stringify(outputPath)},JSON.stringify(report,null,2),{mode:0o600});
  const record=(type,value)=>{if(events.length>=80)return;try{events.push({type,value:snapshot(value)});save();}catch(error){events.push({type:'inspection-error',message:String(error)});save();}};
  const store=context.dialogStore;
  ${promptRestoration ? `
  let promptLast='',promptBusy=false,promptSamples=0;
  const promptTimer=setInterval(async()=>{if(promptBusy||promptSamples>=40)return;promptBusy=true;try{
   const box=await binding.composer.read(),turn=runtime.lpe();
   const value={text:box.text,cursor:box.cursor,turn:turn?{id:turn.turnId,cancelled:turn.cancelled()}:null,messages:(binding.messages?.()??[]).map(row=>({uuid:row.uuid,type:row.type,origin:row.origin}))},key=JSON.stringify(value);
   if(key!==promptLast){promptLast=key;promptSamples++;record('local-prompt',value);}
  }catch(error){record('local-prompt-error',String(error));}finally{promptBusy=false}},100);promptTimer.unref();
  ` : ''}

  ${recommendationChoices ? `
  const recommendationRoots=await import('/$bunfs/root/chunk-pg10s5g1.js');
  let recommendationLast='',recommendationSamples=0;
  const recommendationTimer=setInterval(()=>{try{
   if(recommendationSamples>=20)return;
   const open=context.dialogStore.getState().open;if(!open.some(item=>item.kind==='lsp_recommendation'))return;
   const pending=[recommendationRoots.ai().get(process.stdout)?.container?.current],seen=new Set(),matches=[];
   const describeCache=value=>value===null||['boolean','string','number','undefined'].includes(typeof value)?value:typeof value==='function'?'[function]':Array.isArray(value)?'[array]':{kind:value.kind,id:value.id,reason:value.reason,hidden:value.hidden?.kind};
   while(pending.length){
    const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('Recommendation inspection exceeded bound');seen.add(fiber);
    const props=fiber.memoizedProps;
    if(typeof fiber.type==='function'&&(props?.payload?.pluginName==='recommendation-review'||props?.pluginName==='recommendation-review'||props?.request?.kind==='lsp_recommendation'||props?.transport!==undefined||Array.isArray(props?.options)&&props.options.some(option=>option.value==='never'))){
     const ancestors=[];for(let parent=fiber.return;parent&&ancestors.length<8;parent=parent.return)ancestors.push(typeof parent.type==='function'?parent.type.name:typeof parent.type);
     matches.push({name:fiber.type.name,sha256:createHash('sha256').update(Function.prototype.toString.call(fiber.type)).digest('hex'),keys:Object.keys(props),disabled:props.isDisabled,ready:typeof props.wouldTakeAnswer==='function'?props.wouldTakeAnswer():undefined,values:props.options?.map(option=>option.value),cache:fiber.updateQueue?.memoCache?.data?.map(row=>row.map(describeCache)),ancestors});
    }
    if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);
   }
   const value={open:open.map(item=>({id:item.id,kind:item.kind,hideWhile:item.hideWhile})),visited:seen.size,matches},key=JSON.stringify(value);
   if(key!==recommendationLast){recommendationLast=key;recommendationSamples++;record('recommendation-mounted-controls',value);}
  }catch(error){record('recommendation-inspection-error',String(error));}},200);recommendationTimer.unref();
  ` : ''}

  ${bashChoices ? `
  const roots=await import('/$bunfs/root/chunk-pg10s5g1.js');
  const inspectBashChoices=()=>{
   const root=roots.ai().get(process.stdout)?.container?.current,pending=root?[root]:[],seen=new Set(),choices=[];
   while(pending.length){
    const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;
    if(seen.size>=4096)throw Error('Bash renderer inspection exceeded bound');seen.add(fiber);
    if(typeof fiber.type==='function'&&fiber.type.name==='Tst'){
     const payload=fiber.memoizedProps?.payload;
     if(payload?.toolName==='Bash'){
      const children=fiber.child?[fiber.child]:[],visited=new Set(),controls=[];
      while(children.length){
       const child=children.pop();if(!child||visited.has(child))continue;
       if(visited.size>=2048)throw Error('Bash controls inspection exceeded bound');visited.add(child);
       const props=child.memoizedProps;
       if(Array.isArray(props?.options)&&typeof props.onChange==='function')controls.push({
        component:typeof child.type==='function'?child.type.name:String(child.type),
        options:props.options.map(option=>({value:option.value,type:option.type??'choice',label:typeof option.label==='string'?option.label:'[native element]',initialValue:option.initialValue})),
        onChange:true,onCancel:typeof props.onCancel==='function'
       });
       if(child.sibling)children.push(child.sibling);if(child.child)children.push(child.child);
      }
      choices.push({requestId:payload.requestId,rendererSha256:createHash('sha256').update(Function.prototype.toString.call(fiber.type)).digest('hex'),controls});
     }
    }
    if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);
   }
   return choices;
  };
  let lastBashChoices='';
  const bashTimer=setInterval(()=>{try{const choices=inspectBashChoices(),key=JSON.stringify(choices);if(choices.length&&key!==lastBashChoices){lastBashChoices=key;record('bash-mounted-choices',choices);}}catch(error){record('bash-choice-inspection-error',String(error));}},100);bashTimer.unref();
  ` : ''}
  ${fileChoices ? `
  const fileRoots=await import('/$bunfs/root/chunk-pg10s5g1.js');
  let lastFileChoices='';
  const fileTimer=setInterval(()=>{try{
   const pending=[fileRoots.ai().get(process.stdout)?.container?.current],seen=new Set(),choices=[];
   while(pending.length){
    const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('File renderer traversal exceeded bound');seen.add(fiber);
    if(typeof fiber.type==='function'&&fiber.type.name==='Sat'){
     const payload=fiber.memoizedProps?.payload;
     if(payload&&['Read','Write','Edit'].includes(payload.toolName)){
      const children=[fiber.child],visited=new Set(),controls=[];
      while(children.length){const child=children.pop();if(!child||visited.has(child))continue;if(visited.size>=2048)throw Error('File control traversal exceeded bound');visited.add(child);
       const props=child.memoizedProps;
       if(typeof child.type==='function'&&child.type.name==='Xe'&&Array.isArray(props?.options)&&typeof props.onChange==='function')controls.push({component:child.type.name,onChange:true,onInputModeToggle:typeof props.onInputModeToggle==='function',options:props.options.map(option=>({value:option.value,label:typeof option.label==='string'?option.label:'[native element]',type:option.type??'choice',nativeOption:option.option?.type,initialValue:option.initialValue}))});
       if(child.sibling)children.push(child.sibling);if(child.child)children.push(child.child);
      }
      choices.push({requestId:payload.requestId,toolName:payload.toolName,rendererSha256:createHash('sha256').update(Function.prototype.toString.call(fiber.type)).digest('hex'),wouldTakeAnswer:typeof fiber.memoizedProps.wouldTakeAnswer,controls});
     }
    }
    if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);
   }
   const key=JSON.stringify(choices);if(choices.length&&key!==lastFileChoices){lastFileChoices=key;record('file-mounted-choices',choices);}
  }catch(error){record('file-choice-inspection-error',String(error))}},100);fileTimer.unref();
  ` : ''}
  if(store?.getState&&store?.subscribe){
   store.subscribe(()=>{for(const item of store.getState().open)if(questionTool&&item.kind==='permission_ask_user_question')shownQuestions.set(item.id,questionTool.shownCardInput(item.payload.input));record('state',store.getState());});
   store.onClosed?.(event=>{
    const shown=shownQuestions.get(event.id);
    if(questionTool&&shown&&event.type==='answered'&&event.result?.updatedInput){
     const input=event.result.updatedInput;
     questionContracts.push(snapshot({shown,admitted:questionTool.admitCardAnswer(shown,input),
      unknownAnswer:questionTool.admitCardAnswer(shown,{...input,answers:{foreign:'No'}}),
      changedQuestions:questionTool.admitCardAnswer(shown,{...input,questions:[]}),
      forgedHostField:questionTool.admitCardAnswer(shown,{...input,afkTimeoutMs:1000})}));
    }
    shownQuestions.delete(event.id);record('closed',event);
   });record('initial',store.getState());
  }
  save();
  clearInterval(timer);
 }catch{}finally{busy=false}},250);timer.unref();
}
`;
}
