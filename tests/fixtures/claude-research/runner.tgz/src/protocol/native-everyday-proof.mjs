import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

export const everydayHumanPrompts=[
 'Help me review the release notes and checklist.',
 'Review the release notes with a worker.',
 'Read the release checklist before proposing changes.',
 'Ask me which release audience to target.',
 'Draft the release summary while I review the checklist.',
 'Continue the same release review after the interruption.'
];
const text=content=>typeof content==='string'?content:(content??[]).filter(block=>block.type==='text').map(block=>block.text).join('\n');

/** Reconcile the combined desktop journey with original journals and local model receipts. */
export async function verifyNativeEveryday(workspace,evidence,calls){
 for(const key of ['nativeEverydayCombined','nativeAgentReturn','nativePausedWhileWorking','nativePauseOwnerRetained','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 const proof=JSON.parse(await readFile(join(workspace,'native-everyday-app.json'),'utf8'));
 assert.equal(proof.combinedAcceptance,true);assert.equal(proof.retainedParentDraft,'Keep the release checklist wording unchanged.');assert.equal(proof.retainedAgentDraft,'Please also note the migration steps.');assert.equal(proof.sessionId,evidence.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);
 const expected=['agent','agent-result','composer','approval','question','recovered'].flatMap(stage=>[1100,680].map(width=>[stage,width]));
 assert.deepEqual(proof.geometry.map(row=>[row.stage,row.width]),expected);assert.equal(proof.screenshots.length,expected.length);
 for(const row of proof.geometry){assert.equal(row.sessionId,proof.sessionId);if(['composer','recovered'].includes(row.stage)){
  assert.equal(row.sendDisabled,false);
  assert.equal(row.sendPaint?.disabled,false,'Send paint must be enabled');
  assert.equal(row.sendPaint.activeAnimations,0,'Send paint must be settled');
  assert.match(row.sendPaint.backgroundColor,/^rgb\((37, 99, 235|29, 78, 216)\)$/,'Expected settled default enabled Send colour');
 }}
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>path.endsWith('.jsonl'));assert.ok(paths.length<200);
 const records=async selected=>{const rows=new Map();for(const path of selected){const data=await readFile(join(root,path),'utf8');assert.ok(data.length<20*1024*1024);for(const line of data.trim().split('\n').filter(Boolean)){const row=JSON.parse(line);rows.set(row.uuid??Symbol(),row);}}return [...rows.values()];};
 const main=await records(paths.filter(path=>basename(path)===proof.sessionId+'.jsonl'));
 const humans=main.filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'));
 assert.deepEqual(humans.map(row=>text(row.message?.content)),everydayHumanPrompts,'No extra, duplicated, rewritten or leaked draft human turns');
 const workers=await records(paths.filter(path=>basename(path)==='agent-'+proof.taskId+'.jsonl'));
 assert.ok(workers.some(row=>row.type==='assistant'&&text(row.message?.content).includes('The release notes cover behavior changes and migration guidance.')),'Original selected Agent transcript missing');
 assert.equal(workers.some(row=>row.type==='user'&&text(row.message?.content).includes(proof.retainedParentDraft)),false,'Pending parent draft leaked to worker');
 assert.equal(humans.some(row=>text(row.message?.content).includes(proof.retainedAgentDraft)),false,'Pending Agent draft leaked to parent');
 assert.ok(calls.agent.some(call=>call.child&&call.delivered));
 assert.ok(calls.agent.some(call=>!call.referenceReadError&&JSON.stringify(call.referenceReadResult??'').includes('Keep migration guidance')));
 assert.ok(calls.agent.some(call=>!call.nativeQuestionError&&JSON.stringify(call.nativeQuestionResult??'').includes('Developers')));
 assert.ok(calls.agent.some(call=>call.pauseWaiting&&call.pauseCancelled),'Held native provider request did not cancel');
 assert.equal(calls.seed.length,2);assert.ok(calls.agent.length<=16);
 const ledger=main.filter(row=>row.type==='cost-state').at(-1);
 assert.ok(proof.nativeCost>0&&proof.resumedCost>proof.nativeCost);assert.equal(ledger?.totalCostUSD,proof.resumedCost);assert.equal(evidence.resumedCost,proof.resumedCost);
 return {sessionId:proof.sessionId,taskId:proof.taskId,humanUuids:humans.map(row=>row.uuid),captures:proof.screenshots,syntheticRequests:calls.seed.length+calls.agent.length,nativeCost:proof.nativeCost,resumedCost:proof.resumedCost,scope:'One main-owner ordinary desktop journey across composing/status, Agent return, Read approval, question, interruption and same-session print recovery. Not all contracts, policy/window variants or final F1–F5 acceptance.'};
}

/** Verify complete native model-notice reading separately from older everyday receipts. */
export async function verifyNativeModelNotices(workspace,evidence,{managedPolicy=false}={}){
 const proof=JSON.parse(await readFile(join(workspace,'native-model-notice-app.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);
 assert.equal(proof.settingsUnchanged,true);assert.equal(proof.turns,1);assert.equal(proof.modelPolicyNotice,managedPolicy);
 if(managedPolicy)assert.equal(evidence.nativeModelPolicyNotice,true,'Managed policy profile was not acknowledged by the app');
 assert.equal(proof.retainedDraft,'Keep my model-review draft while I read the complete notice.');
 assert.deepEqual(proof.notices.map(row=>row.selection),['haiku','default']);
 for(const row of proof.notices){
  assert.match(row.text,/for this session only/);assert.equal(row.text.includes('\u001b'),false);
  assert.ok(row.text.includes(`Model selection accepted: ${row.selection}.`));
  if(managedPolicy){assert.match(row.text,/Managed settings pins/);assert.match(row.text,/that applies on restart/);}
  assert.equal(row.screenshots.length,2);assert.deepEqual(row.reading.map(read=>[read.width,read.height]),[[1100,900],[680,600]]);
  for(const read of row.reading){
   assert.equal(read.physicalWheel,true);assert.equal(read.selectionRetained,true);assert.equal(read.draftRetained,true);
   const g=read.geometry;assert.ok([g.top,g.bottom,g.viewportTop,g.viewportBottom].every(Number.isFinite));
   assert.ok(g.top>=g.viewportTop-1&&g.bottom<=g.viewportBottom+1&&g.bottom>g.top,'Model notice text was clipped');
  }
 }
 return {...proof,managedPolicy,scope:'Main-owner original model notice and reset, full text reading and retained desktop draft/selection. No all-policy, OS/MDM or restart-default adoption claim.'};
}
