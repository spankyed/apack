import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** Private configured editor; original Claude owns temp-file creation, launch and readback. */
export async function addNativeWorkflowEditorFixture(workspace) {
  const editor=join(workspace,'workflow-editor.py'),receipt=join(workspace,'native-workflow-editor-receipt.json');
  await writeFile(editor,`import json,os,pathlib,sys
path=pathlib.Path(sys.argv[-1])
before=path.read_text()
editable=before
marker='/* LARGE_WORKFLOW_FIXTURE:'
if marker in before:
 start=before.index(marker)
 end=before.index('*/',start)+2
 editable=before[:start]+before[end:]
after=editable.replace('"Review release notes"','"Edited release notes"').replace('"Review"','"Edited review"')
if after==before: sys.exit(7)
path.write_text(after)
pathlib.Path(${JSON.stringify(receipt)}).write_text(json.dumps({'pid':os.getpid(),'before':before,'after':after,'tempPath':str(path)}))
`);
  const file=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(file,'utf8'));
  const command='/usr/bin/python3 '+editor;
  await writeFile(file,JSON.stringify({...settings,env:{...settings.env,VISUAL:command,EDITOR:command}}));
}
