import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {hash} from '../artifacts/runs.mjs';

export async function probeFileRewind(executable, workspace, output) {
  executable=resolve(executable);workspace=resolve(workspace);output=resolve(output);
  await mkdir(workspace,{recursive:true});
  const cwd=await mkdtemp(join(workspace,'rewind-'));
  const file=join(cwd,'fixture.txt');
  await writeFile(file,'before\n');
  const model=await startSyntheticModel(cwd,'Edit');
  const request=(id,payload)=>JSON.stringify({type:'control_request',request_id:id,request:payload})+'\n';
  const userUuid='44444444-4444-4444-8444-444444444444';
  let buffer='',result,invalidDryRun,dryRun,rewind,afterEdit,afterInvalidDryRun,afterDryRun,afterRewind;
  const permissions=[];
  try {
    const run=await record({executable,cwd,output,timeoutMs:30000,
      args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--bare',
        '--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),
        '--strict-mcp-config','--tools','Read,Edit','--model','claude-sonnet-4-6','--permission-prompt-tool','stdio','--replay-user-messages'],
      env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),ANTHROPIC_BASE_URL:model.url,
        CLAUDE_CODE_ENABLE_SDK_FILE_CHECKPOINTING:'1',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
      input:[request('initialize',{subtype:'initialize',hooks:{}})],
      onStdout(bytes,transport){
        buffer+=bytes;
        while(buffer.includes('\n')){
          const at=buffer.indexOf('\n'),line=buffer.slice(0,at);buffer=buffer.slice(at+1);
          let value;try{value=JSON.parse(line)}catch{continue}
          if(value.type==='control_response'&&value.response.request_id==='initialize'){
            transport.send(JSON.stringify({type:'user',uuid:userUuid,message:{role:'user',content:'Read fixture.txt then replace before with after.'}})+'\n');
          }
          if(value.type==='control_request'&&value.request.subtype==='can_use_tool'){
            permissions.push(value.request.tool_name);
            transport.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,
              response:{behavior:'allow',updatedInput:value.request.input}}})+'\n');
          }
          if(value.type==='result'){
            result=value;
            // The file reads are synchronous so the capture precedes the next transport request.
            afterEdit=readFixture(file);
            transport.send(request('invalid-dry-run',{subtype:'rewind_files',user_message_id:'55555555-5555-4555-8555-555555555555',dry_run:true}));
          }
          if(value.type==='control_response'&&value.response.request_id==='invalid-dry-run'){
            invalidDryRun=value.response;afterInvalidDryRun=readFixture(file);
            transport.send(request('dry-run',{subtype:'rewind_files',user_message_id:userUuid,dry_run:true}));
          }
          if(value.type==='control_response'&&value.response.request_id==='dry-run'){
            dryRun=value.response;afterDryRun=readFixture(file);
            transport.send(request('rewind',{subtype:'rewind_files',user_message_id:userUuid,dry_run:false}));
          }
          if(value.type==='control_response'&&value.response.request_id==='rewind'){
            rewind=value.response;afterRewind=readFixture(file);transport.closeInput();
          }
        }
      }});
    const evidence={verified:run.status==='complete'&&result?.subtype==='success'&&afterEdit==='after\n'
      &&invalidDryRun?.response?.canRewind===false&&afterInvalidDryRun==='after\n'&&dryRun?.subtype==='success'&&afterDryRun==='after\n'&&rewind?.subtype==='success'&&afterRewind==='before\n',
      cwd,sessionId:result?.session_id,userMessageId:userUuid,invalidDryRun,dryRun,rewind,afterEdit,afterInvalidDryRun,afterDryRun,afterRewind,permissions,syntheticApiRequests:model.calls.length,realModelRequests:0,
      driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))};
    await writeFile(join(run.directory,'file-rewind.json'),JSON.stringify(evidence,null,2)+'\n');
    if(!evidence.verified){const path=join(run.directory,'manifest.json');const manifest=JSON.parse(await readFile(path));await writeFile(path,JSON.stringify({...manifest,status:'failed',reason:'file-rewind-verification-failed'},null,2)+'\n')}
    assert.equal(evidence.verified,true,`Rewind verification failed: ${run.directory}`);
    return {...run,...evidence};
  }finally{await model.close()}
}
import {readFileSync} from 'node:fs';
const readFixture=file=>readFileSync(file,'utf8');
