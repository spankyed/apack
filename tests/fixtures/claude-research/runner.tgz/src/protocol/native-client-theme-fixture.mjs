import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Original Client sandbox draws semantic roles; only owned native theme files change. */
export async function addNativeClientThemeFixture(plugin,workspace){
 const palettes={dark:{name:'Client review',base:'dark',overrides:{text:'#e2e8f0',inverseText:'#263241',success:'#86efac',warning:'#fbbf24'}},light:{name:'Client review',base:'light',overrides:{text:'#0f172a',inverseText:'#f3f4f6',success:'#166534',warning:'#92400e'}}};
 const themePath=join(workspace,'.claude/themes/client-review.json');await mkdir(join(workspace,'.claude/themes'),{recursive:true});
 const settingsPath=join(workspace,'.claude/settings.json');await writeFile(settingsPath,JSON.stringify({...JSON.parse(await readFile(settingsPath,'utf8')),theme:'custom:client-review'}));
 await writeFile(themePath,JSON.stringify(palettes.dark));await writeFile(join(workspace,'native-client-theme-inputs.json'),JSON.stringify({themePath,palettes},null,2));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){
 let retired=false;const receipts=[];
 on('ui.render',{component:'AbovePrompt'},($,e,next)=>{if(e.surface!=='desktop'||retired)return next(e);const {Client}=$.ui.resolve(e);return Client({key:'workspace-theme',module:'./client-theme.ts',props:{},height:4});});
 on('ui.message',async($,e,next)=>{if(e.data?.clientTheme!==true)return next(e);if(e.data.key==='r')retired=true;receipts.push({...e.data,retired,surface:e.surface,component:e.component,at:await $.clock.now()});await $.fs.write('native-client-theme-events.json',JSON.stringify(receipts));if(retired)await $.ui.invalidate('ui.render');return {props:{}};});
}`);
 await writeFile(join(plugin,'hooks/client-theme.ts'),`export default function(_props,s){
 const {Box,Text}=s.elements;if(s.state===undefined)s.setState({count:0});
 s.onKey(e=>{if(e.key==='u')s.setState({count:s.state.count+1});s.post({clientTheme:true,key:e.key,count:s.state.count});});
 return Box({flexDirection:'column',backgroundColor:'inverseText',children:[Text({color:'success',children:['Workspace connected']}),Text({children:['Release review ready']}),Text({color:'warning',children:['Updates '+s.state.count]})]});
}`);
}
