/** Pinned 2.1.302 side queries: agent_namer (chunk-5gs3r92m) and job classifier (chunk-aspqank8). */
export function nativeBackgroundMetadataFixture(request) {
  if (request.tools?.length || request.messages?.length !== 1) return;
  const message = request.messages[0];
  if (message.role !== 'user' || typeof message.content !== 'string') return;
  if (message.content.startsWith('2-4 word lowercase label for this job.\nUser: "')) {
    return {kind: 'job-name', text: 'release review'};
  }
  if (/^Current state: (working|blocked|done|failed) \(for [0-9]+m\)\nTool calls so far:/.test(message.content)) {
    return {kind: 'job-status', text: JSON.stringify({state: 'working', tempo: 'idle', detail: 'Release review ready for follow-up', happened: 'Release review completed.', output: {}})};
  }
}
