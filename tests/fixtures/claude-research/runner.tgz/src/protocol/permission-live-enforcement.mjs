import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {readFileSync,unlinkSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Three fixed tool attempts in one process, with durable deny added/removed between inputs. */
export async function probePermissionLiveEnforcement(executable,root,output,{applyFlag=false,refreshOnly=false}={}){
 if(refreshOnly&&!applyFlag)throw new Error('Empty patch requires applyFlag');
 const stage=refreshOnly?'permission-live-refresh-enforcement':applyFlag?'permission-live-flag-enforcement':'permission-live-enforcement';
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'permission-live-enforcement-')),cwd=join(workspace,'project'),home=join(workspace,'home'),config=join(home,'.claude');await mkdir(cwd,{recursive:true});await mkdir(config,{recursive:true});
 const settings=join(config,'settings.json');await writeFile(settings,JSON.stringify({language:'research-preserve',apiKeyHelper:'/usr/bin/printf research-fixture-key'}));
 const env={PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
 const run=await createRun(output,stage,{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
 const edits=[],phases=[];let model;
 const edit=value=>{const response=JSON.parse(execFileSync(executable,['edit-permission-rules','--json'],{cwd,env,input:JSON.stringify(value)+'\n',timeout:5000,maxBuffer:65536}).toString());assert.equal(response.ok,true);const saved=JSON.parse(readFileSync(settings,'utf8'));assert.equal(saved.language,'research-preserve');edits.push({edit:value,response,settings:saved})};
 try{
  edit({op:'add',rules:['Bash'],behavior:'allow',destination:'userSettings'});
  model=await startSyntheticModel(cwd,'Bash',{forceBash:true,bashPerInput:true});let pending='',phase=0;const permissions=[],toolResults=[];
  const request=(id,value)=>JSON.stringify({type:'control_request',request_id:id,request:value})+'\n';
  const begin=channel=>{phases.push({turn:phase+1});channel.send(request(`rules-${phase}`,{subtype:'list_permission_rules'}))};
  const transport=await record({executable,cwd,output,timeoutMs:35000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--permission-mode','default','--setting-sources','user','--strict-mcp-config','--tools','Bash','--no-session-persistence','--max-turns','3'],env:{...env,ANTHROPIC_BASE_URL:model.url},input:[request('init',{subtype:'initialize',hooks:{}})],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){
    const i=pending.indexOf('\n'),line=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(line)}catch{continue}
    if(value.type==='control_response'){
     assert.equal(value.response.subtype,'success');const id=value.response.request_id;
     if(id==='init'&&refreshOnly)channel.send(request('flag-seed',{subtype:'apply_flag_settings',settings:{language:'flag-preserve',permissions:{ask:['Read']}}}));
     else if(id==='init'||id==='flag-seed'||id===`flag-${phase}`)begin(channel);
     if(id===`rules-${phase}`){phases[phase].catalog=value.response.response;channel.send(request(`settings-${phase}`,{subtype:'get_settings'}))}
     if(id===`settings-${phase}`){phases[phase].settings=value.response.response;channel.send(JSON.stringify({type:'user',message:{role:'user',content:`ResearchPermissionTurn${phase+1}: write only the disposable synthetic fixture marker.`}})+'\n')}
    }
    if(value.type==='control_request'&&value.request?.subtype==='can_use_tool'){
     assert.equal(value.request.tool_name,'Bash');permissions.push({turn:phase+1,request:value.request});channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:{behavior:'deny',message:'Private fixture refuses fallback permission requests.'}}})+'\n');
    }
    if(value.type==='user'&&Array.isArray(value.message?.content))toolResults.push(...value.message.content.filter(block=>block.type==='tool_result').map(result=>({turn:phase+1,...result})));
    if(value.type==='result'){
     assert.equal(value.is_error,false);let marker;try{marker=readFileSync(join(cwd,'fixture.txt'),'utf8');unlinkSync(join(cwd,'fixture.txt'))}catch(error){if(error.code!=='ENOENT')throw error}
     phases[phase].marker=marker??null;phases[phase].resultSubtype=value.subtype;
     if(phase===2){channel.closeInput();continue}
     edit(phase===0?{op:'add',rules:['Bash'],behavior:'deny',destination:'userSettings'}:{op:'remove',rule:'Bash',behavior:'deny',source:'userSettings'});phase++;if(applyFlag)channel.send(request(`flag-${phase}`,{subtype:'apply_flag_settings',settings:refreshOnly?{}:{permissions:{deny:phase===1?['Bash']:[]}}}));else begin(channel);
    }
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(phases.length,3);assert.ok(phases.every(item=>item.resultSubtype));
  for(let turn=1;turn<=3;turn++)assert.ok(toolResults.some(result=>result.turn===turn&&result.tool_use_id===`toolu_research_fixture_${turn}`));
  assert.deepEqual(model.calls.map(call=>call.fixtureTurn),[1,1,2,2,3,3]);
  if(refreshOnly){
   assert.deepEqual(phases.map(item=>item.marker),['synthetic protocol fixture\n',null,'synthetic protocol fixture\n']);
   assert.deepEqual(phases.map(item=>item.catalog.state.rules.some(rule=>rule.behavior==='deny'&&rule.rule==='Bash'&&rule.source==='userSettings')),[false,true,false]);
   assert.ok(phases.every(item=>!item.catalog.state.rules.some(rule=>rule.behavior==='deny'&&rule.rule==='Bash'&&rule.source==='flagSettings')));
   assert.ok(phases.every(item=>item.catalog.state.rules.some(rule=>rule.behavior==='ask'&&rule.rule==='Read'&&rule.source==='flagSettings')));
   assert.ok(phases.every(item=>item.settings.effective.language==='flag-preserve'&&item.settings.effective.permissions.ask.includes('Read')));
   assert.equal(permissions.length,0);
   assert.ok(toolResults.some(result=>result.turn===2&&result.is_error&&/Permission to use Bash has been denied/.test(String(result.content))));
  }else if(applyFlag){
   assert.deepEqual(phases.map(item=>item.marker),['synthetic protocol fixture\n',null,'synthetic protocol fixture\n']);
   assert.deepEqual(phases.map(item=>item.catalog.state.rules.some(rule=>rule.behavior==='deny'&&rule.rule==='Bash')),[false,true,false]);
   assert.deepEqual(phases.map(item=>item.settings.effective.permissions?.deny?.includes('Bash')??false),[false,true,false]);
   assert.equal(permissions.length,0);
   assert.ok(phases[1].catalog.state.rules.some(rule=>rule.behavior==='deny'&&rule.rule==='Bash'&&rule.source==='flagSettings'&&rule.editability==='readonly'));
   assert.ok(phases[1].catalog.state.rules.some(rule=>rule.behavior==='deny'&&rule.rule==='Bash'&&rule.source==='userSettings'));
   assert.ok(model.calls.every(call=>call.toolNames.includes('Bash')));
   assert.ok(toolResults.some(result=>result.turn===2&&result.is_error&&/Permission to use Bash has been denied/.test(String(result.content))));
  }else if(!applyFlag){
  assert.deepEqual(phases.map(item=>item.marker),Array(3).fill('synthetic protocol fixture\n'));
  assert.deepEqual(phases.map(item=>item.catalog.state.rules.some(rule=>rule.behavior==='deny'&&rule.rule==='Bash')),[false,false,false]);
  assert.deepEqual(phases.map(item=>item.settings.effective.permissions?.deny?.includes('Bash')??false),[false,true,false]);
  assert.equal(permissions.length,0);
  assert.ok(toolResults.every(result=>!result.is_error));
  }
  const normalize=value=>JSON.parse(JSON.stringify(value).split(workspace).join('${WORKSPACE}'));
  const result=normalize({applyFlag,refreshOnly,phases,edits,permissions,toolResults,modelCalls:model.calls,realModelRequests:0,qualification:(refreshOnly?'Seeds flag language/Read ask, then sends repeated empty apply_flag_settings patches after each external edit and verifies seed preservation. ':applyFlag?'Also sends explicit apply_flag_settings permissions.deny mirroring each edit; flag source differs from durable user source. ':'')+'User allow baseline plus external user deny add/remove between three actual host inputs, one retained process, default mode and forced fixed Bash only. Immediate catalog snapshots precede each input. Other sources/modes, arbitrary watcher timing and app editor behavior are unproven.'});
  await writeFile(join(run.directory,stage+'.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',markers:phases.map(item=>item.marker!==null),catalogDeny:phases.map(item=>item.catalog.state.rules.some(rule=>rule.behavior==='deny'&&rule.rule==='Bash')),settingsDeny:phases.map(item=>item.settings.effective.permissions?.deny?.includes('Bash')??false),permissionRequests:permissions.length,realModelRequests:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}finally{await model?.close()}
}
