import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {hash} from '../artifacts/runs.mjs';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';

/** Explicit local plugin; native gates remain unchanged. No arbitrary vendor code is evaluated. */
export async function probeMod(executable,workspace,output,mode='filesystem'){
 if(!['filesystem','question','ui-limits'].includes(mode))throw new Error('Unknown mod probe mode');
 await mkdir(workspace,{recursive:true});const cwd=await mkdtemp(join(workspace,'native-mod-'));
 const plugin=join(cwd,'plugin');await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
 const manifest=JSON.stringify({name:'research-mod-fixture',version:'0.0.1',description:'Disposable local mod contract fixture.'},null,2)+'\n';
 const question='Which synthetic mod fixture?';
 const body=mode==='question'
  ? `const answer = await $.ui.ask(${JSON.stringify(question)}, ["Alpha", "Beta"]);\n    await $.fs.write("mod-marker.txt", "synthetic mod answer: " + answer + "\\n");`
  : mode==='ui-limits'
   ? `const view = await $.ui.view({});\n    const identity = await $.session.identity();\n    await $.fs.write("mod-marker.txt", JSON.stringify({view, identity}));`
   : `await $.fs.write("mod-marker.txt", "synthetic mod session.start\\n");`;
 const source=`export function register(on) {\n  on("session.start", async ($, e, next) => {\n    ${body}\n    return next(e);\n  });\n}\n`;
 const hooks=JSON.stringify({modules:['./register.ts']},null,2)+'\n';
 await writeFile(join(plugin,'.claude-plugin','plugin.json'),manifest);await writeFile(join(plugin,'hooks','register.ts'),source);await writeFile(join(plugin,'hooks','hooks.json'),hooks);
 const model=await startSyntheticModel(cwd,'TextOnly');let pending='',result,initialization;const permissions=[];
 try{
  const run=await record({executable,cwd,output,timeoutMs:20000,
   args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--debug-file',join(cwd,'native-debug.log'),'--permission-mode','default','--setting-sources','','--strict-mcp-config','--plugin-dir',plugin,'--tools',mode==='question'?'AskUserQuestion':'','--permission-prompt-tool','stdio','--max-turns','1','--no-session-persistence','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})],
   env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),ANTHROPIC_BASE_URL:model.url,ENABLE_TOOL_SEARCH:'0',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
   input:[JSON.stringify({type:'control_request',request_id:'initialize',request:{subtype:'initialize',hooks:{}}})+'\n'],
   onStdout(bytes,transport){pending+=bytes.toString('utf8');while(pending.includes('\n')){const at=pending.indexOf('\n'),line=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(line)}catch{continue}
    if(value.type==='control_response'&&value.response?.request_id==='initialize'){initialization=value.response;transport.send(JSON.stringify({type:'user',message:{role:'user',content:'Confirm the synthetic mod fixture without using tools.'},parent_tool_use_id:null})+'\n')}
    if(value.type==='control_request'){
     permissions.push(value);const request=value.request;
     const expected=mode==='question'&&request?.subtype==='can_use_tool'&&request.tool_name==='AskUserQuestion'&&request.input?.questions?.length===1&&request.input.questions[0].question===question;
     const decision=expected?{behavior:'allow',updatedInput:{...request.input,answers:{[question]:'Alpha'}}}:{behavior:'deny',message:'Unexpected request in isolated mod fixture'};
     transport.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:decision}})+'\n');
    }
    if(value.type==='result'){result=value;transport.closeInput()}
   }}});
  let marker;try{marker=await readFile(join(cwd,'mod-marker.txt'),'utf8')}catch(error){if(error.code!=='ENOENT')throw error}
  const debug=await readFile(join(cwd,'native-debug.log'),'utf8');
  await writeFile(join(run.directory,'native-debug.log'),debug);
  const stages={workerLoaded:debug.includes('hooks module research-mod-fixture@inline loaded (worker,'),admitted:debug.includes('plugin.register: research-mod-fixture (user, research-mod-fixture@inline), judged by core alone: admitted'),hookSettled:debug.includes('hooks module research-mod-fixture@inline session.start settled')};
  let observations;if(mode==='ui-limits')try{observations=JSON.parse(marker)}catch{}
  const observed=mode==='question'?marker==='synthetic mod answer: Alpha\n'&&permissions.length===1:mode==='ui-limits'?observations?.view?.deny==='no main view here'&&observations?.identity?.deny?.includes('managed settings enable')&&permissions.length===0:marker==='synthetic mod session.start\n'&&permissions.length===0;
  const verified=Boolean(observed)&&Object.values(stages).every(Boolean)&&run.status==='complete'&&result?.subtype==='success'&&model.calls.length===1;
  const evidence={verified,mode,observations,stages,debugSha256:hash(Buffer.from(debug)),targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),pluginManifestSha256:hash(Buffer.from(manifest)),pluginSourceSha256:hash(Buffer.from(source)),pluginHooksSha256:hash(Buffer.from(hooks)),initialization,permissions,result,marker,calls:model.calls,realModelRequests:0,qualification:`Explicit private local plugin ${mode} fixture. No rollout overrides; not full mods/UI or policy parity.`};
  await writeFile(join(run.directory,'mod-probe.json'),JSON.stringify(evidence,null,2)+'\n');
  if(!verified){const path=join(run.directory,'manifest.json');const value=JSON.parse(await readFile(path,'utf8'));await writeFile(path,JSON.stringify({...value,status:'failed',verificationFailure:'native-mod-marker-not-verified'},null,2)+'\n')}
  return{...run,status:verified?'complete':'failed',verified,mode,markerWritten:marker!==undefined,syntheticApiRequests:model.calls.length,realModelRequests:0};
 }finally{await model.close()}
}
