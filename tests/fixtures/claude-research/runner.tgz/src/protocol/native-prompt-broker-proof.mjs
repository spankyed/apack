import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Validate preserved original read, process, journal and actual-app recovery receipts. */
export async function verifyPromptBrokerFailure(workspace,evidence,seedCalls){
 const proof=JSON.parse(await readFile(join(workspace,'native-prompt-broker-failure-proof.json'),'utf8'));
 assert.equal(evidence.nativePromptBrokerFailure,true);assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.boundNativePid,evidence.boundNativePid);assert.equal(proof.freshPid,evidence.reopenedNativePid);assert.notEqual(proof.freshPid,proof.boundNativePid);
 assert.equal(proof.failure.kind,'broker');assert.equal(proof.failure.nativePid,proof.boundNativePid);assert.ok(proof.failure.retiredAt>=proof.failure.at);
 assert.equal(proof.replies.length,2);assert.notEqual(proof.replies[0].requestId,proof.replies[1].requestId);assert.notEqual(proof.replies[0].mountId,proof.replies[1].mountId);
 assert.deepEqual(proof.replies[0].box,proof.old);assert.deepEqual(proof.replies[1].box,proof.current);assert.deepEqual(proof.fresh.result,proof.current);
 assert.ok(proof.replies[0].heldAt<=proof.failure.at);assert.ok(proof.replies[1].heldAt>proof.failure.retiredAt);assert.ok(proof.replies[0].releasedAt>proof.replies[1].heldAt);assert.ok(proof.replies[1].releasedAt>proof.replies[0].releasedAt);assert.ok(proof.fresh.finished>=proof.replies[1].releasedAt);
 for(const reply of proof.replies){
  if(!reply.transport)continue; // Preserved pre-batching evidence retains its original frame-only scope.
  const original=JSON.parse(reply.transport.originalFrame), released=JSON.parse(reply.transport.releaseFrame);
  const messages=Array.isArray(original)?original:[original], held=Array.isArray(released)?released:[released];
  const addressed=messages.filter(message=>message?.params?.input?.event?.type==='CLAUDE_PROMPT_HOST_RESPONSE'&&message.params.input.event.requestId===reply.requestId);
  assert.equal(addressed.length,1);assert.deepEqual(held,addressed);
  assert.equal(reply.transport.forwardedOperations,messages.length-1);
  assert.deepEqual(held[0].params.input.event.box,reply.box);
 }
 assert.equal(proof.oldDidNotSettleFresh,true);assert.equal(proof.noPhantomTurn,true);assert.equal(seedCalls.length,2);
 const folders=(await readdir(join(workspace,'electron-results'),{withFileTypes:true})).filter(row=>row.isDirectory());
 for(const phase of ['disconnected','recovered'])for(const [width,height]of [[1100,900],[680,600]]){const matches=[];for(const folder of folders){try{matches.push(await readFile(join(workspace,'electron-results',folder.name,'native-prompt-broker-'+phase+'-'+width+'.png')))}catch(error){if(error.code!=='ENOENT')throw error;}}assert.equal(matches.length,1);assert.equal(matches[0].subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(matches[0].readUInt32BE(16),width);assert.equal(matches[0].readUInt32BE(20),height);}

 const rows=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const children=await rows('native-children.jsonl'),exits=await rows('native-exits.jsonl');
 assert.equal(children.length,5);assert.equal(children[1].pid,proof.boundNativePid);assert.equal(children[3].pid,proof.freshPid);
 assert.ok(proof.failure.retiredAt<=children[2].at);assert.ok(children[2].args.includes('--print')&&children[2].args.includes('--no-session-persistence'));assert.ok(children[3].args.includes('--resume'));assert.ok(children[4].args.includes('--print'));
 for(const [before,after]of [[0,1],[2,3],[3,4]])assert.ok(exits.find(row=>row.pid===children[before].pid)?.at<=children[after].at);
 const paths=(await readdir(join(workspace,'.claude/projects'),{recursive:true})).filter(path=>path.split('/').at(-1)===proof.sessionId+'.jsonl');assert.equal(paths.length,1);
 const journal=(await readFile(join(workspace,'.claude/projects',paths[0]),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse),unique=new Map(journal.filter(row=>row.uuid).map(row=>[row.uuid,row]));
 const humans=[...unique.values()].filter(row=>row.type==='user'&&row.isMeta!==true);assert.equal(humans.length,2,'Pending UI reads cannot add original human turns');
 const text=content=>typeof content==='string'?content:Array.isArray(content)?content.filter(block=>block.type==='text').map(block=>block.text).join('\n'):'';
 assert.ok(humans.some(row=>text(row.message?.content).includes('Seed this private native interface session.')));assert.ok(humans.some(row=>text(row.message?.content).includes('Continue after recovering the interrupted native draft read.')));
 return {sessionId:proof.sessionId,oldNativePid:proof.boundNativePid,reopenedNativePid:proof.freshPid,oldRequestId:proof.replies[0].requestId,freshRequestId:proof.replies[1].requestId,originalHumanTurns:humans.length,captures:4,oldDidNotSettleFresh:true,scope:'Owned broker loss with pending original parent read, explicit compact workspace trust and visible composer editing; distinct fresh owner, late raw frame refusal, native read/history and same-session recovery. Other reverse kinds/windows remain separate.'};
}
