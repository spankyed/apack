import {appendFileSync} from 'node:fs';
import {createInterface} from 'node:readline';
import {mcpReleaseForm} from './mcp-elicitation-app-fixture.mjs';
const send=value=>process.stdout.write(JSON.stringify({jsonrpc:'2.0',...value})+'\n');
const pending=new Map();
createInterface({input:process.stdin}).on('line',line=>{
 let value;try{value=JSON.parse(line)}catch{return}
 appendFileSync(process.env.APACK_MCP_ELICITATION_RECEIPT,JSON.stringify(value)+'\n');
 if(pending.has(value.id)){
  const tool=pending.get(value.id);pending.delete(value.id);
  send({id:tool,result:{content:[{type:'text',text:JSON.stringify({elicitation:value.result??{error:value.error}})}]}});return;
 }
 if(value.id===undefined)return;
 switch(value.method){
  case 'initialize':send({id:value.id,result:{protocolVersion:value.params.protocolVersion,capabilities:{tools:{}},serverInfo:{name:'release-review',version:'1.0.0'}}});return;
  case 'ping':send({id:value.id,result:{}});return;
  case 'tools/list':send({id:value.id,result:{tools:[{name:'echo',description:'Review release notes after collecting explicit reviewer input.',inputSchema:{type:'object',properties:{scenario:{type:'string'},phase:{type:'integer'}},required:['scenario','phase']}}]}});return;
  case 'tools/call':{
   const {scenario,phase}=value.params.arguments,id='research-elicitation-'+phase;
   pending.set(id,value.id);const mode=scenario.startsWith('url-')?'url':'form';
   send({id,method:'elicitation/create',params:{mode,message:mode==='form'?'Confirm the release review details.':'Complete the release review on the requested page, then return here.',...(mode==='form'?{requestedSchema:mcpReleaseForm}:{url:'https://example.invalid/release-review',elicitationId:'release-review-'+phase}),_meta:{'anthropic/permissionDisplay':{title:'Release review',displayName:'Release review server',description:'Review input stays in the private fixture.'}}}});return;
  }
 }
 send({id:value.id,error:{code:-32601,message:'Unsupported fixture operation'}});
});
