import {appendFileSync,existsSync,readFileSync} from 'node:fs';
import {createInterface} from 'node:readline';
import {mcpReleaseForm} from './mcp-elicitation-app-fixture.mjs';
const send=value=>process.stdout.write(JSON.stringify({jsonrpc:'2.0',...value})+'\n');
function reviewUrl(phase){
 const configured=process.env.APACK_MCP_URL_BROWSER_ORIGIN;if(!configured)return 'https://example.invalid/release-review';
 const origin=new URL(configured);if(origin.protocol!=='http:'||origin.hostname!=='127.0.0.1'||origin.href!==origin.origin+'/')throw Error('Only owned loopback review pages are allowed');
 return origin.origin+'/release-review?phase='+phase;
}
const pending=new Map(),completionPhases=new Map(),retryCounts=new Map();
function watchCompletion(phase){
 const root=process.env.APACK_MCP_URL_CONTROL_ROOT;if(!root)return;
 const path=root+'/mcp-url-completion-'+phase,deadline=Date.now()+30000;let previous;
 const timer=setInterval(()=>{if(Date.now()>deadline){clearInterval(timer);return;}if(!existsSync(path))return;const id=readFileSync(path,'utf8');if(id===previous)return;if(id!=='release-review-foreign'&&id!=='release-review-'+phase)throw Error('Invalid owned completion ID');previous=id;const notification={method:'notifications/elicitation/complete',params:{elicitationId:id}};appendFileSync(process.env.APACK_MCP_ELICITATION_RECEIPT,JSON.stringify({fixtureOutgoing:notification})+'\n');send(notification);if(id==='release-review-'+phase)clearInterval(timer);},25);timer.unref();
}
createInterface({input:process.stdin}).on('line',line=>{
 let value;try{value=JSON.parse(line)}catch{return}
 appendFileSync(process.env.APACK_MCP_ELICITATION_RECEIPT,JSON.stringify(value)+'\n');
 if(pending.has(value.id)){
  const tool=pending.get(value.id);pending.delete(value.id);const phase=completionPhases.get(value.id);if(phase!==undefined){completionPhases.delete(value.id);if(value.result?.action==='accept')watchCompletion(phase);}
  send({id:tool,result:{content:[{type:'text',text:JSON.stringify({elicitation:value.result??{error:value.error}})}]}});return;
 }
 if(value.id===undefined)return;
 switch(value.method){
  case 'initialize':send({id:value.id,result:{protocolVersion:value.params.protocolVersion,capabilities:{tools:{}},serverInfo:{name:'release-review',version:'1.0.0'}}});return;
  case 'ping':send({id:value.id,result:{}});return;
  case 'tools/list':send({id:value.id,result:{tools:[{name:'echo',description:'Review release notes after collecting explicit reviewer input.',inputSchema:{type:'object',properties:{scenario:{type:'string'},phase:{type:'integer'}},required:['scenario','phase']}}]}});return;
  case 'tools/call':{
   const {scenario,phase}=value.params.arguments,id='research-elicitation-'+phase;
   if(scenario.startsWith('url-retry')){
    const attempt=(retryCounts.get(phase)??0)+1;retryCounts.set(phase,attempt);
    if(attempt===1){const response={id:value.id,error:{code:-32042,message:'Release review requires opening a URL',data:{elicitations:[{mode:'url',message:'Complete the release review on the requested page, then retry.',url:reviewUrl(phase),elicitationId:'release-retry-'+phase}]}}};appendFileSync(process.env.APACK_MCP_ELICITATION_RECEIPT,JSON.stringify({fixtureOutgoing:response})+'\n');send(response);}
    else send({id:value.id,result:{content:[{type:'text',text:'Original retry completed for phase'+phase}]}});
    return;
   }
   pending.set(id,value.id);if(scenario==='url-complete')completionPhases.set(id,phase);const mode=scenario.startsWith('url-')?'url':'form';
   send({id,method:'elicitation/create',params:{mode,message:mode==='form'?'Confirm the release review details.':'Complete the release review on the requested page, then return here.',...(mode==='form'?{requestedSchema:mcpReleaseForm}:{url:reviewUrl(phase),elicitationId:'release-review-'+phase}),_meta:{'anthropic/permissionDisplay':{title:'Release review',displayName:'Release review server',description:'Review input stays in the private fixture.'}}}});return;
  }
 }
 send({id:value.id,error:{code:-32601,message:'Unsupported fixture operation'}});
});
