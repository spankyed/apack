import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

export const genericPermissionDescription = 'Review local migration notes for the current release.\nThe request includes the project, review flags and target release date.\nReturn the submitted notes without reading files or contacting a service.';
export const genericPermissionSteps = [
  { tool: 'mcp__research__echo', input: { message: 'Review the migration notes.', count: 3, flags: { preserveOriginal: true }, deadline: '2026-10-22T12:00:00Z' }, prompt: 'Review these migration notes with the connected release tool.', decision: 'once' },
  { tool: 'mcp__research__echo', input: { message: 'Proposed release changes' }, prompt: 'Ask before sending the proposed release changes to the tool.', decision: 'deny' },
  { tool: 'mcp__research__echo', input: { message: 'Remember this local release review tool' }, prompt: 'Remember permission for this local release review tool.', decision: 'standing' },
  { tool: 'mcp__research__echo', input: { message: 'Long migration notes: '+ 'x'.repeat(200268) }, prompt: 'Review the large migration-notes request before using the tool.', decision: 'withheld-deny' },
  { tool: 'mcp__research__echo', input: { message: 'Cancel the pending review' }, prompt: 'Review this final tool request before continuing.', decision: 'cancel' },
];
export async function addNativeGenericPermissionFixture(workspace, plugin) {
  const path = join(workspace, '.claude/settings.json'), settings = JSON.parse(await readFile(path, 'utf8'));
  settings.permissions.ask = [...new Set([...settings.permissions.ask, 'mcp__research__echo'])];
  await writeFile(path, JSON.stringify(settings));
  await writeFile(join(workspace, 'native-generic-permission-steps.json'), JSON.stringify(genericPermissionSteps));
  await writeFile(join(workspace, 'native-generic-permission-description.txt'), genericPermissionDescription);
  await writeFile(join(plugin, 'hooks/register.ts'), `export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&/^native_permission_/.test(e.props.tool_use_id))await $.fs.write('native-generic-permission-result-'+e.props.tool_use_id+'.json',JSON.stringify({props:e.props}));return next(e);});}`);
}
export async function verifyNativeGenericPermissions(workspace, calls, proof) {
  assert.equal(proof.steps.length, 5); assert.equal(proof.retainedDraft, true);
  const results = calls.flatMap(call => call.toolPermissionResults ?? []);
  for (const phase of [1, 2, 3, 4]) {
    const result = results.find(row => row.tool_use_id === 'native_permission_' + phase);
    assert.ok(result, 'Original generic tool result missing: ' + phase);
    if ([1, 3].includes(phase)) assert.notEqual(result.is_error, true);
    else { assert.equal(result.is_error, true); assert.match(JSON.stringify(result.content), /Keep the original release notes/); }
  }
  const receipts = (await readFile(join(workspace, 'mcp-receipts.jsonl'), 'utf8')).trim().split('\n').map(JSON.parse);
  const executed = receipts.filter(row => row.method === 'tools/call');
  assert.equal(executed.length, 2); assert.deepEqual(executed.map(row => row.arguments.message), [genericPermissionSteps[0].input.message, genericPermissionSteps[2].input.message]);
  assert.deepEqual(executed[0].arguments, genericPermissionSteps[0].input);
  const settings = JSON.parse(await readFile(join(workspace, '.claude/settings.local.json'), 'utf8'));
  assert.ok(settings.permissions.allow.includes('mcp__research__echo'));
  const inspection = JSON.parse(await readFile(join(workspace, 'native-dialog-shapes.json'), 'utf8'));
  const opened = inspection.events.flatMap(event => event.value?.open ?? []);
  for (let phase=1;phase<=5;phase++) assert.ok(opened.some(row => row.kind === 'permission_prompt' && row.payload?.requestId === 'native_permission_'+phase));
  const children = (await readFile(join(workspace, 'mcp-children.jsonl'), 'utf8')).trim().split('\n').map(JSON.parse);
  const exits = (await readFile(join(workspace, 'mcp-exits.jsonl'), 'utf8')).trim().split('\n').map(JSON.parse);
  assert.ok(children.length>0);for(const child of children)assert.ok(exits.some(row=>row.pid===child.pid),'Owned MCP process exit missing');
  return { originalMcpExecution: true, originalDenialFeedback: true, originalStandingScopePersisted: true, originalWithholding: true, cancelledRequestNotExecuted: true, ownedMcpShutdown: true };
}
