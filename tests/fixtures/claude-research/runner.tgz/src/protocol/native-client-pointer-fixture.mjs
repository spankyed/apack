import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

/** Ordinary local plugin. Native Client listeners and their original unsubscribe own admission. */
export async function createClientPointerFixture(plugin,project){
 for(const path of ['.claude-plugin','hooks'])await mkdir(join(plugin,path),{recursive:true});
 await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'release-timeline',version:'0.0.1'}));
 await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
 const mode={key:'initial',pointer:true,show:true};await writeFile(join(project,'client-pointer-mode.json'),JSON.stringify(mode),{flag:'wx'});
 const source=`export function register(on){let mode=${JSON.stringify(mode)},last=JSON.stringify(mode),rows=[],seen=new Map(),writes=Promise.resolve();
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const base=await next(e);if(e.surface!=='desktop'||e.view?.agentId)return base;const{Box,Client}=$.ui.resolve(e);return Box({flexDirection:'column',children:[base,Client({key:'timeline-clock',module:'./clock.ts',height:1}),...(mode.show?[Client({key:mode.key,module:'./timeline.ts',props:{name:mode.key,pointer:mode.pointer},width:'100%',height:3})]:[])]});});
 on('ui.message',async($,e,next)=>{if(e.data?.timelineClock===true){const text=await $.fs.read('client-pointer-mode.json');if(text!==last){mode=JSON.parse(text);last=text;await $.ui.invalidate('ui.render');}return next(e);}if(e.data?.timelinePointer!==true)return next(e);const identity=JSON.stringify([e.surface,e.component,e.element,e.data.incarnation]);let serial=seen.get(identity)??0;for(const item of e.data.events){if(item.serial<=serial)continue;if(item.serial!==serial+1)throw Error('Pointer fixture history gap');rows.push({timelinePointer:true,...item,incarnation:e.data.incarnation,surface:e.surface,component:e.component,element:e.element});serial=item.serial;}seen.set(identity,serial);if(rows.length>256)throw Error('Pointer fixture receipt limit');const snapshot=JSON.stringify(rows);writes=writes.then(()=>$.fs.write('client-pointer-receipts.json',snapshot));await writes;return next(e);});}`;
 const module=`let incarnation=0;const stops=new WeakMap();export default function(props,s){const{Box,Text}=s.elements;if(s.state===undefined)s.setState({last:'Ready',incarnation:++incarnation,events:[]});if(props.pointer&&!stops.has(s)){stops.set(s,s.onPointer(input=>{if(s.state.events.length>=256)throw Error('Pointer fixture callback limit');const events=[...s.state.events,{serial:s.state.events.length+1,name:props.name,input}];s.setState({...s.state,last:input.type+' '+input.x+','+input.y,events});s.post({timelinePointer:true,incarnation:s.state.incarnation,events});}));}if(!props.pointer&&stops.has(s)){stops.get(s)();stops.delete(s);}return Box({flexDirection:'column',children:[Text({children:['Release timeline '+props.name]}),Text({children:[props.pointer?'Drag to review the release window':'Timeline is read-only']}),Text({children:[s.state.last]})]});}`;
 const clock=`export default function(props,s){if(s.state===undefined){s.setState({started:true});s.every(100,()=>s.post({timelineClock:true}));}return s.elements.Text({children:['Release window']});}`;
 const files={'hooks/register.ts':source,'hooks/timeline.ts':module,'hooks/clock.ts':clock};for(const[name,text]of Object.entries(files))await writeFile(join(plugin,name),text);
 const hashes=Object.fromEntries(Object.entries(files).map(([name,text])=>[name,createHash('sha256').update(text).digest('hex')]));
 assert.ok((await readFile(join(plugin,'hooks/timeline.ts'),'utf8')).includes('s.onPointer'));
 return{hashes};
}
