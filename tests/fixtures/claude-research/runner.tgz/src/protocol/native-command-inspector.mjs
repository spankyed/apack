/** Observe original command module calls inside the pinned executable; recovered files are never loaded. */
export function nativeCommandInspector(outputPath) {
  return `
{
 const {writeFileSync,readFileSync}=await import('node:fs');
 const {createHash}=await import('node:crypto');
 if(createHash('sha256').update(readFileSync(process.execPath)).digest('hex')==='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37'){
  const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),globals=await import('/$bunfs/root/chunk-hdxpvbx1.js');
  const events=[],installed=new WeakSet(),modules=new WeakMap();let lastOutputs;
  const save=()=>{try{writeFileSync(${JSON.stringify(outputPath)},JSON.stringify(events),{mode:0o600});}catch{}};
  const wrap=(module,command)=>{
   if(!module||typeof module.call!=='function')return module;
   if(modules.has(module))return modules.get(module);
   const descriptor=Object.getOwnPropertyDescriptor(module,'call');
   if(descriptor&&!descriptor.configurable&&descriptor.writable===false)return module;
   const original=module.call;let proxy;
   const call=function(...args){
    if(events.length>=8)return Reflect.apply(original,this===proxy?module:this,args);
    const entry={command,startedAt:Date.now(),sessionIdBefore:String(globals.q()),commandMessageUuid:args[1]?.commandMessageUuid};events.push(entry);save();
    const context=args[1],query= context&&Object.getOwnPropertyDescriptor(context,'onQueryEvent');let restoreQuery=()=>{};
    if(query?.writable&&typeof query.value==='function'){
     const originalQuery=query.value,observe=function(event,...rest){if(event?.type==='conversation_reset'){entry.queryEvents??=[];entry.queryEvents.push({type:event.type,newConversationId:event.newConversationId});save();}return Reflect.apply(originalQuery,this,[event,...rest]);};
     context.onQueryEvent=observe;restoreQuery=()=>{if(context.onQueryEvent===observe)Object.defineProperty(context,'onQueryEvent',query);};
    }

    const returned=value=>{restoreQuery();entry.returnedAt=Date.now();entry.sessionIdAfter=String(globals.q());entry.resultType=value?.type;entry.resultKeys=value&&typeof value==='object'?Object.keys(value):[];entry.compactionKeys=value?.compactionResult?Object.keys(value.compactionResult):undefined;entry.boundaries=Object.entries(value?.compactionResult??{}).filter(([,item])=>item&&typeof item==='object'&&item.type==='system'&&item.subtype==='compact_boundary').map(([key,item])=>({key,uuid:item.uuid,trigger:item.compactMetadata?.trigger}));save();return value;};
    const failed=error=>{restoreQuery();entry.failedAt=Date.now();entry.sessionIdAfter=String(globals.q());entry.errorName=error?.name??typeof error;save();throw error;};
    try{const result=Reflect.apply(original,this===proxy?module:this,args);return result&&typeof result.then==='function'?result.then(returned,failed):returned(result);}catch(error){return failed(error);}
   };
   proxy=new Proxy(module,{get(target,key,receiver){return key==='call'?call:Reflect.get(target,key,receiver);}});modules.set(module,proxy);return proxy;
  };
  const timer=setInterval(()=>{try{const binding=runtime.ey();if(binding?.surface!=='terminal')return;const outputs=binding.messages().filter(row=>row.subtype==='local_command');const snapshot=JSON.stringify(outputs.slice(-8));if(snapshot!==lastOutputs){lastOutputs=snapshot;writeFileSync(${JSON.stringify(outputPath+'.outputs.json')},snapshot,{mode:0o600});}for(const command of binding.commands()){
   if(!['compact','clear'].includes(command.name)||installed.has(command))continue;
   const descriptor=Object.getOwnPropertyDescriptor(command,'load');if(!descriptor?.writable||typeof descriptor.value!=='function')continue;
   const original=descriptor.value;
   command.load=function(...args){const result=Reflect.apply(original,this,args);return result&&typeof result.then==='function'?result.then(module=>wrap(module,command.name)):wrap(result,command.name);};installed.add(command);
  }}catch{}},100);timer.unref();
 }
}
`;
}
