import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {recognizeOnboardingPrompt} from './pty-onboarding.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {record} from './record.mjs';
import {hash} from '../artifacts/runs.mjs';

/** Original marketplace registration only; never install the recommendation candidate or alter eligibility. */
export async function prepareLspRecommendation(executable,parent,output){
 assert.equal(process.platform,'linux','Original CLI probes run only in the owned Linux container');
 const targetSha256=hash(await readFile(executable));
 assert.equal(targetSha256,'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10','Pinned target required');
 await mkdir(parent,{recursive:true});
 const workspace=await mkdtemp(join(resolve(parent),'lsp-recommendation-'));
 const marketplace=join(workspace,'marketplace'),plugin=join(marketplace,'plugins/recommendation-review');
 await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});
 await mkdir(join(plugin,'.claude-plugin'),{recursive:true});
 const lspServers={review:{command:process.execPath,args:['--version'],extensionToLanguage:{'.txt':'typescript'}}};
 await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:'owned-recommendation',owner:{name:'Private research'},plugins:[{name:'recommendation-review',source:'./plugins/recommendation-review',description:'Owned LSP recommendation admission fixture',lspServers}]}));
 await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'recommendation-review',version:'1.0.0',description:'Owned recommendation fixture',lspServers}));
 await writeFile(join(workspace,'release.recommendationreview'),'export const release = "2.1.302";\n');
 const env={PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
 const result=await record({executable:resolve(executable),cwd:workspace,output,env,args:['--setting-sources','','plugin','marketplace','add',marketplace],timeoutMs:20000,maxBytes:1024*1024});
 const stdout=await readFile(join(result.directory,'stdout.bin'),'utf8'),stderr=await readFile(join(result.directory,'stderr.bin'),'utf8');
 const evidence={workspace,marketplace,pluginId:'recommendation-review@owned-recommendation',candidateInstallation:'not requested; installed state not independently inspected',targetSha256,run:result,stdout,stderr,scope:'Original local marketplace registration only. Matching file is not yet tracked; recommendation eligibility, choices, installation and actual app delivery are unverified. The node --version candidate is not a working LSP server and must not be used as LSP integration acceptance.'};
 await writeFile(join(result.directory,'lsp-recommendation-registration.json'),JSON.stringify(evidence,null,2)+'\n');
 assert.equal(result.code,0,'Original marketplace registration refused; inspect preserved evidence');
 assert.equal(result.reason,undefined);
 return evidence;
}

/** Exercise original file tracking and recommendation admission with one local Edit turn. */
export async function probeLspRecommendation(executable,parent,output){
 const registration=await prepareLspRecommendation(executable,parent,output);
 const {workspace}=registration;
 await writeFile(join(workspace,'fixture.txt'),'before\n');
 const model=await startSyntheticModel(workspace,'Edit',{maxRequests:6,captureMessages:true});
 const bridge=fileURLToPath(new URL('./pty_bridge.py',import.meta.url));
 let terminal='',theme=false,security=false,navigated=false,trusted=false,sent=false,declined=false,transport,exitKeys=0,completedAt;
 const timers=[];
 const poll=setInterval(()=>{
  if(!transport||!sent||exitKeys)return;
  if(declined&&model.calls.length>=3&&terminal.includes('Fixture completed.')){
   completedAt??=Date.now();
   if(Date.now()-completedAt>2500){exitKeys++;transport.send('\x04');timers.push(setTimeout(()=>{if(exitKeys===1){exitKeys++;transport.send('\x04');}},600));}
  }
 },100);
 let run;
 try{
  run=await record({executable:'/usr/bin/python3',cwd:workspace,output,timeoutMs:45000,maxBytes:2*1024*1024,
   args:[bridge,resolve(executable),'--setting-sources','user','--strict-mcp-config','--tools','Read,Edit','--permission-mode','acceptEdits','--debug-file',join(workspace,'native-debug.log'),'--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})],
   env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),TERM:'xterm-256color',COLUMNS:'100',LINES:'30',ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
   onStdout(bytes,channel){
    transport=channel;terminal+=bytes.toString('utf8');
    const screen=recognizeOnboardingPrompt(terminal,workspace),compact=terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');
    let input;
    if(screen==='theme'&&!theme){theme=true;input='\r';}
    else if(screen==='security-notes'&&theme&&!security){security=true;input='\r';}
    else if(screen==='workspace-trust'&&!navigated){navigated=true;input='\x1b[B';}
    else if(screen==='workspace-trust-selected'&&!trusted){trusted=true;input='\r';}
    else if(trusted&&!sent&&compact.includes('shift+tabtocycle')){sent=true;input='Review the owned fixture only.\r';}
    else if(sent&&!declined&&compact.includes('Fixturecompleted.')&&compact.lastIndexOf('LSPpluginrecommendation')>compact.lastIndexOf('Fixturecompleted.')&&compact.includes('DisableallLSPrecommendations')){declined=true;input='\x1b';}
    else if(exitKeys===1&&/pressctrl[+-]dagaintoexit/i.test(compact)){exitKeys++;input='\x04';}
    if(input!==undefined)timers.push(setTimeout(()=>channel.send(input),180));
   }});
  const edited=await readFile(join(workspace,'fixture.txt'),'utf8');
  const nativeLog=(await readFile(join(workspace,'native-debug.log'),'utf8')).split('\n').filter(line=>line.includes('[lspRecommendation]')||line.includes('[useLspPluginRecommendation]'));
  const nativeResponse=nativeLog.map(line=>line.match(/User response: (\w+) for recommendation-review/)?.[1]).find(Boolean);
  const evidence={registration:registration.run.directory,workspace,run,sent,declined,nativeResponse,nativeLog,exitKeys,edited,modelRequests:model.calls.length,realModelRequests:0,driverSha256:hash(await readFile(new URL(import.meta.url))),bridgeSha256:hash(await readFile(bridge)),targetSha256:registration.targetSha256,scope:'Original PTY tracked-file recommendation and Escape/defer only; no app delivery, install, persistence or other choice acceptance.'};
  await writeFile(join(run.directory,'lsp-recommendation.json'),JSON.stringify(evidence,null,2)+'\n');
  await writeFile(join(run.directory,'synthetic-calls.json'),JSON.stringify(model.calls,null,2)+'\n');
  assert.equal(run.status,'complete','Original journey failed; inspect preserved PTY output');
  assert.equal(edited,'after\n','Native Edit must actually complete');
  assert.equal(declined,true,'Original recommendation was not observed');
  assert.equal(nativeResponse,'no','Escape must resolve the original defer result, not time out');
  return evidence;
 }finally{clearInterval(poll);for(const timer of timers)clearTimeout(timer);await model.close();}
}

/** Registers a working candidate in an already-owned app workspace; original CLI owns registration. */
export async function addLspRecommendationAppFixture(executable,workspace,output){
 assert.equal(process.platform,'linux');
 const {addNativeLspFixture}=await import('./native-lsp-fixture.mjs');
 const marketplace=join(workspace,'recommendation-marketplace'),plugin=join(marketplace,'plugins/recommendation-review');
 await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'.claude-plugin'),{recursive:true});
 await mkdir(join(plugin,'hooks'),{recursive:true});
 await addNativeLspFixture(workspace,plugin);
 const lspServers=JSON.parse(await readFile(join(plugin,'.lsp.json'),'utf8'));lspServers.review.extensionToLanguage['.txt']='typescript';
 await writeFile(join(plugin,'.lsp.json'),JSON.stringify(lspServers));
 await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'recommendation-review',version:'1.0.0'}));
 await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:'owned-recommendation',owner:{name:'Private research'},plugins:[{name:'recommendation-review',source:'./plugins/recommendation-review',description:'Code intelligence for release review files',lspServers}]}));
 await writeFile(join(workspace,'fixture.txt'),'before\n');
 const registration=await record({executable,cwd:workspace,output,env:{PATH:process.env.PATH,HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},args:['--setting-sources','','plugin','marketplace','add',marketplace],timeoutMs:20000,maxBytes:1024*1024});
 assert.equal(registration.status,'complete');
 await writeFile(join(workspace,'native-lsp-recommendation-fixture.json'),JSON.stringify({registration,pluginId:'recommendation-review@owned-recommendation',marketplace,workingServer:true}));
}

export async function verifyLspRecommendationApp(workspace,calls,evidence,decision){
 assert.equal(evidence.nativeLspRecommendation,true);assert.equal(evidence.resumedPrintSameSession,true);
 assert.equal(await readFile(join(workspace,'fixture.txt'),'utf8'),'after\n');
 const nativeLog=(await readFile(join(workspace,'native-debug.log'),'utf8')).split('\n').filter(line=>line.includes('[useLspPluginRecommendation]')||line.includes('[lspRecommendation]'));
 const responses=nativeLog.flatMap(line=>line.match(/User response: (\w+) for recommendation-review/)?.[1]??[]);
 assert.deepEqual(responses,[decision]);assert.ok(calls.length>=3&&calls.length<=6);
 const global=JSON.parse(await readFile(join(workspace,'.claude/.claude.json'),'utf8'));
 const settings=JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8'));
 const pluginId='recommendation-review@owned-recommendation';
 if(decision==='never')assert.ok(global.lspRecommendationNeverPlugins?.includes(pluginId));
 if(decision==='disable')assert.equal(global.lspRecommendationDisabled,true);
 if(decision==='timeout')assert.equal(global.lspRecommendationIgnoredCount,1);
 if(decision==='yes'){assert.equal(settings.enabledPlugins?.[pluginId],true);assert.ok(nativeLog.some(line=>line.includes('Plugin installed: '+pluginId)));}
 const persisted={neverPlugins:global.lspRecommendationNeverPlugins??[],disabled:global.lspRecommendationDisabled??false,ignoredCount:global.lspRecommendationIgnoredCount??0,enabled:settings.enabledPlugins?.[pluginId]??false};
 const proof={decision,nativeLog,persisted,scope:'Actual-app recommendation and exact native result; independent policy/owner/window variants and full F1–F5 remain open.'};
 await writeFile(join(workspace,'native-lsp-recommendation-verified.json'),JSON.stringify(proof,null,2)+'\n');return proof;
}
