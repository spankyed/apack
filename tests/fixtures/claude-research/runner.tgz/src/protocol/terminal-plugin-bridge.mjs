import { installNativeStatusPrefix } from './native-status-prefix.mjs';
import assert from 'node:assert/strict';
import http from 'node:http';
import { randomBytes } from 'node:crypto';
import { mkdir, mkdtemp, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { hash } from '../artifacts/runs.mjs';

/** Private, bounded prompt-control experiment; the native plugin retains API admission and policy. */
export async function startTerminalPluginBridge(workspace, { approvals = false, tasks = false, observeNarration = false, observeUiEngine = false, statusCommands } = {}) {
  const directory = await mkdtemp('/private/tmp/cc-native-');
  const socketPath = join(directory, 'bridge.sock'), token = randomBytes(24).toString('hex');
  const pluginRoot = join(workspace, 'terminal-bridge-plugin');
  await mkdir(join(pluginRoot, '.claude-plugin'), { recursive: true }); await mkdir(join(pluginRoot, 'hooks'));
  let sessionId, sequence = 0, pending, closed = false;
  const evidence = [], permissionEvidence = [], agentEvidence = [], nativeStatusEvidence = [];
  const server = http.createServer(async (req, res) => {
    const reply = (code, value) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(value)); };
    try {
      if (req.method !== 'POST' || req.headers['x-research-token'] !== token) return reply(403, { deny: 'Private fixture only' });
      let bytes = 0, text = '';
      for await (const chunk of req) { bytes += chunk.length; if (bytes > (req.url === '/native-status' ? 32768 : 16384)) return reply(413, {}); text += chunk; }
      const body = JSON.parse(text);
      if (typeof body.sessionId !== 'string' || !/^[a-f0-9-]{36}$/.test(body.sessionId)) return reply(400, {});
      if (sessionId && sessionId !== body.sessionId) return reply(409, { deny: 'Foreign native session' });
      sessionId ??= body.sessionId;
      if (req.url === '/native-status' && statusCommands) {
        if (!['main','subagent'].includes(body.kind) || typeof body.stdout !== 'string' || Buffer.byteLength(body.stdout) > 8192 || typeof body.truncated !== 'boolean' || (body.code !== null && !Number.isInteger(body.code))) return reply(400, {});
        nativeStatusEvidence.push({ ...body, at: Date.now() });
        return reply(200, { received: true });
      }
      if (req.url === '/permission' && approvals) {
        const index = permissionEvidence.length + 1;
        if (body.tool !== 'Bash' || body.id !== `toolu_research_fixture_${index}` || index > 2 || body.nativeVerdict?.decision !== 'ask') return reply(409, { deny: 'Unknown native ask' });
        const decision = index === 1 ? 'allow' : 'deny';
        permissionEvidence.push({ ...body, decision });
        return reply(200, { id: body.id, sessionId, decision });
      }
      if (req.url === '/poll') {
        if (tasks) {
          if (!Array.isArray(body.agents)) return reply(400, { deny: 'Missing native agents' });
          const previous = agentEvidence.at(-1);
          if (!previous || JSON.stringify(previous.agents) !== JSON.stringify(body.agents)) agentEvidence.push({ sessionId, at: Date.now(), agents: body.agents });
        }
        if (!pending || pending.sent) return reply(200, {});
        pending.sent = true; return reply(200, pending.command);
      }
      if (req.url !== '/result' || !pending || body.id !== pending.command.id || !pending.sent) return reply(409, { deny: 'Retired command' });
      const current = pending; pending = undefined; clearTimeout(current.timer);
      evidence.push({ sessionId, ...current.command, result: body.result, error: body.error });
      if (body.error) current.reject(Error(body.error)); else current.resolve(body.result);
      reply(200, {});
    } catch (error) { if (!res.headersSent) reply(400, { deny: error.message }); else res.destroy(); }
  });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(socketPath, resolve); });
  const statusPrefix = statusCommands ? await installNativeStatusPrefix(workspace, { socketPath, token, commands: statusCommands }) : undefined;
  const pluginSource = `export function register(on) {
    let busy=false,started=false,frames={},nativeUiClicks=0;
    ${observeUiEngine ? `on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{const {Box,Text,Button}=$.ui.resolve(e);return Box({children:[Text({children:['NativeTerminalUi '+nativeUiClicks]}),Button({key:'native-engine-button',label:'Native engine fixture',onPress:async()=>{nativeUiClicks++;await $.fs.write('native-engine-clicks.json',JSON.stringify({clicks:nativeUiClicks}));$.ui.invalidate('ui.render');}}),await next(e)]});});` : ''}
    ${observeNarration ? `on('ui.render',{component:'AssistantMessage'},async($,e,next)=>{frames[e.requestId+':'+(e.props.isSummary?'summary':'text')]={id:e.requestId,...e.props};await $.fs.write('terminal-message-frames.json',JSON.stringify(Object.values(frames)));return next(e);});` : ''}
    ${approvals ? `on('tool.check',{tool:'Bash'},async($,e,next)=>{
      const verdict=await next(e);if(verdict.decision!=='ask'||!e.tool_use_id)return verdict;
      const sessionId=await $.session.id();
      const response=await $.http.fetch('http://research/permission',{method:'POST',socketPath:${JSON.stringify(socketPath)},headers:{'x-research-token':${JSON.stringify(token)},'content-type':'application/json'},body:JSON.stringify({sessionId,id:e.tool_use_id,tool:e.tool,input:e.input,agentId:e.agentId,nativeVerdict:verdict})});
      if(!response.ok)return{decision:'deny',reason:'Owned research bridge refused'};
      const answer=JSON.parse(response.text);if(answer.id!==e.tool_use_id||answer.sessionId!==sessionId||!['allow','deny'].includes(answer.decision))return{decision:'deny',reason:'Uncorrelated research reply'};
      return{decision:answer.decision,reason:'Disposable fixture delegated '+answer.decision};
    }).catch(()=>({decision:'deny',reason:'Owned research bridge unavailable'}));` : ''}

    on('session.start', async ($,e,next)=>{
      if(!started){started=true;$.clock.every(150,()=>{if(busy)return;busy=true;(async()=>{
        const sessionId=await $.session.id();
        const send=async(path,body)=>{const r=await $.http.fetch('http://research'+path,{method:'POST',socketPath:${JSON.stringify(socketPath)},headers:{'x-research-token':${JSON.stringify(token)},'content-type':'application/json'},body:JSON.stringify({sessionId,...body})});if(!r.ok)throw Error('Bridge HTTP '+r.status);return JSON.parse(r.text);};
        const command=await send('/poll',${tasks ? '{agents:await $.agent.list()}' : '{}'});if(!command.id)return;
        let result,error;try{if(command.kind==='read')result=await $.prompt.read();else if(command.kind==='fill')result=await $.prompt.fill({text:command.text,mode:'replace'});else throw Error('Unknown fixture command');}catch(e){error=String(e);}
        await send('/result',{id:command.id,result,error});
      })().catch(async e=>{await $.fs.write('terminal-bridge-error.txt',String(e));}).finally(()=>{busy=false;});});}
      return next(e);
    });
  }`;
  await writeFile(join(pluginRoot, '.claude-plugin/plugin.json'), JSON.stringify({ name: 'research-terminal-bridge', version: '0.0.1' }));
  await writeFile(join(pluginRoot, 'hooks/hooks.json'), JSON.stringify({ modules: ['./register.ts'] }));
  await writeFile(join(pluginRoot, 'hooks/register.ts'), pluginSource);
  function command(kind, text) {
    assert.ok(!closed && !pending, 'One owned command may be in flight');
    return new Promise((resolve, reject) => {
      const id = `fixture-${++sequence}`;
      const timer = setTimeout(() => { if (pending?.command.id === id) pending = undefined; reject(Error(`Native ${kind} bridge timed out`)); }, 5000);
      pending = { command: { id, kind, ...(text === undefined ? {} : { text }) }, resolve, reject, timer, sent: false };
    });
  }
  return { pluginRoot, statusPrefix, nativeStatusEvidence, pluginSourceSha256: hash(Buffer.from(pluginSource)), evidence, permissionEvidence, agentEvidence,
    async preparePrompt(text) {
      const before = await command('read'); assert.equal(before.text, '');
      const filled = await command('fill', text); assert.equal(filled.isFilled, true);
      const after = await command('read'); assert.equal(after.text, text); return { before, filled, after };
    },
    async close() {
      closed = true;
      if (pending) { clearTimeout(pending.timer); pending.reject(Error('Owned terminal bridge closed')); pending = undefined; }
      server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
      await writeFile(join(workspace, 'terminal-bridge-evidence.json'), JSON.stringify({ sessionId, pluginSourceSha256: hash(Buffer.from(pluginSource)), commands: evidence, permissions: permissionEvidence, agents: agentEvidence, nativeStatus: nativeStatusEvidence }, null, 2) + '\n');
    }
  };
}
