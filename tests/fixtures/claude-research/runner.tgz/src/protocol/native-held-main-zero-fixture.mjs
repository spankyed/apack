import assert from 'node:assert/strict';
import {join} from 'node:path';

/** One original managed status command; its owned process survives TERM until a bounded release. */
export function makeHeldMainZeroFixture(workspace){
 assert.match(workspace,/^\/work\/\.claude-research\/policy-zero-app[0-9]+$/);
 const paths=Object.fromEntries(['arm','claimed','release','started','finished','state','calls'].map(name=>[name,join(workspace,'held-status-'+name+(name==='calls'?'.jsonl':name==='started'||name==='finished'||name==='state'?'.json':''))]));
 const helper=join(workspace,'held-status.py'),command="trap '' TERM; exec /usr/bin/python3 '"+helper+"'";
 const source=`import json,os,pathlib,re,signal,sys,time
ROOT=pathlib.Path(${JSON.stringify(workspace)})
PATHS=json.loads(${JSON.stringify(JSON.stringify(paths))})
def atomic(name,value):
 p=pathlib.Path(PATHS[name]);temp=p.with_name(p.name+'.'+str(os.getpid())+'.tmp');temp.write_text(json.dumps(value));temp.replace(p)
def start(pid):
 raw=pathlib.Path('/proc/'+str(pid)+'/stat').read_text();return raw[raw.rfind(')')+2:].split()[19]
raw=sys.stdin.read(1048577)
if len(raw.encode())>1048576:sys.exit(8)
p=json.loads(raw)
if not re.fullmatch('[a-fA-F0-9-]{36}',p.get('session_id','')) or not all(k in p for k in ['version','cost','context_window']) or 'hook_event_name' in p:sys.exit(8)
if os.environ.get('CLAUDE_CODE_SHELL_PREFIX'):sys.exit(13)
identity={'pid':os.getpid(),'parentPid':os.getppid(),'start':start(os.getpid()),'parentStart':start(os.getppid()),'sessionId':p['session_id'],'prefixAbsent':True}
held=False
try:pathlib.Path(PATHS['arm']).rename(PATHS['claimed']);held=True
except FileNotFoundError:pass
if held:
 signal.signal(signal.SIGTERM,signal.SIG_IGN)
 atomic('started',identity)
 deadline=time.monotonic()+12
 while not pathlib.Path(PATHS['release']).exists() and time.monotonic()<deadline:time.sleep(.02)
 if not pathlib.Path(PATHS['release']).exists():sys.exit(9)
 text='STALE_HELD_HELPER'
else:
 state=json.loads(pathlib.Path(PATHS['state']).read_text())
 if state.get('phase') not in ['allowed','restricted','restored']:sys.exit(8)
 text={'allowed':'Release status ready','restricted':'Managed release status ready','restored':'Release status restored'}[state['phase']]
print(text,flush=True)
record={**identity,'held':held,'printed':text}
log=pathlib.Path(PATHS['calls'])
if log.exists() and log.stat().st_size>1048576:sys.exit(9)
with log.open('a') as f:f.write(json.dumps(record)+'\\n')
if held:atomic('finished',record)
`;
 const policy=allowManagedHooksOnly=>({allowManagedHooksOnly,statusLine:{type:'command',command,refreshInterval:1}});
 return {workspace,helper,command,source,paths,allowedPolicy:policy(false),restrictedPolicy:policy(true),requiresNoShellPrefix:true,heldDeadlineSeconds:12,scope:'Original no-prefix Linux status-helper late zero-exit policy case. No native gate, cancellation, timeout or signal delivery is overridden; the configured owned helper ignores TERM. Prefix-specific cancelled-wrapper evidence stays separate.'};
}
