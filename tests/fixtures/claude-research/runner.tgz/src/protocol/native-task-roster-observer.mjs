import {isAbsolute,join} from 'node:path';
/** Bounded read-only original task identities; never mutate or retain task authority. */
export function nativeTaskRosterObserver(workspace){
 if(!isAbsolute(workspace))throw Error('Task observation requires an owned absolute workspace');
 return `{
 const {writeFileSync}=await import('node:fs');const rows=[];let busy=false,last;const deadline=Date.now()+190000;
 const timer=setInterval(()=>{if(Date.now()>deadline||rows.length>=128){clearInterval(timer);return}if(busy)return;busy=true;(async()=>{
  const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),binding=runtime.ey();if(binding?.surface!=='terminal'||typeof binding.toolContext!=='function')return;
  const context=binding.toolContext(new AbortController()),all=context.taskRegistry.all();
  const tasks=Object.entries(all).slice(0,256).map(([key,task])=>({key,type:task.type,status:task.status,agentId:task.agentId,teammateAgentId:task.identity?.resumableAgentId??task.identity?.agentId}));
  const value={selected:context.getAppState().viewingAgentTaskId,tasks},key=JSON.stringify(value);if(key===last)return;last=key;rows.push({at:Date.now(),pid:process.pid,...value});
  writeFileSync(${JSON.stringify(join(workspace,'native-task-roster-observations.json'))},JSON.stringify(rows),{mode:0o600});
 })().catch(error=>{if(rows.length<128){rows.push({at:Date.now(),error:String(error).slice(0,1000)});writeFileSync(${JSON.stringify(join(workspace,'native-task-roster-observations.json'))},JSON.stringify(rows),{mode:0o600})}}).finally(()=>{busy=false})},100);timer.unref();
}\n`;
}
