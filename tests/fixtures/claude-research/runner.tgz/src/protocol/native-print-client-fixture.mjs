import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** Desktop-only original Client, so print acquisition is distinguishable from terminal handoff. */
export async function addNativePrintClientFixture(plugin) {
  await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){
    on('ui.render',{component:'AbovePrompt'},($,e,next)=>{if(e.surface!=='desktop')return next(e);const {Client}=$.ui.resolve(e);return Client({key:'workspace-status',module:'./print-status.ts',props:{label:'Workspace connected'},width:48,height:14});});
    let writes=Promise.resolve();const receipts=[];
    on('ui.message',async($,e,next)=>{if(e.data?.printClient!==true)return next(e);if(e.data.key)await $.fs.write('native-print-client-key.json',JSON.stringify({...e.data,surface:e.surface,component:e.component,requestId:e.requestId}));receipts.push({...e.data,surface:e.surface,component:e.component,requestId:e.requestId});receipts.splice(0,Math.max(0,receipts.length-64));const snapshot=JSON.stringify(receipts);writes=writes.then(()=>$.fs.write('native-print-client-receipts.json',snapshot));await writes;return e.data.key?{props:{label:'Workspace synchronized'}}:next(e);});
    on('ui.input',($,e,next)=>next(e.value==='rewrite'?{...e,value:'Release notes'}:e));
  }`);
  await writeFile(join(plugin,'hooks/print-status.ts'),`export default function(props,s){
    const {Box,Text,Button,Input,Select}=s.elements;
    if(s.state===undefined){s.setState({count:0,key:'none',note:'',choice:'a',ticks:0});s.every(300,()=>{s.setState({...s.state,ticks:s.state.ticks+1});s.post({printClient:true,count:s.state.count,columns:s.columns,rows:s.rows,ticks:s.state.ticks,...(s.state.key==='none'?{}:{key:s.state.key})});});}
    s.onKey(e=>{s.setState({...s.state,key:e.key});s.post({printClient:true,key:e.key});});
    return Box({flexDirection:'column',children:[Text({children:[props.label+' · '+s.state.count+' updates']}),Text({children:['Key '+s.state.key+' · Refresh '+s.state.ticks]}),Button({key:'refresh',label:'Refresh workspace',onPress:()=>s.setState({...s.state,count:s.state.count+1})}),Input({key:'note',label:'Review note',value:s.state.note,onInput:note=>s.setState({...s.state,note}),onSubmit:note=>s.setState({...s.state,note})}),Select({key:'scope',label:'Review scope',value:s.state.choice,options:[{value:'a',label:'Current changes'},{value:'b',label:'Release changes'}],onSelect:choice=>s.setState({...s.state,choice})})]});
  }`);
}
