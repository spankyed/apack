import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Reconcile direct Settings command UI evidence with original native and read-only app receipts. */
export async function verifyNativeSettingsRoutes(root){
 const json=async path=>JSON.parse(await readFile(path,'utf8'));
 const names=await readdir(join(root,'workspaces'));assert.equal(names.length,1);const workspace=join(root,'workspaces',names[0]);
 const lines=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').map(JSON.parse);
 const proof=await json(join(workspace,'native-settings-routes-proof.json')),evidence=await json(join(workspace,'native-terminal-app-evidence.json'));
 for(const key of ['desktopPanels','editorRetained','modelCostUnchangedDuringRoutes','sameSessionRecovery'])assert.equal(proof[key],true);
 assert.equal(evidence.actualAppGui,true);assert.equal(evidence.nativeSettingsRoutes,true);assert.equal(evidence.sessionId,proof.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.deepEqual(proof.routes.map(row=>[row.command,row.tab]),[['status','Status'],['usage','Usage'],['cost','Usage'],['stats','Stats']]);
 assert.equal(proof.captures.length,8);assert.equal(new Set(proof.captures).size,8);
 for(const file of proof.captures){assert.match(file,/^native-settings-route-(status|usage|cost|stats)-(1100|680)\.png$/);assert.ok((await readFile(join(root,'captures',file))).length>1000)}
 assert.ok(proof.routes[0].text.includes('2.1.302'));assert.ok(proof.routes[0].text.includes(proof.sessionId));
 for(const row of proof.routes){assert.equal(row.after.sessionId,proof.sessionId);assert.equal(row.after.native.state.nativePid,proof.boundNativePid);assert.equal(row.after.claude.totalCostUsd,proof.baseline.claude.totalCostUsd);assert.equal(row.after.turns,proof.baseline.turns)}
 assert.equal(proof.afterRoutes.turns,proof.baseline.turns);assert.equal(proof.afterRoutes.claude.totalCostUsd,proof.baseline.claude.totalCostUsd);
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),prints=await lines('native-print-results.jsonl');assert.equal(children.length,3);assert.equal(exits.length,3);assert.equal(children[1].pid,proof.boundNativePid);
 for(const child of children){const exit=exits.find(row=>row.pid===child.pid);assert.ok(exit);assert.ok([0,143].includes(exit.code));assert.ok(exit.at>=child.at)}
 assert.ok(exits.find(row=>row.pid===children[0].pid).at<=children[1].at);assert.ok(exits.find(row=>row.pid===children[1].pid).at<=children[2].at);
 assert.equal(prints.length,2);assert.ok(prints.every(row=>row.sessionId===proof.sessionId));
 let native;for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{native=(await readFile(join(workspace,'.claude/projects',bucket,proof.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}assert.ok(native);
 const humans=native.filter(row=>row.type==='user'&&row.isMeta!==true&&row.isVirtual!==true&&typeof row.message?.content==='string');
 assert.deepEqual(humans.map(row=>row.message.content),['Review the release notes for this project.','Continue the release review after checking Status and Usage.']);
 assert.equal(new Set(humans.map(row=>row.uuid)).size,2);
 const cost=native.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,prints.at(-1).totalCostUsd);assert.equal(cost,proof.final.claude.totalCostUsd);
 const app=await json(join(root,'app-query.stdout')),threads=app.threads.filter(row=>row.claude?.sessionId===proof.sessionId);assert.equal(threads.length,1);assert.equal(threads[0].claude.totalCostUsd,cost);assert.equal(threads[0].claude.turns,2);assert.equal(threads[0].claude.chatState,'success');
 for(const row of humans){const matches=app.messages.filter(message=>message.sender==='user'&&message.context?.cliUuid===row.uuid);assert.equal(matches.length,1);assert.equal(matches[0].text,row.message.content)}
 const calls=await json(join(workspace,'model-calls.json'));assert.equal(calls.agent.length,0);assert.equal(calls.seed.filter(row=>row.path==='/v1/messages?beta=true').length,2);
 assert.deepEqual(await json(join(root,'compiled-after.json')),await json(join(root,'compiled-before.json')));
 const boundary=await json(join(root,'offline-boundary.json'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);assert.equal(boundary.memory,6*1024**3);assert.equal(boundary.memorySwap,boundary.memory);assert.equal(boundary.nanoCpus,2*10**9);assert.deepEqual(Object.keys(boundary.networks),['none']);
 return {mainDesktopRoutes:true,costAndStatsAliases:true,noExtraHumanOrModelTurn:true,editorRetained:true,sameSessionRecovery:true,exactAppNativeHistory:true,appNativePrintCost:cost,ownedNativeExits:3,screenshots:8};
}

/** Verify selected-Agent direct routes, including original human history and final app accounting. */
export async function verifyNativeAgentSettingsRoutes(root){
 const json=async path=>JSON.parse(await readFile(path,'utf8'));
 const [name,...extra]=await readdir(join(root,'workspaces'));assert.ok(name);assert.equal(extra.length,0);
 const workspace=join(root,'workspaces',name),proof=await json(join(workspace,'native-agent-settings-routes-proof.json'));
 const evidence=await json(join(workspace,'native-terminal-app-evidence.json'));
 assert.equal(evidence.nativeAgentSettingsRoutes,true);assert.equal(evidence.sessionId,proof.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.deepEqual(proof.routes.map(row=>[row.command,row.tab]),[['status','Status'],['usage','Usage'],['cost','Usage'],['stats','Stats']]);
 assert.equal(proof.originalView.kind,'agent');assert.equal(proof.originalView.taskId,proof.taskId);
 for(const row of proof.routes)assert.deepEqual(row.view,proof.originalView);
 assert.equal(proof.before.turns,proof.after.turns);assert.equal(proof.before.claude.totalCostUsd,proof.after.claude.totalCostUsd);
 assert.equal(proof.after.native.state.nativePid,proof.boundNativePid);assert.equal(proof.captures.length,8);assert.equal(new Set(proof.captures).size,8);
 const files=await readdir(join(workspace,'electron-results'),{recursive:true});
 for(const file of proof.captures){const matches=files.filter(path=>path.endsWith('/'+file));assert.equal(matches.length,1);assert.ok((await readFile(join(workspace,'electron-results',matches[0]))).length>1000)}
 const lines=async file=>(await readFile(join(workspace,file),'utf8')).trim().split('\n').map(JSON.parse);
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),prints=await lines('native-print-results.jsonl');
 assert.equal(children.length,3);assert.equal(exits.length,3);assert.equal(children[1].pid,proof.boundNativePid);
 for(const child of children){const exit=exits.find(row=>row.pid===child.pid);assert.ok(exit);assert.ok([0,143].includes(exit.code));assert.ok(exit.at>=child.at)}
 assert.equal(prints.length,2);assert.ok(prints.every(row=>row.sessionId===proof.sessionId));
 const journals=await readdir(join(workspace,'.claude/projects'),{recursive:true});
 const parent=journals.find(file=>file.endsWith('/'+proof.sessionId+'.jsonl'));assert.ok(parent);
 const rows=(await readFile(join(workspace,'.claude/projects',parent),'utf8')).trim().split('\n').map(JSON.parse);
 const humans=rows.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&typeof row.message?.content==='string'&&(!row.origin||row.origin.kind==='human'));
 assert.deepEqual(humans.map(row=>row.message.content),['Review the release notes for this project.','Review the release notes with a worker.','Continue after checking worker Status and Usage.']);
 const cost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,prints.at(-1).totalCostUsd);
 const worker=journals.find(file=>file.endsWith('/agent-'+proof.taskId+'.jsonl'));assert.ok(worker);
 const workerRows=(await readFile(join(workspace,'.claude/projects',worker),'utf8')).trim().split('\n').map(JSON.parse);
 assert.equal(workerRows.filter(row=>row.type==='user'&&row.isMeta===true&&row.origin?.kind==='human').length,0);
 const app=await json(join(root,'app-query.stdout')),threads=app.threads.filter(row=>row.claude?.sessionId===proof.sessionId);assert.equal(threads.length,1);assert.equal(threads[0].claude.totalCostUsd,cost);assert.equal(threads[0].claude.chatState,'success');
 for(const row of humans){const matches=app.messages.filter(message=>message.sender==='user'&&message.context?.cliUuid===row.uuid);assert.equal(matches.length,1);assert.equal(matches[0].text,row.message.content)}
 const calls=await json(join(workspace,'model-calls.json'));assert.equal(calls.seed.filter(row=>row.path==='/v1/messages?beta=true').length,2);assert.equal(calls.agent.length,4);assert.equal(calls.agent.filter(row=>row.child&&row.delivered).length,1);
 assert.deepEqual(await json(join(root,'compiled-before.json')),await json(join(root,'compiled-after.json')));
 const boundary=await json(join(root,'offline-boundary.json'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);assert.equal(boundary.memory,6*1024**3);assert.equal(boundary.memorySwap,boundary.memory);assert.equal(boundary.nanoCpus,2*10**9);assert.deepEqual(Object.keys(boundary.networks),['none']);
 return {selectedAgentRoutes:true,originalOwnerRetained:true,noWorkerHumanTurn:true,exactParentHumanHistory:true,appNativePrintCost:cost,ownedNativeExits:3,screenshots:8};
}
