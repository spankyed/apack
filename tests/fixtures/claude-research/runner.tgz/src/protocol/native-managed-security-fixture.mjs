import assert from 'node:assert/strict';
import {readFile,mkdir} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import {join,isAbsolute,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {createServer} from 'node:https';
import {prepareNativeCreditTls} from './native-credit-billing.mjs';
import {record} from './record.mjs';
import {recognizeOnboardingPrompt} from './pty-onboarding.mjs';

export const MANAGED_SECURITY_KEY='sk-ant-api03-owned-policy-fixture-key0001';
const pinnedBinary='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10';
const digest=value=>createHash('sha256').update(value).digest('hex');

/** Original first-party acquisition and consent; bootstrap admits the key through native terminal input. */
export async function prepareNativeManagedSecurity(workspace,executable,{port=443}={}){
 assert.equal(process.platform,'linux','Original native probes require the inspected Linux container');
 assert.ok(isAbsolute(workspace)&&basename(workspace).startsWith('apack-terminal-owner-app-'));
 assert.equal(digest(await readFile(executable)),pinnedBinary);
 const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
 assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);
 const hosts=await readFile('/etc/hosts','utf8');
 assert.ok(hosts.split('\n').some(line=>{const [ip,...names]=line.trim().split(/\s+/);return ip==='127.0.0.1'&&names.includes('api.anthropic.com')}));
 const tls=await prepareNativeCreditTls(join(workspace,'managed-security-tls'));
 const settings={statusLine:{type:'command',command:'/usr/bin/printf ManagedPolicyTrustRequired'}};
 const state={phase:'bootstrap',requests:[],settings,bootstrapActions:[],bootstrapKeyApproved:false};
 const server=createServer({key:await readFile(tls.key),cert:await readFile(tls.cert)},(req,res)=>{
  const path=new URL(req.url,'https://api.anthropic.com').pathname;
  if(state.requests.length>=200){res.writeHead(429);res.end();return;}
  state.requests.push({path,method:req.method,phase:state.phase,syntheticKey:req.headers['x-api-key']===MANAGED_SECURITY_KEY});
  const reply=(status,value)=>{res.writeHead(status,{'content-type':'application/json'});res.end(JSON.stringify(value));};
  if(path==='/api/claude_code/settings'&&req.method==='GET'){
   if(req.headers['x-api-key']!==MANAGED_SECURITY_KEY)return reply(401,{error:'Owned key required'});
   if(state.phase==='bootstrap'){res.writeHead(204);res.end();return;}
   return reply(200,{uuid:'11111111-1111-4111-8111-111111111111',checksum:digest(JSON.stringify(settings)),settings});
  }
  if(req.method==='HEAD'&&path==='/api/hello')return reply(200,{ok:true});
  reply(404,{error:'No additional capability in this owned fixture'});
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve)});
 const close=()=>new Promise(resolve=>{server.closeAllConnections();server.close(resolve)});
 const env={HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),ANTHROPIC_API_KEY:MANAGED_SECURITY_KEY,ANTHROPIC_BASE_URL:'https://api.anthropic.com',NODE_EXTRA_CA_CERTS:tls.ca,DISABLE_AUTOUPDATER:'1',TERM:'xterm-256color',COLUMNS:'100',LINES:'30',PATH:'/usr/bin:/bin'};
 let terminal='',transportRef,approvedTimer;const timers=[];
 try{
  await mkdir(join(workspace,'managed-security-bootstrap'),{recursive:true});
  const bootstrap=await record({executable:'/usr/bin/python3',args:[new URL('./pty_bridge.py',import.meta.url).pathname,executable],cwd:workspace,output:join(workspace,'managed-security-bootstrap'),timeoutMs:35000,maxBytes:2*1024*1024,env,onStdout(bytes,transport){
   transportRef=transport;terminal+=bytes.toString('utf8');
   const stage=recognizeOnboardingPrompt(terminal,state.bootstrapActions.includes('workspace-trust-selected')?undefined:workspace,{apiKeySuffix:MANAGED_SECURITY_KEY.slice(-20)});
   if(stage&&!state.bootstrapActions.includes(stage)){
    state.bootstrapActions.push(stage);
    timers.push(setTimeout(()=>transport.send(stage==='workspace-trust'?'\x1b[B':stage==='environment-api-key'?'\x1b[A':'\r'),200));
   }
   approvedTimer??=setInterval(()=>{try{const config=JSON.parse(readFileSync(join(workspace,'.claude/.claude.json'),'utf8'));if(config.customApiKeyResponses?.approved?.includes(MANAGED_SECURITY_KEY.slice(-20))){state.bootstrapKeyApproved=true;transportRef.stop('original-synthetic-api-key-approved');clearInterval(approvedTimer);}}catch{}},100);
  }});
  assert.equal(state.bootstrapKeyApproved,true,'Native key approval was not completed; do not synthesize consent');
  assert.equal(state.requests.some(row=>row.path.startsWith('/v1/messages')),false);
  state.phase='review';
  return {env,tls,state,bootstrap,close};
 }catch(error){await close();throw error;}finally{for(const timer of timers)clearTimeout(timer);clearInterval(approvedTimer);}
}
