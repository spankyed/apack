import { access, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { record } from './record.mjs';
import { hash } from '../artifacts/runs.mjs';
import {prepareNativeDocumentMediaFixture} from './native-document-media-fixture.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

/** Explicit Linux-only original-process probe; private policy discovery, never an app upload proof. */
export async function probeDocumentMedia(executable, workspace, output, { sourceRefusals = false } = {}) {
  if (process.platform !== 'linux') throw Error('Native document probe belongs in the owned Linux container');
  await access('/.dockerenv');
  if (hash(await readFile(executable)) !== '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10') throw Error('Document probe requires the pinned Linux2.1.302 executable');
  const {cwd,ordinary,preload,content,managedSourceSha256}=await prepareNativeDocumentMediaFixture(workspace,{sourceRefusals});
  const model = await startSyntheticModel(cwd, 'TextOnly');
  let pending = '', result, initialization;
  const unexpected = [];
  try {
    const run = await record({ executable, cwd, output, timeoutMs: 30000,
      args: ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json', '--setting-sources', '', '--strict-mcp-config', '--plugin-dir', ordinary, '--tools', '', '--max-turns', '1', '--permission-prompt-tool', 'stdio', '--no-session-persistence', '--settings', JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' })],
      env: { PATH: process.env.PATH, HOME: cwd, CLAUDE_CONFIG_DIR: join(cwd, '.claude'), BUN_OPTIONS: '--preload=' + preload, ANTHROPIC_BASE_URL: model.url, DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
      input: [JSON.stringify({ type: 'control_request', request_id: 'document-initialize', request: { subtype: 'initialize', hooks: {} } }) + '\n'],
      onStdout(bytes, transport) {
        pending += bytes.toString('utf8');
        while (pending.includes('\n')) {
          const at = pending.indexOf('\n'), line = pending.slice(0, at); pending = pending.slice(at + 1);
          let value; try { value = JSON.parse(line); } catch { continue; }
          if (value.type === 'control_response' && value.response?.request_id === 'document-initialize') {
            initialization = value.response;
            transport.send(JSON.stringify({ type: 'user', message: { role: 'user', content }, parent_tool_use_id: null }) + '\n');
          } else if (value.type === 'control_request') {
            unexpected.push(value.request?.subtype);
            transport.send(JSON.stringify({ type: 'control_response', response: { subtype: 'error', request_id: value.request_id, error: 'No reverse capabilities in owned document probe' } }) + '\n');
          } else if (value.type === 'result') { result = value; transport.closeInput(); }
        }
      } });
    const receipt = async name => { try { return JSON.parse(await readFile(join(cwd, name), 'utf8')); } catch (error) { if (error.code === 'ENOENT') return null; throw error; } };
    const observations = { managed: await receipt('managed-documents.json'), ordinary: await receipt('ordinary-documents.json'), settled: await receipt('settled-documents.json') };
    const evidence = { status: 'unverified', sourceRefusals, targetSha256: hash(await readFile(executable)), driverSha256: hash(await readFile(new URL(import.meta.url))), managedSourceSha256, input: content, initialization, result, observations, unexpected, calls: model.calls, realModelRequests: 0,
      qualification: 'Raw original-process evidence only. Exact byte/result schema, managed admission and ordinary refusal require inspection before acceptance. URL/file/nested-source cases remain separate; settled lifetime receipts require independent inspection; no app UI or OS policy acceptance.' };
    await writeFile(join(run.directory, 'document-media.json'), JSON.stringify(evidence, null, 2) + '\n');
    return { ...run, verified: false, evidence: join(run.directory, 'document-media.json') };
  } finally { await model.close(); }
}
