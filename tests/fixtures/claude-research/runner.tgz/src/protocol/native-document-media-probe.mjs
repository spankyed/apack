import { access, mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { record } from './record.mjs';
import { hash } from '../artifacts/runs.mjs';
import { nativeManagedFiles } from './native-managed-files.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

/** Explicit Linux-only original-process probe; private policy discovery, never an app upload proof. */
export async function probeDocumentMedia(executable, workspace, output, { sourceRefusals = false } = {}) {
  if (process.platform !== 'linux') throw Error('Native document probe belongs in the owned Linux container');
  await access('/.dockerenv');
  if (hash(await readFile(executable)) !== '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10') throw Error('Document probe requires the pinned Linux2.1.302 executable');
  await mkdir(workspace, { recursive: true });
  const cwd = await mkdtemp(join(workspace, 'document-media-'));
  const marketplace = join(cwd, 'marketplace'), managed = join(marketplace, 'plugins/document-media');
  const ordinary = join(cwd, 'ordinary'), policy = join(cwd, 'policy'), preload = join(cwd, 'preload.mjs');
  for (const path of [join(marketplace, '.claude-plugin'), policy, ...[managed, ordinary].flatMap(p => [join(p, '.claude-plugin'), join(p, 'hooks')])]) await mkdir(path, { recursive: true });
  await writeFile(join(marketplace, '.claude-plugin/marketplace.json'), JSON.stringify({ name: 'document-research', owner: { name: 'Private research' }, plugins: [{ name: 'document-media', source: './plugins/document-media' }] }));
  await writeFile(join(policy, 'managed-settings.json'), JSON.stringify({ extraKnownMarketplaces: { 'document-research': { source: { source: 'directory', path: marketplace } } }, enabledPlugins: { 'document-media@document-research': true } }));
  await writeFile(preload, nativeManagedFiles({ directory: policy, receipt: join(cwd, 'policy-reads.jsonl'), platform: 'linux' }));
  const source = (isManaged) => `export function register(on){on('prompt.submit',async($,e,next)=>{
    const rows=[];for(const item of e.attachments??[]){if(item.type==='document')rows.push({id:item.id,result:await $.prompt.media({id:item.id})});}
    if(!rows.length)return next(e);
    const unlisted=await $.prompt.media({id:'unlisted_document_fixture'});
    await $.fs.write(${JSON.stringify(isManaged ? 'managed-documents.json' : 'ordinary-documents.json')},JSON.stringify({rows,unlisted}));
    return next(e);
  });${isManaged ? `on('turn.complete',async($,e,next)=>{const receipt=JSON.parse(await $.fs.read('managed-documents.json'));const rows=[];for(const item of receipt.rows)rows.push({id:item.id,result:await $.prompt.media({id:item.id})});await $.fs.write('settled-documents.json',JSON.stringify({rows}));return next(e);});` : ''}}`;
  for (const [path, isManaged] of [[managed, true], [ordinary, false]]) {
    await writeFile(join(path, '.claude-plugin/plugin.json'), JSON.stringify({ name: isManaged ? 'document-media' : 'ordinary-document-media', version: '0.0.1' }));
    await writeFile(join(path, 'hooks/hooks.json'), JSON.stringify({ modules: ['./register.ts'] }));
    await writeFile(join(path, 'hooks/register.ts'), source(isManaged));
  }
  const text = 'Document byte fixture: café\n第二行\n';
  const content = [{ type: 'text', text: 'Acknowledge the owned document fixture without tools.' },
    { type: 'document', source: { type: 'text', media_type: 'text/plain', data: text } },
    { type: 'document', source: { type: 'base64', media_type: 'text/plain', data: Buffer.from(text).toString('base64') } }];
  if (sourceRefusals) content.push(
    { type: 'document', source: { type: 'url', url: 'http://127.0.0.1:9/owned-document-missing' } },
    { type: 'document', source: { type: 'file', file_id: 'owned-document-missing' } },
    { type: 'document', source: { type: 'content', content: [{ type: 'text', text: 'Nested owned document fixture' }] } });
  const model = await startSyntheticModel(cwd, 'TextOnly');
  let pending = '', result, initialization;
  const unexpected = [];
  try {
    const run = await record({ executable, cwd, output, timeoutMs: 30000,
      args: ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json', '--setting-sources', '', '--strict-mcp-config', '--plugin-dir', ordinary, '--tools', '', '--max-turns', '1', '--permission-prompt-tool', 'stdio', '--no-session-persistence', '--settings', JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' })],
      env: { PATH: process.env.PATH, HOME: cwd, CLAUDE_CONFIG_DIR: join(cwd, '.claude'), BUN_OPTIONS: '--preload=' + preload, ANTHROPIC_BASE_URL: model.url, DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
      input: [JSON.stringify({ type: 'control_request', request_id: 'document-initialize', request: { subtype: 'initialize', hooks: {} } }) + '\n'],
      onStdout(bytes, transport) {
        pending += bytes.toString('utf8');
        while (pending.includes('\n')) {
          const at = pending.indexOf('\n'), line = pending.slice(0, at); pending = pending.slice(at + 1);
          let value; try { value = JSON.parse(line); } catch { continue; }
          if (value.type === 'control_response' && value.response?.request_id === 'document-initialize') {
            initialization = value.response;
            transport.send(JSON.stringify({ type: 'user', message: { role: 'user', content }, parent_tool_use_id: null }) + '\n');
          } else if (value.type === 'control_request') {
            unexpected.push(value.request?.subtype);
            transport.send(JSON.stringify({ type: 'control_response', response: { subtype: 'error', request_id: value.request_id, error: 'No reverse capabilities in owned document probe' } }) + '\n');
          } else if (value.type === 'result') { result = value; transport.closeInput(); }
        }
      } });
    const receipt = async name => { try { return JSON.parse(await readFile(join(cwd, name), 'utf8')); } catch (error) { if (error.code === 'ENOENT') return null; throw error; } };
    const observations = { managed: await receipt('managed-documents.json'), ordinary: await receipt('ordinary-documents.json'), settled: await receipt('settled-documents.json') };
    const evidence = { status: 'unverified', sourceRefusals, targetSha256: hash(await readFile(executable)), driverSha256: hash(await readFile(new URL(import.meta.url))), managedSourceSha256: hash(Buffer.from(source(true))), input: content, initialization, result, observations, unexpected, calls: model.calls, realModelRequests: 0,
      qualification: 'Raw original-process evidence only. Exact byte/result schema, managed admission and ordinary refusal require inspection before acceptance. URL/file/nested-source cases remain separate; settled lifetime receipts require independent inspection; no app UI or OS policy acceptance.' };
    await writeFile(join(run.directory, 'document-media.json'), JSON.stringify(evidence, null, 2) + '\n');
    return { ...run, verified: false, evidence: join(run.directory, 'document-media.json') };
  } finally { await model.close(); }
}
