import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** No prompt, model call, credentials, hooks, plugins or MCP servers; only inert settings markers. */
export async function probeSettingsPrecedence(executable,root,output){
  await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'settings-precedence-'));
  const home=join(workspace,'home'),cwd=join(workspace,'project');
  await mkdir(join(home,'.claude'),{recursive:true});await mkdir(join(cwd,'.claude'),{recursive:true});
  execFileSync('/usr/bin/git',['init','-q',cwd]);
  const layer=(label,allow)=>({language:`research-${label}`,env:{CLAUDE_RESEARCH_COMMON:label,[`CLAUDE_RESEARCH_${label.toUpperCase()}`]:label},permissions:{allow:allow==='Read'?['Read']:[allow,'Read']}});
  await writeFile(join(home,'.claude','settings.json'),JSON.stringify(layer('user','Read')));
  await writeFile(join(cwd,'.claude','settings.json'),JSON.stringify(layer('project','Glob')));
  await writeFile(join(cwd,'.claude','settings.local.json'),JSON.stringify(layer('local','Grep')));
  const recipes=[{sources:'',expected:null},{sources:'user',expected:'user'},{sources:'user,project',expected:'project'},{sources:'user,project,local',expected:'local'},{sources:'user,project,local',expected:'inline',inline:{...layer('inline','Edit'),model:'sonnet'}},{sources:'user,project,local',expected:'inline',inline:{...layer('inline','Edit'),model:'sonnet'},model:'haiku'}];
  const cases=[];
  const aggregate=await createRun(output,'settings-precedence',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url)))});
  try {
  for(const recipe of recipes){
    let buffered='',reply;
    const request=(request_id,request)=>JSON.stringify({type:'control_request',request_id,request})+'\n';
    const args=['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources',recipe.sources,'--strict-mcp-config','--tools','','--no-session-persistence',...(recipe.inline?['--settings',JSON.stringify(recipe.inline)]:[]),...(recipe.model?['--model',recipe.model]:[])];
    const run=await record({executable,cwd,output,args,timeoutMs:15000,env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[request('settings-init',{subtype:'initialize',hooks:{}})],onStdout(bytes,transport){
      buffered+=bytes.toString('utf8');
      while(buffered.includes('\n')){
        const at=buffered.indexOf('\n'),line=buffered.slice(0,at);buffered=buffered.slice(at+1);
        let event;try{event=JSON.parse(line)}catch{continue}
        if(event.type!=='control_response')continue;
        if(event.response.request_id==='settings-init')transport.send(request('settings-read',{subtype:'get_settings'}));
        else if(event.response.request_id==='settings-read'){reply=event.response;transport.closeInput()}
      }
    }});
    assert.equal(run.status,'complete');assert.equal(reply?.subtype,'success');
    const response=reply.response;
    const labels=recipe.sources?recipe.sources.split(','):[];
    if(recipe.inline)labels.push('inline');
    assert.equal(response.effective.language,recipe.expected?`research-${recipe.expected}`:undefined);
    const expectedEnv=Object.assign({},...labels.map(label=>layer(label,'Read').env));
    assert.deepEqual(response.effective.env??{},expectedEnv);
    const rules={user:'Read',project:'Glob',local:'Grep',inline:'Edit'};
    assert.deepEqual(response.effective.permissions?.allow??[],labels.map(label=>rules[label]));
    if(recipe.inline){assert.equal(response.effective.model,'sonnet');assert.match(response.applied.model,recipe.model?/^claude-haiku-/:/^claude-sonnet-/)}
    cases.push({modelOverride:recipe.model??null,sources:recipe.sources,inline:!!recipe.inline,expected:recipe.expected,response,run:run.directory});
  }
  const result={workspace,cases,modelRequests:0,qualification:'Local user/project/local/inline sources only; managed/account/provider precedence and actual sandbox enforcement are not exercised.'};
  await writeFile(join(aggregate.directory,'settings-precedence.json'),JSON.stringify(result,null,2)+'\n');
  await aggregate.finish({status:'complete',cases:cases.length});
  return {directory:aggregate.directory,status:'complete',...result};
  } catch(error) {await aggregate.finish({status:'failed',error:error.message});throw error}
}
