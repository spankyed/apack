import {createInterface} from 'node:readline';
import {appendFileSync} from 'node:fs';
const [capture,mode='form']=process.argv.slice(2);
if(!['form','form-rich','url'].includes(mode))throw Error('Unsupported fixture mode');
if(!capture)throw Error('Private capture path required');
const richSchema={type:'object',properties:{name:{type:'string',minLength:2,maxLength:12,default:'Fixture'},enabled:{type:'boolean',default:false},count:{type:'integer',minimum:0,maximum:5,default:0},ratio:{type:'number',minimum:0,maximum:1,default:0.5},email:{type:'string',format:'email',default:'fixture@example.com'},uri:{type:'string',format:'uri',default:'https://example.invalid'},date:{type:'string',format:'date',default:'2026-10-16'},time:{type:'string',format:'date-time',default:'2026-10-16T14:30:00Z'},legacy:{type:'string',enum:['a','b'],enumNames:['Alpha','Beta'],default:'b'},titled:{type:'string',oneOf:[{const:'x',title:'Ex'}],default:'x'},tags:{type:'array',minItems:1,maxItems:2,items:{type:'string',enum:['one','two']},default:['one']},titledTags:{type:'array',items:{anyOf:[{const:'x',title:'Ex'}]},default:['x']},optional:{type:'string'}},required:['name','enabled','count','ratio','email','uri','date','time','legacy','titled','tags','titledTags']};
const send=value=>process.stdout.write(JSON.stringify({jsonrpc:'2.0',...value})+'\n');
let pendingTool;
createInterface({input:process.stdin}).on('line',line=>{
 let value;try{value=JSON.parse(line)}catch{return}
 appendFileSync(capture,JSON.stringify(value)+'\n');
 if(value.id==='fixture-elicitation'){
  if(pendingTool!==undefined)send({id:pendingTool,result:{content:[{type:'text',text:JSON.stringify({elicitation:value.result??{error:value.error}})}]}});
  pendingTool=undefined;return;
 }
 if(value.id===undefined)return;
 switch(value.method){
  case 'initialize':send({id:value.id,result:{protocolVersion:value.params.protocolVersion,capabilities:{tools:{}},serverInfo:{name:'research-elicitation',version:'1.0.0'}}});return;
  case 'ping':send({id:value.id,result:{}});return;
  case 'tools/list':send({id:value.id,result:{tools:[{name:'echo',description:'Private fixture requiring one structured user answer',inputSchema:{type:'object',properties:{message:{type:'string'}},required:['message']}}]}});return;
  case 'tools/call':
   if(value.params.name!=='echo')break;
   pendingTool=value.id;send({id:'fixture-elicitation',method:'elicitation/create',params:{mode:mode==='form-rich'?'form':mode,message:'Select the private synthetic fixture.',...(mode!=='url'?{requestedSchema:mode==='form-rich'?richSchema:{type:'object',properties:{choice:{type:'string',title:'Fixture',enum:['Alpha','Beta']}},required:['choice']}}:{url:'https://example.invalid/research-elicitation',elicitationId:'research-url-fixture'}),_meta:{'anthropic/permissionDisplay':{title:'Synthetic fixture answer',displayName:'Private elicitation',description:'No external service or account'}}}});return;
 }
 send({id:value.id,error:{code:-32601,message:'Unsupported synthetic operation'}});
});
