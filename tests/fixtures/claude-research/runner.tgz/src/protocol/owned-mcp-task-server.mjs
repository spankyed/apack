import {createInterface} from 'node:readline';
import {appendFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';

/** Owned modern task producer; never changes the native client's admission gates. */
export function createOwnedMcpTaskServer() {
 const tasks=new Map();let sequence=0,requests=0;
 const complete=extra=>({resultType:'complete',...extra});
 const refuse=message=>({error:{code:-32602,message}});
 return request=>{
  if(++requests>64)return refuse('Owned request budget exhausted');
  const {method,params={}}=request;
  const meta=params._meta;
  if(meta?.['io.modelcontextprotocol/protocolVersion']!=='2026-07-28'||typeof meta?.['io.modelcontextprotocol/clientCapabilities']!=='object')return refuse('Original modern protocol envelope required');
  if(method==='server/discover')return {result:complete({supportedVersions:['2026-07-28'],capabilities:{tools:{}},ttlMs:0,cacheScope:'private'})};
  if(method==='tools/list')return {result:complete({ttlMs:0,cacheScope:'private',tools:[{name:'review',description:'Owned task admission and lifetime fixture',inputSchema:{type:'object',properties:{scenario:{enum:['complete','input','held']}},required:['scenario']}}]})};
  if(method==='tools/call'){
   const scenario=params.arguments?.scenario;
   if(params.name!=='review'||!['complete','input','held'].includes(scenario)||tasks.size>=8)return refuse('Invalid owned tool call or task budget');
   const taskId='owned-review-'+ ++sequence;
   tasks.set(taskId,{scenario,status:'working',polls:0});
   return {result:{resultType:'task',taskId,status:'working',statusMessage:'Owned review queued',pollIntervalMs:250,ttlMs:15000}};
  }
  if(!['tasks/get','tasks/update','tasks/cancel'].includes(method))return {error:{code:-32601,message:'Unsupported owned method'}};
  const task=tasks.get(params.taskId);if(!task)return refuse('Unknown owned task');
  if(method==='tasks/cancel'){if(!['completed','cancelled'].includes(task.status))task.status='cancelled';return {result:complete({})};}
  if(method==='tasks/update'){
   if(task.status!=='input_required'||Object.keys(params.inputResponses??{}).length!==1)return refuse('Task is not awaiting this answer');
   const answer=params.inputResponses['review-input'];
   if(!answer||!['accept','decline','cancel'].includes(answer.action))return refuse('Unknown owned input response');
   task.answer=answer;task.status=answer.action==='accept'?'completed':'cancelled';return {result:complete({})};
  }
  task.polls++;
  if(task.status==='working'&&task.scenario!=='held'&&task.polls>1)task.status=task.scenario==='input'?'input_required':'completed';
  return {result:{taskId:params.taskId,status:task.status,pollIntervalMs:250,ttlMs:15000,
   ...(task.status==='input_required'?{inputRequests:{'review-input':{method:'elicitation/create',params:{mode:'form',message:'Confirm the owned task review.',requestedSchema:{type:'object',properties:{confirmed:{type:'boolean'}},required:['confirmed']}}}}}:{}),
   ...(task.status==='completed'?{result:complete({content:[{type:'text',text:JSON.stringify({review:'complete',...(task.answer?{answer:task.answer}:{})})}]})}:{})}};
 };
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const handle=createOwnedMcpTaskServer(),receipt=process.env.APACK_MCP_TASK_RECEIPT;
 if(!receipt)throw Error('Explicit owned task receipt path required');
 const input=createInterface({input:process.stdin});let bytes=0;
 input.on('line',line=>{
  bytes+=Buffer.byteLength(line);if(bytes>1048576){input.close();process.stdin.destroy();process.exitCode=1;return;}
  let request;try{request=JSON.parse(line);}catch{return;}
  appendFileSync(receipt,JSON.stringify({direction:'in',value:request})+'\n');
  if(request.id===undefined)return;
  const reply={jsonrpc:'2.0',id:request.id,...handle(request)};
  appendFileSync(receipt,JSON.stringify({direction:'out',value:reply})+'\n');process.stdout.write(JSON.stringify(reply)+'\n');
 });
}
