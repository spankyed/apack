import assert from 'node:assert/strict';
import {isAbsolute} from 'node:path';
import {createHash} from 'node:crypto';
import {createNativeTestImage} from './native-test-image.mjs';

/** Observe only the original input-preparation helpers; never submit a turn or alter a native gate. */
export function nativeAgentMediaPreparationObserver(output,hashes){
 assert.ok(isAbsolute(output));
 for(const name of ['ufe','Mc','QA','L$e','hse'])assert.match(hashes[name]?.sha256??'',/^[a-f0-9]{64}$/);
 const image=createNativeTestImage().toString('base64');
 return `{
 const {readFileSync,writeFileSync}=await import('node:fs'),{createHash}=await import('node:crypto');
 const sha=value=>createHash('sha256').update(value).digest('hex');
 if(process.platform!=='linux'||process.getuid()!==1000||sha(readFileSync(process.execPath))!=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10')throw Error('Pinned ordinary-user Linux observer required');
 const expected=${JSON.stringify(hashes)};let attempts=0,busy=false,last;
 const timer=setInterval(async()=>{if(busy)return;busy=true;try{
  if(++attempts>160){clearInterval(timer);writeFileSync(${JSON.stringify(output+'.error')},JSON.stringify({attempts,error:last}));return;}
  const input=await import('/$bunfs/root/chunk-m86ay9q5.js'),api=await import('/$bunfs/root/chunk-a7b8k0bt.js');
  const functions={ufe:input.ufe,Mc:input.Mc,QA:api.QA,L$e:api.L$e,hse:api.hse};
  for(const[name,fn]of Object.entries(functions))if(typeof fn!=='function'||sha(Function.prototype.toString.call(fn))!==expected[name].sha256)throw Error('Original Agent preparation helper changed: '+name);
  const tagged=api.QA(),prepare=(text,pasted)=>input.ufe(text,pasted,tagged?api.L$e:undefined,tagged?api.hse:undefined);
  const image=${JSON.stringify(image)},text='Review café\\n第二行';
  const pasted={1:{id:1,type:'image',content:image,mediaType:'image/png',filename:'review.png'},2:{id:2,type:'text',content:text}};
  const cases=[{name:'plain',text:'Review this project',pasted:{}},{name:'image',text:'Inspect [Image #1].',pasted:{1:pasted[1]}},{name:'text-and-image',text:'Review [Pasted text #2 +2 lines] alongside [Image #1].',pasted},{name:'unreferenced-image',text:'Review this project',pasted:{1:pasted[1]}}].map(item=>({...item,matches:input.Mc(item.text),output:prepare(item.text,item.pasted)}));
  clearInterval(timer);writeFileSync(${JSON.stringify(output)},JSON.stringify({pid:process.pid,uid:process.getuid(),platform:process.platform,binarySha256:sha(readFileSync(process.execPath)),functionHashes:expected,tagged,cases,imageSha256:sha(Buffer.from(image,'base64')),expectedText:text,modelTurns:0,scope:'Original native preparation helper outputs only. No live Agent submission, downstream model delivery, app attachment UI, source/gate modification or inferred upload support.'}));
 }catch(error){last=String(error);}finally{busy=false;}},50);timer.unref();
}`;
}

/** The prepared Agent input is text; image bytes are not materialized at this specific boundary. */
export function verifyNativeAgentMediaPreparation(receipt,expectedHashes){
 for(const name of ['ufe','Mc','QA','L$e','hse'])assert.deepEqual(receipt.functionHashes[name],expectedHashes[name],name);
 const imageBytes=createNativeTestImage(),imageData=imageBytes.toString('base64');assert.equal(receipt.imageSha256,createHash('sha256').update(imageBytes).digest('hex'));
 assert.equal(receipt.platform,'linux');assert.equal(receipt.uid,1000);assert.equal(receipt.binarySha256,'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');assert.equal(receipt.modelTurns,0);
 assert.deepEqual(receipt.cases.map(row=>row.name),['plain','image','text-and-image','unreferenced-image']);
 const [plain,image,mixed,unused]=receipt.cases;assert.equal(plain.output,plain.text);assert.equal(unused.output,plain.text);
 assert.equal(image.output,image.text);assert.ok(mixed.output.includes(receipt.expectedText));assert.ok(mixed.output.includes('[Image #1]'));assert.ok(!mixed.output.includes('[Pasted text'));
 assert.deepEqual(image.matches.map(row=>row.id),[1]);assert.deepEqual(mixed.matches.map(row=>row.id),[2,1]);
 for(const row of receipt.cases){assert.equal(typeof row.output,'string');for(const value of Object.values(row.pasted))if(value.type==='image'){assert.equal(value.content,imageData);assert.equal(value.mediaType,'image/png');assert.ok(!row.output.includes(value.content));}}
 return {verified:true,preparedInputType:'string',pastedTextExpanded:true,imageMarkerRetained:true,imageBytesNotMaterialized:true,cases:receipt.cases.length,modelTurns:0,scope:receipt.scope};
}
