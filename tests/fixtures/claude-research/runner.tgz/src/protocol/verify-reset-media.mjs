import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Correlate queued-media reset observations with the replacement's original native journal. */
export async function verifyResetMedia(workspace){
 const proof=JSON.parse(await readFile(join(workspace,'native-reset-task-proof.json'),'utf8'));
 for(const key of ['pendingMediaAttached','pendingMediaCleared','pendingMediaExcludedFromReplacement'])assert.equal(proof[key],true);
 assert.notEqual(proof.sessionId,proof.finalSessionId);
 const projects=join(workspace,'.claude/projects');let rows;
 for(const bucket of await readdir(projects)){
  try{rows=(await readFile(join(projects,bucket,proof.finalSessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break;}
  catch(error){if(error.code!=='ENOENT')throw error;}
 }
 assert.ok(rows,'Replacement original native journal must exist');
 const humans=rows.filter(row=>row.type==='user'&&row.isMeta!==true&&row.isVirtual!==true);
 assert.deepEqual(humans.map(row=>row.uuid),[proof.newHumanUuid,proof.followUpHumanUuid]);
 for(const row of humans){assert.equal(row.sessionId,proof.finalSessionId);assert.equal(typeof row.message.content,'string');assert.ok(!row.message.content.includes('native-app-image.png'));assert.ok(!row.message.content.includes(proof.sessionId));assert.ok(!row.message.content.includes(proof.taskId));}
 assert.ok(humans[0].message.content.endsWith('Latest user message:\n'+proof.newHumanText));
 assert.equal(humans[1].message.content,proof.followUpText);
 assert.equal(humans[0].parentUuid,null);
 return{pendingFileImageRetired:true,replacementHumanRows:2,replacementImageBlocks:0,oldSessionAndTaskExcluded:true};
}
