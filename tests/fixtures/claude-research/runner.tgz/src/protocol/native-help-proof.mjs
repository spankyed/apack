import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Reconcile desktop Help evidence with original native journals and the owned app database. */
export async function verifyNativeHelpDesktop(root,{agent=false,fullReading=false,links=false}={}){
 if(links)assert.equal(agent,false,'Agent Help links need their own acceptance journey');
 const json=async file=>JSON.parse(await readFile(file,'utf8'));
 const names=await readdir(join(root,'workspaces'));assert.equal(names.length,1);const workspace=join(root,'workspaces',names[0]);
 const lines=async file=>(await readFile(join(workspace,file),'utf8')).trim().split('\n').map(JSON.parse);
 const proof=await json(join(workspace,links?'native-help-links-proof.json':agent?'native-agent-help-proof.json':'native-help-proof.json')),evidence=await json(join(workspace,'native-terminal-app-evidence.json'));
 assert.equal(evidence.actualAppGui,true);assert.equal(links?evidence.nativeHelpLinks:evidence.nativeHelpDesktop,true);if(agent)assert.equal(evidence.nativeAgentHelpDesktop,true);
 assert.equal(evidence.sessionId,proof.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);
 if(!links){
 assert.deepEqual(proof.samples.map(row=>[row.tab,row.width]),[['General',1100],['General',680],['Commands',1100],['Commands',680],['Custom commands',1100],['Custom commands',680]]);
 assert.ok(proof.samples.filter(row=>row.tab==='General').every(row=>/shift \+ tab.*auto-accept edits/.test(row.text)));
 assert.ok(proof.samples.filter(row=>row.tab==='Commands').every(row=>row.text.includes('/help')));
 }else{
  assert.equal(proof.url,'https://code.claude.com/docs/en/overview');assert.deepEqual(proof.activations.map(row=>[row.width,row.activation]),[[1100,'primary'],[1100,'modified'],[1100,'middle'],[680,'primary'],[680,'modified'],[680,'middle']]);for(const row of proof.activations)assert.equal(row.after,row.before+1);assert.equal(proof.requests.length,6);assert.ok(proof.requests.every(url=>url===proof.url));
 }
 if(fullReading){
  assert.deepEqual(proof.readings.map(row=>[row.tab,row.width]),proof.samples.map(row=>[row.tab,row.width]));
  for(const reading of proof.readings){assert.equal(reading.realWheel,true);assert.equal(reading.atBottom,true);assert.ok(reading.rows.length>0);for(const row of reading.rows){assert.equal(typeof row.text,'string');assert.ok(row.height>=0);assert.ok(row.covered>=row.height-1)}}
  for(const sample of proof.samples.filter(row=>row.tab==='Custom commands')){assert.ok(sample.text.includes('/review-release'));assert.ok(sample.text.includes('Review the release checklist and report remaining risks.'))}
 }
 assert.equal(proof.captures.length,links?2:6);assert.equal(new Set(proof.captures).size,links?2:6);
 const pictures=await readdir(join(workspace,'electron-results'),{recursive:true});
 for(const file of proof.captures){const matches=pictures.filter(path=>path.endsWith('/'+file));assert.equal(matches.length,1);const bytes=await readFile(join(workspace,'electron-results',matches[0]));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),file.endsWith('-680.png')?680:1100);assert.equal(bytes.readUInt32BE(20),file.endsWith('-680.png')?600:900)}
 if(!links){
 assert.equal(proof.after.turns,proof.baseline.turns);assert.equal(proof.after.claude.totalCostUsd,proof.baseline.claude.totalCostUsd);assert.equal(proof.after.native.state.nativePid,proof.boundNativePid);assert.equal(proof.final.sessionId,proof.sessionId);
 }
 if(agent){assert.equal(proof.originalView.kind,'agent');assert.equal(proof.originalView.taskId,proof.taskId);assert.deepEqual(proof.after.native.state.view,proof.originalView)}
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),prints=await lines('native-print-results.jsonl');assert.equal(children.length,3);assert.equal(exits.length,3);assert.equal(children[1].pid,proof.boundNativePid);
 for(const child of children){const exit=exits.find(row=>row.pid===child.pid);assert.ok(exit);assert.ok([0,143].includes(exit.code));assert.ok(exit.at>=child.at)}
 assert.equal(prints.length,2);assert.ok(prints.every(row=>row.sessionId===proof.sessionId));
 const journals=await readdir(join(workspace,'.claude/projects'),{recursive:true}),parent=journals.find(file=>file.endsWith('/'+proof.sessionId+'.jsonl'));assert.ok(parent);
 const rows=(await readFile(join(workspace,'.claude/projects',parent),'utf8')).trim().split('\n').map(JSON.parse);
 const humans=rows.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&typeof row.message?.content==='string'&&(!row.origin||row.origin.kind==='human'));
 assert.deepEqual(humans.map(row=>row.message.content),['Review the release notes for this project.',...(agent?['Review the release notes with a worker.']:[]),links?'Continue the release review after opening Help documentation.':agent?'Continue the release review after reading worker Help.':'Continue the release review after reading Help.']);
 if(agent){const worker=journals.find(file=>file.endsWith('/agent-'+proof.taskId+'.jsonl'));assert.ok(worker);const rows=(await readFile(join(workspace,'.claude/projects',worker),'utf8')).trim().split('\n').map(JSON.parse);assert.equal(rows.filter(row=>row.type==='user'&&row.isMeta===true&&row.origin?.kind==='human').length,0)}
 const cost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,prints.at(-1).totalCostUsd);assert.equal(cost,proof.final.claude.totalCostUsd);
 const app=await json(join(root,'app-query.stdout')),threads=app.threads.filter(row=>row.claude?.sessionId===proof.sessionId);assert.equal(threads.length,1);assert.equal(threads[0].claude.totalCostUsd,cost);assert.equal(threads[0].claude.chatState,'success');
 for(const row of humans){const matches=app.messages.filter(message=>message.sender==='user'&&message.context?.cliUuid===row.uuid);assert.equal(matches.length,1);assert.equal(matches[0].text,row.message.content)}
 const calls=await json(join(workspace,'model-calls.json'));assert.equal(calls.seed.filter(row=>row.path==='/v1/messages?beta=true').length,2);assert.equal(calls.agent.length,agent?4:0);
 assert.deepEqual(await json(join(root,'compiled-before.json')),await json(join(root,'compiled-after.json')));
 const boundary=await json(join(root,'offline-boundary.json'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);assert.equal(boundary.memory,6*1024**3);assert.equal(boundary.memorySwap,boundary.memory);assert.equal(boundary.nanoCpus,2*10**9);assert.deepEqual(Object.keys(boundary.networks),['none']);
 return {owner:agent?'selected-Agent':'main',...(fullReading?{completeBodyWheelReading:true,populatedCustomCommands:true}:{}),...(links?{helpLinkRouting:true,browserActivations:6}:{originalTabs:true,groupedShortcutText:true}),noExtraHumanTurn:true,exactAppNativeHistory:true,appNativePrintCost:cost,ownedNativeExits:3,screenshots:links?2:6};
}
