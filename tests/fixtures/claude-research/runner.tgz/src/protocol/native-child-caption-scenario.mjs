import assert from 'node:assert/strict';

/** Ask the original child to launch one native Agent; no task IDs or captions are fabricated. */
export function nativeChildCaptionStep(body) {
 const messages=body.messages??[];
 const text=messages.flatMap(message=>typeof message.content==='string'?[message.content]:Array.isArray(message.content)?message.content.filter(block=>block.type==='text').map(block=>block.text):[]).join('\n');
 if(text.includes('Check the release notes for clarity. Return a brief review.'))return {stage:'reviewer-working',hold:true,block:{type:'text',text:'The release notes are clear and ready for review.'}};
 if(!text.includes('ResearchChildCaptionReview'))return;
 const id='toolu_child_caption_review';
 const result=messages.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[]).find(block=>block.tool_use_id===id);
 if(result)return {stage:'review-complete',result,block:{type:'text',text:result.is_error?'The release reviewer could not start.':'The release review is ready.'}};
 const agent=body.tools?.find(tool=>tool.name==='Agent');
 assert.ok(agent?.input_schema?.properties?.subagent_type,'Original Agent tool is unavailable');
 return {stage:'launch-reviewer',block:{type:'tool_use',id,name:'Agent',input:{description:'Review release notes',prompt:'Check the release notes for clarity. Return a brief review.',subagent_type:'general-purpose',...(agent.input_schema.properties.run_in_background?{run_in_background:true}:{})}}};
}
