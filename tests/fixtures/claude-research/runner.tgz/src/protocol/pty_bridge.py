"""Run one explicit argv in a PTY; merge target stdout/stderr as a terminal does.

The enclosing Node recorder owns time/output limits and provenance. This adapter uses
only Python's standard library and kills its separately sessioned child on shutdown.
"""
import errno
import fcntl
import os
import pty
import select
import signal
import struct
import sys
import termios

if len(sys.argv) < 2:
    raise SystemExit('Expected explicit executable argv')

child_pid, terminal = pty.fork()
if child_pid == 0:
    fcntl.ioctl(0, termios.TIOCSWINSZ, struct.pack('HHHH', 30, 100, 0, 0))
    os.execvpe(sys.argv[1], sys.argv[1:], os.environ)


def terminate(signum, _frame):
    raise SystemExit(128 + signum)


signal.signal(signal.SIGTERM, terminate)
signal.signal(signal.SIGINT, terminate)
try:
    inputs = [terminal, sys.stdin.fileno()]
    while True:
        ready, _, _ = select.select(inputs, [], [])
        if terminal in ready:
            try:
                data = os.read(terminal, 65536)
            except OSError as error:
                if error.errno != errno.EIO:
                    raise
                break
            if not data:
                break
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()
        if sys.stdin.fileno() in ready:
            data = os.read(sys.stdin.fileno(), 65536)
            if not data:
                inputs.remove(sys.stdin.fileno())
            else:
                while data:
                    written = os.write(terminal, data)
                    data = data[written:]
    _, status = os.waitpid(child_pid, 0)
    code = os.waitstatus_to_exitcode(status)
    raise SystemExit(code if code >= 0 else 128 - code)
finally:
    try:
        os.killpg(child_pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    os.close(terminal)
    try:
        os.waitpid(child_pid, 0)
    except ChildProcessError:
        pass
