import {createNativeLargeTestImage} from './native-test-image.mjs';
export const resourceImageUri='research://release/screenshot';
export const resourceImage=createNativeLargeTestImage();
export const resourceFileSteps=[
 {id:'resource-files-list',name:'ListMcpResourcesTool',input:{server:'research'}},
 {id:'resource-files-image',name:'ReadMcpResourceTool',input:{server:'research',uri:resourceImageUri}},
 {id:'resource-files-binary',name:'ReadMcpResourceTool',input:{server:'research',uri:'research://release/evidence'}},
];
