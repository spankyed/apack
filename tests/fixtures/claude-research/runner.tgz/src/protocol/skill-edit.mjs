import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Exercise the native extension-facing writer only in a disposable project. */
export async function probeSkillEdit(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'skill-edit-'));
 const cwd=join(workspace,'project'),home=join(workspace,'home');
 await mkdir(join(home,'.claude'),{recursive:true});
 for(const [name,extra] of [['research-editable',''],['research-author-locked','disable-model-invocation: true\n']]){
  const dir=join(cwd,'.claude','skills',name);await mkdir(dir,{recursive:true});
  await writeFile(join(dir,'SKILL.md'),`---\nname: ${name}\ndescription: Private edit fixture\n${extra}---\nSynthetic body.\n`);
 }
 execFileSync('/usr/bin/git',['init','-q',cwd]);
 const settingsPath=join(cwd,'.claude','settings.local.json');
 await writeFile(settingsPath,JSON.stringify({language:'research-preserve',skillOverrides:{'research-other':'name-only'}}));
 const run=await createRun(output,'skill-edit',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url)))});
 const cases=[];
 try{
  for(const edit of [{name:'research-editable',state:'off'},{name:'research-editable',state:'off'},{name:'research-editable',state:'on'},{name:'research-author-locked',state:'on'},{name:'__proto__',state:'off'}]){
   const before=await readFile(settingsPath);const transport=await record({executable,cwd,output,timeoutMs:15000,args:['edit-skill-overrides','--json'],input:[JSON.stringify(edit)+'\n'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'}});
   const stdout=(await readFile(join(transport.directory,'stdout.bin'),'utf8')).trim(),stderr=(await readFile(join(transport.directory,'stderr.bin'),'utf8')).trim();
   const after=await readFile(settingsPath);let response;try{response=JSON.parse(stdout)}catch{response=null}
   cases.push({edit,status:transport.status,code:transport.code,response,stderr:stderr.split(workspace).join('${WORKSPACE}'),fileUnchanged:before.equals(after),settings:JSON.parse(after),transportRun:transport.directory});
  }
  for(const item of cases){assert.equal(item.settings.language,'research-preserve');assert.equal(item.settings.skillOverrides['research-other'],'name-only')}
  for(const item of cases.slice(0,3)){assert.equal(item.code,0);assert.equal(item.response?.ok,true)}
  assert.equal(cases[0].settings.skillOverrides['research-editable'],'off');assert.equal(cases[0].response.changed,true);
  assert.equal(cases[1].response.changed,false);assert.equal(cases[1].fileUnchanged,true);
  assert.equal(cases[2].response.changed,true);assert.equal(cases[2].settings.skillOverrides['research-editable'],undefined);
  for(const item of cases.slice(3)){assert.notEqual(item.code,0);assert.equal(item.fileUnchanged,true)}
  const result={cases,modelPrompts:0,qualification:'Private local writer only; running-process refresh, policy/plugin locks, aliases, concurrency and app UI require separate verification.'};
  await writeFile(join(run.directory,'skill-edit.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete',cases:cases.length});return{directory:run.directory,status:'complete',cases:cases.length,modelPrompts:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
