import assert from 'node:assert/strict';
import * as vm from 'node:vm';
import { readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

/** Hold only the successful readiness result of one authored private module, before native mount. */
export function installOwnedClientLoadDelay({ modulePath, workspace, prototype = vm.SourceTextModule?.prototype }) {
  assert.ok(resolve(modulePath).startsWith(resolve(workspace) + '/pending-client-fixture/hooks/'));
  assert.ok(prototype && typeof prototype.evaluate === 'function', 'Native module evaluator required');
  const original = prototype.evaluate, receiptPath = join(workspace, 'native-client-load-delay.json'), releasePath = join(workspace, 'native-client-load.release');
  let claimed = false;
  prototype.evaluate = function (...args) {
    if (claimed || this.identifier !== modulePath) return Reflect.apply(original, this, args);
    claimed = true;
    const receipt = { startedAt: Date.now(), module: 'pending-extension.ts' }, save = () => writeFileSync(receiptPath, JSON.stringify(receipt));
    save();
    return Reflect.apply(original, this, args).then(async result => {
      receipt.evaluatedAt = Date.now(); save();
      const deadline = Date.now() + 3000;
      let released = false;
      while (Date.now() < deadline) {
        try { readFileSync(releasePath); released = true; break; } catch {}
        await new Promise(resolve => setTimeout(resolve, 10));
      }
      Object.assign(receipt, { deliveredAt: Date.now(), reason: released ? 'explicit' : 'deadline' }); save();
      return result;
    }, error => { receipt.failedAt = Date.now(); save(); throw error; });
  };
  return () => { prototype.evaluate = original; };
}
