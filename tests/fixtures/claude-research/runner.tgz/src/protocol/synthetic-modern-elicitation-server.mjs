import {appendFileSync} from 'node:fs';
import {createInterface} from 'node:readline';
const version='2026-07-28',receipt=process.env.APACK_MCP_ELICITATION_RECEIPT;
const send=value=>process.stdout.write(JSON.stringify({jsonrpc:'2.0',...value})+'\n');
const complete=(id,result)=>send({id,result:{resultType:'complete',_meta:{'io.modelcontextprotocol/serverInfo':{name:'release-review-modern',version:'1.0.0'}},...result}});
const error=(id,code,message)=>send({id,error:{code,message}});
const reviewUrl=phase=>{
 const configured=process.env.APACK_MCP_URL_BROWSER_ORIGIN;if(!configured)return 'https://example.invalid/release-review';
 const origin=new URL(configured);if(origin.protocol!=='http:'||origin.hostname!=='127.0.0.1'||origin.href!==origin.origin+'/')throw Error('Only owned loopback review pages are allowed');
 return origin.origin+'/release-review?phase='+phase+'&title=release notes';
};
const pending=new Map();
createInterface({input:process.stdin}).on('line',line=>{
 let request;try{request=JSON.parse(line)}catch{return;}
 appendFileSync(receipt,JSON.stringify(request)+'\n');
 if(request.id===undefined)return;
 const {id,method,params={}}=request,meta=params._meta;
 if(method==='initialize')return error(id,-32601,'Modern fixture requires server/discover negotiation');
 if(meta?.['io.modelcontextprotocol/protocolVersion']!==version||typeof meta?.['io.modelcontextprotocol/clientCapabilities']!=='object')return error(id,-32602,'Missing original modern protocol envelope');
 switch(method){
  case 'server/discover':return complete(id,{supportedVersions:[version],capabilities:{tools:{}},ttlMs:0,cacheScope:'private'});
  case 'ping':return complete(id,{});
  case 'tools/list':return complete(id,{ttlMs:0,cacheScope:'private',tools:[{name:'echo',description:'Review release input through an addressed modern input request.',inputSchema:{type:'object',properties:{scenario:{type:'string'},phase:{type:'integer'}},required:['scenario','phase']}}]});
  case 'tools/call':{
   if(meta['io.modelcontextprotocol/clientCapabilities'].elicitation?.url===undefined)return error(id,-32602,'Client did not advertise original URL elicitation');
   const phase=params.arguments?.phase;
   if(!Number.isSafeInteger(phase)||phase<1||phase>64)return error(id,-32602,'Invalid owned phase');
   const state='modern-release-'+phase,key='release-review';
   if(params.inputResponses!==undefined){
    const response=params.inputResponses[key];
    if(pending.get(state)!==phase||params.requestState!==state||Object.keys(params.inputResponses).length!==1||!['accept','decline','cancel'].includes(response?.action))return error(id,-32602,'Foreign or expired original input response');
    pending.delete(state);return complete(id,{content:[{type:'text',text:JSON.stringify({elicitation:response})}]});
   }
   if(params.requestState!==undefined||pending.has(state))return error(id,-32602,'Input request already pending');
   pending.set(state,phase);
   return send({id,result:{resultType:'input_required',requestState:state,inputRequests:{[key]:{method:'elicitation/create',params:{mode:'url',message:'Complete the release review in the browser, then confirm here.',url:reviewUrl(phase)}}}}});
  }
  default:return error(id,-32601,'Unsupported owned modern method');
 }
});
