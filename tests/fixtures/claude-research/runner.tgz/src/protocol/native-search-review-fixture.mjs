import {mkdir,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Fixed local search work; original tools execute every search and produce every result. */
export function nativeSearchReviewSteps(workspace){
 const path=join(workspace,'release-notes');
 return [
  {tool:'Glob',input:{pattern:'*.md',path},purpose:'Find the release documents'},
  {tool:'Grep',input:{pattern:'Migration:',path,output_mode:'content','-n':true},purpose:'Review matching migration lines'},
  {tool:'Grep',input:{pattern:'NoSuchReleaseMarker',path,output_mode:'content'},purpose:'Handle an empty search'},
  {tool:'Grep',input:{pattern:'[',path,output_mode:'content'},purpose:'Recover from an invalid regular expression'},
 ];
}

export async function addNativeSearchReviewFixture(workspace,plugin){
 const directory=join(workspace,'release-notes');
 await mkdir(directory,{recursive:true});
 await writeFile(join(directory,'release.md'),'# Release review\nMigration: preserve session history.\nMigration: retain the current draft.\n');
 await writeFile(join(directory,'checklist.md'),'# Checklist\nReview approvals and interruption recovery.\n');
 await writeFile(join(workspace,'native-search-review-steps.json'),JSON.stringify(nativeSearchReviewSteps(workspace)));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&/^native_search_review_[1-4]$/.test(e.props.tool_use_id))await $.fs.write(e.props.tool_use_id+'-original.json',JSON.stringify({requestId:e.requestId,props:e.props}));return next(e);});}`);
}
