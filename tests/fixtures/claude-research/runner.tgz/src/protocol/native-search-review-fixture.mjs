import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Fixed local search work; original tools execute every search and produce every result. */
export function nativeSearchReviewSteps(workspace){
 const path=join(workspace,'release-notes');
 return [
  {tool:'Glob',input:{pattern:'*.md',path},purpose:'Find the release documents'},
  {tool:'Grep',input:{pattern:'Migration:',path,output_mode:'content','-n':true},purpose:'Review matching migration lines'},
  {tool:'Grep',input:{pattern:'NoSuchReleaseMarker',path,output_mode:'content'},purpose:'Handle an empty search'},
  {tool:'Grep',input:{pattern:'[',path,output_mode:'content'},purpose:'Recover from an invalid regular expression'},
 ];
}

export async function addNativeSearchReviewFixture(workspace,plugin){
 const directory=join(workspace,'release-notes');
 await mkdir(directory,{recursive:true});
 await writeFile(join(directory,'release.md'),'# Release review\nMigration: preserve session history.\nMigration: retain the current draft.\n');
 await writeFile(join(directory,'checklist.md'),'# Checklist\nReview approvals and interruption recovery.\n');
 await writeFile(join(workspace,'native-search-review-steps.json'),JSON.stringify(nativeSearchReviewSteps(workspace)));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&/^native_search_review_[1-4]$/.test(e.props.tool_use_id))await $.fs.write(e.props.tool_use_id+'-original.json',JSON.stringify({requestId:e.requestId,props:e.props}));return next(e);});}`);
}

/** Independently revalidate the idle journey from original saved receipts; never relaunch it. */
export async function verifyNativeIdleRedraw(workspace,{seedCalls,agentCalls,evidence}){
 const json=async name=>JSON.parse(await readFile(join(workspace,name),'utf8'));
 const proof=await json('native-search-review-proof.json'),idle=proof.idleProof;
 assert.equal(evidence.nativeIdleRedraw,true);assert.equal(evidence.resumedPrintSameSession,true);
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(evidence.finalSessionId,evidence.sessionId);
 assert.equal(idle.childrenBefore,idle.childrenAfter);assert.equal(idle.turnsBefore,idle.turnsAfter);
 assert.equal(idle.receipt.count,4);assert.equal(idle.receipt.read.text,idle.draft);assert.ok(idle.messageIds.length>0);
 assert.equal(agentCalls.length,0,'Idle native UI must not request a model response');
 assert.equal(seedCalls.length,2,'Only seed and final print continuation may request responses');
 const lines=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl');
 assert.equal(children.length,3);assert.equal(children[1].pid,evidence.boundNativePid);
 assert.ok(children[0].args.includes('--print'));assert.ok(children[2].args.includes('--print'));
 assert.equal(children[2].args[children[2].args.indexOf('--resume')+1],evidence.sessionId);
 for(const child of children)assert.ok(exits.some(exit=>exit.pid===child.pid),'Every owned native child must have its original exit receipt');
 assert.ok(exits.find(exit=>exit.pid===children[1].pid).at<=children[2].at);
 assert.deepEqual(evidence.browserErrors,[]);
 return {nativeProcesses:3,originalExitReceipts:3,idleModelRequests:0,totalSyntheticRequests:2,callbackCount:4,sameSessionRecovery:true};
}
