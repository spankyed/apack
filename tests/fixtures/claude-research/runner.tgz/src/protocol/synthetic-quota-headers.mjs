/** Copy a bounded set of synthetic provider quota headers; never allow response/header injection. */
export function syntheticQuotaHeaders(value) {
  const headers = {};
  if (value === undefined) return headers;
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('Quota headers require an object');
  const entries = Object.entries(value);
  if (entries.length > 20) throw Error('Too many quota headers');
  for (const [name, content] of entries) {
    if (!/^anthropic-ratelimit-unified-[a-z0-9-]{1,80}$/.test(name) || typeof content !== 'string' || content.length > 256 || /[^\x20-\x7e]/.test(content)) throw Error('Invalid bounded quota header');
    headers[name] = content;
  }
  return headers;
}
