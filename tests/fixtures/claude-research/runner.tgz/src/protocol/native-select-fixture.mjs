import assert from 'node:assert/strict';
import {writeFile,readFile} from 'node:fs/promises';
import {join} from 'node:path';

/** An original admitted Select with a legitimate empty-string option; no vendor code is changed. */
export async function addNativeSelectFixture(plugin){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){
 let selected;const rows=[];
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
  if(e.surface!=='desktop')return next(e);
  const{Box,Select,Button}=$.ui.resolve(e);
  await $.fs.write('native-select-drawing.json',JSON.stringify({requestId:e.requestId,hasValue:selected!==undefined,...selected!==undefined?{value:selected}:{}}));
  return Box({flexDirection:'row',alignItems:'center',gap:1,children:[
   Select({key:'release-audience',label:'Release audience',...selected!==undefined?{value:selected}:{},options:[{value:'',label:'No audience filter'},{value:'developers',label:'Developers'}],onSelect:async value=>{selected=value;rows.push({kind:'select',value,requestId:e.requestId});await $.fs.write('native-select-callbacks.json',JSON.stringify(rows));$.ui.invalidate('ui.render');}}),
   Button({key:'clear-audience',label:'Clear audience',onPress:async()=>{selected=undefined;rows.push({kind:'clear',requestId:e.requestId});await $.fs.write('native-select-callbacks.json',JSON.stringify(rows));$.ui.invalidate('ui.render');}})
  ]});
 });
}`);
}

export async function verifyNativeSelectFixture(workspace){
 const proof=JSON.parse(await readFile(join(workspace,'native-select-proof.json'),'utf8'));
 const callbacks=JSON.parse(await readFile(join(workspace,'native-select-callbacks.json'),'utf8'));
 assert.deepEqual(proof.callbacks,callbacks);
 assert.ok(callbacks.every(row=>typeof row.requestId==='string'&&row.requestId.length>0));
 assert.deepEqual(proof.callbacks.map(({kind,value})=>({kind,...value!==undefined?{value}:{}})),[{kind:'select',value:''},{kind:'select',value:'developers'},{kind:'clear'}]);
 assert.deepEqual(proof.states.map(({stage,width})=>[stage,width]),['unset','empty','selected','cleared'].flatMap(stage=>[1100,680].map(width=>[stage,width])));
 for(const state of proof.states){
  assert.equal(state.drawing.hasValue,['empty','selected'].includes(state.stage));
  if(state.stage==='empty'){assert.equal(state.drawing.value,'');assert.equal(state.label,'No audience filter');}
  else if(state.stage==='selected'){assert.equal(state.drawing.value,'developers');assert.equal(state.label,'Developers');}
  else{assert.equal(state.drawing.value,undefined);assert.equal(state.label,'none');}
 }
 assert.deepEqual(proof.keyboardCancellation,[1100,680].map(width=>({width,callbacks:[],label:'none',focused:true})));
 assert.equal(proof.noPhantomTurn,true);
 return {originalSelectCallbacks:2,originalClearCallbacks:1,states:8,keyboardCancellations:2,noPhantomTurn:true};
}
