import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** Original public Text/Box factories carry multiline and mixed-direction strings to the app. */
export async function addNativeTextMeasurementFixture(plugin, workspace) {
  const samples = [
    { text: 'Release notes\nMigration guidance for desktop', width: 12 },
    { text: 'Ready\nNo changes', width: 12 },
    { text: 'ABC אבגדהוזחטי XYZ', width: 12 },
    { text: 'Wé👩‍💻XYZ release\nOK', width: 12 },
  ];
  await writeFile(join(workspace, 'native-text-measurement-inputs.json'), JSON.stringify(samples));
  await writeFile(join(plugin, 'hooks/register.ts'), `export function register(on){
    on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text}=$.ui.resolve(e);
      const samples=${JSON.stringify(samples)};
      const drawing=Box({flexDirection:'column',children:samples.map(sample=>Box({flexDirection:'row',columnGap:2,children:['truncate-end','truncate-start','middle'].map(wrap=>Box({width:sample.width,flexShrink:0,children:[Text({wrap,children:[sample.text]})]}))}))});
      await $.fs.write('native-text-measurement-drawn.json',JSON.stringify({surface:e.surface,component:e.component,samples,drawing}));return drawing;
    });
    on('ui.render',{component:'PromptHint'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Text}=$.ui.resolve(e);return Text({children:['Release review excerpts']});});
  }`);
}

/** Exercise default paragraph direction and explicit overrides using styled inline runs. */
export async function addNativeTextDirectionFixture(plugin, workspace) {
  const samples = ['אבגדה\nRelease ready', 'Release ready\nאבגדה'];
  await writeFile(join(workspace, 'native-text-direction-inputs.json'), JSON.stringify(samples));
  await writeFile(join(plugin, 'hooks/register.ts'), `export function register(on){
    on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text}=$.ui.resolve(e);const samples=${JSON.stringify(samples)};
      const drawing=Box({flexDirection:'column',children:samples.map(text=>Box({flexDirection:'row',columnGap:2,children:[undefined,'rtl','ltr'].map(dir=>Box({width:14,flexShrink:0,children:[Text({...(dir?{dir}:{}),wrap:'wrap',children:[Text({weight:'semibold',children:[text.split('\\n')[0]]}),Text({children:['\\n'+text.split('\\n')[1]]})]})]}))}))});
      await $.fs.write('native-text-direction-drawn.json',JSON.stringify({surface:e.surface,component:e.component,samples,drawing}));return drawing;
    });
    on('ui.render',{component:'PromptHint'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Text}=$.ui.resolve(e);return Text({children:['Release review excerpts']});});
  }`);
}
