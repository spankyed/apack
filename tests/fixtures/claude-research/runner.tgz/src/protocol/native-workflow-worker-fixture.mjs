import { isAbsolute } from 'node:path';
/** Observe original worker controller aborts; never replace a controller or signal. */
export function nativeWorkflowWorkerFixture(directory) {
 if(!isAbsolute(directory))throw Error('Workflow worker fixture requires a private absolute directory');
 return `{
 const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),fs=await import('node:fs'),path=await import('node:path');
 const seen=new WeakSet(),watched=[],aborts=[],deadline=Date.now()+100000,directory=${JSON.stringify(directory)};
 const save=()=>fs.writeFileSync(path.join(directory,'native-workflow-worker-signals.json'),JSON.stringify({watched,aborts}),{mode:0o600});
 const timer=setInterval(()=>{if(Date.now()>deadline){clearInterval(timer);return}try{
  const binding=runtime.ey();if(binding?.surface!=='terminal')return;
  for(const task of Object.values(binding.toolContext(new AbortController()).taskRegistry.all())){
   if(task.type!=='local_workflow')continue;
   for(const [agentId,controller] of task.agentControllers??[]){
    const signal=controller.signal;if(seen.has(signal)||watched.length>=32)continue;seen.add(signal);watched.push({taskId:task.id,agentId});
    signal.addEventListener('abort',()=>{aborts.push({taskId:task.id,agentId,reason:String(signal.reason?.message??signal.reason),aborted:signal.aborted});save()},{once:true});save();
   }
  }
 }catch{}},50);timer.unref();
 }`;
}
