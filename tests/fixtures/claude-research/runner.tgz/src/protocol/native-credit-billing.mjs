import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {mkdir,readFile,writeFile,chmod} from 'node:fs/promises';
import {join,isAbsolute} from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createServer} from 'node:https';
import {CREDIT_ORGANIZATION_ID,CREDIT_SYNTHETIC_TOKEN} from './native-credit-account.mjs';
const exec=promisify(execFile);

/** A new fixture CA only; never install trust or change DNS on the host. */
export async function prepareNativeCreditTls(directory){
 assert.ok(isAbsolute(directory));await mkdir(directory,{mode:0o700});
 const run=args=>exec('openssl',args,{cwd:directory,timeout:10000,maxBuffer:131072});
 await run(['req','-x509','-newkey','rsa:2048','-sha256','-nodes','-days','2','-subj','/CN=Owned Claude credit fixture','-addext','basicConstraints=critical,CA:TRUE','-addext','keyUsage=critical,keyCertSign,cRLSign','-keyout','ca.key','-out','ca.pem']);
 await run(['req','-newkey','rsa:2048','-nodes','-subj','/CN=api.anthropic.com','-keyout','server.key','-out','server.csr']);
 await writeFile(join(directory,'server.ext'),'basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=DNS:api.anthropic.com,DNS:claude.ai\n');
 await run(['x509','-req','-in','server.csr','-CA','ca.pem','-CAkey','ca.key','-CAcreateserial','-days','2','-sha256','-extfile','server.ext','-out','server.pem']);
 await chmod(join(directory,'ca.key'),0o600);await chmod(join(directory,'server.key'),0o600);
 return {ca:join(directory,'ca.pem'),cert:join(directory,'server.pem'),key:join(directory,'server.key')};
}

/** Original native billing routes on loopback HTTPS. All accounts, money and notifications are synthetic. */
export async function startNativeCreditBilling(tls,{port=443,allowMutations=false,evidencePath}={}){
 assert.ok(Number.isInteger(port)&&port>=0&&port<=65535);assert.equal(typeof allowMutations,'boolean');if(evidencePath!==undefined)assert.ok(isAbsolute(evidencePath));
 const state={enabled:false,balance:0,purchases:[],adminRequests:[],requests:[]};
 const bundle={id:'owned-credit-bundle',currency:'USD',price_minor_units:9000,credit_minor_units:10000,discount_minor_units:1000,local_price_minor_units:9000,local_credit_minor_units:10000};
 const server=createServer({key:await readFile(tls.key),cert:await readFile(tls.cert)},async(req,res)=>{
  if(evidencePath)res.once('finish',()=>writeFileSync(evidencePath,JSON.stringify(state,null,2)+'\n'));
  const send=(code,data)=>{res.writeHead(code,{'content-type':'application/json'});res.end(JSON.stringify(data));};
  try{
   if(!['api.anthropic.com','claude.ai'].includes((req.headers.host??'').split(':')[0]))return send(421,{error:'Owned original host required'});
   if(req.headers.authorization!=='Bearer '+CREDIT_SYNTHETIC_TOKEN)return send(401,{error:'Synthetic OAuth required'});
   const chunks=[];let length=0;for await(const chunk of req){length+=chunk.length;if(length>65536)return send(413,{error:'Fixture request too large'});chunks.push(chunk);}
   const body=length?JSON.parse(Buffer.concat(chunks).toString('utf8')):undefined,url=new URL(req.url,'https://api.anthropic.com'),prefix='/api/oauth/organizations/'+CREDIT_ORGANIZATION_ID;
   const record={method:req.method,path:url.pathname,query:url.search,body,syntheticAuth:true};if(state.requests.length>=256)return send(429,{error:'Owned billing request bound reached'});state.requests.push(record);
   if(url.pathname.startsWith('/api/oauth/organizations/')&&req.headers['x-organization-uuid']!==CREDIT_ORGANIZATION_ID)return send(403,{error:'Owned organization required'});
   const route=url.pathname.startsWith(prefix)?url.pathname.slice(prefix.length):url.pathname;
   if(req.method==='GET'&&route==='/prepaid/credits')return send(200,{amount:state.balance,currency:'USD',auto_reload_settings:{enabled:false},expiry_policy_months:12});
   if(req.method==='GET'&&route==='/prepaid/bundles')return send(200,{bundles:[bundle],bundle_paid_this_month_minor_units:0,bundle_monthly_cap_minor_units:null,purchases_reset_at:'2026-10-27T00:00:00Z',currency:'USD',stripe_product_id:'prod_owned_credit',expiry_policy_months:12});
   if(req.method==='GET'&&route==='/payment_method')return send(200,{type:'card',brand:'visa',last4:'4242',exp_month:12,exp_year:2030});
   if(req.method==='GET'&&route==='/api/oauth/usage')return send(200,{five_hour:{utilization:0,resets_at:null},seven_day:{utilization:0,resets_at:null},extra_usage:{is_enabled:state.enabled,monthly_limit:10000,used_credits:0,currency:'USD',utilization:0,disabled_reason:state.enabled?null:'overage_not_provisioned'}});
   if(req.method==='POST'&&route==='/billing/tax_rate'){
    assert.equal(body.product_id,'prod_owned_credit');assert.equal(body.currency,'USD');assert.ok(Number.isInteger(body.price)&&body.price>0&&body.price<=1000000);return send(200,{tax_rate:10,tax_label:'Review tax'});
   }
   if(req.method==='GET'&&route==='/admin_requests/eligibility')return send(200,{is_allowed:true});
   if(req.method==='GET'&&route==='/admin_requests/me')return send(200,state.adminRequests);
   if(!allowMutations&&['POST /setup_overage_billing','PUT /overage_spend_limit','POST /contracts/prepaid/credits','POST /admin_requests'].includes(req.method+' '+route))return send(409,{error:'No billing mutations admitted in this fixture phase'});
   if(req.method==='POST'&&route==='/setup_overage_billing'){assert.ok(Number.isInteger(body.org_monthly_spend_limit));return send(200,{ok:true});}
   if(req.method==='PUT'&&route==='/overage_spend_limit'){assert.equal(body.is_enabled,true);state.enabled=true;return send(200,{is_enabled:true});}
   if(req.method==='POST'&&route==='/contracts/prepaid/credits'){
    assert.ok(Number.isInteger(body.amount)&&body.amount>0&&body.amount<=1000000);
    if(body.bundle_id){assert.equal(body.bundle_id,bundle.id);assert.equal(body.amount,bundle.credit_minor_units);assert.equal(body.expected_price_minor_units,bundle.price_minor_units);}
    state.balance+=body.amount;state.purchases.push(body);return send(200,{payment_status:'success',purchase_id:'owned-purchase-'+state.purchases.length});
   }
   if(req.method==='POST'&&route==='/admin_requests'){assert.deepEqual(body,{request_type:'limit_increase',details:null});const answer={id:'owned-admin-request-'+(state.adminRequests.length+1),status:'pending',request_type:'limit_increase'};state.adminRequests.push(answer);return send(201,answer);}
   return send(404,{error:'Unreviewed synthetic billing route'});
  }catch(error){send(400,{error:String(error)});}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
 return {state,port:server.address().port,close:async()=>{server.closeAllConnections();await new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()));}};
}
