import {EFFORT_EVAL_ROUTE,effortRolloutResponse,effortDecisionEvents} from './native-effort-rollout.mjs';
import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {mkdir,readFile,writeFile,chmod} from 'node:fs/promises';
import {join,isAbsolute,basename} from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createServer} from 'node:https';
import {CREDIT_ACCOUNT_ID,CREDIT_ORGANIZATION_ID,CREDIT_SYNTHETIC_TOKEN} from './native-credit-account.mjs';
const exec=promisify(execFile);

/** A new fixture CA only; never install trust or change DNS on the host. */
export async function prepareNativeCreditTls(directory){
 assert.ok(isAbsolute(directory));await mkdir(directory,{mode:0o700});
 const run=args=>exec('openssl',args,{cwd:directory,timeout:10000,maxBuffer:131072});
 await run(['req','-x509','-newkey','rsa:2048','-sha256','-nodes','-days','2','-subj','/CN=Owned Claude credit fixture','-addext','basicConstraints=critical,CA:TRUE','-addext','keyUsage=critical,keyCertSign,cRLSign','-keyout','ca.key','-out','ca.pem']);
 await run(['req','-newkey','rsa:2048','-nodes','-subj','/CN=api.anthropic.com','-keyout','server.key','-out','server.csr']);
 await writeFile(join(directory,'server.ext'),'basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=DNS:api.anthropic.com,DNS:claude.ai,DNS:platform.claude.com\n');
 await run(['x509','-req','-in','server.csr','-CA','ca.pem','-CAkey','ca.key','-CAcreateserial','-days','2','-sha256','-extfile','server.ext','-out','server.pem']);
 await chmod(join(directory,'ca.key'),0o600);await chmod(join(directory,'server.key'),0o600);
 return {ca:join(directory,'ca.pem'),cert:join(directory,'server.pem'),key:join(directory,'server.key')};
}

/** Original native billing routes on loopback HTTPS. All accounts, money and notifications are synthetic. */
export async function startNativeCreditBilling(tls,{port=443,allowMutations=false,evidencePath,accountType='pro',adminBarrier,purchaseOutcome='success',paymentBarrier,adminRequestOutcome='success',adminRequestsAllowed='always',effortRollout=false}={}){
 assert.equal(typeof effortRollout,'boolean');
 assert.ok(Number.isInteger(port)&&port>=0&&port<=65535);assert.equal(typeof allowMutations,'boolean');assert.ok(['pro','team'].includes(accountType));if(evidencePath!==undefined)assert.ok(isAbsolute(evidencePath));
 if(adminBarrier!==undefined){assert.ok(isAbsolute(adminBarrier));assert.equal(basename(adminBarrier),'native-credit-admin-release');}
 assert.ok(['success','pending-paid','pending-failed','requires-action','error'].includes(purchaseOutcome));
 if(paymentBarrier!==undefined){assert.ok(isAbsolute(paymentBarrier));assert.equal(basename(paymentBarrier),'native-credit-payment-release');}
 assert.ok(['success','disconnect'].includes(adminRequestOutcome));assert.ok(['always','until-first-attempt','never'].includes(adminRequestsAllowed));
 const lifetime=new AbortController();
 const persist=()=>{if(evidencePath)writeFileSync(evidencePath,JSON.stringify(state,null,2)+'\n')};
 const state={enabled:false,balance:0,purchases:[],purchaseStates:{},adminRequests:[],requests:[]};
 async function waitForRelease(path,value,record){
  record.waitingForRelease=true;persist();const until=Date.now()+8000;
  while(true){lifetime.signal.throwIfAborted();try{assert.equal(await readFile(path,'utf8'),value);break;}catch(error){if(error.code!=='ENOENT')throw error;}if(Date.now()>=until)throw Error('Owned credit response barrier expired');await new Promise(resolve=>setTimeout(resolve,25));}
  record.waitingForRelease=false;
 }
 const bundle={id:'owned-credit-bundle',currency:'USD',price_minor_units:9000,credit_minor_units:10000,discount_minor_units:1000,local_price_minor_units:9000,local_credit_minor_units:10000};
 const server=createServer({key:await readFile(tls.key),cert:await readFile(tls.cert)},async(req,res)=>{
  let record;res.once('finish',()=>{if(record){record.status=res.statusCode;record.finishedAt=Date.now();}persist();});
  const send=(code,data)=>{res.writeHead(code,{'content-type':'application/json'});res.end(JSON.stringify(data));};
  try{
   if(!['api.anthropic.com','claude.ai','platform.claude.com'].includes((req.headers.host??'').split(':')[0]))return send(421,{error:'Owned original host required'});
   const requested=new URL(req.url,'https://api.anthropic.com');
   // Shipped setup checks these public endpoints before account authentication.
   if(req.method==='GET'&&['/api/hello','/v1/oauth/hello'].includes(requested.pathname)){
    if(state.requests.length>=256)return send(429,{error:'Owned billing request bound reached'});
    record={at:Date.now(),method:'GET',path:requested.pathname,query:requested.search,syntheticAuth:false};state.requests.push(record);return send(200,{ok:true});
   }
   if(req.headers.authorization!=='Bearer '+CREDIT_SYNTHETIC_TOKEN)return send(401,{error:'Synthetic OAuth required'});
   const url=requested,prefix='/api/oauth/organizations/'+CREDIT_ORGANIZATION_ID;
   record={at:Date.now(),method:req.method,path:url.pathname,query:url.search,syntheticAuth:true};if(state.requests.length>=256){req.resume();return send(429,{error:'Owned billing request bound reached'});}state.requests.push(record);
   if(url.pathname.startsWith('/api/oauth/organizations/')&&req.headers['x-organization-uuid']!==CREDIT_ORGANIZATION_ID){req.resume();return send(403,{error:'Owned organization required'});}
   const route=url.pathname.startsWith(prefix)?url.pathname.slice(prefix.length):url.pathname;
   const reviewed=['GET /api/oauth/profile','GET /api/oauth/usage','GET /prepaid/credits','GET /prepaid/bundles','GET /payment_method','POST /billing/tax_rate','GET /admin_requests/eligibility','GET /admin_requests/me','POST /setup_overage_billing','PUT /overage_spend_limit','POST /contracts/prepaid/credits','POST /admin_requests'];
   if(effortRollout)reviewed.push('POST '+EFFORT_EVAL_ROUTE,'POST /api/event_logging/v2/batch');
   // Reject unrelated startup/telemetry traffic without collecting its bodies or abandoning keep-alive uploads.
   if(!reviewed.includes(req.method+' '+route)&&!(req.method==='GET'&&/^\/prepaid\/commits\/owned-purchase-[1-9]\d*$/.test(route))){req.resume();return send(404,{error:'Unreviewed synthetic billing route'});}
   const chunks=[];let length=0;for await(const chunk of req){length+=chunk.length;if(length>(effortRollout&&route==='/api/event_logging/v2/batch'?1048576:65536)){req.resume();return send(413,{error:'Fixture request too large'});}chunks.push(chunk);}
   const body=length?JSON.parse(Buffer.concat(chunks).toString('utf8')):undefined;
   if(effortRollout&&req.method==='POST'&&route==='/api/event_logging/v2/batch'){
    const events=effortDecisionEvents(body);state.effortEvents??=[];assert.ok(state.effortEvents.length+events.length<=64);state.effortEvents.push(...events);record.effortEventCount=events.length;return send(200,{accepted_count:body.events.length});
   }
   record.body=body;
   if(effortRollout&&req.method==='POST'&&route===EFFORT_EVAL_ROUTE)return send(200,effortRolloutResponse(body));
   if(req.method==='GET'&&route==='/api/oauth/profile')return send(200,{account:{uuid:CREDIT_ACCOUNT_ID,email:'credit-review@example.test',display_name:'Release reviewer',created_at:'2026-01-01T00:00:00Z'},organization:{uuid:CREDIT_ORGANIZATION_ID,billing_type:'stripe_subscription',has_extra_usage_enabled:state.enabled,subscription_created_at:'2026-01-01T00:00:00Z',cc_onboarding_flags:{},plan_display_name:accountType==='team'?'Team':'Pro'}});
   if(req.method==='GET'&&route==='/prepaid/credits')return send(200,{amount:state.balance,currency:'USD',auto_reload_settings:{enabled:false},expiry_policy_months:12});
   if(req.method==='GET'&&route==='/prepaid/bundles')return send(200,{bundles:[bundle],bundle_paid_this_month_minor_units:0,bundle_monthly_cap_minor_units:null,purchases_reset_at:'2026-10-27T00:00:00Z',currency:'USD',stripe_product_id:'prod_owned_credit',expiry_policy_months:12});
   if(req.method==='GET'&&route==='/payment_method')return send(200,{type:'card',brand:'visa',last4:'4242',exp_month:12,exp_year:2030});
   if(req.method==='GET'&&route==='/api/oauth/usage')return send(200,{five_hour:{utilization:0,resets_at:null},seven_day:{utilization:0,resets_at:null},extra_usage:{is_enabled:state.enabled,monthly_limit:10000,used_credits:0,currency:'USD',utilization:0,disabled_reason:state.enabled?null:'overage_not_provisioned'}});
   if(req.method==='GET'&&route.startsWith('/prepaid/commits/')){
    const id=route.split('/').at(-1),purchase=state.purchaseStates[id];if(!purchase)return send(404,{error:'Unknown owned purchase'});
    purchase.pollCount++;
    if(purchase.status==='pending'){
     if(paymentBarrier)await waitForRelease(paymentBarrier,'release-owned-payment\n',record);
     purchase.status=purchaseOutcome==='pending-paid'?'paid':'failed';
     if(purchase.status==='paid'&&!purchase.credited){state.balance+=purchase.amount;purchase.credited=true;}
    }
    return send(200,{purchase_id:id,status:purchase.status,stripe_payment_intent_client_secret:null});
   }
   if(req.method==='POST'&&route==='/billing/tax_rate'){
    assert.equal(body.product_id,'prod_owned_credit');assert.equal(body.currency,'USD');assert.ok(Number.isInteger(body.price)&&body.price>0&&body.price<=1000000);return send(200,{tax_rate:10,tax_label:'Review tax'});
   }
   if(req.method==='GET'&&route==='/admin_requests/eligibility')return send(200,{is_allowed:adminRequestsAllowed==='always'||adminRequestsAllowed==='until-first-attempt'&&!state.requests.some(row=>row.method==='POST'&&row.path===prefix+'/admin_requests')});
   if(req.method==='GET'&&route==='/admin_requests/me')return send(200,state.adminRequests);
   if(!allowMutations&&['POST /setup_overage_billing','PUT /overage_spend_limit','POST /contracts/prepaid/credits','POST /admin_requests'].includes(req.method+' '+route))return send(409,{error:'No billing mutations admitted in this fixture phase'});
   if(req.method==='POST'&&route==='/setup_overage_billing'){assert.ok(Number.isInteger(body.org_monthly_spend_limit));return send(200,{ok:true});}
   if(req.method==='PUT'&&route==='/overage_spend_limit'){assert.equal(body.is_enabled,true);state.enabled=true;return send(200,{is_enabled:true});}
   if(req.method==='POST'&&route==='/contracts/prepaid/credits'){
    assert.ok(Number.isInteger(body.amount)&&body.amount>0&&body.amount<=1000000);
    if(body.bundle_id){assert.equal(body.bundle_id,bundle.id);assert.equal(body.amount,bundle.credit_minor_units);assert.equal(body.expected_price_minor_units,bundle.price_minor_units);}
    state.purchases.push(body);const id='owned-purchase-'+state.purchases.length,status=purchaseOutcome==='success'?'paid':purchaseOutcome.startsWith('pending-')?'pending':purchaseOutcome==='requires-action'?'action_needed':'error';
    state.purchaseStates[id]={amount:body.amount,status,pollCount:0,credited:status==='paid'};
    if(status==='paid'){state.balance+=body.amount;return send(200,{payment_status:'success',purchase_id:id});}
    if(status==='pending')return send(200,{payment_status:'pending_invoice',purchase_id:id});
    if(status==='action_needed')return send(200,{payment_status:'requires_action',purchase_id:id});
    return send(500,{error:{type:'api_error',message:'Owned payment failure'}});
   }
   if(req.method==='POST'&&route==='/admin_requests'){assert.deepEqual(body,{request_type:'limit_increase',details:null});
    if(adminBarrier)await waitForRelease(adminBarrier,'release-owned-admin-request\n',record);
    if(adminRequestOutcome==='disconnect'){record.transportFailure='response-disconnected';record.finishedAt=Date.now();persist();req.socket.destroy();return;}
    const answer={id:'owned-admin-request-'+(state.adminRequests.length+1),status:'pending',request_type:'limit_increase'};state.adminRequests.push(answer);return send(201,answer);}
   return send(404,{error:'Unreviewed synthetic billing route'});
  }catch(error){if(record?.waitingForRelease){record.fixtureFailure=String(error);persist();res.destroy();return;}send(400,{error:String(error)});}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
 return {state,port:server.address().port,close:async()=>{lifetime.abort(Error('Owned billing fixture closed'));server.closeAllConnections();await new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()));}};
}
