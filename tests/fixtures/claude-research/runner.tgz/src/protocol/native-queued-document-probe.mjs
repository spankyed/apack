import assert from 'node:assert/strict';
import { access, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { basename, isAbsolute, join } from 'node:path';
import { record } from './record.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';
import { hash } from '../artifacts/runs.mjs';

assert.equal(process.platform, 'linux');
await access('/.dockerenv');
const [executable, workspace, output] = process.argv.slice(2);
assert.ok([executable, workspace, output].every(path => typeof path === 'string' && isAbsolute(path)),
  'Pass the pinned executable, a fresh private workspace and an evidence directory');
assert.equal((await readFile('/proc/net/route', 'utf8')).trim().split('\n').length, 1,
  'Use a container with networking disabled');
const executableSha256 = hash(await readFile(executable));
assert.equal(executableSha256, '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');

await mkdir(workspace);
const config = join(workspace, 'config');
await mkdir(config);
const main = '22222222-2222-4222-8222-222222222222';
const queued = '33333333-3333-4333-8333-333333333333';
const cancelled = '44444444-4444-4444-8444-444444444444';
const opened = 'Which synthetic fixture should be selected?';
const document = { type: 'document', title: 'Release checklist',
  source: { type: 'text', media_type: 'text/plain', data: 'The migration guide is covered in this fixture.' } };
const content = [{ type: 'text', text: 'Add the release checklist to this review.' }, document];
const discarded = [document, { type: 'text', text: 'Do not send this duplicate checklist.' }];
const model = await startSyntheticModel(workspace, 'AskUserQuestion', { captureMessages: true, maxRequests: 5 });
const jsonl = object => JSON.stringify(object) + '\n';
const request = (id, request) => jsonl({ type: 'control_request', request_id: id, request });
const user = (uuid, content) => jsonl({ type: 'user', uuid, message: { role: 'user', content }, parent_tool_use_id: null });
const lifecycle = [], results = [], projected = [];
let pending = '', question, cancellation;
try {
  const run = await record({
    executable, cwd: workspace, output, timeoutMs: 30000,
    args: ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json',
      '--setting-sources', '', '--strict-mcp-config', '--tools', 'AskUserQuestion',
      '--model', 'claude-sonnet-4-6', '--permission-prompt-tool', 'stdio', '--replay-user-messages',
      '--settings', JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' })],
    env: { PATH: process.env.PATH, HOME: workspace, CLAUDE_CONFIG_DIR: config, ANTHROPIC_BASE_URL: model.url,
      DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
    input: [request('initialize', { subtype: 'initialize', hooks: {} })],
    onStdout(bytes, transport) {
      pending += bytes.toString('utf8');
      while (pending.includes('\n')) {
        const end = pending.indexOf('\n'), line = pending.slice(0, end);
        pending = pending.slice(end + 1);
        const row = JSON.parse(line);
        if (row.type === 'control_response' && row.response.request_id === 'initialize') {
          assert.equal(row.response.subtype, 'success');
          transport.send(user(main, 'Review the release notes.'));
        } else if (row.type === 'control_request' && row.request.subtype === 'can_use_tool') {
          assert.equal(question, undefined);
          assert.equal(row.request.tool_name, 'AskUserQuestion');
          assert.equal(row.request.input.questions[0].question, opened);
          question = row;
          transport.send(user(queued, content));
          transport.send(user(cancelled, discarded));
          transport.send(request('cancel-second', { subtype: 'cancel_async_message', message_uuid: cancelled }));
        } else if (row.type === 'control_response' && row.response.request_id === 'cancel-second') {
          cancellation = row.response;
          assert.equal(cancellation.subtype, 'success');
          assert.equal(cancellation.response.cancelled, true);
          transport.send(jsonl({ type: 'control_response', response: { subtype: 'success', request_id: question.request_id,
            response: { behavior: 'allow', updatedInput: { ...question.request.input, answers: { [opened]: 'Alpha' } } } } }));
        } else if (row.type === 'command_lifecycle') {
          lifecycle.push(row);
        } else if (row.type === 'user' && row.uuid === queued) {
          projected.push(row);
        } else if (row.type === 'result') {
          results.push(row);
          if (row.queued_turn_count === 0 || row.is_error === true) transport.closeInput();
        }
      }
    },
  });
  const journals = await readdir(join(config, 'projects'), { recursive: true });
  const journalName = journals.find(name => basename(name) === results[0]?.session_id + '.jsonl');
  const journal = journalName ? await readFile(join(config, 'projects', journalName), 'utf8') : '';
  await writeFile(join(run.directory, 'native-journal.jsonl'), journal);
  const calls = model.calls.filter(row => row.path?.startsWith('/v1/messages'));
  await writeFile(join(run.directory, 'queued-document.json'), JSON.stringify({
    executableSha256, run, content, discarded, lifecycle, results, cancellation, projected, calls,
    sendIds: { main, queued, cancelled }, realModelRequests: 0,
  }, null, 2) + '\n');
  const rows = journal.trim().split('\n').map(line => JSON.parse(line));
  const attachment = rows.filter(row => row.attachment?.type === 'queued_command');
  const states = id => lifecycle.filter(row => row.command_uuid === id).map(row => row.state);
  assert.equal(run.code, 0);
  assert.equal(results.length, 1);
  assert.deepEqual(states(queued), ['queued', 'started', 'completed']);
  assert.deepEqual(states(cancelled), ['queued', 'cancelled']);
  assert.equal(attachment.length, 1);
  assert.equal(attachment[0].attachment.source_uuid, queued);
  assert.deepEqual(attachment[0].attachment.prompt, content);
  assert.equal(projected.length, 1);
  assert.equal(projected[0].isReplay, true);
  assert.deepEqual(projected[0].message.content, content);
  assert.equal(calls.length, 2);
  const requests = JSON.stringify(calls.map(call => call.messages));
  assert.equal(requests.split(content[0].text).length - 1, 1);
  assert.ok(!requests.includes(document.source.data));
  assert.ok(!requests.includes(discarded[1].text));
  console.log(JSON.stringify({ ...run, calls: calls.length, results: results.length, journal: !!journal }));
} finally {
  await model.close();
}
