import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {verifyNativeReadMediaResults} from './native-read-media-fixture.mjs';

/** Verify the actual app proof against captured original human requests, files and media results. */
export async function verifyNativeAttachmentMedia(workspace,evidence,calls){
 for(const key of ['actualAppGui','nativeAttachmentMedia','nativeReadMedia','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 assert.equal(evidence.sessionId,evidence.finalSessionId);assert.deepEqual(evidence.browserErrors,[]);
 const proof=JSON.parse(await readFile(join(workspace,'native-attachment-media-proof.json'),'utf8'));
 assert.deepEqual(proof.attachments.map(row=>row.name),['release-cover.png','release-notes.pdf','release-analysis.ipynb']);assert.equal(proof.receipts.length,3);
 for(const [index,row]of proof.attachments.entries()){
  // The app proof records the original container path; a preserved workspace can be relocated.
  assert.ok(row.file.endsWith('/'+row.name));
  assert.ok(calls.some(call=>call.messages?.some(message=>message.role==='user'&&(typeof message.content==='string'?message.content:message.content.filter(block=>block.type==='text').map(block=>block.text).join('\n')).includes('[Attached file: '+row.file+']'))),'Original human attachment reference missing: '+row.name);
  const receipt=proof.receipts[index];assert.equal(receipt.name,row.name);assert.equal(receipt.type,['image','pdf','notebook'][index]);assert.ok(receipt.nativeResultUuid&&receipt.nativeAssistantUuid);
  const observed=JSON.parse(await readFile(join(workspace,'native-media-result-native_media_'+(index+1)+'.json'),'utf8'));assert.deepEqual(receipt.output,observed.props.output);
 }
 const delivery=await verifyNativeReadMediaResults(workspace,calls.filter(call=>call.mediaResult).map(call=>call.mediaResult));
 const paths=await readdir(join(workspace,'electron-results'),{recursive:true});
 for(let turn=1;turn<=3;turn++)for(const width of [1100,680]){
  const name='native-media-'+turn+'-'+width+'.png',matches=paths.filter(path=>path.endsWith('/'+name));assert.equal(matches.length,1,name);
  const png=await readFile(join(workspace,'electron-results',matches[0]));assert.equal(png.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(png.readUInt32BE(16),width);assert.equal(png.readUInt32BE(20),width===680?600:900);
 }
 const exits=(await readFile(join(workspace,'native-exits.jsonl'),'utf8')).trim().split('\n').map(line=>JSON.parse(line));assert.equal(exits.length,3);
 return {...delivery,attachmentReferences:true,originalResultProps:true,appCaptures:6,ownedNativeExits:exits.length};
}
