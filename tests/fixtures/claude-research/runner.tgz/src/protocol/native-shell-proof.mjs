import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Correlate desktop shell controls with original native history and public, read-only app DB receipts. */
export async function verifyNativeShellDesktop(root){
 const workspaces=join(root,'workspaces'),names=await readdir(workspaces);assert.equal(names.length,1);
 const workspace=join(workspaces,names[0]);
 const json=async path=>JSON.parse(await readFile(path,'utf8'));
 const lines=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').map(JSON.parse);
 const proof=await json(join(workspace,'native-task-manager-proof.json'));
 const evidence=await json(join(workspace,'native-terminal-app-evidence.json'));
 for(const key of ['desktopShell','childExited','sideEffectAbsent','ownerRetained','taskStoppedIndependently'])assert.equal(proof[key],true);
 assert.equal(evidence.actualAppGui,true);assert.equal(evidence.nativeShellDesktop,true);
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.equal(proof.managerStopKey,'desktop-stop');assert.deepEqual(proof.managerScreens.map(row=>row.width),[1100,680]);
 for(const screen of proof.managerScreens)assert.ok(screen.text.includes('Owned release review is waiting.'));
 assert.equal(proof.captures.length,3);for(const capture of proof.captures)assert.ok((await readFile(join(root,'captures',capture.file))).length>1000);
 assert.equal(proof.beforeTurns,proof.afterStopTurns);assert.equal(proof.continuedNativePid,proof.boundNativePid);assert.equal(proof.continuedTurns,proof.beforeTurns+1);
 assert.ok(proof.childRetiredAt>=proof.stoppedAt);
 const ready=await json(join(workspace,'native-active-bash-ready.json'));assert.deepEqual(proof.child,ready);
 const taskId=proof.backgroundReceipt.toolUseResult.backgroundTaskId;assert.ok(taskId);assert.equal(proof.backgroundReceipt.toolUseResult.backgroundedByTurnAbort,true);
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),prints=await lines('native-print-results.jsonl');
 assert.equal(children.length,3);assert.equal(exits.length,3);assert.equal(children[1].pid,proof.boundNativePid);
 for(const child of children){const exit=exits.find(row=>row.pid===child.pid);assert.ok(exit);assert.ok([0,143].includes(exit.code));assert.ok(exit.at>=child.at)}
 assert.ok(exits.find(row=>row.pid===children[0].pid).at<=children[1].at);assert.ok(exits.find(row=>row.pid===children[1].pid).at<=children[2].at);
 assert.equal(prints.length,2);assert.ok(prints.every(row=>row.sessionId===proof.sessionId));assert.deepEqual(prints.map(row=>row.pid),[children[0].pid,children[2].pid]);
 let native;for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{native=(await readFile(join(workspace,'.claude/projects',bucket,proof.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break}catch(error){if(error.code!=='ENOENT')throw error}}
 assert.ok(native);assert.ok(native.some(row=>row.uuid===proof.backgroundReceipt.uuid&&row.toolUseResult?.backgroundTaskId===taskId));
 const humans=native.filter(row=>row.type==='user'&&row.isMeta!==true&&row.isVirtual!==true&&typeof row.message?.content==='string');
 assert.deepEqual(humans.map(row=>row.message.content),['Review the release notes for this project.','ResearchPermissionTurn1 Review this project with the bounded native command.','ResearchPermissionTurn1 Continue the release review after native Pause.','Continue this saved review after cancelling active execution.']);
 assert.equal(new Set(humans.map(row=>row.uuid)).size,4);assert.ok(humans.every(row=>!row.message.content.includes(proof.draft)));
 const cost=native.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,prints.at(-1).totalCostUsd);assert.ok(cost>prints[0].totalCostUsd);
 const threads=await json(join(root,'app-cost-query-correct.stdout')),app=threads.filter(row=>row.claude?.sessionId===proof.sessionId);assert.equal(app.length,1);
 assert.equal(app[0].claude.totalCostUsd,cost);assert.equal(app[0].claude.turns,4);assert.equal(app[0].claude.toolCallCount,1);assert.equal(app[0].claude.chatState,'success');assert.equal(app[0].claude.isRunning,false);
 const messages=await json(join(root,'app-history-query.stdout'));
 for(const human of humans){const matched=messages.filter(row=>row.sender==='user'&&row.context?.cliUuid===human.uuid);assert.equal(matched.length,1);assert.equal(matched[0].text,human.message.content);assert.equal(matched[0].context.claudeNativeUserMessage.sessionId,proof.sessionId)}
 const calls=await json(join(workspace,'model-calls.json'));assert.equal(calls.seed.length,2);assert.equal(calls.agent.length,2);
 assert.ok(calls.agent.some(row=>JSON.stringify(row.messages).includes(taskId)));assert.ok(!JSON.stringify(calls).includes(proof.draft));
 const before=await json(join(root,'compiled-before.json')),after=await json(join(root,'compiled-after.json'));assert.deepEqual(after,before);
 const boundary=await json(join(root,'offline-boundary.json'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);assert.equal(boundary.memory,6*1024**3);assert.equal(boundary.memorySwap,boundary.memory);assert.equal(boundary.nanoCpus,2*10**9);assert.deepEqual(Object.keys(boundary.networks),['none']);
 return {desktopOutputAndStop:true,exactAppAndNativeHistory:true,appNativePrintCostMatched:true,cost,turns:4,taskId,ownedNativeExits:3,realModelRequests:0,screenshots:3};
}
