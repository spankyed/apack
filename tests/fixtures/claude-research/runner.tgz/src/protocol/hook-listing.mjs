import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,access} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Read native hook catalog/provenance without tools or prompts; verify source bytes and masked headers. */
export async function probeHookListing(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'hook-listing-')),cwd=join(workspace,'project'),home=join(workspace,'home');await mkdir(join(cwd,'.claude'),{recursive:true});await mkdir(join(home,'.claude'),{recursive:true});execFileSync('/usr/bin/git',['init','-q',cwd]);
 const paths=[join(home,'.claude','settings.json'),join(cwd,'.claude','settings.json'),join(cwd,'.claude','settings.local.json')],secret='synthetic-header-value-not-for-display',marker=join(workspace,'unexpected-hook-execution');
 const configs=[{hooks:{PreToolUse:[{matcher:'Read',hooks:[{type:'http',url:'https://example.invalid/hook',headers:{Authorization:secret}}]}]}},{hooks:{PreToolUse:[{matcher:'Write',hooks:[{type:'command',command:'/usr/bin/printf project > '+marker}]}]}},{hooks:{PreToolUse:[{matcher:'Edit',hooks:[{type:'command',command:'/usr/bin/printf local > '+marker}]}]}}];
 for(let i=0;i<paths.length;i++)await writeFile(paths[i],JSON.stringify(configs[i]));const before=await Promise.all(paths.map(path=>readFile(path,'utf8')));
 const run=await createRun(output,'hook-listing',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url)))}),cases=[];
 try{
  for(const mode of ['all-sources','user-only','bare','disabled']){
   let pending='',reply;
   const send=(id,request)=>JSON.stringify({type:'control_request',request_id:id,request})+'\n';
   const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources',mode==='user-only'?'user':'user,project,local','--strict-mcp-config','--tools','','--no-session-persistence',...(mode==='bare'?['--bare']:[]),'--settings',JSON.stringify({...(mode==='disabled'?{disableAllHooks:true}:{}),hooks:{PreToolUse:[{matcher:'Glob',hooks:[{type:'command',command:'/usr/bin/printf flag > '+marker}]}]}})],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[send('init',{subtype:'initialize'})],onStdout(bytes,channel){
    pending+=bytes.toString();while(pending.includes('\n')){const i=pending.indexOf('\n'),text=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(text)}catch{continue}
     if(value.type==='control_response'&&value.response?.request_id==='init'){assert.equal(value.response.subtype,'success');channel.send(send('hooks',{subtype:'get_hooks_listing'}));}
     if(value.type==='control_response'&&value.response?.request_id==='hooks'){reply=value.response;channel.closeInput();}
    }
   }});
   assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(reply?.subtype,'success');assert.ok(Array.isArray(reply.response.eventCatalog));assert.ok(reply.response.eventCatalog.some(value=>value.name==='PreToolUse'));assert.ok(Array.isArray(reply.response.hooks));assert.equal(JSON.stringify(reply.response).includes(secret),false);
   const listing=reply.response;
   assert.equal(listing.eventCatalog.length,33);
   assert.deepEqual(listing.hooks.map(value=>value.source).sort(),(mode==='user-only'?['userSettings','flagSettings']:['userSettings','projectSettings','localSettings','flagSettings']).sort());
   for(const row of listing.hooks){
    assert.equal(row.disabled===true,mode==='bare'||mode==='disabled');
    if(row.source==='flagSettings')assert.equal(row.editable,undefined);else assert.ok(row.editable?.config);
   }
   const http=listing.hooks.find(value=>value.source==='userSettings');assert.equal(http.editable.headersRedacted,true);assert.deepEqual(http.editable.config.headers,{Authorization:''});
   assert.equal(listing.policy.allDisabled,mode==='disabled');assert.equal(!!listing.bareMode,mode==='bare');
   assert.deepEqual(await Promise.all(paths.map(path=>readFile(path,'utf8'))),before);
   cases.push({mode,response:JSON.parse(JSON.stringify(reply.response).split(workspace).join('${WORKSPACE}'))});
  }
  await assert.rejects(access(marker),{code:'ENOENT'});
  const evidence={cases,modelPrompts:0,sourceFilesUnchanged:true,headerValueNotExposed:true,hookExecuted:false};await writeFile(join(run.directory,'hook-listing.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
