import { isAbsolute } from 'node:path';
/** Private bounded control receipts; observe existing traffic without changing dispatch or replies. */
export function nativeClientControlObserver(outputPath, {documents = false, dialogs = false} = {}) {
 if(!isAbsolute(outputPath))throw Error('Client observer needs an absolute private path');
 return `{
 const h=await import('node:http'),f=await import('node:fs'),requests=new WeakMap(),records=[];
 const emit=h.Server.prototype.emit,end=h.ServerResponse.prototype.end;
 h.Server.prototype.emit=function(event,...args){
  if(event==='request'&&args[0]?.url==='/control'){
   const request=args[0],chunks=[];let length=0;
   request.on('data',chunk=>{length+=chunk.length;if(length<=1048576)chunks.push(chunk)});
   request.on('end',()=>{try{const value=JSON.parse(Buffer.concat(chunks).toString()).request;if(['apack_ui_client','ui_press',...(${documents}?['ui_render']:[]),...(${dialogs}?['apack_answer_file_dialog','apack_answer_question_dialog']:[])].includes(value?.subtype))requests.set(request,{subtype:value.subtype,client_id:value.client_id,id:value.id,revision:value.revision,decision:value.decision,sequence:value.sequence,event:value.event,component:value.component,instance_id:value.instance_id,instance_revision:value.instance_revision,plugin:value.plugin,handle:value.handle,key:value.key})}catch{}});
  }
  return Reflect.apply(emit,this,[event,...args]);
 };
 h.ServerResponse.prototype.end=function(...args){
  try{const request=requests.get(this.req);if(request&&typeof args[0]==='string'&&args[0].length<=2097152){let response=JSON.parse(args[0]);if(request.subtype==='ui_render'){const nodes=[];function visit(node){if(!node||typeof node!=='object')return;nodes.push({type:node.type,text:node.props?.children,sourceLength:node.props?.source?.length,markdownLength:node.props?.text?.length});for(const child of node.children??[])visit(child)}visit(response.result?.tree);response={id:response.id,components:nodes,error:response.error}}records.push({at:Date.now(),request,status:this.statusCode,response});if(records.length>256)records.shift();f.writeFileSync(${JSON.stringify(outputPath)},JSON.stringify(records));}}catch{}
  return Reflect.apply(end,this,args);
 };
}\n`;
}
