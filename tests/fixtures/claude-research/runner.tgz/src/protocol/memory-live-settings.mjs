import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Compare acknowledged memory setting writes with a retained process's immediate views. */
export async function probeMemoryLiveSettings(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'memory-live-'));
 const cwd=join(workspace,'project'),home=join(workspace,'home'),config=join(home,'.claude');
 await mkdir(cwd,{recursive:true});await mkdir(config,{recursive:true});execFileSync('/usr/bin/git',['init','-q',cwd]);
 const settings=join(config,'settings.json');await writeFile(settings,JSON.stringify({language:'research-preserve'}));
 const env={PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
 const run=await createRun(output,'memory-live-settings',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url)))});
 try{
  let pending='';const replies=[],edits=[];
  const requests=[{subtype:'initialize',hooks:{}},{subtype:'get_memory_dialog'},{subtype:'get_settings'},{subtype:'get_memory_dialog'},{subtype:'get_settings'},{subtype:'get_memory_dialog'},{subtype:'get_settings'}];
  const line=i=>JSON.stringify({type:'control_request',request_id:`memory-live-${i}`,request:requests[i]})+'\n';
  const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user,project,local','--strict-mcp-config','--no-session-persistence'],env,input:[line(0)],onStdout(bytes,channel){
   pending+=bytes.toString('utf8');while(pending.includes('\n')){
    const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type!=='control_response'||value.response?.request_id!==`memory-live-${replies.length}`)continue;
    replies.push({request:requests[replies.length],response:value.response});
    if([3,5].includes(replies.length)){
     const edit={autoMemoryEnabled:replies.length===5};
     const stdout=execFileSync(executable,['edit-memory-settings','--json'],{cwd,env,input:JSON.stringify(edit)+'\n',timeout:5000,maxBuffer:65536});
     const response=JSON.parse(stdout.toString('utf8'));assert.equal(response.ok,true);
     const saved=JSON.parse(readFileSync(settings,'utf8'));assert.equal(saved.autoMemoryEnabled,edit.autoMemoryEnabled);assert.equal(saved.language,'research-preserve');
     edits.push({edit,response,settings:saved});
    }
    if(replies.length<requests.length)channel.send(line(replies.length));else channel.closeInput();
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(replies.length,7);assert.equal(edits.length,2);
  for(const item of replies)assert.equal(item.response.subtype,'success');
  const normalize=value=>JSON.parse(JSON.stringify(value).split(workspace).join('${WORKSPACE}'));
  const states=[1,3,5].map(index=>replies[index].response.response.auto_memory);
  const effective=[2,4,6].map(index=>replies[index].response.response.effective.autoMemoryEnabled??null);
  assert.deepEqual(states.map(state=>state.enabled),[true,false,true]);
  assert.deepEqual(effective,[null,false,true]);
  const result={replies:normalize(replies),edits,states,effective,modelPrompts:0,qualification:'Immediate idle reads after external writes only; no watcher settling delay, model turns, dream/generation effects or other policy/account cases.'};
  await writeFile(join(run.directory,'memory-live-settings.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',states,effective,modelPrompts:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
