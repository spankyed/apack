import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,access} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Exercise only the native hook settings writer in a disposable repository; never invoke a model/tool. */
export async function probeHookEdit(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'hook-edit-')),cwd=join(workspace,'project'),home=join(workspace,'home');await mkdir(join(cwd,'.claude'),{recursive:true});await mkdir(join(home,'.claude'),{recursive:true});execFileSync('/usr/bin/git',['init','-q',cwd]);
 const paths={userSettings:join(home,'.claude','settings.json'),projectSettings:join(cwd,'.claude','settings.json'),localSettings:join(cwd,'.claude','settings.local.json')};
 for(const[source,path]of Object.entries(paths))await writeFile(path,JSON.stringify({language:'research-'+source,permissions:{ask:['Glob']}}));
 const env={PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},cases=[];
 const run=await createRun(output,'hook-edit',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url)))});
 const snapshot=async()=>Object.fromEntries(await Promise.all(Object.entries(paths).map(async([source,path])=>[source,await readFile(path,'utf8')])));
 const normalize=value=>JSON.parse(JSON.stringify(value).split(workspace).join('${WORKSPACE}'));
 async function edit(label,input,expectedCode,extraArgs=[]){
  const before=await snapshot(),transport=await record({executable,cwd,output,timeoutMs:10000,args:[...extraArgs,'edit-hook','--json'],env,input:[JSON.stringify(input)+'\n']});
  const stdout=(await readFile(join(transport.directory,'stdout.bin'),'utf8')).trim(),after=await snapshot();const response=JSON.parse(stdout);
  assert.equal(transport.reason,undefined);assert.equal(transport.code,expectedCode===null?0:1);assert.equal(response.ok,expectedCode===null);if(expectedCode!==null){assert.equal(response.code,expectedCode);assert.deepEqual(after,before);}else for(const source of Object.keys(paths))if(source!==input.source)assert.equal(after[source],before[source]);
  for(const[source,bytes]of Object.entries(after)){const settings=JSON.parse(bytes);assert.equal(settings.language,'research-'+source);assert.deepEqual(settings.permissions,{ask:['Glob']});}
  cases.push(normalize({label,input,response,fileUnchanged:JSON.stringify(before)===JSON.stringify(after),settings:Object.fromEntries(Object.entries(after).map(([source,bytes])=>[source,JSON.parse(bytes)]))}));return JSON.parse(after[input.source]??'{}');
 }
 try{
  const original={type:'command',command:'/usr/bin/printf fixture > '+join(workspace,'unexpected-hook-execution')},replacement={type:'command',command:'/usr/bin/printf replaced > '+join(workspace,'unexpected-hook-execution')};
  for(const source of Object.keys(paths)){
   const target={event:'PreToolUse',matcher:'Read',hook:original};
   const added=await edit(source+' add',{op:'add',source,...target},null);assert.deepEqual(added.hooks.PreToolUse,[{matcher:'Read',hooks:[original]}]);
   await edit(source+' duplicate',{op:'add',source,...target},'duplicate');
   const replaced=await edit(source+' replace',{op:'replace',source,event:'PostToolUse',matcher:'Read',hook:replacement,target},null);assert.equal(replaced.hooks.PreToolUse,undefined);assert.deepEqual(replaced.hooks.PostToolUse,[{matcher:'Read',hooks:[replacement]}]);
   const removed=await edit(source+' remove',{op:'remove',source,event:'PostToolUse',matcher:'Read',target:{event:'PostToolUse',matcher:'Read',hook:replacement}},null);assert.equal(removed.hooks,undefined);
  }
  await edit('missing target',{op:'remove',source:'userSettings',event:'PreToolUse',target:{event:'PreToolUse',hook:original}},'target_missing');
  await edit('invalid source',{op:'add',source:'policySettings',event:'PreToolUse',hook:original},'bad_request');
  await edit('disabled source',{op:'add',source:'projectSettings',event:'PreToolUse',hook:original},'source_disabled',['--setting-sources','user']);
  const http={type:'http',url:'https://example.invalid/hook',headers:{Authorization:'synthetic-fixture-only'},researchMetadata:{preserve:true}};
  const user=JSON.parse(await readFile(paths.userSettings,'utf8'));await writeFile(paths.userSettings,JSON.stringify({...user,hooks:{PreToolUse:[{matcher:'Read',hooks:[http]}]}}));
  await edit('HTTP header-only twin',{op:'add',source:'userSettings',event:'PreToolUse',matcher:'Read',hook:{type:'http',url:http.url,headers:{Authorization:'different-synthetic-value'}}},'twin_by_headers');
  const masked={type:'http',url:http.url,headers:{Authorization:''}},httpReplacement={type:'http',url:'https://example.invalid/replaced',headers:{authorization:''}};
  const httpEdited=await edit('HTTP masked replacement',{op:'replace',source:'userSettings',event:'PreToolUse',matcher:'Read',hook:httpReplacement,target:{event:'PreToolUse',matcher:'Read',hook:masked}},null);
  assert.equal(httpEdited.hooks.PreToolUse[0].hooks[0].headers.authorization,'synthetic-fixture-only');assert.equal(httpEdited.hooks.PreToolUse[0].hooks[0].researchMetadata,undefined);
  await edit('HTTP masked removal',{op:'remove',source:'userSettings',event:'PreToolUse',matcher:'Read',target:{event:'PreToolUse',matcher:'Read',hook:{...httpReplacement,headers:{authorization:''}}}},null);
  const ambiguous=JSON.parse(await readFile(paths.userSettings,'utf8'));await writeFile(paths.userSettings,JSON.stringify({...ambiguous,hooks:{PreToolUse:[{hooks:[original,original]}]}}));
  await edit('ambiguous target',{op:'remove',source:'userSettings',event:'PreToolUse',target:{event:'PreToolUse',hook:original}},'target_ambiguous');
  await edit('prototype hook key',{op:'add',source:'userSettings',event:'PreToolUse',hook:JSON.parse('{"type":"command","command":"/usr/bin/true","__proto__":{}}')},'bad_request');
  await edit('invalid event',{op:'add',source:'userSettings',event:'NotANativeEvent',hook:original},'bad_request');
  await assert.rejects(access(join(workspace,'unexpected-hook-execution')),{code:'ENOENT'});
  const evidence={cases,modelPrompts:0,hookExecuted:false,qualification:'Native private hook writer and file readback only; hook firing, live refresh, managed policy, actual credentials, concurrency and app UI require separate verification.'};await writeFile(join(run.directory,'hook-edit.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',cases:cases.length,modelPrompts:0,hookExecuted:false};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
