import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { hash } from '../artifacts/runs.mjs';
import { record } from './record.mjs';

/** Observe fresh-home startup only. Never confirms a dialog or submits a model prompt. */
export async function probePtyStartup(executable, workspace, output) {
  if (process.platform !== 'darwin') throw new Error('PTY startup recipe is verified only on macOS');
  await mkdir(workspace, { recursive: true });
  const cwd = await mkdtemp(join(workspace, 'pty-startup-'));
  const bridge = fileURLToPath(new URL('./pty_bridge.py', import.meta.url));
  const targetSha256 = hash(await readFile(executable));
  const bridgeSha256 = hash(await readFile(bridge));
  let scheduled = false;
  const timers = [];
  try {
    const run = await record({ executable: '/usr/bin/python3', cwd, output, timeoutMs: 8000,
      args: [bridge, executable, '--bare', '--setting-sources', '', '--settings',
        JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' }),
        '--tools', '', '--strict-mcp-config'],
      env: { PATH: process.env.PATH, HOME: cwd, CLAUDE_CONFIG_DIR: join(cwd, '.claude'),
        TERM: 'xterm-256color', COLUMNS: '100', LINES: '30', ANTHROPIC_BASE_URL: 'http://127.0.0.1:9',
        DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
      onStdout(_bytes, transport) {
        if (scheduled) return;
        scheduled = true;
        timers.push(setTimeout(() => transport.send('\x03'), 1500));
        timers.push(setTimeout(() => { transport.send('\x03'); transport.closeInput(); }, 2200));
      },
    });
    const summary = { targetSha256, bridgeSha256, terminal: { columns: 100, rows: 30 },
      userPromptsSent: 0, stdoutIsMergedTargetTerminal: true,
      observedTerminalBytes: (await readFile(join(run.directory, 'stdout.bin'))).length,
      qualification: 'PTY startup and Ctrl-C only; timeout is a failed run, not completed terminal interaction.' };
    await writeFile(join(run.directory, 'pty-summary.json'), JSON.stringify(summary, null, 2) + '\n');
    return { ...run, ...summary };
  } finally { for (const timer of timers) clearTimeout(timer); }
}
