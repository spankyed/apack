import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,realpath} from 'node:fs/promises';
import {join,sep} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel,WORKFLOW_FIXTURE_SCRIPT,WORKFLOW_FAILURE_SCRIPT} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Fixed deterministic script only; no child agents, real model or account. */
export async function probeWorkflow(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'workflow-')),cases=[];
 const run=await createRun(output,'workflow',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),scriptSha256:hash(Buffer.from(WORKFLOW_FIXTURE_SCRIPT))});
 try{
  for(const decision of ['allow','deny','failure']){
   const cwd=join(workspace,decision),home=join(cwd,'home'),temporary=join(cwd,'tmp');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(temporary,{mode:0o700});
   const script=decision==='failure'?WORKFLOW_FAILURE_SCRIPT:WORKFLOW_FIXTURE_SCRIPT;
   const model=await startSyntheticModel(cwd,decision==='failure'?'WorkflowFailure':'Workflow'),permissions=[],toolResults=[],tasks=[],results=[],dialogs=[];let pending='',closed=false;
   const user=JSON.stringify({type:'user',message:{role:'user',content:'Execute only the fixed deterministic local Workflow fixture. Do not call agents or other tools.'}})+'\n';
   let transport;
   try{
    transport=await record({executable,cwd,output,timeoutMs:30000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--strict-mcp-config','--permission-mode','default','--tools','default','--model','default','--no-session-persistence','--max-turns','4'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),CLAUDE_CODE_TMPDIR:temporary,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[JSON.stringify({type:'control_request',request_id:'workflow-init',request:{subtype:'initialize'}})+'\n'],onStdout(bytes,channel){
     pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),line=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(line)}catch{continue}
      if(value.type==='control_response'&&value.response?.request_id==='workflow-init'){assert.equal(value.response.subtype,'success');channel.send(user);}
      if(value.type==='control_request'&&value.request?.subtype==='can_use_tool'){
       assert.equal(value.request.tool_name,'Workflow');assert.equal(value.request.input.script,script);permissions.push(value.request);
       channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:decision!=='deny'?{behavior:'allow',updatedInput:value.request.input}:{behavior:'deny',message:'Fixed fixture denies Workflow'}}})+'\n');
      }
      if(value.type==='control_request'&&value.request?.subtype==='request_user_dialog'){dialogs.push(value.request.dialog_kind);channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:{behavior:'cancelled'}}})+'\n');}
      if(value.type==='user'&&Array.isArray(value.message?.content))toolResults.push(...value.message.content.filter(block=>block.type==='tool_result'));
      if(value.type==='system'&&['task_started','task_progress','task_notification'].includes(value.subtype))tasks.push(value);
      if(value.type==='result')results.push(value);
      const terminalTask=tasks.some(value=>value.subtype==='task_notification');
      if(!closed&&results.length&&(terminalTask||!tasks.some(value=>value.subtype==='task_started'))){closed=true;channel.closeInput();}
     }
    }});
   }finally{await model.close();}
   assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.ok(results.length);assert.equal(dialogs.length,0);
   assert.ok(model.calls.some(call=>call.toolNames?.includes('Workflow')));assert.equal(permissions.length,1);assert.equal(toolResults.length,1);
   assert.ok(results.every(value=>value.subtype==='success'&&!value.is_error));
   let taskOutput;
   if(decision!=='deny'){
    assert.equal(toolResults[0].is_error,false);const started=tasks.filter(value=>value.subtype==='task_started'),finished=tasks.filter(value=>value.subtype==='task_notification');assert.equal(started.length,1);assert.equal(finished.length,1);assert.equal(started[0].task_type,'local_workflow');assert.equal(started[0].workflow_name,'research-native-workflow');assert.equal(finished[0].status,decision==='failure'?'failed':'completed');assert.equal(finished[0].task_id,started[0].task_id);assert.equal(finished[0].tool_use_id,permissions[0].tool_use_id);
    const scriptPath=toolResults[0].content.match(/^Script file: (.+)$/m)?.[1];assert.ok(scriptPath,'Workflow did not identify its persisted script');assert.ok((await realpath(scriptPath)).startsWith((await realpath(home))+sep),'Workflow script escaped private home');assert.equal(await readFile(scriptPath,'utf8'),script);
    const outputPath=await realpath(finished[0].output_file);assert.ok(outputPath.startsWith((await realpath(temporary))+sep),'Workflow output escaped private temporary root');
    const outputText=await readFile(outputPath,'utf8');
    if(decision==='failure'){
     assert.equal(outputText,'');assert.match(finished[0].summary,/NATIVE_WORKFLOW_FAILURE/);assert.equal(finished[0].usage.total_tokens,0);assert.equal(finished[0].usage.tool_uses,0);taskOutput={empty:true,bytes:0,nativeFailureMarkerRetained:true};
    }else{
     taskOutput=JSON.parse(outputText);assert.equal(taskOutput.agentCount,0);assert.deepEqual(taskOutput.result,{marker:'NATIVE_WORKFLOW_FIXTURE',answer:42});assert.deepEqual(taskOutput.logs,['NATIVE_WORKFLOW_FIXTURE']);assert.equal(taskOutput.totalToolCalls,0);assert.equal(taskOutput.totalTokens,0);assert.ok(taskOutput.workflowProgress.some(value=>value.type==='workflow_phase'&&value.title==='Fixture'));
    }
    assert.ok(tasks.some(value=>value.subtype==='task_progress'&&value.workflow_progress?.some(phase=>phase.type==='workflow_phase'&&phase.title==='Fixture')));
    assert.equal(model.calls.length,3);
   }else{assert.equal(toolResults[0].is_error,true);assert.match(toolResults[0].content,/Fixed fixture denies Workflow/);assert.equal(tasks.length,0);assert.equal(model.calls.length,2);}
   cases.push({decision,transportRun:transport.directory,taskOutput,persistedScriptVerified:decision!=='deny',offered:model.calls.some(call=>call.toolNames?.includes('Workflow')),permissions:permissions.map(value=>({toolName:value.tool_name,toolUseId:value.tool_use_id,input:value.input})),toolResults,tasks,results,modelCalls:model.calls,realModelRequests:0});
  }
  const evidence=JSON.parse(JSON.stringify({cases,qualification:'Fixed deterministic script; observed availability/approval/tool/task results only. No subagents, remote workflows, resume, named scripts, policy or app/mounted acceptance.'}).split(workspace).join('${WORKSPACE}'));
  await writeFile(join(run.directory,'workflow.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
