import assert from 'node:assert/strict';
import http from 'node:http';
import {readFileSync,appendFileSync} from 'node:fs';
import {join} from 'node:path';
import {syncBuiltinESMExports} from 'node:module';

/** Delay only the exact owned Stop body; never synthesize a request or alter native state. */
export function installWorkflowStopBarrier({workspace,httpModule=http,deadlineMs=4500,pollMs=2}){
 const original=httpModule.request;
 httpModule.request=function(...args){
  const request=Reflect.apply(original,this,args),options=args[0];
  if(options?.path!=='/control'||!/^\/(?:private\/)?tmp\/cc-app-[A-Za-z0-9_-]+\/ui[.]sock$/.test(options.socketPath??''))return request;
  const end=request.end;
  request.end=function(body,...rest){
   let envelope;try{envelope=JSON.parse(body);}catch{return Reflect.apply(end,this,[body,...rest]);}
   const operation=envelope.request;
   if(operation?.subtype!=='apack_task_control'||operation.operation!=='stop')return Reflect.apply(end,this,[body,...rest]);
   const target=operation.task_id,started=Date.now();let timer;
   const receipt=(stage,task)=>appendFileSync(join(workspace,'workflow-stop-delivery.jsonl'),JSON.stringify({stage,at:Date.now(),id:envelope.id,sessionId:envelope.sessionId,ownerPid:envelope.ownerPid,taskId:target,task})+'\n');
   receipt('held');
   const clear=()=>clearTimeout(timer);request.once('close',clear);
   const poll=()=>{
    if(request.destroyed)return;
    let task;try{task=JSON.parse(readFileSync(join(workspace,'native-workflow-state.json'),'utf8')).find(value=>value.id===target);}catch{}
    if(task?.status==='completed'&&task.settled===false){receipt('released',task);request.removeListener('close',clear);Reflect.apply(end,request,[body,...rest]);return;}
    if(Date.now()-started>=deadlineMs){receipt('expired',task);request.destroy(Error('Owned Workflow phase was not observed before transport deadline'));return;}
    timer=setTimeout(poll,pollMs);
   };poll();return request;
  };
  return request;
 };
 syncBuiltinESMExports();
 return ()=>{httpModule.request=original;syncBuiltinESMExports();};
}

/** Read-only native admission/reply audit. The original listener consumes and handles the body. */
export function observeWorkflowStops({directory,workspace,snapshot,httpModule=http}){
 assert.match(directory,/^\/(?:private\/)?tmp\/cc-app-[A-Za-z0-9_-]+$/);
 const config=JSON.parse(readFileSync(join(directory,'observer.json'),'utf8'));
 assert.equal(config.uiSocketPath,join(directory,'ui.sock'));
 const original=httpModule.createServer;
 httpModule.createServer=function(...args){
  const index=args.findIndex(value=>typeof value==='function');if(index<0)return Reflect.apply(original,this,args);
  const handler=args[index];let owned=false;
  args[index]=function(request,response){
   if(owned&&request.url==='/control'){
    const chunks=[];let bytes=0,admitted;
    request.on('data',chunk=>{bytes+=chunk.length;if(bytes<=1048576)chunks.push(chunk);});
    request.once('end',()=>{
     try{
      const body=JSON.parse(Buffer.concat(chunks));
      if(bytes>1048576||body.request?.subtype!=='apack_task_control'||body.request.operation!=='stop')return;
      admitted={id:body.id,sessionId:body.sessionId,ownerPid:body.ownerPid,taskId:body.request.task_id,at:Date.now(),pid:process.pid,task:snapshot(body.request.task_id)};
     }catch{}
    });
    const end=response.end;
    response.end=function(...values){
     if(admitted)try{appendFileSync(join(workspace,'native-workflow-stop-receipts.jsonl'),JSON.stringify({...admitted,repliedAt:Date.now(),status:response.statusCode,reply:JSON.parse(String(values[0]))})+'\n');}catch{}
     return Reflect.apply(end,this,values);
    };
   }
   return Reflect.apply(handler,this,[request,response]);
  };
  const server=Reflect.apply(original,this,args),listen=server.listen;
  server.listen=function(...values){owned=values[0]===config.uiSocketPath;return Reflect.apply(listen,this,values);};return server;
 };
 return ()=>{httpModule.createServer=original;};
}
