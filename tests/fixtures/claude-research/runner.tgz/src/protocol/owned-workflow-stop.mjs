import assert from 'node:assert/strict';
import http from 'node:http';
import {readFileSync,appendFileSync} from 'node:fs';
import {join} from 'node:path';
import {syncBuiltinESMExports} from 'node:module';
import {setTimeout as wait} from 'node:timers/promises';

/** Tag only the owned Stop for same-process delivery; preserve original body, identity and deadlines. */
export function tagWorkflowStopDelivery({workspace,httpModule=http}){
 const original=httpModule.request;
 httpModule.request=function(...args){
  const request=Reflect.apply(original,this,args),options=args[0];
  if(options?.path!=='/control'||!/^\/(?:private\/)?tmp\/cc-app-[A-Za-z0-9_-]+\/ui[.]sock$/.test(options.socketPath??''))return request;
  const end=request.end;
  request.end=function(body,...rest){
   let envelope;try{envelope=JSON.parse(body);}catch{return Reflect.apply(end,this,[body,...rest]);}
   const operation=envelope.request;
   if(operation?.subtype!=='apack_task_control'||operation.operation!=='stop')return Reflect.apply(end,this,[body,...rest]);
   const target=operation.task_id;
   const receipt=stage=>appendFileSync(join(workspace,'workflow-stop-delivery.jsonl'),JSON.stringify({stage,at:Date.now(),id:envelope.id,sessionId:envelope.sessionId,ownerPid:envelope.ownerPid,taskId:target})+'\n');
   request.setHeader('x-claude-research-workflow-stop',target);
   receipt('held');
   appendFileSync(join(workspace,'workflow-stop-held.jsonl'),JSON.stringify({id:envelope.id,sessionId:envelope.sessionId,ownerPid:envelope.ownerPid,taskId:target})+'\n');
   receipt('forwarded');return Reflect.apply(end,this,[body,...rest]);
  };
  return request;
 };
 syncBuiltinESMExports();
 return ()=>{httpModule.request=original;syncBuiltinESMExports();};
}

/** Queue only research-tagged delivery; native state and the original handler are never changed. */
export function holdAndObserveWorkflowStops({directory,workspace,snapshot,httpModule=http,deadlineMs=4500,pollMs=2}){
 assert.match(directory,/^\/(?:private\/)?tmp\/cc-app-[A-Za-z0-9_-]+$/);
 const config=JSON.parse(readFileSync(join(directory,'observer.json'),'utf8'));
 assert.equal(config.uiSocketPath,join(directory,'ui.sock'));
 const original=httpModule.createServer;
 httpModule.createServer=function(...args){
  const index=args.findIndex(value=>typeof value==='function');if(index<0)return Reflect.apply(original,this,args);
  const handler=args[index];let owned=false;
  args[index]=function(request,response){
   const receiver=this;
   const deliver=dispatchTask=>{
    if(owned&&request.url==='/control'){
     const chunks=[];let bytes=0,admitted;
     request.on('data',chunk=>{bytes+=chunk.length;if(bytes<=1048576)chunks.push(chunk);});
     request.once('end',()=>{
      try{
       const body=JSON.parse(Buffer.concat(chunks));
       if(bytes>1048576||body.request?.subtype!=='apack_task_control'||body.request.operation!=='stop')return;
       admitted={id:body.id,sessionId:body.sessionId,ownerPid:body.ownerPid,taskId:body.request.task_id,at:Date.now(),pid:process.pid,dispatchTask,task:snapshot(body.request.task_id)};
      }catch{}
     });
     const end=response.end;
     response.end=function(...values){
      if(admitted)try{appendFileSync(join(workspace,'native-workflow-stop-receipts.jsonl'),JSON.stringify({...admitted,repliedAt:Date.now(),after:snapshot(admitted.taskId),status:response.statusCode,reply:JSON.parse(String(values[0]))})+'\n');}catch{}
      return Reflect.apply(end,this,values);
     };
    }
    return Reflect.apply(handler,receiver,[request,response]);
   };
   const target=request.headers?.['x-claude-research-workflow-stop'];
   if(!owned||request.method!=='POST'||request.url!=='/control'||request.headers?.['x-apack-native-token']!==config.token||typeof target!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(target))return deliver();
   // Leave the IncomingMessage unread; the original async iterator consumes the original bytes on dispatch.
   request.pause();let timer;const deadline=Date.now()+deadlineMs;
   const cancel=()=>clearTimeout(timer);request.once('aborted',cancel);response.once('close',cancel);
   const poll=()=>{
    if(request.destroyed||response.destroyed)return;
    const task=snapshot(target);
    if(task?.type==='local_workflow'&&task.status==='completed'&&task.settled===false){
     request.off('aborted',cancel);response.off('close',cancel);return deliver(task);
    }
    if(Date.now()>=deadline){request.destroy(Error('Owned Workflow delivery phase expired'));response.destroy();return;}
    timer=setTimeout(poll,pollMs);
   };return poll();
  };
  const server=Reflect.apply(original,this,args),listen=server.listen;
  server.listen=function(...values){owned=values[0]===config.uiSocketPath;return Reflect.apply(listen,this,values);};return server;
 };
 return ()=>{httpModule.createServer=original;};
}

/** The owned model releases a real checkpoint only after an actual app Stop has been held. */
export async function waitForWorkflowStop(workspace,{signal,deadlineMs=30000}={}){
 const deadline=Date.now()+deadlineMs;
 while(Date.now()<deadline){
  signal?.throwIfAborted();
  let held,tasks;try{
   held=JSON.parse(readFileSync(join(workspace,'workflow-stop-held.jsonl'),'utf8').trim().split('\n').at(-1));
   tasks=JSON.parse(readFileSync(join(workspace,'native-workflow-state.json'),'utf8'));
  }catch{}
  if(held?.id&&held.sessionId&&Number.isInteger(held.ownerPid)&&tasks?.some(task=>task.id===held.taskId&&task.type==='local_workflow'&&task.status==='running'&&task.settled===false))return held;
  await wait(10,undefined,{signal});
 }
 throw Error('Owned Workflow checkpoint did not receive an actual app Stop');
}
