import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';
export const STRUCTURED_SCHEMA={type:'object',properties:{answer:{type:'integer'},marker:{type:'string',const:'STRUCTURED_FIXTURE'}},required:['answer','marker'],additionalProperties:false};

/** Fixed private schema validation and repair; no tools outside StructuredOutput or real model API. */
export async function probeStructuredOutput(executable,root,output,{repair=false,exhaust=false}={}){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'structured-output-')),home=join(workspace,'home'),cwd=join(workspace,'project');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(cwd);
 const run=await createRun(output,'structured-output',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),repair,exhaust,schema:STRUCTURED_SCHEMA});
 let model,pending='',initialized=false;const permissions=[],results=[],assistant=[],toolResults=[];
 try{
  model=await startSyntheticModel(cwd,exhaust?'StructuredInvalid':repair?'StructuredRepair':'StructuredOutput',{maxRequests:8});
  const transport=await record({executable,cwd,output,timeoutMs:30000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--strict-mcp-config','--tools','','--model','sonnet','--no-session-persistence','--max-turns','8','--json-schema',JSON.stringify(STRUCTURED_SCHEMA)],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',...(exhaust?{MAX_STRUCTURED_OUTPUT_RETRIES:'2'}:{})},input:[JSON.stringify({type:'control_request',request_id:'structured-init',request:{subtype:'initialize'}})+'\n'],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type==='control_response'&&value.response?.request_id==='structured-init'){assert.equal(value.response.subtype,'success');initialized=true;channel.send(JSON.stringify({type:'user',message:{role:'user',content:'Return the fixed structured fixture only.'}})+'\n');}
    if(value.type==='control_request'&&value.request?.subtype==='can_use_tool'){permissions.push(value.request.tool_name);assert.equal(value.request.tool_name,'StructuredOutput');channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:{behavior:'allow',updatedInput:value.request.input}}})+'\n');}
    if(value.type==='assistant')assistant.push(...(value.message?.content??[]));
    if(value.type==='user')toolResults.push(...(value.message?.content??[]).filter(block=>block.type==='tool_result'));
    if(value.type==='result'){results.push(value);channel.closeInput();}
   }
  }});
  assert.equal(transport.status,exhaust?'failed':'complete');assert.equal(transport.code,exhaust?1:0);assert.equal(initialized,true);assert.equal(results.length,1);assert.equal(results[0].subtype,exhaust?'error_max_structured_output_retries':'success');assert.equal(results[0].is_error,exhaust);if(exhaust){assert.equal(results[0].structured_output,undefined);assert.ok(results[0].errors?.length);}else assert.deepEqual(results[0].structured_output,{answer:42,marker:'STRUCTURED_FIXTURE'});
  assert.equal(model.calls.length,(repair||exhaust)?2:1);assert.equal(assistant.filter(block=>block.type==='tool_use'&&block.name==='StructuredOutput').length,(repair||exhaust)?2:1);
  if(repair)assert.ok(toolResults.some(result=>result.tool_use_id==='structured_fixture_1'&&result.is_error));
  const evidence={repair,exhaust,permissions,assistant,toolResults,terminal:{subtype:results[0].subtype,is_error:results[0].is_error,result:results[0].result,errors:results[0].errors,structured_output:results[0].structured_output},modelCalls:model.calls,realModelRequests:0,qualification:'Private Sonnet structured output and optional invalid-then-valid repair only; no real API, unbounded/default retry policy, providers, app or mounted UI claims.'};
  await writeFile(join(run.directory,'structured-output.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await writeFile(join(run.directory,'failed-observations.json'),JSON.stringify({permissions,assistant,toolResults,results,modelCalls:model?.calls??[]},null,2)+'\n');await run.finish({status:'failed',error:error.message});throw error;}finally{await model?.close();}
}
