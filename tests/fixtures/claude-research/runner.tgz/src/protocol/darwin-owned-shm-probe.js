// Private Darwin arm64 reader probe; publisher creates the object in another process.
// Darwin SDK sys/stat.h __DARWIN_STRUCT_STAT64: st_size is at byte96.
ObjC.import('Foundation');
ObjC.bindFunction('shm_open',['int',['char *','int']]);
ObjC.bindFunction('shm_unlink',['int',['char *']]);
ObjC.bindFunction('fstat',['int',['int','void *']]);
ObjC.bindFunction('mmap',['void *',['void *','unsigned long','int','int','int','long long']]);
ObjC.bindFunction('mprotect',['int',['void *','unsigned long','int']]);
ObjC.bindFunction('munmap',['int',['void *','unsigned long']]);
ObjC.bindFunction('close',['int',['int']]);
function run(argv){
 var name=argv[0],fd=-1,mapping,result;
 if(!/^\/apack_cc_probe_[a-z0-9]{8}$/.test(name))throw Error('Private probe name required');
 try{
  fd=$.shm_open(name,0);if(fd<0)throw Error('Read-only open failed');
  var stat=$.NSMutableData.dataWithLength(256);if($.fstat(fd,stat.mutableBytes)!==0)throw Error('Stat failed');
  mapping=$.mmap(null,4,1,1,fd,0);if($.mprotect(mapping,4,1)!==0)throw Error('Read-only mapping failed');
  var pixels=$.NSData.dataWithBytesLength(mapping,4);
  result={sizeBytes:ObjC.unwrap(stat.subdataWithRange({location:96,length:8}).base64EncodedStringWithOptions(0)),base64:ObjC.unwrap(pixels.base64EncodedStringWithOptions(0))};
 }finally{if(mapping)$.munmap(mapping,4);if(fd>=0)$.close(fd);}
 if($.shm_unlink(name)!==0)throw Error('Private consumed object unlink failed');
 return JSON.stringify(result);
}
