import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {join,isAbsolute,basename} from 'node:path';

export const CREDIT_ACCOUNT_ID='11111111-1111-4111-8111-111111111111';
export const CREDIT_ORGANIZATION_ID='22222222-2222-4222-8222-222222222222';
export const CREDIT_SYNTHETIC_TOKEN='research-only-credit-account-token';
/** Original inputs in a disposable home; no developer overrides, predicate patches or real credentials. */
export async function configureNativeCreditAccount(workspace,profile='oauth'){
 assert.ok(isAbsolute(workspace));assert.match(basename(workspace),/^(native-credit-admission-|apack-terminal-owner-app-)/,'Disposable owned fixture required');assert.ok(['oauth','api-key'].includes(profile));
 const directory=join(workspace,'.claude');await mkdir(directory,{recursive:true});
 const path=join(directory,'.claude.json');let config;
 try{config=JSON.parse(await readFile(path,'utf8'));}catch(error){if(error.code!=='ENOENT')throw error;config={};}
 assert.equal(config.oauthAccount,undefined,'Refuse replacing an existing account');
 assert.equal(config.growthBookOverrides,undefined);assert.equal(config.cachedGrowthBookFeatures,undefined,'Use a fresh owned profile');
 config.oauthAccount={accountUuid:CREDIT_ACCOUNT_ID,organizationUuid:CREDIT_ORGANIZATION_ID,emailAddress:'credit-review@example.test',billingType:'stripe_subscription',hasExtraUsageEnabled:false};
 config.cachedGrowthBookFeatures={tengu_ember_latch:true,tengu_saffron_lattice:{enabled:true,overageConsentRequired:true}};
 await writeFile(path,JSON.stringify(config,null,2)+'\n',{mode:0o600});
 try{await writeFile(join(directory,'settings.json'),JSON.stringify({theme:'dark'})+'\n',{mode:0o600,flag:'wx'});}catch(error){if(error.code!=='EEXIST')throw error;}
 return {HOME:workspace,CLAUDE_CONFIG_DIR:directory,...profile==='oauth'?{CLAUDE_CODE_OAUTH_TOKEN:CREDIT_SYNTHETIC_TOKEN,CLAUDE_CODE_SUBSCRIPTION_TYPE:'pro',CLAUDE_CODE_OAUTH_SCOPES:'user:inference user:profile'}:{ANTHROPIC_API_KEY:'research-only-credit-api-key'}};
}

/** Read original admission functions only; never mount a component or invoke a billing writer. */
export function nativeCreditAdmissionObserver(outputPath,hashes,{billingReads=false}={}){
 assert.ok(isAbsolute(outputPath));assert.equal(typeof hashes,'object');
 return `{
 const {readFileSync,writeFileSync}=await import('node:fs');const {createHash}=await import('node:crypto');
 const sha=value=>createHash('sha256').update(value).digest('hex');
 if(process.platform!=='linux'||sha(readFileSync(process.execPath))!=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10')throw Error('Pinned Linux credit admission target required');
 const expected=${JSON.stringify(hashes)},billingReads=${JSON.stringify(billingReads)};let attempts=0,busy=false,last;
 const timer=setInterval(async()=>{if(busy)return;busy=true;try{
  if(++attempts>160){clearInterval(timer);writeFileSync(${JSON.stringify(outputPath+'.error')},JSON.stringify({attempts,error:last}));return;}
  const source=await import('/$bunfs/root/chunk-tm94jfk2.js');source.ue();const credentials=source.Fn();
  const consent=await import('/$bunfs/root/chunk-9gw2deqq.js'),inline=await import('/$bunfs/root/chunk-437jhwmx.js'),models=await import('/$bunfs/root/chunk-25pk6nzd.js');
  for(const [name,fn]of Object.entries({E:source.E,Fn:source.Fn,LO:source.LO,eje:consent.eje,y4t:inline.y4t,Toe:models.Toe})){if(typeof fn!=='function'||sha(Function.prototype.toString.call(fn))!==expected[name])throw Error('Original credit admission function changed: '+name);}
  const billing=source.E('tengu_saffron_lattice',{}),latch=source.E('tengu_ember_latch',false);
  const receipt={pid:process.pid,uid:process.getuid(),attempts,platform:process.platform,binarySha256:sha(readFileSync(process.execPath)),featureInputs:{billing,latch},oauthPresent:typeof credentials?.accessToken==='string',scopes:credentials?.scopes??[],subscriptionType:credentials?.subscriptionType??null,accountEligible:source.LO(),modelUsesCreditBilling:consent.eje('Fable'),requiresCreditConsent:models.Toe('fable'),inlinePurchaseEligible:inline.y4t(),functionHashes:expected,observerWrites:billingReads?'Owned evidence and original read-only billing calls only; no native setters, component/testing shortcuts or billing writers.':'Owned evidence only; no native setters, component/testing shortcuts, account writers or billing calls.'};
  if(billingReads&&receipt.oauthPresent){
   const api=await import('/$bunfs/root/chunk-a7b8k0bt.js');
   receipt.billingReads={balance:await api.QAe(),bundles:await api.fms(),paymentMethod:await api.mms(),tax:await api.olo(7500,'USD','prod_owned_credit')};
  }
  writeFileSync(${JSON.stringify(outputPath)},JSON.stringify(receipt,null,2));clearInterval(timer);
 }catch(error){last=String(error);}finally{busy=false;}},50);timer.unref();
}`;
}
