import assert from 'node:assert/strict'
import { request } from 'node:http'
import { pipeline } from 'node:stream/promises'
import { CREDIT_SYNTHETIC_TOKEN } from './native-credit-account.mjs'

export function isolatedModelGateway(model, requests) {
  return async (incoming, outgoing) => {
    const parsed = new URL(incoming.url, 'https://api.anthropic.com')
    const path = parsed.pathname
    if (incoming.method !== 'POST' || !['/v1/messages','/v1/messages/count_tokens'].includes(path)) return false
    assert.equal(incoming.headers.host, 'api.anthropic.com')
    assert.equal(incoming.headers.authorization, 'Bearer ' + CREDIT_SYNTHETIC_TOKEN)
    assert.ok(requests.length < 12)
    requests.push({ method: incoming.method, path, at: Date.now() })
    await new Promise((resolve,reject) => {
      const target = new URL(model.url)
      target.pathname = path
      target.search = parsed.search
      const upstream = request(target, { method: 'POST',
        headers: { 'content-type': incoming.headers['content-type'] ?? 'application/json' }, timeout: 8000 })
      upstream.once('error', reject)
      upstream.once('timeout', () => upstream.destroy(Error('Owned model gateway timeout')))
      upstream.once('response', response => {
        outgoing.writeHead(response.statusCode, response.headers)
        void pipeline(response,outgoing).then(resolve,reject)
      })
      void pipeline(incoming,upstream).catch(reject)
    })
    return true
  }
}
