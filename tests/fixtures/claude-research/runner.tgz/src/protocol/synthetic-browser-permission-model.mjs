import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
export const browserReviewSeed='Review the release browser permissions.';
export const browserReviewFollowup='Continue the release review after the browser decisions.';
export const browserReviewCases=[
 {tag:'deny',prompt:'Check the release page before changing it.',url:'https://release-review.example/deny',decision:'browser_deny'},
 {tag:'allow',prompt:'Read this release page once.',url:'https://release-review.example/once',decision:'browser_allow'},
 {tag:'domain',prompt:'Review release pages for this session.',url:'https://release-review.example/remember',decision:'browser_domain'},
 {tag:'reuse',prompt:'Read the next release page with the session permission.',url:'https://release-review.example/follow'},
 {tag:'cancel',prompt:'Check a different release page before continuing.',url:'https://cancel-review.example/cancel',decision:'browser_cancel'},
];
const tool='mcp__claude-in-chrome__navigate';
export async function startBrowserPermissionModel({maxRequests}){
 assert.equal(process.platform,'linux');assert.ok(Number.isInteger(maxRequests)&&maxRequests>0&&maxRequests<=24);const calls=[];let pending,closed=false;
 const text=row=>typeof row.content==='string'?row.content:row.content?.filter(b=>b.type==='text').map(b=>b.text).join('')??'';
 const server=createServer(async(req,res)=>{try{
  const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;assert.ok(size<=4*1048576);chunks.push(chunk)}const body=JSON.parse(Buffer.concat(chunks)),path=req.url??'/';assert.equal(path.split('?')[0],'/v1/messages');assert.ok(calls.length<maxRequests);const call={path,model:body.model,toolNames:(body.tools??[]).map(t=>t.name),messages:body.messages,messageCount:body.messages?.length};calls.push(call);
  const title=body.messages?.length===1&&body.messages[0].role==='user'&&text(body.messages[0]).startsWith('<session>\n');let block,stop='end_turn';
  if(title){assert.equal(body.model,'claude-haiku-5-5');assert.equal(call.toolNames.length,0);const input=[browserReviewSeed,browserReviewFollowup,...browserReviewCases.map(v=>v.prompt)].find(s=>text(body.messages[0]).startsWith('<session>\n'+s+'\n</session>\n\n'));assert.ok(input);const rest=text(body.messages[0]).slice(('<session>\n'+input+'\n</session>\n\n').length);assert.equal(createHash('sha256').update(rest).digest('hex'),'30704b4d05983bebf62600d91882d0f6c98a0748dc7ae578cece46864bb0f515');call.nativeTitle=true;block={type:'text',text:'Release browser review'};}
  else{const prompts=[browserReviewSeed,browserReviewFollowup,...browserReviewCases.map(v=>v.prompt)],latest=[...body.messages].reverse().find(m=>m.role==='user'&&prompts.some(p=>text(m).includes(p))),prompt=prompts.find(p=>text(latest??{}).includes(p));assert.ok(prompt,'Unknown browser fixture input');call.prompt=prompt;const step=browserReviewCases.find(v=>v.prompt===prompt),results=body.messages.flatMap(m=>Array.isArray(m.content)?m.content.filter(b=>b.type==='tool_result'):[]),result=step&&results.find(r=>r.tool_use_id==='browser_'+step.tag);
   if(!step||result){if(result)call.browserResult=result;block={type:'text',text:!step?(prompt===browserReviewFollowup?'The browser review continued in the same session.':'Ready to continue the release review.'):result.is_error?'The browser request was not executed.':'The browser review is complete.'};}
   else if(!call.toolNames.includes(tool)){assert.ok(call.toolNames.includes('ToolSearch'),'Native browser tool and search are unavailable');assert.ok(!results.some(r=>r.tool_use_id==='browser_search_'+step.tag),'Native discovery did not admit the browser namespace');block={type:'tool_use',id:'browser_search_'+step.tag,name:'ToolSearch',input:{query:'select:'+tool,max_results:1}};stop='tool_use';}
   else{assert.ok(!pending);call.browserStep=step.tag;block={type:'tool_use',id:'browser_'+step.tag,name:tool,input:{url:step.url}};stop='tool_use';await new Promise(resolve=>{pending={tag:step.tag,resolve};res.once('close',()=>{if(pending?.resolve===resolve){call.cancelledBeforeDelivery=true;pending=undefined;resolve();}})});if(res.destroyed)return;}
  }
  res.writeHead(200,{'content-type':'text/event-stream'});const send=(type,value)=>res.write('event: '+type+'\ndata: '+JSON.stringify({type,...value})+'\n\n');send('message_start',{message:{id:'browser_message_'+calls.length,type:'message',role:'assistant',model:body.model,content:[],stop_reason:null,usage:{input_tokens:10,output_tokens:0}}});send('content_block_start',{index:0,content_block:block.type==='tool_use'?{...block,input:{}}:{type:'text',text:''}});send('content_block_delta',{index:0,delta:block.type==='tool_use'?{type:'input_json_delta',partial_json:JSON.stringify(block.input)}:{type:'text_delta',text:block.text}});send('content_block_stop',{index:0});send('message_delta',{delta:{stop_reason:stop,stop_sequence:null},usage:{output_tokens:5}});send('message_stop',{});res.end();
 }catch(error){calls.push({fixtureError:error.message});if(!res.headersSent)res.writeHead(400,{'content-type':'application/json'});res.end('{}');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 return{url:'http://127.0.0.1:'+server.address().port,calls,get waiting(){return pending?.tag},release(tag){assert.equal(pending?.tag,tag);const done=pending.resolve;pending=undefined;done()},async close(){if(closed)return;closed=true;pending?.resolve();pending=undefined;server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}};
}
