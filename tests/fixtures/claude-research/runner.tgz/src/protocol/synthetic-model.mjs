import { genericPermissionSteps } from './native-generic-permission-fixture.mjs';
import { toolPermissionSteps } from './native-tool-permission-fixture.mjs';
import {nativeNotebookSteps} from './native-notebook-edit-fixture.mjs';
import {resourceSteps,directoryStep} from './mcp-resource-fixture.mjs';
import {access,writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import http from 'node:http';
import { join } from 'node:path';

export const WORKFLOW_FIXTURE_SCRIPT = 'export const meta = { name: "research-native-workflow", description: "Fixed arithmetic fixture", phases: [{title:"Fixture"}] };\nphase("Fixture");\nlog("NATIVE_WORKFLOW_FIXTURE");\nreturn {marker:"NATIVE_WORKFLOW_FIXTURE",answer:42};\n';

export const WORKFLOW_FAILURE_SCRIPT = WORKFLOW_FIXTURE_SCRIPT.replace('return {marker:"NATIVE_WORKFLOW_FIXTURE",answer:42};', 'throw new Error("NATIVE_WORKFLOW_FAILURE");');

export const WORKFLOW_WAIT_SCRIPT = WORKFLOW_FIXTURE_SCRIPT.replace('return {marker:"NATIVE_WORKFLOW_FIXTURE",answer:42};', 'await new Promise(() => {});');

const shellQuote = value => "'" + value.replaceAll("'", "'\"'\"'") + "'";

export const BASH_RELEASE_SCRIPT = 'import pathlib,time\np=pathlib.Path(__file__).with_name("native-bash-release");end=time.monotonic()+15\nwhile not p.exists() and time.monotonic()<end: time.sleep(0.05)\n';

/** Fixed local model fixture. It emits a harmless tool call; it never calls an upstream API. */
export async function startSyntheticModel(workspace, toolName = 'Bash', {expectedCronJobId,cronExpression,planText,questionFirst=false,forceBash=false,bashStandingRule=false,bashPerInput=false,bashDelayMs=0,bashReleaseFile,maxRequests=8,captureMessages=false,captureSystem=false,mcpResources=false,mcpResourceDirectory=false,captureThinking=false,captureEffort=false,queuedSchemaBarrier=false,questionWizard=false,questionFormControls=false,questionExtended=false,pairedText=false,focusContextTool=false,thinkingBlock=false,narration=false,thinkingCycles=0,textReply,readMedia=false,readMediaPages=false,directoryReadFiles,heldModel=false,heldModelStreaming=false,heldModelRich=false,notebookEdits=false,toolPermissions=false,genericPermissions=false}  = {}) {
  if(typeof notebookEdits!=='boolean'||notebookEdits&&toolName!=='TextOnly')throw Error('Notebook edits require the text fixture');
  if(typeof heldModel!=='boolean'||heldModel&&toolName!=='TextOnly')throw Error('Held model requires text-only fixture');
  if(typeof heldModelStreaming!=='boolean'||heldModelStreaming&&!heldModel)throw Error('Streaming model requires held model fixture');
  if(typeof heldModelRich!=='boolean'||heldModelRich&&!heldModelStreaming)throw Error('Rich preview requires the held streaming fixture');
  if(directoryReadFiles!==undefined&&(!Array.isArray(directoryReadFiles)||directoryReadFiles.length!==2||toolName!=='TextOnly'||directoryReadFiles.some(file=>typeof file!=='string'||file.length>4096||!file.startsWith(join(workspace,'..')+'/native-reference-outside-')||!file.endsWith('/native-reference.txt'))))throw Error('Invalid owned staged-directory fixture');
  if(typeof readMediaPages!=='boolean'||readMediaPages&&!readMedia)throw Error('PDF pages require the media fixture');
  if(typeof readMedia!=='boolean'||readMedia&&toolName!=='TextOnly')throw Error('Read media requires the bounded text fixture');
  if(textReply!==undefined&&(toolName!=='TextOnly'||typeof textReply!=='string'||!textReply.length||textReply.length>2000))throw new Error('Invalid bounded text reply');
  if(planText!==undefined&&(toolName!=='TuiPlan'||typeof planText!=='string'||planText.length>200001))throw Error('Invalid bounded plan fixture text');
  if(!Number.isSafeInteger(thinkingCycles) || thinkingCycles < 0 || thinkingCycles > 2 || thinkingCycles && (toolName !== 'TextOnly' || !thinkingBlock || !narration || pairedText))throw new Error('Thinking cycles require narration-only text fixture and at most two tools');
  if(typeof narration !== 'boolean' || narration && !thinkingBlock)throw new Error('Narration requires the thinking fixture');
  if(typeof thinkingBlock !== 'boolean')throw new Error('Thinking summary fixture must be boolean');
  if(typeof pairedText !== 'boolean' || pairedText && toolName !== 'TextOnly')throw new Error('Paired text requires the text-only fixture');
  if(typeof questionExtended!=='boolean'||questionExtended&&toolName!=='AskUserQuestion')throw new Error('Extended questions require the fixed question tool');
  if(typeof questionFormControls !== 'boolean' || questionFormControls && !questionWizard)throw new Error('Question form controls require the fixed wizard fixture');
  if(typeof questionWizard !== 'boolean' || questionWizard && toolName !== 'AskUserQuestion')throw new Error('Question wizard requires the fixed question fixture');
  if(typeof queuedSchemaBarrier!=='boolean'||queuedSchemaBarrier&&toolName!=='StructuredOutput')throw new Error('Queue barrier requires the fixed structured fixture');
  if(typeof mcpResourceDirectory!=='boolean'||mcpResourceDirectory&&!mcpResources)throw new Error('Directory fixture requires MCP resources');
  if(typeof mcpResources!=='boolean'||mcpResources!==(toolName==='ListMcpResourcesTool'))throw new Error('MCP resources require the fixed resource fixture');
  if (typeof captureSystem !== 'boolean') throw new Error('Invalid system capture option');
  if (typeof captureMessages !== 'boolean') throw new Error('Invalid message capture option');
  if (typeof captureEffort !== 'boolean') throw new Error('Invalid effort capture option');
  if (typeof captureThinking !== 'boolean') throw new Error('Invalid thinking capture option');
  if (!['StructuredOutput', 'StructuredRepair', 'StructuredInvalid', 'TaskDeletion', 'TaskLifecycle', 'WorkflowWait', 'WorkflowFailure', 'Workflow', 'Refusal', 'TuiPlan', 'WakeupFire', 'WakeupLifecycle', 'TextOnly', 'Bash', 'AskUserQuestion', 'EnterPlanMode', 'ExitPlanMode', 'mcp__research__echo', 'ListMcpResourcesTool', 'BashBackground', 'Edit', 'CronLifecycle', 'CronCreateOnly', 'CronListOnly', 'CronResumeCleanup', 'CronFire'].includes(toolName)) throw new Error('Unsupported synthetic tool');
  if (!Number.isSafeInteger(maxRequests) || maxRequests < 1 || maxRequests > 32) throw new Error('Fixture request bound must be an integer from 1 to 32');
  if (typeof bashPerInput !== 'boolean' || (bashPerInput && (toolName !== 'Bash' || !forceBash))) throw new Error('Per-input Bash requires forced Bash');
  if (!Number.isSafeInteger(bashDelayMs) || bashDelayMs < 0 || bashDelayMs > 5000 || (bashDelayMs && !forceBash)) throw new Error('Invalid bounded Bash delay');
  if(bashReleaseFile!==undefined&&(typeof bashReleaseFile!=='string'||!forceBash||bashReleaseFile!==join(workspace,'native-bash-release')))throw new Error('Invalid private Bash release barrier');
  if(typeof bashStandingRule!=='boolean'||bashStandingRule&&!forceBash)throw new Error('Standing-rule fixture requires forced Bash');
  const standingCommand=shellQuote(process.execPath)+' -e '+shellQuote("require('node:fs').writeFileSync("+JSON.stringify(join(workspace,'fixture.txt'))+",'synthetic protocol fixture\\n')");
  const bashWait=bashReleaseFile?'/usr/bin/python3 '+shellQuote('./native-bash-wait.py')+'; ':'';
  if (typeof forceBash !== 'boolean' || (forceBash && toolName !== 'Bash')) throw new Error('Forced Bash requires the fixed Bash fixture');
  if (typeof questionFirst !== 'boolean' || (questionFirst && toolName !== 'CronFire')) throw new Error('Question-first fixture requires CronFire');
  if (expectedCronJobId !== undefined && !/^[a-f0-9]{8}$/.test(expectedCronJobId)) throw new Error('Invalid fixture cron job ID');
  const actualToolName = ['WorkflowWait', 'WorkflowFailure'].includes(toolName) ? 'Workflow' : toolName === 'TuiPlan' ? 'ExitPlanMode' : toolName === 'BashBackground' ? 'Bash' : toolName;
  const calls = [];
  let sequence = 0, tuiPlanExitIssued = false;
  const server = http.createServer((req, res) => {
    respond(req, res).catch(error => {
      if(['TaskLifecycle','TaskDeletion'].includes(toolName)&&calls.length) calls.at(-1).fixtureError=error.message;
      if (!res.headersSent) res.writeHead(400, { 'content-type': 'application/json' });
      res.end('{"error":{"type":"invalid_request_error","message":"Invalid synthetic request"}}');
    });
  });
  server.requestTimeout = 5000;

  async function respond(req, res) {
    let bytes = 0;
    const chunks = [];
    for await (const chunk of req) {
      bytes += chunk.length;
      if (bytes > 2 * 1024 * 1024) {
        res.writeHead(413); res.end(); return;
      }
      chunks.push(chunk);
    }
    const body = JSON.parse(Buffer.concat(chunks).toString() || '{}');
    calls.push({ path: req.url, model: body.model,
      toolNames: body.tools?.map(tool => tool.name), messageCount: body.messages?.length });
    if (captureMessages) calls.at(-1).messages = body.messages ?? [];
    if (captureSystem) calls.at(-1).system = body.system ?? null;
    if (captureThinking) calls.at(-1).thinking = body.thinking ?? null;
    if (captureEffort) calls.at(-1).effort = body.output_config?.effort ?? null;
    if (req.url?.includes('count_tokens')) {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end('{"input_tokens":10}'); return;
    }
    if (!req.url?.startsWith('/v1/messages')) { res.writeHead(404); res.end('{}'); return; }
    if (++sequence > maxRequests) { res.writeHead(429); res.end('{}'); return; }
    if(queuedSchemaBarrier&&sequence===1){
      const deadline=Date.now()+5000;let ready=false;
      while(Date.now()<deadline){try{await access(join(workspace,'queued-schema-ready'));ready=true;break}catch(error){if(error.code!=='ENOENT')throw error}await delay(10);}
      if(!ready)throw new Error('Queued schema fixture did not reach its input barrier');
      calls.at(-1).queueBarrierReleased=true;
    }
    const fixtureTurn = bashPerInput ? body.messages?.flatMap(message => typeof message.content === 'string' ? [message.content] : message.content?.filter(block => block.type === 'text').map(block => block.text) ?? []).join('\n').match(/ResearchPermissionTurn[1234]/g)?.at(-1)?.slice(-1) : undefined;
    if (bashPerInput && !fixtureTurn) throw new Error('Missing bounded permission turn marker');
    const toolUseId = bashPerInput ? `toolu_research_fixture_${fixtureTurn}` : 'toolu_research_fixture';
    if (bashPerInput) calls.at(-1).fixtureTurn = Number(fixtureTurn);
    const hasResult = body.messages?.some(message => Array.isArray(message.content)
      && message.content.some(block => block.type === 'tool_result' && block.tool_use_id === toolUseId));
    const searched = body.messages?.some(message => Array.isArray(message.content)
      && message.content.some(block => block.type === 'tool_result' && block.tool_use_id === 'toolu_search_fixture'));
    const search = toolName === 'ExitPlanMode' && !hasResult && !searched
      && !body.tools?.some(tool => tool.name === actualToolName) && body.tools?.some(tool => tool.name === 'ToolSearch');
    const results = body.messages?.flatMap(message => Array.isArray(message.content) ? message.content.filter(block => block.type === 'tool_result') : []) ?? [];
    if (['Workflow', 'WorkflowFailure', 'WorkflowWait'].includes(toolName)) calls.at(-1).workflowResults = results.filter(block => block.tool_use_id === toolUseId);
    const advertisedPlanPaths=toolName==='TuiPlan'?[...new Set(JSON.stringify(body).match(/\/[A-Za-z0-9_./-]*\/\.claude\/plans\/[A-Za-z0-9_-]+\.md/g)??[])]:[];
    const planPaths=advertisedPlanPaths.filter(path=>path.startsWith(join(workspace,'.claude','plans')+'/')&&!path.includes('/../'));
    const tuiPlanPath=planPaths.length===1?planPaths[0]:undefined;
    const tuiWritten=results.find(block=>block.tool_use_id==='tui_plan_write_fixture');
    if(toolName==='TuiPlan')Object.assign(calls.at(-1),{tuiPlanPath,advertisedPlanPaths,hasTuiSeed:JSON.stringify(body.messages).includes('NativePlanFixtureSeedAlpha'),hasSyntheticPlan:JSON.stringify(body.messages).includes('Synthetic native plan')});
    const latestUser = body.messages?.findLast(message => message.role === 'user');
    const latestText = typeof latestUser?.content === 'string' ? latestUser.content : latestUser?.content?.filter(block=>block.type==='text').map(block=>block.text).join('\n') ?? '';
    if(heldModel&&latestText==='Review the release notes while I check the migration guidance.'){
      const call=calls.at(-1);call.heldModel=true;
      const send=(type,data)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...data})}\n\n`);
      if(heldModelStreaming){
        if(body.stream!==true)throw Error('Streaming model fixture requires a native streaming request');call.streamingStarted=true;call.richPreview=heldModelRich;
        res.writeHead(200,{'content-type':'text/event-stream'});
        send('message_start',{message:{id:'msg_interrupted_release_review',type:'message',role:'assistant',model:body.model,content:[],stop_reason:null,stop_sequence:null,usage:{input_tokens:10,output_tokens:0}}});
        send('content_block_start',{index:0,content_block:{type:'text',text:''}});
        send('content_block_delta',{index:0,delta:{type:'text_delta',text:heldModelRich?'I am reviewing the migration guidance before continuing.\n\n## Migration review\n\n- Keep the migration notes.\n- Verify the release checklist.\n\n```ts\nconst release = { reviewed: true };\nconsole.log(release.reviewed);\n```\n\nReview completed sections before proceeding.\nUNFINISHED_REVIEW_TAIL_MUST_STAY_HIDDEN':'I am reviewing the migration guidance before continuing.\nThe migration checklist is next.'}});
      }

      res.once('close',()=>{call.responseClosed=true;void writeFile(join(workspace,'native-held-model-closed.json'),JSON.stringify({closed:true,ended:res.writableEnded}));});
      await writeFile(join(workspace,'native-held-model-ready.json'),JSON.stringify({ready:true,request:sequence}));
      const deadline=Date.now()+30000;let released=false;
      while(Date.now()<deadline){try{await access(join(workspace,'native-held-model-release'));released=true;break}catch(error){if(error.code!=='ENOENT')throw error}await delay(25);}
      if(!released)throw Error('Owned model barrier expired');
      call.lateResponseAttempted=true;
      await writeFile(join(workspace,'native-held-model-late.json'),JSON.stringify({attempted:true,closed:res.destroyed}));
      if(heldModelStreaming){
        send('content_block_delta',{index:0,delta:{type:'text_delta',text:'STALE_RELEASE_REVIEW_MUST_NOT_APPEAR'}});
        send('content_block_stop',{index:0});send('message_delta',{delta:{stop_reason:'end_turn',stop_sequence:null},usage:{output_tokens:20}});send('message_stop',{});res.end();
      }else       res.end(JSON.stringify({id:'msg_stale_release_review',type:'message',role:'assistant',model:body.model,content:[{type:'text',text:'STALE_RELEASE_REVIEW_MUST_NOT_APPEAR'}],stop_reason:'end_turn',usage:{input_tokens:1,output_tokens:1}}));return;
    }
    const scheduledPromptInLatestUser = latestText.includes(toolName==='WakeupFire'?'Synthetic wakeup fixture. Do not execute.':'Synthetic scheduling fixture. Do not execute.');
    if (['CronFire','WakeupFire'].includes(toolName)) calls[calls.length-1].scheduledPromptInLatestUser = scheduledPromptInLatestUser;
    const cronIds = ['WakeupLifecycle','WakeupFire'].includes(toolName) ? ['wakeup_arm_fixture','wakeup_stop_fixture'] : toolName === 'CronFire' ? ['cron_create_fixture','cron_fired_list_fixture'] : toolName === 'CronResumeCleanup' ? ['cron_resumed_list_fixture','cron_resumed_delete_fixture','cron_resumed_empty_fixture'] : toolName === 'CronCreateOnly' ? ['cron_create_fixture'] : toolName === 'CronListOnly' ? ['cron_list_fixture'] : ['cron_create_fixture','cron_list_fixture','cron_delete_fixture','cron_empty_fixture'];
    const cronStep = cronIds.findIndex(id => !results.some(block => block.tool_use_id === id));
    const cronNames = ['WakeupLifecycle','WakeupFire'].includes(toolName) ? ['ScheduleWakeup','ScheduleWakeup'] : toolName === 'CronFire' ? ['CronCreate','CronList'] : toolName === 'CronResumeCleanup' ? ['CronList','CronDelete','CronList'] : toolName === 'CronCreateOnly' ? ['CronCreate'] : toolName === 'CronListOnly' ? ['CronList'] : ['CronCreate','CronList','CronDelete','CronList'];
    const created = results.find(block => block.tool_use_id === cronIds[0]);
    const createdText = typeof created?.content === 'string' ? created.content : JSON.stringify(created?.content);
    const cronJobId = createdText?.match(/Scheduled (?:one-shot task|recurring job) ([a-f0-9]{8}) /)?.[1]
      ?? (toolName === 'CronResumeCleanup' ? createdText?.match(/^([a-f0-9]{8}) —/)?.[1] : undefined);
    const future = new Date(Date.now() + 48*60*60*1000);
    const cronInput = ['WakeupLifecycle','WakeupFire'].includes(toolName) ? cronStep === 0 ? {delaySeconds:1,reason:'Verify native delay clamping then cancel immediately',prompt:'Synthetic wakeup fixture. Do not execute.',noop:true} : {stop:true} : cronNames[cronStep] === 'CronCreate' ? {cron: cronExpression ?? `0 0 ${future.getUTCDate()} ${future.getUTCMonth()+1} *`,prompt:'Synthetic scheduling fixture. Do not execute.',recurring:false,durable:false} : cronNames[cronStep] === 'CronDelete' ? {id:cronJobId ?? 'missing_fixture_job'} : {};
    const readCompleted = body.messages?.some(message => Array.isArray(message.content)
      && message.content.some(block => block.type === 'tool_result' && block.tool_use_id === 'toolu_read_fixture'));
    const needsRead = toolName === 'Edit' && !readCompleted;
    const cron = ['TuiPlan', 'WakeupFire','WakeupLifecycle','CronLifecycle','CronCreateOnly','CronListOnly','CronResumeCleanup','CronFire'].includes(toolName);
    const cronFailed = results.some(block => cronIds.includes(block.tool_use_id) && block.is_error);
    let useTool = toolName==='TuiPlan' ? !!tuiPlanPath&&!tuiPlanExitIssued&&!tuiWritten?.is_error&&body.tools?.some(tool=>tool.name===(tuiWritten?'ExitPlanMode':'Write')) : cron ? !(['CronFire','WakeupFire'].includes(toolName) && cronStep === 1 && !scheduledPromptInLatestUser) && !cronFailed && cronStep >= 0 && (cronNames[cronStep] !== 'CronDelete' || (!!cronJobId && (!expectedCronJobId || expectedCronJobId === cronJobId))) && body.tools?.some(tool => tool.name === cronNames[cronStep]) : search || (!hasResult && body.tools?.some(tool => tool.name === actualToolName));
    if (forceBash) useTool = !hasResult;
    let block = toolName==='TuiPlan'&&useTool ? {type:'tool_use',id:tuiWritten?toolUseId:'tui_plan_write_fixture',name:tuiWritten?'ExitPlanMode':'Write',input:tuiWritten?{allowedPrompts:[]}:{file_path:tuiPlanPath,content:planText??'# Synthetic native plan\n\nImplement the isolated fixture only.\n'}} : cron && useTool ? {type:'tool_use',id:cronIds[cronStep],name:cronNames[cronStep],input:cronInput} : useTool ? { type: 'tool_use', id: needsRead ? 'toolu_read_fixture' : search ? 'toolu_search_fixture' : toolUseId,
      name: needsRead ? 'Read' : search ? 'ToolSearch' : actualToolName, input: needsRead ? { file_path: join(workspace, 'fixture.txt') } : toolName === 'Edit' ? { file_path: join(workspace, 'fixture.txt'), old_string: 'before\n', new_string: 'after\n' } : search ? { query: 'select:ExitPlanMode', max_results: 1 } : toolName === 'mcp__research__echo'
      ? { message: 'synthetic MCP echo' } : toolName === 'WorkflowWait' ? { script: WORKFLOW_WAIT_SCRIPT } : toolName === 'WorkflowFailure' ? { script: WORKFLOW_FAILURE_SCRIPT } : toolName === 'Workflow' ? { script: WORKFLOW_FIXTURE_SCRIPT } : toolName === 'EnterPlanMode' ? {} : toolName === 'ExitPlanMode' ? { allowedPrompts: [] } : toolName === 'AskUserQuestion' ? {
      questions: [{ question: 'Which synthetic fixture should be selected?', header: 'Fixture',
        options: [{ label: 'Alpha', description: 'First fixture' }, { label: 'Beta', description: 'Second fixture' }], multiSelect: false }, ...(questionWizard ? [{ question: 'Which second synthetic fixture should be selected?', header: 'Second fixture', options: [{ label: 'Gamma', description: 'Third fixture' }, { label: 'Delta', description: 'Fourth fixture' }], multiSelect: questionFormControls }] : [])],
    } : {
      ...(toolName === 'BashBackground' ? { run_in_background: true } : {}),
      command: bashStandingRule ? standingCommand : `${bashWait}${toolName === 'BashBackground' ? '/bin/sleep 2; ' : bashDelayMs ? '/bin/sleep '+(bashDelayMs/1000)+'; ' : ''}/usr/bin/printf 'synthetic protocol fixture\\n' > ${shellQuote(join(workspace, 'fixture.txt'))}`,
      description: 'Write disposable synthetic fixture',
    } } : { type: 'text', text: textReply??'Fixture completed.' };
    if(toolPermissions||genericPermissions){
      const permissionSteps=genericPermissions?genericPermissionSteps:toolPermissionSteps,permissionStem=genericPermissions?'generic':'tool';
      const phase=await import('node:fs/promises').then(fs=>fs.readFile(join(workspace,'native-'+permissionStem+'-permission-phase.txt'),'utf8').then(Number,()=>0));
      if(phase){
        if(!Number.isInteger(phase)||phase<1||phase>permissionSteps.length)throw Error('Invalid permission phase');
        const step=permissionSteps[phase-1],id='native_permission_'+phase,result=results.find(row=>row.tool_use_id===id);
        const searchId='native_permission_search_'+phase,search=results.find(row=>row.tool_use_id===searchId);
        if(!result){
          await writeFile(join(workspace,'native-'+permissionStem+'-permission-model-ready-'+phase),'ready');const deadline=Date.now()+10000;let released=false;
          while(Date.now()<deadline){try{await access(join(workspace,'native-'+permissionStem+'-permission-model-release-'+phase));released=true;break}catch(error){if(error.code!=='ENOENT')throw error}await delay(20);}
          if(!released)throw Error('Owned permission draft barrier expired');
        }
        if(!result&&!body.tools?.some(tool=>tool.name===step.tool)&&!search){
          if(!body.tools?.some(tool=>tool.name==='ToolSearch'))throw Error('Original tool discovery unavailable');
          useTool=true;block={type:'tool_use',id:searchId,name:'ToolSearch',input:{query:'select:'+step.tool,max_results:1}};
        }else{useTool=!result;block=useTool?{type:'tool_use',id,name:step.tool,input:step.input}:{type:'text',text:'Release permission review complete.'};}
        Object.assign(calls.at(-1),{toolPermissionPhase:phase,toolPermissionResults:results.filter(row=>/^native_permission_\d+$/.test(row.tool_use_id))});
      }
    }
    if(notebookEdits){
      if(sequence===1){
        await writeFile(join(workspace,'native-notebook-model-ready'),'ready');const deadline=Date.now()+10000;let released=false;
        while(Date.now()<deadline){try{await access(join(workspace,'native-notebook-model-release'));released=true;break}catch(error){if(error.code!=='ENOENT')throw error}await delay(20);}
        if(!released)throw Error('Owned notebook draft barrier expired');
      }
      const steps=nativeNotebookSteps(workspace),step=steps.find(step=>!results.some(result=>result.tool_use_id===step.id));
      if(step&&!body.tools?.some(tool=>tool.name===step.name))throw Error('Original notebook tool unavailable: '+step.name);
      useTool=!!step;block=step?{type:'tool_use',...step}:{type:'text',text:'Notebook updated; original migration notes retained.'};calls.at(-1).notebookResults=results.filter(result=>steps.some(step=>step.id===result.tool_use_id));
    }
    if(directoryReadFiles){
      const marker=JSON.stringify(body.messages??[]).match(/ResearchDirectoryTurn[12]/g)?.at(-1)?.slice(-1);
      if(marker){const id='native_staged_directory_'+marker,result=results.find(result=>result.tool_use_id===id);if(!body.tools?.some(tool=>tool.name==='Read'))throw Error('Original Read tool unavailable');useTool=!result;block=useTool?{type:'tool_use',id,name:'Read',input:{file_path:directoryReadFiles[Number(marker)-1]}}:{type:'text',text:'Directory review complete.'};Object.assign(calls.at(-1),{directoryTurn:Number(marker),directoryResult:result});}
    }
    if(readMedia){
      const marker=JSON.stringify(body.messages).match(/ResearchMediaTurn[1-6]/g)?.at(-1)?.slice(-1);
      if(!marker)throw Error('Missing bounded media turn marker');
      const id='native_media_'+marker,result=results.find(result=>result.tool_use_id===id);
      if(!body.tools?.some(tool=>tool.name==='Read'))throw Error('Original Read tool unavailable');
      useTool=!result;block=useTool?{type:'tool_use',id,name:'Read',input:readMediaPages?{file_path:join(workspace,marker==='6'?'empty-release.pdf':'release-notes.pdf'),pages:marker==='5'?'0':'1'}:{file_path:join(workspace,['release-cover.png','release-notes.pdf','release-analysis.ipynb'][Number(marker)-1])}}:{type:'text',text:'Media review complete.'};
      Object.assign(calls.at(-1),{mediaTurn:Number(marker),mediaResult:result,fixtureResponse:block.type==='tool_use'?block.name:'text'});
    }
    if(mcpResources){
      const steps=mcpResourceDirectory?[directoryStep]:resourceSteps;
      const step=steps.find(step=>!results.some(result=>result.tool_use_id===step.id));
      calls.at(-1).resourceResults=results.filter(result=>steps.some(step=>step.id===result.tool_use_id));
      calls.at(-1).resourceStep=step?.id??'complete';
      useTool=!!step&&body.tools?.some(tool=>tool.name===step.name);
      block=useTool?{type:'tool_use',id:step.id,name:step.name,input:step.input}:{type:'text',text:step?'Resource tool unavailable.':mcpResourceDirectory?'Directory eligibility checked.':'Resources inspected.'};
    }
    if(questionExtended){
      const text=body.messages?.flatMap(message=>typeof message.content==='string'?[message.content]:message.content?.filter(item=>item.type==='text').map(item=>item.text)??[]).join('\n')??'';
      const round=text.match(/ResearchQuestionTurn[123]/g)?.at(-1)?.slice(-1);
      if(!round)throw Error('Missing bounded question round marker');
      const id='toolu_extended_question_'+round,answer=results.find(result=>result.tool_use_id===id),followId=id+'_follow',follow=results.find(result=>result.tool_use_id===followId);
      const needsFollow=answer&&!answer.is_error&&JSON.stringify(answer).includes('follow-up questions');
      useTool=!answer||needsFollow&&!follow;
      block=useTool?{type:'tool_use',id:answer?followId:id,name:'AskUserQuestion',input:answer?{title:'One more detail',questions:[{question:'What should the first example demonstrate?',header:'Example',kind:'text',multiSelect:false}]}:{title:'Project setup',questions:[{question:'Which language should the examples use?',header:'Language',kind:'choice',options:[{label:'TypeScript'},{label:'Python'}],multiSelect:false},{question:'What should this project be called?',header:'Name',kind:'text',placeholder:'Project name',multiSelect:false},{question:'How many examples should be included?',header:'Examples',kind:'number',min:1,max:10,step:1,defaultValue:3,unit:'examples',multiSelect:false}]}}:{type:'text',text:'Fixture completed.'};
      Object.assign(calls.at(-1),{questionRound:Number(round),questionResults:results.filter(result=>[id,followId].includes(result.tool_use_id)),fixtureResponse:block.type==='tool_use'?block.name:'text'});
      if(useTool)await delay(1000);
    }
    if(questionFirst){
      const answer=results.find(result=>result.tool_use_id==='toolu_initial_question_fixture');
      if(!answer){
        if(!body.tools?.some(tool=>tool.name==='AskUserQuestion'))throw new Error('Question fixture tool unavailable');
        useTool=true;block={type:'tool_use',id:'toolu_initial_question_fixture',name:'AskUserQuestion',input:{questions:[{question:'Which synthetic fixture should be selected?',header:'Fixture',options:[{label:'Alpha',description:'First fixture'},{label:'Beta',description:'Second fixture'}],multiSelect:false}]}};
      }
      Object.assign(calls.at(-1),{fixtureResponse:block.type==='tool_use'?block.name:'text',questionAnsweredAlpha:Boolean(answer)&&JSON.stringify(answer).includes('Alpha')});
    }
    if(toolName==='TuiPlan'){calls.at(-1).fixtureResponse=useTool?block.name:'text';if(useTool&&tuiWritten)tuiPlanExitIssued=true;}
    if(['TaskLifecycle','TaskDeletion'].includes(toolName)) {
      const steps=[['task_empty_fixture','TaskList',{}],['task_create_fixture','TaskCreate',{subject:'NativeTaskFixture',description:'Fixed private task lifecycle fixture'}],['task_get_fixture','TaskGet',{}],['task_running_fixture','TaskUpdate',{status:'in_progress'}],['task_active_list_fixture','TaskList',{}],['task_complete_fixture','TaskUpdate',{status:'completed'}],['task_done_get_fixture','TaskGet',{}],['task_final_list_fixture','TaskList',{}],['task_missing_fixture','TaskGet',{taskId:'999999999'}]];
      if(toolName==='TaskDeletion')steps.push(['task_delete_fixture','TaskUpdate',{status:'deleted'}],['task_deleted_get_fixture','TaskGet',{}],['task_missing_update_fixture','TaskUpdate',{status:'in_progress'}]);
      const created=results.find(result=>result.tool_use_id==='task_create_fixture');
      const createdText=typeof created?.content==='string'?created.content:created?.content?.filter(value=>value.type==='text').map(value=>value.text).join('\n')??'';
      const taskId=createdText.match(/Task #(\d+) created/)?.[1];
      const failed=results.some(result=>steps.slice(0,-1).some(([id])=>id===result.tool_use_id)&&result.is_error);
      const step=steps.find(([id])=>!results.some(result=>result.tool_use_id===id));
      const searchResult=results.find(result=>result.tool_use_id==='task_search_fixture');
      const names=['TaskCreate','TaskGet','TaskList','TaskUpdate'];
      calls.at(-1).taskResults=results.filter(result=>steps.some(([id])=>id===result.tool_use_id));
      if(!failed&&step) {
        if(!names.every(name=>body.tools?.some(tool=>tool.name===name))&&!searchResult) {
          if(!body.tools?.some(tool=>tool.name==='ToolSearch'))throw new Error('Task fixtures require native tool discovery');
          block={type:'tool_use',id:'task_search_fixture',name:'ToolSearch',input:{query:'select:'+names.join(','),max_results:4}};useTool=true;
        } else {
          const [id,name,input]=step;
          if(!body.tools?.some(tool=>tool.name===name))throw new Error('Native task tool unavailable after discovery: '+name);
          if(['TaskGet','TaskUpdate'].includes(name)&&id!=='task_missing_fixture'&&(!taskId||!/^\d{1,10}$/.test(taskId)))throw new Error('Private task create result did not supply a bounded task ID');
          block={type:'tool_use',id,name,input:{...input,...(['TaskGet','TaskUpdate'].includes(name)&&id!=='task_missing_fixture'?{taskId}:{})}};useTool=true;
        }
      } else {block={type:'text',text:'Task lifecycle fixture completed.'};useTool=false;}
    }
    if(['StructuredOutput','StructuredRepair','StructuredInvalid'].includes(toolName)) {
      const tool=body.tools?.find(tool=>tool.name==='StructuredOutput');
      if(!tool)throw new Error('Native structured output tool unavailable');
      calls.at(-1).structuredSchema=tool.input_schema;
      calls.at(-1).structuredResults=results.filter(result=>/^structured_fixture_[12]$/.test(result.tool_use_id));
      const prior=results.find(result=>result.tool_use_id==='structured_fixture_1');
      useTool=true;block={type:'tool_use',id:toolName==='StructuredInvalid'?`structured_fixture_${sequence}`:prior?'structured_fixture_2':'structured_fixture_1',name:'StructuredOutput',input:{answer:toolName==='StructuredInvalid'||toolName==='StructuredRepair'&&!prior?'invalid':42,marker:'STRUCTURED_FIXTURE'}};
    }
    if(thinkingCycles){
      const ids=Array.from({length:thinkingCycles},(_,index)=>`thinking_cycle_${index+1}`);
      const completed=results.filter(result=>ids.includes(result.tool_use_id));
      calls.at(-1).thinkingCycleResults=completed;
      if(completed.some(result=>result.is_error))throw new Error('Synthetic thinking-cycle tool failed');
      const step=ids.findIndex(id=>!completed.some(result=>result.tool_use_id===id));
      useTool=step!==-1;
      if(useTool){
        if(!body.tools?.some(tool=>tool.name==='Bash'))throw new Error('Thinking-cycle Bash tool unavailable');
        block={type:'tool_use',id:ids[step],name:'Bash',input:{command:`/usr/bin/printf NATIVE_THINKING_CYCLE_${step+1}`,description:`Read-only thinking cycle ${step+1}`}};
      } else block={type:'text',text:'Thinking cycles completed.'};
    }
    if(focusContextTool&&!results.some(result=>result.tool_use_id==='native_focus_tool')){if(!body.tools?.some(tool=>tool.name==='Bash'))throw Error('Original focus Bash tool unavailable');useTool=true;block={type:'tool_use',id:'native_focus_tool',name:'Bash',input:{command:'/usr/bin/printf NATIVE_FOCUS_REVIEW',description:'Read-only release review marker'}};}
    const thinkingContent = thinkingBlock ? {type:'thinking',thinking:`Synthetic thinking summary ${sequence}.`,signature:narration?'Eg0KC0IJbmFycmF0aW9u':'private-fixture-signature'} : undefined;
    const message = { id: `msg_fixture_${sequence}`, type: 'message', role: 'assistant',
      model: body.model, content: [...(thinkingContent ? [thinkingContent] : []),...(pairedText ? [block,{type:'text',text:'Second native text block.'}] : [block])], stop_reason: toolName === 'Refusal' ? 'refusal' : useTool ? 'tool_use' : 'end_turn',
      stop_sequence: null, usage: { input_tokens: 10, output_tokens: 5 } };
    if (!body.stream) {
      res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(message)); return;
    }
    res.writeHead(200, { 'content-type': 'text/event-stream' });
    const send = (type, data) => res.write(`event: ${type}\ndata: ${JSON.stringify({ type, ...data })}\n\n`);
    send('message_start', { message: { ...message, content: [], stop_reason: null,
      usage: { input_tokens: 10, output_tokens: 0 } } });
    const textIndex = thinkingBlock ? 1 : 0;
    if(thinkingContent){send('content_block_start',{index:0,content_block:{type:'thinking',thinking:'',signature:''}});send('content_block_delta',{index:0,delta:{type:'thinking_delta',thinking:thinkingContent.thinking}});send('content_block_delta',{index:0,delta:{type:'signature_delta',signature:thinkingContent.signature}});send('content_block_stop',{index:0});}
    send('content_block_start', { index: textIndex,
      content_block: useTool ? { ...block, input: {} } : { type: 'text', text: '' } });
    send('content_block_delta', { index: textIndex, delta: useTool
      ? { type: 'input_json_delta', partial_json: JSON.stringify(block.input) }
      : { type: 'text_delta', text: block.text } });
    send('content_block_stop', { index: textIndex });
    if(pairedText){send('content_block_start',{index:textIndex+1,content_block:{type:'text',text:''}});send('content_block_delta',{index:textIndex+1,delta:{type:'text_delta',text:'Second native text block.'}});send('content_block_stop',{index:textIndex+1});}
    send('message_delta', { delta: { stop_reason: message.stop_reason, stop_sequence: null },
      usage: { output_tokens: 5 } });
    send('message_stop', {}); res.end();
  }

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  return { url: `http://127.0.0.1:${server.address().port}`, calls, async close() {
    server.closeAllConnections();
    await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
  } };
}
