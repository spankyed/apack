import http from 'node:http';

/** Two native background workers, each asking for one disposable Bash marker write. */
export async function startSyntheticMultiAgentModel() {
  const calls=[],requests=[];let sequence=0;
  const server=http.createServer((req,res)=>{respond(req,res).catch(error=>{calls.push({error:error.message});if(!res.headersSent)res.writeHead(400);res.end('{}')})});
  server.requestTimeout=12000;
  async function respond(req,res){
    let bytes=0;const chunks=[];
    for await(const chunk of req){bytes+=chunk.length;if(bytes>2097152){res.writeHead(413);res.end();return}chunks.push(chunk)}
    const body=JSON.parse(Buffer.concat(chunks).toString()||'{}');
    if(req.url?.includes('count_tokens')){res.writeHead(200,{'content-type':'application/json'});res.end('{"input_tokens":10}');return}
    if(!req.url?.startsWith('/v1/messages')){res.writeHead(404);res.end('{}');return}
    const id=++sequence;if(id>12){res.writeHead(429);res.end('{}');return}
    requests.push(body);
    const child=JSON.stringify(body.system??'').includes('NativeMultiChildSystem');
    const label=child?(JSON.stringify(body.messages).includes('WorkerB')?'b':'a'):undefined;
    const results=body.messages?.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[])??[];
    const childResult=results.find(block=>block.tool_use_id===`multi_child_${label}`);
    const launch=!child&&!results.some(block=>['multi_agent_a','multi_agent_b'].includes(block.tool_use_id));
    let blocks;
    if(launch){
      if(!body.tools?.some(tool=>tool.name==='Agent'))throw Error('Agent unavailable');
      blocks=['a','b'].map(key=>({type:'tool_use',id:`multi_agent_${key}`,name:'Agent',input:{description:`Disposable Worker${key.toUpperCase()}`,prompt:`Worker${key.toUpperCase()}: use the disposable marker tool once.`,subagent_type:'multi-permission-fixture'}}));
    }else if(child&&!childResult){
      if(!body.tools?.some(tool=>tool.name==='Bash'))throw Error('Bash unavailable to child');
      blocks=[{type:'tool_use',id:`multi_child_${label}`,name:'Bash',input:{command:`/usr/bin/printf MultiChild${label.toUpperCase()} > multi-child-${label}.txt`,description:`Write disposable Worker${label.toUpperCase()} marker`}}];
    }else blocks=[{type:'text',text:child?`Worker${label.toUpperCase()}Complete`:'MultiParentComplete'}];
    const call={requestIndex:requests.length-1,child,label:label??null,response:blocks.map(block=>block.type==='tool_use'?block.name:block.text),...(childResult?{childToolError:childResult.is_error===true}:{})};calls.push(call);
    if(child&&!childResult)await new Promise(resolve=>setTimeout(resolve,5000));
    if(res.destroyed)return;
    const tool=blocks.some(block=>block.type==='tool_use');
    const message={id:`msg_multi_agent_${id}`,type:'message',role:'assistant',model:body.model,content:blocks,stop_reason:tool?'tool_use':'end_turn',stop_sequence:null,usage:{input_tokens:10,output_tokens:5}};
    if(!body.stream){res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(message));call.delivered=true;return}
    res.writeHead(200,{'content-type':'text/event-stream'});
    const send=(type,value)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...value})}\n\n`);
    send('message_start',{message:{...message,content:[],stop_reason:null,usage:{input_tokens:10,output_tokens:0}}});
    for(const [index,block] of blocks.entries()){
      const useTool=block.type==='tool_use';
      send('content_block_start',{index,content_block:useTool?{...block,input:{}}:{type:'text',text:''}});
      send('content_block_delta',{index,delta:useTool?{type:'input_json_delta',partial_json:JSON.stringify(block.input)}:{type:'text_delta',text:block.text}});
      send('content_block_stop',{index});
    }
    send('message_delta',{delta:{stop_reason:message.stop_reason,stop_sequence:null},usage:{output_tokens:5}});send('message_stop',{});res.end();call.delivered=true;
  }
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
  return {calls,requests,url:`http://127.0.0.1:${server.address().port}`,async close(){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}};
}
