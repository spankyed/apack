/** A real script return with an unawaited reviewer; native loop cleanup owns settlement. */
export const WORKFLOW_UNSETTLED_SCRIPT='export const meta = {name: "release-review", description: "Review release notes", phases: [{title: "Review"}]}; const reviewer = agent("Return the synthetic worker marker only.", {agentType: "status-fixture", label: "Release reviewer", phase: "Review"}); reviewer.catch(() => {}); await new Promise(resolve => setTimeout(resolve, 10000)); log("Release reviewer ready to settle"); await new Promise(resolve => setTimeout(resolve, 4000)); return {reviewQueued: true};';

import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

export async function verifyWorkflowUnsettled(workspace,evidence,calls){
 assert.equal(evidence.nativeWorkflowUnsettled,true);
 const proof=JSON.parse(await readFile(join(workspace,'native-workflow-unsettled-proof.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.sessionId,evidence.finalSessionId);
 assert.equal(proof.before.id,proof.taskId);assert.equal(proof.before.status,'completed');assert.equal(proof.before.settled,false);assert.equal(proof.before.result?.reviewQueued,true);
 assert.equal(proof.after.id,proof.taskId);assert.equal(proof.after.settled,true);
 const history=(await readFile(join(workspace,'native-workflow-state-history.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 const admitted=history.find(row=>row.tasks.some(task=>task.id===proof.taskId&&task.status==='completed'&&task.settled===false));
 assert.ok(admitted,'No original completed/unsettled snapshot');
 assert.ok(history.some(row=>row.at>=admitted.at&&row.tasks.some(task=>task.id===proof.taskId&&task.settled===true)),'Original native settlement never followed');
 const receipts=(await readFile(join(workspace,'native-workflow-stop-receipts.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 const receipt=receipts.find(row=>row.id===proof.receipt?.id&&row.taskId===proof.taskId);
 assert.ok(receipt,'No correlated original native Stop receipt');
 assert.equal(receipt.sessionId,proof.sessionId);assert.equal(receipt.ownerPid,proof.boundNativePid);assert.equal(receipt.pid,proof.boundNativePid);
 assert.equal(receipt.task?.status,'completed');assert.equal(receipt.task?.settled,false);assert.equal(receipt.status,200);
 assert.equal(receipt.reply?.id,receipt.id);assert.equal(receipt.reply?.sessionId,proof.sessionId);assert.equal(receipt.reply?.pid,proof.boundNativePid);assert.equal(receipt.reply?.result?.stopped,true);
 const delivery=(await readFile(join(workspace,'workflow-stop-delivery.jsonl'),'utf8')).trim().split('\n').map(JSON.parse).filter(row=>row.id===receipt.id);
 assert.deepEqual(delivery.map(row=>row.stage),['held','released']);assert.equal(delivery[1].taskId,proof.taskId);assert.equal(delivery[1].ownerPid,proof.boundNativePid);assert.equal(delivery[1].sessionId,proof.sessionId);
 assert.equal(delivery[1].task.status,'completed');assert.equal(delivery[1].task.settled,false);assert.ok(delivery[1].at<=receipt.at&&receipt.at<=receipt.repliedAt);
 assert.equal(receipt.after?.stoppedByUser,true,'Original Stop did not mark this task as user-stopped');
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width]),[['settled',1100],['settled',680]]);
 for(const row of proof.captures){assert.equal(row.task.id,proof.taskId);assert.equal(row.task.settled,row.stage==='settled');assert.equal(row.task.canStop,row.stage==='running');}
 assert.ok(calls.agent.some(call=>call.child&&call.heldReleased&&call.disconnectedWhenReleased&&!call.delivered),'Original reviewer request did not cancel before held response release');
 assert.equal(calls.seed.length,2);
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.equal(paths.length,1);
 const rows=(await readFile(join(root,paths[0]),'utf8')).trim().split('\n').map(JSON.parse);
 const humans=rows.filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'));
 const text=content=>typeof content==='string'?content:(content??[]).filter(block=>block.type==='text').map(block=>block.text).join('\n');
 assert.deepEqual(humans.map(row=>text(row.message?.content)),['Review the release notes for this project.','Use a workflow to review the release notes.','Continue after stopping the unsettled release review.']);
 return {sessionId:proof.sessionId,taskId:proof.taskId,humanUuids:humans.map(row=>row.uuid),captures:proof.captures,scope:'Original completed-but-unsettled Workflow with a live reviewer, native Stop admitted before settlement, control retirement, retained composing and same-session recovery; not paused/unsettled resume or all task lifetimes.'};
}
