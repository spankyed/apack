import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticAgentModel} from './synthetic-agent-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Original TaskStop cancels a real caller while its foreground child's model response is held. */
export async function probeSubagentHandbackCancel(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'handback-cancel-')),home=join(workspace,'home'),cwd=join(workspace,'project');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(cwd);
 const run=await createRun(output,'subagent-handback-cancel',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-agent-model.mjs',import.meta.url)))});
 const model=await startSyntheticAgentModel({handbackProbe:true,handbackNested:true,handbackCancelCaller:true,handbackClassifierSafe:true,parentLaunchOnce:true,requestLimit:16,captureMessages:true});
 const events=[];let pending='',callerId,stopAcknowledged=false;
 try{
  const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--permission-mode','auto','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','Agent,TaskStop','--allowedTools','Agent,TaskStop','--agents',JSON.stringify({'status-fixture':{description:'Release reviewer',prompt:'NativeStatusChildSystem. Review using a foreground migration worker.',tools:['Agent'],maxTurns:5,permissionMode:'auto'},'late-fixture':{description:'Migration reviewer',prompt:'NativeStatusGrandchildSystem. Return the late migration report.',tools:[],maxTurns:3,permissionMode:'auto'}}),'--model','sonnet','--no-session-persistence','--max-turns','6'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,CLAUDE_CODE_SENDMESSAGE_HANDBACK:'1',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[JSON.stringify({type:'control_request',request_id:'cancel-init',request:{subtype:'initialize',hooks:{PreToolUse:[{matcher:'Agent|TaskStop',hookCallbackIds:['cancel-fixed-fixture']}]}}})+'\n'],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),line=pending.slice(0,at);pending=pending.slice(at+1);let event;try{event=JSON.parse(line)}catch{continue}events.push(event);
    if(event.type==='control_response'&&event.response?.request_id==='cancel-init'){assert.equal(event.response.subtype,'success');channel.send(JSON.stringify({type:'user',message:{role:'user',content:'Review the release notes with a worker, then cancel that review.'}})+'\n');}
    if(event.type==='system'&&event.subtype==='task_started'&&event.spawn_depth===1){callerId=event.task_id;model.releaseChild();}
    if(event.type==='control_request'&&event.request?.subtype==='hook_callback'){
     assert.equal(event.request.callback_id,'cancel-fixed-fixture');const input=event.request.input;assert.equal(input.hook_event_name,'PreToolUse');
     if(input.tool_name==='TaskStop'){assert.ok(callerId);assert.deepEqual(input.tool_input,{task_id:callerId});}
     else{assert.equal(input.tool_name,'Agent');assert.ok([['status-fixture','Return the synthetic worker marker only.'],['late-fixture','Return the late migration report.']].some(([type,prompt])=>input.tool_input.subagent_type===type&&input.tool_input.prompt===prompt));}
     channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:event.request_id,response:{hookSpecificOutput:{hookEventName:'PreToolUse',permissionDecision:'allow'}}}})+'\n');
    }
    if(event.type==='user'&&event.message?.content?.some(block=>block.type==='tool_result'&&block.tool_use_id==='cancel_caller_fixture'&&!block.is_error)){stopAcknowledged=true;model.releaseGrandchild();}
    if(event.type==='result'&&stopAcknowledged)channel.closeInput();
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(stopAcknowledged,true);
  const starts=events.filter(event=>event.type==='system'&&event.subtype==='task_started'),notifications=events.filter(event=>event.type==='system'&&event.subtype==='task_notification');
  const leaf=model.calls.find(call=>call.grandchild);assert.ok(leaf);assert.equal(leaf.handbackOffered,true);assert.equal(leaf.responseCancelled,true);assert.equal(leaf.delivered,undefined);
  assert.equal(starts.length,2);const child=starts.find(event=>event.spawn_depth===2);assert.equal(child?.parent_task_id,callerId);assert.equal(child?.is_backgrounded,false);
  assert.equal(notifications.length,2);assert.ok(notifications.every(event=>event.status==='stopped'));assert.deepEqual(new Set(notifications.map(event=>event.task_id)),new Set(starts.map(event=>event.task_id)));
  assert.equal(notifications.some(event=>event.handback_report),false);
  assert.equal(events.some(event=>event.type==='assistant'&&event.message?.content?.some(block=>block.type==='tool_use'&&block.name==='SubagentHandback')),false);
  const results=events.filter(event=>event.type==='result');assert.ok(results.every(event=>event.subtype==='success'&&!event.is_error));
  const evidence={status:'complete',callerId,stopAcknowledged,starts:starts.map(({task_id,parent_task_id,spawn_depth,is_backgrounded})=>({task_id,parent_task_id,spawn_depth,is_backgrounded})),notifications:notifications.map(({task_id,status,handback})=>({task_id,status,handback})),heldForegroundRequest:leaf,results:results.map(({num_turns,subagent_stats})=>({num_turns,subagent_stats})),noHandbackInvoked:true,noReportAdmitted:true,localModelRequests:model.messageRequestCount(),realModelRequests:0,qualification:'Original caller cancellation while a real foreground child model request is held. This checks cancellation before invocation; it does not establish the separate already-invoked closed-caller refusal race or mounted app acceptance.'};
  await writeFile(join(run.directory,'subagent-handback-cancel.json'),JSON.stringify(evidence,null,2)+'\n');await writeFile(join(run.directory,'model-requests.json'),JSON.stringify(model.requests,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,...evidence};
 }catch(error){await writeFile(join(run.directory,'failed-observations.json'),JSON.stringify({events,calls:model.calls,requests:model.requests},null,2)+'\n');await run.finish({status:'failed',error:error.message});throw error;}finally{await model.close();}
}
