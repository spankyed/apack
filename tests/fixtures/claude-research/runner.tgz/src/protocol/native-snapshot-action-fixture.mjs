import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** A native status clock drives redraws independently of the neighbouring original callback. */
export async function addNativeSnapshotActionFixture(plugin){
 const register=join(plugin,'hooks/register.ts');await writeFile(register,(await readFile(register,'utf8')).replace('width:48,height:14','width:48,height:2'));
 await writeFile(join(plugin,'hooks/print-status.ts'),`export default function(props,s){if(s.state===undefined){s.setState({ticks:0});s.every(300,()=>s.setState({ticks:s.state.ticks+1}));}return s.elements.Text({color:'success',children:['Workspace connected · Refresh '+s.state.ticks]});}`);
}
