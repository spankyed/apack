import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Discover private instructions and exercise only native memory-settings persistence. */
export async function probeMemoryDiscovery(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'memory-discovery-'));
 const cwd=join(workspace,'project'),home=join(workspace,'home'),config=join(home,'.claude');
 await mkdir(join(cwd,'.claude','rules'),{recursive:true});await mkdir(config,{recursive:true});
 execFileSync('/usr/bin/git',['init','-q',cwd]);
 const files={'CLAUDE.md':'Project instruction fixture.\n','CLAUDE.local.md':'Local instruction fixture.\n','.claude/rules/research.md':'Unconditional rule fixture.\n'};
 for(const [name,text] of Object.entries(files))await writeFile(join(cwd,name),text);
 await writeFile(join(config,'CLAUDE.md'),'User instruction fixture.\n');
 const settings=join(config,'settings.json');await writeFile(settings,JSON.stringify({language:'research-preserve'}));
 const env={PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
 const run=await createRun(output,'memory-discovery',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url)))});
 try{
  let pending='';const replies=[],requests=[{subtype:'initialize',hooks:{}},{subtype:'get_memory_dialog'},{subtype:'get_context_usage',detail:'full'}];
  const line=i=>JSON.stringify({type:'control_request',request_id:`memory-${i}`,request:requests[i]})+'\n';
  const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user,project,local','--strict-mcp-config','--no-session-persistence'],env,input:[line(0)],onStdout(bytes,channel){
   pending+=bytes.toString('utf8');while(pending.includes('\n')){
    const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type!=='control_response'||value.response?.request_id!==`memory-${replies.length}`)continue;
    replies.push({request:requests[replies.length],response:value.response});
    if(replies.length<requests.length)channel.send(line(replies.length));else channel.closeInput();
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(replies.length,3);for(const item of replies)assert.equal(item.response.subtype,'success');
  const dialog=replies[1].response.response,context=replies[2].response.response;
  for(const path of [join(config,'CLAUDE.md'),...Object.keys(files).map(name=>join(cwd,name))]){
   assert.ok(dialog.files.some(file=>file.path===path&&file.exists===true));
   assert.ok(context.memoryFiles.some(file=>file.path===path));
  }
  assert.equal(dialog.auto_memory.enabled,true);assert.equal(dialog.auto_dream.shown,false);
  const edits=[];
  for(const edit of [{autoMemoryEnabled:false},{autoMemoryEnabled:true},{autoMemoryEnabled:'invalid'}]){
   const before=await readFile(settings);const result=await record({executable,cwd,output,timeoutMs:15000,args:['edit-memory-settings','--json'],env,input:[JSON.stringify(edit)+'\n']});
   const after=await readFile(settings),stdout=(await readFile(join(result.directory,'stdout.bin'),'utf8')).trim(),stderr=(await readFile(join(result.directory,'stderr.bin'),'utf8')).trim();
   let response;try{response=JSON.parse(stdout)}catch{response=null}
   edits.push({edit,code:result.code,response,stderr,fileUnchanged:before.equals(after),settings:JSON.parse(after),transportRun:result.directory});
  }
  for(const item of edits)assert.equal(item.settings.language,'research-preserve');
  for(const item of edits.slice(0,2)){assert.equal(item.code,0);assert.equal(item.response.ok,true);assert.equal(item.settings.autoMemoryEnabled,item.edit.autoMemoryEnabled)}
  assert.notEqual(edits[2].code,0);assert.equal(edits[2].fileUnchanged,true);
  const normalize=value=>JSON.parse(JSON.stringify(value).split(workspace).join('${WORKSPACE}'));
  const result={replies:normalize(replies),edits:normalize(edits),modelPrompts:0,qualification:'Instruction discovery and user settings persistence only; automatic memory generation, dream execution, policy/account and live refresh are not proven.'};
  await writeFile(join(run.directory,'memory-discovery.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',controls:3,edits:3,modelPrompts:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
