import {appendFileSync} from 'node:fs';
const[capture]=process.argv.slice(2);if(!capture)throw Error('Private startup capture required');
appendFileSync(capture,'started\n');
await import('./synthetic-mcp-server.mjs');
