import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Verify native thinking controls and resulting local API fields, including partial refusal. */
export async function probeLiveThinking(executable,root,output,mode='adaptive'){
 if(!['adaptive','budgeted','partial-refusal','null-budget'].includes(mode))throw new Error('Unknown thinking fixture mode');
 const selectedModel=mode==='adaptive'?'sonnet':'claude-sonnet-4-20250514';
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'live-thinking-')),home=join(workspace,'home'),cwd=join(workspace,'project');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(cwd);
 const path=join(home,'.claude','settings.json'),before=JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',model:'sonnet',language:'preserve'});await writeFile(path,before);
 let model;
 const steps=[
  {request:{subtype:'initialize'}},
  {request:{subtype:'set_max_thinking_tokens',max_thinking_tokens:0}},
  {user:'Synthetic thinking disabled fixture.'},
  {request:{subtype:'set_max_thinking_tokens',max_thinking_tokens:2048}},
  {user:'Synthetic thinking budget fixture.'},
  {request:{subtype:'set_max_thinking_tokens',max_thinking_tokens:4096,thinking_display:'highlights'}},
  {user:'Synthetic thinking after partial refusal fixture.'},
  {request:{subtype:'set_max_thinking_tokens',max_thinking_tokens:'invalid'}},
  {request:{subtype:'set_max_thinking_tokens',max_thinking_tokens:0,thinking_display:'omitted'}},
  {user:'Synthetic thinking disabled again fixture.'},
 ];
 if(mode==='null-budget')steps[5]={request:{subtype:'set_max_thinking_tokens',max_thinking_tokens:null}};
 let pending='',index=0;const replies=[],results=[],initializations=[];
 const run=await createRun(output,'live-thinking',{mode,selectedModel,targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
 const input=()=>JSON.stringify(steps[index].request?{type:'control_request',request_id:'model-'+index,request:steps[index].request}:{type:'user',message:{role:'user',content:steps[index].user}})+'\n';
 try{
  model=await startSyntheticModel(cwd,'TextOnly',{captureThinking:true});
  const transport=await record({executable,cwd,output,timeoutMs:30000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','','--no-session-persistence','--model',selectedModel,'--max-turns','10'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',...(mode==='partial-refusal'?{CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS:'1'}:{})},input:[input()],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const i=pending.indexOf('\n'),text=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type==='system'&&value.subtype==='init')initializations.push({step:index,model:value.model,sessionId:value.session_id});
    let advance=false;
    if(value.type==='control_response'&&value.response?.request_id==='model-'+index){replies.push({step:index,request:steps[index].request,response:value.response,modelRequestsSoFar:model.calls.length});advance=true;}
    if(value.type==='result'&&steps[index]?.user){results.push({subtype:value.subtype,is_error:value.is_error??false,sessionId:value.session_id,model: model.calls.at(-1)?.model});advance=true;}
    if(advance){index++;if(index<steps.length)channel.send(input());else channel.closeInput();}
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(index,steps.length);assert.equal(results.length,4);assert.ok(results.every(value=>value.subtype==='success'&&!value.is_error));assert.equal(new Set(results.map(value=>value.sessionId)).size,1);
  assert.equal(model.calls.length,4);
  assert.equal(replies.find(value=>value.step===5).response.subtype,mode==='partial-refusal'?'error':'success');
  const thinking=model.calls.map(value=>value.thinking);
  if(mode==='adaptive') {
   assert.ok(thinking.every(value=>value?.type==='adaptive'));
   assert.equal(thinking[2].display,'highlights');
   assert.ok(thinking.every(value=>!('budget_tokens' in value)));
  } else {
   assert.deepEqual(thinking.map(value=>value?.type),['disabled','enabled','enabled','disabled']);
   assert.equal(thinking[1].budget_tokens,2048);assert.equal(thinking[2].budget_tokens,mode==='null-budget'?31999:4096);
   if(mode==='partial-refusal'||mode==='null-budget')assert.notEqual(thinking[2].display,'highlights');else assert.equal(thinking[2].display,'highlights');
  }
  for(const step of [1,3,8])assert.equal(replies.find(value=>value.step===step).response.subtype,'success');
  assert.equal(replies.find(value=>value.step===7).response.subtype,'error');
  assert.equal(await readFile(path,'utf8'),before);
  const evidence={mode,selectedModel,replies:replies.filter(value=>value.request.subtype==='set_max_thinking_tokens'),initializations,results,modelCalls:model.calls,settingsUnchanged:true,realModelRequests:0,qualification:'Private loopback-model idle thinking control and outgoing API fields only. Malformed-type refusal observed; partial mutation on gated display refusal is exercised only in partial-refusal mode; not all providers/policies/models, active-turn mutation, app persistence or UI.'};
  const sanitized=JSON.parse(JSON.stringify(evidence).split(workspace).join('${WORKSPACE}'));await writeFile(join(run.directory,'live-thinking.json'),JSON.stringify(sanitized,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...sanitized};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}finally{await model?.close();}
}
