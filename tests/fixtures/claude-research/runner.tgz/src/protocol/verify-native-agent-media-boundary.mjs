import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
/** Classify original delivery; literal image labels are not evidence of image blocks. */
export async function verifyNativeAgentMediaBoundary(workspace,calls){
 const proof=JSON.parse(await readFile(join(workspace,'native-agent-media-boundary-proof.json'),'utf8'));
 assert.equal(proof.before.selected,proof.taskId);assert.equal(proof.prepared.selected,proof.taskId);assert.equal(proof.delivered.taskId,proof.taskId);
 assert.match(proof.prepared.draft.text,/NativeAgentMediaBoundary[\s\S]*\[Image\s*#\d+\]/i);
 for(const key of ['parentDraftRetained','agentDraftRetained','sameSessionRecovery'])assert.equal(proof[key],true);
 const own=message=>message.role==='user'&&(typeof message.content==='string'?message.content.includes('NativeAgentMediaBoundary'):Array.isArray(message.content)&&message.content.some(block=>block.type==='text'&&block.text.includes('NativeAgentMediaBoundary')));
 const requests=calls.filter(call=>call.child===true&&(call.messages??[]).some(own));assert.ok(requests.length,'Original resumed Agent request was not captured');
 const imageBlocks=call=>(call.messages??[]).flatMap(row=>Array.isArray(row.content)?row.content.filter(block=>block.type==='image'):[]);
 const first=calls.indexOf(requests[0]),baseline=calls.slice(0,first).filter(call=>call.child===true);assert.ok(baseline.length,'Original Agent baseline request missing');assert.ok(baseline.every(call=>imageBlocks(call).length===0),'Baseline worker already contained unrelated images');
 const images=requests.flatMap(imageBlocks);
 const journal=proof.delivered.observed;assert.ok(journal.length,'Original Agent user row missing');
 const priorIds=new Set((proof.before.observed??[]).map(row=>row.uuid));
 assert.ok(journal.every(row=>typeof row.uuid==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(row.uuid)&&!priorIds.has(row.uuid)),'Agent journal must contain new canonical user UUIDs');
 const journalImages=journal.flatMap(row=>Array.isArray(row.content)?row.content.filter(block=>block.type==='image'):[]);
 const source=await readFile(join(workspace,'native-app-image.png'));
 return {classification:images.length?'image-reached-original-worker':journalImages.length?'image-in-journal-without-worker-image':'text-marker-only-in-original-route',originalWorkerRequests:requests.length,workerImageBlocks:images.length,journalImageBlocks:journalImages.length,sourceSha256:createHash('sha256').update(source).digest('hex'),workerImages:images.map(block=>({mediaType:block.source?.media_type,sha256:typeof block.source?.data==='string'?createHash('sha256').update(Buffer.from(block.source.data,'base64')).digest('hex'):null})),qualification:'Original selected-Agent terminal paste/Enter route only. Neither static source nor literal image markers establish app image support; other native media/plugin contexts remain separate.'};
}
