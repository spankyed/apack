import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Original logging only: fixture controls never render the log text themselves. */
export async function addNativeLogFixture(workspace,plugin){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){let count=0;on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Text({children:['Review records '+count]}),Button({key:'log-release',label:'Record review',onPress:async()=>{const text='Release review recorded by the native plugin.',debug='Private release review debug record.';await $.ui.log(text);await $.ui.log(debug,{to:'debug'});await $.fs.write('native-log-native.json',JSON.stringify({requestId:e.requestId,text,debug}));count++;$.ui.invalidate('ui.render');}})]});});}`);
}
export async function verifyNativeLogFixture(workspace){
 const native=JSON.parse(await readFile(join(workspace,'native-log-native.json'),'utf8'));
 assert.ok(native.requestId);assert.equal(native.text,'Release review recorded by the native plugin.');
 const proof=JSON.parse(await readFile(join(workspace,'native-log-app-proof.json'),'utf8'));
 assert.deepEqual(proof.receipt,native);assert.deepEqual(proof.widths,[1100,680]);
 assert.equal(proof.journalNotice.sessionId,proof.sessionId);assert.match(proof.journalNotice.uuid,/^[a-f0-9-]{36}$/i);
 assert.equal(proof.journalNotice.type,'system');assert.equal(proof.journalNotice.subtype,'informational');assert.equal(proof.journalNotice.level,'notice');
 assert.equal(proof.journalNotice.content,'native-history-fixture: '+native.text);
 assert.equal(proof.transcriptVisible,true);assert.equal(proof.debugExcluded,true);assert.equal(proof.draftRetained,true);assert.equal(proof.noPhantomTurn,true);
 return{appTranscript:true,debugExcluded:true,retainedDraft:true,noPhantomTurn:true};
}
