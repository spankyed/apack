import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const sha = value => createHash('sha256').update(value).digest('hex');
const binary = sha(readFileSync(process.execPath));
if (process.platform !== 'linux' || process.arch !== 'arm64' || binary !== '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10') throw Error('Unreviewed inline-eligibility target');
delete process.env.BUN_OPTIONS;
const native = await import('/$bunfs/root/chunk-m86ay9q5.js');
const validate = native.sTr;
if (typeof validate !== 'function') throw Error('Missing original tree validator');
if (sha(validate.toString()) !== 'f8253b89e7b069d88aecd64b2be57817c6f952a973a4f10ffc1a6fda577c26a5') throw Error('Unreviewed original tree validator');
if (!process.env.CLAUDE_INLINE_PROOF) throw Error('Explicit private output path required');
const cases = [];
const surfaces = ['terminal', 'desktop', 'mobile', 'vscode'];
const blocks = ['Box', 'Button', 'Input', 'Select', 'Svg', 'Code', 'Markdown', 'Client', 'Raster', 'Image', 'engine'];
const link = children => ({ type: 'Link', props: { href: 'https://example.test/releases' }, children });
const text = children => ({ type: 'Text', children });
for (const surface of surfaces) {
  for (const parent of ['Text', 'Link']) {
    for (const block of blocks) {
      const tree = parent === 'Text' ? text([{ type: block }]) : link([{ type: block }]);
      const problem = validate(tree, 'AbovePrompt', { surface });
      const expected = `${block === 'engine' ? 'engine node' : block} inside an inline element`;
      if (problem !== expected) throw Error(`${surface}/${parent}/${block}: ${problem}`);
      cases.push({ surface, parent, child: block, problem });
    }
  }
  for (const [name, tree] of [
    ['plainText', text(['Ready'])],
    ['nestedText', text([text(['Ready'])])],
    ['textLink', text([link(['Release notes'])])],
    ['linkText', link([text(['Release notes'])])],
    ['boxText', { type: 'Box', children: [text(['Ready'])] }],
  ]) {
    const problem = validate(tree, 'AbovePrompt', { surface });
    if (problem !== undefined) throw Error(`${surface}/${name}: ${problem}`);
    cases.push({ surface, name, accepted: true });
  }
  const problem = validate(text([link([text([{ type: 'Box' }])])]), 'AbovePrompt', { surface });
  if (problem !== 'Box inside an inline element') throw Error(`Lost inline ancestry: ${problem}`);
  cases.push({ surface, name: 'deepInlineAncestry', problem });
}
writeFileSync(process.env.CLAUDE_INLINE_PROOF, JSON.stringify({ binary, module: 'chunk-m86ay9q5.js', symbol: 'sTr', functionSha256: sha(validate.toString()), cases }, null, 2));
