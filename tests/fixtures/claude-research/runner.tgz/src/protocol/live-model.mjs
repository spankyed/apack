import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Verify native model mutation between real local turns; do not replace its validation/gates. */
export async function probeLiveModel(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'live-model-')),home=join(workspace,'home'),cwd=join(workspace,'project');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(cwd);
 const path=join(home,'.claude','settings.json'),before=JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',model:'sonnet',language:'preserve'});await writeFile(path,before);
 const model=await startSyntheticModel(cwd,'TextOnly'),steps=[
  {request:{subtype:'initialize'}},
  {user:'Synthetic model fixture one.'},
  {request:{subtype:'set_model',model:'haiku'}},
  {user:'Synthetic model fixture two.'},
  {request:{subtype:'set_model',model:'research-custom-model'}},
  {user:'Synthetic model fixture three.'},
  {request:{subtype:'set_model',model:'haiku',system_prompt:''}},
  {request:{subtype:'set_model',model:'sonnet',only_if_model_is_current:true,system_prompt:'Private fixture system prompt.'}},
  {user:'Synthetic model fixture four after refusals.'},
  {request:{subtype:'set_model',model:'default'}},
  {user:'Synthetic model fixture five.'},
  {request:{subtype:'get_settings'}},
 ];let pending='',index=0;const replies=[],results=[],initializations=[];
 const run=await createRun(output,'live-model',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
 const input=()=>JSON.stringify(steps[index].request?{type:'control_request',request_id:'model-'+index,request:steps[index].request}:{type:'user',message:{role:'user',content:steps[index].user}})+'\n';
 try{
  const transport=await record({executable,cwd,output,timeoutMs:30000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','','--no-session-persistence','--model','sonnet','--max-turns','10'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[input()],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const i=pending.indexOf('\n'),text=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type==='system'&&value.subtype==='init')initializations.push({step:index,model:value.model,sessionId:value.session_id});
    let advance=false;
    if(value.type==='control_response'&&value.response?.request_id==='model-'+index){replies.push({step:index,request:steps[index].request,response:value.response,modelRequestsSoFar:model.calls.length});advance=true;}
    if(value.type==='result'&&steps[index]?.user){results.push({subtype:value.subtype,is_error:value.is_error??false,sessionId:value.session_id,model: model.calls.at(-1)?.model});advance=true;}
    if(advance){index++;if(index<steps.length)channel.send(input());else channel.closeInput();}
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(index,steps.length);assert.equal(results.length,5);assert.ok(results.every(value=>value.subtype==='success'&&!value.is_error));assert.equal(new Set(results.map(value=>value.sessionId)).size,1);
  assert.equal(model.calls.length,6);assert.ok(results[0].model.includes('sonnet'));assert.ok(results[1].model.includes('haiku'));assert.equal(results[2].model,'research-custom-model');assert.equal(results[3].model,'research-custom-model');assert.ok(results[4].model.includes('opus'));
  for(const step of [2,4,9])assert.equal(replies.find(value=>value.step===step).response.subtype,'success');
  assert.equal(replies.find(value=>value.step===4).modelRequestsSoFar,3);
  assert.equal(replies.find(value=>value.step===6).response.error_code,'invalid_request');assert.equal(replies.find(value=>value.step===7).response.error_code,'model_not_current');
  assert.equal(await readFile(path,'utf8'),before);
  const evidence={replies:replies.filter(value=>value.request.subtype==='set_model'),initializations,results,modelCalls:model.calls.map(value=>({path:value.path,model:value.model})),settingsUnchanged:(await readFile(path,'utf8'))===before,realModelRequests:0,qualification:'Private loopback-model live control, not all providers/policies/hooks, active-turn mutation, app persistence or UI.'};
  const sanitized=JSON.parse(JSON.stringify(evidence).split(workspace).join('${WORKSPACE}'));await writeFile(join(run.directory,'live-model.json'),JSON.stringify(sanitized,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return{directory:run.directory,status:'complete',...sanitized};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}finally{await model.close();}
}
