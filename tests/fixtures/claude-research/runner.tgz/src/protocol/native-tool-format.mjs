import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, copyFile } from 'node:fs/promises';
import { existsSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { hash } from '../artifacts/runs.mjs';
import { record } from './record.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

const targetSha256='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37';
export async function probeNativeToolFormat(executable, workspaceParent, output, apackCheckout) {
 assert.equal(hash(await readFile(executable)),targetSha256);
 await mkdir(workspaceParent,{recursive:true});
 const workspace=await mkdtemp(join(workspaceParent,'native-tool-format-'));
 const trigger=join(workspace,'initialized'),reportPath=join(workspace,'native-tool-format.json'),preload=join(workspace,'format.mjs');
 const runtimeSource=apackCheckout?await readFile(join(apackCheckout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-ui-runtime.ts'),'utf8'):'';
 const formatSource=apackCheckout?await readFile(join(apackCheckout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-tool-output-runtime.ts'),'utf8'):'';
 const progressSource=apackCheckout?await readFile(join(apackCheckout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-tool-progress-runtime.ts'),'utf8'):'';
 const progressHelper=progressSource?progressSource.slice(progressSource.indexOf('String.raw`')+11,progressSource.lastIndexOf('`')):'';
 const themeHelper=runtimeSource?runtimeSource.slice(runtimeSource.indexOf('function nativeThemeProvider('),runtimeSource.indexOf('let nativeThemeSnapshot;')):'';
 const formatHelper=formatSource?formatSource.slice(formatSource.indexOf('String.raw`')+11,formatSource.lastIndexOf('`')):'';
 const source=`${themeHelper}\n${formatHelper}\n${progressHelper}\nimport {writeFileSync,existsSync} from 'node:fs';
async function probe(){const report={};let providerRoot;try{
 const registry=await import('/$bunfs/root/chunk-r2k35jby.js'),render=await import('/$bunfs/root/chunk-mn4kxp8g.js'),jsx=await import('/$bunfs/root/chunk-4hec5rn1.js'),runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js'),app=await import('/$bunfs/root/chunk-002p0hd2.js'),globals=await import('/$bunfs/root/chunk-hdxpvbx1.js');
 const binding=runtime.ey();report.binding=binding?.surface;const tools=binding?.tools?.()??[];report.tools=tools.map(tool=>({name:tool.name,outputSchema:typeof tool.outputSchema}));
 const input={file_path:'native-fixture.txt',content:'first\\nsecond\\n'},original={type:'create',filePath:'native-fixture.txt',content:input.content,structuredPatch:[],originalFile:null,userModified:false};
 report.results=[];
 ${apackCheckout?`const ink=await import('/$bunfs/root/chunk-tdpa6qc1.js'),themeRoots=await import('/$bunfs/root/chunk-pg10s5g1.js'),themePreferences=await import('/$bunfs/root/chunk-gnpc8ecg.js'),toolExport=await import('/$bunfs/root/chunk-ste1xxgx.js');const {PassThrough}=await import('node:stream');const inputStream=new PassThrough();let mounted=false;function Capture(){themePreferences.ew();mounted=true;return null;}providerRoot=await ink.fce({stdout:process.stdout,stdin:inputStream,stderr:process.stderr,exitOnCtrlC:false,patchConsole:false});providerRoot.render(jsx.e(Capture,{}));const mountDeadline=Date.now()+2500;while(!mounted){if(Date.now()>mountDeadline)throw Error('Original formatter theme provider did not mount');await new Promise(resolve=>setTimeout(resolve,10));}const n={terminalComponents:ink,themeRoots,themePreferences,toolExport,jsx,appProvider:app,questionOptions:globals,runtime,toolRendering:registry,staticRender:render};report.adapterResults=[];report.rootsBefore=themeRoots.ai().size;`:''}

 for(const verbose of [false,true])for(const rewritten of [false,true]){
  const data=rewritten?{...original,content:'rewritten first\\nrewritten second\\nrewritten third\\n'}:original;
  if(!tools.some(tool=>tool.name==='Write'))throw Error('Original Write tool missing');
  const call={type:'tool_use',id:'format-call',name:'Write',input};
  const assistant={type:'assistant',uuid:'11111111-1111-1111-1111-111111111111',message:{role:'assistant',content:[call]}};
  const message={type:'user',uuid:'22222222-2222-2222-2222-222222222222',message:{role:'user',content:[{type:'tool_result',tool_use_id:call.id,content:'original result'}]},toolUseResult:data};
  const facts=runtime.sQt([{message:assistant},{message}]);
  const props={message,lookups:facts.lookups,containerWidth:80,addMargin:false,tools,commands:[],verbose,inProgressToolUseIDs:facts.inProgressToolUseIDs,progressMessagesForMessage:[],shouldAnimate:false,shouldShowDot:false,style:'condensed',isTranscriptMode:verbose,isStatic:true,disableDisplayOverride:true};
  const text=await render.v6e(jsx.e(app.d_,{session:globals.j(),keybindings:false,children:jsx.e(registry.h3,props)}),{columns:80});report.results.push({verbose,rewritten,text});
 ${apackCheckout?`if(verbose){const facts={message,messages:[assistant,message],block:message.message.content[0],fingerprint:JSON.stringify([assistant,message])},options={tools,columns:80};const first=await formatNativeToolResult(n,facts,data,options);report.adapterResults.push({rewritten,text:first,matchesOriginal:first===text});if(!rewritten){const invalid=await formatNativeToolResult(n,facts,{pluginResult:'invalid schema'},options);report.adapterInvalid=invalid;
const siblingCall={...call,id:'sibling-format-call'},batchAssistant={...assistant,message:{...assistant.message,content:[call,siblingCall]}},batch={...message,message:{...message.message,content:[...message.message.content,{type:'tool_result',tool_use_id:siblingCall.id,content:'sibling result'}]}};
report.adapterBatch=await formatNativeToolResult(n,{message:batch,messages:[batchAssistant,batch],block:batch.message.content[0],fingerprint:'batch-source'},data,options);
const originalTool=tools.find(tool=>tool.name===call.name),originalLabel=originalTool.userFacingName;
report.adapterToolUse=await formatNativeToolUse(n,{message:assistant,messages:[assistant,message],block:call,progress:new Set()}, {tool:'ShownWrite',input:{...input,file_path:'display-only.txt'}},options);
const grouped=runtime.Qdo([assistant,message],tools).find(row=>row.type==='collapsed_read_search');
report.nativeGroup=grouped?{uuid:grouped.uuid,type:grouped.type,members:grouped.messages.map(row=>row.uuid),renderings:[]}:null;
if(grouped)for(const expanded of [false,true]){const groupText=await render.v6e(jsx.e(app.d_,{session:globals.j(),keybindings:false,children:jsx.e(registry.h3,{...props,message:grouped,verbose:expanded,isTranscriptMode:false,isActiveCollapsedGroup:false})}),{columns:80});report.nativeGroup.renderings.push({expanded,text:groupText});}
report.adapterProgress=await formatNativeToolProgress(n,'Native background hint',{columns:80});
report.adapterToolUsePreserved={name:call.name,path:call.input.file_path,toolDefinitionUnchanged:originalTool.userFacingName===originalLabel};

}}`:''}

  if(!verbose&&!rewritten){const invalid={...message,toolUseResult:{pluginResult:'invalid schema'}};report.invalid=await render.v6e(jsx.e(app.d_,{session:globals.j(),keybindings:false,children:jsx.e(registry.h3,{...props,message:invalid})}),{columns:80});}
  if(!verbose&&!rewritten){
   const failed={...message,message:{...message.message,content:[{type:'tool_result',tool_use_id:call.id,content:'fixture denied',is_error:true}]},toolUseResult:undefined};
   const failedFacts=runtime.sQt([{message:assistant},{message:failed}]);
   report.failed=await render.v6e(jsx.e(app.d_,{session:globals.j(),keybindings:false,children:jsx.e(registry.h3,{...props,message:failed,lookups:failedFacts.lookups})}),{columns:80});
   report.toolUse=[];
   for(const running of [false,true]){const source=running?runtime.sQt([{message:assistant}]):facts;const text=await render.v6e(jsx.e(app.d_,{session:globals.j(),keybindings:false,children:jsx.e(registry.h3,{...props,message:assistant,lookups:source.lookups,inProgressToolUseIDs:source.inProgressToolUseIDs})}),{columns:80});report.toolUse.push({running,hasOriginalRunningId:source.inProgressToolUseIDs.has(call.id),text});}
  }


 }
 ${apackCheckout?'report.rootsAfter=themeRoots.ai().size;':''}
}catch(error){report.error=String(error);}finally{providerRoot?.unmount();}writeFileSync(${JSON.stringify(reportPath)},JSON.stringify(report,null,2));}
let started=false;const timer=setInterval(()=>{if(started||!existsSync(${JSON.stringify(trigger)}))return;started=true;clearInterval(timer);probe();},25);timer.unref();`;
 await writeFile(preload,source);
 const model=await startSyntheticModel(workspace,'TextOnly');let buffer='',observing,run;
 try {
  run=await record({executable,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--strict-mcp-config','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})],cwd:workspace,output,timeoutMs:15000,
   env:{HOME:workspace,CLAUDE_CONFIG_DIR:join(workspace,'.claude'),PATH:'/usr/bin:/bin',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',ANTHROPIC_BASE_URL:model.url,BUN_OPTIONS:'--preload='+preload},
   input:[JSON.stringify({type:'control_request',request_id:'format-init',request:{subtype:'initialize',hooks:{}}})+'\n'],
   onStdout(bytes,transport){buffer+=bytes;while(buffer.includes('\n')){const at=buffer.indexOf('\n'),line=buffer.slice(0,at);buffer=buffer.slice(at+1);let row;try{row=JSON.parse(line)}catch{continue}if(row.type==='control_response'&&row.response.request_id==='format-init'&&!observing){writeFileSync(trigger,'ready');observing=(async()=>{const deadline=Date.now()+10000;while(!existsSync(reportPath)){if(Date.now()>deadline){transport.stop('tool-format-observation-timeout');return}await new Promise(resolve=>setTimeout(resolve,25));}transport.closeInput();})();}}}
  });if(observing)await observing;assert.equal(model.calls.length,0);
 }finally{await model.close();}
 const report=JSON.parse(await readFile(reportPath,'utf8'));
 await copyFile(preload,join(run.directory,'authored-tool-format-preload.mjs'));await copyFile(reportPath,join(run.directory,'native-tool-format.json'));
 const evidence={targetSha256,authoredPreloadSha256:hash(Buffer.from(source)),...(apackCheckout?{authoredRuntimeSha256:hash(Buffer.from(runtimeSource)),authoredFormatterSha256:hash(Buffer.from(formatSource)),authoredProgressSha256:hash(Buffer.from(progressSource))}:{}),report,importsEmbeddedNativeModules:true,recoveredSourceExecuted:false,modelRequests:0,qualification:'Original message renderer, transcript lookups and static export providers on synthetic Write results, including original output-schema rejection. Not actual app or other-tool parity.'};
 await writeFile(join(run.directory,'integration.json'),JSON.stringify(evidence,null,2)+'\n');
 assert.equal(run.status,'complete');assert.equal(report.error,undefined);assert.equal(report.results.length,4);assert.equal(report.invalid.trim(),'');assert.ok(report.results.every(result=>result.text.includes(result.rewritten?'Wrote 3 lines':'Wrote 2 lines')));if(apackCheckout){assert.equal(report.adapterResults.length,2);assert.ok(report.adapterResults.every(result=>result.matchesOriginal));assert.equal(report.adapterInvalid.trim(),'');assert.equal((report.adapterBatch.match(/Wrote 2 lines/g)??[]).length,1);assert.ok(report.adapterToolUse.includes('ShownWrite'));assert.ok(report.adapterToolUse.includes('display-only.txt'));assert.deepEqual(report.adapterToolUsePreserved,{name:'Write',path:'native-fixture.txt',toolDefinitionUnchanged:true});assert.ok(report.adapterProgress.includes('Native background hint'));assert.equal(report.rootsAfter,report.rootsBefore);}
 return {...run,evidence};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 assert.ok(process.argv.length===5||process.argv.length===6,'Usage: node src/protocol/native-tool-format.mjs <pinned-binary> <private-root> <output> [apack-checkout]');
 const result=await probeNativeToolFormat(...process.argv.slice(2).map(value=>resolve(value)));
 console.log(JSON.stringify({directory:result.directory,status:result.status,report:result.evidence.report},null,2));
}
