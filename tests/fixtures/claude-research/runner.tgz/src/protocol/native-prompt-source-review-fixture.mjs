/** Useful release-review actions, admitted through original desktop prompt APIs. */
export const promptSourceReviewSteps = [
 {label:'Add migration example',mode:'append',text:'\n\n~~~ts\nconst migrationReady = true\n~~~'},
 {label:'Add review note',mode:'insert',text:'\nKeep migration notes with this review.'},
 {label:'Use fresh review draft',mode:'replace',text:'~~~ts\nconst reviewComplete = true\n~~~'},
];

export function nativePromptSourceReviewHook(){return `export function register(on){
 let phase=0;const effects=[],edits=[],draws=[],steps=${JSON.stringify(promptSourceReviewSteps)};
 on('prompt.edit',async($,e,next)=>{const result=await next(e);if(edits.length>=256)throw Error('Review edit receipt bound');edits.push({origin:e.origin,inputText:e.inputText,text:result.text,cursor:result.cursor});await $.fs.write('native-prompt-source-edits.json',JSON.stringify(edits));return result;});
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
  if(e.surface!=='desktop'||e.props.view?.agentId)return next(e);
  const {Box,Text,Button}=$.ui.resolve(e),step=steps[phase];
  if(draws.length>=128)throw Error('Review draw receipt bound');draws.push({surface:e.surface,view:e.props.view,component:e.component,phase});await $.fs.write('native-prompt-source-draws.json',JSON.stringify(draws));
  return Box({flexDirection:'column',gap:'xs',children:[Text({weight:'medium',children:['Release review']}),...(step?[Button({key:'release-review-'+phase,label:step.label,onPress:async()=>{
   const before=await $.prompt.read(),input={mode:step.mode,text:step.text},result=await $.prompt.fill(input),after=await $.prompt.read();
   effects.push({phase,input,before,result,after,surface:e.surface,view:e.props.view});await $.fs.write('native-prompt-source-effects.json',JSON.stringify(effects));
   if(result.isFilled){phase++;$.ui.invalidate('ui.render');}
  }})]:[Text({children:['Review draft prepared.']})])]});
 });
}`;}
