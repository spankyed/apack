import assert from 'node:assert/strict';
import {createNativeTestImage} from './native-test-image.mjs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {existsSync} from 'node:fs';
import {createHash} from 'node:crypto';

/** Disposable real files and a passive native result observer; no fake tool results. */
export async function addNativeReadMediaFixture(workspace,plugin,{pageSuccess=false,notebookImages=false}={}){
 await writeFile(join(workspace,'empty-release.pdf'),Buffer.alloc(0));
 await writeFile(join(workspace,'release-cover.png'),Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=','base64'));
 const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
 const stream='BT /F1 18 Tf 72 720 Td (Release notes: verify native PDF delivery.) Tj ET';objects.push('<< /Length '+Buffer.byteLength(stream)+' >>\nstream\n'+stream+'\nendstream');
 let pdf='%PDF-1.4\n',offsets=[0];for(const[index,object]of objects.entries()){offsets.push(Buffer.byteLength(pdf));pdf+=(index+1)+' 0 obj\n'+object+'\nendobj\n'}const xref=Buffer.byteLength(pdf);pdf+='xref\n0 6\n0000000000 65535 f \n'+offsets.slice(1).map(offset=>String(offset).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF\n';await writeFile(join(workspace,'release-notes.pdf'),pdf);
 await writeFile(join(workspace,'release-analysis.ipynb'),JSON.stringify({nbformat:4,nbformat_minor:5,metadata:{},cells:[{cell_type:'markdown',id:'release-notes',metadata:{},source:['# Release analysis\n','Review migration notes before publishing.']},{cell_type:'code',id:'release-check',metadata:{},execution_count:1,source:['6 * 7'],outputs:[{output_type:'execute_result',execution_count:1,metadata:{},data:{'text/plain':['42']}}]}]}));
 if(notebookImages){
  const file=join(workspace,'release-analysis.ipynb'),notebook=JSON.parse(await readFile(file,'utf8'));
  notebook.cells[1].outputs.push({output_type:'display_data',metadata:{},data:{'text/plain':['Release cover preview'],'image/png':createNativeTestImage([255,0,0,255]).toString('base64')}},{output_type:'execute_result',execution_count:1,metadata:{},data:{'text/plain':['Release approval marker'],'image/png':createNativeTestImage([0,255,0,255]).toString('base64')}});
  await writeFile(file,JSON.stringify(notebook));
 }
 if(pageSuccess)await addNativePdfPageSuccessFixture(workspace);
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&/^native_media_[1-9]$/.test(e.props.tool_use_id))await $.fs.write('native-media-result-'+e.props.tool_use_id+'.json',JSON.stringify({props:e.props}));return next(e)});}`);
}

/** Check original model-facing results against the exact private files and notebook content. */
export async function verifyNativeReadMediaResults(workspace,results){
 const find=id=>{const result=results.find(result=>result.tool_use_id===id);assert.ok(result&&!result.is_error,'Original media result missing: '+id);return result;};
 const image=find('native_media_1').content.find(block=>block.type==='image');
 assert.equal(image?.source?.media_type,'image/png');assert.equal(image.source.type,'base64');assert.deepEqual(Buffer.from(image.source.data,'base64'),await readFile(join(workspace,'release-cover.png')));
 const document=find('native_media_2').content.find(block=>block.type==='document');
 assert.equal(document?.source?.media_type,'application/pdf');assert.equal(document.source.type,'base64');assert.deepEqual(Buffer.from(document.source.data,'base64'),await readFile(join(workspace,'release-notes.pdf')));
 const notebook=find('native_media_3').content.filter(block=>block.type==='text').map(block=>block.text).join('\n');
 const original=JSON.parse(await readFile(join(workspace,'release-analysis.ipynb'),'utf8'));
 for(const cell of original.cells){assert.ok(notebook.includes(cell.id));assert.ok(notebook.includes(cell.source.join('')));for(const output of cell.outputs??[])for(const text of output.data?.['text/plain']??[])assert.ok(notebook.includes(text));}
 return {imageBytesExact:true,pdfBytesExact:true,notebookCellsAndOutput:true};
}

/** Missing native dependencies and invalid/empty inputs must remain authoritative errors. */
export function verifyNativePdfPageFailures(results){
 const outcomes=[];
 for(const[id,pattern]of [['native_media_4',/pdftoppm is not installed/],['native_media_5',/Invalid pages parameter/],['native_media_6',/PDF file is empty/]]){
  const result=results.find(result=>result.tool_use_id===id);assert.equal(result?.is_error,true,'Original PDF error missing: '+id);
  const text=typeof result.content==='string'?result.content:result.content.filter(block=>block.type==='text').map(block=>block.text).join('\n');assert.match(text,pattern);outcomes.push({id,error:text});
 }
 return {pdfExtractionAvailable:false,outcomes};
}

/** Small, distinct real pages keep page-order proof separate from native rendering internals. */
export function makeNativePageReviewPdf(){
 const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [4 0 R 6 0 R 8 0 R] /Count 3 >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
 for(let page=1;page<=3;page++){
  objects.push('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 144 144] /Resources << /Font << /F1 3 0 R >> >> /Contents '+(5+(page-1)*2)+' 0 R >>');
  const stream='BT /F1 12 Tf 12 100 Td (Release review page '+page+') Tj ET';
  objects.push('<< /Length '+Buffer.byteLength(stream)+' >>\nstream\n'+stream+'\nendstream');
 }
 let pdf='%PDF-1.4\n',offsets=[0];for(const[index,object]of objects.entries()){offsets.push(Buffer.byteLength(pdf));pdf+=(index+1)+' 0 obj\n'+object+'\nendobj\n';}
 const xref=Buffer.byteLength(pdf);pdf+='xref\n0 '+(objects.length+1)+'\n0000000000 65535 f \n'+offsets.slice(1).map(offset=>String(offset).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size '+(objects.length+1)+' /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF\n';return Buffer.from(pdf);
}
async function addNativePdfPageSuccessFixture(workspace){
 assert.ok(process.platform==='linux'&&existsSync('/.dockerenv'),'PDF extraction replay requires the owned Linux container');
 const file=join(workspace,'release-pages.pdf'),reference=join(workspace,'reference-pdf-pages');await writeFile(file,makeNativePageReviewPdf());await mkdir(reference);
 const version=await promisify(execFile)('pdftoppm',['-v'],{timeout:5000,maxBuffer:65536});await writeFile(join(workspace,'native-pdf-renderer.json'),JSON.stringify({tool:'pdftoppm',version:(version.stdout+version.stderr).trim(),referenceArguments:['-jpeg','-r','100','-f','1','-l','3'],inputSha256:createHash('sha256').update(await readFile(file)).digest('hex')}));
 await promisify(execFile)('pdftoppm',['-jpeg','-r','100','-f','1','-l','3',file,join(reference,'page')],{timeout:20000,maxBuffer:65536});
}
export async function verifyNativePdfPageSuccess(workspace,results){
 const cases=[];
 for(const[id,pages]of [['native_media_7',[2]],['native_media_8',[2,3]]]){
  const result=results.find(row=>row.tool_use_id===id);assert.ok(result&&!result.is_error,'Original page read failed: '+id);
  const images=result.content.filter(block=>block.type==='image');assert.equal(images.length,pages.length,'Original PDF page count differs');
  const hashes=[];for(let index=0;index<pages.length;index++){
   const image=images[index];assert.equal(image.source.type,'base64');assert.equal(image.source.media_type,'image/jpeg');
   const expected=await readFile(join(workspace,'reference-pdf-pages','page-'+pages[index]+'.jpg')),actual=Buffer.from(image.source.data,'base64');assert.deepEqual(actual,expected,'Original page bytes/order differ');hashes.push(createHash('sha256').update(actual).digest('hex'));
  }
  cases.push({id,pages,images:images.length,pageSha256:hashes});
 }
 const refused=results.find(row=>row.tool_use_id==='native_media_9');assert.equal(refused?.is_error,true);const refusal=typeof refused.content==='string'?refused.content:refused.content.filter(block=>block.type==='text').map(block=>block.text).join('\n');assert.match(refusal,/Page range "3-" exceeds maximum of 20 pages per request/);
 return {pdfExtractionAvailable:true,realPdftoppm:true,exactPageBytesAndOrder:true,cases,openEndedRangeRefused:true,refusal};
}

/** Notebook images must retain native cell/text order and exact admitted image bytes. */
export async function verifyNativeNotebookImages(workspace,results){
 const result=results.find(row=>row.tool_use_id==='native_media_3');assert.ok(result&&!result.is_error);
 const notebook=JSON.parse(await readFile(join(workspace,'release-analysis.ipynb'),'utf8'));
 const text=result.content.filter(block=>block.type==='text').map(block=>block.text).join('\n');
 for(const cell of notebook.cells){assert.ok(text.includes(cell.id));assert.ok(text.includes(cell.source.join('')));for(const output of cell.outputs??[])for(const value of output.data?.['text/plain']??[])assert.ok(text.includes(value));}
 const expected=notebook.cells.flatMap(cell=>(cell.outputs??[]).flatMap(output=>typeof output.data?.['image/png']==='string'?[output.data['image/png']]:[]));
 const images=result.content.filter(block=>block.type==='image');assert.equal(expected.length,2);assert.equal(images.length,expected.length);
 for(let index=0;index<images.length;index++)assert.deepEqual(images[index].source,{type:'base64',media_type:'image/png',data:expected[index]});
 const kinds=result.content.map(block=>block.type);assert.deepEqual(kinds,['text','image','text','image']);
 return {notebookCellsAndText:true,notebookImageBytesAndOrder:true,images:images.length};
}
