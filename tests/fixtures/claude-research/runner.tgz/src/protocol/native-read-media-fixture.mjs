import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Disposable real files and a passive native result observer; no fake tool results. */
export async function addNativeReadMediaFixture(workspace,plugin){
 await writeFile(join(workspace,'empty-release.pdf'),Buffer.alloc(0));
 await writeFile(join(workspace,'release-cover.png'),Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=','base64'));
 const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
 const stream='BT /F1 18 Tf 72 720 Td (Release notes: verify native PDF delivery.) Tj ET';objects.push('<< /Length '+Buffer.byteLength(stream)+' >>\nstream\n'+stream+'\nendstream');
 let pdf='%PDF-1.4\n',offsets=[0];for(const[index,object]of objects.entries()){offsets.push(Buffer.byteLength(pdf));pdf+=(index+1)+' 0 obj\n'+object+'\nendobj\n'}const xref=Buffer.byteLength(pdf);pdf+='xref\n0 6\n0000000000 65535 f \n'+offsets.slice(1).map(offset=>String(offset).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF\n';await writeFile(join(workspace,'release-notes.pdf'),pdf);
 await writeFile(join(workspace,'release-analysis.ipynb'),JSON.stringify({nbformat:4,nbformat_minor:5,metadata:{},cells:[{cell_type:'markdown',id:'release-notes',metadata:{},source:['# Release analysis\n','Review migration notes before publishing.']},{cell_type:'code',id:'release-check',metadata:{},execution_count:1,source:['6 * 7'],outputs:[{output_type:'execute_result',execution_count:1,metadata:{},data:{'text/plain':['42']}}]}]}));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&/^native_media_[1-6]$/.test(e.props.tool_use_id))await $.fs.write('native-media-result-'+e.props.tool_use_id+'.json',JSON.stringify({props:e.props}));return next(e)});}`);
}

/** Check original model-facing results against the exact private files and notebook content. */
export async function verifyNativeReadMediaResults(workspace,results){
 const find=id=>{const result=results.find(result=>result.tool_use_id===id);assert.ok(result&&!result.is_error,'Original media result missing: '+id);return result;};
 const image=find('native_media_1').content.find(block=>block.type==='image');
 assert.equal(image?.source?.media_type,'image/png');assert.equal(image.source.type,'base64');assert.deepEqual(Buffer.from(image.source.data,'base64'),await readFile(join(workspace,'release-cover.png')));
 const document=find('native_media_2').content.find(block=>block.type==='document');
 assert.equal(document?.source?.media_type,'application/pdf');assert.equal(document.source.type,'base64');assert.deepEqual(Buffer.from(document.source.data,'base64'),await readFile(join(workspace,'release-notes.pdf')));
 const notebook=find('native_media_3').content.filter(block=>block.type==='text').map(block=>block.text).join('\n');
 const original=JSON.parse(await readFile(join(workspace,'release-analysis.ipynb'),'utf8'));
 for(const cell of original.cells){assert.ok(notebook.includes(cell.id));assert.ok(notebook.includes(cell.source.join('')));for(const output of cell.outputs??[])for(const text of output.data?.['text/plain']??[])assert.ok(notebook.includes(text));}
 return {imageBytesExact:true,pdfBytesExact:true,notebookCellsAndOutput:true};
}

/** Missing native dependencies and invalid/empty inputs must remain authoritative errors. */
export function verifyNativePdfPageFailures(results){
 const outcomes=[];
 for(const[id,pattern]of [['native_media_4',/pdftoppm is not installed/],['native_media_5',/Invalid pages parameter/],['native_media_6',/PDF file is empty/]]){
  const result=results.find(result=>result.tool_use_id===id);assert.equal(result?.is_error,true,'Original PDF error missing: '+id);
  const text=typeof result.content==='string'?result.content:result.content.filter(block=>block.type==='text').map(block=>block.text).join('\n');assert.match(text,pattern);outcomes.push({id,error:text});
 }
 return {pdfExtractionAvailable:false,outcomes};
}
