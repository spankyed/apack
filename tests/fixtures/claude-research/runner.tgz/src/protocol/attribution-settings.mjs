import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Native attribution parsing/normalization only, without prompts, Git operations or account credentials. */
export async function probeAttributionSettings(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'attribution-settings-'));
 const run=await createRun(output,'attribution-settings',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))}),cases=[];
 try{
  for(const [label,attribution,expected] of [['false',false,{commit:'',pr:'',sessionUrl:false}],['true',true,{}],['object',{commit:'FIXTURE_COMMIT',pr:'',sessionUrl:false,fixtureExtra:'preserved'},{commit:'FIXTURE_COMMIT',pr:'',sessionUrl:false,fixtureExtra:'preserved'}],['invalid',42,undefined]]){
   const cwd=join(workspace,label),home=join(cwd,'home'),config=join(home,'.claude');await mkdir(config,{recursive:true});
   const settings=join(config,'settings.json'),before=JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',model:'sonnet',attribution});await writeFile(settings,before);
   let model,pending='',reply,initialized=false;
   const request=(id,request)=>JSON.stringify({type:'control_request',request_id:id,request})+'\n';
   try{
    model=await startSyntheticModel(cwd,'TextOnly');
    const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','','--no-session-persistence'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[request('attribution-settings-init',{subtype:'initialize'})],onStdout(bytes,channel){
     pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
      if(value.type!=='control_response')continue;
      if(value.response?.request_id==='attribution-settings-init'){assert.equal(value.response.subtype,'success');initialized=true;channel.send(request('attribution-settings-read',{subtype:'get_settings'}));}
      else if(value.response?.request_id==='attribution-settings-read'){reply=value.response;channel.closeInput();}
     }
    }});
    assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(initialized,true);assert.equal(reply?.subtype,'success');assert.equal(model.calls.length,0);assert.equal(await readFile(settings,'utf8'),before);
    const parsed=reply.response.effective.attribution;
    assert.deepEqual(parsed,expected);
    if(label==='invalid')assert.ok(reply.response.errors?.length>0);
    cases.push({label,requestedAttribution:attribution,parsedAttribution:parsed??null,errorCount:reply.response.errors?.length??0,settingsUnchanged:true,localModelRequests:0,transportRun:transport.directory});
   }finally{await model?.close();}
  }
  const evidence={cases,realModelRequests:0,qualification:'Private user-source parsed attribution only; no actual commit/PR/session-link effect, real provider/account, managed precedence, UI or all settings validation claim.'};await writeFile(join(run.directory,'attribution-settings.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete'});return {directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
