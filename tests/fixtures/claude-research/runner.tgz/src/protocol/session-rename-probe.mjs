import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { record } from './record.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

export async function probeSessionRename(executable, workspace, output) {
  await mkdir(workspace, { recursive: true });
  const cwd = await mkdtemp(join(workspace, 'rename-'));
  const model = await startSyntheticModel(cwd);
  const request = (id, payload) => JSON.stringify({ type: 'control_request', request_id: id, request: payload }) + '\n';
  let buffer = '', result, response;
  try {
    const run = await record({ executable, cwd, output, timeoutMs: 20000,
      args: ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json',
        '--bare', '--setting-sources', '', '--tools', '', '--strict-mcp-config', '--model', 'claude-sonnet-4-6',
        '--settings', JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' })],
      env: { PATH: process.env.PATH, HOME: cwd, CLAUDE_CONFIG_DIR: join(cwd, '.claude'), ANTHROPIC_BASE_URL: model.url,
        DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
      input: [request('initialize', { subtype: 'initialize', hooks: {} })],
      onStdout(bytes, transport) {
        buffer += bytes;
        while (buffer.includes('\n')) {
          const at = buffer.indexOf('\n'); const line = buffer.slice(0, at); buffer = buffer.slice(at + 1);
          let value; try { value = JSON.parse(line); } catch { continue; }
          if (value.type === 'control_response' && value.response.request_id === 'initialize') {
            transport.send(JSON.stringify({ type: 'user', message: { role: 'user', content: 'Confirm the synthetic session fixture.' } }) + '\n');
          }
          if (value.type === 'result') {
            result = value;
            transport.send(request('rename', { subtype: 'rename_session', title: 'Synthetic research title', source: 'host', session_id: value.session_id }));
          }
          if (value.type === 'control_response' && value.response.request_id === 'rename') { response = value.response; transport.closeInput(); }
        }
      },
    });
    let titleRecord;
    const projects = join(cwd, '.claude', 'projects');
    for (const bucket of await readdir(projects)) {
      const entries = await readdir(join(projects, bucket));
      if (!entries.includes(`${result?.session_id}.jsonl`)) continue;
      const text = await readFile(join(projects, bucket, `${result.session_id}.jsonl`), 'utf8');
      titleRecord = text.trim().split('\n').map(JSON.parse).findLast(row => row.type === 'custom-title');
    }
    const verified = run.status === 'complete' && result?.subtype === 'success' && response?.subtype === 'success'
      && titleRecord?.customTitle === 'Synthetic research title' && titleRecord.sessionId === result.session_id && model.calls.length === 1;
    await writeFile(join(run.directory, 'session-rename.json'), JSON.stringify({ verified, titleRecord, response,
      syntheticApiRequests: model.calls.length, realModelRequests: 0 }, null, 2) + '\n');
    if (!verified) {
      const path = join(run.directory, 'manifest.json');
      const manifest = JSON.parse(await readFile(path, 'utf8'));
      await writeFile(path, JSON.stringify({ ...manifest, status: 'failed', reason: 'session-rename-verification-failed' }, null, 2) + '\n');
    }
    assert.equal(verified, true, `Session rename verification failed: ${run.directory}`);
    return { ...run, verified, persistedNativeTitle: true, syntheticApiRequests: model.calls.length, realModelRequests: 0 };
  } finally { await model.close(); }
}
