import assert from 'node:assert/strict';

/** Original Button callbacks used by the disposable desktop keybinding journey. */
export const nativeActionAppHook = String.raw`export function register(on) {
 const receipts=[];let retired=false;
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
  if(e.surface!=='desktop')return next(e);
  const {Box,Text,Button}=$.ui.resolve(e);
  if(retired)return Text({children:['Review shortcuts finished']});
  return Box({flexDirection:'column',children:[
   Button({key:'read-review-draft',label:'Read review draft',action:'app:cycleDiffBase',onPress:async()=>{
    receipts.push({view:e.props.view,value:await $.prompt.read()});
    await $.fs.write('native-action-app-receipts.json',JSON.stringify(receipts));
   }}),
   Button({key:'engine-priority-review',label:'Show review tasks',action:'app:toggleTodos',onPress:async()=>{
    await $.fs.write('native-action-app-wrong-engine-fallback.json',JSON.stringify({view:e.props.view}));
   }}),
   Button({key:'finish-review-shortcuts',label:'Finish review shortcuts',onPress:async()=>{retired=true;$.ui.invalidate('ui.render');}}),
  ]});
 });
}`;

export function nativeActionAppBindings(rebound = false, context = 'Global') {
 assert.ok(['Global','Plugin'].includes(context),'Unknown native action context');
 return {bindings:[{context,bindings:{
  'ctrl+alt+u':rebound?null:'app:cycleDiffBase',
  ...(rebound?{'ctrl+alt+r':'app:cycleDiffBase'}:{}),
  'ctrl+alt+k u':'app:cycleDiffBase',
  ...(context==='Global'?{'ctrl+alt+p':'app:toggleTodos'}:{}),
 }},...(context==='Plugin'?[{context:'Global',bindings:{'ctrl+alt+p':'app:toggleTodos'}}]:[])]};
}

/** Independent evidence checks for the context journey; Global acceptance remains separate. */
export function verifyNativeActionContextAppProof(proof) {
 assert.equal(proof.noPhantomTurn,true);assert.equal(proof.contextLeaseReleased,true);
 assert.equal(proof.contextSequence,8);assert.equal(proof.parentReturned,true);
 assert.ok(Number.isSafeInteger(proof.boundNativePid)&&proof.boundNativePid>1);
 const phases=['inactive-single','inactive-chord','active-single','active-chord','deactivated-single','deactivated-chord'];
 assert.equal(proof.contextCases.length,24);assert.equal(proof.receipts.length,17);
 let index=0,callbacks=0;
 for(const view of ['main','agent'])for(const width of [1100,680])for(const phase of phases){
  const expected=phase!=='inactive-single'&&phase!=='deactivated-single';
  if(expected)callbacks++;
  const actual=proof.contextCases[index++];
  assert.equal(actual.view,view);assert.equal(actual.width,width);assert.equal(actual.phase,phase);
  assert.equal(actual.handled,expected);assert.equal(actual.callbacks,callbacks);
 }
 proof.receipts.forEach((receipt,index)=>{
  const agent=index>=8&&index<16;
  assert.equal(receipt.view.agentId,agent?proof.taskId:undefined);
  assert.deepEqual(receipt.value,agent?proof.agent:proof.parent);
 });
 return {mainAndAgentContexts:true,originalEligibility:true,exactDrafts:true,parentReturn:true,noPhantomTurn:true};
}

/** A real original question awaited by a desktop Button, without a model turn. */
export const nativeActionDialogAppHook = String.raw`export function register(on) {
 const receipts=[];
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
  if(e.surface!=='desktop')return next(e);
  const {Button}=$.ui.resolve(e);
  return Button({key:'review-question',label:'Review release guidance',action:'app:cycleDiffBase',onPress:async()=>{
   receipts.push({view:e.props.view,value:await $.prompt.read()});
   await $.fs.write('native-action-app-receipts.json',JSON.stringify(receipts));
   if(receipts.length===1){
    const answer=await $.ui.ask('Continue reviewing the release guidance?', ['Continue','Pause']);
    await $.fs.write('native-action-dialog-answer.json',JSON.stringify({answer,value:await $.prompt.read()}));
    $.ui.invalidate('ui.render');
   }
  }});
 });
}`;

export function verifyNativeActionDialogAppProof(proof) {
 assert.ok(Number.isSafeInteger(proof.boundNativePid)&&proof.boundNativePid>1);
 assert.equal(proof.noPhantomTurn,true);assert.equal(proof.dialogSuppressedShortcut,true);
 assert.ok(proof.heldMs>=8000);assert.deepEqual(proof.widths,[1100,680]);
 assert.equal(proof.answer.answer,'Continue');assert.deepEqual(proof.answer.value,proof.parent);
 assert.equal(proof.receipts.length,2);
 for(const receipt of proof.receipts){assert.equal(receipt.view.agentId,undefined);assert.deepEqual(receipt.value,proof.parent);}
 return {originalQuestion:true,heldDialog:true,shortcutSuppression:true,exactDraft:true,shortcutRestored:true,noPhantomTurn:true};
}

/** Competing original actions in the composer band and two switchable native panes. */
export const nativeActionPaneAppHook = String.raw`async function read($,e,kind,receipts){
 receipts.push({kind,view:e.props.view,value:await $.prompt.read()});await $.fs.write('native-action-app-receipts.json',JSON.stringify(receipts));
}
export function register(on){
 const receipts=[];
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
  if(e.surface!=='desktop')return next(e);const{Box,Button}=$.ui.resolve(e);
  return Box({flexDirection:'column',children:[
   Button({key:'first-review',label:'Review draft first',action:'app:cycleDiffBase',onPress:()=>read($,e,'above-first',receipts)}),
   Button({key:'later-review',label:'Review draft latest',action:'app:cycleDiffBase',onPress:()=>read($,e,'above-last',receipts)}),
   Button({key:'open-first',label:'Open release notes',onPress:async()=>$.ui.open({id:'release-notes',title:'Release notes',focus:true,rows:2})}),
   Button({key:'open-second',label:'Open migration notes',onPress:async()=>$.ui.open({id:'migration-notes',title:'Migration notes',focus:true,rows:2})}),
  ]});
 });
 on('ui.render',{component:'Pane'},async($,e,next)=>{
  if(e.surface!=='desktop')return next(e);const{Button}=$.ui.resolve(e);
  return Button({key:'pane-review',label:'Review this pane draft',action:'app:cycleDiffBase',onPress:()=>read($,e,'pane:'+e.requestId,receipts)});
 });
}`;

export function verifyNativeActionPaneAppProof(proof){
 assert.equal(proof.noPhantomTurn,true);assert.equal(proof.panesClosed,true);
 assert.ok(Number.isSafeInteger(proof.boundNativePid)&&proof.boundNativePid>1);
 assert.notEqual(proof.paneIds.first,proof.paneIds.second);
 assert.equal(proof.cases.length,12);assert.equal(proof.receipts.length,12);
 const expected=['above-last','pane:'+proof.paneIds.first,'pane:'+proof.paneIds.second,'pane:'+proof.paneIds.first,'pane:'+proof.paneIds.second,'above-last'];
 for(const [i,record]of proof.cases.entries()){
  assert.equal(record.width,i<6?1100:680);assert.equal(record.winner,expected[i%6]);
  assert.equal(proof.receipts[i].kind,record.winner);assert.equal(proof.receipts[i].view.agentId,undefined);assert.deepEqual(proof.receipts[i].value,proof.parent);
 }
 return {panePriority:true,laterRegistration:true,hiddenPaneRetired:true,closedPaneRetired:true,exactDraft:true,noPhantomTurn:true};
}
