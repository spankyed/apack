/** Original Button callbacks used by the disposable desktop keybinding journey. */
export const nativeActionAppHook = String.raw`export function register(on) {
 const receipts=[];let retired=false;
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
  if(e.surface!=='desktop')return next(e);
  const {Box,Text,Button}=$.ui.resolve(e);
  if(retired)return Text({children:['Review shortcuts finished']});
  return Box({flexDirection:'column',children:[
   Button({key:'read-review-draft',label:'Read review draft',action:'app:cycleDiffBase',onPress:async()=>{
    receipts.push({view:e.props.view,value:await $.prompt.read()});
    await $.fs.write('native-action-app-receipts.json',JSON.stringify(receipts));
   }}),
   Button({key:'engine-priority-review',label:'Show review tasks',action:'app:toggleTodos',onPress:async()=>{
    await $.fs.write('native-action-app-wrong-engine-fallback.json',JSON.stringify({view:e.props.view}));
   }}),
   Button({key:'finish-review-shortcuts',label:'Finish review shortcuts',onPress:async()=>{retired=true;$.ui.invalidate('ui.render');}}),
  ]});
 });
}`;

export function nativeActionAppBindings(rebound = false) {
 return [{context:'Global',bindings:{
  'ctrl+alt+u':rebound?null:'app:cycleDiffBase',
  ...(rebound?{'ctrl+alt+r':'app:cycleDiffBase'}:{}),
  'ctrl+alt+k u':'app:cycleDiffBase',
  'ctrl+alt+p':'app:toggleTodos',
 }}];
}
