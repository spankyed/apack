import assert from 'node:assert/strict';

/** Original Button callbacks used by the disposable desktop keybinding journey. */
export const nativeActionAppHook = String.raw`export function register(on) {
 const receipts=[];let retired=false;
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
  if(e.surface!=='desktop')return next(e);
  const {Box,Text,Button}=$.ui.resolve(e);
  if(retired)return Text({children:['Review shortcuts finished']});
  return Box({flexDirection:'column',children:[
   Button({key:'read-review-draft',label:'Read review draft',action:'app:cycleDiffBase',onPress:async()=>{
    receipts.push({view:e.props.view,value:await $.prompt.read()});
    await $.fs.write('native-action-app-receipts.json',JSON.stringify(receipts));
   }}),
   Button({key:'engine-priority-review',label:'Show review tasks',action:'app:toggleTodos',onPress:async()=>{
    await $.fs.write('native-action-app-wrong-engine-fallback.json',JSON.stringify({view:e.props.view}));
   }}),
   Button({key:'finish-review-shortcuts',label:'Finish review shortcuts',onPress:async()=>{retired=true;$.ui.invalidate('ui.render');}}),
  ]});
 });
}`;

export function nativeActionAppBindings(rebound = false, context = 'Global') {
 assert.ok(['Global','Plugin'].includes(context),'Unknown native action context');
 return {bindings:[{context,bindings:{
  'ctrl+alt+u':rebound?null:'app:cycleDiffBase',
  ...(rebound?{'ctrl+alt+r':'app:cycleDiffBase'}:{}),
  'ctrl+alt+k u':'app:cycleDiffBase',
  ...(context==='Global'?{'ctrl+alt+p':'app:toggleTodos'}:{}),
 }},...(context==='Plugin'?[{context:'Global',bindings:{'ctrl+alt+p':'app:toggleTodos'}}]:[])]};
}

/** Independent evidence checks for the context journey; Global acceptance remains separate. */
export function verifyNativeActionContextAppProof(proof) {
 assert.equal(proof.noPhantomTurn,true);assert.equal(proof.contextLeaseReleased,true);
 assert.equal(proof.contextSequence,8);assert.equal(proof.parentReturned,true);
 assert.ok(Number.isSafeInteger(proof.boundNativePid)&&proof.boundNativePid>1);
 const phases=['inactive-single','inactive-chord','active-single','active-chord','deactivated-single','deactivated-chord'];
 assert.equal(proof.contextCases.length,24);assert.equal(proof.receipts.length,17);
 let index=0,callbacks=0;
 for(const view of ['main','agent'])for(const width of [1100,680])for(const phase of phases){
  const expected=phase!=='inactive-single'&&phase!=='deactivated-single';
  if(expected)callbacks++;
  const actual=proof.contextCases[index++];
  assert.equal(actual.view,view);assert.equal(actual.width,width);assert.equal(actual.phase,phase);
  assert.equal(actual.handled,expected);assert.equal(actual.callbacks,callbacks);
 }
 proof.receipts.forEach((receipt,index)=>{
  const agent=index>=8&&index<16;
  assert.equal(receipt.view.agentId,agent?proof.taskId:undefined);
  assert.deepEqual(receipt.value,agent?proof.agent:proof.parent);
 });
 return {mainAndAgentContexts:true,originalEligibility:true,exactDrafts:true,parentReturn:true,noPhantomTurn:true};
}

/** A real original question awaited by a desktop Button, without a model turn. */
export const nativeActionDialogAppHook = String.raw`export function register(on) {
 const receipts=[];
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{
  if(e.surface!=='desktop')return next(e);
  const {Button}=$.ui.resolve(e);
  return Button({key:'review-question',label:'Review release guidance',action:'app:cycleDiffBase',onPress:async()=>{
   receipts.push({view:e.props.view,value:await $.prompt.read()});
   await $.fs.write('native-action-app-receipts.json',JSON.stringify(receipts));
   if(receipts.length===1){
    const answer=await $.ui.ask('Continue reviewing the release guidance?', ['Continue','Pause']);
    await $.fs.write('native-action-dialog-answer.json',JSON.stringify({answer,value:await $.prompt.read()}));
    $.ui.invalidate('ui.render');
   }
  }});
 });
}`;

export function verifyNativeActionDialogAppProof(proof) {
 assert.ok(Number.isSafeInteger(proof.boundNativePid)&&proof.boundNativePid>1);
 assert.equal(proof.noPhantomTurn,true);assert.equal(proof.dialogSuppressedShortcut,true);
 assert.ok(proof.heldMs>=8000);assert.deepEqual(proof.widths,[1100,680]);
 assert.equal(proof.answer.answer,'Continue');assert.deepEqual(proof.answer.value,proof.parent);
 assert.equal(proof.receipts.length,2);
 for(const receipt of proof.receipts){assert.equal(receipt.view.agentId,undefined);assert.deepEqual(receipt.value,proof.parent);}
 return {originalQuestion:true,heldDialog:true,shortcutSuppression:true,exactDraft:true,shortcutRestored:true,noPhantomTurn:true};
}
