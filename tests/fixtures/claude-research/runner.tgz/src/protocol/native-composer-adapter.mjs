import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
/** Exercise the exact authored app helper inside the original process, without an app rebuild. */
export async function nativeComposerAdapter(checkout, outputPath, { terminalPlacements = false } = {}) {
 const source=await readFile(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-composer-runtime.ts'),'utf8');
 const runtime=await readFile(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-ui-runtime.ts'),'utf8');
 const helper=source.slice(source.indexOf('String.raw`')+11,source.lastIndexOf('`'));
 const theme=runtime.slice(runtime.indexOf('function nativeThemeProvider('),runtime.indexOf('let nativeThemeSnapshot;'));
 return `
{
 const {createHash}=await import('node:crypto'),{writeFileSync}=await import('node:fs');
 ${theme}
 ${helper}
 ${terminalPlacements ? `Object.assign(composerSignatures,{
 Pg:{component:'TurnDuration',hash:'53b5427fec9b423983b721ed3152f419c62aab735d8d0fc50a797d92c80c40a8',slot:9},
 Uo:{component:'InfoNotice',hash:'32790fda3445a2da7f59d62c7e62ea9ecdb8602f82e5ab51b0497e192d687ef1',slot:8}
 });` : ''}
 const originalContext=undefined,edits=new Map();
 function nativeViewFacts(n,binding,abort){const selected=binding.toolContext(abort).getAppState().viewingAgentTaskId;if(selected!==undefined)throw Error('Composer probe expects main view');return{view:{kind:'main'}};}
 const n={engine:await import('/$bunfs/root/chunk-c7wcn77x.js'),terminalComponents:await import('/$bunfs/root/chunk-tdpa6qc1.js'),themeRoots:await import('/$bunfs/root/chunk-pg10s5g1.js'),themePreferences:await import('/$bunfs/root/chunk-gnpc8ecg.js'),runtime:await import('/$bunfs/root/chunk-hqtnbrjd.js'),questionOptions:await import('/$bunfs/root/chunk-hdxpvbx1.js'),jsx:await import('/$bunfs/root/chunk-4hec5rn1.js'),appProvider:await import('/$bunfs/root/chunk-002p0hd2.js'),staticRender:await import('/$bunfs/root/chunk-mn4kxp8g.js')};
 const samples=[];let busy=false;const deadline=Date.now()+100000;
 const timer=setInterval(async()=>{if(busy)return;if(Date.now()>deadline){clearInterval(timer);return}busy=true;try{
  if(n.runtime.ey()?.surface!=='terminal')return;
  const list=nativeComposerList(n,'probe');
  for(const item of list){if(samples.some(sample=>sample.component===item.component))continue;const facts=nativeComposerFacts(n,'probe',item.component,item.id);if(!facts)continue;
   const onScreen=n.engine.vfe.askedOnScreen(facts.input),nativeInput=onScreen===undefined?facts.input:{...facts.input,props:{...facts.input.props,onScreen}};
   const settled=n.engine.vfe.settled(nativeInput),held=n.engine.vfe.held(nativeInput);
   if(n.engine.aK.hasRenderHooksFor(facts.input)&&settled===undefined)continue;
   let rewritten;const pending=settled?[settled]:[];let nodes=0;while(pending.length){if(++nodes>1024)throw Error('Native settled tree exceeds bound');const node=pending.pop();if(node?.type==='engine'&&node.ref){const input=n.engine.aK.heldRenderInput(settled,node.ref);if(input?.component===facts.component){rewritten=input.props;break}}if(Array.isArray(node?.children))pending.push(...node.children);}
   const rootsBefore=n.themeRoots.ai().size,props=rewritten??(item.component==='Spinner'?{...facts.props,word:'Native adapter activity'}:item.component==='SessionMode'?{...facts.props,modes:['Native adapter mode']}:facts.props);
   const text=await formatNativeComposer(n,facts,props,{columns:80,signal:new AbortController().signal});
   const shape=value=>{if(value===undefined)return{unavailable:true};try{const raw=JSON.stringify(value);return raw===undefined?{notSerializable:true}:raw.length<=16384?JSON.parse(raw):{truncated:true}}catch{return{notSerializable:true}}};
   const binding=n.runtime.ey(),taskState=binding.toolContext(new AbortController()).getAppState().tasks;
   samples.push({component:item.component,id:item.id,props:facts.props,originalViewport:nativeInput.viewport,onScreen,shownProps:props,text,settled:shape(settled),held:shape(held),taskTypes:Object.values(taskState??{}).map(task=>({type:task.type,status:task.status})).slice(0,32),rootsBefore,rootsAfter:n.themeRoots.ai().size});
  }
  writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({samples},null,2),{mode:0o600});
 }catch(error){writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({samples,error:String(error)}),{mode:0o600});}finally{busy=false}},200);timer.unref();
}
`;
}
