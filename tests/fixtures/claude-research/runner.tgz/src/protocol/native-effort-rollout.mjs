import assert from 'node:assert/strict';
import {CREDIT_ACCOUNT_ID,CREDIT_ORGANIZATION_ID} from './native-credit-account.mjs';

/** Source-valid copy, delivered only through the original remote-evaluation protocol in an owned test. */
export const EFFORT_ROLLOUT_COPY=Object.freeze({title:'Try medium effort',body:'Use medium effort for quicker everyday reviews.\nYou can change it later from /effort.',confirmLabel:'Use medium',cancelLabel:'Keep high',cancelFirst:true,fromEffort:'high',toEffort:'medium',showWarning:true,warningText:'Choose the effort that fits this task.'});
export const EFFORT_EVAL_ROUTE='/api/eval/sdk-zAZezfDKGoZuXXKe';
export function effortRolloutResponse(body){
 assert.equal(body?.attributes?.accountUUID,CREDIT_ACCOUNT_ID);
 assert.equal(body.attributes.organizationUUID,CREDIT_ORGANIZATION_ID);
 return{features:{tengu_radiant_island:{defaultValue:{...EFFORT_ROLLOUT_COPY}}}};
}

/** Preserve only the original effort decision metadata, never auth or unrelated telemetry. */
export function effortDecisionEvents(body){
 assert.ok(Array.isArray(body?.events)&&body.events.length<=512);
 return body.events.flatMap(event=>{
  const value=event?.event_data;
  if(event?.event_type!=='ClaudeCodeInternalEvent'||value?.event_name!=='tengu_effort_medium_nudge_resolved')return[];
  assert.equal(typeof value.session_id,'string');assert.equal(typeof value.additional_metadata,'string');assert.ok(value.additional_metadata.length<=65536);
  const metadata=JSON.parse(Buffer.from(value.additional_metadata,'base64').toString());
  const fields=['choice','outcome','option_order','cohort','nudge_model','from_level','to_level','warning_shown'];
  return[{eventName:value.event_name,sessionId:value.session_id,metadata:Object.fromEntries(fields.filter(key=>Object.hasOwn(metadata,key)).map(key=>[key,metadata[key]]))}];
 });
}
