import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readdir, readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parse } from 'acorn';

const components = new Set(['Spinner', 'TurnDuration', 'InfoNotice', 'SessionMode', 'PromptHint']);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');

/** Locate declarations without importing/executing recovered modules. Byte offsets refer to UTF-8 files. */
export async function nativeComposerSignatures(directory) {
  const found = new Map();
  for (const file of (await readdir(directory)).filter(file => file.endsWith('.js')).sort()) {
    const bytes = await readFile(join(directory, file)), source = bytes.toString('utf8');
    if (!source.includes('useRenderInput')) continue;
    assert.ok(bytes.equals(Buffer.from(source)), 'Recovered source must be valid UTF-8');
    const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module' });
    const pending = [{ node: ast, ancestors: [] }];
    while (pending.length) {
      const { node, ancestors } = pending.pop();
      const callee = node.type === 'CallExpression' ? node.callee : undefined;
      const property = callee?.type === 'MemberExpression' ? callee.computed ? callee.property.value : callee.property.name : undefined;
      const component = node.arguments?.[0]?.type === 'Literal' ? node.arguments[0].value : undefined;
      if (property === 'useRenderInput' && components.has(component)) {
        assert.ok(!found.has(component), 'Multiple producers require source review: ' + component);
        const fn = [...ancestors].reverse().find(item => ['FunctionDeclaration', 'FunctionExpression', 'ArrowFunctionExpression'].includes(item.type));
        assert.ok(fn, 'Producer must have a lexical function owner');
        const declaration = [...ancestors.slice(0, ancestors.indexOf(fn))].reverse().find(item => item.type === 'VariableDeclarator');
        const name = fn.id?.name ?? declaration?.id?.name;
        assert.ok(name, 'Anonymous producer requires explicit source review');
        found.set(component, {
          component, file, fileSha256: hash(bytes), name,
          startByte: Buffer.byteLength(source.slice(0, fn.start)), endByte: Buffer.byteLength(source.slice(0, fn.end)),
          useRenderInputByteOffset: Buffer.byteLength(source.slice(0, node.start)),
          functionSha256: hash(Buffer.from(source.slice(fn.start, fn.end))),
        });
      }
      for (const value of Object.values(node)) {
        if (Array.isArray(value)) for (const child of value) { if (child?.type) pending.push({ node: child, ancestors: [...ancestors, node] }); }
        else if (value?.type) pending.push({ node: value, ancestors: [...ancestors, node] });
      }
    }
  }
  assert.deepEqual([...found.keys()].sort(), [...components].sort(), 'Missing original composer producers');
  return [...found.values()].sort((a, b) => a.component.localeCompare(b.component));
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  assert.equal(process.argv.length, 3, 'Usage: node src/protocol/native-composer-signatures.mjs <extracted-files-directory>');
  console.log(JSON.stringify(await nativeComposerSignatures(resolve(process.argv[2])), null, 2));
}
