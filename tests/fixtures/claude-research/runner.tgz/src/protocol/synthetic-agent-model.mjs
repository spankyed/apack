import http from 'node:http';
import { isAbsolute } from 'node:path';

export const HANDBACK_CALLER_REPORT='Release review complete. The migration example is still being reviewed.';
export const HANDBACK_LATE_REPORT='Migration review complete. Keep the upgrade example before publishing.';
export const HANDBACK_RELEASE_REPORT='Release review complete.\n\nThe release notes cover behavior changes and migration guidance.\nCheck the migration example before publishing.';

export const WORKFLOW_APPROVAL_FIXTURE_SCRIPT='export const meta = {name: "release-review", description: "Review release notes", phases: [{title: "Review"}]}; return await agent("Return the synthetic worker marker only.", {agentType: "status-fixture", label: "Release reviewer", phase: "Review"});';
export const WORKFLOW_PROGRESS_FIXTURE_SCRIPT=WORKFLOW_APPROVAL_FIXTURE_SCRIPT.replace('; return await','; log("Release review started"); const reviewed = await')+' log("Release review finished"); return reviewed;';
export const WORKFLOW_RESUME_FIXTURE_SCRIPT='export const meta = {name: "release-review", description: "Review release notes", phases: [{title: "Collect"}, {title: "Review"}]}; phase("Collect"); const collected = await agent("CachedStageFixture", {agentType: "status-fixture", label: "Collect reviewer", phase: "Collect"}); phase("Review"); const reviewed = await agent("ResumeStageFixture", {agentType: "status-fixture", label: "Release reviewer", phase: "Review"}); return {collected, reviewed};';

/** A bounded Agent fixture: one custom worker, optionally requesting a caller-specified fixture tool. */
export async function startSyntheticAgentModel({ childTool, workflowProbe=false, workflowScript, workflowName, workflowGrantScope=false, workflowResumeProbe=false, workflowWorkspace, workflowReturnBarrier, backgroundAgent=false, handbackProbe=false, handbackNested=false, handbackCancelCaller=false, beforeCallerCancel, handbackDuplicate=false, handbackClassifierSafe=false, agentClassifierSafe=false, handbackClassifierOutcome, handbackClassifierUnavailable=false, handbackMessage, referenceFile, referenceRetry=false, childDelayMs=7500, onPauseRequest, questionProbe=false, questionRecoveryProbe=false, questionPreviewFormat='markdown', steeringProbe=false, holdChildUntilRelease=false, requestLimit, parentLaunchOnce=false, launchAgent=true, everydayProbe=false, captureMessages=false, beforeDecision } = {}) {
  if(workflowReturnBarrier!==undefined&&(typeof workflowReturnBarrier!=='function'||!workflowProbe||!holdChildUntilRelease))throw Error('Workflow return barrier requires the held native Workflow fixture');
  if(typeof workflowResumeProbe!=='boolean'||workflowResumeProbe&&(!workflowProbe||!isAbsolute(workflowWorkspace??'')))throw Error('Invalid Workflow resume fixture');
  if(typeof workflowGrantScope!=='boolean'||workflowGrantScope&&workflowName!=='release-review')throw new Error('Invalid Workflow grant-scope fixture');
  if(workflowName!==undefined&&(!workflowProbe||workflowName!=='release-review'))throw new Error('Invalid named Workflow fixture');
  if(workflowScript!==undefined&&(!workflowProbe||typeof workflowScript!=='string'||workflowScript.length>250000))throw new Error('Invalid Workflow fixture script');
  if(beforeDecision!==undefined&&(!everydayProbe||typeof beforeDecision!=='function'))throw new Error('Decision barrier requires the everyday fixture');
  if(typeof captureMessages!=='boolean')throw new Error('Invalid message capture fixture');
  if(typeof agentClassifierSafe!=='boolean'||agentClassifierSafe&&(!captureMessages||!parentLaunchOnce||!launchAgent||handbackProbe||childTool||workflowProbe))throw Error('Fixed Agent classifier requires the captured single-worker fixture');
  if(typeof everydayProbe!=='boolean')throw new Error('Invalid everyday journey fixture');
  if(typeof launchAgent!=='boolean')throw new Error('Invalid Agent launch fixture');
  if(typeof parentLaunchOnce!=='boolean')throw new Error('Invalid single parent launch fixture');
  if(requestLimit!==undefined&&(!Number.isInteger(requestLimit)||requestLimit<1||requestLimit>16))throw new Error('Synthetic Agent request limit must be between 1 and 16');
  if(typeof holdChildUntilRelease!=='boolean')throw new Error('Invalid child hold probe');
  if(typeof steeringProbe!=='boolean')throw new Error('Invalid steering probe');
  if(!['markdown','html'].includes(questionPreviewFormat))throw new Error('Invalid question preview format');
  if(typeof questionProbe!=='boolean')throw new Error('Invalid question probe');
  if(typeof questionRecoveryProbe!=='boolean'||questionRecoveryProbe&&(!questionProbe||!everydayProbe||launchAgent))throw Error('Question recovery requires an everyday question-only fixture');
  if(onPauseRequest!==undefined&&typeof onPauseRequest!=='function')throw new Error('Pause fixture callback must be a function');
  if(!Number.isInteger(childDelayMs)||childDelayMs<7500||childDelayMs>15000)throw new Error('Child fixture delay must be bounded between 7500 and 15000ms');
  if(referenceFile !== undefined && (typeof referenceFile !== 'string' || !isAbsolute(referenceFile) || childTool || handbackProbe)) throw new Error('Reference fixture requires one absolute file and no child-tool scenario');
  if(typeof workflowProbe!=='boolean')throw Error('Invalid workflow probe');
  if(typeof backgroundAgent!=='boolean')throw Error('Invalid background Agent fixture');
  if(typeof handbackProbe!=='boolean'||handbackProbe&&childTool)throw new Error('Handback probe cannot combine arbitrary child tools');
  if(typeof handbackClassifierUnavailable!=='boolean'||handbackClassifierUnavailable&&!handbackProbe)throw Error('Classifier outage requires the fixed handback fixture');
  if(handbackMessage!==undefined&&(!handbackProbe||typeof handbackMessage!=='string'||!handbackMessage.trim()||handbackMessage.length>16384))throw Error('Invalid fixed handback message');
  if(beforeCallerCancel!==undefined&&(!handbackCancelCaller||typeof beforeCallerCancel!=='function'))throw Error('Cancellation barrier requires fixed caller cancellation');
  if(typeof handbackCancelCaller!=='boolean'||handbackCancelCaller&&!handbackNested)throw Error('Caller cancellation requires nested handback fixture');
  if(typeof handbackNested!=='boolean'||handbackNested&&(!handbackProbe||handbackDuplicate))throw Error('Invalid nested handback fixture');
  if(typeof handbackDuplicate!=='boolean'||handbackDuplicate&&!handbackProbe||typeof handbackClassifierSafe!=='boolean'||handbackClassifierSafe&&(!handbackProbe||handbackClassifierUnavailable))throw Error('Invalid fixed handback variant');
  if(handbackClassifierOutcome!==undefined&&(!handbackProbe||!['blocked','refused'].includes(handbackClassifierOutcome)||handbackClassifierSafe||handbackClassifierUnavailable))throw Error('Invalid handback classifier outcome');
  if(handbackProbe)childTool={name:'SubagentHandback',input:{message:handbackMessage??'HAND_BACK_FIXTURE'}};
  let releaseChild;const childReady=new Promise(resolve=>{releaseChild=resolve});
  let releaseGrandchild;const grandchildReady=new Promise(resolve=>{releaseGrandchild=resolve});
  let grandchildRequested;const grandchildStarted=new Promise(resolve=>{grandchildRequested=resolve});
  const calls=[],requests=[],delayedResponses=new Set();let sequence=0,parentLaunched=!launchAgent,nextParentDelayMs=0;
  const server=http.createServer((req,res)=>{respond(req,res).catch(()=>{if(!res.headersSent)res.writeHead(400);res.end('{}')})});
  server.requestTimeout=12000;
  async function respond(req,res){
    let bytes=0;const chunks=[];
    for await(const chunk of req){bytes+=chunk.length;if(bytes>2*1024*1024){res.writeHead(413);res.end();return}chunks.push(chunk)}
    const body=JSON.parse(Buffer.concat(chunks).toString()||'{}');
    if(req.url?.includes('count_tokens')){res.writeHead(200,{'content-type':'application/json'});res.end('{"input_tokens":10}');return}
    if(!req.url?.startsWith('/v1/messages')){res.writeHead(404);res.end('{}');return}
    if(++sequence>(requestLimit??(steeringProbe?10:questionProbe?12:referenceFile?10:childTool?10:6))){res.writeHead(429);res.end('{}');return}
    requests.push(body);
    const grandchild=handbackNested&&JSON.stringify(body.system??'').includes('NativeStatusGrandchildSystem');
    const child=grandchild||JSON.stringify(body.system??'').includes('NativeStatusChildSystem');
    const results=body.messages?.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[])??[];
    const result=results.find(block=>block.tool_use_id==='status_agent_fixture');
    const childResult=results.find(block=>block.tool_use_id==='child_permission_fixture');
    const agent=body.tools?.find(tool=>tool.name===(workflowProbe?'Workflow':'Agent'));
    const call={grandchild,requestIndex:requests.length-1,child,hasAgentResult:!!result,agentResultError:result?.is_error===true,toolNames:body.tools?.map(tool=>tool.name),model:body.model};calls.push(call);if(everydayProbe||captureMessages)call.messages=body.messages;
    if(handbackCancelCaller)res.once('close',()=>{if(!res.writableEnded)call.responseCancelled=true;});
    if(grandchild)grandchildRequested();
    if(handbackClassifierUnavailable&&!child&&!body.tools?.length&&JSON.stringify(body.system??'').includes('You are a security monitor for autonomous AI coding agents.')){call.classifierUnavailable=true;res.writeHead(503,{'content-type':'application/json'});res.end(JSON.stringify({type:'error',error:{type:'api_error',message:'Synthetic classifier unavailable'}}));return;}
    const fixedAgentClassifier=agentClassifierSafe&&!child&&!body.tools?.length&&JSON.stringify(body.system??'').includes('You are a security monitor for autonomous AI coding agents.');
    if(fixedAgentClassifier){
      const message=body.messages?.filter(message=>message.role==='user').at(-1),content=message?.content;
      const text=typeof content==='string'?content:Array.isArray(content)?content.filter(block=>block.type==='text').map(block=>block.text).join(''):'';
      let rows;try{rows=text.match(/<transcript>\n([\s\S]*?)<\/transcript>/)?.[1].trim().split('\n').filter(Boolean).map(line=>JSON.parse(line));}catch{}
      const worker='(status-fixture): Return the synthetic worker marker only.';
      const shaped=Array.isArray(rows)&&rows.every(row=>row&&typeof row==='object'&&!Array.isArray(row));
      const exact=shaped&&rows.some(row=>row.Agent===worker)&&rows.every(row=>Object.keys(row).length===1&&(row.Agent===worker||['Review the release notes for this project.','Review the release notes with a worker.'].includes(row.user)));
      if(!exact){call.classifierRefused=true;res.writeHead(503,{'content-type':'application/json'});res.end(JSON.stringify({type:'error',error:{type:'api_error',message:'Unknown fixed Agent classifier transcript'}}));return;}
      call.classifierScope='status-fixture';
    }
    const classifier=fixedAgentClassifier||(handbackClassifierSafe||handbackClassifierOutcome!==undefined)&&!child&&!body.tools?.length&&JSON.stringify(body.system??'').includes('You are a security monitor for autonomous AI coding agents.');
    if(classifier){call.classifierOutcome=handbackClassifierOutcome??'safe';if(handbackClassifierOutcome!=='refused')call.classifierSeverity=handbackClassifierOutcome==='blocked'?100:0;}
    const latestUser=body.messages?.filter(message=>message.role==='user').at(-1);
    const childStage=workflowResumeProbe&&child?(JSON.stringify(latestUser??'').includes('ResumeStageFixture')?'resume':JSON.stringify(latestUser??'').includes('CachedStageFixture')?'cached':undefined):undefined;if(workflowResumeProbe&&child&&!childStage)throw Error('Unknown native Workflow child stage');if(childStage)call.workflowStage=childStage;
    const steered=steeringProbe&&child&&JSON.stringify(latestUser??'').includes('NativeAgentSteerFixture');
    if(steeringProbe)call.steeringObserved=steered;
    if(onPauseRequest&&JSON.stringify(latestUser??'').includes(everydayProbe?'Draft the release summary':'NativePauseFixture')){
      call.pauseWaiting=true;
      await onPauseRequest();
      await new Promise(resolve=>{if(res.destroyed)resolve();else res.once('close',resolve)});
      call.pauseCancelled=true;
      return;
    }
    const denyReference=!!referenceFile&&JSON.stringify(body.messages??[]).includes('NativeReferenceDenyFixture');
    const retryReference=referenceRetry&&(JSON.stringify(latestUser??'').includes('after recovery')||results.some(block=>block.tool_use_id==='native_reference_retry'));
    const referenceId=retryReference?'native_reference_retry':denyReference?'native_reference_deny':'native_reference_read';
    const referenceRequested=denyReference||!!referenceFile && (everydayProbe ? results.some(block=>block.tool_use_id===referenceId)||JSON.stringify(latestUser??'').includes('Read the release checklist') : JSON.stringify(body.messages??[]).includes('NativeReferenceReadFixture'));
    const referenceResult=results.find(block=>block.tool_use_id===referenceId);
    const referenceTool=referenceRequested&&!referenceResult;
    if(referenceRequested){if(referenceRetry)call.referenceReadId=referenceId;call.referenceReadRequested=true;if(referenceResult){call.referenceReadResult=referenceResult.content;call.referenceReadError=referenceResult.is_error===true;}}
    const questionId=questionRecoveryProbe&&(JSON.stringify(latestUser??'').includes('after recovering the question')||results.some(block=>block.tool_use_id==='native_question_recovery_fixture'))?'native_question_recovery_fixture':'native_question_fixture';
    const questionRequested=questionProbe&&(everydayProbe ? results.some(block=>block.tool_use_id===questionId)||JSON.stringify(latestUser??'').includes('Ask me which release audience') : JSON.stringify(body.messages??[]).includes('NativeQuestionFixture'));
    const questionResult=results.find(block=>block.tool_use_id===questionId);
    const questionTool=questionRequested&&!questionResult;
    if(questionResult){call.nativeQuestionResult=questionResult.content;call.nativeQuestionError=questionResult.is_error===true;}
    const workflowStage=workflowGrantScope&&!child?(JSON.stringify(latestUser??'').includes('Run the saved release review again.')?'repeat':JSON.stringify(latestUser??'').includes('Run the separate security review.')?'unrelated':undefined):undefined;
    const workflowStageId=workflowStage?'workflow_scope_'+workflowStage:undefined;
    const scopeTool=!!workflowStageId&&!results.some(block=>block.tool_use_id===workflowStageId);
    if(workflowStage)call.workflowStage=workflowStage;
    const resumeMatch=workflowResumeProbe&&!child?/Workflow\(\{scriptPath: '([^']+)', resumeFromRunId: '([^']+)'/.exec(JSON.stringify(latestUser??'')):undefined;
    if(resumeMatch&&!resumeMatch[1].startsWith(workflowWorkspace+'/'))throw Error('Resume fixture escaped private workspace');
    const resumeTool=!!resumeMatch&&!results.some(block=>block.tool_use_id==='workflow_resume_fixture');
    const callerText=handbackCancelCaller&&!child&&result?JSON.stringify(result.content):'';
    const callerId=handbackCancelCaller?/agentId: ([a-zA-Z0-9_-]+)/.exec(callerText)?.[1]:undefined;
    const stopCaller=!!callerId&&!results.some(block=>block.tool_use_id==='cancel_caller_fixture');
    if(stopCaller&&!body.tools?.some(tool=>tool.name==='TaskStop'&&tool.input_schema?.properties?.task_id))throw Error('Original TaskStop is unavailable');
    if(stopCaller){await grandchildStarted;await beforeCallerCancel?.();}
    const parentTool=!classifier&&!stopCaller&&(resumeTool||scopeTool||!referenceRequested&&!child&&!result&&!!agent&&(!parentLaunchOnce||!parentLaunched));
    const nestedTool=handbackNested&&child&&!grandchild&&!results.some(block=>block.tool_use_id==='nested_agent_fixture');
    if(nestedTool&&!agent)throw Error('Original caller does not advertise nested Agent');
    let useChildTool=child&&!!childTool&&!childResult&&!nestedTool;
    if(child&&handbackProbe){call.handbackOffered=body.tools?.some(tool=>tool.name==='SubagentHandback')??false;if(!call.handbackOffered)useChildTool=false;}
    const useTool=stopCaller||nestedTool||(questionRequested?questionTool:referenceTool||parentTool||useChildTool);
    if(parentTool){if(backgroundAgent&&!workflowProbe&&!agent.input_schema?.properties?.run_in_background)throw Error('Original Agent does not admit run_in_background');parentLaunched=true;for(const key of (workflowProbe?[workflowName?'name':'script']:['prompt','description','subagent_type']))if(!agent.input_schema?.properties?.[key])throw Error('Unexpected Agent schema');call.agentSchema=agent.input_schema;}
    if(useChildTool&&!body.tools?.some(tool=>tool.name===childTool.name))throw Error('Child fixture tool unavailable');
    if(referenceTool&&!body.tools?.some(tool=>tool.name==='Read'))throw Error('Reference Read tool unavailable');
    if(questionTool&&!body.tools?.some(tool=>tool.name==='AskUserQuestion'))throw Error('Native question tool unavailable');
    const handbackParentText=handbackCancelCaller&&results.some(block=>block.tool_use_id==='cancel_caller_fixture')?'The release review was cancelled. No worker report was delivered.':handbackMessage!==undefined?(JSON.stringify(body.messages??[]).includes(handbackMessage.split('\n')[0])?'The Agent review is complete. Check the migration example before publishing.':'A release reviewer is checking the notes. I will bring the report back here.'):undefined;
    const block=stopCaller?{type:'tool_use',id:'cancel_caller_fixture',name:'TaskStop',input:{task_id:callerId}}:nestedTool?{type:'tool_use',id:'nested_agent_fixture',name:'Agent',input:{description:'Review migration example',prompt:'Return the late migration report.',subagent_type:'late-fixture',run_in_background:!handbackCancelCaller}}:classifier?{type:'text',text:handbackClassifierOutcome==='refused'?'Fixed research classifier refusal.':handbackClassifierOutcome==='blocked'?'<severity>100</severity><category>Data Exfiltration</category><reason>Fixed research review warning.</reason>':'<severity>0</severity>'}:questionTool?{type:'tool_use',id:questionId,name:'AskUserQuestion',input:{questions:everydayProbe?[{question:'Who should the release summary address?',header:'Audience',options:[{label:'Developers',description:'People integrating the updated behavior'},{label:'Operators',description:'People deploying and maintaining it'}],multiSelect:false}]:[
      {question:'Which native answer should be used?',header:'First',options:[{label:'Alpha',description:'First fixture'},{label:'Beta',description:'Second fixture'}],multiSelect:false},
      {question:'Which native options should be combined?',header:'Second',options:[{label:'Gamma',description:'Third fixture',preview:questionPreviewFormat==='html'?'<div style="border-left:3px solid #aa9977;padding:8px"><strong>Native Gamma preview</strong><p>HTML option fragment</p><img src="https://preview.invalid/leak" onerror="top.previewPoisoned=true"><a href="https://preview.invalid/nav">Preview link</a></div>':'**Native Gamma preview**\n\n```ts\nconst selected = true;\n```'},{label:'Delta',description:'Fourth fixture',preview:questionPreviewFormat==='html'?'<div>'+ 'x'.repeat(2001)+'</div>':'x'.repeat(2001)}],multiSelect:true}
    ]}}:questionRequested?{type:'text',text:everydayProbe?'I will write the release summary for developers.':'NativeQuestionComplete'}:referenceTool?{type:'tool_use',id:referenceId,name:'Read',input:{file_path:referenceFile}}:referenceRequested?{type:'text',text:everydayProbe?'The release checklist is available. I will preserve the existing guidance.':'NativeReferenceReadComplete'}:useChildTool?{type:'tool_use',id:'child_permission_fixture',name:childTool.name,input:handbackNested?{message:grandchild?HANDBACK_LATE_REPORT:HANDBACK_CALLER_REPORT}:childTool.input}:parentTool?{type:'tool_use',id:resumeTool?'workflow_resume_fixture':workflowStageId??'status_agent_fixture',name:workflowProbe?'Workflow':'Agent',input:workflowProbe?(resumeTool?{scriptPath:resumeMatch[1],resumeFromRunId:resumeMatch[2]}:workflowName?{name:workflowStage==='unrelated'?'security-review':workflowName}:{script:workflowScript??WORKFLOW_APPROVAL_FIXTURE_SCRIPT}):{description:everydayProbe||handbackMessage!==undefined?'Review release notes':'Disposable status fixture',prompt:everydayProbe?'Review the release note structure and return a brief summary.':'Return the synthetic worker marker only.',subagent_type:everydayProbe?'release-reviewer':'status-fixture',...((handbackProbe||backgroundAgent)&&agent.input_schema?.properties?.run_in_background?{run_in_background:true}:{})}}:{type:'text',text:child?workflowResumeProbe?childStage==='cached'?'CachedStageComplete':'ResumeStageComplete':handbackProbe?'HAND_BACK_UNAVAILABLE':steered?'ChildSteeringObserved':everydayProbe?'The release notes cover behavior changes and migration guidance.':'SubagentFixtureComplete':handbackParentText??(everydayProbe?'The release review is ready. I can check the checklist next.':'ParentSubagentFixtureComplete')};
    if(parentTool&&(workflowGrantScope||workflowResumeProbe))call.workflowInput=block.input;
    call.response=useTool?block.name:block.text;
    if(everydayProbe&&beforeDecision&&(referenceTool||questionTool))await beforeDecision(block.name);
    if(childResult){call.childToolResult=childResult.content;call.childToolError=childResult.is_error===true;}
    if(grandchild)await grandchildReady;
    const returnCheckpoint=!!workflowReturnBarrier&&child&&JSON.stringify(latestUser??'').includes('WorkflowReturnCheckpoint');
    if(returnCheckpoint){
      call.workflowReturnCheckpoint=true;const abort=new AbortController(),cancel=()=>abort.abort();res.once('close',cancel);
      try{call.workflowReturnBarrier=await workflowReturnBarrier(abort.signal);}finally{res.off('close',cancel);}
    }
    if(child&&!returnCheckpoint&&(handbackProbe||holdChildUntilRelease)&&!(workflowResumeProbe&&childStage==='cached')){await childReady;call.heldReleased=true;call.disconnectedWhenReleased=res.destroyed;}
    if(child&&!steered&&!handbackProbe&&!holdChildUntilRelease&&(!childTool||useChildTool))await new Promise(resolve=>setTimeout(resolve,childDelayMs));
    if(!child&&nextParentDelayMs){
      const ms=nextParentDelayMs;nextParentDelayMs=0;call.delayedMs=ms;
      const waiting=new Promise(resolve=>{const done=()=>{if(res.destroyed)call.delayCancelled=true;clearTimeout(timer);res.off('close',done);resolve()};const timer=setTimeout(done,ms);res.once('close',done)});
      delayedResponses.add(waiting);try{await waiting}finally{delayedResponses.delete(waiting)}
    }
    if(res.destroyed)return;
    const blocks=handbackDuplicate&&useChildTool?[block,{...block,id:'child_handback_duplicate'}]:[block];
    const message={id:`msg_status_agent_${sequence}`,type:'message',role:'assistant',model:body.model,content:blocks,stop_reason:classifier&&handbackClassifierOutcome==='refused'?'refusal':useTool?'tool_use':'end_turn',stop_sequence:null,usage:{input_tokens:10,output_tokens:5}};
    call.responseMessageId=message.id;
    if(!body.stream){res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(message));call.delivered=true;return}
    res.writeHead(200,{'content-type':'text/event-stream'});
    const send=(type,value)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...value})}\n\n`);
    send('message_start',{message:{...message,content:[],stop_reason:null,usage:{input_tokens:10,output_tokens:0}}});
    for(const [index,item] of blocks.entries()){
      send('content_block_start',{index,content_block:useTool?{...item,input:{}}:{type:'text',text:''}});
      send('content_block_delta',{index,delta:useTool?{type:'input_json_delta',partial_json:JSON.stringify(item.input)}:{type:'text_delta',text:item.text}});
      send('content_block_stop',{index});
    }
    send('message_delta',{delta:{stop_reason:message.stop_reason,stop_sequence:null},usage:{output_tokens:5}});send('message_stop',{});res.end();call.delivered=true;
  }
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
  return {calls,requests,delayNextParentResponse(ms){if(!server.listening||!Number.isInteger(ms)||ms<1||ms>10000||nextParentDelayMs)throw Error('Invalid or already pending parent response delay');nextParentDelayMs=ms;},messageRequestCount:()=>sequence,releaseChild:()=>releaseChild(),releaseGrandchild:()=>releaseGrandchild(),url:`http://127.0.0.1:${server.address().port}`,async close(){releaseChild();releaseGrandchild();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await Promise.all([...delayedResponses])}};
}
