import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Native parsed persisted model settings, without a prompt or account credentials. */
export async function probeModelSettings(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'model-settings-'));
 const run=await createRun(output,'model-settings',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))}),cases=[];
 try{
  for(const effortLevel of ['low','xhigh','max','invalid']){
   const cwd=join(workspace,effortLevel),home=join(cwd,'home'),config=join(home,'.claude');await mkdir(config,{recursive:true});
   const settings=join(config,'settings.json'),before=JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',model:'sonnet',modelSettings:{'claude-sonnet-5-5':{effortLevel}}});await writeFile(settings,before);
   let model,pending='',reply,initialized=false;
   const request=(id,request)=>JSON.stringify({type:'control_request',request_id:id,request})+'\n';
   try{
    model=await startSyntheticModel(cwd,'TextOnly');
    const transport=await record({executable,cwd,output,timeoutMs:15000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','','--no-session-persistence'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[request('model-settings-init',{subtype:'initialize'})],onStdout(bytes,channel){
     pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
      if(value.type!=='control_response')continue;
      if(value.response?.request_id==='model-settings-init'){assert.equal(value.response.subtype,'success');initialized=true;channel.send(request('model-settings-read',{subtype:'get_settings'}));}
      else if(value.response?.request_id==='model-settings-read'){reply=value.response;channel.closeInput();}
     }
    }});
    assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(initialized,true);assert.equal(reply?.subtype,'success');assert.equal(model.calls.length,0);assert.equal(await readFile(settings,'utf8'),before);
    const parsed=reply.response.effective.modelSettings?.['claude-sonnet-5-5'];
    assert.equal(parsed?.effortLevel,['low','xhigh'].includes(effortLevel)?effortLevel:undefined);
    cases.push({requestedEffort:effortLevel,parsedModelSettings:parsed??null,applied:reply.response.applied,settingsUnchanged:true,localModelRequests:0,transportRun:transport.directory});
   }finally{await model?.close();}
  }
  const evidence={cases,realModelRequests:0,qualification:'Private user-source parsed per-model effort settings only; no turn-level effective effort, real provider/account, policy, UI or all settings validation claim.'};await writeFile(join(run.directory,'model-settings.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete'});return {directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
