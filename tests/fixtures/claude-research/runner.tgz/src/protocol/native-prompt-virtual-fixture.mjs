export const virtualDraft = 'Review the release checklist.';
export const virtualHint = '[suggest adding a rollback step] ';

export const virtualHintHook = `export function register(on) {
    on('prompt.edit', async ($, event, next) => {
      const frame = await next(event);
      if (frame.text !== ${JSON.stringify(virtualDraft)}) return frame;
      const pos = frame.text.indexOf('checklist');
      const decorations = [
        { start: 0, end: frame.text.length, bold: true },
        { start: pos, end: pos, virtualText: ${JSON.stringify(virtualHint)}, dimColor: true },
      ];
      await $.fs.write('virtual-edit.json', JSON.stringify({ text: frame.text, decorations }));
      return { ...frame, decorations };
    });
    on('prompt.submit', async ($, event, next) => {
      await $.fs.write('virtual-submit.json', JSON.stringify({ text: event.text }));
      return next(event);
    });
  }`;


// The PTY driver arms this only after the original composer is visible.
export const virtualFillTrigger = 'virtual-fill-ready.json';
export const virtualFillHook = `export function register(on) {
  let started = false;
  on('session.start', async ($, event, next) => {
    if (!started) {
      started = true;
      let busy = false;
      const tick = $.clock.every(150, () => {
        if (busy) return;
        busy = true;
        (async () => {
          const ready = await $.fs.read(${JSON.stringify(virtualFillTrigger)}).catch(() => '');
          if (ready !== 'true') return;
          tick.cancel();
          const text = ${JSON.stringify(virtualDraft)}, pos = text.indexOf('checklist');
          const input = { text, mode: 'replace', decorations: [
            { start: 0, end: text.length, bold: true },
            { start: pos, end: pos, virtualText: ${JSON.stringify(virtualHint)}, dimColor: true },
          ] };
          const before = await $.prompt.read();
          const result = await $.prompt.fill(input);
          const after = await $.prompt.read();
          await $.fs.write('virtual-fill.json', JSON.stringify({ before, input, result, after }));
        })().catch(async error => {
          await $.fs.write('virtual-fill.json', JSON.stringify({ error: String(error) }));
        }).finally(() => { busy = false; });
      });
    }
    return next(event);
  });
  on('prompt.submit', async ($, event, next) => {
    await $.fs.write('virtual-submit.json', JSON.stringify({ text: event.text }));
    return next(event);
  });
}`;

export const desktopVirtualFillTrigger = 'virtual-desktop-fill-step.json';
export const desktopVirtualFillSteps = [
  { mode: 'replace', text: virtualDraft, anchor: 'checklist', hint: virtualHint },
  { mode: 'append', text: ' Keep migration notes.', anchor: 'migration', hint: '[verify upgrade steps] ' },
  { mode: 'insert', text: 'verified ', anchor: 'verified', hint: '[confirm the baseline] ' },
];

// Advance only when the actual app driver has verified its current editor and requested that step.
export const desktopVirtualFillHook = `export function register(on) {
  let started = false, busy = false, phase = 0;
  const receipts = [], steps = ${JSON.stringify(desktopVirtualFillSteps)};
  on('session.start', async ($, event, next) => {
    if (!started) {
      started = true;
      const tick = $.clock.every(150, () => {
        if (busy || phase >= steps.length) return;
        busy = true;
        (async () => {
          const command = await $.fs.read(${JSON.stringify(desktopVirtualFillTrigger)}).catch(() => '');
          if (command !== String(phase + 1)) return;
          const step = steps[phase], at = step.text.indexOf(step.anchor);
          const input = { mode: step.mode, text: step.text, decorations: [
            { start: 0, end: step.text.length, bold: true },
            { start: at, end: at, virtualText: step.hint, dimColor: true },
          ] };
          const before = await $.prompt.read();
          const result = await $.prompt.fill(input);
          const after = await $.prompt.read();
          receipts.push({ input, before, result, after });
          phase++;
          if (phase === steps.length) tick.cancel();
          await $.fs.write('virtual-desktop-fill.json', JSON.stringify(receipts));
        })().catch(async error => {
          tick.cancel();
          await $.fs.write('virtual-desktop-fill-error.txt', String(error));
        }).finally(() => { busy = false; });
      });
    }
    return next(event);
  });
}`;
