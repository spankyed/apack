import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

/** Read original component restrictions only after the original terminal binding mounts. */
export function nativeBareModeObserver(outputPath){
 return `if(process.argv.includes('--bare')&&!process.argv.includes('--print')){
 const {writeFileSync}=await import('node:fs');let attempts=0,busy=false;
 const timer=setInterval(async()=>{if(busy)return;busy=true;try{
  if(++attempts>600){clearInterval(timer);return;}
  const runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js');if(runtime.ey()?.surface!=='terminal')return;
  const restrictions=await import('/$bunfs/root/chunk-kmv3514c.js');
  writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({bare:process.argv.includes('--bare'),pid:process.pid,plugins:restrictions.xr('plugins'),hooks:restrictions.xr('hooks'),statusLine:restrictions.xr('statusLine'),themes:restrictions.xr('themes')}),{mode:0o600});clearInterval(timer);
 }catch(error){writeFileSync(${JSON.stringify(outputPath+'.error')},String(error));clearInterval(timer);}finally{busy=false;}},200);timer.unref();
}`;
}

export async function verifyNativeBareMode(workspace,evidence,calls){
 assert.equal(evidence.nativeBareMode,true);assert.equal(evidence.resumedPrintSameSession,true);
 const proof=JSON.parse(await readFile(join(workspace,'native-bare-mode-proof.json'),'utf8'));
 assert.deepEqual(proof.credentialConsent,{navigated:true,confirmed:true});
 assert.equal(proof.nativePrompt,'Continue reviewing without project customizations.');assert.equal(proof.continuation,'Continue after the bare native owner has stopped.');
 assert.deepEqual(proof.captures,['native-bare-mode-ready-1100.png','native-bare-mode-ready-680.png']);
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.sessionId,evidence.finalSessionId);
 const policy=JSON.parse(await readFile(join(workspace,'native-bare-policy.json'),'utf8'));assert.deepEqual(policy,proof.nativePolicy);
 assert.equal(policy.pid,evidence.boundNativePid);
 for(const [key,value] of Object.entries({bare:true,plugins:true,hooks:true,statusLine:false,themes:false}))assert.equal(policy[key],value,key);
 const children=(await readFile(join(workspace,'native-children.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 assert.equal(children.length,3);assert.ok(children[1].args.includes('--bare'));assert.equal(children[0].args.includes('--bare'),false);assert.equal(children[2].args.includes('--bare'),false);
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.equal(paths.length,1);
 const records=(await readFile(join(root,paths[0]),'utf8')).trim().split('\n').map(JSON.parse);
 const humans=records.filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'));
 const text=content=>typeof content==='string'?content:(content??[]).filter(block=>block.type==='text').map(block=>block.text).join('\n');
 assert.deepEqual(humans.map(row=>text(row.message?.content)),['Review the release notes for this project.',proof.nativePrompt,proof.continuation]);
 const nativeReply=records.find(row=>row.type==='assistant'&&text(row.message?.content)==='Bare session review complete.');assert.ok(nativeReply,'Original bare owner never received the successful local model reply');
 assert.equal(calls.seed.length,2);assert.equal(calls.agent.length,1);
 return {sessionId:proof.sessionId,nativePid:policy.pid,nativeRestrictions:policy,humanUuids:humans.map(row=>row.uuid),nativeReplyUuid:nativeReply.uuid,captures:proof.captures,scope:'Original --bare terminal startup, private plugin UI suppression, retained composing, one native input and same-session print recovery. Not safe-mode, managed policy/MDM, live transitions or all bare-mode families.'};
}
