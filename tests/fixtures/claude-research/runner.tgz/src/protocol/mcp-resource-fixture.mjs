import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
export const resourceText = '# Release notes\n\nVerify resource provenance before shipping.\nReleaseReadmeEnd';
export const resourceBlob = Buffer.from([82,101,108,101,97,115,101,0,255,69,118,105,100,101,110,99,101]);
export const resourceUris = { text: 'research://release/notes', binary: 'research://release/evidence', missing: 'research://release/stale' };
export const resourceSteps = [
  {id:'resource-list-initial',name:'ListMcpResourcesTool',input:{server:'research'}},
  {id:'resource-read-text',name:'ReadMcpResourceTool',input:{server:'research',uri:resourceUris.text}},
  {id:'resource-read-binary',name:'ReadMcpResourceTool',input:{server:'research',uri:resourceUris.binary}},
  {id:'resource-read-stale',name:'ReadMcpResourceTool',input:{server:'research',uri:resourceUris.missing}},
  {id:'resource-list-refresh',name:'ListMcpResourcesTool',input:{server:'research'}},
];

export async function verifyMcpResourceProof(workspace,proof,calls){
  assert.deepEqual(proof.text.contents,[{uri:resourceUris.text,mimeType:'text/markdown',text:resourceText}]);
  assert.equal(proof.binary.contents[0].uri,resourceUris.binary);
  assert.equal(proof.binary.contents[0].mimeType,'application/octet-stream');
  assert.equal(proof.binary.contents[0].blobSavedTo,proof.blobPath);
  assert.ok(proof.blobPath.startsWith(join(workspace,'.claude','projects')+'/'));
  assert.ok(proof.blobPath.includes('/'+proof.sessionId+'/tool-results/'));
  assert.deepEqual(await readFile(proof.blobPath),resourceBlob);
  assert.ok(proof.missing.error.includes('Resource not found: '+resourceUris.missing));
  assert.ok(proof.listed.some(row=>row.uri===resourceUris.text&&row.name==='Current release notes'&&row.server==='research'));
  const results=calls.flatMap(call=>call.resourceResults??[]);
  const content=id=>{const row=results.find(row=>row.tool_use_id===id);assert.ok(row,'Original native result missing: '+id);return typeof row.content==='string'?row.content:row.content.filter(part=>part.type==='text').map(part=>part.text).join('\n')};
  assert.deepEqual(JSON.parse(content('resource-read-text')),proof.text);
  assert.deepEqual(JSON.parse(content('resource-read-binary')),proof.binary);
  assert.equal(content('resource-read-stale'),proof.missing.error);
  assert.deepEqual(JSON.parse(content('resource-list-refresh')),proof.listed);
  assert.ok(JSON.parse(content('resource-list-initial')).some(row=>row.uri===resourceUris.text&&row.name==='Release notes'));
  return {originalResults:resourceSteps.length,binaryBytes:resourceBlob.length,blobPath:proof.blobPath,textUri:resourceUris.text,binaryUri:resourceUris.binary,staleUri:resourceUris.missing,refreshed:true};
}

export const directoryStep={id:'resource-directory',name:'ReadMcpResourceDirTool',input:{server:'research',uri:'research://release/'}};
