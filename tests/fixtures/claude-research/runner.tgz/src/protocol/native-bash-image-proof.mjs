import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Match a real Bash image result to its original formatter, model request and app session. */
export async function verifyNativeBashImage(root,{large=false}={}){
 const json=async file=>JSON.parse(await readFile(file,'utf8'));
 const names=await readdir(join(root,'workspaces'));assert.equal(names.length,1);const workspace=join(root,'workspaces',names[0]);
 const lines=async file=>(await readFile(join(workspace,file),'utf8')).trim().split('\n').map(JSON.parse);
 const proof=await json(join(workspace,'native-bash-image-proof.json')),evidence=await json(join(workspace,'native-terminal-app-evidence.json'));
 assert.equal(evidence.nativeBashImage,true);assert.equal(evidence.actualAppGui,true);assert.equal(evidence.sessionId,proof.sessionId);assert.equal(evidence.finalSessionId,proof.sessionId);
 const output=proof.observed.props.output;assert.equal(proof.observed.props.tool,'Bash');assert.equal(proof.observed.props.tool_use_id,proof.id);assert.equal(proof.observed.props.isErrored,false);assert.equal(output.isImage,true);assert.equal(output.interrupted,false);assert.equal(output.stderr,'');
 assert.match(proof.notice,/\[Image data detected and sent to Claude\]/);assert.ok(!proof.notice.includes('data:image/'));
 const expected=large?(await readFile(join(workspace,'release-cover.png'))).toString('base64'):'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=';if(large)assert.ok(Buffer.from(expected,'base64').length>262144&&Buffer.from(expected,'base64').length<1048576);assert.equal(output.stdout,'data:image/png;base64,'+expected);
 const calls=await json(join(workspace,'model-calls.json'));assert.equal(calls.seed.filter(row=>row.path==='/v1/messages?beta=true').length,2);assert.equal(calls.agent.length,2);
 const modelResults=calls.agent.flatMap(call=>(call.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'&&block.tool_use_id===proof.id):[]));assert.equal(modelResults.length,1);assert.ok(!modelResults[0].is_error);
 const images=modelResults[0].content.filter(block=>block.type==='image');assert.equal(images.length,1);assert.deepEqual(images[0].source,{type:'base64',media_type:'image/png',data:expected});
 if(large){const resumed=calls.seed.at(-1).messages;assert.ok(Array.isArray(resumed));const results=resumed.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'&&block.tool_use_id===proof.id):[]);assert.equal(results.length,1);assert.deepEqual(results[0].content,modelResults[0].content);}
 const journals=await readdir(join(workspace,'.claude/projects'),{recursive:true}),parent=journals.find(file=>file.endsWith('/'+proof.sessionId+'.jsonl'));assert.ok(parent);
 const rows=(await readFile(join(workspace,'.claude/projects',parent),'utf8')).trim().split('\n').map(JSON.parse);
 const nativeResults=rows.filter(row=>row.toolUseResult?.isImage===true);assert.equal(nativeResults.length,1);assert.deepEqual(nativeResults[0].toolUseResult,output);
 const journalResults=nativeResults[0].message.content.filter(block=>block.type==='tool_result'&&block.tool_use_id===proof.id);assert.equal(journalResults.length,1);assert.deepEqual(journalResults[0].content,modelResults[0].content);
 const humans=rows.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&typeof row.message?.content==='string'&&(!row.origin||row.origin.kind==='human'));
 assert.deepEqual(humans.map(row=>row.message.content),['Review the release notes for this project.','Generate a release cover and inspect its image output.','Continue the release review after inspecting the Bash image.']);
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),prints=await lines('native-print-results.jsonl');assert.equal(children.length,3);assert.equal(exits.length,3);assert.equal(children[1].pid,proof.boundNativePid);for(const child of children){const exit=exits.find(row=>row.pid===child.pid);assert.ok(exit);assert.ok([0,143].includes(exit.code));assert.ok(exit.at>=child.at)}assert.equal(prints.length,2);assert.ok(prints.every(row=>row.sessionId===proof.sessionId));
 const cost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,prints.at(-1).totalCostUsd);assert.equal(cost,proof.final.claude.totalCostUsd);
 const app=await json(join(root,'app-query.stdout')),threads=app.threads.filter(row=>row.claude?.sessionId===proof.sessionId);assert.equal(threads.length,1);assert.equal(threads[0].claude.totalCostUsd,cost);assert.equal(threads[0].claude.chatState,'success');for(const row of humans){const matches=app.messages.filter(message=>message.sender==='user'&&message.context?.cliUuid===row.uuid);assert.equal(matches.length,1);assert.equal(matches[0].text,row.message.content)}
 const pictures=await readdir(join(workspace,'electron-results'),{recursive:true});assert.equal(proof.captures.length,2);for(const file of proof.captures){const matches=pictures.filter(path=>path.endsWith('/'+file));assert.equal(matches.length,1);const bytes=await readFile(join(workspace,'electron-results',matches[0]));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),file.endsWith('-680.png')?680:1100)}
 assert.deepEqual(await json(join(root,'compiled-before.json')),await json(join(root,'compiled-after.json')));const boundary=await json(join(root,'offline-boundary.json'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);assert.equal(boundary.memory,6*1024**3);assert.equal(boundary.memorySwap,boundary.memory);assert.equal(boundary.nanoCpus,2*10**9);assert.deepEqual(Object.keys(boundary.networks),['none']);
 return {nativeBashImage:true,...(large?{largerPayload:true,resumedModelImageExact:true}:{}),originalFormatterNotice:true,imageBytesExact:true,imageBytes:Buffer.from(expected,'base64').length,exactAppNativeHistory:true,appNativePrintCost:cost,ownedNativeExits:3,screenshots:2};
}
