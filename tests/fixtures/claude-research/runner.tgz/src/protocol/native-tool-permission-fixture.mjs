import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

export const toolPermissionSteps = [
  { tool: 'Skill', input: { skill: 'release-review-once' }, prompt: 'Use the release review skill to check the migration notes.', decision: 'once' },
  { tool: 'Skill', input: { skill: 'release-review-deny' }, prompt: 'Review the proposed release skill before using it.', decision: 'deny' },
  { tool: 'Skill', input: { skill: 'release-review-remember' }, prompt: 'Remember permission for this release-review skill.', decision: 'standing' },
  { tool: 'WebFetch', input: { url: 'https://release-review.invalid/denied', prompt: 'Summarize the migration notes.' }, prompt: 'Ask before fetching these migration notes.', decision: 'deny' },
  { tool: 'WebFetch', input: { url: 'https://release-review.invalid/allowed', prompt: 'Summarize the migration notes.' }, prompt: 'Allow one attempt to fetch the migration notes.', decision: 'once' },
  { tool: 'WebFetch', input: { url: 'https://release-review-remember.invalid/notes', prompt: 'Summarize the migration notes.' }, prompt: 'Remember permission for this migration-notes host.', decision: 'standing' },
  { tool: 'WebFetch', input: { url: 'https://release-review-cancel.invalid/notes', prompt: 'Summarize the migration notes.' }, prompt: 'Review this fetch request before continuing.', decision: 'cancel' },
];

export async function addNativeToolPermissionFixture(workspace, plugin) {
  const path = join(workspace, '.claude/settings.json'), settings = JSON.parse(await readFile(path, 'utf8'));
  settings.permissions.ask = [...new Set([...settings.permissions.ask, 'Skill', 'WebFetch'])];
  await writeFile(path, JSON.stringify(settings));
  for (const step of toolPermissionSteps.filter(step => step.tool === 'Skill')) {
    const directory = join(workspace, '.claude/skills', step.input.skill);
    await mkdir(directory, { recursive: true });
    await writeFile(join(directory, 'SKILL.md'), `---\nname: ${step.input.skill}\ndescription: Review local migration notes without executing commands.\nallowed-tools: Read\n---\nReview the release checklist. ResearchNativeSkillBody: ${step.input.skill}.\n`);
  }
  await writeFile(join(workspace, 'native-tool-permission-steps.json'), JSON.stringify(toolPermissionSteps));
  await writeFile(join(plugin, 'hooks/register.ts'), `export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&/^native_permission_/.test(e.props.tool_use_id))await $.fs.write('native-tool-permission-result-'+e.props.tool_use_id+'.json',JSON.stringify({props:e.props}));return next(e);});}`);
}

export async function verifyNativeToolPermissions(workspace, calls, proof) {
  assert.equal(proof.steps.length, 7); assert.equal(proof.retainedDraft, true);
  const results = calls.flatMap(call => call.toolPermissionResults ?? []);
  for (let phase = 1; phase <= 6; phase++) {
    const result = results.find(row => row.tool_use_id === 'native_permission_' + phase);
    assert.ok(result, 'Original tool result missing: ' + phase);
    if (phase === 1 || phase === 3) assert.notEqual(result.is_error, true);
    if (phase === 2) { assert.equal(result.is_error, true); assert.match(JSON.stringify(result.content), /Keep the original release notes/); }
  }
  const settings = JSON.parse(await readFile(join(workspace, '.claude/settings.local.json'), 'utf8'));
  assert.ok(settings.permissions.allow.includes('Skill(release-review-remember)'));
  assert.ok(settings.permissions.allow.includes('WebFetch(domain:release-review-remember.invalid)'));
  return { originalSkillExecution: true, originalDenialFeedback: true, originalStandingScopesPersisted: true, offlineWebFetchAttempt: true, successfulHttpFetch: false };
}
