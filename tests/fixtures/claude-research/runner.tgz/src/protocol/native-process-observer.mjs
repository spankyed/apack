/** Research observer: retain bounded copies at the native child-process boundary without draining streams. */
import { ChildProcess } from 'node:child_process';
import { appendFileSync } from 'node:fs';
const output = process.env.APACK_NATIVE_PROCESS_OBSERVER_FILE;
if (!output) throw new Error('Private observer output path is required');
const originalSpawn = ChildProcess.prototype.spawn;
ChildProcess.prototype.spawn = function (...args) {
  const startedAt = process.hrtime.bigint().toString();
  const result = Reflect.apply(originalSpawn, this, args);
  const child = this, input = [], chunks = [];
  let inputBytes = 0, outputBytes = 0, ending = false;
  const rememberInput = chunk => {
    if (chunk === undefined || chunk === null || typeof chunk === 'function') return;
    const bytes = typeof chunk === 'string' ? Buffer.from(chunk) : ArrayBuffer.isView(chunk) ? Buffer.from(chunk.buffer, chunk.byteOffset, chunk.byteLength) : undefined;
    if (!bytes) return;
    inputBytes += bytes.length; if (inputBytes <= 1048576) input.push(Buffer.from(bytes));
  };
  if (child.stdin) {
    const write = child.stdin.write, end = child.stdin.end;
    child.stdin.write = function (...values) { if (!ending) rememberInput(values[0]); return Reflect.apply(write, this, values); };
    child.stdin.end = function (...values) { rememberInput(values[0]); ending = true; try { return Reflect.apply(end, this, values); } finally { ending = false; } };
  }
  if (child.stdout) {
    const emit = child.stdout.emit;
    child.stdout.emit = function (event, ...values) {
      if (event === 'data') { const bytes = typeof values[0] === 'string' ? Buffer.from(values[0], this.readableEncoding ?? 'utf8') : Buffer.from(values[0]); outputBytes += bytes.length; if (outputBytes <= 1048576) chunks.push(bytes); }
      return Reflect.apply(emit, this, [event, ...values]);
    };
  }
  child.once('close', (code, signal) => {
    if (inputBytes > 1048576) return;
    let payload; try { payload = JSON.parse(Buffer.concat(input).toString('utf8')); } catch { return; }
    if (!payload || typeof payload !== 'object' || typeof payload.session_id !== 'string' || !/^[a-f0-9-]{36}$/i.test(payload.session_id) || payload.hook_event_name) return;
    const subagent = Array.isArray(payload.tasks) && typeof payload.columns === 'number';
    if (!subagent && (typeof payload.version !== 'string' || !payload.cost || !payload.context_window)) return;
    const kind = subagent ? 'subagent' : 'main';
    try { appendFileSync(output, JSON.stringify({ kind, parentPid: process.pid, sessionId: payload.session_id, pid: child.pid, argv: child.spawnargs, command: child.spawnargs?.at(-1), startedAt, code, signal, stdout: Buffer.concat(chunks).toString('utf8'), truncated: outputBytes > 1048576, input: payload, taskIds: kind === 'subagent' ? payload.tasks.map(task => task.id) : [] }) + '\n'); } catch { /* Observation must not alter native process completion. */ }
  });
  return result;
};
