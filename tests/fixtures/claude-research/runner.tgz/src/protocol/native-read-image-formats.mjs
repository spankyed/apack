export const nativeReadImageFormats = [
  { file: 'release-cover.jpg', id: 'native_read_jpeg', mediaType: 'image/jpeg', prompt: 'Review the JPEG release cover.', extension: 'jpeg' },
  { file: 'release-cover.webp', id: 'native_read_webp', mediaType: 'image/webp', prompt: 'Review the WebP release cover.', extension: 'webp' },
];

export const nativeReadSvgFile = {
  file: 'release-cover.svg', id: 'native_read_svg_source', prompt: 'Review the SVG release cover source.', extension: 'svg',
};

export const nativeReadGifCases = [
  { file: 'release-motion.gif', id: 'native_read_animated_gif', mediaType: 'image/gif',
    prompt: 'Review the animated release cover.', extension: 'gif' },
  { file: 'release-download.gif', id: 'native_read_invalid_gif', error: 'not a valid PNG/JPEG/GIF/WebP',
    prompt: 'Check whether the cover download is usable.', reply: 'The cover download is incomplete. Use a fresh copy.', extension: 'invalid-gif' },
];

export const nativeReadPartialPdf = {
  file: 'release-pages.pdf', id: 'native_read_partial_pdf', extension: 'pdf-partial', pages: '1-3',
  prompt: 'Review the three rendered release pages.', reply: 'Two release pages were readable. Page two needs a fresh render.',
};

export const nativeReadImageReply = 'The cover is ready for the release notes.';
