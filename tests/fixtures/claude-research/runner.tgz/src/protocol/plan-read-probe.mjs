import {mkdir,mkdtemp,readFile,writeFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {hash} from '../artifacts/runs.mjs';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';

/** Verify populated structured plan reads while native ExitPlanMode approval is pending. */
export async function probePlanRead(executable,workspace,output){
 await mkdir(workspace,{recursive:true});const cwd=await mkdtemp(join(workspace,'plan-read-'));
 const model=await startSyntheticModel(cwd,'TuiPlan');
 const request=(id)=>JSON.stringify({type:'control_request',request_id:id,request:{subtype:'get_plan'}})+'\n';
 const replies={};let pending='',approval,approvalCount=0,result;
 try{
  const run=await record({executable,cwd,output,timeoutMs:20000,
   args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--setting-sources','','--strict-mcp-config','--tools','Write,ExitPlanMode','--permission-mode','plan','--permission-prompt-tool','stdio','--max-turns','4','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})],
   env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),ANTHROPIC_BASE_URL:model.url,ENABLE_TOOL_SEARCH:'0',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
   input:[JSON.stringify({type:'control_request',request_id:'initialize',request:{subtype:'initialize',hooks:{}}})+'\n'],
   onStdout(bytes,transport){
    pending+=bytes.toString('utf8');
    while(pending.includes('\n')){
     const at=pending.indexOf('\n'),line=pending.slice(0,at);pending=pending.slice(at+1);
     let value;try{value=JSON.parse(line)}catch{continue}
     const response=value.type==='control_response'?value.response:undefined;
     if(response?.request_id==='initialize')transport.send(request('before-plan'));
     if(['before-plan','pending-plan','after-plan'].includes(response?.request_id)){
      replies[response.request_id]=response;
      if(response.request_id==='before-plan')transport.send(JSON.stringify({type:'user',message:{role:'user',content:'NativePlanFixtureSeedAlpha: Create the synthetic plan and request approval.'},parent_tool_use_id:null})+'\n');
      if(response.request_id==='pending-plan')transport.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:approval.request_id,response:{behavior:'allow',updatedInput:approval.request.input}}})+'\n');
      if(response.request_id==='after-plan')transport.closeInput();
     }
     if(value.type==='control_request'&&value.request?.subtype==='can_use_tool'){
      approvalCount++;if(value.request.tool_name!=='ExitPlanMode'){transport.stop('unexpected-plan-permission');continue}
      approval=value;transport.send(request('pending-plan'));
     }
     if(value.type==='result'){result=value;transport.send(request('after-plan'))}
    }
   }});
  const content='# Synthetic native plan\n\nImplement the isolated fixture only.\n';
  const nativePlan=replies['pending-plan']?.response;
  const expectedPath=model.calls.find(call=>call.tuiPlanPath)?.tuiPlanPath;
  const file=expectedPath?await readFile(expectedPath,'utf8'):undefined;
  const savedFiles=(await readdir(join(cwd,'.claude'),{recursive:true})).filter(file=>file.startsWith('projects/')&&file.endsWith('.jsonl'));
  const savedBefore=await Promise.all(savedFiles.map(async file=>[file,hash(await readFile(join(cwd,'.claude',file)))]));
  const callsBeforeResume=model.calls.length;let resumePending='',resumeResponse;
  const resumed=await record({executable,cwd,output,timeoutMs:10000,
   args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--resume',result.session_id,'--no-session-persistence','--setting-sources','','--strict-mcp-config','--tools','Write,ExitPlanMode','--permission-prompt-tool','stdio','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})],
   env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),ANTHROPIC_BASE_URL:model.url,ENABLE_TOOL_SEARCH:'0',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
   input:[JSON.stringify({type:'control_request',request_id:'initialize',request:{subtype:'initialize',hooks:{}}})+'\n'],
   onStdout(bytes,transport){resumePending+=bytes.toString('utf8');while(resumePending.includes('\n')){const at=resumePending.indexOf('\n'),line=resumePending.slice(0,at);resumePending=resumePending.slice(at+1);let value;try{value=JSON.parse(line)}catch{continue}if(value.response?.request_id==='initialize')transport.send(request('resumed-plan'));if(value.response?.request_id==='resumed-plan'){resumeResponse=value.response;transport.closeInput()}}}
  });
  const savedAfter=await Promise.all(savedFiles.map(async file=>[file,hash(await readFile(join(cwd,'.claude',file)))]));
  const savedUnchanged=savedFiles.length>0&&JSON.stringify(savedBefore)===JSON.stringify(savedAfter);
  const resumeApiRequests=model.calls.length-callsBeforeResume;
  const verified=resumed.status==='complete'&&savedUnchanged&&resumeApiRequests===0&&resumeResponse?.subtype==='success'&&resumeResponse.response?.exists===true&&resumeResponse.response?.content===content&&resumeResponse.response?.path===expectedPath&&run.status==='complete'&&approvalCount===1&&replies['before-plan']?.subtype==='success'&&replies['before-plan'].response?.exists===false&&replies['pending-plan']?.subtype==='success'&&nativePlan?.exists===true&&nativePlan.content===content&&nativePlan.path===expectedPath&&file===content&&result?.subtype==='success'&&replies['after-plan']?.subtype==='success'&&replies['after-plan'].response?.exists===true&&replies['after-plan'].response?.content===content&&replies['after-plan'].response?.path===expectedPath;
  const evidence={verified,targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),approvalCount,replies,result,resumedRun:resumed.directory,resumeResponse,savedUnchanged,resumeApiRequests,calls:model.calls,realModelRequests:0,qualification:'Headless populated get_plan before/during/after approval and prompt-free resume; no context reset or rendered app UI claim.'};
  await writeFile(join(run.directory,'plan-read.json'),JSON.stringify(evidence,null,2)+'\n');
  if(!verified){const path=join(run.directory,'manifest.json');const manifest=JSON.parse(await readFile(path,'utf8'));await writeFile(path,JSON.stringify({...manifest,status:'failed',verificationFailure:'plan-read-verification-failed'},null,2)+'\n')}
  return {...run,status:verified?'complete':'failed',verified};
 }finally{await model.close()}
}
