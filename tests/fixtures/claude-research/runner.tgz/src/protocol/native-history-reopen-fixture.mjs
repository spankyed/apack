import {writeFile,readFile,readdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {join} from 'node:path';
import {largeDocumentCode,largeDocumentMarkdown} from './native-large-document-fixture.mjs';
/** Original result callbacks persist receipts; live status deliberately belongs to one process. */
export async function addNativeHistoryReopenFixture(plugin){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){let tab='source';on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface!=='desktop'||e.props.tool_use_id!=='native_reference_read'||e.props.isErrored)return next(e);const{Box,Text,Button,Code,Markdown}=$.ui.resolve(e);const select=async value=>{const prior=JSON.parse(await $.fs.read('native-history-callbacks.json').catch(()=>'[]'));prior.push({tab:value,requestId:e.requestId,surface:e.surface});await $.fs.write('native-history-callbacks.json',JSON.stringify(prior));tab=value;if(value==='guide')await $.ui.status('Migration guide reviewed');$.ui.invalidate('ui.render');};return Box({flexDirection:'column',children:[Box({flexDirection:'row',gap:1,children:[Button({key:'source',label:'Source',onPress:()=>select('source')}),Button({key:'guide',label:'Guide',onPress:()=>select('guide')})]}),Text({children:[tab==='source'?'Migration registry':'Migration guide']}),tab==='source'?Code({source:${JSON.stringify(largeDocumentCode)},language:'javascript',startLine:1}):Markdown({text:${JSON.stringify(largeDocumentMarkdown)}})]});});}`);
}

/** Revalidate immutable original receipts, not just the browser's success flags. */
export async function verifyNativeHistoryReopen(workspace,evidence){
 const json=async name=>JSON.parse(await readFile(join(workspace,name),'utf8'));
 const proof=await json('native-history-reopen-proof.json'),initial=await json('native-history-initial-control-receipts.json'),fresh=await json('native-client-control-receipts.json');
 if(evidence.nativeOwnerFailure){
  assert.equal(proof.checkpoint.totalCostUSD,proof.nativeCost);assert.ok(Object.keys(proof.checkpoint.modelUsage).length>0,'Original per-model accounting checkpoint required');
  const failure=proof.failure;assert.equal(failure.kind,evidence.nativeOwnerFailure);assert.equal(failure.nativePid,proof.boundNativePid);
  assert.equal(failure.pid,failure.kind==='native'?failure.nativePid:failure.brokerPid);
  assert.ok(Number.isFinite(failure.retiredAt)&&failure.retiredAt>=failure.at,'Original native exit must be observed before replacement');
  const children=(await readFile(join(workspace,'native-children.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
  assert.ok(failure.retiredAt<=children[2].at,'A fresh preflight must not overlap the failed native process');
 }
 assert.equal(proof.sessionId,evidence.sessionId);assert.notEqual(proof.retired.actionId,proof.fresh.actionId);
 assert.notEqual(proof.boundNativePid,proof.reopenedNativePid);
 assert.ok(initial.some(row=>row.request.subtype==='ui_press'&&row.request.key==='guide'&&row.response.pid===proof.boundNativePid&&row.response.result.handled===true));
 const actions=fresh.filter(row=>row.request.subtype==='ui_press'&&row.request.component==='ToolResult');
 assert.equal(actions.length,1);assert.equal(actions[0].request.key,'guide');assert.equal(actions[0].response.pid,proof.reopenedNativePid);assert.equal(actions[0].response.result.handled,true);
 assert.deepEqual(proof.callbacks.map(row=>[row.tab,row.requestId,row.surface]),Array.from({length:2},()=>['guide','native_reference_read','desktop']));
 const log=await readFile(join(workspace,'app-data/apack/logs/main.log'),'utf8');
 for(const action of [proof.retired.actionId,proof.fresh.actionId])assert.equal(log.split(action).length-1,1,'Both retired and fresh app actions must actually reach the backend');
 let closedCost;
 for(const bucket of await readdir(join(workspace,'.claude/projects'))){try{const rows=(await readFile(join(workspace,'.claude/projects',bucket,proof.sessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);closedCost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;break}catch(error){if(error.code!=='ENOENT')throw error}}
 assert.equal(closedCost,proof.continuedCost);assert.equal(closedCost,evidence.continuedCost);
 return {originalCallbackPid:proof.boundNativePid,freshCallbackPid:proof.reopenedNativePid,retiredBackendActions:1,freshBackendActions:1,freshOriginalCallbacks:1,closedCost,historyRows:proof.history.length};
}
