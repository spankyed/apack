import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

/** Validate original effects independently of the renderer's success flags. */
export async function verifyNativeCreditPurchase(workspace,evidence,billing,calls){
 for(const key of ['actualAppGui','nativeCreditForms','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 const proof=JSON.parse(await readFile(join(workspace,'native-credit-app.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);assert.equal(evidence.finalSessionId,proof.sessionId);
 const stages=['bundles','invalid-preview','valid-preview','quote','typed-not-submitted','cancel-charge','purchased'];
 assert.deepEqual(proof.receipts.map(row=>row.stage),stages);
 for(const row of proof.receipts){assert.equal(row.sessionId,proof.sessionId);assert.equal(row.nativePid,proof.nativePid);assert.equal(row.purchases,row.stage==='purchased'?1:0);assert.equal(row.enabled,row.stage==='purchased');assert.equal(row.balance,row.stage==='purchased'?7500:0);}
 assert.deepEqual(billing.purchases,[{amount:7500}]);assert.equal(billing.balance,7500);assert.equal(billing.enabled,true);assert.deepEqual(billing.adminRequests,[]);
 const writes=billing.requests.filter(row=>row.path.startsWith('/api/oauth/organizations/')&&row.method!=='GET'&&!row.path.endsWith('/billing/tax_rate'));
 assert.deepEqual(writes.map(row=>[row.method,row.path.split('/').at(-1)]),[['POST','setup_overage_billing'],['PUT','overage_spend_limit'],['POST','credits']]);
 assert.ok(Number.isInteger(writes[0].body.org_monthly_spend_limit)&&writes[0].body.org_monthly_spend_limit>0);assert.deepEqual(writes[1].body,{is_enabled:true});assert.deepEqual(writes[2].body,{amount:7500});
 assert.ok(billing.requests.some(row=>row.method==='POST'&&row.path.endsWith('/billing/tax_rate')&&row.body.price===7500&&row.body.currency==='USD'));
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width,row.height]),['amount-preview','quote','typed-consent','model-confirmation','recovered'].flatMap(stage=>[[stage,1100,900],[stage,680,600]]));
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.ok(paths.length);
 const rows=new Map();for(const path of paths)for(const line of (await readFile(join(root,path),'utf8')).trim().split('\n').filter(Boolean)){const row=JSON.parse(line);rows.set(row.uuid??Symbol(),row);}
 const humans=[...rows.values()].filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'&&!row.message.content.startsWith('<')));
 assert.deepEqual(humans.map(row=>row.message.content),['Review this project before choosing a credit-billed model.','Continue the same release review after usage-credit controls close.']);
 assert.deepEqual(calls.seed.map(row=>row.path),['/api/hello','/v1/messages?beta=true','/api/hello','/v1/messages?beta=true']);
 const conversation=calls.seed.filter(row=>row.path==='/v1/messages?beta=true');
 for(const row of calls.seed.filter(row=>row.path==='/api/hello')){assert.deepEqual(row.messages,[]);assert.equal(row.model,undefined);}
 assert.equal(calls.agent.length,1);const quota=calls.agent[0];assert.deepEqual(quota.messages,[{role:'user',content:'quota'}]);assert.equal(quota.model,conversation[0].model);assert.equal(quota.child,false);assert.equal(quota.grandchild,false);assert.equal(quota.delivered,true);
 assert.match(conversation[1].model,/fable/i);assert.equal(JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8')).model,'fable');
 const jsonl=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const children=await jsonl('native-children.jsonl'),exits=await jsonl('native-exits.jsonl'),prints=await jsonl('native-print-results.jsonl');
 assert.equal(children.length,3);assert.equal(new Set(children.map(row=>row.pid)).size,3);assert.deepEqual(exits.map(row=>[row.pid,row.code]),children.map((row,index)=>[row.pid,index===0?0:143]));assert.equal(children[1].pid,proof.nativePid);assert.equal(children[2].args[children[2].args.indexOf('--model')+1],'fable');
 assert.equal(prints.length,2);assert.deepEqual(prints.map(row=>[row.pid,row.sessionId,row.subtype]),[children[0],children[2]].map(row=>[row.pid,proof.sessionId,'success']));
 assert.ok(Number.isFinite(evidence.nativeCost)&&evidence.nativeCost>0&&evidence.resumedCost>evidence.nativeCost);assert.deepEqual(prints.map(row=>row.totalCostUsd),[evidence.nativeCost,evidence.resumedCost]);
 const costs=[...rows.values()].filter(row=>row.type==='cost-state');assert.equal(costs.at(-1)?.totalCostUSD,evidence.resumedCost);

 const answers=[...rows.values()].filter(row=>row.type==='assistant'&&typeof row.message?.model==='string');assert.deepEqual(answers.map(row=>row.message.model),conversation.map(row=>row.model));
 return {originalBillingEffects:true,healthChecks:2,quotaChecks:1,conversationTurns:2,requestModels:conversation.map(row=>row.model),nativeExits:exits.map(row=>[row.pid,row.code]),originalCosts:{native:evidence.nativeCost,resumed:evidence.resumedCost},sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),captures:proof.captures,scope:'Synthetic eligible main-owner custom purchase, live native feedback, quote, explicit typed consent, cancellation and same-session recovery. Admin, bundle, failure/pending and other owners remain separate; screenshots require visual review.'};
}
