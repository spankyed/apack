import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

/** Validate original effects independently of the renderer's success flags. */
export async function verifyNativeCreditPurchase(workspace,evidence,billing,calls){
 for(const key of ['actualAppGui','nativeCreditForms','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 const proof=JSON.parse(await readFile(join(workspace,'native-credit-app.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);assert.equal(evidence.finalSessionId,proof.sessionId);
 const stages=['bundles','invalid-preview','valid-preview','quote','typed-not-submitted','cancel-charge','purchased'];
 assert.deepEqual(proof.receipts.map(row=>row.stage),stages);
 for(const row of proof.receipts){assert.equal(row.sessionId,proof.sessionId);assert.equal(row.nativePid,proof.nativePid);assert.equal(row.purchases,row.stage==='purchased'?1:0);assert.equal(row.enabled,row.stage==='purchased');assert.equal(row.balance,row.stage==='purchased'?7500:0);}
 assert.deepEqual(billing.purchases,[{amount:7500}]);assert.equal(billing.balance,7500);assert.equal(billing.enabled,true);assert.deepEqual(billing.adminRequests,[]);
 const writes=billing.requests.filter(row=>row.path.startsWith('/api/oauth/organizations/')&&row.method!=='GET'&&!row.path.endsWith('/billing/tax_rate'));
 assert.deepEqual(writes.map(row=>[row.method,row.path.split('/').at(-1)]),[['POST','setup_overage_billing'],['PUT','overage_spend_limit'],['POST','credits']]);
 assert.ok(Number.isInteger(writes[0].body.org_monthly_spend_limit)&&writes[0].body.org_monthly_spend_limit>0);assert.deepEqual(writes[1].body,{is_enabled:true});assert.deepEqual(writes[2].body,{amount:7500});
 assert.ok(billing.requests.some(row=>row.method==='POST'&&row.path.endsWith('/billing/tax_rate')&&row.body.price===7500&&row.body.currency==='USD'));
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width,row.height]),['amount-preview','quote','typed-consent','model-confirmation','recovered'].flatMap(stage=>[[stage,1100,900],[stage,680,600]]));
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.ok(paths.length);
 const rows=new Map();for(const path of paths)for(const line of (await readFile(join(root,path),'utf8')).trim().split('\n').filter(Boolean)){const row=JSON.parse(line);rows.set(row.uuid??Symbol(),row);}
 const humans=[...rows.values()].filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'&&!row.message.content.startsWith('<')));
 assert.deepEqual(humans.map(row=>row.message.content),['Review this project before choosing a credit-billed model.','Continue the same release review after usage-credit controls close.']);
 assert.deepEqual(calls.seed.map(row=>row.path),['/api/hello','/v1/messages?beta=true','/api/hello','/v1/messages?beta=true']);
 const conversation=calls.seed.filter(row=>row.path==='/v1/messages?beta=true');
 for(const row of calls.seed.filter(row=>row.path==='/api/hello')){assert.deepEqual(row.messages,[]);assert.equal(row.model,undefined);}
 assert.equal(calls.agent.length,1);const quota=calls.agent[0];assert.deepEqual(quota.messages,[{role:'user',content:'quota'}]);assert.equal(quota.model,conversation[0].model);assert.equal(quota.child,false);assert.equal(quota.grandchild,false);assert.equal(quota.delivered,true);
 assert.match(conversation[1].model,/fable/i);assert.equal(JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8')).model,'fable');
 const jsonl=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const children=await jsonl('native-children.jsonl'),exits=await jsonl('native-exits.jsonl'),prints=await jsonl('native-print-results.jsonl');
 assert.equal(children.length,3);assert.equal(new Set(children.map(row=>row.pid)).size,3);assert.deepEqual(exits.map(row=>[row.pid,row.code]),children.map((row,index)=>[row.pid,index===0?0:143]));assert.equal(children[1].pid,proof.nativePid);assert.equal(children[2].args[children[2].args.indexOf('--model')+1],'fable');
 assert.equal(prints.length,2);assert.deepEqual(prints.map(row=>[row.pid,row.sessionId,row.subtype]),[children[0],children[2]].map(row=>[row.pid,proof.sessionId,'success']));
 assert.ok(Number.isFinite(evidence.nativeCost)&&evidence.nativeCost>0&&evidence.resumedCost>evidence.nativeCost);assert.deepEqual(prints.map(row=>row.totalCostUsd),[evidence.nativeCost,evidence.resumedCost]);
 const costs=[...rows.values()].filter(row=>row.type==='cost-state');assert.equal(costs.at(-1)?.totalCostUSD,evidence.resumedCost);

 const answers=[...rows.values()].filter(row=>row.type==='assistant'&&typeof row.message?.model==='string');assert.deepEqual(answers.map(row=>row.message.model),conversation.map(row=>row.model));
 return {originalBillingEffects:true,healthChecks:2,quotaChecks:1,conversationTurns:2,requestModels:conversation.map(row=>row.model),nativeExits:exits.map(row=>[row.pid,row.code]),originalCosts:{native:evidence.nativeCost,resumed:evidence.resumedCost},sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),captures:proof.captures,scope:'Synthetic eligible main-owner custom purchase, live native feedback, quote, explicit typed consent, cancellation and same-session recovery. Admin, bundle, failure/pending and other owners remain separate; screenshots require visual review.'};
}

/** Admin requests retain original membership gates, cancel-first decisions and pending lifetime. */
export async function verifyNativeCreditAdmin(workspace,evidence,billing,calls){
 for(const key of ['actualAppGui','nativeCreditForms','nativeCreditAdmin','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 const proof=JSON.parse(await readFile(join(workspace,'native-credit-admin-app.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.deepEqual(proof.receipts.map(row=>row.stage),['cancelled','sending','sent','duplicate-refused']);
 assert.deepEqual(proof.receipts.map(row=>row.adminRequests),[0,0,1,1]);for(const row of proof.receipts){assert.equal(row.sessionId,proof.sessionId);assert.equal(row.nativePid,proof.nativePid);assert.equal(row.modelUnchanged,true);}
 assert.equal(billing.enabled,false);assert.equal(billing.balance,0);assert.deepEqual(billing.purchases,[]);assert.deepEqual(billing.adminRequests,[{id:'owned-admin-request-1',status:'pending',request_type:'limit_increase'}]);
 const writes=billing.requests.filter(row=>row.path.startsWith('/api/oauth/organizations/')&&row.method!=='GET');assert.equal(writes.length,1);assert.ok(writes[0].path.endsWith('/admin_requests'));assert.equal(writes[0].method,'POST');assert.equal(writes[0].status,201);assert.deepEqual(writes[0].body,{request_type:'limit_increase',details:null});assert.equal(writes[0].waitingForRelease,false);
 for(const [suffix,query]of [['/admin_requests/eligibility','?request_type=limit_increase'],['/admin_requests/me','?request_type=limit_increase&statuses=pending']]){const reads=billing.requests.filter(row=>row.path.endsWith(suffix));assert.equal(reads.length,3);for(const row of reads){assert.equal(row.method,'GET');assert.equal(row.status,200);assert.equal(row.query,query);}}
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width,row.height]),['confirmation','pending','recovered'].flatMap(stage=>[[stage,1100,900],[stage,680,600]]));
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.ok(paths.length);const rows=new Map();
 for(const path of paths)for(const line of (await readFile(join(root,path),'utf8')).trim().split('\n').filter(Boolean)){const row=JSON.parse(line);rows.set(row.uuid??Symbol(),row);}
 const humans=[...rows.values()].filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'&&!row.message.content.startsWith('<')));
 assert.deepEqual(humans.map(row=>row.message.content),['Review this project before requesting usage credits.','Continue the same release review after an admin credit request.']);
 assert.deepEqual(calls.seed.map(row=>row.path),['/api/hello','/v1/messages?beta=true','/api/hello','/v1/messages?beta=true']);const conversation=calls.seed.filter(row=>row.path==='/v1/messages?beta=true');
 for(const row of calls.seed.filter(row=>row.path==='/api/hello')){assert.deepEqual(row.messages,[]);assert.equal(row.model,undefined);}
 assert.equal(calls.agent.length,1);assert.deepEqual(calls.agent[0].messages,[{role:'user',content:'quota'}]);assert.equal(calls.agent[0].model,conversation[0].model);assert.equal(calls.agent[0].child,false);assert.equal(calls.agent[0].delivered,true);
 assert.equal(conversation[1].model,conversation[0].model);assert.equal(JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8')).model,undefined);
 const jsonl=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);const children=await jsonl('native-children.jsonl'),exits=await jsonl('native-exits.jsonl'),prints=await jsonl('native-print-results.jsonl');
 assert.equal(children.length,3);assert.equal(new Set(children.map(row=>row.pid)).size,3);assert.deepEqual(exits.map(row=>[row.pid,row.code]),children.map((row,index)=>[row.pid,index===0?0:143]));assert.equal(children[1].pid,proof.nativePid);
 assert.equal(prints.length,2);assert.deepEqual(prints.map(row=>[row.pid,row.sessionId,row.subtype]),[children[0],children[2]].map(row=>[row.pid,proof.sessionId,'success']));assert.ok(Number.isFinite(evidence.nativeCost)&&evidence.nativeCost>0&&evidence.resumedCost>evidence.nativeCost);assert.deepEqual(prints.map(row=>row.totalCostUsd),[evidence.nativeCost,evidence.resumedCost]);
 assert.equal([...rows.values()].filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD,evidence.resumedCost);assert.deepEqual([...rows.values()].filter(row=>row.type==='assistant'&&typeof row.message?.model==='string').map(row=>row.message.model),conversation.map(row=>row.model));
 return {originalAdminEffects:true,sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),requestModels:conversation.map(row=>row.model),ownedExits:exits.map(row=>[row.pid,row.code]),captures:proof.captures,scope:'Synthetic eligible Team member: cancel-first admin confirmation, no request on cancel, non-cancellable pending send, one original request, duplicate refusal, unchanged model and same-session recovery. Real notifications, failure variants and other owners remain unverified.'};
}

/** Check bundle price binding and original pending invoice separately from custom amount entry. */
export async function verifyNativeCreditBundle(workspace,evidence,billing,calls){
 for(const key of ['actualAppGui','nativeCreditForms','nativeCreditBundle','nativeCreditPendingPayment','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 const proof=JSON.parse(await readFile(join(workspace,'native-credit-bundle-app.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.deepEqual(proof.receipts.map(row=>row.stage),['bundle','quote','typed-not-submitted','payment-pending','purchased']);
 for(const row of proof.receipts){assert.equal(row.sessionId,proof.sessionId);assert.equal(row.nativePid,proof.nativePid);const submitted=['payment-pending','purchased'].includes(row.stage),paid=row.stage==='purchased';assert.equal(row.purchases,submitted?1:0);assert.equal(row.enabled,submitted);assert.equal(row.balance,paid?10000:0);assert.equal(row.paymentStatus,paid?'paid':submitted?'pending':null);}
 assert.deepEqual(billing.purchases,[{amount:10000,bundle_id:'owned-credit-bundle',expected_price_minor_units:9000}]);assert.equal(billing.balance,10000);assert.equal(billing.enabled,true);assert.deepEqual(billing.adminRequests,[]);
 const writes=billing.requests.filter(row=>row.path.startsWith('/api/oauth/organizations/')&&row.method!=='GET'&&!row.path.endsWith('/billing/tax_rate'));assert.deepEqual(writes.map(row=>[row.method,row.path.split('/').at(-1)]),[['POST','setup_overage_billing'],['PUT','overage_spend_limit'],['POST','credits']]);assert.ok(Number.isInteger(writes[0].body.org_monthly_spend_limit)&&writes[0].body.org_monthly_spend_limit>0);assert.deepEqual(writes[1].body,{is_enabled:true});assert.deepEqual(writes[2].body,billing.purchases[0]);
 assert.ok(billing.requests.some(row=>row.method==='POST'&&row.path.endsWith('/billing/tax_rate')&&row.body.price===9000&&row.body.currency==='USD'));
 const polls=billing.requests.filter(row=>row.path.includes('/prepaid/commits/'));assert.ok(polls.length>=1);for(const poll of polls){assert.equal(poll.method,'GET');assert.ok(poll.path.endsWith('/prepaid/commits/owned-purchase-1'));assert.equal(poll.status,200);assert.ok(poll.waitingForRelease===false||poll.waitingForRelease===undefined);}assert.ok(polls.some(row=>row.waitingForRelease===false));
 assert.deepEqual(billing.purchaseStates,{'owned-purchase-1':{amount:10000,status:'paid',pollCount:polls.length,credited:true}});
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width,row.height]),['bundle','quote','typed-consent','pending','model-confirmation','recovered'].flatMap(stage=>[[stage,1100,900],[stage,680,600]]));
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.ok(paths.length);
 const rows=new Map();for(const path of paths)for(const line of (await readFile(join(root,path),'utf8')).trim().split('\n').filter(Boolean)){const row=JSON.parse(line);rows.set(row.uuid??Symbol(),row);}
 const humans=[...rows.values()].filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'&&!row.message.content.startsWith('<')));
 assert.deepEqual(humans.map(row=>row.message.content),['Review this project before buying a usage-credit bundle.','Continue the same release review after the bundle payment.']);
 assert.deepEqual(calls.seed.map(row=>row.path),['/api/hello','/v1/messages?beta=true','/api/hello','/v1/messages?beta=true']);
 const conversation=calls.seed.filter(row=>row.path==='/v1/messages?beta=true');
 for(const row of calls.seed.filter(row=>row.path==='/api/hello')){assert.deepEqual(row.messages,[]);assert.equal(row.model,undefined);}
 assert.equal(calls.agent.length,1);const quota=calls.agent[0];assert.deepEqual(quota.messages,[{role:'user',content:'quota'}]);assert.equal(quota.model,conversation[0].model);assert.equal(quota.child,false);assert.equal(quota.grandchild,false);assert.equal(quota.delivered,true);
 assert.match(conversation[1].model,/fable/i);assert.equal(JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8')).model,'fable');
 const jsonl=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const children=await jsonl('native-children.jsonl'),exits=await jsonl('native-exits.jsonl'),prints=await jsonl('native-print-results.jsonl');
 assert.equal(children.length,3);assert.equal(new Set(children.map(row=>row.pid)).size,3);assert.deepEqual(exits.map(row=>[row.pid,row.code]),children.map((row,index)=>[row.pid,index===0?0:143]));assert.equal(children[1].pid,proof.nativePid);assert.equal(children[2].args[children[2].args.indexOf('--model')+1],'fable');
 assert.equal(prints.length,2);assert.deepEqual(prints.map(row=>[row.pid,row.sessionId,row.subtype]),[children[0],children[2]].map(row=>[row.pid,proof.sessionId,'success']));
 assert.ok(Number.isFinite(evidence.nativeCost)&&evidence.nativeCost>0&&evidence.resumedCost>evidence.nativeCost);assert.deepEqual(prints.map(row=>row.totalCostUsd),[evidence.nativeCost,evidence.resumedCost]);
 const costs=[...rows.values()].filter(row=>row.type==='cost-state');assert.equal(costs.at(-1)?.totalCostUSD,evidence.resumedCost);

 const answers=[...rows.values()].filter(row=>row.type==='assistant'&&typeof row.message?.model==='string');assert.deepEqual(answers.map(row=>row.message.model),conversation.map(row=>row.model));
 return {originalBundleEffects:true,healthChecks:2,quotaChecks:1,conversationTurns:2,requestModels:conversation.map(row=>row.model),nativeExits:exits.map(row=>[row.pid,row.code]),originalCosts:{native:evidence.nativeCost,resumed:evidence.resumedCost},sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),captures:proof.captures,scope:'Synthetic main-owner discounted bundle purchase: original quote/typed consent, pending invoice without early credit or cancellation, paid status, Fable effect and same-session recovery. Failure variants and other owners remain separate; screenshots require visual review.'};
}

/** A failed original invoice must never credit the balance or consent to a model switch. */
export async function verifyNativeCreditFailure(workspace,evidence,billing,calls){
 for(const key of ['actualAppGui','nativeCreditForms','nativeCreditFailure','nativeCreditPendingPayment','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 const proof=JSON.parse(await readFile(join(workspace,'native-credit-failure-app.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.deepEqual(proof.receipts.map(row=>row.stage),['bundle','quote','typed-not-submitted','payment-pending','payment-failed','recovered']);
 for(const row of proof.receipts){assert.equal(row.sessionId,proof.sessionId);assert.equal(row.nativePid,proof.nativePid);const submitted=['payment-pending','payment-failed','recovered'].includes(row.stage);assert.equal(row.purchases,submitted?1:0);assert.equal(row.enabled,submitted);assert.equal(row.balance,0);assert.equal(row.paymentStatus,['payment-failed','recovered'].includes(row.stage)?'failed':submitted?'pending':null);}
 assert.deepEqual(billing.purchases,[{amount:10000,bundle_id:'owned-credit-bundle',expected_price_minor_units:9000}]);assert.equal(billing.balance,0);assert.equal(billing.enabled,true);assert.deepEqual(billing.adminRequests,[]);
 const writes=billing.requests.filter(row=>row.path.startsWith('/api/oauth/organizations/')&&row.method!=='GET'&&!row.path.endsWith('/billing/tax_rate'));assert.deepEqual(writes.map(row=>[row.method,row.path.split('/').at(-1)]),[['POST','setup_overage_billing'],['PUT','overage_spend_limit'],['POST','credits']]);assert.ok(Number.isInteger(writes[0].body.org_monthly_spend_limit)&&writes[0].body.org_monthly_spend_limit>0);assert.deepEqual(writes[1].body,{is_enabled:true});assert.deepEqual(writes[2].body,billing.purchases[0]);
 assert.ok(billing.requests.some(row=>row.method==='POST'&&row.path.endsWith('/billing/tax_rate')&&row.body.price===9000&&row.body.currency==='USD'));
 const polls=billing.requests.filter(row=>row.path.includes('/prepaid/commits/'));assert.ok(polls.length>=1);for(const poll of polls){assert.equal(poll.method,'GET');assert.ok(poll.path.endsWith('/prepaid/commits/owned-purchase-1'));assert.equal(poll.status,200);assert.ok(poll.waitingForRelease===false||poll.waitingForRelease===undefined);}assert.ok(polls.some(row=>row.waitingForRelease===false));
 assert.deepEqual(billing.purchaseStates,{'owned-purchase-1':{amount:10000,status:'failed',pollCount:polls.length,credited:false}});
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width,row.height]),['bundle','quote','typed-consent','pending','error','recovered'].flatMap(stage=>[[stage,1100,900],[stage,680,600]]));
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.ok(paths.length);
 const rows=new Map();for(const path of paths)for(const line of (await readFile(join(root,path),'utf8')).trim().split('\n').filter(Boolean)){const row=JSON.parse(line);rows.set(row.uuid??Symbol(),row);}
 const humans=[...rows.values()].filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'&&!row.message.content.startsWith('<')));
 assert.deepEqual(humans.map(row=>row.message.content),['Review this project before a usage-credit payment failure.','Continue the same release review after the failed payment.']);
 assert.deepEqual(calls.seed.map(row=>row.path),['/api/hello','/v1/messages?beta=true','/api/hello','/v1/messages?beta=true']);
 const conversation=calls.seed.filter(row=>row.path==='/v1/messages?beta=true');
 for(const row of calls.seed.filter(row=>row.path==='/api/hello')){assert.deepEqual(row.messages,[]);assert.equal(row.model,undefined);}
 assert.equal(calls.agent.length,1);const quota=calls.agent[0];assert.deepEqual(quota.messages,[{role:'user',content:'quota'}]);assert.equal(quota.model,conversation[0].model);assert.equal(quota.child,false);assert.equal(quota.grandchild,false);assert.equal(quota.delivered,true);
 assert.equal(conversation[1].model,conversation[0].model);assert.equal(JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8')).model,undefined);
 const jsonl=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const children=await jsonl('native-children.jsonl'),exits=await jsonl('native-exits.jsonl'),prints=await jsonl('native-print-results.jsonl');
 assert.equal(children.length,3);assert.equal(new Set(children.map(row=>row.pid)).size,3);assert.deepEqual(exits.map(row=>[row.pid,row.code]),children.map((row,index)=>[row.pid,index===0?0:143]));assert.equal(children[1].pid,proof.nativePid);assert.ok(!children[2].args.includes('fable'));
 assert.equal(prints.length,2);assert.deepEqual(prints.map(row=>[row.pid,row.sessionId,row.subtype]),[children[0],children[2]].map(row=>[row.pid,proof.sessionId,'success']));
 assert.ok(Number.isFinite(evidence.nativeCost)&&evidence.nativeCost>0&&evidence.resumedCost>evidence.nativeCost);assert.deepEqual(prints.map(row=>row.totalCostUsd),[evidence.nativeCost,evidence.resumedCost]);
 const costs=[...rows.values()].filter(row=>row.type==='cost-state');assert.equal(costs.at(-1)?.totalCostUSD,evidence.resumedCost);

 const answers=[...rows.values()].filter(row=>row.type==='assistant'&&typeof row.message?.model==='string');assert.deepEqual(answers.map(row=>row.message.model),conversation.map(row=>row.model));
 return {originalFailureEffects:true,healthChecks:2,quotaChecks:1,conversationTurns:2,requestModels:conversation.map(row=>row.model),nativeExits:exits.map(row=>[row.pid,row.code]),originalCosts:{native:evidence.nativeCost,resumed:evidence.resumedCost},sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),captures:proof.captures,scope:'Synthetic main-owner failed bundle invoice: original quote/typed consent, held pending status, original failure and cancel-first recovery, zero balance, unchanged model and same-session recovery. Direct HTTP errors, additional verification and other owners remain separate; screenshots require visual review.'};
}

/** Original immediate purchase errors preserve financial state and the current model. */
export async function verifyNativeCreditPaymentError(workspace,evidence,billing,calls){
 for(const key of ['actualAppGui','nativeCreditForms','nativeCreditFailure','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 const proof=JSON.parse(await readFile(join(workspace,'native-credit-failure-app.json'),'utf8'));
 const scenario=proof.scenario;assert.ok(['payment-action','payment-http-error'].includes(scenario));assert.equal(evidence.nativeCreditFailureScenario,scenario);assert.equal(evidence.nativeCreditPendingPayment,false);const action=scenario==='payment-action',status=action?'action_needed':'error';
 if(action)assert.match(proof.errorMessage,/^Your card requires additional verification — this purchase was not completed[.] Try again at https:\/\/claude[.]ai\/settings\/usage/);else assert.equal(proof.errorMessage,'Unexpected purchase state');
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.deepEqual(proof.receipts.map(row=>row.stage),['bundle','quote','typed-not-submitted','payment-failed','recovered']);
 for(const row of proof.receipts){assert.equal(row.sessionId,proof.sessionId);assert.equal(row.nativePid,proof.nativePid);const submitted=['payment-failed','recovered'].includes(row.stage);assert.equal(row.purchases,submitted?1:0);assert.equal(row.enabled,submitted);assert.equal(row.balance,0);assert.equal(row.paymentStatus,submitted?status:null);}
 assert.deepEqual(billing.purchases,[{amount:10000,bundle_id:'owned-credit-bundle',expected_price_minor_units:9000}]);assert.equal(billing.balance,0);assert.equal(billing.enabled,true);assert.deepEqual(billing.adminRequests,[]);
 const writes=billing.requests.filter(row=>row.path.startsWith('/api/oauth/organizations/')&&row.method!=='GET'&&!row.path.endsWith('/billing/tax_rate'));assert.deepEqual(writes.map(row=>[row.method,row.path.split('/').at(-1)]),[['POST','setup_overage_billing'],['PUT','overage_spend_limit'],['POST','credits']]);assert.ok(Number.isInteger(writes[0].body.org_monthly_spend_limit)&&writes[0].body.org_monthly_spend_limit>0);assert.deepEqual(writes[1].body,{is_enabled:true});assert.deepEqual(writes[2].body,billing.purchases[0]);
 assert.ok(billing.requests.some(row=>row.method==='POST'&&row.path.endsWith('/billing/tax_rate')&&row.body.price===9000&&row.body.currency==='USD'));
 const polls=billing.requests.filter(row=>row.path.includes('/prepaid/commits/'));assert.equal(polls.length,0);assert.equal(writes[2].status,action?200:500);
 assert.deepEqual(billing.purchaseStates,{'owned-purchase-1':{amount:10000,status,pollCount:0,credited:false}});
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width,row.height]),['bundle','quote','typed-consent','error','recovered'].flatMap(stage=>[[stage,1100,900],[stage,680,600]]));
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.ok(paths.length);
 const rows=new Map();for(const path of paths)for(const line of (await readFile(join(root,path),'utf8')).trim().split('\n').filter(Boolean)){const row=JSON.parse(line);rows.set(row.uuid??Symbol(),row);}
 const humans=[...rows.values()].filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'&&!row.message.content.startsWith('<')));
 assert.deepEqual(humans.map(row=>row.message.content),['Review this project before a usage-credit payment failure.','Continue the same release review after the failed payment.']);
 assert.deepEqual(calls.seed.map(row=>row.path),['/api/hello','/v1/messages?beta=true','/api/hello','/v1/messages?beta=true']);
 const conversation=calls.seed.filter(row=>row.path==='/v1/messages?beta=true');
 for(const row of calls.seed.filter(row=>row.path==='/api/hello')){assert.deepEqual(row.messages,[]);assert.equal(row.model,undefined);}
 assert.equal(calls.agent.length,1);const quota=calls.agent[0];assert.deepEqual(quota.messages,[{role:'user',content:'quota'}]);assert.equal(quota.model,conversation[0].model);assert.equal(quota.child,false);assert.equal(quota.grandchild,false);assert.equal(quota.delivered,true);
 assert.equal(conversation[1].model,conversation[0].model);assert.equal(JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8')).model,undefined);
 const jsonl=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const children=await jsonl('native-children.jsonl'),exits=await jsonl('native-exits.jsonl'),prints=await jsonl('native-print-results.jsonl');
 assert.equal(children.length,3);assert.equal(new Set(children.map(row=>row.pid)).size,3);assert.deepEqual(exits.map(row=>[row.pid,row.code]),children.map((row,index)=>[row.pid,index===0?0:143]));assert.equal(children[1].pid,proof.nativePid);assert.ok(!children[2].args.includes('fable'));
 assert.equal(prints.length,2);assert.deepEqual(prints.map(row=>[row.pid,row.sessionId,row.subtype]),[children[0],children[2]].map(row=>[row.pid,proof.sessionId,'success']));
 assert.ok(Number.isFinite(evidence.nativeCost)&&evidence.nativeCost>0&&evidence.resumedCost>evidence.nativeCost);assert.deepEqual(prints.map(row=>row.totalCostUsd),[evidence.nativeCost,evidence.resumedCost]);
 const costs=[...rows.values()].filter(row=>row.type==='cost-state');assert.equal(costs.at(-1)?.totalCostUSD,evidence.resumedCost);

 const answers=[...rows.values()].filter(row=>row.type==='assistant'&&typeof row.message?.model==='string');assert.deepEqual(answers.map(row=>row.message.model),conversation.map(row=>row.model));
 return {originalPaymentErrorEffects:true,scenario,errorMessage:proof.errorMessage,healthChecks:2,quotaChecks:1,conversationTurns:2,requestModels:conversation.map(row=>row.model),nativeExits:exits.map(row=>[row.pid,row.code]),originalCosts:{native:evidence.nativeCost,resumed:evidence.resumedCost},sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),captures:proof.captures,scope:'Synthetic main-owner immediate purchase error: original additional-verification or HTTP failure disclosure, cancel-first recovery, zero balance, unchanged model and same-session continuation. Browser completion, retries, other owners and policy/lifecycle combinations remain separate; screenshots require visual review.'};
}

/** Failed sends and newly disabled requests retain native messages without false notifications. */
export async function verifyNativeCreditAdminError(workspace,evidence,billing,calls){
 for(const key of ['actualAppGui','nativeCreditForms','nativeCreditAdminError','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 const proof=JSON.parse(await readFile(join(workspace,'native-credit-admin-error-app.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.deepEqual(proof.receipts.map(row=>row.stage),['sending','send-failed','eligibility-refused']);
 for(const row of proof.receipts){assert.equal(row.adminRequests,0);assert.equal(row.sessionId,proof.sessionId);assert.equal(row.nativePid,proof.nativePid);assert.equal(row.modelUnchanged,true);}
 assert.equal(billing.enabled,false);assert.equal(billing.balance,0);assert.deepEqual(billing.purchases,[]);assert.deepEqual(billing.adminRequests,[]);
 const writes=billing.requests.filter(row=>row.path.startsWith('/api/oauth/organizations/')&&row.method!=='GET');assert.equal(writes.length,1);assert.ok(writes[0].path.endsWith('/admin_requests'));assert.equal(writes[0].method,'POST');assert.deepEqual(writes[0].body,{request_type:'limit_increase',details:null});assert.equal(writes[0].waitingForRelease,false);assert.equal(writes[0].transportFailure,'response-disconnected');assert.equal(writes[0].fixtureFailure,undefined);assert.equal(writes[0].status,undefined);assert.ok(writes[0].finishedAt>=writes[0].at);
 for(const [suffix,query,count]of [['/admin_requests/eligibility','?request_type=limit_increase',2],['/admin_requests/me','?request_type=limit_increase&statuses=pending',1]]){const reads=billing.requests.filter(row=>row.path.endsWith(suffix));assert.equal(reads.length,count);for(const row of reads){assert.equal(row.method,'GET');assert.equal(row.status,200);assert.equal(row.query,query);}}
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width,row.height]),[['confirmation',1100,900],['confirmation',680,600],['pending',680,600],...['error-recovery','refused-recovery'].flatMap(stage=>[[stage,1100,900],[stage,680,600]])]);
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.ok(paths.length);const rows=new Map();
 for(const path of paths)for(const line of (await readFile(join(root,path),'utf8')).trim().split('\n').filter(Boolean)){const row=JSON.parse(line);rows.set(row.uuid??Symbol(),row);}
 const originalText=JSON.stringify([...rows.values()]);assert.ok(originalText.includes("Couldn't send your request. Try again later."));assert.ok(originalText.includes('Usage credit requests are turned off for your organization.'));assert.ok(!originalText.includes('Request sent to your admin to turn on usage credits.'));
 const humans=[...rows.values()].filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'&&!row.message.content.startsWith('<')));
 assert.deepEqual(humans.map(row=>row.message.content),['Review this project before requesting usage credits.','Continue the same release review after an admin credit request.']);
 assert.deepEqual(calls.seed.map(row=>row.path),['/api/hello','/v1/messages?beta=true','/api/hello','/v1/messages?beta=true']);const conversation=calls.seed.filter(row=>row.path==='/v1/messages?beta=true');
 for(const row of calls.seed.filter(row=>row.path==='/api/hello')){assert.deepEqual(row.messages,[]);assert.equal(row.model,undefined);}
 assert.equal(calls.agent.length,1);assert.deepEqual(calls.agent[0].messages,[{role:'user',content:'quota'}]);assert.equal(calls.agent[0].model,conversation[0].model);assert.equal(calls.agent[0].child,false);assert.equal(calls.agent[0].delivered,true);
 assert.equal(conversation[1].model,conversation[0].model);assert.equal(JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8')).model,undefined);
 const jsonl=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);const children=await jsonl('native-children.jsonl'),exits=await jsonl('native-exits.jsonl'),prints=await jsonl('native-print-results.jsonl');
 assert.equal(children.length,3);assert.equal(new Set(children.map(row=>row.pid)).size,3);assert.deepEqual(exits.map(row=>[row.pid,row.code]),children.map((row,index)=>[row.pid,index===0?0:143]));assert.equal(children[1].pid,proof.nativePid);
 assert.equal(prints.length,2);assert.deepEqual(prints.map(row=>[row.pid,row.sessionId,row.subtype]),[children[0],children[2]].map(row=>[row.pid,proof.sessionId,'success']));assert.ok(Number.isFinite(evidence.nativeCost)&&evidence.nativeCost>0&&evidence.resumedCost>evidence.nativeCost);assert.deepEqual(prints.map(row=>row.totalCostUsd),[evidence.nativeCost,evidence.resumedCost]);
 assert.equal([...rows.values()].filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD,evidence.resumedCost);assert.deepEqual([...rows.values()].filter(row=>row.type==='assistant'&&typeof row.message?.model==='string').map(row=>row.message.model),conversation.map(row=>row.model));
 return {originalAdminErrorEffects:true,sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),requestModels:conversation.map(row=>row.model),ownedExits:exits.map(row=>[row.pid,row.code]),captures:proof.captures,scope:'Synthetic Team member: original confirmation and non-cancellable pending send, disconnected response with original failure message, newly disabled organization refusing retry, no filed requests, unchanged model and same-session recovery. HTTP error classification, real notifications and other owner/policy/lifecycle combinations remain separate.'};
}
