import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

/** Validate original effects independently of the renderer's success flags. */
export async function verifyNativeCreditPurchase(workspace,evidence,billing,calls){
 const proof=JSON.parse(await readFile(join(workspace,'native-credit-app.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);assert.equal(evidence.finalSessionId,proof.sessionId);
 const stages=['bundles','invalid-preview','valid-preview','quote','typed-not-submitted','cancel-charge','purchased'];
 assert.deepEqual(proof.receipts.map(row=>row.stage),stages);
 for(const row of proof.receipts){assert.equal(row.sessionId,proof.sessionId);assert.equal(row.nativePid,proof.nativePid);assert.equal(row.purchases,row.stage==='purchased'?1:0);assert.equal(row.enabled,row.stage==='purchased');assert.equal(row.balance,row.stage==='purchased'?7500:0);}
 assert.deepEqual(billing.purchases,[{amount:7500}]);assert.equal(billing.balance,7500);assert.equal(billing.enabled,true);assert.deepEqual(billing.adminRequests,[]);
 const writes=billing.requests.filter(row=>row.path.startsWith('/api/oauth/organizations/')&&row.method!=='GET'&&!row.path.endsWith('/billing/tax_rate'));
 assert.deepEqual(writes.map(row=>[row.method,row.path.split('/').at(-1)]),[['POST','setup_overage_billing'],['PUT','overage_spend_limit'],['POST','credits']]);
 assert.ok(Number.isInteger(writes[0].body.org_monthly_spend_limit)&&writes[0].body.org_monthly_spend_limit>0);assert.deepEqual(writes[1].body,{is_enabled:true});assert.deepEqual(writes[2].body,{amount:7500});
 assert.ok(billing.requests.some(row=>row.method==='POST'&&row.path.endsWith('/billing/tax_rate')&&row.body.price===7500&&row.body.currency==='USD'));
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width,row.height]),['amount-preview','quote','typed-consent','recovered'].flatMap(stage=>[[stage,1100,900],[stage,680,600]]));
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.ok(paths.length);
 const rows=new Map();for(const path of paths)for(const line of (await readFile(join(root,path),'utf8')).trim().split('\n').filter(Boolean)){const row=JSON.parse(line);rows.set(row.uuid??Symbol(),row);}
 const humans=[...rows.values()].filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'&&!row.message.content.startsWith('<')));
 assert.deepEqual(humans.map(row=>row.message.content),['Review this project before choosing a credit-billed model.','Continue the same release review after usage-credit controls close.']);
 assert.equal(calls.seed.length,2);assert.equal(calls.agent.length,0);
 const answers=[...rows.values()].filter(row=>row.type==='assistant'&&typeof row.message?.model==='string');assert.deepEqual(answers.map(row=>row.message.model),calls.seed.map(row=>row.model));
 return {originalBillingEffects:true,sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),captures:proof.captures,scope:'Synthetic eligible main-owner custom purchase, live native feedback, quote, explicit typed consent, cancellation and same-session recovery. Admin, bundle, failure/pending and other owners remain separate; screenshots require visual review.'};
}
