import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Check real empty-thread resume/upload observations against the original imported journal. */
export async function verifyResumeUpload(workspace){
 const proof=JSON.parse(await readFile(join(workspace,'native-resume-upload-proof.json'),'utf8'));
 for(const key of ['uploadHeld','uploadCompleted','resumeFromOtherWindow','sameEmptyThread','noResetDuringUpload','oldSendRetired','draftAndImageRetained','explicitImageRemoval'])assert.equal(proof[key],true);
 assert.equal(proof.sourceSessionId,proof.finalSessionId);assert.equal(proof.replacementImageBlocks,0);assert.equal(proof.captures.length,4);
 const ownership=JSON.parse(await readFile(join(workspace,'native-resume-upload-ownership.json'),'utf8'));
 assert.equal(ownership.sameEditor,true);assert.equal(ownership.ownershipTransitions.length,1);assert.equal(ownership.ownershipTransitions[0].threadId,proof.threadId);assert.equal(ownership.ownershipTransitions[0].mode,'Claude Code');
 let rows;const projects=join(workspace,'.claude/projects');
 for(const bucket of await readdir(projects)){try{rows=(await readFile(join(projects,bucket,proof.finalSessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break;}catch(error){if(error.code!=='ENOENT')throw error;}}
 assert.ok(rows);const humans=rows.filter(row=>row.type==='user'&&row.isMeta!==true&&row.isVirtual!==true);
 assert.ok(proof.baselineHumanUuids.length>0);assert.deepEqual(humans.map(row=>row.uuid),[...proof.baselineHumanUuids,proof.newHumanUuid]);
 const fresh=humans.at(-1);assert.equal(typeof fresh.message.content,'string');assert.ok(fresh.message.content.includes(proof.freshText));assert.ok(!fresh.message.content.includes(proof.heldDraft));
 const cost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,proof.finalCost);assert.ok(Number.isFinite(proof.baselineCost)&&proof.finalCost>=proof.baselineCost);
 return{sameEmptyThread:true,originalHistoryPreserved:true,oldSendRetired:true,originalCostMatched:true,replacementImageBlocks:0};
}

/** Correlate populated-thread import with both immutable native histories and ownership changes. */
export async function verifyPopulatedResumeUpload(workspace,modelCalls){
 const proof=JSON.parse(await readFile(join(workspace,'native-populated-resume-upload-proof.json'),'utf8'));
 for(const key of ['uploadHeld','uploadCompleted','resumeFromOtherWindow','populatedHistoryPreserved','noResetDuringUpload','oldSendRetired','draftAndImageRetained','explicitImageRemoval'])assert.equal(proof[key],true);
 assert.equal(proof.sourceSessionId,proof.finalSessionId);
 assert.notEqual(proof.priorSessionId,proof.finalSessionId);
 assert.notEqual(proof.threadId,proof.importedThreadId);
 assert.equal(proof.replacementImageBlocks,0);assert.equal(proof.captures.length,4);
 assert.ok(proof.priorCost>proof.baselineCost);
 const ownership=JSON.parse(await readFile(join(workspace,'native-populated-resume-upload-ownership.json'),'utf8'));
 assert.equal(ownership.sameEditor,true);assert.ok(ownership.ownershipTransitions.length>=2);
 const first=ownership.ownershipTransitions[0],last=ownership.ownershipTransitions.at(-1);
 assert.equal(first.threadId,proof.threadId);assert.equal(first.mode,'Claude Code');
 assert.deepEqual(last,{...first,threadId:proof.importedThreadId});
 const projects=join(workspace,'.claude/projects');
 async function rowsFor(id){for(const bucket of await readdir(projects)){try{return (await readFile(join(projects,bucket,id+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse)}catch(error){if(error.code!=='ENOENT')throw error}}throw Error('Missing original journal '+id)}
 const humans=rows=>rows.filter(row=>row.type==='user'&&row.isMeta!==true&&row.isVirtual!==true);
 const original=await rowsFor(proof.priorSessionId),imported=await rowsFor(proof.finalSessionId);
 assert.equal(proof.priorHumanUuids.length,2);assert.equal(proof.priorAppHumanIds.length,2);
 assert.deepEqual(humans(original).map(row=>row.uuid),proof.priorHumanUuids);
 for(const text of proof.priorTexts)assert.ok(humans(original).some(row=>JSON.stringify(row.message.content).includes(text)));
 assert.equal(original.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD,proof.priorCost);
 assert.ok(proof.baselineHumanUuids.length>0);
 assert.deepEqual(humans(imported).map(row=>row.uuid),[...proof.baselineHumanUuids,proof.newHumanUuid]);
 const fresh=humans(imported).at(-1);assert.equal(typeof fresh.message.content,'string');
 assert.ok(fresh.message.content.includes(proof.freshText));assert.ok(!fresh.message.content.includes(proof.heldDraft));
 assert.equal(imported.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD,proof.finalCost);
 assert.ok(Number.isFinite(proof.baselineCost)&&proof.finalCost>proof.baselineCost);
 const jsonLines=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').map(JSON.parse);
 const children=await jsonLines('native-children.jsonl'),exits=await jsonLines('native-exits.jsonl'),prints=await jsonLines('native-print-results.jsonl');
 assert.equal(children.length,4);assert.equal(new Set(children.map(row=>row.pid)).size,4);
 assert.equal(exits.length,4);for(const child of children){const exit=exits.find(row=>row.pid===child.pid);assert.ok(exit);assert.ok([0,143].includes(exit.code));assert.ok(exit.at>=child.at)}
 assert.equal(children[1].pid,proof.boundNativePid);
 assert.deepEqual(prints.map(row=>row.sessionId),[proof.sourceSessionId,proof.priorSessionId,proof.priorSessionId,proof.finalSessionId]);
 assert.deepEqual(prints.map(row=>row.pid),[children[0].pid,children[2].pid,children[2].pid,children[3].pid]);
 assert.deepEqual(prints.map(row=>row.totalCostUsd),[proof.baselineCost,proof.baselineCost,proof.priorCost,proof.finalCost]);
 assert.ok(exits.find(row=>row.pid===children[0].pid).at<=children[1].at);
 assert.ok(exits.find(row=>row.pid===children[1].pid).at<=children[2].at);
 assert.equal(children[2].args.includes('--resume'),false);
 assert.equal(children[3].args[children[3].args.indexOf('--resume')+1],proof.finalSessionId);
 const calls=modelCalls??JSON.parse(await readFile(join(workspace,'model-calls.json'),'utf8')).seed;
 assert.equal(calls.length,4);assert.ok(calls.every(row=>row.path==='/v1/messages?beta=true'));
 const finalEnvelope=JSON.stringify(calls.at(-1).messages);
 assert.ok(finalEnvelope.includes(proof.freshText));assert.ok(!finalEnvelope.includes(proof.heldDraft));
 for(const text of proof.priorTexts)assert.ok(!finalEnvelope.includes(text));
 function images(value){if(!value||typeof value!=='object')return 0;return (value.type==='image'?1:0)+Object.values(value).reduce((sum,item)=>sum+images(item),0)}
 assert.equal(images(calls.at(-1).messages),0);
 return{populatedHistoryPreserved:true,distinctImportedThread:true,oldSendRetired:true,originalCostMatched:true,replacementImageBlocks:0};
}
