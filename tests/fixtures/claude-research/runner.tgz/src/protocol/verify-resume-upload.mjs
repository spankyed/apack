import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';

/** Check real empty-thread resume/upload observations against the original imported journal. */
export async function verifyResumeUpload(workspace){
 const proof=JSON.parse(await readFile(join(workspace,'native-resume-upload-proof.json'),'utf8'));
 for(const key of ['uploadHeld','uploadCompleted','resumeFromOtherWindow','sameEmptyThread','noResetDuringUpload','oldSendRetired','draftAndImageRetained','explicitImageRemoval'])assert.equal(proof[key],true);
 assert.equal(proof.sourceSessionId,proof.finalSessionId);assert.equal(proof.replacementImageBlocks,0);assert.equal(proof.captures.length,4);
 const ownership=JSON.parse(await readFile(join(workspace,'native-resume-upload-ownership.json'),'utf8'));
 assert.equal(ownership.sameEditor,true);assert.equal(ownership.ownershipTransitions.length,1);assert.equal(ownership.ownershipTransitions[0].threadId,proof.threadId);assert.equal(ownership.ownershipTransitions[0].mode,'Claude Code');
 let rows;const projects=join(workspace,'.claude/projects');
 for(const bucket of await readdir(projects)){try{rows=(await readFile(join(projects,bucket,proof.finalSessionId+'.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);break;}catch(error){if(error.code!=='ENOENT')throw error;}}
 assert.ok(rows);const humans=rows.filter(row=>row.type==='user'&&row.isMeta!==true&&row.isVirtual!==true);
 assert.ok(proof.baselineHumanUuids.length>0);assert.deepEqual(humans.map(row=>row.uuid),[...proof.baselineHumanUuids,proof.newHumanUuid]);
 const fresh=humans.at(-1);assert.equal(typeof fresh.message.content,'string');assert.ok(fresh.message.content.includes(proof.freshText));assert.ok(!fresh.message.content.includes(proof.heldDraft));
 const cost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,proof.finalCost);assert.ok(Number.isFinite(proof.baselineCost)&&proof.finalCost>=proof.baselineCost);
 return{sameEmptyThread:true,originalHistoryPreserved:true,oldSendRetired:true,originalCostMatched:true,replacementImageBlocks:0};
}
