import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Observe refusal/dialog eligibility with an isolated local provider, without changing upstream gates. */
export async function probeRefusalDialog(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'refusal-dialog-'));
 const run=await createRun(output,'refusal-dialog',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
 const cases=[];
 try{
  for(const declared of [false,true]){
   const cwd=join(workspace,declared?'declared':'undeclared'),home=join(cwd,'home');await mkdir(join(home,'.claude'),{recursive:true});
   const model=await startSyntheticModel(cwd,'Refusal');let pending='',result;const dialogs=[],assistant=[];let transport;
   try{
    transport=await record({executable,cwd,output,timeoutMs:25000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',switchModelsOnFlag:false}),'--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--tools','','--model','claude-opus-4-8','--no-session-persistence','--max-turns','1','--permission-prompt-tool','stdio'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[JSON.stringify({type:'control_request',request_id:'init',request:{subtype:'initialize',...(declared?{supportedDialogKinds:['refusal_fallback_prompt']}:{})}})+'\n'],onStdout(bytes,channel){
     pending+=bytes.toString();while(pending.includes('\n')){const i=pending.indexOf('\n'),line=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(line)}catch{continue}
      if(value.type==='control_response'&&value.response?.request_id==='init')channel.send(JSON.stringify({type:'user',message:{role:'user',content:'Return the fixed local refusal fixture.'}})+'\n');
      if(value.type==='control_request'){assert.equal(value.request?.subtype,'request_user_dialog');dialogs.push(value);channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:{behavior:'cancelled'}}})+'\n');}
      if(value.type==='assistant')assistant.push({stopReason:value.message?.stop_reason,error:value.error??null});
      if(value.type==='result'){result=value;channel.closeInput();}
     }
    }});
   }finally{await model.close();}
   assert.equal(transport.status,'failed');assert.equal(transport.code,1);assert.equal(transport.reason,undefined);assert.equal(result?.is_error,true);assert.equal(result?.terminal_reason,'api_error');assert.equal(result?.safety_stops,2);assert.equal(model.calls.length,2);assert.equal(dialogs.length,0);assert.ok(assistant.some(value=>value.stopReason==='refusal'));
   cases.push({declaredKinds:declared?['refusal_fallback_prompt']:[],dialogs,assistant,result:{subtype:result.subtype,is_error:result.is_error??false,terminal_reason:result.terminal_reason,safety_stops:result.safety_stops},localModelRequests:model.calls.length,realModelRequests:0,transportRun:transport.directory});
  }
  const evidence={cases,qualification:'Native local-provider refusal observation, not a forced upstream flag/account entitlement or proof of populated-dialog handling. A declaration does not guarantee producer eligibility.'};
  await writeFile(join(run.directory,'refusal-dialog.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
