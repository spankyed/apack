import assert from 'node:assert/strict';
import {writeFile,readFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';

export async function addNativeComposeFixture(workspace,plugin){
 const observer=join(workspace,'native-compose-observer');
 await mkdir(join(observer,'.claude-plugin'),{recursive:true});await mkdir(join(observer,'hooks'),{recursive:true});
 await writeFile(join(observer,'.claude-plugin/plugin.json'),JSON.stringify({name:'native-compose-observer',version:'0.0.1'}));
 await writeFile(join(observer,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
 await writeFile(join(observer,'hooks/register.ts'),`export function register(on){on('prompt.compose',async($,e,next)=>{const result=await next(e);const nonce=await $.fs.read('native-compose-arm.txt').catch(()=>'');if(!nonce)return result;const composed={...result,sections:[...result.sections,{id:'release_review',scope:'session',text:'Review the release instructions without changing the draft.'}]};await $.fs.write('native-compose-observer.json',JSON.stringify({nonce,facts:e,result:composed}));return composed;});}`);
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){let count=0;on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Text({children:['System instructions inspected '+count]}),Button({key:'review-instructions',label:'Review system instructions',onPress:async()=>{const nonce=e.requestId+'|'+count;await $.fs.write('native-compose-arm.txt',nonce);try{const returned=await $.prompt.compose({});await $.fs.write('native-compose-native.json',JSON.stringify({requestId:e.requestId,nonce,returned}));count++;$.ui.invalidate('ui.render');}finally{await $.fs.write('native-compose-arm.txt','');}}})]});});}`);
}

export async function verifyNativeComposeFixture(workspace){
 const native=JSON.parse(await readFile(join(workspace,'native-compose-native.json'),'utf8'));
 assert.ok(native.requestId);
 const observed=JSON.parse(await readFile(join(workspace,'native-compose-observer.json'),'utf8'));
 assert.equal(native.nonce,observed.nonce);assert.deepEqual(native.returned,observed.result);
 assert.equal(typeof observed.facts.model,'string');
 assert.ok(Array.isArray(observed.facts.tools));
 assert.ok(native.returned.sections.length>1);
 assert.ok(native.returned.sections.every(section=>typeof section.id==='string'&&typeof section.text==='string'&&['shared','session'].includes(section.scope)));
 assert.equal(native.returned.sections.filter(section=>section.id==='release_review'&&section.text==='Review the release instructions without changing the draft.').length,1);
 const proof=JSON.parse(await readFile(join(workspace,'native-compose-proof.json'),'utf8'));
 assert.equal(proof.noPhantomTurn,true);assert.deepEqual(proof.widths,[1100,680]);
 return{nativeHookObserved:true,sections:native.returned.sections.length,retainedDraft:true,noPhantomTurn:true};
}
