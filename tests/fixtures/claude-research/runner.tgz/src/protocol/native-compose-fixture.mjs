import assert from 'node:assert/strict';
import {writeFile,readFile} from 'node:fs/promises';
import {join} from 'node:path';

export async function addNativeComposeFixture(plugin){
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){
 let armed=false,observed,count=0;
 on('prompt.compose',async($,e,next)=>{const result=await next(e);if(!armed)return result;const composed={...result,sections:[...result.sections,{id:'release_review',scope:'session',text:'Review the release instructions without changing the draft.'}]};observed={facts:e,result:composed};return composed;});
 on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Text({children:['System instructions inspected '+count]}),Button({key:'review-instructions',label:'Review system instructions',onPress:async()=>{armed=true;observed=undefined;try{const returned=await $.prompt.compose({});await $.fs.write('native-compose-native.json',JSON.stringify({requestId:e.requestId,observed,returned}));count++;$.ui.invalidate('ui.render');}finally{armed=false;}}})]});});
}`);
}

export async function verifyNativeComposeFixture(workspace){
 const native=JSON.parse(await readFile(join(workspace,'native-compose-native.json'),'utf8'));
 assert.ok(native.requestId);
 assert.deepEqual(native.returned,native.observed.result);
 assert.equal(typeof native.observed.facts.model,'string');
 assert.ok(Array.isArray(native.observed.facts.tools));
 assert.ok(native.returned.sections.length>1);
 assert.ok(native.returned.sections.every(section=>typeof section.id==='string'&&typeof section.text==='string'&&['shared','session'].includes(section.scope)));
 assert.equal(native.returned.sections.filter(section=>section.id==='release_review'&&section.text==='Review the release instructions without changing the draft.').length,1);
 const proof=JSON.parse(await readFile(join(workspace,'native-compose-proof.json'),'utf8'));
 assert.equal(proof.noPhantomTurn,true);assert.deepEqual(proof.widths,[1100,680]);
 return{nativeHookObserved:true,sections:native.returned.sections.length,retainedDraft:true,noPhantomTurn:true};
}
