import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readdir, readFile, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { record } from './record.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';
import { hash } from '../artifacts/runs.mjs';

/** Persist two synthetic turns, then fork at the first assistant message using the native CLI. */
export async function probeSessionFork(executable, workspace, output, { compact = false } = {}) {
  executable = resolve(executable); workspace = resolve(workspace); output = resolve(output);
  await mkdir(workspace, { recursive: true });
  const cwd = await mkdtemp(join(workspace, 'fork-'));
  const model = await startSyntheticModel(cwd);
  const base = ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json',
    '--bare', '--setting-sources', '', '--tools', '', '--strict-mcp-config', '--model', 'claude-sonnet-4-6',
    '--settings', JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' })];
  const env = { PATH: process.env.PATH, HOME: cwd, CLAUDE_CONFIG_DIR: join(cwd, '.claude'),
    ANTHROPIC_BASE_URL: model.url, DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' };
  const prompt = text => JSON.stringify({ type: 'user', message: { role: 'user', content: text } }) + '\n';
  async function launch(extra, prompts) {
    let buffer = '', next = 0;
    const messages = [];
    const run = await record({ executable, cwd, output, timeoutMs: 25000, args: [...base, ...extra], env,
      input: [JSON.stringify({ type: 'control_request', request_id: 'initialize', request: { subtype: 'initialize', hooks: {} } }) + '\n'],
      onStdout(bytes, transport) {
        buffer += bytes;
        while (buffer.includes('\n')) {
          const at = buffer.indexOf('\n'), line = buffer.slice(0, at); buffer = buffer.slice(at + 1);
          let value; try { value = JSON.parse(line); } catch { continue; }
          messages.push(value);
          if (value.type === 'control_response' && value.response.request_id === 'initialize') {
            if (prompts.length) transport.send(prompt(prompts[next++]));
            else transport.closeInput();
          }
          if (value.type === 'result') {
            if (next < prompts.length) transport.send(prompt(prompts[next++]));
            else transport.closeInput();
          }
        }
      } });
    return { run, messages, results: messages.filter(value => value.type === 'result') };
  }
  async function sessionFiles() {
    const projects = join(cwd, '.claude', 'projects');
    const files = [];
    for (const bucket of await readdir(projects)) {
      for (const name of await readdir(join(projects, bucket))) {
        if (name.endsWith('.jsonl')) files.push({ path: `${bucket}/${name}`, sha256: hash(await readFile(join(projects, bucket, name))) });
      }
    }
    return files.sort((a,b)=>a.path.localeCompare(b.path));
  }
  async function transcript(id) {
    const projects = join(cwd, '.claude', 'projects');
    for (const bucket of await readdir(projects)) {
      const path = join(projects, bucket, `${id}.jsonl`);
      try { const bytes = await readFile(path); return { path, bytes, rows: bytes.toString().trim().split('\n').map(JSON.parse) }; }
      catch (error) { if (error.code !== 'ENOENT') throw error; }
    }
    throw new Error('Session transcript not found');
  }
  try {
    const initial = await launch([], ['research first turn', 'research second turn', ...(compact ? ['/compact', 'research after compaction'] : [])]);
    assert.equal(initial.run.status, 'complete');
    assert.equal(initial.results.length, compact ? 4 : 2);
    const originalId = initial.results[0].session_id;
    const original = await transcript(originalId);
    const compactBoundaries = original.rows.filter(row => row.type === 'system' && row.subtype === 'compact_boundary');
    if (compact) assert.ok(compactBoundaries.length, 'Native compaction did not produce a persisted boundary');
    const boundary = original.rows.find(row => row.type === 'assistant')?.uuid;
    assert.ok(boundary);
    const fork = await launch(['--resume', originalId, '--fork-session', '--resume-session-at', boundary], ['research fork turn']);
    const forkId = fork.results[0]?.session_id;
    const originalUnchanged = async () => hash((await transcript(originalId)).bytes) === hash(original.bytes);
    let forkTranscript, userTexts, verified, postCompaction;
    if (compact) {
      const rejectedOldBoundary = fork.run.status === 'failed' && fork.results[0]?.subtype === 'error_during_execution'
        && fork.results[0].errors?.some(error => error.includes('No message found with message.uuid'));
      const currentBoundary = original.rows.findLast(row => row.type === 'assistant')?.uuid;
      const callsBeforePreflight = model.calls.length;
      const filesBeforePreflight = await sessionFiles();
      const oldPreflight = await launch(['--resume', originalId, '--fork-session', '--resume-session-at', boundary, '--no-session-persistence'], []);
      const currentPreflight = await launch(['--resume', originalId, '--fork-session', '--resume-session-at', currentBoundary, '--no-session-persistence'], []);
      const preflight = { oldRun: oldPreflight.run.directory, currentRun: currentPreflight.run.directory,
        oldRejected: oldPreflight.results[0]?.subtype === 'error_during_execution',
        currentInitialized: currentPreflight.messages.some(message => message.type === 'control_response' && message.response.request_id === 'initialize' && message.response.subtype === 'success'),
        currentStatus: currentPreflight.run.status, sessionFilesUnchanged: JSON.stringify(filesBeforePreflight) === JSON.stringify(await sessionFiles()), syntheticApiRequests: model.calls.length - callsBeforePreflight };
      const continued = await launch(['--resume', originalId, '--fork-session', '--resume-session-at', currentBoundary], ['research fork turn']);
      const continuedId = continued.results[0]?.session_id;
      forkTranscript = continuedId ? await transcript(continuedId) : null;
      userTexts = forkTranscript?.rows.filter(row => row.type === 'user').map(row => row.message?.content);
      postCompaction = { boundary: currentBoundary, run: continued.run.directory, sessionId: continuedId,
        resultSubtype: continued.results[0]?.subtype, rejectedOldBoundary, preflight };
      verified = rejectedOldBoundary && preflight.oldRejected && preflight.currentInitialized
        && preflight.currentStatus === 'complete' && preflight.sessionFilesUnchanged && preflight.syntheticApiRequests === 0 && continued.run.status === 'complete' && continued.results[0]?.subtype === 'success'
        && continuedId !== originalId && userTexts.includes('research after compaction') && userTexts.includes('research fork turn')
        && forkTranscript.rows.some(row => row.type === 'system' && row.subtype === 'compact_boundary') && await originalUnchanged();
    } else {
      forkTranscript = forkId ? await transcript(forkId) : null;
      userTexts = forkTranscript?.rows.filter(row => row.type === 'user').map(row => row.message?.content);
      verified = fork.run.status === 'complete' && fork.results.length === 1 && fork.results[0].subtype === 'success'
        && forkId !== originalId && await originalUnchanged() && userTexts.includes('research first turn')
        && userTexts.includes('research fork turn') && !userTexts.includes('research second turn');
    }
    const unchanged = await originalUnchanged();
    const evidence = { verified, compact, compactBoundaries, postCompaction, originalId, forkId, boundary, originalUnchanged: unchanged, forkUserTexts: userTexts,
      initialRun: initial.run.directory, forkRun: fork.run.directory, syntheticApiRequests: model.calls.length,
      realModelRequests: 0, driverSha256: hash(await readFile(new URL(import.meta.url))) };
    await writeFile(join(fork.run.directory, 'session-fork.json'), JSON.stringify(evidence, null, 2) + '\n');
    if (!verified) {
      const path = join(fork.run.directory, 'manifest.json');
      const manifest = JSON.parse(await readFile(path));
      await writeFile(path, JSON.stringify({ ...manifest, status: 'failed', reason: 'session-fork-verification-failed' }, null, 2) + '\n');
    }
    assert.equal(verified, true, `Fork verification failed: ${fork.run.directory}`);
    return evidence;
  } finally { await model.close(); }
}
