import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {join,basename,dirname} from 'node:path';

/** Shared live/saved verification; never rerun the CLI to repair aggregate metadata. */
export async function verifyNativeDesktopSettings(workspace,evidence,calls){
 const json=async name=>JSON.parse(await readFile(join(workspace,name),'utf8'));
 const lines=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const proof=await json('native-config-desktop-proof.json');
 for(const key of ['actualAppGui','nativeConfigDesktop','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 assert.equal(evidence.sessionId,evidence.finalSessionId);assert.equal(proof.sessionId,evidence.sessionId);
 assert.equal(proof.local.spinnerTipsEnabled,false);assert.equal(proof.local.prefersReducedMotion,true);
 assert.equal(proof.user.timeFormat,'24-hour');assert.equal(proof.user.language,'French');
 for(const key of ['retainedDraft','reopenedValues','lockedControl'])assert.equal(proof[key],true,key);
 assert.equal(proof.captures.length,4);
 for(const file of proof.captures){const bytes=await readFile(join(workspace,'electron-results',basename(dirname(file)),basename(file)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
 const frame=proof.nativeStatusRows===true?await verifyNativeDesktopStatus(workspace,proof):proof.desktopFrameTabs===true?await verifyNativeDesktopSettingsFrame(workspace,proof):undefined;
 const stats=proof.statsCompleteness?await verifyNativeStatsCompleteness(workspace,proof.statsCompleteness,proof.frameCaptures[0]):undefined;
 assert.equal(calls.seed.length,2);assert.equal(calls.agent.length,1);
 assert.ok(calls.agent.some(call=>JSON.stringify(call.messages??[]).includes('Always respond in French.')),'Original language change did not reach the next native model request');
 if(proof.nativeSettingsEditors)assert.ok(calls.agent.some(call=>(call.messages??[]).some(message=>message.role==='system'&&JSON.stringify(message.content).includes('# Output Style: '+proof.outputStyleEditor.after.outputStyle))),'Original output style did not reach the recovered native model request');
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),preloads=await lines('user-preload-calls.jsonl');
 assert.equal(children.length,3);assert.equal(exits.length,3);
 for(const child of children){assert.equal(exits.filter(exit=>exit.pid===child.pid&&[0,143].includes(exit.code)).length,1);assert.equal(preloads.filter(row=>row.pid===child.pid).length,1);}
 const prefixes=await lines('prefix-exits.jsonl');assert.ok(prefixes.length>0);assert.ok(prefixes.every(row=>row.args[0]==='--fixture-prefix'&&row.code===0));
 const prints=await lines('native-print-results.jsonl');assert.equal(prints.at(-1).sessionId,evidence.sessionId);
 return {...(frame?{desktopFrame:frame}:{}),...(stats?{richStats:stats}:{}),...(proof.nativeSettingsEditors?{nativeEditors:{outputStyle:proof.outputStyleEditor.after.outputStyle,styleModelEffectApplied:true,noteReopened:proof.outputStyleEditor.forms.noteReopened,numberReopened:proof.outputStyleEditor.forms.numberReopened,validationMessage:proof.outputStyleEditor.forms.validationMessage,captures:[...proof.outputStyleEditor.samples,...proof.outputStyleEditor.forms.samples].map(row=>basename(row.capture)),scope:'Parent Output Style selection/cancel/persistence/reopen and provided text/number form cancellation, exact Unicode reopen and native validation. Actual held cancellation, Agent and other editor contracts remain separate.'}}:{}),nativeConfigDesktopLanguageApplied:true,sessionId:evidence.sessionId,nativeProcesses:children.length,exitCodes:exits.map(row=>row.code),syntheticApiRequests:calls.seed.length+calls.agent.length,realModelRequests:0,captures:proof.captures.map(file=>basename(file)),scope:'Parent desktop booleans/choice/language, original file persistence and model effect, locked control, retained composing/reopen and same-session recovery. Original exit receipts only; no new post-exit PID liveness audit.'};
}

/** Native Status-only acceptance does not claim that unvisited tabs or Stats ran. */
export async function verifyNativeDesktopStatus(workspace,proof){
 assert.equal(proof.nativeStatusRows,true);assert.equal(proof.desktopFrameTabs,false);assert.equal(proof.nativeStatsDates,false);assert.equal(proof.statsCompleteness,undefined);
 assert.deepEqual(proof.statusSamples.map(row=>row.width),[1100,680]);assert.equal(proof.frameCaptures.length,2);
 const expected=new Set([1100,680].map(width=>'native-settings-desktop-status-'+width+'.png'));
 if(proof.nativeSettingsEditors){
  const editor=proof.outputStyleEditor;assert.equal(editor.forms.cancelPreserved,true);assert.equal(editor.forms.noteReopened,true);assert.equal(editor.forms.numberReopened,'3');assert.match(editor.forms.validationMessage,/between 1 and 9/);assert.deepEqual(editor.forms.samples.map(row=>row.width),[1100,680]);for(const row of editor.forms.samples){assert.equal(row.draft,editor.forms.noteDraft);assert.equal(basename(row.capture),`native-settings-note-form-${row.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(row.capture)),basename(row.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}assert.equal(editor.cancelPreserved,true);assert.equal(editor.reopenedNativeSelection,true);assert.notEqual(editor.after.outputStyle,editor.before.outputStyle);assert.equal(typeof editor.after.outputStyle,'string');assert.ok(editor.chosenLabel.length>0);assert.deepEqual(editor.samples.map(row=>row.width),[1100,680]);
  for(const row of editor.samples){assert.ok(row.options.length>1);assert.equal(row.realWheel,true);assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);assert.equal(basename(row.capture),`native-settings-output-style-${row.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(row.capture)),basename(row.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
 }

 for(const row of proof.statusSamples){assert.match(row.value,/user settings/i);assert.match(row.value,/project local settings/i);assert.match(row.value,/,\s+/);assert.equal(row.realWheel,true);assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);}
 if(proof.nativeStatusDiagnostics){for(const row of proof.statusSamples){assert.match(row.diagnostic.text,/Native installation exists but ~\/\.local\/bin is not in your PATH/);assert.equal(row.diagnostic.realWheel,true);assert.equal(row.diagnostic.geometry.visible,true);assert.ok(row.diagnostic.geometry.top>=row.diagnostic.geometry.viewportTop-1);assert.ok(row.diagnostic.geometry.bottom<=row.diagnostic.geometry.viewportBottom+1);}}
 if(proof.nativeStatusDiagnosticList){
  const reference=proof.statusSamples[0].diagnosticReadings.map(row=>row.text);assert.ok(reference.length>0&&reference.length<=128);
  for(const sample of proof.statusSamples){assert.deepEqual(sample.diagnosticReadings.map(row=>row.text),reference);for(const [index,row]of sample.diagnosticReadings.entries()){
   assert.equal(row.index,index);assert.equal(row.realWheel,true);assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);
   assert.equal(basename(row.capture),`native-settings-diagnostic-${index}-${sample.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(row.capture)),basename(row.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
  }}
 }
 for(const file of proof.frameCaptures){assert.ok(expected.delete(basename(file)));const bytes=await readFile(join(workspace,'electron-results',basename(dirname(file)),basename(file)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
 assert.equal(expected.size,0);return {tab:'Status',samples:proof.statusSamples,captures:proof.frameCaptures.map(file=>basename(file)),scope:'Original multi-source Status value and real normal/compact row reading. Conditional unlabeled warning admission, live status and other tabs retain separate acceptance.'};
}

/** The new frame journey supplements accepted scalar settings; it never retroactively claims old captures. */
export async function verifyNativeDesktopSettingsFrame(workspace,proof){
 assert.equal(proof.desktopFrameTabs,true);assert.equal(proof.nativeStatsDates,true);
 assert.equal(proof.frameCaptures.length,6);
 const expected=new Set(['status','usage','stats'].flatMap(tab=>[680,1100].map(width=>'native-settings-desktop-'+tab+'-'+width+'.png')));
 for(const file of proof.frameCaptures){
  assert.ok(expected.delete(basename(file)),'Unexpected or duplicate desktop frame capture');
  const bytes=await readFile(join(workspace,'electron-results',basename(dirname(file)),basename(file)));
  assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
 }
 assert.equal(expected.size,0);
 return {tabs:['Status','Config','Usage','Stats'],nativeStatsDates:true,captures:proof.frameCaptures.map(file=>basename(file)),scope:'Actual-app tab/Status version/Usage window/Stats model and native date checks, normal/compact captures and retained parent journey. Capture existence is not visual acceptance; richer Stats, conditional Usage and other original Settings contracts remain open.'};
}

/** Saved and live verification of native historical filtering and original clipboard bytes. */
export async function verifyNativeStatsCompleteness(workspace,proof,frameCapture){
 assert.deepEqual(proof.histories.map(row=>row.age),[2,12,45]);assert.equal(new Set(proof.histories.map(row=>row.id)).size,3);
 for(const row of proof.histories){assert.ok(row.tokens>0);assert.match(row.sha256,/^[a-f0-9]{64}$/);}
 assert.deepEqual(proof.ranges.map(row=>row.range),['all','7d','30d','all-restored']);
 for(const row of proof.ranges){const days=row.range==='7d'?7:row.range==='30d'?30:Infinity;const expected=proof.baselineTokens+proof.histories.filter(item=>item.age<days).reduce((sum,item)=>sum+item.tokens,0);assert.equal(row.expected,expected);assert.equal(row.observed,expected);}
 assert.deepEqual(proof.reading.map(row=>row.width),[1100,680]);for(const row of proof.reading){assert.equal(row.longest,true);assert.equal(row.modelTable,true);assert.equal(row.realWheel,true);assert.equal(row.historicalDate,proof.histories[2].date);}
 const captureRoot=join(workspace,'electron-results',basename(dirname(frameCapture)));
 const calendar=proof.captures.some(file=>basename(file).startsWith('native-rich-stats-calendar-'));
 const labels=calendar?['calendar','summary','insight','history','models']:['summary','insight','history','models'];
 assert.equal(proof.captures.length,labels.length*2);const expected=new Set(labels.flatMap(label=>[1100,680].map(width=>'native-rich-stats-'+label+'-'+width+'.png')));
 for(const file of proof.captures){assert.ok(expected.delete(basename(file)));const bytes=await readFile(join(captureRoot,basename(file)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}assert.equal(expected.size,0);
 const modelsExports=proof.exports.filter(row=>row.view==='Models');
 if(modelsExports.length){
  assert.deepEqual(proof.exports.map(row=>[row.view,row.width]),[['Overview',1100],['Overview',680],['Models',1100],['Models',680]]);
  for(const width of [1100,680])assert.notEqual(proof.exports.find(row=>row.view==='Overview'&&row.width===width).sha256,modelsExports.find(row=>row.width===width).sha256,'Models export must not reuse the Overview image');
 }else assert.deepEqual(proof.exports.map(row=>row.width),[1100,680]);
 for(const row of proof.exports){assert.ok(row.formats.includes('image/png'));const bytes=await readFile(join(captureRoot,row.file));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),row.size.width);assert.equal(bytes.readUInt32BE(20),row.size.height);assert.ok(row.size.width>0&&row.size.height>0);assert.equal(createHash('sha256').update(bytes).digest('hex'),row.sha256);}
 return {ranges:proof.ranges,exports:proof.exports,captures:proof.captures.map(file=>basename(file)),scope:'Owned multi-day transcript fixtures admitted by original Stats discovery; native all/7d/30d totals, real wheel summary/history reading and original clipboard PNGs. Byte receipts are not visual review or all original Settings/lifecycle acceptance.'};
}
