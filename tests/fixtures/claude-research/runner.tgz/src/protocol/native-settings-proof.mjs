import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {join,basename,dirname} from 'node:path';

/** Shared live/saved verification; never rerun the CLI to repair aggregate metadata. */
export async function verifyNativeDesktopSettings(workspace,evidence,calls){
 const json=async name=>JSON.parse(await readFile(join(workspace,name),'utf8'));
 const lines=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const proof=await json('native-config-desktop-proof.json');
 let nativeHelloRequests=0;
 if(proof.updateDecisions){
  assert.deepEqual(calls.seed.map(call=>call.path),['/api/hello','/v1/messages?beta=true','/api/hello','/v1/messages?beta=true']);assert.deepEqual(calls.agent.map(call=>call.path),['/api/hello','/v1/messages?beta=true']);
  nativeHelloRequests=3;calls={seed:calls.seed.filter(call=>call.path==='/v1/messages?beta=true'),agent:calls.agent.filter(call=>call.path==='/v1/messages?beta=true')};
 }
 for(const key of ['actualAppGui','nativeConfigDesktop','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 assert.equal(evidence.sessionId,evidence.finalSessionId);assert.equal(proof.sessionId,evidence.sessionId);
 assert.equal(proof.local.spinnerTipsEnabled,false);assert.equal(proof.local.prefersReducedMotion,true);
 assert.equal(proof.user.timeFormat,'24-hour');assert.equal(proof.user.language,'French');
 if(proof.updateDecisions){
  const offline=await json('native-update-offline.json');assert.equal(offline.networkDisabled,true);assert.deepEqual(offline.networks,{});assert.equal(offline.pinnedExecutableReadOnly,true);assert.equal(offline.memory,6*1024**3);assert.equal(offline.memorySwap,offline.memory);assert.equal(offline.nanoCpus,2*10**9);
  const update=proof.updateDecisions;assert.equal(update.visualAcceptanceVersion,2);
  for(const key of ['liveConfigWatcherAdmission','enableCancelPreserved','enabledStable','enabledLatest','downgradeCancelPreserved','stayPinsCurrentVersion','switchLatestClearsPin','downgradeAllowsOlder','noPhantomTurn','exactParentDocumentSelection'])assert.equal(update[key],true,'Update decisions '+key);
  assert.deepEqual(update.samples.map(sample=>[sample.kind,sample.width]),[['downgrade',1100],['downgrade',680],['enable',1100],['enable',680]]);assert.equal(update.finalUser.autoUpdatesChannel,'latest');assert.equal(update.finalUser.minimumVersion,undefined);assert.equal(proof.user.autoUpdatesChannel,'latest');assert.equal(proof.user.minimumVersion,undefined);assert.equal((await json('.claude/.claude.json')).autoUpdates,true);
  for(const sample of update.samples){
   assert.match(sample.text,sample.kind==='enable'?/Enable with latest channel/:/Stay on current version \(2\.1\.302\) until stable catches up/);assert.equal(sample.readings.length,2);
   for(const [index,reading]of sample.readings.entries()){assert.equal(reading.index,index);assert.equal(reading.geometry.visible,true);assert.ok(reading.geometry.top>=reading.geometry.viewportTop-1);assert.ok(reading.geometry.bottom<=reading.geometry.viewportBottom+1);assert.equal(basename(reading.capture),`native-settings-updates-${sample.kind}-${sample.width}-${index}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(reading.capture)),basename(reading.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
  }

 }
 if(proof.remoteHomeEditor){
  const cloud=proof.remoteHomeEditor,fixture=await json('native-cloud-settings-fixture.json'),offline=await json('native-update-offline.json');
  assert.equal(fixture.initialMode,'forward');assert.equal(fixture.nativeFlagOverrides,false);assert.equal(offline.networkDisabled,true);assert.deepEqual(offline.networks,{});assert.equal(offline.pinnedExecutableReadOnly,true);assert.equal(offline.memory,6*1024**3);assert.equal(offline.memorySwap,offline.memory);assert.equal(offline.nanoCpus,2*10**9);
  for(const key of ['notNowPreserved','cancelPreserved','keepLocalPersisted','noPhantomTurn','nativeGatesUnchanged','noFalseSaved'])assert.equal(cloud[key],true,'Cloud settings '+key);
  if(cloud.outcome==='native-flag-refused')assert.match(cloud.resultText.replace(/\s+/g,' '),/Could not turn this on: forwarding settings to cloud sessions is not enabled for you right now/);
  assert.ok(['enabled','native-flag-refused'].includes(cloud.outcome));assert.equal(cloud.finalMode,cloud.outcome==='enabled'?'forward':'keep_local');assert.equal((await json('.claude/.claude.json')).remoteHomeSettingsMode,cloud.finalMode);
  assert.deepEqual(cloud.samples.map(sample=>[sample.width,sample.height]),[[1100,900],[680,600]]);
  for(const sample of cloud.samples){
   assert.match(sample.text.replace(/\s+/g,' '),/never sends hooks, environment variables, MCP servers, or plugins/);assert.match(sample.text,/encrypted at rest/);
   const lines=sample.readings.filter(row=>Number.isInteger(row.index)),options=sample.readings.filter(row=>row.option);
   assert.ok(lines.length>0&&lines.length<128);assert.equal(lines.map(row=>row.text).join(' ').replace(/\s+/g,' ').trim(),sample.text.replace(/\s+/g,' ').trim());assert.deepEqual(options.map(row=>row.option),['forward','keep_local','not_now']);
   for(const row of sample.readings){assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);}
   assert.ok(sample.captures.length>=3&&sample.captures.length<128);
   for(const capture of sample.captures){const bytes=await readFile(join(workspace,'electron-results',basename(dirname(capture)),basename(capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),sample.width);assert.equal(bytes.readUInt32BE(20),sample.height);}
  }
 }
 if(proof.updateEditor){
  const update=proof.updateEditor;for(const key of ['readOnly','cancelPreservesSettings','reopened','noPhantomTurn','exactParentDocumentSelection'])assert.equal(update[key],true,'Update '+key);
  assert.deepEqual(update.samples.map(sample=>sample.width),[1100,680]);
  for(const sample of update.samples){assert.match(sample.text,/Auto-updates are controlled by an environment variable and cannot be changed here\./);assert.match(sample.text,/Unset [\s\S]+ to re-enable auto-updates\./);assert.equal(sample.realWheel,true);assert.equal(sample.geometry.visible,true);assert.ok(sample.geometry.top>=sample.geometry.viewportTop-1);assert.ok(sample.geometry.bottom<=sample.geometry.viewportBottom+1);assert.equal(basename(sample.capture),`native-settings-updates-information-${sample.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(sample.capture)),basename(sample.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
 }
 if(proof.externalConsent){
  const consent=proof.externalConsent;
  assert.deepEqual(consent.securityNavigation.map(row=>[row.width,row.height]),[[1100,900],[680,600]]);for(const row of consent.securityNavigation){assert.equal(row.url,'https://code.claude.com/docs/en/security');assert.equal(row.returnedToConsent,true);assert.equal(row.sameNativeOwner,true);assert.equal(row.nativeNavigationStarted,true);assert.equal(row.navigation.url,row.url);assert.equal(row.navigation.isMainFrame,true);assert.ok(Number.isInteger(row.navigation.webContentsId)&&row.navigation.webContentsId>0);assert.equal(basename(row.capture),`native-consent-security-browser-${row.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(row.capture)),basename(row.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
  for(const key of ['approvedForLiveRequest','reopenedAfterDisable','noPhantomTurn','disabledBeforeResume','exactParentDocumentSelection','restartBoundaryVerified'])assert.equal(consent[key],true,'External consent '+key);
  const key=consent.approvedProject.projectKey;assert.ok(typeof key==='string'&&key.startsWith('/'));assert.equal(consent.disabledProject.projectKey,key);const persisted=await json('.claude/.claude.json');assert.equal(persisted.projects[key].hasClaudeMdExternalIncludesApproved,false);assert.equal(persisted.projects[key].hasClaudeMdExternalIncludesWarningShown,true);
  assert.equal(consent.approvedProject.hasClaudeMdExternalIncludesApproved,true);assert.equal(consent.disabledProject.hasClaudeMdExternalIncludesApproved,false);
  assert.deepEqual(consent.samples.map(sample=>sample.width),[1100,680]);
  for(const sample of consent.samples){assert.equal(sample.declined,true);assert.equal(sample.project.hasClaudeMdExternalIncludesApproved,false);assert.equal(sample.project.hasClaudeMdExternalIncludesWarningShown,true);assert.equal(sample.readings.length,4);for(const [index,reading]of sample.readings.entries()){assert.equal(reading.index,index);assert.equal(reading.realWheel,true);assert.equal(reading.geometry.visible,true);assert.ok(reading.geometry.top>=reading.geometry.viewportTop-1);assert.ok(reading.geometry.bottom<=reading.geometry.viewportBottom+1);assert.equal(basename(reading.capture),`native-settings-external-consent-${sample.width}-${index}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(reading.capture)),basename(reading.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}}
  const fixture=await json('external-consent-fixture.json');assert.equal(consent.marker,fixture.marker);assert.equal(consent.path,fixture.path);assert.ok(fixture.content.includes(fixture.marker));
  const payload=request=>JSON.stringify({system:request?.system,messages:request?.messages});
  // Launcher routes --print to seed and the interactive native CLI to agent.
  assert.equal(payload(calls.seed[0]).includes(fixture.marker),false,'Unapproved external instruction reached initial print request');
  assert.ok(payload(calls.seed[1]).includes(fixture.marker),'Approved external instruction missing from fresh print request');
  assert.ok(Number.isSafeInteger(consent.restartedNativePid)&&consent.restartedNativePid!==proof.boundNativePid);
  const approvedMessages=calls.seed[1].messages,disabledMessages=calls.seed.at(-1).messages;
  const previousIndexes=approvedMessages.flatMap((message,index)=>JSON.stringify(message).includes(fixture.marker)?[index]:[]);
  assert.ok(previousIndexes.length>0,'Approved instruction history absent');
  for(const index of previousIndexes)assert.deepEqual(disabledMessages[index],approvedMessages[index],'Approved historical instruction changed');
  const current=disabledMessages.slice(approvedMessages.length);
  assert.ok(current.length>0,'Disabled request added no new turn');
  assert.equal(JSON.stringify(current).includes(fixture.marker),false,'Disabled instruction injected into new request context');
  assert.equal(payload({system:calls.seed.at(-1).system,messages:disabledMessages.filter((_,index)=>!previousIndexes.includes(index))}).includes(fixture.marker),false,'External instruction appeared outside retained approved history');
  assert.ok(current.some(message=>message.role==='user'&&JSON.stringify(message.content).includes('Instructions no longer present: '+fixture.path)),'Original instruction-removal notice absent');
  assert.ok(payload(calls.seed.at(-1)).includes('Always respond in French.'),'French language missing from resumed print request');
  assert.equal(consent.disableRoutes.length,2);assert.ok(consent.disableRoutes.every(route=>['confirmation','disabled'].includes(route)));
 }
 if(proof.groupEditors){
  assert.deepEqual(proof.groupEditors.map(group=>group.key),['agentsView','notifChannel']);
  assert.ok(proof.groupEditors.some(group=>group.admitted&&group.changes.length>0),'No admitted grouped change');
  for(const group of proof.groupEditors){
   if(!group.admitted){assert.ok(['Original Config did not advertise this row','Original Config advertises the scalar row without a group opener'].includes(group.reason));continue;}
   assert.equal(group.reopened,true);assert.deepEqual(group.samples.map(sample=>sample.width),[1100,680]);
   for(const sample of group.samples){
    assert.equal(sample.readings.length,group.labels.length);
    for(const reading of sample.readings){assert.equal(reading.realWheel,true);assert.equal(reading.geometry.visible,true);assert.ok(reading.geometry.top>=reading.geometry.viewportTop-1);assert.ok(reading.geometry.bottom<=reading.geometry.viewportBottom+1);}
    assert.equal(basename(sample.capture),`native-settings-group-${group.key}-${sample.width}.png`);
    const bytes=await readFile(join(workspace,'electron-results',basename(dirname(sample.capture)),basename(sample.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
   }
   for(const change of group.changes){assert.notEqual(change.before,change.after);assert.ok([1100,680].includes(change.width));if(change.kind==='choice')assert.equal(change.global.preferredNotifChannel,change.after);else if(group.key==='notifChannel')assert.equal(change.global[change.label.includes('needs you')?'inputNeededNotifEnabled':'agentPushNotifEnabled'],change.after);else assert.ok(['leftArrowOpensAgents','defaultToAgentsView'].some(key=>change.global[key]===change.after));}
  }
 }
 if(proof.languageEditor)for(const key of ['cancelPreserved','emptyDefaultReset','trimmedReopen'])assert.equal(proof.languageEditor[key],true,'Language '+key);
 if(proof.modelEditor){const model=proof.modelEditor;for(const key of ['cancelPreserved','nativeSearchClosed','defaultReset','reopenedNativeSelection','noPhantomTurn'])assert.equal(model[key],true,'Model '+key);assert.match(model.selectedModel,/sonnet/i);assert.equal(proof.user.model,model.selectedModel);assert.ok(typeof model.selectedEffort==='string'&&model.selectedEffort.length>0);assert.deepEqual(model.samples.map(row=>row.width),[1100,680]);for(const row of model.samples){assert.ok(row.options.length>1);assert.notEqual(row.beforeEffort,row.afterEffort);assert.ok(row.draftEffort);assert.equal(row.interaction,row.width===680?'arrow':'button');assert.equal(row.realWheel,true);assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);assert.equal(basename(row.capture),`native-settings-model-details-${row.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(row.capture)),basename(row.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}}
 if(proof.themeEditor){for(const key of ['cancelRestoresPreview','previewPreservesSettings','lightCommitReopened','darkRestored','syntaxDisabledRestored'])assert.equal(proof.themeEditor[key],true,'Theme '+key);assert.equal(proof.user.theme,'dark');assert.equal(proof.user.syntaxHighlightingDisabled,false);assert.deepEqual(proof.themeEditor.samples.map(row=>row.width),[1100,680]);for(const row of proof.themeEditor.samples){assert.equal(row.previewChanges,true);assert.equal(row.structuredRows,4);assert.ok(row.surface?.contrast>=4.5,'Native Theme context contrast');assert.notEqual(row.surface.background,'rgba(0, 0, 0, 0)');assert.equal(row.realWheel,true);assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);assert.equal(basename(row.capture),`native-settings-theme-preview-${row.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(row.capture)),basename(row.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}}
 for(const key of proof.consentOnly?['retainedDraft']:['retainedDraft','reopenedValues','lockedControl'])assert.equal(proof[key],true,key);
 assert.equal(proof.captures.length,proof.consentOnly?2:4);
 for(const file of proof.captures){const bytes=await readFile(join(workspace,'electron-results',basename(dirname(file)),basename(file)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
 const frame=proof.nativeStatusRows===true?await verifyNativeDesktopStatus(workspace,proof):proof.desktopFrameTabs===true?await verifyNativeDesktopSettingsFrame(workspace,proof):undefined;
 const stats=proof.statsCompleteness?await verifyNativeStatsCompleteness(workspace,proof.statsCompleteness,proof.frameCaptures[0]):undefined;
 assert.equal(calls.seed.length,proof.externalConsent?.restartBoundaryVerified?3:2);assert.equal(calls.agent.length,1);
 if(proof.modelEditor){assert.match(calls.seed.at(-1).model,/sonnet/i);assert.match(calls.agent[0].model,/sonnet/i);assert.equal(calls.seed.at(-1).effort,proof.modelEditor.selectedEffort,'Live native model effort');assert.equal(calls.agent[0].effort,proof.modelEditor.selectedEffort,'Resumed native model effort');}
 assert.ok(calls.agent.some(call=>JSON.stringify(call.messages??[]).includes('Always respond in French.')),'Original language change did not reach the next native model request');
 if(proof.nativeSettingsEditors)assert.ok(calls.agent.some(call=>(call.messages??[]).some(message=>message.role==='system'&&JSON.stringify(message.content).includes('# Output Style: '+proof.outputStyleEditor.after.outputStyle))),'Original output style did not reach the recovered native model request');
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),preloads=await lines('user-preload-calls.jsonl');
 const expectedProcesses=proof.externalConsent?.restartBoundaryVerified?5:3;assert.equal(children.length,expectedProcesses);assert.equal(exits.length,expectedProcesses);
 if(proof.externalConsent){assert.equal(children[1].pid,proof.boundNativePid);assert.equal(children[3].pid,proof.externalConsent.restartedNativePid);for(const index of [0,2,4])assert.ok(children[index].args.includes('--print'));for(const index of [1,3])assert.equal(children[index].args.includes('--print'),false);}
 for(const child of children){assert.equal(exits.filter(exit=>exit.pid===child.pid&&[0,143].includes(exit.code)).length,1);assert.equal(preloads.filter(row=>row.pid===child.pid).length,1);}
 const prefixes=await lines('prefix-exits.jsonl');assert.ok(prefixes.length>0);assert.ok(prefixes.every(row=>row.args[0]==='--fixture-prefix'&&row.code===0));
 const prints=await lines('native-print-results.jsonl');assert.equal(prints.at(-1).sessionId,evidence.sessionId);
 return {...(proof.remoteHomeEditor?{nativeRemoteHomeSettings:proof.remoteHomeEditor}:{}),...(proof.updateDecisions?{nativeUpdateDecisions:proof.updateDecisions}:{}),...(proof.updateEditor?{nativeUpdateSettings:proof.updateEditor}:{}),...(proof.externalConsent?{nativeExternalConsent:{...proof.externalConsent,freshProcessInstructionEffect:true,disabledInstructionRemovalNotice:true,approvedHistoryRetained:true,liveEffectObserved:JSON.stringify({system:calls.agent[0]?.system,messages:calls.agent[0]?.messages}).includes(proof.externalConsent.marker)}}:{}),...(proof.groupEditors?{nativeGroupedSettings:proof.groupEditors}:{}),...(proof.modelEditor?{nativeModelEditor:{...proof.modelEditor,liveAndResumedModelEffect:true}}:{}),...(proof.themeEditor?{nativeThemeEditor:proof.themeEditor}:{}),...(proof.languageEditor?{nativeLanguageEditor:{...proof.languageEditor,modelEffectApplied:true,resumedModelEffectApplied:JSON.stringify({system:calls.seed.at(-1)?.system,messages:calls.seed.at(-1)?.messages}).includes('Always respond in French.'),scope:'Parent original Language input Cancel, empty default reset, trimmed French persistence/reopen, normal/compact controls and live native model instruction. Resumed print effect requires captured request evidence; see resumedModelEffectApplied. Other owner/IME/hook-refusal contexts remain separate.'}}:{}),...(frame?{desktopFrame:frame}:{}),...(stats?{richStats:stats}:{}),...(proof.nativeSettingsEditors?{nativeEditors:{outputStyle:proof.outputStyleEditor.after.outputStyle,styleModelEffectApplied:true,noteReopened:proof.outputStyleEditor.forms.noteReopened,numberReopened:proof.outputStyleEditor.forms.numberReopened,validationMessage:proof.outputStyleEditor.forms.validationMessage,captures:[...proof.outputStyleEditor.samples,...proof.outputStyleEditor.forms.samples].map(row=>basename(row.capture)),scope:'Parent Output Style selection/cancel/persistence/reopen and provided text/number form cancellation, exact Unicode reopen and native validation. Actual held cancellation, Agent and other editor contracts remain separate.'}}:{}),nativeConfigDesktopLanguageApplied:true,sessionId:evidence.sessionId,nativeProcesses:children.length,exitCodes:exits.map(row=>row.code),syntheticApiRequests:nativeHelloRequests+calls.seed.length+calls.agent.length,syntheticModelRequests:calls.seed.length+calls.agent.length,...nativeHelloRequests?{nativeHelloRequests}:{},realModelRequests:0,captures:proof.captures.map(file=>basename(file)),scope:proof.consentOnly?'Focused original external consent/link navigation, file-inclusion/removal effect, retained composing and same-session recovery. Scalar/language values are initial fixtures; no new scalar or Language editor acceptance. Original exit receipts only; no new post-exit PID liveness audit.':'Parent desktop booleans/choice/language, original file persistence and model effect, locked control, retained composing/reopen and same-session recovery. Original exit receipts only; no new post-exit PID liveness audit.'};
}

/** Native Status-only acceptance does not claim that unvisited tabs or Stats ran. */
export async function verifyNativeDesktopStatus(workspace,proof){
 assert.equal(proof.nativeStatusRows,true);assert.equal(proof.desktopFrameTabs,false);assert.equal(proof.nativeStatsDates,false);assert.equal(proof.statsCompleteness,undefined);
 assert.deepEqual(proof.statusSamples.map(row=>row.width),[1100,680]);assert.equal(proof.frameCaptures.length,2);
 const expected=new Set([1100,680].map(width=>'native-settings-desktop-status-'+width+'.png'));
 if(proof.nativeSettingsEditors){
  const editor=proof.outputStyleEditor;assert.equal(editor.forms.cancelPreserved,true);assert.equal(editor.forms.noteReopened,true);assert.equal(editor.forms.numberReopened,'3');assert.match(editor.forms.validationMessage,/between 1 and 9/);assert.deepEqual(editor.forms.samples.map(row=>row.width),[1100,680]);for(const row of editor.forms.samples){assert.equal(row.draft,editor.forms.noteDraft);assert.equal(basename(row.capture),`native-settings-note-form-${row.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(row.capture)),basename(row.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}assert.equal(editor.cancelPreserved,true);assert.equal(editor.reopenedNativeSelection,true);assert.notEqual(editor.after.outputStyle,editor.before.outputStyle);assert.equal(typeof editor.after.outputStyle,'string');assert.ok(editor.chosenLabel.length>0);assert.deepEqual(editor.samples.map(row=>row.width),[1100,680]);
  for(const row of editor.samples){assert.ok(row.options.length>1);assert.equal(row.realWheel,true);assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);assert.equal(basename(row.capture),`native-settings-output-style-${row.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(row.capture)),basename(row.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
 }

 for(const row of proof.statusSamples){assert.match(row.value,/user settings/i);assert.match(row.value,/project local settings/i);assert.match(row.value,/,\s+/);assert.equal(row.realWheel,true);assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);}
 if(proof.nativeStatusDiagnostics){for(const row of proof.statusSamples){assert.match(row.diagnostic.text,/Native installation exists but ~\/\.local\/bin is not in your PATH/);assert.equal(row.diagnostic.realWheel,true);assert.equal(row.diagnostic.geometry.visible,true);assert.ok(row.diagnostic.geometry.top>=row.diagnostic.geometry.viewportTop-1);assert.ok(row.diagnostic.geometry.bottom<=row.diagnostic.geometry.viewportBottom+1);}}
 if(proof.nativeStatusDiagnosticList){
  const reference=proof.statusSamples[0].diagnosticReadings.map(row=>row.text);assert.ok(reference.length>0&&reference.length<=128);
  for(const sample of proof.statusSamples){assert.deepEqual(sample.diagnosticReadings.map(row=>row.text),reference);for(const [index,row]of sample.diagnosticReadings.entries()){
   assert.equal(row.index,index);assert.equal(row.realWheel,true);assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);
   assert.equal(basename(row.capture),`native-settings-diagnostic-${index}-${sample.width}.png`);const bytes=await readFile(join(workspace,'electron-results',basename(dirname(row.capture)),basename(row.capture)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
  }}
 }
 for(const file of proof.frameCaptures){assert.ok(expected.delete(basename(file)));const bytes=await readFile(join(workspace,'electron-results',basename(dirname(file)),basename(file)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
 assert.equal(expected.size,0);return {tab:'Status',samples:proof.statusSamples,captures:proof.frameCaptures.map(file=>basename(file)),scope:'Original multi-source Status value and real normal/compact row reading. Conditional unlabeled warning admission, live status and other tabs retain separate acceptance.'};
}

/** The new frame journey supplements accepted scalar settings; it never retroactively claims old captures. */
export async function verifyNativeDesktopSettingsFrame(workspace,proof){
 assert.equal(proof.desktopFrameTabs,true);assert.equal(proof.nativeStatsDates,true);
 assert.equal(proof.frameCaptures.length,6);
 const expected=new Set(['status','usage','stats'].flatMap(tab=>[680,1100].map(width=>'native-settings-desktop-'+tab+'-'+width+'.png')));
 for(const file of proof.frameCaptures){
  assert.ok(expected.delete(basename(file)),'Unexpected or duplicate desktop frame capture');
  const bytes=await readFile(join(workspace,'electron-results',basename(dirname(file)),basename(file)));
  assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
 }
 assert.equal(expected.size,0);
 return {tabs:['Status','Config','Usage','Stats'],nativeStatsDates:true,captures:proof.frameCaptures.map(file=>basename(file)),scope:'Actual-app tab/Status version/Usage window/Stats model and native date checks, normal/compact captures and retained parent journey. Capture existence is not visual acceptance; richer Stats, conditional Usage and other original Settings contracts remain open.'};
}

/** Saved and live verification of native historical filtering and original clipboard bytes. */
export async function verifyNativeStatsCompleteness(workspace,proof,frameCapture){
 assert.deepEqual(proof.histories.map(row=>row.age),[2,12,45]);assert.equal(new Set(proof.histories.map(row=>row.id)).size,3);
 for(const row of proof.histories){assert.ok(row.tokens>0);assert.match(row.sha256,/^[a-f0-9]{64}$/);}
 assert.deepEqual(proof.ranges.map(row=>row.range),['all','7d','30d','all-restored']);
 for(const row of proof.ranges){const days=row.range==='7d'?7:row.range==='30d'?30:Infinity;const expected=proof.baselineTokens+proof.histories.filter(item=>item.age<days).reduce((sum,item)=>sum+item.tokens,0);assert.equal(row.expected,expected);assert.equal(row.observed,expected);}
 assert.deepEqual(proof.reading.map(row=>row.width),[1100,680]);for(const row of proof.reading){assert.equal(row.longest,true);assert.equal(row.modelTable,true);assert.equal(row.realWheel,true);assert.equal(row.historicalDate,proof.histories[2].date);}
 const captureRoot=join(workspace,'electron-results',basename(dirname(frameCapture)));
 const calendar=proof.captures.some(file=>basename(file).startsWith('native-rich-stats-calendar-'));
 const labels=calendar?['calendar','summary','insight','history','models']:['summary','insight','history','models'];
 assert.equal(proof.captures.length,labels.length*2);const expected=new Set(labels.flatMap(label=>[1100,680].map(width=>'native-rich-stats-'+label+'-'+width+'.png')));
 for(const file of proof.captures){assert.ok(expected.delete(basename(file)));const bytes=await readFile(join(captureRoot,basename(file)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}assert.equal(expected.size,0);
 const modelsExports=proof.exports.filter(row=>row.view==='Models');
 if(modelsExports.length){
  assert.deepEqual(proof.exports.map(row=>[row.view,row.width]),[['Overview',1100],['Overview',680],['Models',1100],['Models',680]]);
  for(const width of [1100,680])assert.notEqual(proof.exports.find(row=>row.view==='Overview'&&row.width===width).sha256,modelsExports.find(row=>row.width===width).sha256,'Models export must not reuse the Overview image');
 }else assert.deepEqual(proof.exports.map(row=>row.width),[1100,680]);
 for(const row of proof.exports){assert.ok(row.formats.includes('image/png'));const bytes=await readFile(join(captureRoot,row.file));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),row.size.width);assert.equal(bytes.readUInt32BE(20),row.size.height);assert.ok(row.size.width>0&&row.size.height>0);assert.equal(createHash('sha256').update(bytes).digest('hex'),row.sha256);}
 return {ranges:proof.ranges,exports:proof.exports,captures:proof.captures.map(file=>basename(file)),scope:'Owned multi-day transcript fixtures admitted by original Stats discovery; native all/7d/30d totals, real wheel summary/history reading and original clipboard PNGs. Byte receipts are not visual review or all original Settings/lifecycle acceptance.'};
}
