import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join,basename,dirname} from 'node:path';

/** Shared live/saved verification; never rerun the CLI to repair aggregate metadata. */
export async function verifyNativeDesktopSettings(workspace,evidence,calls){
 const json=async name=>JSON.parse(await readFile(join(workspace,name),'utf8'));
 const lines=async name=>(await readFile(join(workspace,name),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 const proof=await json('native-config-desktop-proof.json');
 for(const key of ['actualAppGui','nativeConfigDesktop','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 assert.equal(evidence.sessionId,evidence.finalSessionId);assert.equal(proof.sessionId,evidence.sessionId);
 assert.equal(proof.local.spinnerTipsEnabled,false);assert.equal(proof.local.prefersReducedMotion,true);
 assert.equal(proof.user.timeFormat,'24-hour');assert.equal(proof.user.language,'French');
 for(const key of ['retainedDraft','reopenedValues','lockedControl'])assert.equal(proof[key],true,key);
 assert.equal(proof.captures.length,4);
 for(const file of proof.captures){const bytes=await readFile(join(workspace,'electron-results',basename(dirname(file)),basename(file)));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
 assert.equal(calls.seed.length,2);assert.equal(calls.agent.length,1);
 assert.ok(calls.agent.some(call=>JSON.stringify(call.messages??[]).includes('Always respond in French.')),'Original language change did not reach the next native model request');
 const children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),preloads=await lines('user-preload-calls.jsonl');
 assert.equal(children.length,3);assert.equal(exits.length,3);
 for(const child of children){assert.equal(exits.filter(exit=>exit.pid===child.pid&&[0,143].includes(exit.code)).length,1);assert.equal(preloads.filter(row=>row.pid===child.pid).length,1);}
 const prefixes=await lines('prefix-exits.jsonl');assert.ok(prefixes.length>0);assert.ok(prefixes.every(row=>row.args[0]==='--fixture-prefix'&&row.code===0));
 const prints=await lines('native-print-results.jsonl');assert.equal(prints.at(-1).sessionId,evidence.sessionId);
 return {nativeConfigDesktopLanguageApplied:true,sessionId:evidence.sessionId,nativeProcesses:children.length,exitCodes:exits.map(row=>row.code),syntheticApiRequests:calls.seed.length+calls.agent.length,realModelRequests:0,captures:proof.captures.map(file=>basename(file)),scope:'Parent desktop booleans/choice/language, original file persistence and model effect, locked control, retained composing/reopen and same-session recovery. Original exit receipts only; no new post-exit PID liveness audit.'};
}
