import http from 'node:http';
import {join} from 'node:path';
/** Bounded private file-decision fixture; emits only literal operations inside its workspace. */
export async function startSyntheticFileModel(workspace,{requestDelayMs=0,longReview=false}={}){
 if(!Number.isInteger(requestDelayMs)||requestDelayMs<0||requestDelayMs>2000)throw Error('Invalid bounded request delay');
 const calls=[];let sequence=0;
 const server=http.createServer(async(req,res)=>{try{
  const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>2*1024*1024)throw Error('Request too large');chunks.push(chunk)}
  const body=JSON.parse(Buffer.concat(chunks).toString()||'{}');
  if(req.url?.includes('count_tokens')){res.writeHead(200,{'content-type':'application/json'});res.end('{"input_tokens":10}');return}
  if(!req.url?.startsWith('/v1/messages')||++sequence>18)throw Error('Unexpected request');
  const text=body.messages?.flatMap(message=>typeof message.content==='string'?[message.content]:message.content?.filter(block=>block.type==='text').map(block=>block.text)??[]).join('\n');
  const turn=Number(text?.match(/ResearchFileTurn[1-7]/g)?.at(-1)?.slice(-1));if(!turn)throw Error('Missing fixed file turn');
  const blocks=body.messages?.flatMap(message=>Array.isArray(message.content)?message.content:[])??[];
  const done=id=>blocks.some(block=>block.type==='tool_result'&&block.tool_use_id===id);
  const id='file_fixture_'+turn,readId='file_read_'+turn,isEdit=[3,5,7].includes(turn);
  let block;
  if(done(id))block={type:'text',text:'File fixture completed.'};
  else if(isEdit&&!done(readId))block={type:'tool_use',id:readId,name:'Read',input:{file_path:join(workspace,'file-fixture.txt')}};
  else block={type:'tool_use',id,name:isEdit?'Edit':'Write',input:isEdit?{file_path:join(workspace,'file-fixture.txt'),old_string:turn===3?'overwrite\n':'edited\n',new_string:turn===3?'edited\n':'Must not be applied\n'}:{file_path:join(workspace,'file-fixture.txt'),content:longReview&&turn===4?Array.from({length:160},(_,i)=>'Release checklist item '+(i+1)+': preserve existing behavior.').join('\n')+'\n':turn===1?'created\n':turn===2?'overwrite\n':turn===6?'X'.repeat(200001):'Must not be applied\n'}};
  calls.push({turn,response:block,messages:body.messages});
  if(requestDelayMs&&block.type==='tool_use')await new Promise(resolve=>setTimeout(resolve,requestDelayMs));
  const message={id:'msg_file_'+sequence,type:'message',role:'assistant',model:body.model,content:[block],stop_reason:block.type==='tool_use'?'tool_use':'end_turn',stop_sequence:null,usage:{input_tokens:10,output_tokens:10}};
  if(body.stream){res.writeHead(200,{'content-type':'text/event-stream'});const emit=(event,data)=>res.write('event: '+event+'\ndata: '+JSON.stringify(data)+'\n\n');emit('message_start',{type:'message_start',message:{...message,content:[],stop_reason:null,usage:{input_tokens:10,output_tokens:0}}});emit('content_block_start',{type:'content_block_start',index:0,content_block:block.type==='tool_use'?{...block,input:{}}:{type:'text',text:''}});emit('content_block_delta',{type:'content_block_delta',index:0,delta:block.type==='tool_use'?{type:'input_json_delta',partial_json:JSON.stringify(block.input)}:{type:'text_delta',text:block.text}});emit('content_block_stop',{type:'content_block_stop',index:0});emit('message_delta',{type:'message_delta',delta:{stop_reason:message.stop_reason,stop_sequence:null},usage:{output_tokens:10}});emit('message_stop',{type:'message_stop'});res.end()}
  else{res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(message))}
 }catch(error){calls.push({error:String(error)});if(!res.headersSent)res.writeHead(400);res.end('{}')}});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 return{url:'http://127.0.0.1:'+server.address().port,calls,close:()=>new Promise(resolve=>server.close(resolve))};
}
