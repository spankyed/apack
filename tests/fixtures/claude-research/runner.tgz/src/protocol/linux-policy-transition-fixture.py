"""Bounded root fixture for real managed-file transitions in an owned Linux container.

Install the ordinary managed-policy fixture first. A node-owned private control
folder supplies request-1.json (private), then request-2.json (managed). Neither
request can choose a path, command or policy content. Original native watchers
and consumers remain unmodified. The initial policy bytes/mode are restored.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pwd
import signal
import stat
import sys
import time

POLICY = Path('/etc/claude-code/managed-settings.json')
MANAGED = {'allowManagedHooksOnly': True, 'statusLine': {'type': 'command', 'command': "/usr/bin/printf 'Managed OS policy ready\\nManaged source has priority\\n'"}}


def regular(path):
    value = path.lstat()
    if not stat.S_ISREG(value.st_mode):
        raise ValueError('Fixture files must be regular files')
    return value


def write_new(path, value, mode=0o600):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, 'wb') as out:
        out.write(value)


def replace_policy(value, expected):
    current = regular(POLICY)
    if current.st_uid != 0 or POLICY.read_bytes() != expected:
        raise ValueError('Managed policy changed outside this fixture')
    # Match a normal atomic settings-file save; do not call native cache setters.
    temporary = POLICY.with_name('managed-settings.transition-' + str(os.getpid()))
    write_new(temporary, value, 0o644)
    try:
        os.replace(temporary, POLICY)
    finally:
        if temporary.exists():
            temporary.unlink()
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('control', type=Path)
    parser.add_argument('--seconds', type=int, default=180)
    args = parser.parse_args()
    if sys.platform != 'linux' or not Path('/.dockerenv').is_file() or os.geteuid() != 0:
        raise ValueError('Only root in the explicitly owned Linux container may run this fixture')
    if not 1 <= args.seconds <= 300:
        raise ValueError('Fixture lifetime must be 1..300 seconds')
    control = args.control
    base = Path('/work/.claude-research')
    if not control.is_absolute() or control.parent != base or not control.name.startswith('policy-transition-'):
        raise ValueError('Use a fresh direct child policy-transition-* under the owned research directory')
    if base.resolve() != base or regular(POLICY).st_uid != 0:
        raise ValueError('Unexpected fixture ownership or redirected research directory')
    initial = POLICY.read_bytes()
    if json.loads(initial) != MANAGED or stat.S_IMODE(regular(POLICY).st_mode) != 0o644:
        raise ValueError('Install the exact ordinary managed policy fixture first')
    account = pwd.getpwnam('node')
    control.mkdir(mode=0o700)
    os.chown(control, account.pw_uid, account.pw_gid)
    def stop(_signal, _frame):
        raise SystemExit('Policy transition fixture stopped')
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    current = initial
    deadline = time.monotonic() + args.seconds
    try:
        write_new(control / 'ready.json', json.dumps({'pid': os.getpid(), 'path': str(POLICY), 'initialSha256': hashlib.sha256(initial).hexdigest()}).encode(), 0o644)
        for sequence, mode in [(1, 'private'), (2, 'managed')]:
            request = control / ('request-' + str(sequence) + '.json')
            while not request.exists():
                if (control / 'finish').exists():
                    return
                if time.monotonic() >= deadline:
                    raise TimeoutError('Bounded policy transition request wait expired')
                time.sleep(0.05)
            regular(request)
            if request.stat().st_size > 256 or json.loads(request.read_bytes()) != {'sequence': sequence, 'mode': mode}:
                raise ValueError('Only the fixed private then managed transition is accepted')
            value = (json.dumps({} if mode == 'private' else MANAGED) + '\n').encode()
            current = replace_policy(value, current)
            receipt = {'sequence': sequence, 'mode': mode, 'path': str(POLICY), 'uid': POLICY.stat().st_uid, 'fileMode': stat.S_IMODE(POLICY.stat().st_mode), 'sha256': hashlib.sha256(value).hexdigest(), 'at': time.time()}
            write_new(control / ('receipt-' + str(sequence) + '.json'), json.dumps(receipt).encode(), 0o644)
        while not (control / 'finish').exists():
            if time.monotonic() >= deadline:
                raise TimeoutError('Bounded policy transition completion wait expired')
            time.sleep(0.05)
    finally:
        replace_policy(initial, current)
        write_new(control / 'restored.json', json.dumps({'sha256': hashlib.sha256(initial).hexdigest(), 'path': str(POLICY)}).encode(), 0o644)


if __name__ == '__main__':
    main()
