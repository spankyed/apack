"""Bounded root fixture for real managed-file transitions in an owned Linux container.

Install the ordinary managed-policy fixture first. A node-owned private control
folder supplies the two fixed requests for the selected profile. Neither
request can choose a path, command or policy content. Original native watchers
and consumers remain unmodified. The initial policy bytes/mode are restored.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import signal
import stat
import sys
import time

POLICY = Path('/etc/claude-code/managed-settings.json')
MANAGED = {'allowManagedHooksOnly': True, 'statusLine': {'type': 'command', 'command': "/usr/bin/printf 'Managed OS policy ready\\nManaged source has priority\\n'"}}
MANAGED_MCP = {'allowManagedMcpServersOnly': True, 'allowedMcpServers': [
    {'serverName': name} for name in ('managed-review', 'user-denied-review')]}


def regular(path):
    value = path.lstat()
    if not stat.S_ISREG(value.st_mode):
        raise ValueError('Fixture files must be regular files')
    return value


def write_new(path, value, mode=0o600):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, 'wb') as out:
        out.write(value)


def replace_policy(value, expected):
    current = regular(POLICY)
    if current.st_uid != 0 or POLICY.read_bytes() != expected:
        raise ValueError('Managed policy changed outside this fixture')
    # Match a normal atomic settings-file save; do not call native cache setters.
    temporary = POLICY.with_name('managed-settings.transition-' + str(os.getpid()))
    write_new(temporary, value, 0o644)
    try:
        os.replace(temporary, POLICY)
    finally:
        if temporary.exists():
            temporary.unlink()
    return value


def write_policy_in_place(value, expected):
    # This profile exercises ordinary in-place saves on the isolated system-policy mount.
    if not any(line.split()[4] == str(POLICY.parent) and ' - tmpfs ' in line
               for line in Path('/proc/self/mountinfo').read_text().splitlines()):
        raise ValueError('Managed-rule transitions require a disposable system-policy mount')
    fd = os.open(POLICY, os.O_RDWR | os.O_NOFOLLOW)
    with os.fdopen(fd, 'r+b') as current:
        info = os.fstat(current.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or current.read(len(expected) + 1) != expected:
            raise ValueError('Managed rule policy changed outside the fixture')
        current.seek(0)
        current.write(value)
        current.truncate()
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('control', type=Path)
    parser.add_argument('--seconds', type=int, default=180)
    parser.add_argument('--profile', choices=['main', 'background-formatter', 'permission-restriction', 'mcp-allowlist', 'channel-permission', 'managed-rule-sources'], default='main')
    parser.add_argument('--mcp-reallow', action='store_true')
    parser.add_argument('--managed-rule-workspace', type=Path)
    parser.add_argument('--restore-private-rules', action='store_true')
    args = parser.parse_args()
    if sys.platform != 'linux' or not Path('/.dockerenv').is_file() or os.geteuid() != 0:
        raise ValueError('Only root in the explicitly owned Linux container may run this fixture')
    if args.mcp_reallow and args.profile != 'mcp-allowlist':
        raise ValueError('Reallow applies only to the owned MCP allowlist')
    if args.restore_private_rules and args.profile != 'managed-rule-sources':
        raise ValueError('Restoring private rules requires the owned managed-rule profile')
    max_seconds = 570 if args.mcp_reallow else 510 if args.profile == 'mcp-allowlist' else 300
    if not 1 <= args.seconds <= max_seconds:
        raise ValueError(f'Fixture lifetime must be 1..{max_seconds} seconds for {args.profile}')
    if bool(args.managed_rule_workspace) != (args.profile == 'managed-rule-sources'):
        raise ValueError('Only the managed-rule profile may specify its owned workspace')
    control = args.control
    base = Path('/work/.claude-research')
    if not control.is_absolute() or control.parent != base or not control.name.startswith('policy-transition-'):
        raise ValueError('Use a fresh direct child policy-transition-* under the owned research directory')
    if base.resolve() != base or regular(POLICY).st_uid != 0:
        raise ValueError('Unexpected fixture ownership or redirected research directory')
    initial = POLICY.read_bytes()
    permission_restriction = {'permissions': {'disableBypassPermissionsMode': 'disable'}}
    if args.profile == 'main':
        expected_initial = MANAGED
        transitions = [(1, 'private', {}), (2, 'managed', MANAGED)]
    elif args.profile == 'background-formatter':
        expected_initial = {}
        transitions = [(1, 'restricted', {'disableAllHooks': True}), (2, 'restored', {})]
    elif args.profile == 'channel-permission':
        expected_initial = {'channelsEnabled': True}
        transitions = [(1, 'restricted', {'channelsEnabled': False})]
    elif args.profile == 'managed-rule-sources':
        workspace = args.managed_rule_workspace
        if (workspace.parent != base or workspace.resolve() != workspace
                or not re.fullmatch(r'apack-terminal-owner-app-command[0-9]+', workspace.name)
                or not workspace.is_dir() or workspace.stat().st_uid != 1000):
            raise ValueError('Expected the private owned desktop profile')
        managed = {'permissions': {'ask': ['Read(/' + str(workspace / 'project/managed-checklist.md') + ')']}}
        expected_initial = {'allowManagedPermissionRulesOnly': True, **managed}
        transitions = [(1, 'private-rules-enabled', managed), (2, 'managed-only', expected_initial)]
        if args.restore_private_rules:
            transitions.append((3, 'private-rules-enabled', managed))
    elif args.profile == 'mcp-allowlist':
        expected_initial = MANAGED_MCP
        transitions = [(1, 'unrestricted', {}), (2, 'restricted', MANAGED_MCP)]
        if args.mcp_reallow:
            transitions.append((3, 'unrestricted', {}))
    else:
        expected_initial = permission_restriction
        transitions = [(1, 'unrestricted', {}), (2, 'restricted', permission_restriction)]
    if json.loads(initial) != expected_initial or stat.S_IMODE(regular(POLICY).st_mode) != 0o644:
        raise ValueError('Install the exact initial managed policy for the selected profile')
    account = pwd.getpwnam('node')
    control.mkdir(mode=0o700)
    os.chown(control, account.pw_uid, account.pw_gid)
    def stop(_signal, _frame):
        raise SystemExit('Policy transition fixture stopped')
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    current = initial
    update_policy = write_policy_in_place if args.managed_rule_workspace else replace_policy
    deadline = time.monotonic() + args.seconds
    try:
        write_new(control / 'ready.json', json.dumps({'pid': os.getpid(), 'path': str(POLICY), 'initialSha256': hashlib.sha256(initial).hexdigest(), 'profile': args.profile}).encode(), 0o644)
        for sequence, mode, policy in transitions:
            request = control / ('request-' + str(sequence) + '.json')
            while not request.exists():
                if (control / 'finish').exists():
                    return
                if time.monotonic() >= deadline:
                    raise TimeoutError('Bounded policy transition request wait expired')
                time.sleep(0.05)
            regular(request)
            if request.stat().st_size > 256 or json.loads(request.read_bytes()) != {'sequence': sequence, 'mode': mode}:
                raise ValueError('Only the fixed profile transitions are accepted')
            value = (json.dumps(policy) + '\n').encode()
            current = update_policy(value, current)
            receipt = {'sequence': sequence, 'mode': mode, 'path': str(POLICY), 'uid': POLICY.stat().st_uid, 'fileMode': stat.S_IMODE(POLICY.stat().st_mode), 'sha256': hashlib.sha256(value).hexdigest(), 'at': time.time()}
            write_new(control / ('receipt-' + str(sequence) + '.json'), json.dumps(receipt).encode(), 0o644)
        while not (control / 'finish').exists():
            if time.monotonic() >= deadline:
                raise TimeoutError('Bounded policy transition completion wait expired')
            time.sleep(0.05)
    finally:
        update_policy(initial, current)
        write_new(control / 'restored.json', json.dumps({'sha256': hashlib.sha256(initial).hexdigest(), 'path': str(POLICY)}).encode(), 0o644)


if __name__ == '__main__':
    main()
