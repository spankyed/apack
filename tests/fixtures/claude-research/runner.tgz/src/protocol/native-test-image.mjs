import { deflateSync } from 'node:zlib';

function chunk(name,data){
    const body=Buffer.concat([Buffer.from(name),data]);let crc=0xffffffff;
    for(const byte of body){crc^=byte;for(let bit=0;bit<8;bit++)crc=crc&1?(crc>>>1)^0xedb88320:crc>>>1;}
    const head=Buffer.alloc(4),tail=Buffer.alloc(4);head.writeUInt32BE(data.length);tail.writeUInt32BE((crc^0xffffffff)>>>0);
    return Buffer.concat([head,body,tail]);
}

/** Authored one-pixel PNG for native media fixtures; no clipboard or external image dependency. */
export function createNativeTestImage(rgba = [255, 0, 0, 255]) {
  if (!Array.isArray(rgba) || rgba.length !== 4 || rgba.some(value => !Number.isInteger(value) || value < 0 || value > 255)) throw new Error('Expected four RGBA bytes');
  const header=Buffer.alloc(13);header.writeUInt32BE(1);header.writeUInt32BE(1,4);header[8]=8;header[9]=6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(Buffer.from([0,...rgba]))),chunk('IEND',Buffer.alloc(0))]);
}

/** Fixed deterministic noisy PNG, large enough to exercise transport beyond the UI tree budget. */
export function createNativeLargeTestImage(){
 const width=512,height=256,stride=width*4+1,pixels=Buffer.alloc(stride*height);let state=0x302;
 for(let y=0;y<height;y++)for(let x=1;x<stride;x++){state^=state<<13;state^=state>>>17;state^=state<<5;pixels[y*stride+x]=state&255;}
 const header=Buffer.alloc(13);header.writeUInt32BE(width);header.writeUInt32BE(height,4);header[8]=8;header[9]=6;
 return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(pixels)),chunk('IEND',Buffer.alloc(0))]);
}
