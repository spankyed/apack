import assert from 'node:assert/strict';
import { stripVTControlCharacters } from 'node:util';
import { mkdtemp, mkdir, writeFile, readFile, copyFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { record } from './record.mjs';
import { hash } from '../artifacts/runs.mjs';
import { existsSync, writeFileSync } from 'node:fs';
import { startSyntheticModel } from './synthetic-model.mjs';

const targetSha256 = '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37';
export async function probeNativeTheme(executable, workspaceParent, output, apackCheckout) {
  assert.equal(hash(await readFile(executable)), targetSha256);
  await mkdir(workspaceParent, { recursive: true });
  const workspace = await mkdtemp(join(workspaceParent, 'native-theme-'));
  const largeDocuments=process.env.CLAUDE_RESEARCH_LARGE_DOCUMENTS==='1';
  const largeCode=Array.from({length:700},(_,index)=>`export const migration${index+1} = { from: ${index}, to: ${index+1}, guide: "Keep the upgrade example" };`).join('\n');
  const largeMarkdown=Array.from({length:180},(_,index)=>`## Migration ${index+1}\n\nReview the compatibility notes before deployment. Keep the upgrade example and rollback instructions with the release.\n\n- Preserve existing settings.\n- Verify the migrated workspace.\n`).join('\n');
  const capabilityOverrides={};
  for(const name of ['FORCE_COLOR','FORCE_HYPERLINK','NO_COLOR']){const value=process.env['CLAUDE_RESEARCH_'+name];if(value!==undefined){assert.ok(value.length<=32,'Capability override too long');capabilityOverrides[name]=value;}}
  const config = join(workspace, '.claude'), themes = join(config, 'themes');
  await mkdir(themes, { recursive: true });
  const themePath = join(themes, 'research.json'), reportPath = join(workspace, 'native-theme.json');
  const fixture = { name: 'Research', base: 'light', overrides: { text: '#123456', success: 'rgb(17,34,51)', warning: 'url(invalid)', unknownKey: '#ffffff' } };
  await writeFile(themePath, JSON.stringify(fixture));
  const preload = join(workspace, 'theme.mjs');
  const trigger = join(workspace, 'initialized');
  const adapter=apackCheckout?await readFile(join(apackCheckout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-ui-runtime.ts'),'utf8'):undefined;
  const themeAdapter=apackCheckout?await readFile(join(apackCheckout,'packages/default-setup/src/features/code/be/services/claude-code/native-theme-runtime.ts'),'utf8'):undefined;
  const themeHelper=themeAdapter?.slice(themeAdapter.indexOf('String.raw`')+11,themeAdapter.lastIndexOf('`'))??'';
  const themeEnd=adapter?.indexOf('let nativeThemeSnapshot,')??-1;
  if(adapter)assert.ok(adapter.indexOf('function nativeThemeProvider(')>=0&&themeEnd>0,'Theme helper boundaries changed');
  const helper=adapter?adapter.slice(adapter.indexOf('function nativeThemeProvider('),themeEnd).replace('${claudeNativeThemeRuntime}',themeHelper):'';
  const documentAdapter=apackCheckout?await readFile(join(apackCheckout,'packages/default-setup/src/features/code/be/services/claude-code/terminal-document-runtime.ts'),'utf8'):undefined;
  const documentCodec=apackCheckout?await import(pathToFileURL(join(apackCheckout,'packages/default-setup/src/features/code/common/native-document-codec.ts')).href):undefined;
  const documentHelper=(documentAdapter?.slice(documentAdapter.indexOf('String.raw`')+11,documentAdapter.lastIndexOf('`'))??'').replace('${encodeClaudeDocument.toString()}',documentCodec?.encodeClaudeDocument.toString()??'');
  const source = `${helper}\n${documentHelper}\n${documentCodec?'const decodeNativeDocument = '+documentCodec.decodeClaudeDocument.toString()+';':''}\nimport {writeFileSync,existsSync} from 'node:fs';
async function probe(){
const report={capabilities:{forceColor:process.env.FORCE_COLOR??null,forceHyperlink:process.env.FORCE_HYPERLINK??null,noColor:process.env.NO_COLOR??null}};
try {
 report.capabilities.hyperlinks=(await import('/$bunfs/root/chunk-a1nxqq6q.js')).EE();
 const palette=await import('/$bunfs/root/chunk-xk1dqth2.js');
 const resolver=await import('/$bunfs/root/chunk-4z4q4qvr.js');
 const themes=await import('/$bunfs/root/chunk-5feck2gp.js');
 const preferences=await import('/$bunfs/root/chunk-gnpc8ecg.js');
 report.setting=preferences.lEn();
 report.dark=resolver.UKe('dark');report.light=resolver.UKe('light');
 report.loaded=await themes.ETt();
 report.custom=resolver.UKe('custom:research');
 report.invalidOverrideRetained=report.custom.warning===report.light.warning;
 report.unknownKeyPresent=Object.hasOwn(report.custom,'unknownKey');
 writeFileSync(${JSON.stringify(themePath)},JSON.stringify({name:'Research',base:'dark',overrides:{text:'#654321'}}));
 report.reloaded=await themes.ETt();report.changed=resolver.UKe('custom:research');
 report.originalMerge=palette.nen(palette.gj('light'),{text:'#123456',warning:'url(invalid)',unknownKey:'#fff'});
 const ink=await import('/$bunfs/root/chunk-tdpa6qc1.js'),roots=await import('/$bunfs/root/chunk-pg10s5g1.js'),jsx=await import('/$bunfs/root/chunk-4hec5rn1.js');
 const {PassThrough}=await import('node:stream');const output=new PassThrough(),input=new PassThrough();output.on('data',()=>{});output.columns=100;output.rows=30;output.isTTY=false;input.isTTY=false;
 let captured,root;
 const wait=async(predicate)=>{const deadline=Date.now()+2500;while(!predicate()){if(Date.now()>deadline)throw Error('Mounted theme observation timed out');await new Promise(resolve=>setTimeout(resolve,10));}};
 function Capture(){captured={palette:preferences.ew(),preview:preferences.cEn(),custom:preferences.y_e()};return null;}
 function committed(){const current=roots.ai().get(output)?.container?.current;if(!current)throw Error('Original Ink committed root missing');const pending=[current],seen=new Set();while(pending.length){const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('Theme provider traversal exceeded bound');seen.add(fiber);if(fiber.type===preferences.dEn){const value=fiber.child?.memoizedProps?.value;if(!value?.resolvedTheme||typeof value.themeSetting!=='string')throw Error('Original theme provider contract changed');return value.resolvedTheme;}if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);}throw Error('Original theme provider missing');}
 try{
  root=await ink.fce({stdout:output,stdin:input,stderr:output,exitOnCtrlC:false,patchConsole:false});root.render(jsx.e(Capture,{}));await wait(()=>captured!==undefined);
  const before=preferences.lEn();report.mounted={before,initial:committed()};
  captured.preview.setPreviewTheme('light');await wait(()=>captured.palette.text===report.light.text);report.mounted.preview=committed();
  captured.custom.setPreviewOverrides({text:'#abcdef',success:'#fedcba'});await wait(()=>captured.palette.text==='#abcdef');report.mounted.overrides=committed();
 ${apackCheckout?"report.adapterPalette=nativeThemePalette({themeRoots:roots,themePreferences:preferences},output);report.drawing=nativeThemeTree({themeRoots:{ai:()=>new Map([[process.stdout,roots.ai().get(output)]])},themePreferences:preferences},{type:'Box',props:{backgroundColor:'inverseText'},children:[{type:'Text',props:{color:'success'},children:['Original themed draw']}]});":''}
 ${apackCheckout?`const docRendering=await import('/$bunfs/root/chunk-hz2qqf17.js'),documentDefaults=await import('/$bunfs/root/chunk-pbm0yhpt.js'),appProvider=await import('/$bunfs/root/chunk-002p0hd2.js'),staticRender=await import('/$bunfs/root/chunk-mn4kxp8g.js'),session=await import('/$bunfs/root/chunk-hdxpvbx1.js');
  const n={themeRoots:{ai:()=>new Map([[process.stdout,roots.ai().get(output)]])},themePreferences:preferences,documentRendering:docRendering,documentDefaults,appProvider,staticRender,jsx,questionOptions:session};
  const code={type:'Code',props:{source:'const message = "native";\\nconsole.log(message);',language:'javascript',startLine:7}},diff={type:'Code',props:{source:'@@ -1 +1 @@\\n-const value = 1;\\n+const value = 2;',language:'javascript',format:'diff'}};
  const rootsBefore=roots.ai().size;
  report.documents=await nativeDocumentTree(n,{type:'Box',children:[code,diff]},{columns:60});
  report.documentSourcePreserved=code.props.source===report.documents.children[0].props.source&&diff.props.source===report.documents.children[1].props.source;
  report.documentRootsBefore=rootsBefore;report.documentRootsAfter=roots.ai().size;
  const exportStates=[];n.jsx={e:(type,props)=>{if(type===appProvider.d_)exportStates.push({syntaxHighlightingDisabled:props.initialState.settings.syntaxHighlightingDisabled,tasks:Object.keys(props.initialState.tasks)});return jsx.e(type,props);}};
  n.runtime={ey:()=>({toolContext:()=>({getAppState:()=>({settings:{syntaxHighlightingDisabled:true},tasks:{live:'must not copy'}})})})};
  report.disabledDocuments=await nativeDocumentTree(n,{type:'Box',children:[code,diff]},{columns:60});report.documentExportStates=exportStates;
  report.documentDisabledRootsAfter=roots.ai().size;
  const markdownText=['# Native Markdown','', 'Before **bold** and [callback](https://example.com/native-markdown).','', '\x60\x60\x60javascript', 'const markdownValue = "native";', '\x60\x60\x60', '', '> Quoted text', '', '| Name | Value |', '| --- | --- |', '| Item | 42 |'].join('\\n');
  async function renderMarkdown(disabled){
   const defaults=documentDefaults.$Et(),theme=nativeThemeProvider(n);
   return staticRender.v6e(jsx.e(appProvider.d_,{session:session.j(),keybindings:false,initialState:{...defaults,tasks:{},taskDecorations:{},settings:{...defaults.settings,syntaxHighlightingDisabled:disabled}},children:jsx.e(theme.type,{value:theme.value,children:jsx.e(docRendering.$d.BodyColumns.Provider,{value:60,children:jsx.e(docRendering.$d.MarkdownBlock,{text:markdownText})})})}),{columns:60});
  }
  report.markdown={source:markdownText,enabled:await renderMarkdown(false),disabled:await renderMarkdown(true),rootsAfter:roots.ai().size};


  report.documentTextTheme=nativeThemeTree(n,{type:'Box',children:[{type:'Link',props:{href:'https://example.com',label:'Native link'}},{type:'Markdown',props:{text:'**Native document**'}},code]});
  ${largeDocuments?`n.jsx=jsx;n.runtime={ey:()=>({toolContext:()=>({getAppState:()=>({settings:{syntaxHighlightingDisabled:false}})})})};report.largeDocuments=[];
  for(const [kind,source] of [['Code',${JSON.stringify(largeCode)}],['Markdown',${JSON.stringify(largeMarkdown)}]]){
   const props=kind==='Code'?{source,language:'javascript',startLine:1}:{text:source};
   const defaults=documentDefaults.$Et(),theme=nativeThemeProvider(n),started=Date.now();
   const text=await staticRender.v6e(jsx.e(appProvider.d_,{session:session.j(),keybindings:false,initialState:{...defaults,tasks:{},taskDecorations:{},settings:{...defaults.settings,syntaxHighlightingDisabled:false}},children:jsx.e(theme.type,{value:theme.value,children:jsx.e(docRendering.$d.BodyColumns.Provider,{value:80,children:jsx.e(kind==='Code'?docRendering.$d.CodeBlock:docRendering.$d.MarkdownBlock,props)})})}),{columns:80});
   const annotation=kind==='Code'?'_apackCodeAnsi':'_apackMarkdownAnsi',adapted=await nativeDocumentTree(n,{type:kind,props},{columns:80});
   report.largeDocuments.push({kind,sourceLength:source.length,sourceBytes:Buffer.byteLength(source),drawLength:text.length,drawBytes:Buffer.byteLength(text),wireBytes:Buffer.byteLength(JSON.stringify({type:kind,props:{...props,[annotation]:text}})),durationMs:Date.now()-started,adapterNative:typeof adapted.props[annotation]==='string'||!!adapted.props._apackDocumentPacked,packed:!!adapted.props._apackDocumentPacked,adapterWireBytes:Buffer.byteLength(JSON.stringify(adapted)),lossless:(adapted.props._apackDocumentPacked?decodeNativeDocument(adapted.props._apackDocumentPacked):adapted.props[annotation])===text,sourcePreserved:(kind==='Code'?adapted.props.source:adapted.props.text)===source,first:text.slice(0,250),last:text.slice(-250)});
  }
  const combined=await nativeDocumentTree(n,{type:'Box',children:[{type:'Code',props:{source:${JSON.stringify(largeCode)},language:'javascript',startLine:1}},{type:'Markdown',props:{text:${JSON.stringify(largeMarkdown)}}}]},{columns:80});
  report.largeCombined={native:combined.children.map(node=>!!node.props._apackDocumentPacked||typeof node.props._apackCodeAnsi==='string'||typeof node.props._apackMarkdownAnsi==='string'),wireBytes:Buffer.byteLength(JSON.stringify(nativeThemeTree(n,combined)))};`:''}

 `:''}
  captured.custom.setPreviewOverrides(undefined);captured.preview.cancelPreview();await wait(()=>captured.palette.text===report.mounted.initial.text);report.mounted.cancelled=committed();report.mounted.after=preferences.lEn();
 }finally{root?.unmount();input.destroy();output.destroy();}

} catch(error) { report.error=String(error); }
writeFileSync(${JSON.stringify(reportPath)},JSON.stringify(report,null,2));
}
let started=false;const timer=setInterval(()=>{if(started||!existsSync(${JSON.stringify(trigger)}))return;started=true;clearInterval(timer);probe();},25);timer.unref();
`;
  await writeFile(preload, source);
  const model = await startSyntheticModel(workspace,'TextOnly');
  let buffer='',observation;
  let run;
  try {
    run = await record({ executable, args: ['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--tools','','--strict-mcp-config','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})], cwd: workspace, output, timeoutMs: 15000,
      env: { HOME: workspace, CLAUDE_CONFIG_DIR: config, PATH: '/usr/bin:/bin', DISABLE_AUTOUPDATER: '1',
        CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1', ANTHROPIC_BASE_URL:model.url, BUN_OPTIONS: '--preload=' + preload,
        ...(process.env.CLAUDE_RESEARCH_MARKDOWN_CAPABILITIES==='1'?{FORCE_COLOR:'3',FORCE_HYPERLINK:'1'}:{}),...capabilityOverrides },
      input:[JSON.stringify({type:'control_request',request_id:'theme-init',request:{subtype:'initialize',hooks:{}}})+'\n'],
      onStdout(bytes,transport){
        buffer+=bytes;
        while(buffer.includes('\n')){
          const at=buffer.indexOf('\n'),line=buffer.slice(0,at);buffer=buffer.slice(at+1);let row;try{row=JSON.parse(line)}catch{continue}
          if(row.type==='control_response'&&row.response.request_id==='theme-init'&&!observation){
            writeFileSync(trigger,'ready');
            observation=(async()=>{const deadline=Date.now()+10000;while(!existsSync(reportPath)){if(Date.now()>deadline){transport.stop('theme-observation-timeout');return}await new Promise(resolve=>setTimeout(resolve,25))}transport.closeInput()})();
          }
        }
      }
    });
    if(observation)await observation;
    assert.equal(model.calls.length,0);
  } finally { await model.close(); }
  const report = JSON.parse(await readFile(reportPath, 'utf8'));
  await copyFile(preload, join(run.directory, 'authored-theme-preload.mjs'));
  await copyFile(reportPath, join(run.directory, 'native-theme.json'));
  const evidence = { targetSha256, authoredPreloadSha256: hash(Buffer.from(source)), ...(adapter?{authoredAdapterSha256:hash(Buffer.from(adapter))}:{}),...(documentAdapter?{authoredDocumentAdapterSha256:hash(Buffer.from(documentAdapter))}:{}), report,
    importsEmbeddedNativeModules: true, recoveredSourceExecuted: false, modelRequests: 0,
    markdownCapabilityOverride: process.env.CLAUDE_RESEARCH_MARKDOWN_CAPABILITIES==='1', capabilityOverrides,
    qualification: 'Original persisted/custom resolver and explicit reload plus an original mounted theme provider on isolated streams; preview/override/cancel read through its committed original fiber. No actual app, watcher or print-owner feature acceptance.' };
  await writeFile(join(run.directory, 'integration.json'), JSON.stringify(evidence, null, 2) + '\n');
  assert.equal(run.status, 'complete'); assert.equal(report.error, undefined);
  assert.equal(report.custom.text, '#123456'); assert.equal(report.custom.success, 'rgb(17,34,51)');
  assert.equal(report.invalidOverrideRetained, true); assert.equal(report.unknownKeyPresent, false);
  if(largeDocuments&&process.env.CLAUDE_RESEARCH_LARGE_DOCUMENTS_ACCEPT==='1'){assert.ok(report.largeDocuments.every(document=>document.adapterNative&&document.lossless&&document.sourcePreserved));assert.ok(report.largeCombined.native.every(Boolean));assert.ok(report.largeCombined.wireBytes<=262144);}
  if(largeDocuments){assert.equal(report.largeDocuments.length,2);for(const document of report.largeDocuments)assert.ok(document.sourceLength>32768);assert.ok(report.largeDocuments.find(document=>document.kind==='Code').drawLength>65536);}
  assert.equal(report.changed.text, '#654321'); assert.equal(report.changed.success, report.dark.success);
  assert.equal(report.originalMerge.text, '#123456');
  assert.equal(report.mounted.preview.text,report.light.text);assert.equal(report.mounted.overrides.text,'#abcdef');assert.equal(report.mounted.overrides.success,'#fedcba');assert.deepEqual(report.mounted.cancelled,report.mounted.initial);assert.equal(report.mounted.before,report.mounted.after);
  if(apackCheckout){
    assert.deepEqual(report.adapterPalette,report.mounted.overrides);assert.equal(report.drawing.children[0].props.color,report.mounted.overrides.success);
    assert.equal(report.documentSourcePreserved,true);assert.equal(report.documentRootsBefore,report.documentRootsAfter);assert.equal(report.documentRootsBefore,report.documentDisabledRootsAfter);
    assert.notEqual(report.disabledDocuments.children[1].props._apackCodeAnsi,report.documents.children[1].props._apackCodeAnsi,'Original settings hook must change native diff rendering');
    assert.equal(report.markdown.rootsAfter,report.documentRootsBefore);
    assert.match(report.markdown.enabled,/markdownValue/);assert.match(report.markdown.disabled,/markdownValue/);
    if(capabilityOverrides.FORCE_HYPERLINK==='0'){assert.equal(report.capabilities.hyperlinks,false);assert.ok(!report.markdown.enabled.includes('\x1b]8;'),'Original disabled hyperlinks must remain plain text');}
    if(capabilityOverrides.FORCE_COLOR==='0'||capabilityOverrides.NO_COLOR&&!Object.hasOwn(capabilityOverrides,'FORCE_COLOR'))assert.ok(!/\x1b\[[0-9;]*m/.test(report.markdown.enabled),'Original disabled paint must remain unstyled');
    assert.equal(report.documentExportStates.length,2);for(const state of report.documentExportStates){assert.equal(state.syntaxHighlightingDisabled,true);assert.deepEqual(state.tasks,[]);}
    assert.match(stripVTControlCharacters(report.documents.children[0].props._apackCodeAnsi),/7 const message/);assert.match(stripVTControlCharacters(report.documents.children[0].props._apackCodeAnsi),/8 console.log/);
    assert.match(report.documents.children[1].props._apackCodeAnsi,/\x1b\[/);assert.match(stripVTControlCharacters(report.documents.children[1].props._apackCodeAnsi),/const value = 1/);
    for(const node of report.documentTextTheme.children)assert.equal(node.props._apackDocumentTheme.text,'#abcdef');
  }
  return { ...run, evidence };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  assert.ok(process.argv.length===5||process.argv.length===6, 'Usage: node src/protocol/native-theme.mjs <pinned-binary> <private-root> <output> [apack-checkout]');
  console.log(JSON.stringify(await probeNativeTheme(...process.argv.slice(2).map(value => resolve(value))), null, 2));
}
