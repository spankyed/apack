import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { appendFileSync } from 'node:fs';

// Research runner only. Playwright enables focus emulation on its own CDP session;
// disabling it from another session leaves that original override active.
// Keep real BrowserWindow/document focus for the selected multi-window journey.
if (!process.versions.electron && (process.env.CLAUDE_RESEARCH_WINDOW_SELECTION === '1' || process.env.CLAUDE_RESEARCH_WINDOW_AGENT === '1' || process.env.CLAUDE_RESEARCH_WINDOW_PHASE === '1')
  && process.env.CLAUDE_RESEARCH_WORKSPACE && process.argv.some(value => /playwright/.test(value))) {
  const require = createRequire(join(process.cwd(), 'package.json'));
  const root = dirname(require.resolve('playwright-core/package.json'));
  const { CRSession } = require(join(root, 'lib/server/chromium/crConnection.js'));
  assert.equal(typeof CRSession?.prototype.send, 'function');
  const send = CRSession.prototype.send;
  CRSession.prototype.send = function (method, params) {
    if (method === 'Emulation.setFocusEmulationEnabled' && params?.enabled === true) {
      appendFileSync(join(process.env.CLAUDE_RESEARCH_WORKSPACE, 'native-window-focus-protocol.jsonl'),
        JSON.stringify({ method, enabled: false }) + '\n');
      return Reflect.apply(send, this, [method, { ...params, enabled: false }]);
    }
    return Reflect.apply(send, this, [method, params]);
  };
}
