import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,symlink} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {record} from './record.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Controlled protocol attestations only for repositories created entirely by this fixture. */
export async function probeWorkspaceTrust(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'workspace-trust-')),repo=join(workspace,'repo'),other=join(workspace,'other'),linked=join(workspace,'linked'),alias=join(workspace,'repo-alias'),gitHome=join(workspace,'git-home');await mkdir(gitHome,{recursive:true});
 const gitEnv={PATH:process.env.PATH,HOME:gitHome,GIT_CONFIG_NOSYSTEM:'1'};
 const git=(args,cwd=workspace)=>execFileSync('/usr/bin/git',args,{cwd,env:gitEnv,timeout:10000,stdio:'pipe'});
 for(const directory of [repo,other]){
  await mkdir(join(directory,'.claude'),{recursive:true});await mkdir(join(directory,'subfolder'),{recursive:true});
  await mkdir(join(directory,'subfolder','.claude'),{recursive:true});
  for(const launchDirectory of [directory,join(directory,'subfolder')])await writeFile(join(launchDirectory,'.claude','settings.json'),JSON.stringify({permissions:{allow:['Read(./repo-fixture.txt)'],deny:['Bash']}}));await writeFile(join(directory,'subfolder','README.md'),'Synthetic workspace trust fixture.\n');
  git(['init','-q','--template=',directory]);git(['add','.'],directory);git(['-c','user.name=Research Fixture','-c','user.email=fixture@example.invalid','commit','-qm','Private fixture'],directory);
 }
 git(['worktree','add','--detach',linked,'HEAD'],repo);await symlink(repo,alias,'dir');
 const run=await createRun(output,'workspace-trust',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),gitVersion:git(['--version']).toString().trim()});const cases=[];
 const scenarios=[
  {name:'subfolder-baseline',cwd:join(repo,'subfolder'),profile:'shared',expectedAllow:false},
  {name:'wrong-repository',cwd:join(repo,'subfolder'),profile:'shared',attestation:{accepted:true,directory:other},expectedAllow:false},
  {name:'declined',cwd:join(repo,'subfolder'),profile:'shared',attestation:{accepted:false,directory:repo},expectedAllow:false},
  {name:'subfolder-accept',cwd:join(repo,'subfolder'),profile:'shared',attestation:{accepted:true,directory:join(repo,'subfolder')},expectedAllow:true},
  {name:'root-restart',cwd:repo,profile:'shared',expectedAllow:true},
  {name:'linked-restart',cwd:linked,profile:'shared',expectedAllow:true},
  {name:'linked-subfolder-restart',cwd:join(linked,'subfolder'),profile:'shared',expectedAllow:true},
  {name:'other-repository-isolated',cwd:other,profile:'shared',expectedAllow:false},
  {name:'main-root-for-linked',cwd:join(linked,'subfolder'),profile:'linked-root',attestation:{accepted:true,directory:repo},expectedAllow:true},
  {name:'canonical-alias',cwd:join(repo,'subfolder'),profile:'alias',attestation:{accepted:true,directory:alias},expectedAllow:true},
  {name:'file-not-directory',cwd:join(repo,'subfolder'),profile:'invalid',attestation:{accepted:true,directory:join(repo,'subfolder','README.md')},expectedAllow:false},
  {name:'relative-directory',cwd:join(repo,'subfolder'),profile:'invalid',attestation:{accepted:true,directory:'repo'},expectedAllow:false},
 ];
 try{
  for(const scenario of scenarios){
   const home=join(workspace,`home-${scenario.profile}`),config=join(home,'.claude');await mkdir(config,{recursive:true});
   let pending='';const replies=[],requests=[{subtype:'initialize',hooks:{},...scenario.attestation?{workspaceTrust:scenario.attestation}:{}},{subtype:'get_settings'},{subtype:'list_permission_rules'}];const line=i=>JSON.stringify({type:'control_request',request_id:`trust-${i}`,request:requests[i]})+'\n';
   const transport=await record({executable,cwd:scenario.cwd,output,timeoutMs:10000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--no-session-persistence'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[line(0)],onStdout(bytes,channel){pending+=bytes.toString();while(pending.includes('\n')){const i=pending.indexOf('\n'),text=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(text)}catch{continue}if(value.type!=='control_response'||value.response?.request_id!==`trust-${replies.length}`)continue;replies.push(value.response);if(replies.length<requests.length)channel.send(line(replies.length));else channel.closeInput()}}});
   assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(replies.length,3);for(const reply of replies)assert.equal(reply.subtype,'success');
   const effectivePermissions=replies[1].response.effective.permissions??null,state=replies[2].response.state;
   const allowPresent=state.rules.some(rule=>rule.source==='projectSettings'&&rule.rule==='Read(./repo-fixture.txt)'&&rule.behavior==='allow');
   cases.push({...scenario,trustRecorded:replies[0].response.workspace_trust_recorded??null,allowPresent,effectivePermissions,state,transportRun:transport.directory});
  }
  const normalized=JSON.parse(JSON.stringify(cases).split(workspace).join('${WORKSPACE}'));await writeFile(join(run.directory,'workspace-trust.json'),JSON.stringify({cases:normalized,modelPrompts:0,nativeToolExecutions:0,qualification:'Owned synthetic repositories and protocol attestations; not a real consent dialog, remote/network/glyph screening, concurrent changes or actual rule enforcement.'},null,2)+'\n');
  const acknowledgements={'wrong-repository':false,'subfolder-accept':true,'main-root-for-linked':true,'canonical-alias':true,'file-not-directory':false};
  for(const item of cases)assert.equal(item.trustRecorded,acknowledgements[item.name]??(Object.hasOwn(acknowledgements,item.name)?false:null),`Trust acknowledgement differs for ${item.name}`);
  for(const item of cases){assert.ok(item.effectivePermissions?.allow.includes('Read(./repo-fixture.txt)'),`Fixture settings not loaded for ${item.name}`);assert.ok(item.state.rules.some(rule=>rule.source==='projectSettings'&&rule.rule==='Bash'&&rule.behavior==='deny'));assert.equal(item.allowPresent,item.expectedAllow,`Trust scope differs for ${item.name}`);}
  await run.finish({status:'complete',cases:cases.length});return{directory:run.directory,status:'complete',cases:cases.map(({name,trustRecorded,allowPresent})=>({name,trustRecorded,allowPresent})),modelPrompts:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
