import {mkdir,mkdtemp,readFile,writeFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {recognizeOnboardingPrompt} from './pty-onboarding.mjs';

export async function probePtyPlan(executable,workspace,output,{clearContext=false}={}){
 if(process.platform!=='darwin')throw new Error('Only verified on macOS');
 await mkdir(workspace,{recursive:true});const cwd=await mkdtemp(join(workspace,'pty-plan-'));
 const bridge=fileURLToPath(new URL('./pty_bridge.py',import.meta.url));
 const model=await startSyntheticModel(cwd,'TuiPlan');
 let terminal='',theme=false,security=false,navigated=false,trusted=false,promptTextSent=false,promptSubmitted=false,approvalSent=false,exitKeysSent=0,bound;
 const timers=[];
 try{
  const run=await record({executable:'/usr/bin/python3',cwd,output,timeoutMs:30000,
   args:[bridge,executable,'--setting-sources','','--strict-mcp-config','--permission-mode','plan','--tools','Write,ExitPlanMode','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key',showClearContextOnPlanAccept:true})],
   env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),TERM:'xterm-256color',COLUMNS:'100',LINES:'30',ANTHROPIC_BASE_URL:model.url,ENABLE_TOOL_SEARCH:'0',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
   onStdout(bytes,transport){
    terminal+=bytes.toString('utf8');const screen=recognizeOnboardingPrompt(terminal,cwd);
    const compact=terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');
    let input;
    if(screen==='theme'&&!theme){theme=true;input='\r'}
    else if(screen==='security-notes'&&theme&&!security){security=true;input='\r'}
    else if(screen==='workspace-trust'&&!navigated){navigated=true;input='\x1b[B'}
    else if(screen==='workspace-trust-selected'&&navigated&&!trusted){trusted=true;input='\r'}
    else if(trusted&&!promptTextSent&&compact.includes('APIUsageBilling')&&compact.includes('shift+tabtocycle')){promptTextSent=true;input='NativePlanFixtureSeedAlpha: Create the synthetic plan and request approval.'}
    else if(promptTextSent&&!promptSubmitted&&compact.includes('NativePlanFixtureSeedAlpha:')){promptSubmitted=true;input='\r'}
    const freshContext=model.calls.some(call=>call.toolNames?.includes('Write')&&call.hasSyntheticPlan&&!call.hasTuiSeed);
    const selectedClear=/❯1\.Yes,clearcontext\([^)]*used\)anduseautomode/.test(compact);
    if(clearContext&&promptSubmitted&&!approvalSent&&compact.includes('Readytocode?')&&compact.includes('Syntheticnativeplan')&&selectedClear&&model.calls.some(call=>call.fixtureResponse==='ExitPlanMode')){approvalSent=true;input='\r'}
    else if(approvalSent&&freshContext&&exitKeysSent===0&&compact.includes('⏺Fixturecompleted.')){exitKeysSent++;input='\x04'}
    else if(exitKeysSent===1&&/pressctrl[+-]dagaintoexit/i.test(compact)){exitKeysSent++;input='\x04'}
    if(input!==undefined){timers.push(setTimeout(()=>transport.send(input),150));clearTimeout(bound);bound=setTimeout(()=>transport.stop('plan-dialog-observation-bound'),10000)}
   }});
  const planPath=model.calls.find(call=>call.tuiPlanPath)?.tuiPlanPath;
  let plan; if(planPath)try{plan=await readFile(planPath,'utf8')}catch(error){if(error.code!=='ENOENT')throw error}
  const transcripts=[];let transcriptParseErrors=0;
  for(const file of await readdir(join(cwd,'.claude'),{recursive:true})){
   if(!file.startsWith('projects/')||!file.endsWith('.jsonl'))continue;
   const rows=(await readFile(join(cwd,'.claude',file),'utf8')).split('\n').filter(line=>line.trim()).flatMap(line=>{try{const row=JSON.parse(line);if(row&&typeof row==='object'&&!Array.isArray(row))return[row]}catch{}transcriptParseErrors++;return[]});
   const text=rows.filter(row=>row.type==='user').map(row=>typeof row.message?.content==='string'?row.message.content:JSON.stringify(row.message?.content??'')).join('\n');
   const sessionIds=[...new Set(rows.map(row=>row.sessionId??row.session_id).filter(value=>typeof value==='string'))];
   transcripts.push({file,sessionIds,hasSeed:text.includes('NativePlanFixtureSeedAlpha'),hasContinuation:text.includes('Implement the following plan:')&&text.includes('Synthetic native plan')});
  }
  const sessionIds=[...new Set(transcripts.flatMap(value=>value.sessionIds))];
  const freshContext=model.calls.some(call=>call.toolNames?.includes('Write')&&call.hasSyntheticPlan&&!call.hasTuiSeed);
  const oldSessionPreserved=transcripts.some(value=>value.hasSeed),continuationSaved=transcripts.some(value=>value.hasContinuation);
  const verified=clearContext&&run.status==='complete'&&approvalSent&&plan==='# Synthetic native plan\n\nImplement the isolated fixture only.\n'&&freshContext&&sessionIds.length>=2&&oldSessionPreserved&&continuationSaved&&exitKeysSent>0&&transcriptParseErrors===0;
  const evidence={verified,clearContext,targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),bridgeSha256:hash(await readFile(bridge)),theme,security,navigated,trusted,promptSubmitted,planMatches:plan==='# Synthetic native plan\n\nImplement the isolated fixture only.\n',calls:model.calls,approvalInputsSent:approvalSent?1:0,exitKeysSent,freshContext,oldSessionPreserved,continuationSaved,sessionIds,transcripts,transcriptParseErrors,realModelRequests:0,qualification:clearContext?'Native selected clear-context/auto-mode continuation fixture; not an app action or general task/reset parity claim.':'Plan creation/dialog observation only; no approval or clear-context transition is claimed.'};
  await writeFile(join(run.directory,'pty-plan.json'),JSON.stringify(evidence,null,2)+'\n');
  if(clearContext&&run.status==='complete'&&!verified){const path=join(run.directory,'manifest.json');const manifest=JSON.parse(await readFile(path,'utf8'));await writeFile(path,JSON.stringify({...manifest,status:'failed',verificationFailure:'plan-clear-verification-failed'},null,2)+'\n')}
  return {...run,...evidence,status:clearContext&&!verified?'failed':run.status};
 }finally{clearTimeout(bound);for(const timer of timers)clearTimeout(timer);await model.close()}
}
