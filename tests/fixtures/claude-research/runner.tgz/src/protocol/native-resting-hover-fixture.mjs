import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** Original Client timer/post and hook invalidation drive redraws without moving the app pointer. */
export async function addNativeRestingHoverFixture(plugin, workspace) {
  await writeFile(join(workspace, 'native-resting-hover-request.txt'), '0');
  await writeFile(join(workspace, 'native-resting-hover-applied.json'), '[]');
  await writeFile(join(plugin, 'hooks/hover-clock.ts'), `export default function(props,s){const{Text}=s.elements;if(s.state===undefined){s.setState({ready:true});s.every(100,()=>s.post({restingHover:true}));}return Text({children:['Review status']});}`);
  await writeFile(join(plugin, 'hooks/register.ts'), `export function register(on){let phase=0;
    on('ui.message',async($,e,next)=>{if(e.data?.restingHover!==true)return next(e);const requested=Number((await $.fs.read('native-resting-hover-request.txt')).trim());if(!Number.isInteger(requested)||requested<0||requested>24)throw Error('Invalid review phase');if(requested!==phase){phase=requested;const rows=JSON.parse(await $.fs.read('native-resting-hover-applied.json'));rows.push({phase,component:e.component,surface:e.surface});await $.fs.write('native-resting-hover-applied.json',JSON.stringify(rows));$.ui.invalidate('ui.render');}});
    on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Client}=$.ui.resolve(e);await $.fs.write('native-resting-hover-drawn.json',JSON.stringify({phase,requestId:e.requestId,surface:e.surface}));return Box({flexDirection:'column',children:[Client({key:'review-clock',module:'./hover-clock.ts',height:1}),Box({height:2,children:[Box({paddingTop:phase%2,flexShrink:0,children:[Text({hover:{scope:'review-detail',color:'success'},children:['Review detail trigger']})]})]}),Text({children:['Review update '+phase]})]});});
    on('ui.render',{component:'PromptHint'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Text}=$.ui.resolve(e);return Text({hover:{scope:'review-detail',color:'success'},children:['Release review ready']});});
  }`);
}
