import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { hash } from '../artifacts/runs.mjs';

/** Install authored instrumentation in a private fixture; never modify the configured command. */
export async function installNativeStatusPrefix(workspace, { socketPath, token, commands }) {
  const runtime = await readFile(new URL('./native-status-prefix-runtime.mjs', import.meta.url));
  await writeFile(join(workspace, 'native-status-prefix-runtime.mjs'), runtime, { mode: 0o600 });
  const path = join(workspace, 'native-status-prefix.mjs');
  const source = `#!${process.execPath}\nimport { runNativeStatusPrefix } from './native-status-prefix-runtime.mjs';\nawait runNativeStatusPrefix(${JSON.stringify({ socketPath, token, commands })});\n`;
  await writeFile(path, source, { mode: 0o700 });
  return { path, sha256: hash(Buffer.from(source)), implementationSha256: hash(runtime) };
}
