import assert from 'node:assert/strict';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

/** Configure public PreModelSwitch hooks in an owned fixture; native execution retains all admission. */
export async function addNativeModelPanelFixture(workspace){
 const file=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(file,'utf8'));
 assert.equal(settings.hooks?.PreModelSwitch,undefined);
 const hook=join(workspace,'native-model-hook.py');
 await writeFile(hook,`import json,os,pathlib,sys,time
root=pathlib.Path(__file__).parent
payload=json.load(sys.stdin)
mode=(root/'native-model-hook-mode').read_text().strip()
def record(phase):
 with (root/'native-model-hook-receipts.jsonl').open('a') as out:
  out.write(json.dumps({'phase':phase,'pid':os.getpid(),'at':time.time(),'mode':mode,'input':payload})+'\\n')
record('start')
if mode in ['pending','timeout']:
 time.sleep(30)
else:
 if mode not in ['allow','ask','deny']:raise ValueError('Unknown model hook fixture mode')
 reason={'allow':'The review permits this model change.','ask':'Confirm this model change before continuing.','deny':'Keep the current model for the review.'}[mode]
 record('answer')
 print(json.dumps({'hookSpecificOutput':{'hookEventName':'PreModelSwitch','permissionDecision':mode,'permissionDecisionReason':reason}}))
`);
 await writeFile(join(workspace,'native-model-hook-mode'),'allow');
 const quote=value=>"'"+value.replaceAll("'","'\\''")+"'",command='/usr/bin/python3 '+quote(hook);
 settings.hooks={...settings.hooks,PreModelSwitch:[{matcher:'.*(haiku|opus).*',hooks:[{type:'command',command,timeout:30}]},{matcher:'.*sonnet.*',hooks:[{type:'command',command,timeout:2}]}]};
 await writeFile(file,JSON.stringify(settings));
}

export async function verifyNativeModelPanel(workspace,evidence,calls){
 for(const key of ['nativeModelPanel','nativeModelConfirmation','nativeModelRefusal','nativeModelCancellation','nativeModelTimeout','nativeModelReset','nativeRetainedDraft','resumedPrintSameSession'])assert.equal(evidence[key],true,key);
 const proof=JSON.parse(await readFile(join(workspace,'native-model-panel-app.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.nativePid,evidence.boundNativePid);assert.equal(evidence.finalSessionId,proof.sessionId);
 assert.deepEqual(proof.receipts.map(row=>row.stage),['sdk-ask','cancel-confirmation','confirm','deny','cancel-pending','timeout','allow','native-turn','reset','resumed']);
 for(const row of proof.receipts){assert.equal(row.sessionId,proof.sessionId);if(['sdk-ask','native-turn','resumed'].includes(row.stage))assert.equal(row.inputAcknowledged,true);else assert.equal(row.draftRetained,true);if(row.stage!=='resumed')assert.equal(row.nativePid,proof.nativePid);}
 assert.deepEqual(proof.captures.map(row=>[row.stage,row.width]),['picker','confirmation','pending','recovered'].flatMap(stage=>[1100,680].map(width=>[stage,width])));
 for(const row of proof.captures){assert.equal(row.readable,true);assert.equal(row.controlsReachable,true);}
 const hooks=(await readFile(join(workspace,'native-model-hook-receipts.jsonl'),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
 for(const mode of ['ask','deny','pending','timeout','allow'])assert.ok(hooks.some(row=>row.mode===mode&&row.phase==='start'&&row.input.hook_event_name==='PreModelSwitch'),mode);
 assert.ok(hooks.some(row=>row.mode==='ask'&&row.input.source==='sdk'));
 assert.ok(hooks.some(row=>row.mode==='ask'&&row.input.source==='picker'));
 for(const [stage,mode] of [['cancel-pending','pending'],['timeout','timeout']]){const row=proof.receipts.find(row=>row.stage===stage);assert.equal(row.helperExited,true);assert.ok(hooks.some(hook=>hook.mode===mode&&hook.phase==='start'&&hook.pid===row.helperPid));}
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.ok(paths.length);
 const unique=new Map();for(const path of paths)for(const line of (await readFile(join(root,path),'utf8')).trim().split('\n').filter(Boolean)){const row=JSON.parse(line);unique.set(row.uuid??Symbol(),row);}
 const humans=[...unique.values()].filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'));
 assert.deepEqual(humans.map(row=>row.message.content),['Review this project with the current Claude model.','Review the model choice using the selected model.','Continue the same review after model controls close.']);
 assert.equal(calls.seed.length,2);assert.equal(calls.agent.length,1);assert.equal(calls.agent[0].model,proof.effectiveModel);assert.match(proof.effectiveModel,/sonnet/i);assert.equal(calls.seed[0].model,calls.seed[1].model);
 assert.equal(proof.resetModel,'default');assert.equal(proof.resetSavedModelAbsent,true);
 return {sessionId:proof.sessionId,nativePid:proof.nativePid,humanUuids:humans.map(row=>row.uuid),selectedModel:proof.selectedModel,effectiveModel:proof.effectiveModel,requestModels:{seed:calls.seed.map(row=>row.model),native:calls.agent.map(row=>row.model)},captures:proof.captures,scope:'Main-owner original standalone model picker, configured hooks/confirmation/refusal/cancellation/timeout, default reset, native request effect and same-session print recovery. Credit purchase/admin forms and account-positive usage consent remain separate.'};
}
