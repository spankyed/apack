import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { access, mkdir, mkdtemp, readdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { stripVTControlCharacters } from 'node:util';
import { networkInterfaces } from 'node:os';
import { StringDecoder } from 'node:string_decoder';
import { hash } from '../artifacts/runs.mjs';
import { record } from './record.mjs';
import { recognizeOnboardingPrompt } from './pty-onboarding.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';

import { virtualDraft as text, virtualHint as hint, virtualHintHook, virtualFillHook, virtualFillTrigger } from './native-prompt-virtual-fixture.mjs';
const reply = 'The release checklist is ready.';
const targetSha256 = '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10';

export async function probeNativePromptVirtualTerminal(executable, parent, output, { reverseFill = false } = {}) {
  assert.equal(process.platform, 'linux');
  assert.equal(process.getuid(), 1000);
  await access('/.dockerenv');
  assert.ok(Object.values(networkInterfaces()).flat().every(address => address.internal), 'Virtual hint probe requires an offline Linux container');
  assert.equal(hash(await readFile(executable)), targetSha256);
  await mkdir(parent, { recursive: true });
  const workspace = await mkdtemp(join(parent, 'virtual-terminal-'));
  const config = join(workspace, '.claude');
  const plugin = join(workspace, 'plugin');
  await mkdir(config);
  await mkdir(join(plugin, '.claude-plugin'), { recursive: true });
  await mkdir(join(plugin, 'hooks'));
  await writeFile(join(config, '.claude.json'), JSON.stringify({ hasCompletedOnboarding: true,
    projects: { [workspace]: { hasTrustDialogAccepted: true } } }));
  await writeFile(join(plugin, '.claude-plugin/plugin.json'), JSON.stringify({ name: 'virtual-prompt-review', version: '0.0.1' }));
  await writeFile(join(plugin, 'hooks/hooks.json'), JSON.stringify({ modules: ['./register.ts'] }));
  const source = reverseFill ? virtualFillHook : virtualHintHook;
  await writeFile(join(plugin, 'hooks/register.ts'), source);
  const model = await startSyntheticModel(workspace, 'TextOnly', { captureMessages: true, textReply: reply, maxRequests: 5 });
  const pty = fileURLToPath(new URL('./pty_bridge.py', import.meta.url));
  const decoder = new StringDecoder('utf8');
  let terminal = '', draftSent = false, submitted = false, exitKeys = 0;
  const onboarding = new Set();
  const timers = [];
  try {
    const run = await record({ executable: '/usr/bin/python3', cwd: workspace, output, timeoutMs: 20000, maxBytes: 1024 * 1024,
      args: [pty, executable, '--setting-sources', '', '--plugin-dir', plugin, '--strict-mcp-config', '--tools', '',
        '--settings', JSON.stringify({ theme: 'dark', apiKeyHelper: '/usr/bin/printf research-fixture-key' })],
      env: { PATH: process.env.PATH, HOME: workspace, CLAUDE_CONFIG_DIR: config, TERM: 'xterm-256color',
        ANTHROPIC_BASE_URL: model.url, DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' },
      onStdout(bytes, channel) {
        terminal += decoder.write(bytes);
        const screen = stripVTControlCharacters(terminal);
        const prompt = recognizeOnboardingPrompt(terminal, workspace);
        let input;
        if (!draftSent && prompt && !onboarding.has(prompt)) {
          onboarding.add(prompt);
          input = prompt === 'workspace-trust' ? '\x1b[B' : '\r';
        } else if (!draftSent && screen.includes('❯') && /Claude Code\s*v2\.1\.302/.test(screen)) {
          draftSent = true;
          if (reverseFill) writeFileSync(join(workspace, virtualFillTrigger), 'true', { flag: 'wx', mode: 0o600 });
          else input = text;
        } else if (!submitted && screen.includes(hint.trim())) {
          submitted = true;
          input = '\r';
        } else if (submitted && exitKeys === 0 && screen.replace(/\s/g, '').includes(reply.replace(/\s/g, ''))) {
          exitKeys++;
          input = '\x04';
        } else if (exitKeys === 1 && /press ctrl[+-]d again to exit/i.test(screen)) {
          exitKeys++;
          input = '\x04';
        }
        if (input !== undefined) timers.push(setTimeout(() => channel.send(input), 180));
      },
    });
    const readProof = async name => {
      try { return JSON.parse(await readFile(join(workspace, name), 'utf8')); }
      catch (error) { if (error.code !== 'ENOENT') throw error; return null; }
    };
    const edit = await readProof('virtual-edit.json');
    const fill = reverseFill ? await readProof('virtual-fill.json') : undefined;
    const submission = await readProof('virtual-submit.json');
    const calls = model.calls.filter(call => call.path.split('?')[0] === '/v1/messages');
    await writeFile(join(run.directory, 'model-calls.json'), JSON.stringify(calls, null, 2));
    const journalRoot = join(config, 'projects');
    const paths = await readdir(journalRoot, { recursive: true }).catch(error => {
      if (error.code !== 'ENOENT') throw error;
      return [];
    });
    const journalRows = (await Promise.all(paths.filter(path => path.endsWith('.jsonl')).map(async path =>
      (await readFile(join(journalRoot, path), 'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse)))).flat();
    const exactHumans = journalRows.filter(row => row.type === 'user' && row.message?.content === text);
    await writeFile(join(run.directory, 'matching-transcript.json'), JSON.stringify(exactHumans, null, 2));
    const visible = stripVTControlCharacters(terminal + decoder.end()).includes(hint.trim());
    const originalRequests = calls.flatMap(call => call.messages ?? []).filter(message => message.role === 'user' &&
      (message.content === text || (Array.isArray(message.content) && message.content.length === 1
        && message.content[0].type === 'text' && message.content[0].text === text)));
    const result = { status: run.status, targetSha256, pluginSha256: hash(Buffer.from(source)), run, visible, edit, fill, reverseFill, submission, draftSent, submitted, exitKeys,
      originalJournalRows: exactHumans.length, originalRequests: originalRequests.length,
      providerDidNotReceiveHint: calls.every(call => !JSON.stringify(call.messages).includes(hint.trim())), onboarding: [...onboarding] };
    await writeFile(join(output, 'virtual-terminal-proof.json'), JSON.stringify(result, null, 2));
    assert.equal(run.status, 'complete');
    assert.equal(visible, true);
    if (reverseFill) {
      assert.deepEqual(fill?.before, { text: '', cursor: 0 });
      assert.equal(fill?.result?.isFilled, true);
      assert.deepEqual(fill?.after, { text, cursor: text.length });
    } else assert.equal(edit?.text, text);
    assert.equal(submission?.text, text);
    assert.equal(result.originalRequests, 1);
    assert.equal(result.originalJournalRows, 1);
    assert.equal(result.providerDidNotReceiveHint, true);
    return result;
  } finally {
    for (const timer of timers) clearTimeout(timer);
    await model.close();
  }
}
