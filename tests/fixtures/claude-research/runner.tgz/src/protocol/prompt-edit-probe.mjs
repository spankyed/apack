import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { record } from './record.mjs';
import { startSyntheticModel } from './synthetic-model.mjs';
import { hash } from '../artifacts/runs.mjs';

/** Private native edit/adoption contract; no model turn or reverse composer capabilities. */
export async function probePromptEdit(executable, workspace, output, { virtualText = false } = {}) {
  await mkdir(workspace, { recursive: true });
  const cwd = await mkdtemp(join(workspace, 'prompt-edit-'));
  const plugin = join(cwd, 'plugin');
  await mkdir(join(plugin, '.claude-plugin'), { recursive: true });
  await mkdir(join(plugin, 'hooks'));
  await writeFile(join(plugin, '.claude-plugin', 'plugin.json'), JSON.stringify({ name: 'research-prompt-fixture', version: '0.0.1' }));
  await writeFile(join(plugin, 'hooks', 'hooks.json'), JSON.stringify({ modules: ['./register.ts'] }));
  const source = `export function register(on) {
    on("prompt.edit", async ($, e, next) => {
      const frame = await next(e);
      return { ...frame, text: frame.text.toUpperCase(), decorations: [${virtualText ? '{start: 0, end: 0, virtualText: "native hint "},' : ''}{start: 0, end: frame.text.length, bold: true}] };
    });
  }`;
  await writeFile(join(plugin, 'hooks', 'register.ts'), source);
  const client = { client_id: 'research-prompt', surface: 'desktop' };
  const requests = [
    { subtype: 'initialize', hooks: {} },
    { subtype: 'ui_attach', ...client, answers: [] },
    { subtype: 'ui_prompt_edit', ...client, by: 'app', text: 'seed', cursor: 4 },
    { subtype: 'ui_prompt_edit', ...client, by: 'person', text: 'seedx', cursor: 5 },
    { subtype: 'ui_prompt_edit', ...client, by: 'app', text: 'history', cursor: 7 },
    { subtype: 'ui_prompt_edit', ...client, by: 'person', text: 'history!', cursor: 100 },
    { subtype: 'ui_detach', client_id: client.client_id },
  ];
  const responses = [], unexpected = [];
  let pending = '', next = 1;
  const message = index => JSON.stringify({ type: 'control_request', request_id: `prompt-${index}`, request: requests[index] }) + '\n';
  const model = await startSyntheticModel(cwd, 'TextOnly');
  try {
    const run = await record({ executable, cwd, output, timeoutMs: 15000,
      args: ['--print', '--verbose', '--input-format', 'stream-json', '--output-format', 'stream-json', '--setting-sources', '', '--plugin-dir', plugin, '--strict-mcp-config', '--tools', '', '--permission-prompt-tool', 'stdio', '--no-session-persistence', '--settings', JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' })],
      env: { PATH: process.env.PATH, HOME: cwd, CLAUDE_CONFIG_DIR: join(cwd, '.claude'), ANTHROPIC_BASE_URL: model.url, DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1' }, input: [message(0)],
      onStdout(bytes, transport) {
        pending += bytes.toString('utf8');
        while (pending.includes('\n')) {
          const at = pending.indexOf('\n'), line = pending.slice(0, at); pending = pending.slice(at + 1);
          let value; try { value = JSON.parse(line); } catch { continue; }
          if (value.type === 'control_response' && value.response?.request_id === `prompt-${next - 1}`) {
            responses.push(value.response);
            if (next < requests.length) transport.send(message(next++)); else transport.closeInput();
          } else if (value.type === 'control_request') {
            unexpected.push(value.request?.subtype);
            transport.send(JSON.stringify({ type: 'control_response', response: { subtype: 'error', request_id: value.request_id, error: 'No reverse capability advertised' } }) + '\n');
          }
        }
      },
    });
    const frame = index => responses[index]?.response;
    const verified = run.status === 'complete' && responses.length === requests.length && responses.every(r => r.subtype === 'success')
      && frame(2)?.text === 'seed' && !frame(2)?.decorations?.length
      && frame(3)?.text === 'SEEDX' && frame(3)?.cursor === 5 && frame(3)?.decorations?.some(run => run.bold === true) && (!virtualText || frame(3)?.decorations?.some(run => run.virtualText === 'native hint ' && run.start === 0 && run.end === 0))
      && frame(4)?.text === 'history' && !frame(4)?.decorations?.length
      && frame(5)?.text === 'HISTORY!' && frame(5)?.cursor === 8 && unexpected.length === 0 && model.calls.length === 0;
    const evidence = { verified, virtualText, targetSha256: hash(await readFile(executable)), driverSha256: hash(await readFile(new URL(import.meta.url))), pluginSourceSha256: hash(Buffer.from(source)), requests, responses, unexpected, syntheticApiRequests: model.calls.length, realModelRequests: 0, qualification: 'Sequential private native prompt.edit rewrite/adoption/caret/decorations only; no app composer, concurrent edits, prompt submission or app decoration claim.' };
    await writeFile(join(run.directory, 'prompt-edit.json'), JSON.stringify(evidence, null, 2) + '\n');
    if (!verified) {
      const path = join(run.directory, 'manifest.json'), manifest = JSON.parse(await readFile(path));
      await writeFile(path, JSON.stringify({ ...manifest, status: 'failed', verificationFailure: 'prompt-edit-verification-failed' }, null, 2) + '\n');
    }
    return { ...run, status: verified ? 'complete' : 'failed', verified, responseCount: responses.length, syntheticApiRequests: model.calls.length };
  } finally { await model.close(); }
}
