import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** One real original Client, whose native timer redraws while Chromium owns composition. */
export async function addNativeRootImeFixture(plugin) {
  await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Client}=$.ui.resolve(e);return Client({key:'keyboard-review',module:'./root-ime.ts',width:48,height:2,props:{}});});on('ui.message',async($,e,next)=>{if(e.surface==='desktop'&&e.data?.rootIme===true)await $.fs.write('native-root-ime-state.json',JSON.stringify(e.data));return next(e);});}`);
  await writeFile(join(plugin,'hooks/root-ime.ts'),`export default function(props,s){const{Text}=s.elements;if(s.state===undefined){s.setState({text:'',keys:[],ticks:0});s.every(40,()=>s.setState({...s.state,ticks:s.state.ticks+1}));}s.onKey(e=>s.setState({...s.state,text:s.state.text+e.key,keys:[...s.state.keys,e.key]}));s.post({rootIme:true,...s.state});return Text({children:['Client input: '+s.state.text+' · redraw '+s.state.ticks]});}`);
}
