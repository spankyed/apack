import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {verifyNativeWorkflowResume} from './native-workflow-resume-proof.mjs';

/** A fixed header above one real content scroller, with original workflow/session behavior retained. */
export async function verifyNativeWorkflowDetailsLayout(root){
 const workflow=await verifyNativeWorkflowResume(root),names=(await readdir(join(root,'workspaces'))).filter(name=>name.startsWith('apack-terminal-owner-app-'));assert.equal(names.length,1);
 const proof=JSON.parse(await readFile(join(root,'workspaces',names[0],'native-workflow-resume-proof.json'),'utf8'));
 assert.deepEqual(proof.workflowDetailLayout.map(row=>row.width),[1100,680]);
 for(const row of proof.workflowDetailLayout){
  const {geometry:g,beforeHeader}=row;assert.ok(Math.abs(g.header.top-beforeHeader.y)<0.6);assert.ok(g.header.height>0);assert.ok(g.body.top>=g.header.bottom-1);assert.ok(g.header.top>=g.popover.top);assert.ok(g.header.bottom<=g.popover.bottom);assert.ok(g.body.bottom<=g.popover.bottom);assert.equal(g.headerHit,true);assert.ok(g.clientHeight>0);assert.ok(g.scrollHeight>g.clientHeight);assert.ok(g.scrollTop>0&&g.scrollTop<=g.scrollHeight-g.clientHeight+1);
 }
 return {...workflow,fixedHeaderNormalAndCompact:true,oneIndependentContentScroller:true,realWheelScrolling:true,qualification:'Workflow details header/scrolling, reachable Close/composing and original workflow recovery accepted at two sizes. No early-phase Resume browser click or complete everyday visual-polish claim.'};
}
