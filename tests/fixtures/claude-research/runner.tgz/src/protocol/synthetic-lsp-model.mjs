import http from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Local responses ask the original LSP tool to navigate; this never fabricates its tool results. */
export async function startSyntheticLspModel(workspace,{lifecycle=false,lifetime=false,unload=false,seedUntilInstalled=false,seedBeforeNative=false}={}){
 const calls=[];let sequence=0;
 const server=http.createServer(async(req,res)=>{try{
  const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>2*1024*1024)throw Error('Owned LSP model input exceeded bound');chunks.push(chunk);}
  const body=JSON.parse(Buffer.concat(chunks).toString()||'{}');
  if(req.url?.includes('count_tokens')){res.writeHead(200,{'content-type':'application/json'});res.end('{"input_tokens":10}');return;}
  const path=new URL(req.url,'http://owned-lsp.invalid').pathname;
  if(path!=='/v1/messages'||req.method!=='POST'){calls.push({kind:'metadata-refusal',path:req.url,method:req.method,status:404});res.writeHead(404);res.end('{}');return;}
  if(++sequence>(lifecycle?40:24))throw Error('Owned LSP model request limit');
  await writeFile(join(workspace,'native-lsp-model-count'),String(sequence));
  const installed=seedUntilInstalled?JSON.parse(await readFile(join(workspace,'.claude/settings.json'),'utf8')).enabledPlugins?.['recommendation-review@owned-recommendation']===true:true;
  const phase=installed?Number((await readFile(join(workspace,'native-lsp-phase'),'utf8')).trim()):0;
  if(!((seedUntilInstalled||seedBeforeNative)&&phase===0)&&!(unload?[1,8,7]:lifetime?[1,4,7]:lifecycle?[1,2,3,4,5,6,7]:[1,2,3]).includes(phase))throw Error('Explicit owned LSP phase required');
  const id='native_lsp_'+phase,searchId='native_lsp_search_'+phase;
  const blocks=(body.messages??[]).flatMap(message=>Array.isArray(message.content)?message.content:[]);
  const result=blocks.find(block=>block.type==='tool_result'&&block.tool_use_id===id),search=blocks.find(block=>block.type==='tool_result'&&block.tool_use_id===searchId);
  const offered=body.tools?.find(tool=>tool.name==='LSP');
  const references=search?.content?.filter?.(block=>block.type==='tool_reference').map(block=>block.tool_name)??[];
  const admitted=offered?.input_schema!==undefined&&offered.defer_loading!==true||references.includes('LSP');
  const quota=body.messages?.length===1&&body.messages[0].role==='user'&&body.messages[0].content==='quota'&&(!body.tools||body.tools.length===0);
  let block;
  if(quota)block={type:'text',text:'Fixture completed.'};
  else if(phase===0)block={type:'text',text:'Fixture completed.'};
  else if(result)block={type:'text',text:'Owned LSP review phase '+phase+' complete.'};
  else if(!admitted&&!search&&body.tools?.some(tool=>tool.name==='ToolSearch'))block={type:'tool_use',id:searchId,name:'ToolSearch',input:{query:'select:LSP'}};
  else if(!admitted)block={type:'text',text:'Original LSP tool was not admitted.'};
  else block={type:'tool_use',id,name:'LSP',input:{operation:phase===2?'hover':'goToDefinition',filePath:join(workspace,phase===3?'unmapped.txt':'release.review'),line:2,character:1}};
  calls.push({phase,model:body.model,...(quota?{kind:'native-quota'}:{}),toolNames:body.tools?.map(tool=>tool.name),messages:body.messages,response:block,...(result?{lspResult:result}:{})});
  const message={id:'msg_lsp_'+sequence,type:'message',role:'assistant',model:body.model,content:[block],stop_reason:block.type==='tool_use'?'tool_use':'end_turn',stop_sequence:null,usage:{input_tokens:10,output_tokens:10}};
  if(body.stream){
   res.writeHead(200,{'content-type':'text/event-stream'});const emit=(event,data)=>res.write('event: '+event+'\ndata: '+JSON.stringify(data)+'\n\n');
   emit('message_start',{type:'message_start',message:{...message,content:[],stop_reason:null,usage:{input_tokens:10,output_tokens:0}}});
   emit('content_block_start',{type:'content_block_start',index:0,content_block:block.type==='tool_use'?{...block,input:{}}:{type:'text',text:''}});
   emit('content_block_delta',{type:'content_block_delta',index:0,delta:block.type==='tool_use'?{type:'input_json_delta',partial_json:JSON.stringify(block.input)}:{type:'text_delta',text:block.text}});
   emit('content_block_stop',{type:'content_block_stop',index:0});emit('message_delta',{type:'message_delta',delta:{stop_reason:message.stop_reason,stop_sequence:null},usage:{output_tokens:10}});emit('message_stop',{type:'message_stop'});res.end();
  }else{res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(message));}
 }catch(error){calls.push({error:error.message,path:req.url,method:req.method});if(!res.headersSent)res.writeHead(400);res.end('{}');}});
 server.requestTimeout=5000;
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 return {url:'http://127.0.0.1:'+server.address().port,calls,close:()=>new Promise(resolve=>{server.close(resolve);server.closeAllConnections();})};
}
