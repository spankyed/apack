import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { constants, existsSync, writeFileSync } from 'node:fs'
import { access, mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { stripVTControlCharacters } from 'node:util'
import { hash } from '../artifacts/runs.mjs'
import { configureNativeCreditAccount } from './native-credit-account.mjs'
import { record } from './record.mjs'

const binarySha256 = '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37'
const predicateSha256 = 'f7f9ae16f8ede0e47b93c49d72f134a05fb8345d54286d7dbd1a9e57cb0126b3'
const sandbox = '/usr/bin/sandbox-exec'
const networkProfile = '(version 1)(allow default)(deny network*)'
const bridge = fileURLToPath(new URL('./pty_bridge.py', import.meta.url))

function admissionObserver(ready, receipt) {
  return `
import { constants, existsSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
const timer = setInterval(async () => {
  if (!existsSync(${JSON.stringify(ready)})) return
  clearInterval(timer)
  let result
  try {
    const { oOr, $L } = await import('/$bunfs/root/chunk-2bb0j573.js')
    const { kt } = await import('/$bunfs/root/chunk-2jyw98bz.js')
    const predicateSha256 = createHash('sha256').update(Function.prototype.toString.call(oOr)).digest('hex')
    if (predicateSha256 !== ${JSON.stringify(predicateSha256)}) throw Error('Original cost predicate changed')
    result = { pid: process.pid, predicateSha256, oauthMode: kt(), meteredBilling: $L(), admitted: oOr() }
  } catch (error) { result = { error: String(error) } }
  writeFileSync(${JSON.stringify(receipt)}, JSON.stringify(result, null, 2) + '\\n')
}, 50)
timer.unref()
`
}

assert.equal(process.platform, 'darwin')
assert.equal(process.arch, 'arm64')
const [executableArg, parentArg] = process.argv.slice(2)
assert.ok(executableArg && parentArg, 'Supply the pinned Claude binary and a scratch output directory')
const executable = resolve(executableArg)
const parent = resolve(parentArg)
await access(executable, constants.X_OK)
assert.equal(hash(await readFile(executable)), binarySha256)
const networkCheck = spawnSync(sandbox, ['-p', networkProfile, '/usr/bin/python3', '-c',
  'import errno,socket; s=socket.socket(); s.settimeout(.35); err=s.connect_ex(("192.0.2.1",443)); assert err in (errno.EPERM,errno.EACCES), err; print(err)'],
{ encoding: 'utf8', timeout: 1500 })
assert.equal(networkCheck.status, 0, networkCheck.stderr || String(networkCheck.error))
await mkdir(parent, { recursive: true })
const results = []

for (const [profile, billingType] of [
  ['oauth', 'usage_based'], ['oauth', 'stripe_subscription'], ['api-key', null],
]) {
  const workspace = await mkdtemp(join(parent, 'native-credit-admission-'))
  const credentials = await configureNativeCreditAccount(workspace, profile, { featureCache: 'native-defaults' })
  const configPath = join(credentials.CLAUDE_CONFIG_DIR, '.claude.json')
  const config = JSON.parse(await readFile(configPath, 'utf8'))
  if (billingType) config.oauthAccount.billingType = billingType
  else delete config.oauthAccount
  config.hasCompletedOnboarding = true
  config.projects = { [workspace]: { hasTrustDialogAccepted: true } }
  assert.equal(config.cachedGrowthBookFeatures, undefined)
  assert.equal(config.growthBookOverrides, undefined)
  await writeFile(configPath, JSON.stringify(config, null, 2) + '\n')

  const ready = join(workspace, 'terminal-ready')
  const receipt = join(workspace, 'native-predicate.json')
  const preload = join(workspace, 'observe.mjs')
  await writeFile(preload, admissionObserver(ready, receipt))
  let terminal = '', acceptedFixtureKey = false, exitWhenRead, confirmExit
  let run
  try {
    run = await record({
      executable: '/usr/bin/python3',
      args: [bridge, sandbox, '-p', networkProfile, executable, '--model', 'sonnet', '--tools', '', '--strict-mcp-config', '--setting-sources', ''],
      cwd: workspace, output: join(workspace, 'evidence'), timeoutMs: 12000, maxBytes: 250000,
      env: { ...credentials, PATH: '/usr/bin:/bin', TMPDIR: workspace, TERM: 'xterm-256color', COLUMNS: '100', LINES: '30',
        DISABLE_AUTOUPDATER: '1', DISABLE_TELEMETRY: '1', DISABLE_ERROR_REPORTING: '1', BUN_OPTIONS: '--preload=' + preload },
      onStdout(bytes, controls) {
        terminal += bytes.toString('utf8')
        const screen = stripVTControlCharacters(terminal)
        if (profile === 'api-key' && !acceptedFixtureKey && screen.replace(/\s/g, '').includes('DoyouwanttousethisAPIkey?')) {
          acceptedFixtureKey = true
          controls.send('\x1b[A\r')
          return
        }
        if (exitWhenRead || !/for shortcuts|shift\+tab to cycle/.test(screen)) return
        writeFileSync(ready, 'ready')
        exitWhenRead = setInterval(() => {
          if (!existsSync(receipt)) return
          clearInterval(exitWhenRead)
          controls.send('\x04')
          confirmExit = setTimeout(() => controls.send('\x04'), 220)
        }, 70)
      },
    })
  } finally {
    clearInterval(exitWhenRead)
    clearTimeout(confirmExit)
  }
  const original = JSON.parse(await readFile(receipt, 'utf8').catch(() => 'null'))
  const ack = JSON.parse(await readFile(configPath, 'utf8')).hasAcknowledgedCostThreshold
  const metered = billingType === 'usage_based'
  const verified = run.status === 'complete' && original?.predicateSha256 === predicateSha256
    && original.oauthMode === (profile === 'oauth') && original.meteredBilling === metered
    && original.admitted === metered && ack !== true
  results.push({ profile, billingType, original, verified, run })
}
const proof = { binarySha256, predicateSha256, networkCheckErrno: Number(networkCheck.stdout), results }
await writeFile(join(parent, 'cost-warning-admission.json'), JSON.stringify(proof, null, 2) + '\n')
console.log(JSON.stringify(proof, null, 2))
if (!results.every(result => result.verified)) process.exitCode = 1
