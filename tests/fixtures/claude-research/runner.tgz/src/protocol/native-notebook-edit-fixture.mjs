import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

export const notebookBefore='print("Review pending")\n';
export const notebookAfter='print("Release reviewed")\n';
export const notebookInserted='## Release summary\n\nMigration guidance has been reviewed.';
export const notebookNotes='# Original notes\nKeep the migration checklist.';
export function nativeNotebookSteps(workspace){return [
 {id:'native_notebook_read',name:'Read',input:{file_path:join(workspace,'release-review.ipynb')}},
 {id:'native_notebook_replace',name:'NotebookEdit',input:{notebook_path:join(workspace,'release-review.ipynb'),cell_id:'analysis',new_source:notebookAfter,edit_mode:'replace'}},
 {id:'native_notebook_insert',name:'NotebookEdit',input:{notebook_path:join(workspace,'release-review.ipynb'),cell_id:'analysis',new_source:notebookInserted,cell_type:'markdown',edit_mode:'insert'}},
 {id:'native_notebook_delete',name:'NotebookEdit',input:{notebook_path:join(workspace,'release-review.ipynb'),cell_id:'notes',new_source:'',edit_mode:'delete'}},
 ];}
export async function addNativeNotebookEditFixture(workspace,plugin){
 await writeNativeNotebookFixture(workspace);
 const path=join(workspace,'.claude/settings.json'),settings=JSON.parse(await readFile(path,'utf8'));settings.permissions.ask=[...new Set([...settings.permissions.ask,'NotebookEdit'])];await writeFile(path,JSON.stringify(settings));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface==='desktop'&&/^native_notebook_(?:read|replace|insert|delete)$/.test(e.props.tool_use_id))await $.fs.write('native-notebook-result-'+e.props.tool_use_id+'.json',JSON.stringify({props:e.props}));return next(e)});}`);
}
export async function verifyNativeNotebookEdit(workspace,calls,proof){
 const notebook=JSON.parse(await readFile(join(workspace,'release-review.ipynb'),'utf8'));assert.equal(notebook.cells.length,3);
 const source=cell=>Array.isArray(cell.source)?cell.source.join(''):cell.source;
 assert.equal(source(notebook.cells.find(cell=>cell.id==='analysis')),notebookAfter);
 assert.equal(source(notebook.cells.find(cell=>cell.id==='notes')),notebookNotes);
 assert.equal(source(notebook.cells[1]),notebookInserted);assert.equal(notebook.cells[1].cell_type,'markdown');assert.notEqual(notebook.cells[1].id,'analysis');
 const results=calls.flatMap(call=>call.notebookResults??[]),find=id=>results.find(row=>row.tool_use_id===id);
 for(const id of ['native_notebook_read','native_notebook_replace','native_notebook_insert']){const row=find(id);assert.ok(row);assert.notEqual(row.is_error,true);}
 const denied=find('native_notebook_delete');assert.equal(denied?.is_error,true);assert.match(JSON.stringify(denied.content),/Keep the original migration notes/);
 assert.deepEqual(proof.previews.map(row=>row.mode),['replace','insert','delete']);assert.equal(proof.retainedDraft,true);assert.equal(proof.captures.length,8);
 return {originalReadAndEdits:true,insertedAfterOriginalCell:true,deniedDeleteUnchanged:true,denialFeedbackDelivered:true,cellIds:notebook.cells.map(cell=>cell.id)};
}

export async function writeNativeNotebookFixture(workspace){
 await writeFile(join(workspace,'release-review.ipynb'),JSON.stringify({nbformat:4,nbformat_minor:5,metadata:{kernelspec:{name:'python3',display_name:'Python 3',language:'python'},language_info:{name:'python'}},cells:[{id:'analysis',cell_type:'code',metadata:{},execution_count:null,outputs:[],source:[notebookBefore]},{id:'notes',cell_type:'markdown',metadata:{},source:[notebookNotes]}]}));
}
