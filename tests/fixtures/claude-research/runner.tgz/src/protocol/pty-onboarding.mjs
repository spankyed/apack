import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {hash} from '../artifacts/runs.mjs';
import {record} from './record.mjs';

export function recognizeOnboardingPrompt(terminal,workspace,{apiKeySuffix}={}) {
 const text=terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');
 if(workspace&&text.includes(`Accessingworkspace:${workspace.replace(/\s/g,'')}Quicksafetycheck:`)&&text.includes('Yes,Itrustthisfolder')&&text.includes('No,exit')){
  const yes=text.lastIndexOf('❯Yes,Itrustthisfolder'),no=text.lastIndexOf('❯No,exit');
  return yes>no?'workspace-trust-selected':no>yes?'workspace-trust':null;
 }
 // Authentication is opt-in and bound to the explicitly owned credential display.
 if(typeof apiKeySuffix==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(apiKeySuffix)&&text.includes('DetectedacustomAPIkeyinyourenvironment')&&text.includes('ANTHROPIC_API_KEY:sk-ant-...'+apiKeySuffix+'DoyouwanttousethisAPIkey?')&&text.includes('Entertoconfirm')){
  const yes=text.lastIndexOf('❯Yes'),no=text.lastIndexOf('❯No(recommended)');
  return yes>no?'environment-api-key-selected':no>yes?'environment-api-key':null;
 }
 if(text.includes('Securitynotes:')&&text.includes('PressEntertocontinue'))return 'security-notes';
 if(text.includes('Choosethetextstylethatlooksbestwithyourterminal')&&text.includes('Darkmode'))return 'theme';
 return null;
}

/** Respond only to recognized onboarding and exact own-workspace trust screens. */
export async function probePtyOnboarding(executable,workspace,output) {
 if(process.platform!=='darwin')throw new Error('Only verified on macOS');
 await mkdir(workspace,{recursive:true});const cwd=await mkdtemp(join(workspace,'pty-onboarding-'));
 const bridge=fileURLToPath(new URL('./pty_bridge.py',import.meta.url));
 let terminal='',themeSelected=false,securityNotesAcknowledged=false,trustNavigationSent=false,trustConfirmationSent=false,nativeIdleObserved=false,exitKeysSent=0,observationTimer;const timers=[];
 try {
  const run=await record({executable:'/usr/bin/python3',cwd,output,timeoutMs:12000,
   args:[bridge,executable,'--bare','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--tools','','--strict-mcp-config'],
   env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),TERM:'xterm-256color',COLUMNS:'100',LINES:'30',ANTHROPIC_BASE_URL:'http://127.0.0.1:9',DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},
   onStdout(bytes,transport){
    terminal+=bytes.toString('utf8');
    const screen=recognizeOnboardingPrompt(terminal,cwd);
    const theme=screen==='theme'&&!themeSelected;
    const security=screen==='security-notes'&&themeSelected&&!securityNotesAcknowledged;
    const navigate=screen==='workspace-trust'&&!trustNavigationSent;
    const confirm=screen==='workspace-trust-selected'&&trustNavigationSent&&!trustConfirmationSent;
    const compact=terminal.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\s/g,'');
    const idle=trustConfirmationSent&&!nativeIdleObserved&&compact.includes('APIUsageBilling')&&compact.includes('shift+tabtocycle');
    const exitAgain=exitKeysSent===1&&/pressctrl[+-]dagaintoexit/i.test(compact);
    if(theme||security||navigate||confirm||idle||exitAgain){
     if(theme)themeSelected=true;
     else if(security)securityNotesAcknowledged=true;
     else if(navigate)trustNavigationSent=true;
     else if(confirm)trustConfirmationSent=true;
     else {nativeIdleObserved=true;exitKeysSent++;}
     timers.push(setTimeout(()=>transport.send(navigate?'\x1b[B':idle||exitAgain?'\x04':'\r'),150));
     clearTimeout(observationTimer);
     observationTimer=setTimeout(()=>transport.stop('post-onboarding-step-observation-bound'),3500);
    }
   }});
  const verified=run.status==='complete'&&themeSelected&&securityNotesAcknowledged&&trustConfirmationSent&&nativeIdleObserved&&exitKeysSent>0;
  const evidence={verified,targetSha256:hash(await readFile(executable)),bridgeSha256:hash(await readFile(bridge)),driverSha256:hash(await readFile(new URL(import.meta.url))),
   themeSelected,securityNotesAcknowledged,trustNavigationSent,trustConfirmationSent,nativeIdleObserved,exitKeysSent,userPromptsSent:0,authenticationChoicesSent:0,workspace:cwd,qualification:'Recognized onboarding, own-workspace trust and idle Ctrl-D exit only; no model conversation or plan approval verified.'};
  await writeFile(join(run.directory,'pty-onboarding.json'),JSON.stringify(evidence,null,2)+'\n');
  if(run.status==='complete'&&!verified){
   const manifestPath=join(run.directory,'manifest.json');
   const manifest=JSON.parse(await readFile(manifestPath,'utf8'));
   await writeFile(manifestPath,JSON.stringify({...manifest,status:'failed',verificationFailure:'onboarding-stages-incomplete'},null,2)+'\n');
  }
  return {...run,...evidence,status:verified?'complete':'failed'};
 }finally{clearTimeout(observationTimer);for(const timer of timers)clearTimeout(timer)}
}
