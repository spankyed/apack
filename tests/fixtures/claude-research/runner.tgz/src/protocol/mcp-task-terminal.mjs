import assert from 'node:assert/strict';
import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {recognizeOnboardingPrompt} from './pty-onboarding.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';
import {configureNativeCreditAccount} from './native-credit-account.mjs';
import {prepareNativeCreditTls,startNativeCreditBilling} from './native-credit-billing.mjs';
import {EFFORT_EVAL_ROUTE} from './native-effort-rollout.mjs';

const TOOL_USE_ID='toolu_research_fixture';
const COMPLETED_PAYLOAD='{"review":"complete"}';

function blocks(content) {
 return typeof content==='string'?[{type:'text',text:content}]:Array.isArray(content)?content:[];
}

function taskModelEvidence(calls) {
 const results=[],notifications=[];
 for(const {messages=[]} of calls){
  for(const message of messages){
   for(const block of blocks(message.content)){
    if(block.type==='tool_result'&&block.tool_use_id===TOOL_USE_ID)results.push(block);
    if(message.role==='user'&&block.type==='text'&&block.text.startsWith('<system-reminder>\n[SYSTEM NOTIFICATION - NOT USER INPUT]')){
     const match=/<task-notification>\n<task-id>([a-z0-9]+)<\/task-id>\n<status>completed<\/status>\n<summary>MCP task (owned-review-\d+) \(research\/review\) completed\.<\/summary>\n<result>\n([^\n]+)\n<\/result>\n<\/task-notification>/.exec(block.text);
     if(match&&match[3]===COMPLETED_PAYLOAD)notifications.push({localTaskId:match[1],serverTaskId:match[2],result:match[3]});
    }
   }
  }
 }
 const inlineCompletion=results.some(result=>!result.is_error&&blocks(result.content).some(block=>block.text===COMPLETED_PAYLOAD));
 return {results,notifications,inlineCompletion};
}

/** Native terminal admission using the default profile or an owned authenticated evaluation. */
export async function probeMcpTaskTerminal(executable,root,output,{ownedRollout=false}={}){
 assert.equal(process.platform,'linux');const targetSha256=hash(await readFile(executable));assert.equal(targetSha256,'2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');
 if(ownedRollout){
  const boundary=JSON.parse(await readFile('/control/offline-verified','utf8'));
  assert.ok(boundary.requireMcpTaskHostedEvaluation&&boundary.networkDisabled&&boundary.pinnedExecutableReadOnly);
 }
 await mkdir(root,{recursive:true});
 const cwd=await mkdtemp(join(root,ownedRollout?'native-credit-admission-mcp-task-':'mcp-task-terminal-'));
 const config=join(cwd,'config'),receipt=join(cwd,'tasks.jsonl');
 if(!ownedRollout)await mkdir(config);
 const server=fileURLToPath(new URL('./owned-mcp-task-server.mjs',import.meta.url));
 const run=await createRun(output,'mcp-task-terminal',{targetSha256,driverSha256:hash(await readFile(new URL(import.meta.url))),serverSha256:hash(await readFile(server)),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),platform:process.platform,arch:process.arch,nodeVersion:process.version,ptyBridgeSha256:hash(await readFile(new URL('./pty_bridge.py',import.meta.url))),scope:'Original interactive terminal admission',ownedHostedEvaluation:ownedRollout});
 const model=await startSyntheticModel(cwd,'mcp__research__review',{mcpTaskScenario:'complete',captureMessages:true,maxRequests:6});
 let billing;
 let transport,screen='',theme=false,security=false,navigated=false,trusted=false,exiting=false;
 const timers=[];
 const interval=setInterval(()=>{
  if(!transport||exiting)return;
  const evidence=taskModelEvidence(model.calls);
  if(evidence.inlineCompletion||evidence.notifications.length||evidence.results.some(result=>result.is_error)){
   exiting=true;
   timers.push(setTimeout(()=>transport.send('\x04'),500),setTimeout(()=>transport.send('\x04'),1200));
  }
 },100);
 try{
  let account={HOME:cwd,CLAUDE_CONFIG_DIR:config,CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'};
  let settings=['--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})];
  const taskEnv={APACK_MCP_TASK_RECEIPT:receipt};
  if(ownedRollout){
   account=await configureNativeCreditAccount(cwd,'oauth',{featureCache:'native-defaults'});
   const tls=await prepareNativeCreditTls(join(cwd,'account-tls'));
   billing=await startNativeCreditBilling(tls,{mcpTaskRollout:true,evidencePath:join(run.directory,'hosted-evaluation.json')});
   account.NODE_EXTRA_CA_CERTS=tls.ca;
   settings=[];
   taskEnv.APACK_MCP_ADVERTISE_TASKS='1';
  }
  const mcpConfig={mcpServers:{research:{type:'stdio',command:process.execPath,args:[server],env:taskEnv}}};
  const probe=await record({executable:'/usr/bin/python3',cwd,output,timeoutMs:35000,maxBytes:1048576,
   args:[fileURLToPath(new URL('./pty_bridge.py',import.meta.url)),executable,'--setting-sources','',...settings,
    '--strict-mcp-config','--mcp-config',JSON.stringify(mcpConfig),'--allowed-tools','mcp__research__review','--','Run the owned task review once.'],
   env:{PATH:process.env.PATH,...account,TERM:'xterm-256color',ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1'},
   onStdout(bytes,controls){
    transport=controls;screen+=bytes.toString();
    const kind=recognizeOnboardingPrompt(screen,cwd);
    let key,delay=150;
    if(kind==='theme'&&!theme){theme=true;key='\r';}
    else if(kind==='security-notes'&&!security){security=true;key='\r';}
    // Allow the new native dialog's fresh-keypress guard to settle. The path and
    // selected action must still match the original owned-workspace screen.
    else if(kind==='workspace-trust'&&!navigated){navigated=true;key='\x1b[B';delay=500;}
    else if(kind==='workspace-trust-selected'&&!trusted){trusted=true;key='\r';delay=500;}
    if(key)timers.push(setTimeout(()=>controls.send(key),delay));
   }});
  assert.equal(probe.status,'complete','Original interactive terminal ended with '+probe.reason+'; inspect '+probe.directory);
  const frames=(await readFile(receipt,'utf8')).trim().split('\n').map(JSON.parse),incoming=frames.filter(x=>x.direction==='in').map(x=>x.value),calls=incoming.filter(x=>x.method==='tools/call'),polls=incoming.filter(x=>x.method==='tasks/get');
  assert.equal(calls.length,1);
  const modelEvidence=taskModelEvidence(model.calls);
  assert.ok(modelEvidence.results.length,'Original correlated result must reach subsequent model context');
  const advertised=frames.some(frame=>frame.direction==='out'
   &&frame.value.result?.capabilities?.extensions?.['io.modelcontextprotocol/tasks']!==undefined);
  const hostedEvaluation=Boolean(billing?.state.requests.some(row=>row.method==='POST'&&row.path===EFFORT_EVAL_ROUTE&&row.syntheticAuth&&row.status===200));
  const offered=frames.filter(frame=>frame.direction==='out'&&frame.value.result?.resultType==='task');
  const nativeTaskPollingObserved=polls.length>0;
  const handle=offered[0]?.value.result;
  const backgroundCompletion=handle&&modelEvidence.notifications.find(notification=>
   notification.serverTaskId===handle.taskId&&modelEvidence.results.some(result=>!result.is_error
     &&blocks(result.content).some(block=>block.text?.includes('started server-side task '+handle.taskId+'.')
       &&block.text.includes('moved to the background as task '+notification.localTaskId+' '))));
  const completed=modelEvidence.inlineCompletion||Boolean(backgroundCompletion);
  const admitted=advertised&&hostedEvaluation&&offered.length===1&&nativeTaskPollingObserved
   &&polls.every(poll=>poll.params?.taskId===handle.taskId)&&completed;
  const report={targetSha256,transport:{status:probe.status,code:probe.code},taskHandleOffered:offered.length>0,
   advertised,hostedEvaluation,nativeTaskPollingObserved,admitted,results:modelEvidence.results,frames,
   completion:backgroundCompletion?{route:'background',...backgroundCompletion}
    :modelEvidence.inlineCompletion?{route:'inline'}:null,
   syntheticModelRequests:model.calls.length,realModelRequests:0,
   qualification:'Original terminal tool admission, correlated poll and model-facing completion only. The synthetic cohort uses the original authenticated evaluation. Desktop task input, Stop and unknown-outcome behavior require separate proof.'};
  await writeFile(join(run.directory,'mcp-task-terminal.json'),JSON.stringify(report,null,2)+'\n');await run.finish({status:'complete'});return {directory:run.directory,...report};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}finally{
  clearInterval(interval);for(const timer of timers)clearTimeout(timer);
  try{
   await writeFile(join(run.directory,'model-calls.json'),JSON.stringify(model.calls,null,2));
   try{await writeFile(join(run.directory,'server-receipts.jsonl'),await readFile(receipt));}catch(error){if(error.code!=='ENOENT')throw error;}
  }finally{await Promise.all([model.close(),billing?.close()]);}
 }
}
