import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,readdir,realpath} from 'node:fs/promises';
import {join,sep} from 'node:path';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Only fixed task records under private HOME; no peer owner, background process or external tool. */
export async function probeTaskLifecycle(executable,root,output,{deletion=false}={}){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'task-lifecycle-')),home=join(workspace,'home'),cwd=join(workspace,'project');await mkdir(join(home,'.claude'),{recursive:true});await mkdir(cwd);
 const run=await createRun(output,deletion?'task-deletion':'task-lifecycle',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
 let model,pending='',initialized=false;const permissions=[],toolResults=[],structuredResults=[],results=[];
 try{
  model=await startSyntheticModel(cwd,deletion?'TaskDeletion':'TaskLifecycle',{maxRequests:16});
  const transport=await record({executable,cwd,output,timeoutMs:30000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--strict-mcp-config','--permission-mode','default','--tools','default','--model','sonnet','--no-session-persistence','--max-turns','16'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',CLAUDE_CODE_ENABLE_TODO_TOOLS:'1',CLAUDE_CODE_ENABLE_TASKS:'1'},input:[JSON.stringify({type:'control_request',request_id:'task-init',request:{subtype:'initialize'}})+'\n'],onStdout(bytes,channel){
   pending+=bytes.toString();while(pending.includes('\n')){const at=pending.indexOf('\n'),text=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(text)}catch{continue}
    if(value.type==='control_response'&&value.response?.request_id==='task-init'){assert.equal(value.response.subtype,'success');initialized=true;channel.send(JSON.stringify({type:'user',message:{role:'user',content:'Execute only the fixed private native task lifecycle fixture.'}})+'\n');}
    if(value.type==='control_request'&&value.request?.subtype==='can_use_tool'){
     assert.ok(['TaskCreate','TaskGet','TaskList','TaskUpdate','ToolSearch'].includes(value.request.tool_name));permissions.push(value.request.tool_name);channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:{behavior:'allow',updatedInput:value.request.input}}})+'\n');
    }
    if(value.type==='user'&&Array.isArray(value.message?.content)){const blocks=value.message.content.filter(block=>block.type==='tool_result');toolResults.push(...blocks);if(value.tool_use_result!==undefined)structuredResults.push({toolUseIds:blocks.map(block=>block.tool_use_id),value:value.tool_use_result});}
    if(value.type==='result'){results.push(value);channel.closeInput();}
   }
  }});
  assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(initialized,true);assert.equal(results.length,1);assert.equal(results[0].subtype,'success');assert.equal(results[0].is_error,false);
  const taskResults=toolResults.filter(result=>result.tool_use_id.startsWith('task_')&&result.tool_use_id!=='task_search_fixture');assert.equal(taskResults.length,deletion?12:9);assert.ok(taskResults.slice(0,-1).every(result=>!result.is_error));
  const taskRoot=join(home,'.claude','tasks');let taskFiles=[];try{taskFiles=await readdir(taskRoot,{recursive:true});}catch(error){if(error.code!=='ENOENT')throw error;}
  assert.equal(structuredResults.length,deletion?12:9);const values=structuredResults.map(result=>result.value);
  assert.deepEqual(values[0],{tasks:[]});assert.equal(values[1].task.subject,'NativeTaskFixture');const id=values[1].task.id;assert.match(id,/^\d{1,10}$/);
  assert.equal(values[2].task.status,'pending');assert.deepEqual(values[3].statusChange,{from:'pending',to:'in_progress'});assert.equal(values[3].success,true);
  assert.equal(values[4].tasks[0].status,'in_progress');assert.deepEqual(values[5].statusChange,{from:'in_progress',to:'completed'});assert.equal(values[5].success,true);
  assert.equal(values[6].task.status,'completed');assert.equal(values[7].tasks[0].status,'completed');assert.deepEqual(values[8],{task:null});assert.ok(!taskResults.at(-1).is_error);
  assert.equal(model.calls.length,deletion?13:10);assert.equal(permissions.length,0);
  const persistedPaths=taskFiles.filter(file=>file.endsWith('/'+id+'.json'));assert.equal(persistedPaths.length,deletion?0:1);
  let persistedTask=null;
  if(!deletion){
  const persistedPath=await realpath(join(taskRoot,persistedPaths[0]));assert.ok(persistedPath.startsWith((await realpath(home))+sep));
  persistedTask=JSON.parse(await readFile(persistedPath,'utf8'));assert.equal(persistedTask.status,'completed');assert.equal(persistedTask.subject,'NativeTaskFixture');
  }else{
   assert.deepEqual(values[9],{success:true,taskId:id,updatedFields:['deleted'],statusChange:{from:'completed',to:'deleted'}});
   assert.deepEqual(values[10],{task:null});
   assert.deepEqual(values[11],{success:false,taskId:id,updatedFields:[],error:'Task not found'});
   assert.ok(!taskResults[11].is_error);
  }
  const evidence={structuredResults,persistedTask,enabledGates:{CLAUDE_CODE_ENABLE_TODO_TOOLS:true,CLAUDE_CODE_ENABLE_TASKS:true},permissions,taskResults,taskFiles,modelCalls:model.calls,realModelRequests:0,deletion,qualification:'Fixed isolated TaskList/Create/Get/Update sequence and missing-id read. Includes deletion and missing-update receipts only when deletion=true. Not peer ownership, dependencies, cross-session policy, app/mounted UI or all enabled modes.'};
  const sanitized=JSON.parse(JSON.stringify(evidence).split(workspace).join('${WORKSPACE}'));await writeFile(join(run.directory,'task-lifecycle.json'),JSON.stringify(sanitized,null,2)+'\n');await run.finish({status:'complete',transportRun:transport.directory});return {directory:run.directory,status:'complete',...sanitized};
 }catch(error){await writeFile(join(run.directory,'failed-observations.json'),JSON.stringify({permissions,toolResults,structuredResults,results,modelCalls:model?.calls??[]},null,2)+'\n');await run.finish({status:'failed',error:error.message});throw error;}finally{await model?.close();}
}
