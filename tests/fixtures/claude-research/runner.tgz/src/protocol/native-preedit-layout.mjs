/** Browser-side evidence: compare the preedit field with the original prompt's mirrored row. */
export function measureNativePreeditLayout(field, prefix) {
  const terminal = field.closest('[data-native-terminal]');
  const canvas = terminal?.querySelector('canvas');
  const mirror = terminal?.querySelector('[data-terminal-text]');
  if (!canvas || !mirror) return { ready: false };
  const rows = Array.from(mirror.children, row => row.textContent ?? '');
  const matches = rows.map((text, row) => ({ text, row })).filter(item => item.text.includes(prefix));
  if (matches.length !== 1) return { ready: false, matches: matches.length };
  const prompt = matches[0], column = prompt.text.indexOf(prefix) + prefix.length;
  const style = getComputedStyle(field), measure = document.createElement('canvas').getContext('2d');
  measure.font = style.font;
  const metrics = measure.measureText('M'), snap = value => Math.max(1, Math.round(value * devicePixelRatio)) / devicePixelRatio;
  const cellWidth = snap(metrics.width), cellHeight = Number.parseFloat(style.lineHeight);
  const drawing = canvas.getBoundingClientRect(), box = field.getBoundingClientRect();
  const expected = { x: drawing.x + column * cellWidth, y: drawing.y + prompt.row * cellHeight };
  const delta = { x: box.x - expected.x, y: box.y - expected.y };
  return { ready: true, prompt, column, cellWidth, cellHeight, expected, delta,
    box: { x: box.x, y: box.y, width: box.width, height: box.height },
    anchored: Number.isFinite(cellHeight) && Math.abs(delta.x) <= cellWidth && Math.abs(delta.y) <= cellHeight,
    scope: 'Chromium preedit field beside the original ASCII prompt prefix; no OS candidate-window claim.' };
}
