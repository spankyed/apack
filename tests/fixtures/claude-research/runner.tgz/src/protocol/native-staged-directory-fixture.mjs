import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';

/** Reusable against live captured calls or immutable saved evidence; never launches a process. */
export async function verifyNativeStagedDirectories(workspace, evidence, calls) {
  for (const key of ['actualAppGui','nativeStagedDirectories','nativeStagedDirectoryHandoff','nativeStagedDirectoryReopen','nativeStagedDirectoryRead','nativeRetainedDraft','resumedPrintSameSession']) assert.equal(evidence[key], true);
  assert.equal(evidence.sessionId, evidence.finalSessionId);
  assert.deepEqual(evidence.browserErrors, []);
  const proof = JSON.parse(await readFile(join(workspace, 'native-staged-directory-proof.json'), 'utf8'));
  const reference = JSON.parse(await readFile(join(workspace, 'reference-fixture.json'), 'utf8'));
  const directories = [proof.firstDirectory, proof.secondDirectory];
  assert.deepEqual(proof.additionalDirs, directories);
  assert.deepEqual(proof.launch.addDir, directories);
  assert.equal(proof.launch.sessionId, evidence.sessionId);
  assert.equal(proof.launch.cwd, workspace);
  assert.ok(proof.launch.allowedTools.includes('Read'));
  assert.ok(proof.launch.appendSystemPrompt.includes('Implement only what the plan specifies'));
  for (const [turn, file, content] of [[1, reference.file, reference.content], [2, reference.secondFile, reference.secondContent]]) {
    assert.equal(await readFile(file, 'utf8'), content);
    assert.ok(calls.agent.some(call => call.directoryTurn === turn && call.directoryResult
      && call.directoryResult.is_error !== true && JSON.stringify(call.directoryResult.content ?? '').includes(content)
      && Array.isArray(call.messages) && call.messages.some(message => Array.isArray(message.content) && message.content.some(block => block.type === 'tool_use' && block.name === 'Read' && block.input?.file_path === file))), 'Missing original Read result/path for staged folder ' + turn);
  }
  const jsonl = async name => (await readFile(join(workspace, name), 'utf8')).trim().split('\n').map(JSON.parse);
  const children = await jsonl('native-children.jsonl'), exits = await jsonl('native-exits.jsonl'), preloads = await jsonl('user-preload-calls.jsonl');
  assert.equal(children.length, 5);
  assert.equal(children[1].pid, evidence.boundNativePid);
  assert.equal(children[3].pid, evidence.reopenedNativePid);
  assert.notEqual(evidence.boundNativePid, evidence.reopenedNativePid);
  assert.ok(children[0].args.includes('--print'));
  assert.ok(children[1].args.includes(proof.firstDirectory));
  assert.ok(children[2].args.includes('--print') && children[2].args.includes('--no-session-persistence'));
  for (const child of [children[2], children[3]]) for (const directory of directories) assert.ok(child.args.includes(directory));
  assert.ok(children[3].args.includes('--resume')); assert.ok(children[4].args.includes('--print'));
  for (let index = 0; index < children.length; index++) {
    const child = children[index], exit = exits.find(row => row.pid === child.pid);
    assert.ok(exit && preloads.some(row => row.pid === child.pid));
    if (index < children.length - 1) assert.ok(exit.at <= children[index + 1].at, 'Native owner/preflight overlapped its successor');
    try { process.kill(child.pid, 0); assert.fail('Owned native child remains alive'); }
    catch (error) { assert.equal(error.code, 'ESRCH'); }
  }
  return { directories: 2, originalReads: 2, nativeProcesses: children.length, ownedShutdown: true, syntheticApiRequests: calls.seed.length + calls.agent.length, realModelRequests: 0 };
}
