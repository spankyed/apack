import { addEmptyKeyboardClientFixture } from './empty-keyboard-client-fixture.mjs';
import { readFile, writeFile, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';
import { createNativeTestImage } from './native-test-image.mjs';
/** Shared, private native fixture for source-owner and actual-app terminal Client acceptance. */
export async function addTerminalClientFixture(plugin) {
 if(process.env.CLAUDE_RESEARCH_EMPTY_KEYBOARD_CLIENT==='1')return addEmptyKeyboardClientFixture(plugin);
 const register=join(plugin,'hooks/register.ts');
 const hooks="export function register(on){const terminalEvents=[],terminalFields=[];for(const component of ['InfoNotice','TurnDuration'])on('ui.render',{component},async($,e,next)=>{if(e.surface!=='terminal')return next(e);const{Box,Client}=$.ui.resolve(e);return Box({flexDirection:'column',children:[await next(e),Client({key:'terminal-client',module:'./terminal-client.ts',props:{kind:component},width:48,height:12})]});});on('ui.input',async($,e,next)=>{if(e.element==='native-note'){terminalFields.push(e);await $.fs.write('native-terminal-client-fields.json',JSON.stringify(terminalFields));return next(e.value==='rewrite'?{...e,value:'native-value'}:e);}return next(e);});on('ui.message',async($,e,next)=>{if(e.data?.terminalClient!==true)return next(e);terminalEvents.push({...e.data,surface:e.surface,component:e.component});await $.fs.write('native-terminal-client-events.json',JSON.stringify(terminalEvents));return {props:{kind:e.data.kind}};});";
 await writeFile(register,(await readFile(register,'utf8')).replace('export function register(on){',hooks));
 await writeFile(join(plugin,'hooks/terminal-client.ts'),`export default function(props,s){const{Box,Text,Button,Input,Select}=s.elements;const post=()=>s.post({terminalClient:true,kind:props.kind,...s.state});if(s.state===undefined){s.setState({count:0,ticks:0,key:'none',note:'',choice:'a'});s.every(1000,()=>{s.setState({...s.state,ticks:s.state.ticks+1});post();});}s.onKey(e=>{s.setState({...s.state,key:e.key});post();});return Box({flexDirection:'column',children:[Text({children:[props.kind+' Client count='+s.state.count+' key='+s.state.key]}),Button({key:'native-increment',label:'Increment terminal Client',onPress:()=>{s.setState({...s.state,count:s.state.count+1});post();}}),Input({key:'native-note',label:'Terminal note',value:s.state.note,onInput:note=>{s.setState({...s.state,note});post();},onSubmit:note=>{s.setState({...s.state,note});post();}}),Select({key:'native-choice',label:'Terminal choice',value:s.state.choice,options:[{value:'a',label:'Alpha'},{value:'b',label:'Beta'}],onSelect:choice=>{s.setState({...s.state,choice});post();}})]});}`);
 if(process.env.CLAUDE_RESEARCH_RASTER==='1'){
  const cells=text=>{const bytes=Buffer.alloc(text.length*12);for(let i=0;i<text.length;i++){bytes.writeUInt32LE(text.charCodeAt(i),i*12);bytes.writeUInt32LE(0xff8800,i*12+4);bytes.writeUInt32LE(0x1000000,i*12+8)}return bytes.toString('base64')};
  const source=await readFile(register,'utf8');
  await writeFile(register,source.replace('export function register(on){','export function register(on){let rasterChanged=false;').replace('const{Box,Client}=','const{Box,Client,Raster}=').replace('children:[await next(e),Client(',`children:[await next(e),Raster({key:'release-raster',columns:8,rows:2,cells:rasterChanged?${JSON.stringify(cells('Release updated '))}:${JSON.stringify(cells('Release ready   '))}}),Client(`).replace('terminalEvents.push({...e.data',"if(e.data.key==='r'){rasterChanged=true;await $.ui.invalidate('ui.render');}terminalEvents.push({...e.data"));
  if(process.env.CLAUDE_RESEARCH_RASTER_BLIT==='1'){
   const initial=JSON.stringify(cells('Release ready   ')),blitted=JSON.stringify(cells('Release blitted ')),file=join(plugin,'hooks/terminal-client.ts');
   await writeFile(file,(await readFile(file,'utf8')).replace("s.setState({...s.state,key:e.key});","s.setState({...s.state,key:e.key,rasterKeySerial:(s.state.rasterKeySerial??0)+1});"));
   let source=await readFile(register,'utf8');
   source=source.replace('let rasterChanged=false;','let rasterChanged=false,rasterHidden=false;const rasterSites=new Map(),rasterHandled=new Map(),rasterBlits=[];');
   source=source.replace('const{Box,Client,Raster}=$.ui.resolve(e);','const{Box,Client,Raster}=$.ui.resolve(e);rasterSites.set(component,e.requestId);');
   source=source.replace(`Raster({key:'release-raster',columns:8,rows:2,cells:rasterChanged?${JSON.stringify(cells('Release updated '))}:${initial}})`,`...(rasterHidden?[]:[Raster({key:'release-raster',columns:8,rows:2,cells:${initial}})])`);
   source=source.replace("if(e.data.key==='r'){rasterChanged=true;await $.ui.invalidate('ui.render');}",`if(e.data.rasterKeySerial&&rasterHandled.get(e.requestId)!==e.data.rasterKeySerial){rasterHandled.set(e.requestId,e.data.rasterKeySerial);if(['b','f','x'].includes(e.data.key)){const result=await $.ui.blit({requestId:e.requestId,key:e.data.key==='x'?'foreign-raster':'release-raster',cells:${blitted},...(e.data.key==='f'?{columns:9}:{})});rasterBlits.push({requestId:e.requestId,key:e.data.key,serial:e.data.rasterKeySerial,result});await $.fs.write('native-raster-blits.json',JSON.stringify(rasterBlits));}if(['h','s'].includes(e.data.key)){rasterHidden=e.data.key==='h';await $.ui.invalidate('ui.render');}}`);
   await writeFile(register,source);
  }

 }

 if(process.env.CLAUDE_RESEARCH_IMAGE==='1'){
  if(process.env.CLAUDE_RESEARCH_RASTER==='1')throw Error('Select one terminal picture fixture');
  const pixels=process.env.CLAUDE_RESEARCH_IMAGE_PIXELS==='1';
  const png=pixels?'iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAEUlEQVR4nGP438HwH4QZYAwAW/oKGWP7FYAAAAAASUVORK5CYII=':'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=',file=join(plugin,'hooks/terminal-client.ts');
  await writeFile(file,(await readFile(file,'utf8')).replace("s.setState({...s.state,key:e.key});","s.setState({...s.state,key:e.key,imageKeySerial:(s.state.imageKeySerial??0)+1});"));
  let source=await readFile(register,'utf8');
  source=source.replace('export function register(on){','export function register(on){let imageUpdated=false,imageHidden=false;const imageHandled=new Map(),imageBlits=[];');
  source=source.replace('const{Box,Client}=','const{Box,Client,Image}=');
  source=source.replace('children:[await next(e),Client(',`children:[await next(e),...(imageHidden?[]:[Image({key:'release-image',source:{png:${JSON.stringify(png)}},columns:8,rows:2,alt:imageUpdated?'Release cover updated':'Release cover preview'})]),Client(`);
  source=source.replace('terminalEvents.push({...e.data',`if(e.data.imageKeySerial&&imageHandled.get(e.requestId)!==e.data.imageKeySerial){imageHandled.set(e.requestId,e.data.imageKeySerial);if(e.data.key==='b'){const result=await $.ui.blit({requestId:e.requestId,key:'release-image',source:${JSON.stringify(pixels?{rgba:'AIj//wCI//8AiP//AIj//w==',width:2,height:2}:{png})}});imageBlits.push({requestId:e.requestId,serial:e.data.imageKeySerial,result});await $.fs.write('native-image-blits.json',JSON.stringify(imageBlits));}if(['r','h','s'].includes(e.data.key)){if(e.data.key==='r')imageUpdated=true;else imageHidden=e.data.key==='h';await $.ui.invalidate('ui.render');}}terminalEvents.push({...e.data`);
  if(process.env.CLAUDE_RESEARCH_IMAGE_FILES==='1'){
   if(!pixels)throw Error('Named Image fixture requires pixel acceptance');
   const initial=join(plugin,'release-cover.png'),updated=join(plugin,'release-cover-updated.png'),raw=join(plugin,'release-cover.rgba');
   await writeFile(initial,Buffer.from(png,'base64'));await writeFile(updated,createNativeTestImage([0,200,80,255]));await writeFile(raw,Buffer.from('AIj//wCI//8AiP//AIj//w==','base64'));
   await writeFile(join(plugin,'..','native-image-files.json'),JSON.stringify({initial,updated,raw}));
   source=source.replace(`source:{png:${JSON.stringify(png)}}`,`source:{file:${JSON.stringify(initial)},format:'png',generation:imageUpdated?1:0}`);
   source=source.replace(JSON.stringify({rgba:'AIj//wCI//8AiP//AIj//w==',width:2,height:2}),JSON.stringify({file:raw,format:'rgba',width:2,height:2}));
  }
  if(process.env.CLAUDE_RESEARCH_IMAGE_SHM==='1'){
   if(!pixels||process.env.CLAUDE_RESEARCH_IMAGE_FILES==='1'||process.platform!=='linux')throw Error('Shared Image fixture requires explicit Linux pixel profile');
   const prefix='/apack_cc_'+randomBytes(6).toString('hex'),initial=prefix+'_a',blit=prefix+'_b',owned=[];
   try{
    await writeFile('/dev/shm/'+initial.slice(1),Buffer.from([255,136,0,255,136,0,255,136,0,255,136,0]),{flag:'wx',mode:0o600});owned.push(initial);
    await writeFile('/dev/shm/'+blit.slice(1),Buffer.from([0,136,255,0,136,255,0,136,255,0,136,255]),{flag:'wx',mode:0o600});owned.push(blit);
    await writeFile(join(plugin,'..','native-image-shm.json'),JSON.stringify({initial,blit,format:'rgb',width:2,height:2}));
    source=source.replace(`source:{png:${JSON.stringify(png)}}`,`source:{shm:${JSON.stringify(initial)},format:'rgb',width:2,height:2,generation:imageUpdated?1:0}`);
    source=source.replace(JSON.stringify({rgba:'AIj//wCI//8AiP//AIj//w==',width:2,height:2}),JSON.stringify({shm:blit,format:'rgb',width:2,height:2}));
    source=source.replace("['r','h','s'].includes(e.data.key)","['r','h','s','d'].includes(e.data.key)");
    await writeFile(register,source);return;
   }catch(error){for(const name of owned)await unlink('/dev/shm/'+name.slice(1)).catch(()=>{});throw error;}
  }
  await writeFile(register,source);
 }

}
