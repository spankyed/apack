import assert from 'node:assert/strict';

export const nativeComposerProducerSignatures = Object.freeze({
  Spinner: { name: 'vtr', sha256: '303032488d6858b55a00a4718644628955b5beadbdf79e9161609313fe9ee5e2' },
  TurnDuration: { name: 'Pg', sha256: '53b5427fec9b423983b721ed3152f419c62aab735d8d0fc50a797d92c80c40a8' },
  InfoNotice: { name: 'Uo', sha256: '32790fda3445a2da7f59d62c7e62ea9ecdb8602f82e5ab51b0497e192d687ef1' },
  SessionMode: { name: 'OH', sha256: '102949adbd5d8849d10b15d5d7bc64d7e98466e46a23fa0ad704c86ae02b8b8a' },
  PromptHint: { name: 'vY', sha256: '0e01508dc7198c1522cbf5658ec5b6b83f4ce8068ddeee35694dc501b6103dd5' },
});

/** Validate discovery against frozen source identity; observing inputs does not implement app mounts. */
export function verifyNativeComposerSites(report) {
  assert.equal(report.readOnly, true);
  assert.equal(report.error, undefined);
  assert.ok(Array.isArray(report.samples) && report.samples.length > 0 && report.samples.length <= 64);
  assert.ok(Array.isArray(report.producers) && report.producers.length <= 64);
  const matched = new Set();
  for (const sample of report.samples) {
    assert.ok(Number.isSafeInteger(sample.fibers) && sample.fibers >= 0 && sample.fibers <= 4096);
    assert.ok(Array.isArray(sample.inputs) && sample.inputs.length <= 32);
    if (sample.fibers === 0) assert.equal(sample.inputs.length, 0);
    for (const input of sample.inputs) {
      const expected = nativeComposerProducerSignatures[input.component];
      assert.ok(expected, 'Unknown native composer component');
      const producer = report.producers.find(item => input.producer === item.name + ':' + item.functionSha256);
      assert.ok(producer && producer.name === expected.name && producer.functionSha256 === expected.sha256, 'Native composer producer identity differs from frozen source');
      assert.ok(typeof input.requestId === 'string' && input.requestId.length > 0);
      assert.ok(input.props && typeof input.props === 'object' && !Array.isArray(input.props));
      matched.add(input.component);
    }
  }
  assert.deepEqual([...matched].sort(), Object.keys(nativeComposerProducerSignatures).sort(), 'Missing native composer producer inputs');
  return { components: [...matched].sort(), samples: report.samples.length, exactRecoveredFunctionIdentity: true };
}

/** Read-only discovery of original composer producer inputs; no app support is inferred. */
export function nativeComposerSites(outputPath) {
  return `
{
 const fs=await import('node:fs'),crypto=await import('node:crypto');
 const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
 if(hash(fs.readFileSync(process.execPath))==='5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37'){
  const roots=await import('/$bunfs/root/chunk-pg10s5g1.js'),spinner=await import('/$bunfs/root/chunk-d7rqk9yn.js'),runtime=await import('/$bunfs/root/chunk-hqtnbrjd.js');
  const components=new Set(['Spinner','TurnDuration','InfoNotice','SessionMode','PromptHint']);
  const samples=[],producers=new Map();let previous,busy=false;const deadline=Date.now()+100000;
  const copy=(value,depth=0)=>{
   if(value===null||typeof value==='boolean'||typeof value==='number')return value;
   if(typeof value==='string')return value.slice(0,2048);
   if(depth>=4||!value||typeof value!=='object')return undefined;
   if(Array.isArray(value))return value.slice(0,32).map(item=>copy(item,depth+1));
   return Object.fromEntries(Object.keys(value).slice(0,32).map(key=>[key,copy(value[key],depth+1)]));
  };
  const save=()=>fs.writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({readOnly:true,maximumFibers:4096,maximumHooksPerFiber:128,maximumSamples:64,spinnerExportName:spinner.vtr.name,producers:[...producers.values()],samples},null,2),{mode:0o600});
  const timer=setInterval(()=>{if(busy)return;if(Date.now()>deadline){clearInterval(timer);return;}busy=true;try{
   if(runtime.ey()?.surface!=='terminal')return;
   const root=roots.ai().get(process.stdout)?.container?.current,pending=root?[root]:[],seen=new Set(),inputs=[];let truncatedHookFibers=0;
   while(pending.length){
    const fiber=pending.pop();if(!fiber||seen.has(fiber))continue;if(seen.size>=4096)throw Error('Composer producer traversal bound');seen.add(fiber);
    const type=fiber.type,exportIdentity=type===spinner.vtr||fiber.elementType===spinner.vtr||spinner.vtr.type&&type===spinner.vtr.type;
    const found=[],shapes=[],hooks=new Set();let hook=fiber.memoizedState;
    while(hook&&typeof hook==='object'&&!hooks.has(hook)){
     if(hooks.size>=128){truncatedHookFibers++;break;}hooks.add(hook);
     const value=hook.memoizedState,candidates=[value,...(Array.isArray(value)?value.slice(0,4):[])];
     for(const input of candidates)if(input&&typeof input==='object'&&!Array.isArray(input)&&components.has(input.component)&&input.surface==='terminal'&&typeof input.requestId==='string'&&input.props&&typeof input.props==='object')found.push(input);
     if(exportIdentity)shapes.push(Array.isArray(value)?{kind:'array',length:value.length,first:typeof value[0]}:{kind:typeof value,keys:value&&typeof value==='object'?Object.keys(value).slice(0,8):[]});
     hook=hook.next;
    }
    if(found.length||exportIdentity){
     const source=typeof type==='function'?Function.prototype.toString.call(type):'',signature=hash(source),key=(type?.name??'object')+':'+signature;
     if(!producers.has(key)&&producers.size<64)producers.set(key,{name:type?.name,functionSha256:signature,functionSource:source.slice(0,16384),sourceTruncated:source.length>16384,spinnerExportIdentity:!!exportIdentity,hooks:shapes,updateQueueKeys:Object.keys(fiber.updateQueue??{}).slice(0,16)});
     for(const input of found){const entry={component:input.component,producer:key,requestId:input.requestId,props:copy(input.props)};if(inputs.length<32&&!inputs.some(item=>JSON.stringify(item)===JSON.stringify(entry)))inputs.push(entry);}
    }
    if(fiber.sibling)pending.push(fiber.sibling);if(fiber.child)pending.push(fiber.child);
   }
   const key=JSON.stringify(inputs)+':'+seen.size;if(key!==previous&&samples.length<64){previous=key;samples.push({fibers:seen.size,truncatedHookFibers,inputs});save();}
  }catch(error){fs.writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({readOnly:true,producers:[...producers.values()],samples,error:String(error).slice(0,512)}),{mode:0o600});}finally{busy=false}},100);timer.unref();
 }
}
`;
}
