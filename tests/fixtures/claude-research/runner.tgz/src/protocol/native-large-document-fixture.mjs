import {writeFile} from 'node:fs/promises';
import {join} from 'node:path';
export const largeDocumentCode=Array.from({length:700},(_,index)=>`export const migration${index+1} = { from: ${index}, to: ${index+1}, guide: "Keep the upgrade example" };`).join('\n');
export const largeDocumentMarkdown=Array.from({length:180},(_,index)=>`## Migration ${index+1}\n\nReview the compatibility notes before deployment. Keep the upgrade example and rollback instructions with the release.\n\n- Preserve existing settings.\n- Verify the migrated workspace.\n`).join('\n');
/** A normal Read result with source/guide navigation, using only original native UI elements. */
export async function addNativeLargeDocumentFixture(plugin,workspace){
 await writeFile(join(workspace,'large-document-fixture.json'),JSON.stringify({code:largeDocumentCode,markdown:largeDocumentMarkdown}));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){let tab='source';on('ui.render',{component:'ToolResult'},async($,e,next)=>{if(e.surface!=='desktop'||e.props.tool_use_id!=='native_reference_read'||e.props.isErrored)return next(e);const{Box,Text,Button,Code,Markdown}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Box({flexDirection:'row',gap:1,children:[Button({key:'source',label:'Source',onPress:()=>{tab='source';$.ui.invalidate('ui.render');}}),Button({key:'guide',label:'Guide',onPress:()=>{tab='guide';$.ui.invalidate('ui.render');}})]}),Text({children:[tab==='source'?'Migration registry':'Migration guide']}),tab==='source'?Code({source:${JSON.stringify(largeDocumentCode)},language:'javascript',startLine:1}):Markdown({text:${JSON.stringify(largeDocumentMarkdown)}})]});});}`);
}
