import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

const text=content=>typeof content==='string'?content:(Array.isArray(content)?content.filter(block=>block.type==='text').map(block=>block.text).join('\n'):'');
const images=content=>Array.isArray(content)?content.filter(block=>block.type==='image'):[];
const lastUser=call=>[...(call.messages??[])].reverse().find(message=>message.role==='user');

/** Compare actual app state with original owner-addressed reads, journals and model requests. */
export async function verifyNativeAgentRoundtrip(workspace,evidence,calls){
 const proof=JSON.parse(await readFile(join(workspace,'native-agent-roundtrip-proof.json'),'utf8'));
 assert.equal(evidence.nativeAgentRoundtrip,true);assert.equal(proof.sessionId,evidence.sessionId);assert.equal(evidence.finalSessionId,evidence.sessionId);
 for(const key of ['actualAgentRemount','parentMediaRetained','exactDocumentsAndSelections'])assert.equal(proof[key],true,key);
 assert.ok(proof.parentState.doc&&proof.agentState.doc&&proof.parentState.selection&&proof.agentState.selection);
 assert.notDeepEqual(proof.parentState.doc,proof.agentState.doc);assert.equal(proof.parentState.canonical,proof.parentDraftCanonical);assert.equal(proof.parentCanonical,proof.parentDraftCanonical.replace(/(\n&nbsp;)+$/, '').trim());assert.equal(proof.agentState.canonical,proof.agentCanonical);
 for(const state of [proof.parentState,proof.agentState]){const document=JSON.stringify(state.doc);assert.match(document,/"type":"bold"/);assert.match(document,/"type":"italic"/);assert.match(document,/"type":"reference"/);}
 const parentReads=proof.reads.filter(row=>row.agentId===undefined),agentReads=proof.reads.filter(row=>row.agentId===proof.taskId);
 assert.equal(parentReads.length,2);assert.equal(agentReads.length,2);
 for(const rows of [parentReads,agentReads]){assert.equal(rows[0].value.text,rows[1].value.text);assert.equal(rows[0].value.cursor,rows[1].value.cursor);for(const row of rows)assert.equal(row.value.view?.agentId,row.agentId);}
 assert.equal(parentReads[0].value.text,proof.parentDraftCanonical);assert.equal(agentReads[0].value.text,proof.agentCanonical);
 assert.match(proof.parentImage,/^data:image\/png;base64,/);const imageData=proof.parentImage.split(',')[1],png=Buffer.from(imageData,'base64');assert.equal(png.readUInt32BE(16),160);assert.equal(png.readUInt32BE(20),96);
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>path.endsWith('.jsonl'));assert.ok(paths.length<200);
 const records=async selected=>{const result=new Map();for(const path of selected){const data=await readFile(join(root,path),'utf8');assert.ok(data.length<20*1024*1024);for(const line of data.trim().split('\n').filter(Boolean)){const row=JSON.parse(line);if(row.uuid)result.set(row.uuid,row);}}return [...result.values()];};
 const mainRows=await records(paths.filter(path=>basename(path)===proof.sessionId+'.jsonl'));
 const parent=mainRows.filter(row=>row.type==='user'&&row.isMeta!==true&&text(row.message?.content).includes(proof.parentCanonical));assert.equal(parent.length,1);
 assert.equal(text(parent[0].message.content).split(proof.parentCanonical).length,2);assert.equal(images(parent[0].message.content).filter(image=>image.source?.data===imageData).length,1);
 const workerRows=await records(paths.filter(path=>path.includes('agent-'+proof.taskId)));
 const worker=workerRows.filter(row=>row.type==='user'&&row.isMeta===true&&row.origin?.kind==='human'&&text(row.message?.content).includes(proof.agentCanonical));assert.equal(worker.length,1);assert.equal(text(worker[0].message.content).split(proof.agentCanonical).length,2);
 const requests=[...calls.seed,...calls.agent],parentRequests=requests.filter(call=>text(lastUser(call)?.content).includes(proof.parentCanonical)),workerRequests=requests.filter(call=>text(lastUser(call)?.content).includes(proof.agentCanonical)&&!text(lastUser(call)?.content).includes(proof.parentCanonical));
 assert.equal(parentRequests.length,1);assert.equal(images(lastUser(parentRequests[0]).content).filter(image=>image.source?.data===imageData).length,1);assert.equal(workerRequests.length,1);assert.equal(workerRequests[0].messages.flatMap(message=>images(message.content)).length,0);
 assert.deepEqual(proof.captures.map(row=>[row.owner,row.width,row.height,row.part??null]),[
  ['agent-draft',1100,900,null],['agent-draft',680,600,null],
  ['agent-transcript',1100,900,'heading'],['agent-transcript',1100,900,'code'],['agent-transcript',1100,900,'reference'],['agent-transcript',680,600,'heading'],['agent-transcript',680,600,'code'],['agent-transcript',680,600,'reference'],
  ['parent',1100,900,null],['parent',680,600,null],
 ]);
 const transcript=proof.captures.filter(row=>row.owner==='agent-transcript');assert.equal(new Set(transcript.map(row=>row.visibleUuid)).size,1);
 for(const row of transcript){assert.ok(typeof row.visibleUuid==='string'&&row.visibleUuid.length>0);assert.equal(row.geometry.visible,true);assert.ok(row.geometry.top>=row.geometry.viewportTop-1);assert.ok(row.geometry.bottom<=row.geometry.viewportBottom+1);}

 const captureRoot=join(workspace,'electron-results'),folders=(await readdir(captureRoot,{withFileTypes:true})).filter(entry=>entry.isDirectory());
 for(const row of proof.captures){
  const found=[];for(const folder of folders){try{found.push(await readFile(join(captureRoot,folder.name,row.file)));}catch(error){if(error.code!=='ENOENT')throw error;}}
  assert.equal(found.length,1,'Unique parent round-trip capture');const bytes=found[0];assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),row.width);assert.equal(bytes.readUInt32BE(20),row.height);
 }
 return {sessionId:proof.sessionId,taskId:proof.taskId,parentUuid:parent[0].uuid,workerUuid:worker[0].uuid,parentReads:parentReads.length,agentReads:agentReads.length,originalParentImageBytes:true,noPendingParentImageInWorker:true,captures:proof.captures,scope:'Mixed bold/italic and thread-reference drafts, selected text and actual Agent remount; pending parent PNG retained and submitted once to original parent journal/model. No Agent binary-media or broader lifetime/IME claim.'};
}
