import { isAbsolute } from 'node:path';

/** Private, bounded observation of native control failures; never changes a request or response. */
export function nativeUiErrorFixture(outputPath, { timings = false } = {}) {
  if(typeof outputPath!=='string'||!isAbsolute(outputPath))throw Error('Native UI diagnostic requires an absolute private receipt path');
  return `
{
 const diagnosticHttp=await import('node:http'),diagnosticFs=await import('node:fs');
 const timingEnabled=${JSON.stringify(timings===true)},errors=[],requests=new WeakMap(),started=new WeakMap(),originalEmit=diagnosticHttp.Server.prototype.emit,originalEnd=diagnosticHttp.ServerResponse.prototype.end;
 let writing=false,dirty=false;
 const record=value=>{try{
  if(errors.length>=32)return;errors.push(value);
  if(!timingEnabled){diagnosticFs.writeFileSync(${JSON.stringify(outputPath)},JSON.stringify(errors));return;}
  dirty=true;if(writing)return;writing=true;
  void(async()=>{try{while(dirty){dirty=false;await diagnosticFs.promises.writeFile(${JSON.stringify(outputPath)},JSON.stringify(errors)).catch(()=>{});}}finally{writing=false;}})();
 }catch{}};
 diagnosticHttp.Server.prototype.emit=function(event,...args){
  if(event==='request'&&(args[0]?.url==='/control'||args[0]?.url==='/clients')){
   const request=args[0],chunks=[];let bytes=0;started.set(request,Date.now());
   if(timingEnabled&&request.url==='/clients')args[1].once('close',()=>{if(!args[1].writableEnded)record({event:'response_closed',path:request.url,elapsedMs:Date.now()-started.get(request),request:requests.get(request)});});
   request.on('data',chunk=>{bytes+=chunk.length;if(bytes<=1048576)chunks.push(chunk)});
   request.on('end',()=>{try{const body=JSON.parse(Buffer.concat(chunks).toString()),value=body.request??body.value;requests.set(request,{operation:body.operation,request_id:body.id,subtype:value?.subtype,component:value?.component,instance_id:value?.instance_id,source_uuid:value?.props?.source_uuid,assistant_uuid:value?.props?.assistant_uuid})}catch{}});
  }
  return Reflect.apply(originalEmit,this,[event,...args]);
 };
 diagnosticHttp.ServerResponse.prototype.end=function(...args){
  try{if((this.statusCode===400||timingEnabled&&this.req?.url==='/clients')&&typeof args[0]==='string'){
   const body=this.statusCode>=400?JSON.parse(args[0]):{};
   if(typeof body.error==='string'||timingEnabled&&this.req?.url==='/clients')record({path:this.req?.url,error:body.error,request:requests.get(this.req),...(timingEnabled?{event:'response',statusCode:this.statusCode,elapsedMs:Date.now()-started.get(this.req)}:{})});
  }}catch{}
  return Reflect.apply(originalEnd,this,args);
 };
}
`;
}
