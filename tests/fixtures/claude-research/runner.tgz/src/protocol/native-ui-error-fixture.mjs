import { isAbsolute } from 'node:path';

/** Private, bounded observation of native control failures; never changes a request or response. */
export function nativeUiErrorFixture(outputPath) {
  if(typeof outputPath!=='string'||!isAbsolute(outputPath))throw Error('Native UI diagnostic requires an absolute private receipt path');
  return `
{
 const diagnosticHttp=await import('node:http'),diagnosticFs=await import('node:fs');
 const errors=[],requests=new WeakMap(),originalEmit=diagnosticHttp.Server.prototype.emit,originalEnd=diagnosticHttp.ServerResponse.prototype.end;
 diagnosticHttp.Server.prototype.emit=function(event,...args){
  if(event==='request'&&args[0]?.url==='/control'){
   const request=args[0],chunks=[];let bytes=0;
   request.on('data',chunk=>{bytes+=chunk.length;if(bytes<=1048576)chunks.push(chunk)});
   request.on('end',()=>{try{const value=JSON.parse(Buffer.concat(chunks).toString()).request;requests.set(request,{subtype:value?.subtype,component:value?.component,instance_id:value?.instance_id,source_uuid:value?.props?.source_uuid,assistant_uuid:value?.props?.assistant_uuid})}catch{}});
  }
  return Reflect.apply(originalEmit,this,[event,...args]);
 };
 diagnosticHttp.ServerResponse.prototype.end=function(...args){
  try{if(this.statusCode===400&&typeof args[0]==='string'){
   const body=JSON.parse(args[0]);
   if(typeof body.error==='string'&&errors.length<32){errors.push({path:this.req?.url,error:body.error,request:requests.get(this.req)});diagnosticFs.writeFileSync(${JSON.stringify(outputPath)},JSON.stringify(errors));}
  }}catch{}
  return Reflect.apply(originalEnd,this,args);
 };
}
`;
}
