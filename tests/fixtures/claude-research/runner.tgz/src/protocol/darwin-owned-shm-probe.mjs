import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {randomBytes,createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {release} from 'node:os';
import {fileURLToPath} from 'node:url';
const execute=promisify(execFile);
const publisher=String.raw`import ctypes,os,sys,mmap
name=sys.argv[1].encode();lib=ctypes.CDLL(None,use_errno=True);lib.shm_open.argtypes=[ctypes.c_char_p,ctypes.c_int];lib.shm_open.restype=ctypes.c_int;lib.shm_unlink.argtypes=[ctypes.c_char_p]
fd=lib.shm_open(name,os.O_CREAT|os.O_EXCL|os.O_RDWR,ctypes.c_uint(0o600))
if fd<0: raise OSError(ctypes.get_errno(),'exclusive probe create failed')
try:
 os.ftruncate(fd,4)
 with mmap.mmap(fd,4,access=mmap.ACCESS_WRITE) as mapping: mapping[:]=bytes([1,2,3,255])
except:
 lib.shm_unlink(name)
 raise
finally: os.close(fd)
print('created')
`;
const cleanup=String.raw`import ctypes,os,sys
lib=ctypes.CDLL(None,use_errno=True);lib.shm_open.argtypes=[ctypes.c_char_p,ctypes.c_int];lib.shm_unlink.argtypes=[ctypes.c_char_p];name=sys.argv[1].encode();fd=lib.shm_open(name,os.O_RDONLY)
if fd>=0:
 os.close(fd)
 lib.shm_unlink(name)
 print('removed-leftover')
elif ctypes.get_errno()==2: print('absent')
else: raise OSError(ctypes.get_errno(),'cleanup check failed')
`;
/** System capability probe; Python is only its independent publisher, never an app dependency. */
export async function probeDarwinOwnedSharedMemory(){
 assert.equal(process.platform,'darwin');assert.equal(process.arch,'arm64');
 const script=fileURLToPath(new URL('./darwin-owned-shm-probe.js',import.meta.url));
 const name='/apack_cc_probe_'+randomBytes(4).toString('hex');let owned=false,result,removed=false;
 try{
  const made=await execute('/usr/bin/python3',['-c',publisher,name],{timeout:5000,maxBuffer:16384});assert.equal(made.stdout.trim(),'created');owned=true;
  const {stdout}=await execute('/usr/bin/osascript',['-l','JavaScript',script,name],{timeout:5000,maxBuffer:16384});result=JSON.parse(stdout);assert.equal(result.base64,'AQID/w==');
 }finally{if(owned){const checked=await execute('/usr/bin/python3',['-c',cleanup,name],{timeout:5000,maxBuffer:16384});removed=checked.stdout.trim()==='absent';}}
 assert.equal(removed,true,'reader must consume/unlink its private object');
 const size=Number(Buffer.from(result.sizeBytes,'base64').readBigUInt64LE());assert.ok(size>=4&&size<=65536);
 return{platform:process.platform,arch:process.arch,kernel:release(),scriptSha256:createHash('sha256').update(await readFile(script)).digest('hex'),publisherSha256:createHash('sha256').update(publisher).digest('hex'),expectedBytes:4,observedBase64:result.base64,allocatedBytes:size,independentPublisher:true,readOnlyOpen:true,ownedObjectRemoved:removed};
}
