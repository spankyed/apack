import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {verifyNativeNotebookImages} from './native-read-media-fixture.mjs';

/** Reconcile notebook media across real files, native hooks/journal, app and resumed model request. */
export async function verifyNativeNotebookImageApp(root){
 const json=async file=>JSON.parse(await readFile(file,'utf8')),names=await readdir(join(root,'workspaces'));assert.equal(names.length,1);
 const workspace=join(root,'workspaces',names[0]),evidence=await json(join(workspace,'native-terminal-app-evidence.json'));
 assert.equal(evidence.actualAppGui,true);assert.equal(evidence.nativeNotebookImages,true);assert.equal(evidence.sessionId,evidence.finalSessionId);
 const proof=await json(join(workspace,'native-media-app-proof.json'));assert.equal(proof.length,1);const item=proof[0];assert.equal(item.id,'native_media_3');assert.equal(item.type,'notebook');assert.match(item.formatted,/Read 2 cells/);
 const receipt=await json(join(workspace,'native-media-result-native_media_3.json'));assert.equal(receipt.props.tool,'Read');assert.equal(receipt.props.tool_use_id,item.id);assert.equal(receipt.props.isErrored,false);assert.deepEqual(receipt.props.output,item.output);
 const calls=await json(join(workspace,'model-calls.json'));assert.equal(calls.agent.length,2);assert.equal(calls.seed.filter(row=>row.path==='/v1/messages?beta=true').length,2);
 const find=messages=>messages.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'&&block.tool_use_id===item.id):[]);
 const initial=calls.agent.flatMap(call=>find(call.messages??[]));assert.equal(initial.length,1);const media=await verifyNativeNotebookImages(workspace,initial);
 const resumed=find(calls.seed.at(-1).messages??[]);assert.equal(resumed.length,1);assert.deepEqual(resumed[0].content,initial[0].content);
 const files=await readdir(join(workspace,'.claude/projects'),{recursive:true}),journal=files.find(file=>file.endsWith('/'+evidence.sessionId+'.jsonl'));assert.ok(journal);
 const rows=(await readFile(join(workspace,'.claude/projects',journal),'utf8')).trim().split('\n').map(JSON.parse);
 const results=rows.filter(row=>row.uuid===item.nativeResultUuid);assert.equal(results.length,1);assert.deepEqual(results[0].toolUseResult,item.output);
 const nativeResult=results[0].message.content.filter(block=>block.type==='tool_result'&&block.tool_use_id===item.id);assert.equal(nativeResult.length,1);assert.deepEqual(nativeResult[0].content,initial[0].content);
 const assistant=rows.filter(row=>row.uuid===item.nativeAssistantUuid);assert.equal(assistant.length,1);const nativeCalls=assistant[0].message.content.filter(block=>block.type==='tool_use'&&block.id===item.id&&block.name==='Read');assert.equal(nativeCalls.length,1);assert.equal(nativeCalls[0].input.file_path,item.output.file.filePath);assert.ok(nativeCalls[0].input.file_path.endsWith('/release-analysis.ipynb'));
 const humans=rows.filter(row=>row.type==='user'&&!row.isMeta&&!row.isVirtual&&typeof row.message?.content==='string'&&(!row.origin||row.origin.kind==='human'));
 assert.deepEqual(humans.map(row=>row.message.content),['Seed this private native interface session.','ResearchMediaTurn3 Review release-analysis.ipynb for release.','Continue this saved notebook image review.']);
 const lines=async file=>(await readFile(join(workspace,file),'utf8')).trim().split('\n').map(JSON.parse),children=await lines('native-children.jsonl'),exits=await lines('native-exits.jsonl'),prints=await lines('native-print-results.jsonl');assert.equal(children.length,3);assert.equal(children[1].pid,evidence.boundNativePid);assert.equal(exits.length,3);for(const child of children){const exit=exits.find(row=>row.pid===child.pid);assert.ok(exit&&exit.at>=child.at);assert.ok([0,143].includes(exit.code))}assert.equal(prints.length,2);assert.ok(prints.every(row=>row.sessionId===evidence.sessionId));
 const cost=rows.filter(row=>row.type==='cost-state').at(-1)?.totalCostUSD;assert.equal(cost,prints.at(-1).totalCostUsd);
 const app=await json(join(root,'app-query.stdout')),threads=app.threads.filter(row=>row.claude?.sessionId===evidence.sessionId);assert.equal(threads.length,1);assert.equal(threads[0].claude.totalCostUsd,cost);assert.equal(threads[0].claude.chatState,'success');for(const row of humans){const matches=app.messages.filter(message=>message.sender==='user'&&message.context?.cliUuid===row.uuid);assert.equal(matches.length,1);assert.equal(matches[0].text,row.message.content)}
 const pictures=(await readdir(join(workspace,'electron-results'),{recursive:true})).filter(file=>/\/native-media-3-(1100|680)\.png$/.test(file));assert.equal(pictures.length,2);for(const file of pictures){const bytes=await readFile(join(workspace,'electron-results',file));assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),file.endsWith('-680.png')?680:1100)}
 assert.deepEqual(await json(join(root,'compiled-before.json')),await json(join(root,'compiled-after.json')));const boundary=await json(join(root,'offline-boundary.json'));assert.equal(boundary.networkDisabled,true);assert.equal(boundary.pinnedExecutableReadOnly,true);assert.equal(boundary.memory,6*1024**3);assert.equal(boundary.memorySwap,boundary.memory);assert.equal(boundary.nanoCpus,2*10**9);assert.deepEqual(Object.keys(boundary.networks),['none']);
 return {...media,originalReadSummary:true,exactResumedImageBytes:true,exactAppNativeHistory:true,appNativePrintCost:cost,ownedNativeExits:3,screenshots:2};
}
