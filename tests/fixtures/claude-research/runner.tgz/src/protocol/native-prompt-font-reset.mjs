import assert from 'node:assert/strict';
import http from 'node:http';
import {readFileSync,appendFileSync} from 'node:fs';
import {readFile,readdir} from 'node:fs/promises';
import {join,basename} from 'node:path';

export const FONT_RESET_PLUGIN=`export function register(on){const edits=[];on('prompt.edit',async($,e,next)=>{const result=await next(e),start=result.text.indexOf('Review notes');const output=start<0?result:{...result,decorations:[{start,end:start+12,bold:false,italic:false,dimColor:false}]};edits.push({before:e.text,result:output});await $.fs.write('native-font-reset-edits.json',JSON.stringify(edits.slice(-64)));return output;});on('prompt.submit',async($,e,next)=>{await $.fs.write('native-font-reset-submit.json',JSON.stringify(e));return next(e);});}`;

/** Passive audit of original native prompt-edit replies; original listener and bytes are untouched. */
export function observePromptFontResets({directory,workspace,httpModule=http}){
 assert.match(directory,/^\/(?:private\/)?tmp\/cc-app-[A-Za-z0-9_-]+$/);
 const config=JSON.parse(readFileSync(join(directory,'observer.json'),'utf8'));assert.equal(config.uiSocketPath,join(directory,'ui.sock'));
 const original=httpModule.createServer;let count=0;
 httpModule.createServer=function(...args){
  const index=args.findIndex(value=>typeof value==='function');if(index<0)return Reflect.apply(original,this,args);
  const handler=args[index];let owned=false;
  args[index]=function(request,response){
   if(owned&&request.url==='/control'){
    const chunks=[];let bytes=0;request.on('data',chunk=>{bytes+=chunk.length;if(bytes<=1048576)chunks.push(chunk);});
    const end=response.end;response.end=function(...values){
     try{const body=JSON.parse(Buffer.concat(chunks));if(bytes<=1048576&&body.request?.subtype==='ui_prompt_edit'&&count++<64){const reply=JSON.parse(String(values[0]));appendFileSync(join(workspace,'native-font-reset-controls.jsonl'),JSON.stringify({at:Date.now(),pid:process.pid,request:body,status:response.statusCode,reply})+'\n');}}catch{}
     return Reflect.apply(end,this,values);
    };
   }
   return Reflect.apply(handler,this,[request,response]);
  };
  const server=Reflect.apply(original,this,args),listen=server.listen;
  server.listen=function(...values){owned=values[0]===config.uiSocketPath;return Reflect.apply(listen,this,values);};return server;
 };
 return ()=>{httpModule.createServer=original;};
}

export async function verifyPromptFontResets(workspace,evidence,calls){
 assert.equal(evidence.nativePromptFontResets,true);assert.equal(evidence.sessionId,evidence.finalSessionId);
 const proof=JSON.parse(await readFile(join(workspace,'native-font-reset-proof.json'),'utf8'));
 assert.equal(proof.sessionId,evidence.sessionId);assert.equal(proof.boundNativePid,evidence.boundNativePid);
 assert.equal(proof.canonical,'***Review notes and rollout***');
 const controls=(await readFile(join(workspace,'native-font-reset-controls.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 const control=controls.find(row=>row.reply?.result?.text===proof.canonical&&row.reply.result.decorations?.some(run=>run.bold===false&&run.italic===false&&run.dimColor===false));
 assert.ok(control,'Original native normalized reply did not retain the explicit false properties');
 assert.equal(control.status,200);assert.equal(control.pid,proof.boundNativePid);assert.equal(control.request.ownerPid,proof.boundNativePid);assert.equal(control.request.sessionId,proof.sessionId);assert.equal(control.reply.id,control.request.id);assert.equal(control.reply.pid,proof.boundNativePid);assert.equal(control.reply.sessionId,proof.sessionId);
 assert.equal(control.reply.result.cursor,control.request.request.cursor);
 assert.deepEqual(proof.captures.map(row=>row.width),[1100,680]);
 for(const capture of proof.captures){assert.equal(capture.style.fontWeight,'400');assert.equal(capture.style.fontStyle,'normal');assert.equal(capture.style.opacity,'1');assert.equal(capture.sibling.fontStyle,'italic');assert.ok(Number(capture.sibling.fontWeight)>=600);assert.deepEqual(capture.selection,proof.selection);}
 const root=join(workspace,'.claude/projects'),paths=(await readdir(root,{recursive:true})).filter(path=>basename(path)===proof.sessionId+'.jsonl');assert.equal(paths.length,1);
 const rows=(await readFile(join(root,paths[0]),'utf8')).trim().split('\n').map(JSON.parse);
 const humans=rows.filter(row=>row.type==='user'&&row.isMeta!==true&&(row.origin?.kind==='human'||!row.origin&&typeof row.message?.content==='string'));
 const text=content=>typeof content==='string'?content:(content??[]).filter(block=>block.type==='text').map(block=>block.text).join('\n');
 assert.deepEqual(humans.map(row=>text(row.message.content)),['Review the release notes for this project.',proof.canonical,'Continue after reviewing the native font reset.']);
 assert.equal(humans[1].uuid,proof.sentUuid);
 assert.ok(calls.agent.some(call=>(call.messages??[]).some(message=>message.role==='user'&&text(message.content)===proof.canonical)),'Original model request lost the rich draft');
 assert.equal(calls.seed.length,2);
 return {sessionId:proof.sessionId,humanUuids:humans.map(row=>row.uuid),nativeReplyId:control.reply.id,captures:proof.captures,scope:'Main-owner explicit bold/italic/dimming resets over rich text, adjacent inherited styles, exact canonical submission and same-session recovery. Other line styles, IME, owners and lifetimes remain open.'};
}
