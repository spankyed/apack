import { createHash } from 'node:crypto';

/** Read-only observation; the original mounted renderer retains every callback and field. */
export function inspectNativeMcpRenderers(root, open, identities, digest) {
  const kinds = new Set(['mcp_elicitation', 'mcp_url_elicitation', 'mcp_elicitation_waiting']);
  if (!Array.isArray(open) || open.length !== 1 || !kinds.has(open[0]?.kind)) return [];
  const dialog = open[0], pending = [root], seen = new Set(), wrappers = [];
  const fingerprint = fn => typeof fn === 'function' ? digest(Function.prototype.toString.call(fn)) : undefined;
  const describe = fiber => ({ name: fiber.type.name, sha256: fingerprint(fiber.type) });
  while (pending.length) {
    const fiber = pending.pop();
    if (!fiber || seen.has(fiber)) continue;
    if (seen.size >= 4096) throw Error('MCP renderer root traversal exceeded bound');
    seen.add(fiber);
    if (typeof fiber.type === 'function' && fiber.memoizedProps?.payload === dialog.payload) wrappers.push(fiber);
    if (fiber.sibling) pending.push(fiber.sibling);
    if (fiber.child) pending.push(fiber.child);
  }
  if (wrappers.length !== 1) return [];
  const wrapper = wrappers[0], children = [wrapper.child], visited = new Set(), renderers = [];
  while (children.length) {
    const fiber = children.pop();
    if (!fiber || visited.has(fiber)) continue;
    if (visited.size >= 2048) throw Error('MCP renderer child traversal exceeded bound');
    visited.add(fiber);
    if (typeof fiber.type === 'function') {
      const identity = identities.find(value => value.name === fiber.type.name);
      if (identity) {
        const facts = describe(fiber);
        renderers.push({ ...facts, role: identity.role, verified: facts.sha256 === identity.sha256,
          ...(facts.sha256 === identity.sha256 ? { fiber } : {}) });
      }
    }
    if (fiber.sibling) children.push(fiber.sibling);
    if (fiber.child) children.push(fiber.child);
  }
  const expectedRole = dialog.payload?.params?.mode === 'url' ? 'url' : 'form';
  const matches = renderers.filter(renderer => renderer.role === expectedRole);
  if (matches.length !== 1) return [];
  const renderer = matches[0], controls = [], nodes = [renderer.fiber?.child], controlled = new Set();
  while (nodes.length) {
    const fiber = nodes.pop();
    if (!fiber || controlled.has(fiber)) continue;
    if (controlled.size >= 2048) throw Error('MCP renderer controls exceeded bound');
    controlled.add(fiber);
    const props = fiber.memoizedProps;
    if (props && typeof props === 'object') {
      const callbacks = Object.fromEntries(['onKeyDown', 'onCancel', 'handleTextInputChange', 'handleTextInputSubmit', 'setTextInputCursorOffset'].filter(key => typeof props[key] === 'function').map(key => [key, fingerprint(props[key])]));
      if (Object.keys(callbacks).length || Array.isArray(props.schemaFields)) {
        const state = Object.fromEntries(['schemaFields', 'formValues', 'validationErrors', 'resolvingFields', 'currentFieldIndex', 'focusedButton', 'expandedAccordion', 'accordionOptionIndex', 'textInputValue', 'textInputCursorOffset'].filter(key => Object.hasOwn(props, key)).map(key => [key, props[key] instanceof Set ? [...props[key]] : props[key]]));
        controls.push({ component: typeof fiber.type === 'function' ? describe(fiber) : { name: String(fiber.type) }, callbacks, state });
      }
    }
    if (fiber.sibling) nodes.push(fiber.sibling);
    if (fiber.child) nodes.push(fiber.child);
  }
  const { fiber: _fiber, ...identity } = renderer;
  return [{ id: dialog.id, kind: dialog.kind, serverName: dialog.payload?.serverName,
    mode: dialog.payload?.params?.mode ?? 'form', wrapper: describe(wrapper), renderer: identity,
    readinessCallbackPresent: typeof wrapper.memoizedProps.wouldTakeAnswer === 'function', controls }];
}

export const nativeMcpRendererIdentities = {
  darwin: { binarySha256: '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37', runtimeModule: 'chunk-hqtnbrjd.js', runtimeExport: 'ey', rootsModule: 'chunk-pg10s5g1.js', renderers: [
    { role: 'form', name: 'tet', sha256: 'ba2a4f9045e565e0ac28db116418d4758517b2a2007cc6ae64a40ec73fc4277d' },
    { role: 'url', name: 'tke', sha256: '72edfab66d939fee12559ff708e9fa21a67c9cceb84a7937b7c1b0d994c7a747' },
  ] },
  linux: { binarySha256: '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10', runtimeModule: 'chunk-a7b8k0bt.js', runtimeExport: 'Zh', rootsModule: 'chunk-f7hx5xpd.js', renderers: [
    { role: 'form', name: 'iet', sha256: 'f9ab5cf602703c4ea7dd602d9e75579c8e06cded225d9e27ee9259920c2d4a23' },
    { role: 'url', name: 'ske', sha256: '4dc2845fd34894d5f3ae8f56dace344a119435b62480bba93ad735616e231663' },
  ] },
};

/** Generates an explicit opt-in preload for a private synthetic workspace; never launches the CLI. */
export function nativeMcpRendererInspector(outputPath) {
  if (typeof outputPath !== 'string' || !outputPath.startsWith('/') || outputPath.includes('\0')) throw Error('An absolute private output path is required');
  return `
{const {readFileSync,writeFileSync}=await import('node:fs');
 const {createHash}=await import('node:crypto');
 const identities=${JSON.stringify(nativeMcpRendererIdentities)};
 const platform=identities[process.platform],digest=value=>createHash('sha256').update(value).digest('hex');
 if(platform&&digest(readFileSync(process.execPath))===platform.binarySha256){
  const inspect=${inspectNativeMcpRenderers.toString()};
  const observations=[];let previous,reading=false,attempts=0;
  const timer=setInterval(async()=>{if(reading)return;reading=true;try{
   if(++attempts>1200||observations.length>=80){clearInterval(timer);return;}
   const runtime=await import('/$bunfs/root/'+platform.runtimeModule),binding=runtime[platform.runtimeExport]();
   if(binding?.surface!=='terminal')return;
   const context=binding.toolContext(new AbortController()),roots=await import('/$bunfs/root/'+platform.rootsModule);
   const facts=inspect(roots.ai().get(process.stdout)?.container?.current,context.dialogStore.getState().open,platform.renderers,digest);
   const key=JSON.stringify(facts);if(!facts.length||key===previous)return;
   if(Buffer.byteLength(key)>200000)throw Error('MCP renderer snapshot exceeded bound');
   previous=key;observations.push({at:Date.now(),facts});
   writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({kind:'native-mcp-mounted-renderer-observation',targetSha256:platform.binarySha256,platform:process.platform,observations},null,2),{mode:0o600});
  }catch(error){clearInterval(timer);writeFileSync(${JSON.stringify(outputPath)},JSON.stringify({kind:'native-mcp-mounted-renderer-observation',status:'failed',error:String(error),observations}),{mode:0o600});}finally{reading=false}},100);timer.unref();
 }
}
`;
}

export const nativeMcpInspectorSha256 = () => createHash('sha256').update(inspectNativeMcpRenderers.toString()).digest('hex');
