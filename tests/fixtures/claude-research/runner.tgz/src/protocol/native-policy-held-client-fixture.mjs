import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

/** The native policy loader, rather than a patched tier predicate, admits the observer. */
export async function addNativePolicyHeldClientFixture(workspace, ordinaryPlugin) {
  const marketplace=join(workspace,'policy-observer-marketplace'),plugin=join(marketplace,'plugins/policy-observer');
  await mkdir(join(marketplace,'.claude-plugin'),{recursive:true});
  await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'),{recursive:true});
  await writeFile(join(marketplace,'.claude-plugin/marketplace.json'),JSON.stringify({name:'policy-research',owner:{name:'Private research'},plugins:[{name:'policy-observer',source:'./plugins/policy-observer',description:'Owned policy callback observer'}]}));
  await writeFile(join(plugin,'.claude-plugin/plugin.json'),JSON.stringify({name:'policy-observer',version:'0.0.1'}));
  await writeFile(join(plugin,'hooks/hooks.json'),JSON.stringify({modules:['./register.ts']}));
  const policyPath=join(workspace,'policy/managed-settings.json'),policy=JSON.parse(await readFile(policyPath,'utf8'));
  await writeFile(policyPath,JSON.stringify({...policy,extraKnownMarketplaces:{...policy.extraKnownMarketplaces,'policy-research':{source:{source:'directory',path:marketplace}}},enabledPlugins:{...policy.enabledPlugins,'policy-observer@policy-research':true}}));
  await writeFile(join(plugin,'hooks/register.ts'),String.raw`export function register(on){
 on('ui.press',async($,e,next)=>{
  if(e.plugin!=='native-history-fixture'||e.component!=='AbovePrompt'||e.element!=='held-policy-action')return next(e);
  const nonce=await $.fs.read('native-policy-held-arm.txt').catch(()=>'');if(!nonce){await $.fs.write('native-policy-fresh-draft.json',JSON.stringify(await $.prompt.read()));return next(e);}
  const started=await $.clock.now();
  await $.fs.write('native-policy-held-start.json',JSON.stringify({nonce,started,event:e,draft:await $.prompt.read()}));
  try{
   for(let i=0;i<600;i++){
    if((await $.fs.read('native-policy-held-release.txt').catch(()=>''))===nonce){
     await $.fs.write('native-policy-held-released.json',JSON.stringify({nonce,elapsed:(await $.clock.now())-started}));
     const result=await next(e);
     await $.fs.write('native-policy-held-settled.json',JSON.stringify({nonce,result,elapsed:(await $.clock.now())-started}));
     return result;
    }
    await $.clock.sleep(50,{signal:next.signal});
   }
   throw Error('Owned held-policy observer expired');
  }catch(error){await $.fs.write('native-policy-held-error.json',JSON.stringify({nonce,error:String(error)}));throw error;}
 });
}`);
  await writeFile(join(ordinaryPlugin,'hooks/policy-client.ts'),String.raw`export default function(props,s){
 const{Box,Text,Button}=s.elements;
 const post=()=>s.post({kind:'policy-clock',...s.state});
 if(s.state===undefined)s.setState({pressed:0,key:'none'});
 s.onKey(e=>{s.setState({...s.state,key:e.key});post();});
 return Box({flexDirection:'column',children:[Text({children:['Policy action count='+s.state.pressed+' key='+s.state.key]}),Button({key:'held-policy-action',label:'Apply policy action',onPress:()=>{s.setState({...s.state,pressed:s.state.pressed+1});post();}})]});
}`);
  const register=join(ordinaryPlugin,'hooks/register.ts'),source=await readFile(register,'utf8');
  const previous="module:'./policy-client.ts',props:{},width:'100%',height:1";
  if(!source.includes(previous))throw Error('Original policy Client fixture changed');
  await writeFile(register,source.replace(previous,"module:'./policy-client.ts',props:{},width:'100%',height:3"));
}
