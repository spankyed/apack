import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';

/** Exercise an original public channel preference in an owned home, never the installed CLI settings. */
export async function addNativeNotifyFixture(workspace,plugin){
 const path=join(workspace,'.claude/settings.json');
 const settings=JSON.parse(await readFile(path,'utf8').catch(()=>'{}'));
 await writeFile(path,JSON.stringify({...settings,preferredNotifChannel:'terminal_bell'}));
 await writeFile(join(plugin,'hooks/register.ts'),`export function register(on){let count=0;on('ui.render',{component:'AbovePrompt'},async($,e,next)=>{if(e.surface!=='desktop')return next(e);const{Box,Text,Button}=$.ui.resolve(e);return Box({flexDirection:'column',children:[Text({children:['Attention requests '+count]}),Button({key:'notify-release',label:'Notify me',onPress:async()=>{const text='The release review needs your attention.',title='Release review';const result=await $.ui.notify(text,{title});await $.fs.write('native-notify-native.json',JSON.stringify({requestId:e.requestId,text,title,result}));count++;$.ui.invalidate('ui.render');}})]});});}`);
}

export async function verifyNativeNotifyFixture(workspace){
 const native=JSON.parse(await readFile(join(workspace,'native-notify-native.json'),'utf8'));
 assert.ok(native.requestId);assert.equal(native.text,'The release review needs your attention.');
 assert.deepEqual(native.result,{isSent:true,channel:'terminal_bell'});
 const proof=JSON.parse(await readFile(join(workspace,'native-notify-app-proof.json'),'utf8'));
 assert.deepEqual(proof.receipt,native);assert.deepEqual(proof.widths,[1100,680]);
 assert.equal(proof.draftRetained,true);assert.equal(proof.noPhantomTurn,true);
 return{originalChannel:'terminal_bell',appAlert:true,retainedDraft:true,noPhantomTurn:true};
}
