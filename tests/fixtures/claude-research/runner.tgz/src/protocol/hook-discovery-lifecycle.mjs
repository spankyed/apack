import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';

/** Observe lifecycle activation during metadata-only native initialization and writer commands. */
export async function probeHookDiscoveryLifecycle(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'hook-discovery-lifecycle-')),hook=fileURLToPath(new URL('./synthetic-lifecycle-hook.mjs',import.meta.url)),cases=[];
 const run=await createRun(output,'hook-discovery-lifecycle',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),hookSha256:hash(await readFile(hook)),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});
 try{
  for(const mode of ['normal','init-only','bare','disabled','writer']){
   const cwd=join(workspace,mode),home=join(cwd,'home'),config=join(home,'.claude'),capture=join(cwd,'hooks.jsonl');await mkdir(config,{recursive:true});
   const settings={apiKeyHelper:'/usr/bin/printf research-fixture-key',hooks:Object.fromEntries(['SessionStart','SessionEnd','UserPromptSubmit','Stop'].map(event=>[event,[{hooks:[{type:'command',command:process.execPath,args:[hook,capture]}]}]]))},path=join(config,'settings.json'),before=JSON.stringify(settings);await writeFile(path,before);
   const model=await startSyntheticModel(cwd,'TextOnly'),replies=[];let pending='',transport;
   const requests=mode==='init-only'?[{subtype:'initialize'}]:[{subtype:'initialize'},{subtype:'get_hooks_listing'},{subtype:'get_memory_dialog'},{subtype:'get_skills_dialog'},{subtype:'list_permission_rules'},{subtype:'get_plan'},{subtype:'get_context_usage',detail:'summary'}],send=index=>JSON.stringify({type:'control_request',request_id:'metadata-'+index,request:requests[index]})+'\n';let index=0;
   try{
    transport=await record({executable,cwd,output,timeoutMs:15000,env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:config,ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},args:mode==='writer'?['edit-hook','--json']:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--permission-prompt-tool','stdio','--setting-sources','user','--strict-mcp-config','--tools','','--no-session-persistence',...(mode==='bare'?['--bare']:[]),...(mode==='disabled'?['--settings','{"disableAllHooks":true}']:[])],input:[mode==='writer'?JSON.stringify({op:'add',source:'userSettings',event:'PreToolUse',hook:{type:'command',command:'/usr/bin/true'}})+'\n':send(0)],...(mode==='writer'?{}:{onStdout(bytes,channel){pending+=bytes.toString();while(pending.includes('\n')){const i=pending.indexOf('\n'),text=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(text)}catch{continue}
     if(value.type==='control_response'&&value.response?.request_id==='metadata-'+index){assert.equal(value.response.subtype,'success');replies.push(requests[index].subtype);index++;if(index<requests.length)channel.send(send(index));else channel.closeInput();}
    }}})});
   }finally{await model.close();}
   assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(model.calls.length,0);if(mode!=='writer'){assert.deepEqual(replies,requests.map(value=>value.subtype));assert.equal(await readFile(path,'utf8'),before);}
   let events=[];try{events=(await readFile(capture,'utf8')).trim().split('\n').filter(Boolean).map(line=>JSON.parse(line));}catch(error){if(error.code!=='ENOENT')throw error;}
   assert.deepEqual(events.map(value=>value.event),['normal','init-only'].includes(mode)?['SessionStart','SessionEnd']:[]);
   assert.ok(events.every(value=>value.sessionIdPresent));
   if(mode==='writer'){const saved=JSON.parse(await readFile(path,'utf8'));assert.deepEqual(saved.hooks.PreToolUse,[{hooks:[{type:'command',command:'/usr/bin/true'}]}]);}
   cases.push({mode,controls:replies,lifecycleEvents:events,sourceUnchanged:mode!=='writer',modelRequests:0,userPrompts:0});
  }
  const evidence={cases,qualification:'Private command-hook lifecycle during no-prompt controls/writer only; not plugin modules, managed hooks, remote state or model/tool execution.'};await writeFile(join(run.directory,'hook-discovery-lifecycle.json'),JSON.stringify(evidence,null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',...evidence};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
