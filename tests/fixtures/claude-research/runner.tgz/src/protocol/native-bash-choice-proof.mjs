import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import { join, basename } from 'node:path';
import { execFileSync } from 'node:child_process';
import { verifyNativePluginHintAppEvidence } from './native-plugin-hint-app-proof.mjs';
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const digest = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
async function workspace(root) {
  const names = await readdir(join(root, 'records/workspaces')); assert.equal(names.length, 1);
  return join(root, 'records/workspaces', names[0]);
}

/** Reconstruct both recorded snapshots; the old native HTTP error itself was not retained. */
export async function reconstructBashPrefixTokenFailure(root) {
  const directory = await workspace(root), database = await json(join(root, 'admission-history-query.json'));
  const threads = database.threads.filter(row => row.claude?.pendingControlRequest?.toolName === 'Bash'); assert.equal(threads.length, 1);
  const pending = threads[0].claude.pendingControlRequest, native = pending.nativeTerminal;
  const log = await readFile(join(directory, 'app-data/apack/logs/main.log'), 'utf8');
  const events = [...log.matchAll(/Incoming: "INTERACTIVE_MSG_RESPONSE" \{[\s\S]*?\n\}/g)].map(match => match[0]).filter(value => value.includes('choiceToken:'));
  assert.equal(events.length, 1); assert.match(events[0], /choice: 'yes'/);
  const posted = events[0].match(/choiceToken: '([a-f0-9]{64})'/)?.[1]; assert.ok(posted);
  const choices = native.bash.choices; assert.ok(choices.every(choice => !Object.hasOwn(choice, 'token')));
  const once = choices.find(choice => choice.value === 'yes'); assert.ok(once); assert.equal(once.prefix, undefined);
  const initial = choices.map(choice => choice.value === 'yes-prefix-edited' ? { ...choice, prefix: pending.originalInput.command } : choice);
  assert.notDeepEqual(initial, choices); assert.deepEqual(initial.find(choice => choice.value === 'yes'), once);
  const initialToken = digest([native.revision, initial]), refinedToken = digest([native.revision, choices]);
  assert.equal(initialToken, posted); assert.equal(refinedToken, native.bash.token); assert.notEqual(initialToken, refinedToken);
  const inspected = await json(join(directory, 'native-dialog-shapes.json'));
  const original = inspected.events.flatMap(event => event.value?.open ?? []).find(dialog => dialog.kind === 'permission_bash');
  assert.equal(original.id, native.dialogId); assert.equal(original.payload.input.command, pending.originalInput.command);
  assert.equal(inspected.events.some(event => event.type === 'closed' && event.value.id === original.id && event.value.result?.behavior === 'allow'), false);
  return { dialogId: native.dialogId, revision: native.revision, posted, initialToken, refinedToken,
    unchangedSelectedChoice: once, initialMatchesPosted: true, refinedMatchesPersisted: true,
    limitation: 'The original HTTP refusal was not captured. This reconstructs the incompatible list snapshots and unchanged selected choice; it does not attribute every native approval refusal to this race.' };
}

/** Match the real pointer-down selection to the original native admission, callback and saved session. */
export async function verifyNativeBashChoiceAppEvidence(root) {
  const original = await verifyNativePluginHintAppEvidence(root), directory = await workspace(root);
  const app = await json(join(directory, 'native-plugin-hint-app.json')), click = await json(join(directory, 'native-bash-app-before.json'));
  const lines = (await readFile(join(directory, 'native-bash-admission.jsonl'), 'utf8')).trim().split('\n'); assert.ok(lines.length > 2 && lines.length <= 256);
  const trace = lines.map(JSON.parse); assert.ok(trace.every(row => row.pid === app.boundNativePid));
  const requests = trace.filter(row => row.phase === 'request'), responses = trace.filter(row => row.phase === 'response');
  assert.equal(requests.length, 1); assert.equal(responses.length, 1);
  const sent = requests[0], response = responses[0], pending = click.pending, native = pending.nativeTerminal;
  assert.equal(sent.request.id, native.dialogId); assert.equal(sent.request.revision, native.revision); assert.equal(sent.request.session_id, native.sessionId);
  assert.equal(native.sessionId, app.sessionId); assert.equal(sent.request.choice, 'yes'); assert.equal(sent.request.decision, 'allow');
  const selected = native.bash.choices.find(choice => choice.value === sent.request.choice); assert.ok(selected);
  assert.equal(sent.request.choiceToken, selected.token); assert.notEqual(selected.token, native.bash.token);
  assert.equal(sent.native.matches.length, 1); assert.equal(sent.native.matches[0].wouldTakeAnswer, true);
  const controls = sent.native.matches[0].controls; assert.equal(controls.length, 1);
  const option = controls[0].find(option => option.value === selected.value); assert.ok(option); assert.equal(option.disabled, false);
  assert.equal(selected.token, digest([native.revision, { value: option.value, label: option.label }]));
  assert.equal(response.id, sent.id); assert.equal(response.status, 200); assert.equal(response.reply.result.answered, true); assert.equal(response.native.dialog, null);
  assert.ok(click.at <= sent.at && sent.at <= response.at);
  return { original, nativePid: app.boundNativePid, sessionId: app.sessionId, selectedChoice: selected.value,
    selectedToken: selected.token, presentationToken: native.bash.token, originalAdmission: true,
    originalCallbackAcknowledged: true, appResponses: 1, automaticRetries: 0,
    scope: 'Ordinary first-click one-time consent and same-session recovery. Exact prefix-refinement races, standing edits and other admission failures require their own retained evidence.' };
}

/** Check native permission writes, unchanged commands, next matching execution and app/session accounting. */
export async function verifyNativeBashStandingAppEvidence(root) {
  const directory = await workspace(root), proof = await json(join(directory, 'native-terminal-app-evidence.json'));
  assert.equal(proof.actualAppGui, true); assert.equal(proof.nativeBashStanding, true); assert.deepEqual(proof.browserErrors, []);
  const settings = await json(join(directory, '.claude/settings.local.json'));
  assert.ok(settings.permissions.allow.includes('Bash(' + proof.editedPrefix + ')'));
  const inspected = await json(join(directory, 'native-dialog-shapes.json'));
  const opened = inspected.events.flatMap(event => event.value?.open ?? []).filter(dialog => dialog.kind === 'permission_bash');
  const ids = [...new Set(opened.map(dialog => dialog.id))]; assert.equal(ids.length, 3);
  const closed = inspected.events.filter(event => event.type === 'closed' && ids.includes(event.value.id)).map(event => event.value);
  assert.deepEqual(closed.map(dialog => dialog.result.behavior), ['allow', 'deny', 'allow']);
  assert.deepEqual(closed[2].result.permissionUpdates, [{ type: 'addRules', rules: [{ toolName: 'Bash', ruleContent: proof.editedPrefix }], behavior: 'allow', destination: 'localSettings' }]);
  assert.equal(closed[2].result.updatedInput.command, proof.originalCommand);
  const names = await readdir(join(directory, '.claude/projects'), { recursive: true }), name = names.find(name => name.endsWith('/' + proof.sessionId + '.jsonl')); assert.ok(name);
  const rows = async path => (await readFile(path, 'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);
  const journal = await rows(join(directory, '.claude/projects', name)), humans = journal.filter(row => row.type === 'user' && !row.isMeta && !row.isVirtual && typeof row.message?.content === 'string' && (!row.origin || row.origin.kind === 'human'));
  assert.deepEqual(humans.map(row => row.message.content), ['Seed this private native interface session.', ...[1, 2, 3, 4].map(turn => 'ResearchPermissionTurn' + turn), 'Continue after remembered Bash approval.']);
  const blocks = journal.flatMap(row => Array.isArray(row.message?.content) ? row.message.content : []);
  assert.equal(blocks.find(block => block.type === 'tool_use' && block.id === 'toolu_research_fixture_3')?.input.command, proof.originalCommand);
  for (const turn of [1, 2, 3, 4]) {
    const result = blocks.find(block => block.type === 'tool_result' && block.tool_use_id === 'toolu_research_fixture_' + turn); assert.ok(result);
    assert.equal(result.is_error === true, turn === 2);
  }
  const bytes = execFileSync('/usr/bin/tar', ['-xOf', join(root, 'raw-evidence.tgz'), './workspaces/' + basename(directory) + '/fixture.txt'], { maxBuffer: 1048576 });
  assert.equal(bytes.toString(), 'synthetic protocol fixture\n');
  const database = await json(join(root, 'app-query.stdout')), thread = database.threads.filter(row => row.claude?.sessionId === proof.sessionId); assert.equal(thread.length, 1);
  for (const human of humans) {
    const matches = database.messages.filter(row => row.sender === 'user' && row.context?.cliUuid === human.uuid); assert.equal(matches.length, 1); assert.equal(matches[0].text, human.message.content);
  }
  const prints = await rows(join(directory, 'native-print-results.jsonl')), cost = journal.filter(row => row.type === 'cost-state').at(-1)?.totalCostUSD;
  assert.ok(Number.isFinite(cost) && cost > 0); assert.equal(prints.at(-1).sessionId, proof.sessionId); assert.equal(prints.at(-1).subtype, 'success'); assert.equal(prints.at(-1).totalCostUsd, cost); assert.equal(thread[0].claude.totalCostUsd, cost);
  const children = await rows(join(directory, 'native-children.jsonl')), exits = await rows(join(directory, 'native-exits.jsonl')); assert.equal(children.length, 3); assert.equal(exits.length, 3); assert.equal(children[1].pid, proof.boundNativePid);
  for (let index = 0; index < children.length; index++) { const exit = exits.find(row => row.pid === children[index].pid); assert.ok(exit && [0, 143].includes(exit.code)); if (index < 2) assert.ok(exit.at <= children[index + 1].at); }
  const pictures = await readdir(join(directory, 'electron-results'), { recursive: true }), expected = ['apack-managed-composer-status.png', ...[900, 600].flatMap(height => ['apack-native-bash-prefix-before-geometry-' + height + '.png', 'apack-native-bash-prefix-' + height + '.png'])];
  for (const name of expected) { const found = pictures.filter(path => path.endsWith('/' + name)); assert.equal(found.length, 1); const image = await readFile(join(directory, 'electron-results', found[0])); assert.equal(image.subarray(0, 8).toString('hex'), '89504e470d0a1a0a'); assert.equal(image.readUInt32BE(16), 680); assert.equal(image.readUInt32BE(20), name.includes('900') ? 900 : 600); }
  assert.deepEqual(await json(join(root, 'compiled-before.json')), await json(join(root, 'compiled-after.json')));
  const boundary = await json(join(root, 'offline-boundary.json')); assert.equal(boundary.memory, 6 * 1024 ** 3); assert.equal(boundary.memorySwap, boundary.memory); assert.equal(boundary.nanoCpus, 2 * 10 ** 9); assert.equal(boundary.pinnedExecutableReadOnly, true); assert.deepEqual(Object.keys(boundary.networks), ['none']);
  const calls = await json(join(directory, 'model-calls.json'));
  return { sessionId: proof.sessionId, nativePid: proof.boundNativePid, originalHumanUuids: humans.map(row => row.uuid), originalDecisions: closed.map(dialog => dialog.result.behavior), editedPrefix: proof.editedPrefix,
    originalCommandPreserved: true, originalRulePersisted: true, nextMatchingCommandWithoutDialog: true,
    appNativePrintCost: cost, ownedNativeExits: 3, screenshots: expected.length, syntheticHttpRequests: calls.seed.length + calls.agent.length, realModelRequests: 0,
    scope: 'One-time allow/deny and one edited-prefix rule, next matching command and same-session recovery at narrow/tall and compact sizes. Other rule/mode/provider/policy/owner/window variants remain open.' };
}
