import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';

/** Reconcile original policy-loader diagnostics with the app journey; never interpret policy for the app. */
export async function verifyNativeSystemPolicyStartup(workspace,{unreadable=false}={}){
 const installed=JSON.parse(await readFile(join(workspace,'native-system-policy-install.json'),'utf8'));
 const proof=JSON.parse(await readFile(join(workspace,'native-system-policy-app-proof.json'),'utf8'));
 const debug=await readFile(join(workspace,'native-debug.log'),'utf8');
 if(unreadable){
  assert.equal(installed.path,'/etc/claude-code/managed-settings.json');assert.equal(installed.uid,0);assert.equal(installed.mode,0);assert.equal(installed.errno,'EACCES');assert.equal(installed.filesystemMapping,false);assert.equal(installed.platformEmulation,false);
  assert.equal(proof.nativeManagedWarning,true);assert.equal(proof.successfulContinuation,true);assert.equal(proof.draftRetained,true);assert.ok(proof.nativeHumanUuid);
  assert.ok(proof.warningText.includes(installed.path)&&proof.warningText.includes('EACCES'));
  return {realDefaultPathObserved:true,originalUnreadableDiagnosticDisplayed:true,originalContinuationPreserved:true,helperControlEligibility:'not accepted by this warning journey',nativeDebugSha256:createHash('sha256').update(debug).digest('hex')};
 }
 assert.equal(installed.path,'/etc/claude-code/managed-settings.json');assert.equal(installed.uid,0);assert.equal(installed.mode,0o644);
 assert.equal(installed.filesystemMapping,false);assert.equal(installed.platformEmulation,false);assert.equal(installed.policy.allowManagedHooksOnly,true);
 assert.match(debug,/Watching for changes in setting files[^\n]*\/etc\/claude-code\/managed-settings\.json/);
 assert.match(debug,/hooks module native-history-fixture@inline not loaded: only managed plugins and built-in plugins run \(allowManagedHooksOnly \/ disableAllHooks\)/);
 assert.equal(proof.userStatusOverridden,true);assert.equal(proof.privateControlsSuppressed,true);assert.equal(proof.draftRetained,true);assert.ok(proof.nativeHumanUuid);
 const calls=(await readFile(join(workspace,'prefix-calls.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 assert.ok(!calls.some(row=>row.args.at(-1).includes('/main.py')),'User status helper ran despite managed source');
 return {realDefaultPathObserved:true,originalPrivateHookRefusal:true,userHelperNotExecuted:true,policySha256:installed.sha256,nativeDebugSha256:createHash('sha256').update(debug).digest('hex')};
}
