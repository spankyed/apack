import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';

/** Reconcile original policy-loader diagnostics with the app journey; never interpret policy for the app. */
export async function verifyNativeSystemPolicyStartup(workspace,{unreadable=false,transitions=false}={}){
 const installed=JSON.parse(await readFile(join(workspace,'native-system-policy-install.json'),'utf8'));
 const proof=JSON.parse(await readFile(join(workspace,'native-system-policy-app-proof.json'),'utf8'));
 const debug=await readFile(join(workspace,'native-debug.log'),'utf8');
 if(unreadable){
  assert.equal(installed.path,'/etc/claude-code/managed-settings.json');assert.equal(installed.uid,0);assert.equal(installed.mode,0);assert.equal(installed.errno,'EACCES');assert.equal(installed.filesystemMapping,false);assert.equal(installed.platformEmulation,false);
  assert.equal(proof.originalSettingsConsent,true);assert.equal(proof.nativeManagedWarning,true);assert.equal(proof.successfulContinuation,true);assert.equal(proof.draftRetained,true);assert.ok(proof.nativeHumanUuid);
  assert.ok(proof.warningText.includes(installed.path)&&proof.warningText.includes('EACCES'));
  return {realDefaultPathObserved:true,originalUnreadableDiagnosticDisplayed:true,originalContinuationPreserved:true,helperControlEligibility:'not accepted by this warning journey',nativeDebugSha256:createHash('sha256').update(debug).digest('hex')};
 }
 assert.equal(installed.path,'/etc/claude-code/managed-settings.json');assert.equal(installed.uid,0);assert.equal(installed.mode,0o644);
 assert.equal(installed.filesystemMapping,false);assert.equal(installed.platformEmulation,false);assert.equal(installed.policy.allowManagedHooksOnly,true);
 assert.match(debug,/Watching for changes in setting files[^\n]*\/etc\/claude-code\/managed-settings\.json/);
 assert.match(debug,/hooks module native-history-fixture@inline not loaded: only managed plugins and built-in plugins run \(allowManagedHooksOnly \/ disableAllHooks\)/);
 assert.equal(proof.userStatusOverridden,true);assert.equal(proof.privateControlsSuppressed,true);assert.equal(proof.draftRetained,true);assert.ok(proof.nativeHumanUuid);
 const calls=(await readFile(join(workspace,'prefix-calls.jsonl'),'utf8')).trim().split('\n').map(JSON.parse);
 if(transitions){
  const live=proof.liveTransitions;assert.ok(live,'Live policy transition proof missing');
  assert.equal(live.sameNativeOwner,true);assert.equal(live.noPhantomTurn,true);assert.equal(live.draftRetained,true);
  assert.equal(live.privateControlsRestored,true);assert.equal(live.managedControlsRetired,true);
  assert.equal(live.receipts.length,2);assert.deepEqual(live.receipts.map(row=>row.mode),['private','managed']);
  assert.equal(live.phases.length,2);const [privatePhase,managedPhase]=live.phases;
  assert.equal(privatePhase.mode,'private');assert.equal(managedPhase.mode,'managed');
  for(const key of ['ownerId','nativePid','sessionId'])assert.equal(privatePhase[key],managedPhase[key]);
  assert.equal(privatePhase.sessionId,proof.sessionId);assert.equal(privatePhase.nativePid,proof.boundNativePid);
  assert.equal(privatePhase.turns,1);assert.equal(managedPhase.turns,1);
  assert.ok(privatePhase.status.includes('Session ready'));assert.ok(!privatePhase.status.includes('Managed OS policy ready'));
  assert.ok(managedPhase.status.includes('Managed OS policy ready'));assert.ok(!managedPhase.status.includes('Session ready'));
  assert.ok(privatePhase.privateControls>0);assert.equal(managedPhase.privateControls,0);
  assert.ok(live.receipts.every(row=>row.path===installed.path&&row.uid===0&&row.fileMode===0o644));
  assert.ok(calls.some(row=>row.args.at(-1).includes('/main.py')),'Original private helper never ran during eligible phase');
  return {realDefaultPathObserved:true,livePolicyTransitions:true,sameNativeOwner:true,privateControlsRestored:true,managedControlsRetired:true,policySha256:installed.sha256,nativeDebugSha256:createHash('sha256').update(debug).digest('hex')};
 }
 assert.ok(!calls.some(row=>row.args.at(-1).includes('/main.py')),'User status helper ran despite managed source');
 return {realDefaultPathObserved:true,originalPrivateHookRefusal:true,userHelperNotExecuted:true,policySha256:installed.sha256,nativeDebugSha256:createHash('sha256').update(debug).digest('hex')};
}
