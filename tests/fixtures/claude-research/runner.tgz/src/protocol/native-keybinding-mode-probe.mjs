import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const cli = '/frozen-claude/claude';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
assert.equal(process.platform, 'linux');
assert.equal(process.arch, 'arm64');
assert.ok(existsSync('/.dockerenv'));
assert.equal(sha(readFileSync(cli)), '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10');

const workspace = mkdtempSync('/tmp/claude-keybinding-mode-');
const config = join(workspace, '.claude');
mkdirSync(config, { mode: 0o700 });
const file = join(config, 'keybindings.json');
const bindingBytes = JSON.stringify({ bindings: [{ context: 'Global', bindings: {
  'ctrl+t': null,
  'ctrl+alt+p': 'app:toggleTodos',
} }] });
writeFileSync(file, bindingBytes, { mode: 0o600 });
const preload = join(workspace, 'inspect.mjs');
writeFileSync(preload, [
  "import {readFileSync,writeFileSync} from 'node:fs';",
  "import {IEs,qBn,uen,z8} from '/$bunfs/root/chunk-yybetdc6.js';",
  "import {xr} from '/$bunfs/root/chunk-tsw4ek67.js';",
  "const keys=IEs(), config=uen();",
  "const action=(key,alt)=>qBn({ key, ctrl:true, alt, shift:false, meta:alt, super:false },['Global'],keys)??null;",
  "writeFileSync(process.env.FIXTURE_OBSERVATION,JSON.stringify({ rollout:z8(), suppressed:xr('keybindings'), config, configBytes:readFileSync(config,'utf8'), defaultAction:action('t',false), customAction:action('p',true) }),{mode:0o600,flag:'wx'});",
].join('\n'));

const modes = [
  ['normal', {}, false],
  ['safe', { CLAUDE_CODE_SAFE_MODE: '1' }, true],
  ['bare', { CLAUDE_CODE_SIMPLE: '1' }, false],
];
const observations = [];
for (const [mode, settings, suppressed] of modes) {
  const resultPath = join(workspace, mode + '.json');
  const result = spawnSync(cli, ['--version'], {
    cwd: workspace, encoding: 'utf8', timeout: 12000, maxBuffer: 65536,
    env: {
      PATH: '/usr/bin:/bin', HOME: workspace, CLAUDE_CONFIG_DIR: config,
      BUN_OPTIONS: '--preload=' + preload, FIXTURE_OBSERVATION: resultPath,
      DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1', ...settings,
    },
  });
  assert.equal(result.error, undefined);
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stdout, /2\.1\.302/);
  const observed = JSON.parse(readFileSync(resultPath, 'utf8'));
  assert.equal(observed.config, file);
  assert.equal(observed.configBytes, bindingBytes);
  assert.equal(observed.rollout, true);
  assert.equal(observed.suppressed, suppressed);
  assert.equal(observed.defaultAction, suppressed ? 'app:toggleTodos' : null);
  assert.equal(observed.customAction, suppressed ? null : 'app:toggleTodos');
  observations.push({ mode, rollout: observed.rollout, suppressed, defaultAction: observed.defaultAction, customAction: observed.customAction });
}
assert.equal(readFileSync(file, 'utf8'), bindingBytes);
console.log(JSON.stringify({ platform: 'linux/arm64', version: '2.1.302', binarySha256: sha(readFileSync(cli)),
  keybindingsSha256: sha(bindingBytes), settingsUnchanged: true, observations }, null, 2));
