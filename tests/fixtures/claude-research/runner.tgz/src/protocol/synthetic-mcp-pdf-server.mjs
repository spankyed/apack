import {createInterface} from 'node:readline';
import {appendFileSync,readFileSync} from 'node:fs';
import {makeNativePageReviewPdf} from './native-read-media-fixture.mjs';
const pdf=makeNativePageReviewPdf();let count=0;
let identity;if(process.env.APACK_MCP_RECEIPT){const start=pid=>{const s=readFileSync('/proc/'+pid+'/stat','utf8');return s.slice(s.lastIndexOf(')')+2).split(' ')[19];};identity={pid:process.pid,ppid:process.ppid,start:start(process.pid),parentStart:start(process.ppid)};process.once('exit',code=>{if(process.env.APACK_MCP_EXITS)appendFileSync(process.env.APACK_MCP_EXITS,JSON.stringify({...identity,code})+'\n');});}
/** One ordinary embedded-resource MCP result; no native gate or file-store injection. */
createInterface({input:process.stdin}).on('line',line=>{
 if(Buffer.byteLength(line)>32768||++count>64){process.exitCode=1;process.stdin.destroy();return;}
 let request;try{request=JSON.parse(line);}catch{return;}
 if(request.id===undefined)return;
 if(process.env.APACK_MCP_RECEIPT)appendFileSync(process.env.APACK_MCP_RECEIPT,JSON.stringify({...identity,method:request.method,tool:request.params?.name})+'\n');
 let result,error;
 switch(request.method){
  case 'initialize':result={protocolVersion:request.params?.protocolVersion??'2024-11-05',capabilities:{tools:{}},serverInfo:{name:'release-report-fixture',version:'1.0.0'}};break;
  case 'ping':result={};break;
  case 'tools/list':result={tools:[{name:'echo',description:'Return the owned release-report PDF.',inputSchema:{type:'object',properties:{message:{type:'string'}},required:['message']}}]};break;
  case 'tools/call':if(request.params?.name==='echo'&&typeof request.params?.arguments?.message==='string')result={content:[{type:'resource',resource:{uri:'research://release/report.pdf',mimeType:'application/pdf',blob:pdf.toString('base64')}}]};else error={code:-32602,message:'Unknown release-report request'};break;
  default:error={code:-32601,message:'Unsupported release-report operation'};
 }
 process.stdout.write(JSON.stringify({jsonrpc:'2.0',id:request.id,...(error?{error}:{result})})+'\n');
});
