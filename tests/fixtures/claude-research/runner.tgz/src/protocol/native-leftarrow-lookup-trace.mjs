/** Diagnostic-only getter tracing. Every lookup delegates unchanged; never acceptance evidence alone. */
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { join, basename } from 'node:path';
if(process.platform!=='linux'||createHash('sha256').update(readFileSync(process.execPath)).digest('hex')!=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10'||!basename(process.env.HOME??'').startsWith('apack-terminal-owner-app-'))throw Error('Owned pinned Linux diagnostic required');
const original=Map.prototype.get,deadline=Date.now()+90000,rows=[];
Map.prototype.get=function(key){const value=Reflect.apply(original,this,[key]);try{
 if(Date.now()<deadline&&rows.length<32&&typeof key==='string'&&key.startsWith('apack-')&&typeof value?.box?.text==='string'&&Array.isArray(value.waiting)){
  const stack=new Error().stack??'';if(stack.includes('dispatchNativeAgentsGesture')){rows.push({at:Date.now(),client:key,textLength:value.box.text.length,cursor:value.box.cursor,active:!!value.active,waiting:value.waiting.length,stale:value.stale,offeredLength:value.offered?.text?.length});writeFileSync(join(process.env.HOME,'native-leftarrow-lookup-trace-'+process.pid+'.json'),JSON.stringify(rows));}
 }
}catch{}return value;};
