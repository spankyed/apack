import assert from 'node:assert/strict';
import {syncBuiltinESMExports} from 'node:module';
import fs from 'node:fs/promises';
import {readFileSync,writeFileSync,renameSync,existsSync} from 'node:fs';
import {join,resolve} from 'node:path';

/** Delay only the return of an actual read on this fixture's private raw image. */
export function installOwnedImageReadHold({workspace,path,filesystem=fs,holdMs=12000}){
 assert.equal(resolve(path),join(resolve(workspace),'prompt-fixture/release-cover.rgba'));
 assert.ok(Number.isInteger(holdMs)&&holdMs>=10&&holdMs<=15000);
 const original=filesystem.open,claimed=new Set();let restored=false;
 const pause=()=>new Promise(resolve=>setTimeout(resolve,20));
 filesystem.open=async function(...args){
  const handle=await Reflect.apply(original,this,args);
  if(String(args[0])!==path)return handle;
  const read=handle.read,close=handle.close;let heldReceipt,heldSave;
  if(typeof close==='function')handle.close=async function(...values){const result=await Reflect.apply(close,this,values);if(heldReceipt){heldReceipt.closedAt=Date.now();heldSave();}return result;};
  handle.read=async function(...values){
   const result=await Reflect.apply(read,this,values);
   let arm;try{arm=JSON.parse(readFileSync(join(workspace,'native-image-read.arm.json'),'utf8'));}catch{return result;}
   if(restored||!['timeout','close'].includes(arm.id)||claimed.has(arm.id))return result;
   claimed.add(arm.id);
   const receipt={id:arm.id,pid:process.pid,startedAt:Date.now(),bytesRead:result.bytesRead};
   const destination=join(workspace,'native-image-read-'+arm.id+'.json');
   const save=()=>{writeFileSync(destination+'.tmp',JSON.stringify(receipt));renameSync(destination+'.tmp',destination);};heldReceipt=receipt;heldSave=save;save();
   const release=join(workspace,'native-image-read-'+arm.id+'.release'),deadline=Date.now()+holdMs;
   while(!restored&&!existsSync(release)&&Date.now()<deadline)await pause();
   receipt.releasedAt=Date.now();receipt.reason=restored?'restored':existsSync(release)?'explicit':'safety-deadline';save();
   return result;
  };
  return handle;
 };
 if(filesystem===fs)syncBuiltinESMExports();
 return()=>{restored=true;filesystem.open=original;if(filesystem===fs)syncBuiltinESMExports();};
}
