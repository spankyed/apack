import http from 'node:http';

/** Activate one private skill, then request one fixed Bash marker per host input. */
export async function startSyntheticSkillOnceModel(){
 const calls=[],requests=[];let sequence=0;
 const server=http.createServer((req,res)=>{respond(req,res).catch(error=>{calls.push({error:error.message});if(!res.headersSent)res.writeHead(400);res.end('{}')})});server.requestTimeout=8000;
 async function respond(req,res){
  let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>2097152){res.writeHead(413);res.end();return}chunks.push(chunk)}
  const body=JSON.parse(Buffer.concat(chunks).toString()||'{}');if(req.url?.includes('count_tokens')){res.writeHead(200,{'content-type':'application/json'});res.end('{"input_tokens":10}');return}
  if(!req.url?.startsWith('/v1/messages')){res.writeHead(404);res.end('{}');return}
  const id=++sequence;if(id>12){res.writeHead(429);res.end('{}');return}requests.push(body);
  const results=body.messages?.flatMap(message=>Array.isArray(message.content)?message.content.filter(block=>block.type==='tool_result'):[])??[];
  const second=JSON.stringify(body.messages).includes('SECOND_ONCE_FIXTURE_INPUT');
  const skill=results.find(block=>block.tool_use_id==='skill_once_activation');
  const toolId=second?'skill_once_bash_second':'skill_once_bash_first';
  const completed=results.find(block=>block.tool_use_id===toolId);
  let block;
  if(!skill&&!second){
   if(!body.tools?.some(tool=>tool.name==='Skill'&&tool.input_schema?.properties?.skill))throw Error('Native Skill schema unavailable');
   block={type:'tool_use',id:'skill_once_activation',name:'Skill',input:{skill:'hook-once-fixture'}};
  }else if(!completed){
   if(!body.tools?.some(tool=>tool.name==='Bash'))throw Error('Bash unavailable');
   block={type:'tool_use',id:toolId,name:'Bash',input:{command:`/usr/bin/printf '${second?'second':'first'}' > once-tool-${second?'second':'first'}.txt`,description:'Write disposable once-hook fixture marker'}};
  }else block={type:'text',text:'OnceFixtureComplete'};
  const call={requestIndex:requests.length-1,response:block.type==='tool_use'?block.name:block.text,second,skillResultError:skill?.is_error===true,bashResultError:completed?.is_error===true};calls.push(call);
  const tool=block.type==='tool_use';const message={id:`msg_skill_once_${id}`,type:'message',role:'assistant',model:body.model,content:[block],stop_reason:tool?'tool_use':'end_turn',stop_sequence:null,usage:{input_tokens:10,output_tokens:5}};
  if(!body.stream){res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(message));call.delivered=true;return}
  res.writeHead(200,{'content-type':'text/event-stream'});const send=(type,value)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...value})}\n\n`);
  send('message_start',{message:{...message,content:[],stop_reason:null,usage:{input_tokens:10,output_tokens:0}}});send('content_block_start',{index:0,content_block:tool?{...block,input:{}}:{type:'text',text:''}});send('content_block_delta',{index:0,delta:tool?{type:'input_json_delta',partial_json:JSON.stringify(block.input)}:{type:'text_delta',text:block.text}});send('content_block_stop',{index:0});send('message_delta',{delta:{stop_reason:message.stop_reason,stop_sequence:null},usage:{output_tokens:5}});send('message_stop',{});res.end();call.delivered=true;
 }
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
 return{calls,requests,url:`http://127.0.0.1:${server.address().port}`,async close(){server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}};
}
