/** Read-only native row discovery. Never invoke a row writer or bypass config.set hooks. */
export function nativeSettingsInspector(outputPath) {
  if (typeof outputPath !== 'string' || !outputPath.startsWith('/') || outputPath.length > 4096) throw Error('Absolute owned settings evidence path required');
  return `
{
 const {readFileSync,writeFileSync}=await import('node:fs');
 const {createHash}=await import('node:crypto');
 const sha=value=>createHash('sha256').update(value).digest('hex');
 const binary=sha(readFileSync(process.execPath));
 const platforms={
  ['5262ce9de86243fed0d21edc39b271555'+'d56780d0112e2b194439fe1c6662d37']:{platform:'darwin',rows:'chunk-1ghyy712.js',runtime:'chunk-hqtnbrjd.js',binding:'ey',commit:'Ims',handleHash:'721f01dbe7e02c62a3bbb62e47974fe3f01f6f95d7a1145f92e71b5acab220ac'},
  '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10':{platform:'linux',rows:'chunk-t6m4bmxc.js',runtime:'chunk-a7b8k0bt.js',binding:'Zh',commit:'qfs',handleHash:'a00a517f89031951f2e1ade77ec67fc1f4547a5361a18843c2ae0053dee41125'}
 };
 const spec=platforms[binary];
 if(spec&&spec.platform===process.platform){
  let busy=false,attempts=0,done=false;
  const save=value=>{const body=JSON.stringify({binarySha256:binary,platform:process.platform,...value},null,2);if(Buffer.byteLength(body)>262144)throw Error('Native settings evidence exceeds bound');writeFileSync(${JSON.stringify(outputPath)},body,{mode:0o600});};
  const timer=setInterval(async()=>{if(busy||done)return;busy=true;try{
   if(++attempts>100){done=true;clearInterval(timer);save({status:'not-ready',attempts});return;}
   const runtime=await import('/$bunfs/root/'+spec.runtime),binding=runtime[spec.binding]();
   if(binding?.surface!=='terminal'||typeof binding.toolContext!=='function')return;
   const api=await import('/$bunfs/root/'+spec.rows);
   if(typeof api.configRowHandles!=='function'||sha(Function.prototype.toString.call(api.configRowHandles))!==spec.handleHash)throw Error('Original settings row producer changed');
   if(typeof runtime[spec.commit]!=='function')throw Error('Original config.set coordinator absent');
   const context=binding.toolContext(new AbortController()),handles=api.configRowHandles(context);
   if(!Array.isArray(handles)||handles.length>256)throw Error('Native row count exceeds reviewed bound');
   const rows=handles.map(handle=>{
    const row=handle.row;if(!row||typeof row.key!=='string'||row.key.length>4096)throw Error('Invalid native setting key');
    const value={key:row.key,kind:row.kind,valueType:typeof row.value,provider:row.provider,isLocked:row.isLocked,hasWriter:typeof handle.write==='function',hasLockReason:typeof handle.lockReason==='string'};
    if(['tips','reduceMotion','language','verbose','theme'].includes(row.key)&&['string','boolean','number','undefined'].includes(typeof row.value))value.value=row.value;
    if(Array.isArray(row.options)){if(row.options.length>256)throw Error('Native option bound exceeded');value.options=row.options;}
    return value;
   });
   done=true;clearInterval(timer);save({status:'observed',attempts,rows,commitFunction:spec.commit,commitFunctionSha256:sha(Function.prototype.toString.call(runtime[spec.commit])),writes:0,scope:'Original row discovery only. Raw writers were not called: lock, type, config.describe/config.set hooks, consent, stale ownership and acknowledgement still require native-owned integration.'});
  }catch(error){done=true;clearInterval(timer);save({status:'failed',message:String(error)});}finally{busy=false;}},100);
  timer.unref();
 }
}
`;
}
