/** Read-only native row discovery. Never invoke a row writer or bypass config.set hooks. */
export function nativeSettingsInspector(outputPath) {
  if (typeof outputPath !== 'string' || !outputPath.startsWith('/') || outputPath.length > 4096) throw Error('Absolute owned settings evidence path required');
  return `
{
 const {readFileSync,writeFileSync}=await import('node:fs');
 const {createHash}=await import('node:crypto');
 const sha=value=>createHash('sha256').update(value).digest('hex');
 const binary=sha(readFileSync(process.execPath));
 const platforms={
  ['5262ce9de86243fed0d21edc39b271555'+'d56780d0112e2b194439fe1c6662d37']:{platform:'darwin',rows:'chunk-1ghyy712.js',runtime:'chunk-hqtnbrjd.js',binding:'ey',commit:'Ims',handleHash:'721f01dbe7e02c62a3bbb62e47974fe3f01f6f95d7a1145f92e71b5acab220ac'},
  '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10':{platform:'linux',rows:'chunk-t6m4bmxc.js',runtime:'chunk-a7b8k0bt.js',binding:'Zh',commit:'qfs',handleHash:'a00a517f89031951f2e1ade77ec67fc1f4547a5361a18843c2ae0053dee41125'}
 };
 const spec=platforms[binary];
 if(spec&&spec.platform===process.platform){
  let busy=false,attempts=0,done=false;
  const save=value=>{const body=JSON.stringify({binarySha256:binary,platform:process.platform,...value},null,2);if(Buffer.byteLength(body)>262144)throw Error('Native settings evidence exceeds bound');writeFileSync(${JSON.stringify(outputPath)},body,{mode:0o600});};
  const timer=setInterval(async()=>{if(busy||done)return;busy=true;try{
   if(++attempts>100){done=true;clearInterval(timer);save({status:'not-ready',attempts});return;}
   const runtime=await import('/$bunfs/root/'+spec.runtime),binding=runtime[spec.binding]();
   if(binding?.surface!=='terminal'||typeof binding.toolContext!=='function')return;
   const api=await import('/$bunfs/root/'+spec.rows);
   if(typeof api.configRowHandles!=='function'||sha(Function.prototype.toString.call(api.configRowHandles))!==spec.handleHash)throw Error('Original settings row producer changed');
   if(typeof runtime[spec.commit]!=='function')throw Error('Original config.set coordinator absent');
   const context=binding.toolContext(new AbortController()),handles=api.configRowHandles(context);
   if(!Array.isArray(handles)||handles.length>256)throw Error('Native row count exceeds reviewed bound');
   const rows=handles.map(handle=>{
    const row=handle.row;if(!row||typeof row.key!=='string'||row.key.length>4096)throw Error('Invalid native setting key');
    const value={key:row.key,kind:row.kind,valueType:typeof row.value,provider:row.provider,isLocked:row.isLocked,hasWriter:typeof handle.write==='function',hasLockReason:typeof handle.lockReason==='string'};
    if(['tips','reduceMotion','language','verbose','theme'].includes(row.key)&&['string','boolean','number','undefined'].includes(typeof row.value))value.value=row.value;
    if(Array.isArray(row.options)){if(row.options.length>256)throw Error('Native option bound exceeded');value.options=row.options;}
    return value;
   });
   done=true;clearInterval(timer);save({status:'observed',attempts,rows,commitFunction:spec.commit,commitFunctionSha256:sha(Function.prototype.toString.call(runtime[spec.commit])),writes:0,scope:'Original row discovery only. Raw writers were not called: lock, type, config.describe/config.set hooks, consent, stale ownership and acknowledgement still require native-owned integration.'});
  }catch(error){done=true;clearInterval(timer);save({status:'failed',message:String(error)});}finally{busy=false;}},100);
  timer.unref();
 }
}
`;
}

/** Observe selected settings only; never clear native caches or invoke a writer. */
export function nativeSettingsFreshnessInspector(outputPath) {
  if (typeof outputPath !== 'string' || !outputPath.startsWith('/') || outputPath.length > 4096) throw Error('Absolute owned settings evidence path required');
  return `
{
 const {readFileSync,writeFileSync,existsSync}=await import('node:fs');
 const {createHash}=await import('node:crypto');
 const sha=value=>createHash('sha256').update(value).digest('hex');
 const binary=sha(readFileSync(process.execPath));
 const specs={
  ['5262ce9de86243fed0d21edc39b271555'+'d56780d0112e2b194439fe1c6662d37']:{platform:'darwin',rows:'chunk-1ghyy712.js',runtime:'chunk-hqtnbrjd.js',binding:'ey',settings:'chunk-1pjd7qsk.js',handleHash:'721f01dbe7e02c62a3bbb62e47974fe3f01f6f95d7a1145f92e71b5acab220ac'},
  '2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10':{platform:'linux',rows:'chunk-t6m4bmxc.js',runtime:'chunk-a7b8k0bt.js',binding:'Zh',settings:'chunk-x1ap3wr2.js',handleHash:'a00a517f89031951f2e1ade77ec67fc1f4547a5361a18843c2ae0053dee41125'}
 };
 const spec=specs[binary],home=process.env.HOME,config=process.env.CLAUDE_CONFIG_DIR;
 if(spec&&spec.platform===process.platform&&typeof home==='string'&&config===home+'/.claude'&&${JSON.stringify(outputPath)}.startsWith(home+'/')){
  const selected=value=>({spinnerTipsEnabled:typeof value?.spinnerTipsEnabled==='boolean'?value.spinnerTipsEnabled:null,prefersReducedMotion:typeof value?.prefersReducedMotion==='boolean'?value.prefersReducedMotion:null});
  const file=path=>{try{return selected(JSON.parse(readFileSync(path,'utf8')))}catch(error){return {error:error.code??error.name}}};
  const samples=[];let attempts=0,busy=false,last='',terminal=false;
  const save=status=>{const body=JSON.stringify({binarySha256:binary,platform:process.platform,status,attempts,samples,writes:0,scope:'Read-only selected effective/source/file metadata; no cache invalidation, callbacks or writer invocation.'},null,2);if(Buffer.byteLength(body)>262144)throw Error('Freshness evidence exceeds bound');writeFileSync(${JSON.stringify(outputPath)},body,{mode:0o600});};
  const timer=setInterval(async()=>{if(busy||terminal)return;busy=true;try{
   if(++attempts>240){terminal=true;clearInterval(timer);save('finished');return;}
   if(!existsSync(home+'/native-settings-freshness-ready'))return;
   const runtime=await import('/$bunfs/root/'+spec.runtime),binding=runtime[spec.binding]();
   if(binding?.surface!=='terminal'||typeof binding.toolContext!=='function')return;
   const api=await import('/$bunfs/root/'+spec.rows),settings=await import('/$bunfs/root/'+spec.settings);
   if(sha(Function.prototype.toString.call(api.configRowHandles))!==spec.handleHash||typeof settings.ut!=='function'||typeof settings.me!=='function')throw Error('Native freshness producer changed');
   const context=binding.toolContext(new AbortController()),handles=api.configRowHandles(context);
   if(!Array.isArray(handles)||handles.length>256)throw Error('Native freshness row bound exceeded');
   const snapshot={raw:handles.filter(handle=>['tips','reduceMotion'].includes(handle.row?.key)).map(handle=>({key:handle.row.key,value:handle.row.value})),effective:selected(settings.ut()),sources:Object.fromEntries(['userSettings','localSettings','projectSettings','flagSettings','policySettings'].map(source=>[source,selected(settings.me(source))])),files:{user:file(config+'/settings.json'),local:file(config+'/settings.local.json')},storageV5:context.storageV5!==undefined};
   const encoded=JSON.stringify(snapshot);if(encoded!==last){if(samples.length>=64)throw Error('Native freshness change bound exceeded');samples.push({at:Date.now(),...snapshot});last=encoded;save('observing');}
  }catch(error){terminal=true;clearInterval(timer);samples.push({at:Date.now(),error:String(error)});save('failed');}finally{busy=false;}},250);
  timer.unref();
 }
}
`;
}
