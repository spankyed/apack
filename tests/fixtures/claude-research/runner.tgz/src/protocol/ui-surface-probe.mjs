import {mkdir,mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {hash} from '../artifacts/runs.mjs';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';

/** Consume only a native button capability owned by the expected fixture. */
export function findUiButton(tree,{key,plugin},depth=0){
 if(depth>64||!tree||typeof tree!=='object'||Array.isArray(tree))return;
 if(tree.type==='Button'&&tree.props?.key===key&&tree.press?.plugin===plugin&&Number.isSafeInteger(tree.press?.handle))return{plugin,handle:tree.press.handle,key};
 if(Array.isArray(tree.children))for(const child of tree.children){const found=findUiButton(child,{key,plugin},depth+1);if(found)return found}
}

/** Explicit private structured UI client. Advertises no clipboard/composer answer capabilities. */
export async function probeUiSurface(executable,workspace,output,{pluginRender=false,interaction=false}={}){
 await mkdir(workspace,{recursive:true});const cwd=await mkdtemp(join(workspace,'ui-surface-'));
 const plugin=join(cwd,'plugin');let pluginSources;
 if(pluginRender){
  await mkdir(join(plugin,'.claude-plugin'),{recursive:true});await mkdir(join(plugin,'hooks'));
  pluginSources={manifest:JSON.stringify({name:'research-ui-fixture',version:'0.0.1'}),hooks:JSON.stringify({modules:['./register.ts']}),source:interaction?`export function register(on) {\n let presses=0;\n on("ui.render", {component:"AbovePrompt"}, async ($, e, next) => {\n  const {Box,Text,Button} = $.ui.resolve(e);\n  return Box({children:[Text({children:["Synthetic native UI fixture; count: " + presses]}),Button({key:"fixture-button",label:"Run fixture",onPress:async()=>{presses++;await $.fs.write("pressed.txt","native UI press " + presses + "\\n");$.ui.invalidate("ui.render");}}),await next(e)]});\n });\n}\n`:`export function register(on) {\n on("ui.render", {component:"AbovePrompt"}, async ($, e, next) => ({type:"Box", children:[{type:"Text",children:["Synthetic native UI fixture"]}, await next(e)]}));\n}\n`};
  await writeFile(join(plugin,'.claude-plugin','plugin.json'),pluginSources.manifest);await writeFile(join(plugin,'hooks','hooks.json'),pluginSources.hooks);await writeFile(join(plugin,'hooks','register.ts'),pluginSources.source);
 }
 const model=await startSyntheticModel(cwd,'TextOnly'),client='research-ui';
 const requests=[{subtype:'initialize',hooks:{}},{subtype:'ui_attach',surface:'desktop',client_id:'research:invalid',answers:[]},
  {subtype:'ui_attach',surface:'desktop',client_id:client,answers:[],viewport:{columns:100,rows:30,isFullscreen:false}},
  {subtype:'ui_attach',surface:'desktop',client_id:client,answers:[]},
  {subtype:'ui_panes',client_id:client},
  {subtype:'ui_render',surface:'desktop',client_id:client,component:'AbovePrompt',instance_id:'research-above',props:{}},
  {subtype:'ui_detach',client_id:client},{subtype:'ui_detach',client_id:client}];
 const message=index=>JSON.stringify({type:'control_request',request_id:`ui-${index}`,request:requests[index]})+'\n';
 let pending='',next=1,originalPress;const responses=[],events=[],unexpected=[];
 try{
  const run=await record({executable,cwd,output,timeoutMs:15000,
   args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--setting-sources','',...(pluginRender?['--plugin-dir',plugin]:[]),'--strict-mcp-config','--tools','','--permission-prompt-tool','stdio','--no-session-persistence','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'})],
   env:{PATH:process.env.PATH,HOME:cwd,CLAUDE_CONFIG_DIR:join(cwd,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[message(0)],
   onStdout(bytes,transport){pending+=bytes.toString('utf8');while(pending.includes('\n')){const at=pending.indexOf('\n'),line=pending.slice(0,at);pending=pending.slice(at+1);let value;try{value=JSON.parse(line)}catch{continue}
    if(value.type==='control_response'&&value.response?.request_id===`ui-${next-1}`){responses.push(value.response);
     if(interaction&&next===6){
      originalPress=findUiButton(value.response.response?.tree,{key:'fixture-button',plugin:'research-ui-fixture'});
      if(!originalPress){transport.stop('native-button-not-rendered');continue}
      requests.splice(6,0,{subtype:'ui_press',...originalPress,surface:'desktop',client_id:client},
       {subtype:'ui_render',surface:'desktop',client_id:client,component:'AbovePrompt',instance_id:'research-above',props:{}},
       {subtype:'ui_press',...originalPress,surface:'desktop',client_id:client});
     }
     if(next<requests.length)transport.send(message(next++));else transport.closeInput()}
    else if(value.type==='control_request'){unexpected.push(value);transport.send(JSON.stringify({type:'control_response',response:{subtype:'error',request_id:value.request_id,error:'No answer capability advertised by research fixture'}})+'\n')}
    else events.push(value);
   }}});
  const roster=(index)=>responses[index]?.response?.surfaces;
  const rendered=responses[5]?.response;
  const pluginObserved=pluginRender&&(rendered?.hooked===true&&rendered?.drawn_by?.includes('research-ui-fixture')&&JSON.stringify(rendered.tree).includes('Synthetic native UI fixture'));
  let pressed;try{pressed=await readFile(join(cwd,'pressed.txt'),'utf8')}catch(error){if(error.code!=='ENOENT')throw error}
  const detached=interaction?9:6;
  const redrawnButton=interaction?findUiButton(responses[7]?.response?.tree,{key:'fixture-button',plugin:'research-ui-fixture'}):undefined;
  const verified=(!interaction||(responses[6]?.response?.handled===true&&pressed==='native UI press 1\n'&&responses[8]?.response?.handled===false&&JSON.stringify(responses[7]?.response?.tree).includes('count: 1')&&Boolean(redrawnButton)&&redrawnButton.handle!==originalPress?.handle&&JSON.stringify(rendered.tree).includes('count: 0')&&events.some(value=>value.type==='system'&&value.subtype==='ui_invalidate'&&value.event==='ui.render')))&&(!pluginRender||pluginObserved)&&run.status==='complete'&&responses.length===requests.length&&responses[0]?.subtype==='success'&&responses[0]?.response?.capabilities?.includes('ui_surface_v1')&&responses[1]?.subtype==='error'&&responses.slice(2).every(value=>value.subtype==='success')&&JSON.stringify(roster(2))==='["desktop"]'&&JSON.stringify(roster(2))===JSON.stringify(roster(3))&&responses[detached]?.response?.detached===true&&responses[detached+1]?.response?.detached===false&&JSON.stringify(roster(detached))==='[]'&&JSON.stringify(roster(detached+1))==='[]'&&typeof rendered?.rewritten==='boolean'&&typeof rendered?.hooked==='boolean'&&rendered?.tree!==undefined&&unexpected.length===0&&model.calls.length===0;
  const evidence={verified,pluginRender,interaction,pressed,pluginObserved,...(pluginSources?{pluginSourceHashes:Object.fromEntries(Object.entries(pluginSources).map(([key,value])=>[key,hash(Buffer.from(value))]))}:{}),targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url))),requests,responses,events,unexpected,syntheticApiRequests:model.calls.length,realModelRequests:0,userPromptsSent:0,qualification:interaction?'Private native UI plugin render/press/redraw/stale-capability fixture; no app renderer or clipboard/composer support claimed.':pluginRender?'Private structured UI plugin render and attribution. No client event handling, clipboard/composer capabilities or rendered app parity.':'Private structured UI attach/base render/detach only. No clipboard/composer capabilities, plugin interaction or rendered app parity.'};
  await writeFile(join(run.directory,'ui-surface.json'),JSON.stringify(evidence,null,2)+'\n');
  if(!verified){const path=join(run.directory,'manifest.json');const manifest=JSON.parse(await readFile(path,'utf8'));await writeFile(path,JSON.stringify({...manifest,status:'failed',verificationFailure:'ui-surface-verification-failed'},null,2)+'\n')}
  return{...run,status:verified?'complete':'failed',verified,responseCount:responses.length,syntheticApiRequests:model.calls.length};
 }finally{await model.close()}
}
