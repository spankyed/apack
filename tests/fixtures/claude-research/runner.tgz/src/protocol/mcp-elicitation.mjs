import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {record} from './record.mjs';
import {startSyntheticModel} from './synthetic-model.mjs';
import {createRun,hash} from '../artifacts/runs.mjs';
/** Local MCP form request/host answer transport, independent of tool permission decisions. */
export async function probeMcpElicitation(executable,root,output){
 await mkdir(root,{recursive:true});const workspace=await mkdtemp(join(root,'mcp-elicitation-')),server=fileURLToPath(new URL('./synthetic-elicitation-server.mjs',import.meta.url));
 const run=await createRun(output,'mcp-elicitation',{targetSha256:hash(await readFile(executable)),driverSha256:hash(await readFile(new URL(import.meta.url))),serverSha256:hash(await readFile(server)),modelSha256:hash(await readFile(new URL('./synthetic-model.mjs',import.meta.url)))});const cases=[];
 try{
  for(const action of ['accept','decline','cancel','interrupt','url-accept','url-cancel','wrong-tool-reply']){
   const mode=action.startsWith('url-')?'url':'form',responseAction=action.replace(/^url-/,'');
   const cwd=join(workspace,action),home=join(cwd,'home'),capture=join(cwd,'mcp-input.jsonl');await mkdir(join(home,'.claude'),{recursive:true});
   const model=await startSyntheticModel(cwd,'mcp__research__echo');let pending='',result;const asks=[],permissions=[],toolResults=[],cancelledRequests=[];let interruptResponse;const answer=action==='wrong-tool-reply'?{behavior:'deny',message:'Invalid request: missing tool_name'}:responseAction==='accept'&&mode==='form'?{action:responseAction,content:{choice:'Alpha'}}:{action:responseAction};let transport;
   const control=(id,request)=>JSON.stringify({type:'control_request',request_id:id,request})+'\n';
   try{
    transport=await record({executable,cwd,output,timeoutMs:25000,args:['--print','--verbose','--input-format','stream-json','--output-format','stream-json','--setting-sources','','--settings',JSON.stringify({apiKeyHelper:'/usr/bin/printf research-fixture-key'}),'--strict-mcp-config','--mcp-config',JSON.stringify({mcpServers:{research:{type:'stdio',command:process.execPath,args:[server,capture,mode]}}}),'--tools','default','--permission-mode','default','--no-session-persistence','--max-turns','3','--permission-prompt-tool','stdio'],env:{PATH:process.env.PATH,HOME:home,CLAUDE_CONFIG_DIR:join(home,'.claude'),ANTHROPIC_BASE_URL:model.url,DISABLE_AUTOUPDATER:'1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1'},input:[control('initialize',{subtype:'initialize',hooks:{}})],onStdout(bytes,channel){
     pending+=bytes.toString();while(pending.includes('\n')){
      const i=pending.indexOf('\n'),text=pending.slice(0,i);pending=pending.slice(i+1);let value;try{value=JSON.parse(text)}catch{continue}
      if(value.type==='control_response'&&value.response?.request_id==='initialize')channel.send(JSON.stringify({type:'user',message:{role:'user',content:'Run the local research echo fixture once.'}})+'\n');
      if(value.type==='control_request'){
       if(value.request.subtype==='can_use_tool'){permissions.push(value.request);channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:{behavior:'allow',updatedInput:value.request.input}}})+'\n')}
       else if(value.request.subtype==='elicitation'){asks.push({...value.request,request_id:value.request_id});if(action==='interrupt'){channel.send(control('stop-elicitation',{subtype:'interrupt'}));continue}channel.send(JSON.stringify({type:'control_response',response:{subtype:'success',request_id:value.request_id,response:answer}})+'\n')}
       else throw Error('Unexpected native request '+value.request.subtype);
      }
      if(value.type==='control_cancel_request')cancelledRequests.push(value.request_id);
      if(value.type==='control_response'&&value.response?.request_id==='stop-elicitation')interruptResponse=value.response;
      if(value.type==='user'&&Array.isArray(value.message?.content))toolResults.push(...value.message.content.filter(block=>block.type==='tool_result'));
      if(value.type==='result'){result=value;channel.closeInput()}
     }
    }});
   }finally{await model.close()}
   if(action==='interrupt'){assert.equal(transport.status,'failed');assert.equal(transport.code,1);assert.equal(transport.reason,undefined);assert.equal(result?.subtype,'error_during_execution');assert.equal(result.terminal_reason,'aborted_tools');assert.equal(result.is_error,true)}
   else{assert.equal(transport.status,'complete');assert.equal(transport.code,0);assert.equal(result?.subtype,'success')}
   const inputs=(await readFile(capture,'utf8')).trim().split('\n').map(line=>JSON.parse(line));
   const initialize=inputs.find(value=>value.method==='initialize'),serverAnswer=inputs.find(value=>value.id==='fixture-elicitation'&&value.result)?.result;
   assert.equal(asks.length,1);assert.equal(permissions.length,1);assert.equal(permissions[0].tool_name,'mcp__research__echo');
   if(action!=='interrupt')assert.deepEqual(serverAnswer,action==='wrong-tool-reply'?{action:'cancel'}:answer);assert.equal(asks[0].mcp_server_name,'research');assert.equal(asks[0].mode,mode);
   if(mode==='form'){assert.deepEqual(asks[0].property_order,['choice']);assert.deepEqual(asks[0].requested_schema,{type:'object',properties:{choice:{type:'string',title:'Fixture',enum:['Alpha','Beta']}},required:['choice']});}
   else{assert.equal(asks[0].property_order,undefined);assert.equal(asks[0].requested_schema,undefined);assert.equal(asks[0].url,'https://example.invalid/research-elicitation');assert.equal(asks[0].elicitation_id,'research-url-fixture');}
   assert.equal(asks[0].title,'Synthetic fixture answer');assert.equal(asks[0].display_name,'Private elicitation');
   assert.deepEqual(initialize.params.capabilities.elicitation,{form:{},url:{}});
   if(action==='interrupt'){
    assert.equal(model.calls.length,1);assert.deepEqual(serverAnswer,{action:'cancel'});assert.ok(cancelledRequests.includes(asks[0].request_id));
    assert.equal(interruptResponse.subtype,'success');assert.deepEqual(interruptResponse.response.still_queued,[]);
    const call=inputs.find(value=>value.method==='tools/call');assert.ok(inputs.some(value=>value.method==='notifications/cancelled'&&value.params.requestId===call.id));
    assert.equal(toolResults.length,1);assert.equal(toolResults[0].is_error,true);assert.equal(toolResults[0].tool_use_id,'toolu_research_fixture');
   }else{assert.equal(model.calls.length,2);assert.equal(toolResults.length,1);assert.equal(Boolean(toolResults[0].is_error),false);
   assert.equal(toolResults[0].tool_use_id,'toolu_research_fixture');assert.deepEqual(JSON.parse(toolResults[0].content[0].text),{elicitation:action==='wrong-tool-reply'?{action:'cancel'}:answer});}
   const normalize=value=>JSON.parse(JSON.stringify(value).split(workspace).join('${WORKSPACE}'));
   cases.push(normalize({action,mode,answer:action==='interrupt'?undefined:answer,asks,permissions,toolResults,cancelledRequests,interruptResponse,terminal:{subtype:result.subtype,is_error:result.is_error??false,reason:result.terminal_reason??null},transportOutcome:{status:transport.status,code:transport.code,reason:transport.reason??null},serverNotifications:inputs.filter(value=>value.method==='notifications/cancelled'),clientCapabilities:initialize?.params.capabilities,serverAnswer,localModelRequests:model.calls.length,realModelRequests:0}));
  }
  await writeFile(join(run.directory,'mcp-elicitation.json'),JSON.stringify({cases,qualification:'Local stdio MCP form and URL metadata; URL never opened or fetched by this fixture; distinct tool permission and elicitation answers. Interrupt case deliberately verifies aborted_tools error result/exit 1 plus host/server cancellation; it is not successful tool completion. Native raw transport, not app UI, browser execution, cancellation races or other schema forms.'},null,2)+'\n');await run.finish({status:'complete'});return{directory:run.directory,status:'complete',cases:cases.map(value=>({action:value.action,asks:value.asks.length,permissions:value.permissions.length,serverAnswer:value.serverAnswer,cancelledRequests:value.cancelledRequests.length,interruptResponse:value.interruptResponse,localModelRequests:value.localModelRequests})),realModelRequests:0};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
