import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { hash } from '../artifacts/runs.mjs';
import { record } from './record.mjs';
import { recognizeOnboardingPrompt } from './pty-onboarding.mjs';
import { nativeActionKeyInspector } from './native-action-key-inspector.mjs';

/** Original interactive owner baseline. App keyboard projection is deliberately not inferred. */
export async function probeNativeActionKeys(executable, workspaceParent, output, checkout) {
  if (process.env.GITHUB_ACTIONS !== 'true' || process.env.RUNNER_ENVIRONMENT !== 'github-hosted' || process.platform !== 'darwin' || process.arch !== 'arm64') throw Error('Native action acceptance requires disposable GitHub macOS arm64');
  const targetSha256 = hash(await readFile(executable));
  assert.equal(targetSha256, '5262ce9de86243fed0d21edc39b271555d56780d0112e2b194439fe1c6662d37');
  await mkdir(workspaceParent, { recursive: true });
  const workspace = await mkdtemp(join(workspaceParent, 'native-actions-')), config = join(workspace, '.claude'), plugin = join(workspace, 'plugin');
  await mkdir(config); await mkdir(join(plugin, '.claude-plugin'), { recursive: true }); await mkdir(join(plugin, 'hooks'));
  const action = 'app:cycleDiffBase', engineAction = 'app:toggleTodos', reportPath = join(workspace, 'native-action-keys.json'), receiptsPath = join(workspace, 'native-action-key-receipts.json');
  const keyConfig = rebound => ({ bindings: [{ context: 'Global', bindings: { 'ctrl+alt+u': rebound ? null : action, ...(rebound ? { 'ctrl+alt+r': action } : {}), 'ctrl+alt+p': engineAction } }, { context: 'Chat', bindings: { 'ctrl+alt+o': 'chat:modelPicker' } }] });
  await writeFile(join(config, 'keybindings.json'), JSON.stringify(keyConfig(false)));
  await writeFile(join(plugin, '.claude-plugin/plugin.json'), JSON.stringify({ name: 'research-action-keys', version: '0.0.1' }));
  await writeFile(join(plugin, 'hooks/hooks.json'), JSON.stringify({ modules: ['./register.ts'] }));
  const fixture = `export function register(on){const receipts=[];on('ui.render',{component:'AbovePrompt'},($,e,next)=>{if(e.surface!=='terminal')return next(e);const {Box,Text,Button}=$.ui.resolve(e);const press=kind=>async()=>{receipts.push({kind,surface:e.surface,requestId:e.requestId,prompt:await $.prompt.read()});await $.fs.write('native-action-key-receipts.json',JSON.stringify(receipts));$.ui.invalidate('ui.render');};return Box({flexDirection:'column',children:receipts.filter(row=>row.kind==='fallback').length<2?[Text({children:['Review release context']}),Button({key:'review-context',label:'Review context',action:${JSON.stringify(action)},onPress:press('fallback')}),Button({key:'engine-priority',label:'Review task state',action:${JSON.stringify(engineAction)},onPress:press('engine-fallback')})]:[Text({children:['Review context action retired']})]});});}`;
  await writeFile(join(plugin, 'hooks/register.ts'), fixture);
  const preload = join(workspace, 'action-keys.mjs');
  await writeFile(preload, 'delete process.env.BUN_OPTIONS;\n' + nativeActionKeyInspector(reportPath));
  globalThis.self ??= globalThis;
  const { Terminal } = createRequire(join(checkout, 'packages/default-setup/package.json'))('@app/claude-terminal-xterm');
  const terminal = new Terminal({ cols: 100, rows: 30, allowProposedApi: true });
  const bridge = fileURLToPath(new URL('./pty_bridge.py', import.meta.url)), stages = [], screens = [];
  let transport, processing = false, phase = 'startup', phaseAt = Date.now(), theme = false, security = false, navigated = false, confirmed = false, trustAttempts = 0, trustAt = 0, exitAgain = false, failure, finalReport, finalReceipts = [];
  const stage = name => { phase = name; phaseAt = Date.now(); stages.push({ name, at: phaseAt }); };
  const readJson = async path => { try { return JSON.parse(await readFile(path, 'utf8')); } catch (error) { if (error.code === 'ENOENT' || error instanceof SyntaxError) return undefined; throw error; } };
  const control = async () => {
    if (!transport || processing) return; processing = true;
    try {
      const screen = Array.from({ length: terminal.rows }, (_, row) => terminal.buffer.active.getLine(terminal.buffer.active.baseY + row)?.translateToString(true) ?? '').join('\n');
      const report = await readJson(reportPath), sample = report?.samples.at(-1), receipts = await readJson(receiptsPath) ?? [];
      if (report?.error) throw Error(report.error);
      if (receipts.some(row => row.kind !== 'fallback')) throw Error('Original engine priority was bypassed');
      const fallback = () => sample?.handlers.some(row => row.action === action && row.fallback);
      const bound = key => sample?.bindings.some(row => row.action === action && row.chord.length === 1 && row.chord[0].key === key && row.chord[0].ctrl && row.chord[0].alt);
      if (Date.now() - phaseAt > (phase === 'startup' ? 40000 : 10000)) throw Error('Native action phase timed out: ' + phase);
      if (phase === 'startup') {
        const onboarding = recognizeOnboardingPrompt(screen, workspace);
        if (onboarding === 'theme' && !theme) { theme = true; transport.send('\r'); }
        else if (onboarding === 'security-notes' && theme && !security) { security = true; transport.send('\r'); }
        else if (onboarding === 'workspace-trust' && !navigated) { navigated = true; trustAt = Date.now(); transport.send('\x1b[B'); }
        else if (onboarding === 'workspace-trust-selected' && !navigated) { navigated = true; trustAt = Date.now(); }
        else if (onboarding === 'workspace-trust-selected' && trustAttempts < 3 && Date.now() - trustAt > 1200) { confirmed = true; trustAt = Date.now(); trustAttempts++; transport.send('\r'); }
        if (confirmed && sample && bound('u') && fallback() && sample.handlers.some(row => row.action === engineAction && !row.fallback) && sample.handlers.some(row => row.action === engineAction && row.fallback)) {
          assert.equal(sample.nativeKeyboardEventAvailable, true); assert.equal(sample.nativeDiscreteDispatchAvailable, true); assert.equal(sample.nativeRootKeyboardDispatchAvailable, true);
          assert.notEqual(sample.expandedView, 'tasks'); screens.push({ phase, screen }); stage('engine-priority'); transport.send('\x1b\x10');
        }
      } else if (phase === 'engine-priority' && sample?.expandedView === 'tasks') {
        assert.equal(receipts.length, 0); screens.push({ phase, screen }); stage('first-action'); transport.send('\x1b\x15');
      } else if (phase === 'first-action' && receipts.length === 1) {
        assert.equal(receipts[0].surface, 'terminal'); stage('dialog-open'); transport.send('\x1b\x0f');
      } else if (phase === 'dialog-open' && sample?.dialogCount > 0 && !fallback()) {
        screens.push({ phase, screen }); stage('dialog-blocked'); transport.send('\x1b\x15');
      } else if (phase === 'dialog-blocked' && Date.now() - phaseAt > 300) {
        assert.equal(receipts.length, 1); stage('dialog-close'); transport.send('\x1b');
      } else if (phase === 'dialog-close' && sample?.dialogCount === 0 && fallback()) {
        assert.equal(receipts.length, 1); stage('rebind'); await writeFile(join(config, 'keybindings.json'), JSON.stringify(keyConfig(true)));
      } else if (phase === 'rebind' && bound('r') && !bound('u')) {
        stage('rebound-action'); transport.send('\x1b\x15\x1b\x12');
      } else if (phase === 'rebound-action' && receipts.length === 2 && !fallback()) {
        assert.deepEqual(receipts.map(row => row.prompt), [receipts[0].prompt, receipts[0].prompt]); finalReport = report; finalReceipts = receipts; screens.push({ phase, screen }); stage('retired'); transport.send('\x1b\x12');
      } else if (phase === 'retired' && Date.now() - phaseAt > 300) {
        assert.equal(receipts.length, 2); stage('exit'); transport.send('\x04');
      } else if (phase === 'exit' && !exitAgain && /press\s+ctrl[+-]d\s+again\s+to\s+exit/i.test(screen)) { exitAgain = true; transport.send('\x04'); }
    } catch (error) { failure = String(error); transport.stop('native-action-verification-failed'); } finally { processing = false; }
  };
  const timer = setInterval(() => { void control(); }, 100);
  let run;
  try {
    run = await record({ executable: '/usr/bin/python3', cwd: workspace, output, timeoutMs: 90000,
      args: [bridge, executable, '--setting-sources', '', '--strict-mcp-config', '--tools', '', '--plugin-dir', plugin, '--settings', JSON.stringify({ apiKeyHelper: '/usr/bin/printf research-fixture-key' })],
      env: { PATH: process.env.PATH, HOME: workspace, CLAUDE_CONFIG_DIR: config, TERM: 'xterm-256color', COLUMNS: '100', LINES: '30', ANTHROPIC_BASE_URL: 'http://127.0.0.1:9', DISABLE_AUTOUPDATER: '1', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: '1', BUN_OPTIONS: '--preload=' + JSON.stringify(preload) },
      onStdout(bytes, owner) { transport = owner; terminal.write(bytes.toString('utf8')); },
    });
  } finally { clearInterval(timer); terminal.dispose(); }
  const receipts = await readJson(receiptsPath) ?? finalReceipts, report = await readJson(reportPath) ?? finalReport;
  let nativeGone = false;
  if (Number.isSafeInteger(report?.nativePid)) { try { process.kill(report.nativePid, 0); } catch (error) { if (error.code === 'ESRCH') nativeGone = true; else throw error; } }
  const verified = run.status === 'complete' && !failure && phase === 'exit' && nativeGone && receipts.length === 2 && receipts.every(row => row.kind === 'fallback' && row.surface === 'terminal');
  const proof = { verified, failure, targetSha256, nativePid: report?.nativePid, nativeGone, stages, screens, receipts, fixtureSha256: hash(Buffer.from(fixture)), driverSha256: hash(await readFile(new URL(import.meta.url))), inspectorSha256: hash(await readFile(new URL('./native-action-key-inspector.mjs', import.meta.url))), bridgeSha256: hash(await readFile(bridge)), originalBoundKeys: keyConfig(false), reboundKeys: keyConfig(true), userPromptsSent: 0, realModelRequests: 0, actualAppGui: false, qualification: 'Original native configured-action, engine priority, dialog suppression/restoration, rebind and unmount baseline only. Pane/registration collisions and ordinary-composer app projection remain open.' };
  await writeFile(join(run.directory, 'native-action-key-proof.json'), JSON.stringify(proof, null, 2) + '\n');
  await writeFile(join(workspace, 'native-action-key-proof.json'), JSON.stringify(proof, null, 2) + '\n');
  if (!verified) { const path = join(run.directory, 'manifest.json'), manifest = JSON.parse(await readFile(path, 'utf8')); await writeFile(path, JSON.stringify({ ...manifest, status: 'failed', verificationFailure: 'native-action-keys' }, null, 2) + '\n'); }
  return { ...run, status: verified ? 'complete' : 'failed', verified, nativeGone, qualification: proof.qualification };
}
