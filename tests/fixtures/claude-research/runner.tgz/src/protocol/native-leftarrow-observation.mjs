/** Read-only original input/focus evidence; never changes a dialog, task, key or native gate. */
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { join, basename } from 'node:path';
if(process.platform!=='linux'||createHash('sha256').update(readFileSync(process.execPath)).digest('hex')!=='2bd4f4e5ed5cb09955b490098f745321cb5491e7ea8c752ba1e3bb010cdadb10')throw Error('Pinned offline Linux Claude required');
if(!basename(process.env.HOME??'').startsWith('apack-terminal-owner-app-'))throw Error('Owned research HOME required');
const deadline=Date.now()+90000,history=[];let reading=false,prior;
const timer=setInterval(async()=>{if(Date.now()>deadline){clearInterval(timer);return}if(reading)return;reading=true;
try{
 const {ai}=await import('/$bunfs/root/chunk-f7hx5xpd.js');const pending=[ai().get(process.stdout)?.container?.current],seen=new Set(),inputs=[];
 while(pending.length){const f=pending.pop();if(!f||seen.has(f))continue;if(seen.size>=4096)throw Error('Read-only input bound');seen.add(f);
  if(typeof f.type==='function'&&f.type.name==='Nr'&&typeof f.memoizedProps?.onLeftArrowOnEmpty==='function'){
   const rows=f.updateQueue?.memoCache?.data??[],row=rows.find(row=>Array.isArray(row)&&row.length===58),p=f.memoizedProps,ancestors=[];let a=f;
   for(let i=0;a&&i<64;i++,a=a.return){for(const cache of a.updateQueue?.memoCache?.data??[]){if(!Array.isArray(cache)||cache.length<=341||!cache[337])continue;const c=cache[337];ancestors.push({type:a.type?.name,slots:cache.length,controller:c.constructor?.name,matching259:cache[259]===c,matching341:cache[341]?.gesture===c,classSha256:typeof c.constructor==='function'?createHash('sha256').update(String(c.constructor)).digest('hex'):null});}}
   inputs.push({valueLength:typeof p.value==='string'?p.value.length:null,focus:p.focus,offset:row?.[53]?.offset,optionsValueLength:typeof row?.[47]?.value==='string'?row[47].value.length:null,drawnInputMatches:row?.[54]?.props?.inputState===row?.[53],ancestors});
  }
  if(f.sibling)pending.push(f.sibling);if(f.child)pending.push(f.child);
 }
 if(!inputs.length)return;const key=JSON.stringify(inputs);if(key===prior)return;prior=key;history.push({at:Date.now(),pid:process.pid,inputs});if(history.length>32)history.shift();writeFileSync(join(process.env.HOME,'native-leftarrow-input-observation-'+process.pid+'.json'),JSON.stringify(history));
}catch(error){writeFileSync(join(process.env.HOME,'native-leftarrow-input-observer-error-'+process.pid+'.json'),JSON.stringify({error:String(error)}))}finally{reading=false}
},200);timer.unref();
