import { parse } from 'acorn';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { hash, readCompleteRun, createRun } from '../artifacts/runs.mjs';

/** Candidate dispatch objects, distinct from boolean policy tables or declared wire schemas. */
export function inspectControlHandlerMaps(source, knownSubtypes) {
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module' });
  const maps = [];
  function walk(node) {
    if (!node?.type) return;
    if (node.type === 'ObjectExpression' && node.properties.length >= 5) {
      const properties = node.properties;
      const keys = properties.map(property => property.type === 'Property' && !property.computed
        ? property.key.name ?? property.key.value : null);
      if (keys.filter(key => knownSubtypes.has(key)).length >= 5
        && properties.every(property => property.type === 'Property' && property.value.type === 'Identifier')) {
        maps.push({ start: node.start, end: node.end, handlers: properties.map((property, index) => ({
          subtype: keys[index], handlerSymbol: property.value.name, start: property.start,
          declaredInRequestUnion: knownSubtypes.has(keys[index]),
        })) });
      }
    }
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) { for (const child of value) walk(child); }
      else if (value?.type) walk(value);
    }
  }
  walk(ast);
  return maps;
}

export async function catalogControlHandlerMaps(protocolRun, output) {
  const parent = await readCompleteRun(protocolRun, 'protocol-schemas');
  const schemaBytes = await readFile(join(protocolRun, 'protocol-schemas.json'));
  if (hash(schemaBytes) !== parent.protocolSchemasSha256) throw new Error('Protocol inventory changed');
  const known = new Set(JSON.parse(schemaBytes).requests.map(request => request.subtype));
  const catalog = await readCompleteRun(parent.inputs.catalogRun, 'catalog');
  const extraction = await readCompleteRun(catalog.inputs.extraction, 'extract');
  const bytes = await readFile(join(catalog.inputs.extraction, 'inventory.json'));
  if (hash(bytes) !== extraction.inventorySha256) throw new Error('Extraction inventory changed');
  const run = await createRun(output, 'control-handler-maps', { protocolRun, extraction: catalog.inputs.extraction,
    targetSha256: parent.inputs.targetSha256, scannerSha256: hash(await readFile(new URL(import.meta.url))), parser: 'acorn@8.15.0' });
  try {
    const modules = [];
    for (const file of JSON.parse(bytes)) {
      if (file.loader !== 'js') continue;
      if (!['latin1', 'utf8', 'utf-8'].includes(file.encoding)) throw new Error('Unsupported source encoding');
      const source = await readFile(join(catalog.inputs.extraction, 'extracted', file.path));
      if (hash(source) !== file.sha256) throw new Error(`Source changed: ${file.path}`);
      const maps = inspectControlHandlerMaps(source.toString(file.encoding), known);
      if (maps.length) modules.push({ path: file.path, sha256: hash(source), maps });
    }
    const result = JSON.stringify({ modules,
      qualification: 'Candidate literal identifier-valued maps with at least five declared control keys. Not exhaustive dispatch discovery; references do not prove availability, reachability or callable handlers.' }, null, 2) + '\n';
    await writeFile(join(run.directory, 'control-handler-maps.json'), result);
    await run.finish({ status: 'complete', outputSha256: hash(Buffer.from(result)), modules: modules.length });
    return { directory: run.directory, status: 'complete', modules: modules.length };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
