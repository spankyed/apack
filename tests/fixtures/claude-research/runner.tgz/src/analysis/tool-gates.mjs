import { parse } from 'acorn';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createRun, hash, readCompleteRun } from '../artifacts/runs.mjs';
const fields=['isEnabled','isReadOnly','isConcurrencySafe','isOpenWorld','shouldDefer'];
const key=property=>property.type==='Property' ? (!property.computed?property.key.name??property.key.value:property.key.type==='Literal'?property.key.value:null):null;
function walk(node,visit){if(!node?.type)return;visit(node);for(const value of Object.values(node)){if(Array.isArray(value)){for(const child of value)if(child?.type)walk(child,visit);}else if(value?.type)walk(value,visit);}}
function boolean(node){
 if(node?.type==='Literal'&&typeof node.value==='boolean')return node.value;
 if(node?.type==='UnaryExpression'&&node.operator==='!'&&node.argument.type==='Literal'&&['boolean','number','string'].includes(typeof node.argument.value))return !node.argument.value;
 return null;
}
function describe(property,source){
 const value=property.value,callback=['ArrowFunctionExpression','FunctionExpression'].includes(value.type);
 let expression=callback?(value.body.type==='BlockStatement'?value.body.body.length===1&&value.body.body[0].type==='ReturnStatement'?value.body.body[0].argument:null:value.body):value;
 const calls=[];walk(value,node=>{if(node.type==='CallExpression')calls.push({start:node.start,end:node.end,callee:node.callee.type==='Identifier'?node.callee.name:node.callee.type==='MemberExpression'&&!node.callee.computed?source.slice(node.callee.start,node.callee.end).slice(0,160):null});});
 return {start:property.start,end:property.end,kind:property.kind,callback,async:callback?value.async:false,valueType:value.type,literalBoolean:boolean(expression),calls};
}

/** Local syntax only: declaration facts never imply effective registration, permission policy or availability. */
export function inspectToolGates(source,candidates){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),objects=new Map();walk(ast,node=>{if(node.type==='ObjectExpression')objects.set(node.start,node);});
 return candidates.map(candidate=>{
  const object=objects.get(candidate.start);if(!object||object.end!==candidate.end)throw new Error('Tool candidate source range changed');
  const declarations={};for(const field of fields)declarations[field]=object.properties.filter(property=>key(property)===field).map(property=>describe(property,source));
  return {name:candidate.resolvedName??candidate.literalName??null,start:object.start,end:object.end,unresolvedOverrides:object.properties.some(property=>property.type==='SpreadElement'||property.computed&&key(property)===null),declarations};
 });
}

export async function catalogToolGates(definitionsRun,output){
 const parent=await readCompleteRun(definitionsRun,'tool-definitions'),bytes=await readFile(join(definitionsRun,'tool-definitions.json'));
 if(hash(bytes)!==parent.outputSha256)throw new Error('Tool definitions changed');
 const extraction=await readCompleteRun(parent.inputs.extraction,'extract'),inventoryBytes=await readFile(join(parent.inputs.extraction,'inventory.json'));
 if(hash(inventoryBytes)!==extraction.inventorySha256)throw new Error('Extraction inventory changed');
 const inventory=new Map(JSON.parse(inventoryBytes).map(file=>[file.path,file]));
 const run=await createRun(output,'tool-gates',{definitionsRun,targetSha256:parent.inputs.targetSha256,scannerSha256:hash(await readFile(new URL(import.meta.url))),parser:'acorn@8.15.0'});
 try{
  const modules=[];
  for(const module of JSON.parse(bytes).modules){
   const file=inventory.get(module.path);if(!file||file.loader!=='js'||file.sha256!==module.sha256)throw new Error('Unverified tool module');
   if(!['latin1','utf8','utf-8'].includes(file.encoding))throw new Error('Unsupported source encoding');
   const source=await readFile(join(parent.inputs.extraction,'extracted',module.path));if(hash(source)!==file.sha256)throw new Error(`Source changed: ${module.path}`);
   modules.push({path:module.path,sha256:file.sha256,encoding:file.encoding,tools:inspectToolGates(source.toString(file.encoding),module.tools)});
  }
  const result={modules,qualification:'Own local declarations for five tool predicates/markers. LiteralBoolean is only a direct literal or single return expression, not an effective gate. Duplicate declarations, accessors, async callbacks and unresolved spread/computed overrides remain explicit. Calls are lexical navigation, not symbol resolution or runtime reachability. Absent declaration is not false. No recovered code executed.'};
  const outputBytes=Buffer.from(JSON.stringify(result,null,2)+'\n');await writeFile(join(run.directory,'tool-gates.json'),outputBytes);
  const candidates=modules.reduce((sum,module)=>sum+module.tools.length,0);await run.finish({status:'complete',outputSha256:hash(outputBytes),modules:modules.length,candidates});return {directory:run.directory,status:'complete',modules:modules.length,candidates};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
