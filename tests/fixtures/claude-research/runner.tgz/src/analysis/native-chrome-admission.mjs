import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {parse} from 'acorn';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
/** Static provenance for the selected original Chrome admission chain; never evaluates source. */
export function inspectNativeChromeAdmission(files){
 assert.ok(Array.isArray(files)&&files.length>0&&files.length<=16);
 const paths=new Set(),functions=[];
 for(const file of files){
  assert.equal(typeof file.path,'string');assert.ok(!paths.has(file.path),'Duplicate source path');paths.add(file.path);
  assert.ok(Buffer.isBuffer(file.bytes)&&file.bytes.length<=8*1024**2);assert.ok(['utf8','latin1'].includes(file.encoding));
  const source=file.bytes.toString(file.encoding),ast=parse(source,{ecmaVersion:'latest',sourceType:'module'});
  assert.ok(Array.isArray(file.symbols)&&file.symbols.length>0&&file.symbols.length<=16);
  for(const symbol of file.symbols){
   assert.equal(typeof symbol,'string');const declarations=ast.body.filter(node=>node.type==='FunctionDeclaration'&&node.id?.name===symbol);
   assert.equal(declarations.length,1,'Expected unique top-level admission function '+symbol);
   const node=declarations[0];functions.push({path:file.path,encoding:file.encoding,fileSha256:sha(file.bytes),symbol,start:node.start,end:node.end,functionSha256:sha(source.slice(node.start,node.end))});
  }
 }
 return{kind:'static-native-chrome-admission',functions,qualification:'Selected source identity/ranges only. Gate interpretation must be reviewed against these original functions and their imports. No source execution, account qualification, browser connection or app acceptance.'};
}
