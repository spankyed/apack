import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { basename, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { runInNewContext } from 'node:vm'
import { parse } from 'acorn'
import { hash } from '../artifacts/runs.mjs'

const targets = {
  'linux-arm64': {
    source: ['chunk-a7b8k0bt.js', 'b443eac014f19ee213c7ce08adcade84d8b20555b9a247e3a47d136b92c962d7'],
    transport: ['chunk-tm94jfk2.js', 'c9919154713d1aac8842d33661daf124b56bdbb24f39657319c99afcee00b2bc'],
    tool: ['chunk-f00rdtft.js', 'd23c16f9af592a153e44c06ab3975883b1cdeaf91a2a44947532f2bec8977037'],
    classifier: 'OZt', text: 'DZt', poll: 'IZt', fetch: 'wEe', choose: 'pVo',
  },
  'darwin-arm64': {
    source: ['chunk-hqtnbrjd.js', '5d138d857b67d4417c68137baa33974a5b8ecf4341db67a32a12f4c394b434da'],
    transport: ['chunk-2jyw98bz.js', '60354055046d457532c350b068b31a20ff86e06ca2ebe08c0b80110b41a5ef6c'],
    tool: ['chunk-qn3dayn5.js', '4f2e6922fcad20fc5978c845b92f2e9c43044896f8f0bd8620c175e9670b2fb3'],
    classifier: 'wZt', text: 'TZt', poll: 'vZt', fetch: 'Ake', choose: 'g2o',
  },
}

async function reviewedModule(folder, [file, sha256]) {
  const bytes = await readFile(join(folder, file))
  assert.equal(hash(bytes), sha256, 'Unreviewed source module ' + file)
  const source = bytes.toString('utf8')
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module' })
  const declarations = ast.body.flatMap(node => node.type === 'VariableDeclaration' ? node.declarations : [node])
  const named = name => {
    const matches = declarations.filter(node => node.id?.name === name)
    assert.equal(matches.length, 1, name)
    return matches[0]
  }
  const text = node => source.slice(node.start, node.end)
  return {
    file, sha256,
    importFrom(name) {
      const imports = ast.body.filter(node=>node.type==='ImportDeclaration'&&node.specifiers.some(spec=>spec.local.name===name))
      assert.equal(imports.length, 1, name)
      return basename(imports[0].source.value)
    },
    textOf: name => text(named(name)),
    receipt(names) {
      return Object.fromEntries(names.map(name=>{
        const node = named(name), selected = text(node)
        const start = Buffer.byteLength(source.slice(0,node.start)), end = start + Buffer.byteLength(selected)
        assert.equal(bytes.subarray(start,end).toString('utf8'), selected)
        return [name,{start,end,sha256:hash(Buffer.from(selected))}]
      }))
    },
    literal(name) {
      const node = named(name)
      assert.equal(node.init?.type, 'Literal', name)
      return node.init.value
    },
  }
}

/** Exercise the reviewed event classifier directly against synthetic wire payloads, with no CLI or HTTP. */
export async function verifyUltraplanCloudEvents(platform, folder) {
  const target = targets[platform]
  assert.ok(target, 'Select one reviewed platform')
  const [main, transport, tool] = await Promise.all([
    reviewedModule(folder, target.source), reviewedModule(folder, target.transport), reviewedModule(folder,target.tool),
  ])
  assert.equal(main.importFrom(target.fetch), transport.file)
  assert.equal(main.importFrom('Lu'), tool.file)
  const toolName = tool.literal('Lu'), localMarker = main.literal('q8o')
  assert.equal(toolName, 'ExitPlanMode')
  assert.equal(localMarker, '__ULTRAPLAN_TELEPORT_LOCAL__')
  const originalFunctions = [target.text, 'K8o', 'V8o', target.classifier]
  const factory = runInNewContext(originalFunctions.map(main.textOf).join('\n') + '\n() => new ' + target.classifier + '()',
    { Lu:toolName, q8o:localMarker }, { timeout:1000, codeGeneration:{strings:false,wasm:false} })
  const call = (id, name=toolName) => ({type:'assistant',session_id:'owned-cloud-session',message:{content:[{type:'tool_use',name,id}]}})
  const answer = (id, content, is_error) => ({type:'user',session_id:'owned-cloud-session',message:{content:[{type:'tool_result',tool_use_id:id,content,is_error}]}})
  const one = factory(), cases = []
  function verify(name, actual, expected) {
    assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, name)
    cases.push(name)
  }
  verify('wrong tool and foreign result do not open choice',one.ingest([call('read','Read'),answer('read',localMarker+'\nignored',true)]),{kind:'unchanged'})
  verify('ExitPlanMode appears before approval',one.ingest([call('plan-1')]),{kind:'pending'})
  verify('unrelated approval result does not settle the plan',one.ingest([answer('unknown',localMarker+'\nignored',true)]),{kind:'pending'})
  verify('unmarked error is a rejection',one.ingest([answer('plan-1','Needs revision',true)]),{kind:'rejected',id:'plan-1'})
  verify('new plan may await approval after rejection',one.ingest([call('plan-2')]),{kind:'pending'})
  const firstLine = '# Approved release plan'
  const rest = '\n\nKeep the original rollback step.  '
  verify('local marker in the matched error carries the full revised plan',
    one.ingest([answer('plan-2',[{type:'text',text:localMarker+'\n'+firstLine},{type:'text',text:rest}],true)]),
    {kind:'teleport',plan:firstLine+rest.trimEnd()})
  assert.equal(one.rejectCount,1)
  const remote = factory()
  verify('edited remote approval retains the edited plan',
    remote.ingest([call('remote'),answer('remote','## Approved Plan (edited by user):\n'+firstLine+rest,false)]),
    {kind:'approved',plan:firstLine+rest.trimEnd()})
  const malformed = factory()
  assert.throws(()=>malformed.ingest([call('bad'),answer('bad','No original approval marker',false)]),/no "## Approved Plan:" marker/)
  cases.push('markerless success is refused')
  const terminated = factory()
  verify('cloud failure ends pending approval without a local choice',terminated.ingest([call('interrupted'),{type:'result',session_id:'owned-cloud-session',subtype:'error_during_execution'}]),
    {kind:'terminated',subtype:'error_during_execution'})

  const fetch = transport.textOf(target.fetch)
  assert.ok(fetch.includes('/v1/code/sessions/')&&fetch.includes('/events')&&fetch.includes('sequence_num')&&fetch.includes('next_cursor'))
  const chooser = main.textOf(target.choose)
  assert.ok(chooser.includes('auto-continuation')&&chooser.includes('resetTrigger:"fresh_session"')&&chooser.includes('Ultraplan rejected'))
  return {
    platform, cases,
    sources: [
      {file:main.file,sha256:main.sha256,sites:main.receipt([...originalFunctions,target.poll,target.choose,'q8o'])},
      {file:transport.file,sha256:transport.sha256,sites:transport.receipt([target.fetch])},
      {file:tool.file,sha256:tool.sha256,sites:tool.receipt(['Lu'])},
    ],
    wire: {
      events:'GET /v1/code/sessions/{id}/events',
      projection:'Each event supplies sequence_num and payload. Workflow events require session_id. next_cursor controls pagination.',
      localApproval:'Matching ExitPlanMode tool_result with is_error:true and the local handoff marker.',
      remoteApproval:'Matching successful ExitPlanMode tool_result with the ordinary or edited approval marker.',
    },
    qualification:'Recovered original classifiers executed in a VM against synthetic payloads. Polling, cloud admission and desktop handoff are unverified here.',
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [platform, files] = process.argv.slice(2)
  assert.ok(platform && files, 'Supply the platform and recovered files directory')
  console.log(JSON.stringify(await verifyUltraplanCloudEvents(platform, files), null, 2))
}
