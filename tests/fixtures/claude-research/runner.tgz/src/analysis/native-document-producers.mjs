import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join,posix} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
import {analysisProvenance} from './provenance.mjs';

const key=node=>node?.type==='Identifier'?node.name:node?.type==='Literal'?node.value:undefined;
const isFunction=node=>['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node.type);
/** Record syntax, not inferred runtime eligibility or a claim that dynamic producers cannot exist. */
export function inspectNativeDocumentProducers(source){
 const tree=parse(source,{ecmaVersion:'latest',sourceType:'module'}),constructors=[],references=[],functions=[],imports=[];
 const stack=[{node:tree,owner:undefined}];
 while(stack.length){
  const {node,owner:prior}=stack.pop();let owner=prior;
  if(isFunction(node)){
   owner={name:node.id?.name??null,start:node.start,end:node.end,sha256:hash(source.slice(node.start,node.end))};
   functions.push(owner);
  }
  if(node.type==='ImportDeclaration')for(const specifier of node.specifiers)imports.push({local:specifier.local.name,imported:key(specifier.imported),module:posix.basename(node.source.value)});
  if(node.type==='ObjectExpression'){
   const type=node.properties.find(field=>field.type==='Property'&&(!field.computed||field.key.type==='Literal')&&key(field.key)==='type');
   if(type?.value.type==='Literal'&&type.value.value==='document')constructors.push({start:node.start,end:node.end,sha256:hash(source.slice(node.start,node.end)),fields:node.properties.map(field=>field.type==='SpreadElement'?'...':key(field.key)??'[computed]'),owner});
  }
  if(node.type==='Literal'&&node.value==='document')references.push({start:node.start,end:node.end,owner});
  for(const value of Object.values(node)){
   if(Array.isArray(value)){for(let index=value.length-1;index>=0;index--)if(value[index]?.type)stack.push({node:value[index],owner});}
   else if(value?.type)stack.push({node:value,owner});
  }
 }
 return {constructors,references,functions,imports};
}

export async function recoverNativeDocumentProducers(extraction,output){
 const parent=await readCompleteRun(extraction,'extract'),bytes=await readFile(join(extraction,'inventory.json'));
 if(hash(bytes)!==parent.inventorySha256)throw Error('Extraction inventory changed');
 const inventory=JSON.parse(bytes),run=await createRun(output,'native-document-producers',{extraction,targetSha256:parent.inputs.targetSha256,inventorySha256:hash(bytes),...await analysisProvenance(new URL(import.meta.url))});
 try{
  const scanned=[],modules=[];
  for(const file of inventory.filter(file=>file.loader==='js')){
   if(posix.isAbsolute(file.path)||file.path.includes('\\')||file.path.split('/').includes('..'))throw Error('Unsafe source path');
   if(!['latin1','utf8','utf-8'].includes(file.encoding))throw Error('Unsupported source encoding');
   const bytes=await readFile(join(extraction,'extracted',file.path));if(hash(bytes)!==file.sha256)throw Error('Source changed: '+file.path);
   const source=bytes.toString(file.encoding);scanned.push({path:file.path,sha256:file.sha256,encoding:file.encoding});
   // Escaped spellings require parsing even without the literal word in source.
   if(!source.includes('document')&&!source.includes('\\'))continue;
   const result=inspectNativeDocumentProducers(source);
   if(result.references.length)modules.push({path:file.path,sha256:file.sha256,encoding:file.encoding,...result});
  }
  const result={scanned,modules,qualification:'All inventoried JavaScript bytes are hash-checked; explicit document literals/constructors are recorded with lexical function boundaries. Dynamic object assembly, incoming values and runtime gates require separate dataflow and native evidence. No recovered code is executed.'};
  const encoded=JSON.stringify(result,null,2)+'\n';await writeFile(join(run.directory,'document-producers.json'),encoded);await run.finish({status:'complete',outputSha256:hash(encoded)});return {directory:run.directory,...result};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
