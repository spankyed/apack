import {parse} from 'acorn';

const property = node => node?.type === 'MemberExpression'
  ? node.computed ? node.property.type === 'Literal' ? node.property.value : null : node.property.name
  : null;
const children = node => Object.values(node).flatMap(value => Array.isArray(value)
  ? value.filter(child => child?.type) : value?.type ? [value] : []);
const functions = new Set(['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression']);

/** Conservative lexical const aliases. Candidates do not establish object identity or reachability. */
export function inspectRequestAliases(source, known = new Set()) {
  const ast = parse(source,{ecmaVersion:'latest',sourceType:'module'});
  const scopes = new WeakMap(), owners = new WeakMap(), all = [];
  const makeScope = (parent,isFunction = false) => ({parent,isFunction,bindings:new Map()});
  const root = makeScope(null,true);
  function bindPattern(pattern, scope, record = null, path = []) {
    if (!pattern) return;
    if (pattern.type === 'Identifier') {
      // Duplicate declarations, parameters and mutable declarations block alias inference.
      scope.bindings.set(pattern.name, scope.bindings.has(pattern.name) ? null : record && {...record,path});
    } else if (pattern.type === 'ObjectPattern') {
      for (const item of pattern.properties) {
        if (item.type !== 'Property') { bindPattern(item.argument,scope); continue; }
        const key = item.computed ? item.key.type === 'Literal' ? item.key.value : null : item.key.name ?? item.key.value;
        bindPattern(item.value,scope,key === null ? null : record,[...path,key]);
      }
    } else if (pattern.type === 'ArrayPattern') {
      for (const item of pattern.elements) bindPattern(item,scope);
    } else if (pattern.type === 'AssignmentPattern') bindPattern(pattern.left,scope);
    else if (pattern.type === 'RestElement') bindPattern(pattern.argument,scope);
  }
  function collect(node, scope, owner = null) {
    if (['FunctionDeclaration','ClassDeclaration'].includes(node.type) && node.id) bindPattern(node.id,scope);
    if (['ClassDeclaration','ClassExpression'].includes(node.type)) {
      scope=makeScope(scope);if(node.id)bindPattern(node.id,scope);
    }
    if (functions.has(node.type)) {
      scope = makeScope(scope,true); owner = {name:node.id?.name ?? null,start:node.start,end:node.end};
      if (node.id) bindPattern(node.id,scope);
      for (const param of node.params) bindPattern(param,scope);
    } else if (['BlockStatement','CatchClause','ForStatement','ForInStatement','ForOfStatement','SwitchStatement','ClassBody'].includes(node.type)) scope = makeScope(scope);
    scopes.set(node,scope); owners.set(node,owner); all.push(node);
    if (node.type === 'CatchClause') bindPattern(node.param,scope);
    if (node.type === 'ImportDeclaration') for(const specifier of node.specifiers)bindPattern(specifier.local,scope);
    if (node.type === 'VariableDeclaration') for (const declaration of node.declarations) {
      let bindingScope=scope;
      if(node.kind==='var')while(!bindingScope.isFunction)bindingScope=bindingScope.parent;
      bindPattern(declaration.id,bindingScope,node.kind === 'const' && declaration.init
        ? {init:declaration.init,end:declaration.end,scope} : null);
    }
    for (const child of children(node)) collect(child,scope,owner);
  }
  collect(ast,root);
  function lookup(scope,name) {
    while (scope) { if (scope.bindings.has(name)) return scope.bindings.get(name); scope=scope.parent; }
    return null;
  }
  // Invalid const writes in parseable input and assignments in nested closures are also excluded.
  for (const node of all) {
    const target = node.type === 'AssignmentExpression' ? node.left : node.type === 'UpdateExpression' ? node.argument : null;
    if (!target) continue;
    function invalidate(pattern) {
      if (pattern.type === 'Identifier') { const record=lookup(scopes.get(node),pattern.name); if(record)record.written=true; }
      else if (['ObjectPattern','ArrayPattern','AssignmentPattern','RestElement','Property'].includes(pattern.type)) for(const child of children(pattern)) invalidate(child);
    }
    invalidate(target);
  }
  function resolve(node, scope, at, seen = new Set()) {
    if (!node) return null;
    if (node.type === 'Identifier') {
      const binding=lookup(scope,node.name);
      if (!binding || binding.written || binding.end > at || seen.has(binding)) return null;
      const chain=new Set(seen);chain.add(binding);
      let origin=resolve(binding.init,binding.scope,binding.init.start,chain),path=binding.path;
      if(!origin && path[0]==='request') {
        origin={level:'request',receiver:source.slice(binding.init.start,binding.init.end),aliases:[]};path=path.slice(1);
      }
      if(!origin)return null;
      let value={...origin,aliases:[...origin.aliases,{name:node.name,start:binding.init.start,end:binding.end}]};
      for(const key of path)value=advance(value,key);
      return value;
    }
    if (node.type !== 'MemberExpression') return null;
    const key=property(node);
    if (key === null) return null;
    const parent=resolve(node.object,scope,at,seen);
    if(parent)return advance(parent,key);
    // Same syntactic request root as the direct scanner; no inference from plain event.subtype.
    if(key === 'request')return {level:'request',receiver:source.slice(node.object.start,node.object.end),aliases:[]};
    return null;
  }
  function advance(value,key) {
    if(!value)return null;
    return value.level === 'request' && key === 'subtype' ? {...value,level:'subtype'} : null;
  }
  const sites=[];
  function add(subject,label,node,kind,operator) {
    if(label?.type !== 'Literal' || typeof label.value !== 'string')return;
    const value=resolve(subject,scopes.get(subject),subject.start);
    if(value?.level !== 'subtype' || value.aliases.length === 0)return;
    sites.push({subtype:label.value,kind,...operator?{operator}:{},receiver:value.receiver,
      start:node.start,end:node.end,owner:owners.get(node),aliases:value.aliases,
      declaredInRequestUnion:known.has(label.value),qualification:'lexical-const-alias candidate; no identity, mutation, call/dataflow or runtime-admission proof'});
  }
  for(const node of all) {
    if(node.type==='BinaryExpression' && ['===','==','!==','!='].includes(node.operator)) {
      add(node.left,node.right,node,'comparison',node.operator);add(node.right,node.left,node,'comparison',node.operator);
    }
    if(node.type==='SwitchStatement')for(const arm of node.cases)add(node.discriminant,arm.test,arm,'switch-case');
  }
  return sites;
}
