import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {parse} from 'acorn';
const hash=source=>createHash('sha256').update(source).digest('hex');
function walk(node,visit){if(!node?.type)return;visit(node);for(const value of Object.values(node)){if(Array.isArray(value)){for(const child of value)walk(child,visit);}else if(value?.type)walk(value,visit);}}
function includesText(node,text){let found=false;walk(node,child=>{if(child.type==='Literal'&&typeof child.value==='string'&&child.value.includes(text)||child.type==='TemplateElement'&&child.value.raw.includes(text))found=true;});return found;}
/** Identify the original browser approval renderer without importing or running recovered source. */
export function inspectNativeBrowserPermission(source,encoding='utf8'){
 assert.equal(typeof source,'string');assert.ok(['utf8','latin1'].includes(encoding),'Unsupported browser source encoding');assert.ok(Buffer.byteLength(source,encoding)<=8*1024**2,'Browser source exceeds bound');
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),candidates=ast.body.filter(node=>node.type==='FunctionDeclaration'&&includesText(node,'Claude in Chrome wants to')&&['allow','allow-domain','deny'].every(text=>includesText(node,text)));
 assert.equal(candidates.length,1,'Expected one original browser permission renderer');const fn=candidates[0];
 const memo=fn.body.body[0];assert.equal(memo.type,'VariableDeclaration');const binding=memo.declarations[0];assert.equal(binding.id.type,'Identifier');assert.equal(binding.init?.type,'CallExpression');assert.deepEqual(binding.init.arguments.map(arg=>arg.value),[44],'Browser memo layout changed');
 const cache=binding.id.name,controls=[],panels=[];
 walk(fn,node=>{if(node.type!=='VariableDeclarator'||node.id.type!=='Identifier'||node.init?.type!=='CallExpression')return;const props=node.init.arguments.find(arg=>arg.type==='ObjectExpression');if(!props)return;const names=new Set(props.properties.map(prop=>prop.key?.name??prop.key?.value));if(['options','onChange','onCancel','selectedValue'].every(key=>names.has(key)))controls.push({variable:node.id.name,selector:node.init.arguments[0]?.name});if(['title','requestSource','children'].every(key=>names.has(key)))panels.push({variable:node.id.name});});
 // Compiled React also assigns elements inside branches rather than variable initializers.
 walk(fn,node=>{if(node.type!=='AssignmentExpression'||node.left.type!=='Identifier'||node.right?.type!=='CallExpression')return;const props=node.right.arguments.find(arg=>arg.type==='ObjectExpression');if(!props)return;const names=new Set(props.properties.map(prop=>prop.key?.name??prop.key?.value));if(['options','onChange','onCancel','selectedValue'].every(key=>names.has(key)))controls.push({variable:node.left.name,selector:node.right.arguments[0]?.name});if(['title','requestSource','children'].every(key=>names.has(key)))panels.push({variable:node.left.name});});
 assert.equal(controls.length,1,'Browser selector is ambiguous');assert.equal(panels.length,1,'Browser panel is ambiguous');assert.equal(typeof controls[0].selector,'string');
 const slot=variable=>{const slots=new Set();walk(fn,node=>{if(node.type==='AssignmentExpression'&&node.left.type==='Identifier'&&node.left.name===variable&&node.right.type==='MemberExpression'&&node.right.object.name===cache&&Number.isInteger(node.right.property.value))slots.add(node.right.property.value);});assert.equal(slots.size,1,'Browser memo slot is ambiguous');return [...slots][0];};
 assert.equal(slot(controls[0].variable),31,'Browser selector slot changed');assert.equal(slot(panels[0].variable),43,'Browser panel slot changed');
 return{encoding,fileSha256:hash(Buffer.from(source,encoding)),renderer:{name:fn.id.name,start:fn.start,end:fn.end,sha256:hash(source.slice(fn.start,fn.end))},memo:{length:44,selectorSlot:31,panelSlot:43},selector:controls[0].selector,qualification:'Static renderer identity/layout only. Native account/browser/rollout and live dialog admission, original callbacks/effects and actual app acceptance require separate evidence; no recovered source executed.'};
}
