import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
function canonical(value){
 if(Array.isArray(value))return value.map(canonical);
 if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])]));
 return value;
}
function group(catalog){
 const named=new Map(),unresolved=[];
 for(const module of catalog.modules){
  if(!Array.isArray(module.commands)||!Array.isArray(module.promptCandidates))throw Error('Expanded command catalog required; rescan both inputs');
  for(const [family,rows]of [['typed',module.commands],['prompt-candidate',module.promptCandidates]])for(const row of rows){
   const name=row.resolvedName,fields={},uncomparedExpressions=[];
   if(!row.fields||!Number.isInteger(row.start))throw Error('Invalid command candidate');
   for(const [key,field]of Object.entries(row.fields)){
    if(key==='name')continue;
    if(!['literal','literal-array','literal-object','expression'].includes(field.kind))throw Error('Invalid command field');
    fields[key]={kind:field.kind,getter:!!field.getter};
    if(field.kind==='expression')uncomparedExpressions.push(key);else fields[key].value=field.value;
   }
   // Names have a separate identity, and no source offsets enter the comparison signature.
   delete fields.name;
   const metadata={type:row.type??null,fields,spreadCount:row.spreadCount??0,uncomparedExpressions:uncomparedExpressions.sort()};
   const location={module:module.path,start:row.start,end:row.end};
   if(typeof name!=='string'||!name){unresolved.push({family,...location,metadata});continue;}
   const key=JSON.stringify([family,name]),items=named.get(key)??[];
   items.push({signature:JSON.stringify(canonical(metadata)),metadata,location});named.set(key,items);
  }
 }
 for(const items of named.values())items.sort((a,b)=>a.signature.localeCompare(b.signature));
 return {named,unresolved};
}
/** Declaration metadata only: callback bodies, registration identity and effective gates are not compared. */
export function compareCommandCatalogs(before,after){
 const a=group(before),b=group(after),added=[],removed=[],changed=[],sameDeclaredMetadata=[];
 for(const key of [...new Set([...a.named.keys(),...b.named.keys()])].sort()){
  const [family,name]=JSON.parse(key),old=a.named.get(key),next=b.named.get(key),item={family,name};
  const entries=items=>items.map(({metadata,location})=>({metadata,location}));
  if(!old)added.push({...item,after:entries(next)});
  else if(!next)removed.push({...item,before:entries(old)});
  else if(JSON.stringify(old.map(x=>x.signature))!==JSON.stringify(next.map(x=>x.signature)))changed.push({...item,before:entries(old),after:entries(next)});
  else sameDeclaredMetadata.push({...item,occurrences:old.length,uncomparedExpressions:[...new Set(old.flatMap(x=>x.metadata.uncomparedExpressions))]});
 }
 return {added,removed,changed,sameDeclaredMetadata,unresolved:{before:a.unresolved,after:b.unresolved},qualification:'Name/family identities with selected declaration metadata occurrence multisets. Module/binding/range churn ignored; duplicate counts and literal array order retained. Expression bodies, registration, policy effects, prompt text and runtime availability are not compared. Equal metadata is not behavioral equivalence. Unresolved names are never matched by position or counted unchanged.'};
}
export async function compareCommandRuns(before,after,output){
 const paths=[before,after],parents=await Promise.all(paths.map(path=>readCompleteRun(path,'slash-commands'))),catalogs=[];
 for(let i=0;i<paths.length;i++){const bytes=await readFile(join(paths[i],'slash-commands.json'));if(hash(bytes)!==parents[i].outputSha256)throw Error('Command catalog changed');catalogs.push(JSON.parse(bytes));}
 const run=await createRun(output,'compare-commands',{before,after,parentRunIds:parents.map(p=>p.id),targetSha256:parents.map(p=>p.inputs.targetSha256),parentOutputSha256:parents.map(p=>p.outputSha256),scannerSha256:hash(await readFile(new URL(import.meta.url))),runHelperSha256:hash(await readFile(new URL('../artifacts/runs.mjs',import.meta.url)))});
 try{const result=compareCommandCatalogs(...catalogs),raw=JSON.stringify(result,null,2)+'\n';await writeFile(join(run.directory,'comparison.json'),raw);const counts={added:result.added.length,removed:result.removed.length,changed:result.changed.length,sameDeclaredMetadata:result.sameDeclaredMetadata.length,unresolvedBefore:result.unresolved.before.length,unresolvedAfter:result.unresolved.after.length};await run.finish({status:'complete',outputSha256:hash(raw),...counts});return{directory:run.directory,status:'complete',...counts};}catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
