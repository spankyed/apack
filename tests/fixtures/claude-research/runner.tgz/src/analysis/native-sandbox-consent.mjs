import {parse} from 'acorn';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';

/** Read-only provenance for the original sandbox consent view and its payload-bound wrapper. */
export async function inspectNativeSandboxConsent(file){
 const bytes=await readFile(file);if(bytes.length>16*1024*1024)throw Error('Sandbox source exceeds audit bound');
 const source=bytes.toString('utf8'),ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),views=[],wrappers=[];
 const walk=node=>{
  if(!node||typeof node!=='object')return;
  if(node.type==='FunctionDeclaration'&&source.slice(node.start,node.end).includes('Network request outside of sandbox'))views.push({name:node.id.name,node});
  if(node.type==='VariableDeclarator'&&node.init?.type==='ArrowFunctionExpression'){
   const props=node.init.body?.arguments?.[1]?.properties;
   if(props?.some(property=>property.key?.name==='hostPattern')&&props.some(property=>property.key?.name==='onUserResponse'))wrappers.push({name:node.id.name,node:node.init});
  }
  for(const [key,value]of Object.entries(node))if(key!=='start'&&key!=='end'){
   if(Array.isArray(value))for(const item of value)walk(item);
   else if(value&&typeof value==='object')walk(value);
  }
 };
 walk(ast);
 if(views.length!==1||wrappers.length!==1)throw Error('Original sandbox view/wrapper is ambiguous or absent');
 const hash=value=>createHash('sha256').update(value).digest('hex');
 const site=({name,node})=>({name,utf16Start:node.start,utf16End:node.end,byteStart:Buffer.byteLength(source.slice(0,node.start)),byteEnd:Buffer.byteLength(source.slice(0,node.end)),functionSha256:hash(source.slice(node.start,node.end))});
 return {file,sourceSha256:hash(bytes),view:site(views[0]),wrapper:site(wrappers[0]),qualification:'Static source sites only; no recovered code executes and no native eligibility/app acceptance is inferred.'};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 if(process.argv.length<3)throw Error('Usage: native-sandbox-consent.mjs <extracted-module> [...]');
 const rows=[];for(const file of process.argv.slice(2))rows.push(await inspectNativeSandboxConsent(file));
 console.log(JSON.stringify(rows,null,2));
}
