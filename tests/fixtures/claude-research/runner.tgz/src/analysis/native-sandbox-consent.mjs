import {parse} from 'acorn';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';

const hash=value=>createHash('sha256').update(value).digest('hex');
async function readSandboxModule(file){
 const bytes=await readFile(file);if(bytes.length>16*1024*1024)throw Error('Sandbox source exceeds audit bound');
 const source=bytes.toString('utf8');
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'});
 const site=({name,node})=>({name,utf16Start:node.start,utf16End:node.end,byteStart:Buffer.byteLength(source.slice(0,node.start)),byteEnd:Buffer.byteLength(source.slice(0,node.end)),functionSha256:hash(source.slice(node.start,node.end))});
 return {source,ast,site,sourceSha256:hash(bytes)};
}

/** Read-only provenance for the original sandbox consent view and its payload-bound wrapper. */
export async function inspectNativeSandboxConsent(file){
 const {source,ast,site,sourceSha256}=await readSandboxModule(file),views=[],wrappers=[];
 const walk=node=>{
  if(!node||typeof node!=='object')return;
  if(node.type==='FunctionDeclaration'&&source.slice(node.start,node.end).includes('Network request outside of sandbox'))views.push({name:node.id.name,node});
  if(node.type==='VariableDeclarator'&&node.init?.type==='ArrowFunctionExpression'){
   const props=node.init.body?.arguments?.[1]?.properties;
   if(props?.some(property=>property.key?.name==='hostPattern')&&props.some(property=>property.key?.name==='onUserResponse'))wrappers.push({name:node.id.name,node:node.init});
  }
  for(const [key,value]of Object.entries(node))if(key!=='start'&&key!=='end'){
   if(Array.isArray(value))for(const item of value)walk(item);
   else if(value&&typeof value==='object')walk(value);
  }
 };
 walk(ast);
 if(views.length!==1||wrappers.length!==1)throw Error('Original sandbox view/wrapper is ambiguous or absent');
 return {file,sourceSha256,view:site(views[0]),wrapper:site(wrappers[0]),qualification:'Static source sites only; no recovered code executes and no native eligibility/app acceptance is inferred.'};
}

const networkAdmissionSections=[
 ['linuxDependencies', [
  '"bubblewrap (bwrap) not installed"', '"socat not installed"',
 ]],
 ['proxyPolicy', [
  '"No config available, denying network request"', 'Denying malformed host:',
  'Denied by config rule:', 'Allowed by config rule:', '.network.strictAllowlist',
  'Allowed by per-command rule:', 'if(!r)return', 'No matching config rule, asking user:',
  'await r({host:n,port:e})', 'User allowed:', 'User denied:',
 ]],
 ['managedPolicy', [
  'Blocked network request to ', '(allowManagedDomainsOnly)', 'return r(y)',
 ]],
];

/** Trace the hosts that can reach the native prompt from the pinned runtime. */
export async function inspectNativeSandboxNetworkAdmission(file){
 const {source,ast,site,sourceSha256}=await readSandboxModule(file);
 const declarations=ast.body.filter(node=>node.type==='FunctionDeclaration');
 const sections={};
 for(const [section,anchors] of networkAdmissionSections){
  const matches=declarations.filter(node=>source.slice(node.start,node.end).includes(anchors[0]));
  if(matches.length!==1)throw Error('Original sandbox '+section+' function is ambiguous or absent');
  const [node]=matches;
  const body=source.slice(node.start,node.end);
  let previous=-1;
  const evidence={};
  for(const anchor of anchors){
   const position=body.indexOf(anchor,previous+1);
   if(position<0)throw Error('Original sandbox '+section+' anchor changed: '+anchor);
   previous=position;
   evidence[anchor]=Buffer.byteLength(source.slice(0,node.start+position));
  }
  sections[section]={...site({name:node.id.name,node}),anchors:evidence};
 }
 return {file,sourceSha256,sections,qualification:'Static dependency and policy branch order only. No sandbox execution or desktop acceptance.'};
}

if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const [first,...remaining]=process.argv.slice(2);
 const networkAdmission=first==='--network-admission';
 const files=networkAdmission?remaining:process.argv.slice(2);
 if(!files.length)throw Error('Usage: native-sandbox-consent.mjs [--network-admission] <extracted-module> [...]');
 const inspect=networkAdmission?inspectNativeSandboxNetworkAdmission:inspectNativeSandboxConsent;
 const rows=[];for(const file of files)rows.push(await inspect(file));
 console.log(JSON.stringify(rows,null,2));
}
