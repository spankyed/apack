import {execFile} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {parse} from 'acorn';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
import {analysisProvenance} from './provenance.mjs';

export function inspectInlineScript(source,attrs={},closed=true) {
  const type=(attrs.type??'').trim().toLowerCase();
  if(Object.hasOwn(attrs,'src'))return {status:'external-reference',source:attrs.src};
  if(type&&!['module','text/javascript','application/javascript'].includes(type))return {status:'data-or-other-language',type};
  if(!closed)return {status:'unclosed-script'};
  try {
    parse(source,{ecmaVersion:'latest',sourceType:type==='module'?'module':'script'});
    return {status:'parsed',sourceType:type==='module'?'module':'script',qualification:'Syntax only; browser globals, runtime messages, generated substitutions and eligibility not evaluated.'};
  }catch(error){if(!(error instanceof SyntaxError))throw error;return {status:'syntax-unresolved',offset:error.pos};}
}

export async function catalogHtmlAssets(assetRun,output) {
  const parent=await readCompleteRun(assetRun,'code-assets');
  const bytes=await readFile(join(assetRun,'code-assets.json'));
  if(hash(bytes)!==parent.outputSha256)throw new Error('Asset catalog changed');
  const selected=JSON.parse(bytes).assets.filter(a=>a.format==='html');
  const sources=new Map(),inputs=[];
  for(const asset of selected){const file=join(assetRun,asset.decodedPath),raw=await readFile(file);if(hash(raw)!==asset.decodedSha256)throw new Error('Decoded HTML changed');sources.set(asset.path,{asset,raw,source:raw.toString(asset.sourceEncoding)});inputs.push({path:asset.path,file,encoding:asset.sourceEncoding});}
  const helper=new URL('./html-script-ranges.py',import.meta.url);
  const run=await createRun(output,'html-assets',{assetRun,parentRunId:parent.id,targetSha256:parent.inputs.targetSha256,...await analysisProvenance(new URL(import.meta.url)),htmlHelperSha256:hash(await readFile(helper))});
  try {
    const parsed=await new Promise((resolve,reject)=>{const child=execFile('python3',['-I',fileURLToPath(helper)],{timeout:10000,maxBuffer:1024*1024},(error,stdout)=>{if(error)return reject(error);try{resolve(JSON.parse(stdout))}catch(error){reject(error)}});child.stdin.on('error',reject);child.stdin.end(JSON.stringify(inputs));});
    const assets=parsed.assets.map(item=>{
      const {asset,raw,source}=sources.get(item.path);if(hash(raw)!==item.sha256)throw new Error('HTML parser input changed');
      // Python reports Unicode code points; convert them to JS UTF-16 indexes before slicing.
      const codepoints=Array.from(source),prefix=n=>codepoints.slice(0,n).join('');
      const scripts=item.scripts.map(script=>{const body=codepoints.slice(script.bodyStart,script.bodyEnd).join('');return {attrs:script.attrs,byteStart:Buffer.byteLength(prefix(script.bodyStart),asset.sourceEncoding),byteEnd:Buffer.byteLength(prefix(script.bodyEnd),asset.sourceEncoding),closed:script.closed,...inspectInlineScript(body,script.attrs,script.closed)};});
      return {path:item.path,decodedSha256:item.sha256,scripts,handlers:item.handlers,qualification:'Python stdlib HTMLParser spans, not a browser DOM or complete HTML/JavaScript execution model. Handler tag positions are Unicode code-point offsets; handler bodies not parsed.'};
    });
    const result={assets,parser:{python:parsed.python,sha256:parsed.parserSha256},qualification:'Static HTML script classification. External references are not fetched; data scripts, unclosed scripts and syntax failures remain explicit. No browser or recovered code executes.'};
    const resultBytes=Buffer.from(JSON.stringify(result,null,2)+'\n');await writeFile(join(run.directory,'html-assets.json'),resultBytes);
    const scripts=assets.flatMap(a=>a.scripts),summary={assets:assets.length,scripts:scripts.length,parsed:scripts.filter(s=>s.status==='parsed').length,nonJs:scripts.filter(s=>s.status==='data-or-other-language').length,external:scripts.filter(s=>s.status==='external-reference').length,unresolved:scripts.filter(s=>['syntax-unresolved','unclosed-script'].includes(s.status)).length,handlerAttributes:assets.reduce((sum,a)=>sum+a.handlers.length,0)};
    await run.finish({status:'complete',outputSha256:hash(resultBytes),parser:result.parser,...summary});return {directory:run.directory,status:'complete',...summary};
  }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
