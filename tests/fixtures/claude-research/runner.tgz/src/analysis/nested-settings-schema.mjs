import { parse } from 'acorn';
const nameOf = property => property.type === 'Property' && !property.computed ? property.key.name ?? property.key.value : null;
const kinds = new Set(['string','number','boolean','object','array','enum','literal','union','record','lazy','unknown','any','null','undefined','pipe']);
function bindings(ast) {
  const result=new Map();
  for(const statement of ast.body){
    const node=statement.type==='ExportNamedDeclaration'?statement.declaration:statement;
    if(node?.type==='FunctionDeclaration')result.set(node.id.name,node);
    if(node?.type==='VariableDeclaration')for(const declaration of node.declarations)if(declaration.id.type==='Identifier')result.set(declaration.id.name,declaration.init);
  }
  return result;
}
function returned(node){
  if(node?.async||node?.generator)return;
  if(node?.type==='ArrowFunctionExpression'&&node.body.type!=='BlockStatement')return node.body;
  if(['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node?.type)){
    if(node.body.body.some(statement=>['IfStatement','SwitchStatement','TryStatement','ForStatement','ForOfStatement','ForInStatement','WhileStatement','DoWhileStatement','BlockStatement','LabeledStatement'].includes(statement.type)))return;
    const returns=node.body.body.filter(statement=>statement.type==='ReturnStatement');
    if(returns.length===1)return returns[0].argument;
  }
}
// Recognize only the record(value) / record(key, value) overload's exact missing-second-argument guard.
function recordOverload(node) {
  if (!['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node?.type) || node.async || node.generator || node.body.type!=='BlockStatement') return;
  const [branch,fallback,...rest]=node.body.body;
  if(rest.length || branch?.type!=='IfStatement' || branch.alternate || branch.consequent.type!=='ReturnStatement' || fallback?.type!=='ReturnStatement')return;
  const [first,second]=node.params;if(first?.type!=='Identifier'||second?.type!=='Identifier')return;
  const test=branch.test;
  const negatedParameter=value=>value?.type==='UnaryExpression'&&value.operator==='!'&&value.argument.type==='Identifier'&&value.argument.name===second.name;
  const right=test?.right;
  if(test?.type!=='LogicalExpression'||test.operator!=='||'||!negatedParameter(test.left)||right?.type!=='UnaryExpression'||right.operator!=='!'||right.argument.type!=='MemberExpression'||right.argument.computed||right.argument.object.type!=='Identifier'||right.argument.object.name!==second.name||right.argument.property.name!=='_zod')return;
  const expressions=[branch.consequent.argument,fallback.argument];
  if(!expressions.every(value=>value?.type==='NewExpression'&&value.callee.type==='Identifier'&&value.arguments[0]?.type==='ObjectExpression'))return;
  if(expressions[0].callee.name!==expressions[1].callee.name)return;
  for(let index=0;index<expressions.length;index++){
    const fields=expressions[index].arguments[0].properties;
    const type=fields.find(property=>nameOf(property)==='type')?.value,value=fields.find(property=>nameOf(property)==='valueType')?.value;
    if(type?.type!=='Literal'||type.value!=='record'||value?.type!=='Identifier'||value.name!==(index===0?first.name:second.name))return;
  }
  return {kind:'record',start:node.start,end:node.end,recordValueArgumentByArity:{1:0},conditionalOverload:true};
}

/** Infer only a constructor's explicit returned type tag, following direct local helpers, never executing it. */
export function inferSchemaConstructorExports(source, { locals = false } = {}){
  const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),top=bindings(ast);
  function infer(node,seen=new Set()){
    if(!node||seen.has(node))return;
    const next=new Set(seen);next.add(node);
    const value=returned(node);
    if(!value)return recordOverload(node);
    if(value.type==='CallExpression'&&value.callee.type==='Identifier'){
      const result=infer(top.get(value.callee.name),next);
      if(result?.recordValueArgumentByArity)return;
      if(result?.schemaArgument!==undefined){
        const argument=value.arguments[result.schemaArgument];
        const index=node.params.findIndex(parameter=>parameter.type==='Identifier'&&parameter.name===argument?.name);
        const {schemaArgument,...rest}=result;
        return index>=0?{...rest,schemaArgument:index}:rest;
      }
      return result;
    }
    if(value.type!=='NewExpression')return;
    let argument=value.arguments[0];
    if(argument?.type==='Identifier'){
      const declaration=(node.body.type==='BlockStatement'?node.body.body:[]).flatMap(statement=>statement.type==='VariableDeclaration'?statement.declarations:[]).find(item=>item.id.name===argument.name);
      argument=declaration?.init;
    }
    if(argument?.type!=='ObjectExpression')return;
    const type=argument.properties.find(property=>nameOf(property)==='type')?.value;
    if(type?.type!=='Literal'||!kinds.has(type.value))return;
    const output=argument.properties.find(property=>nameOf(property)==='out')?.value;
    const index=output?.type==='Identifier'?node.params.findIndex(parameter=>parameter.name===output.name):-1;
    return {kind:type.value,start:node.start,end:node.end,...(type.value==='pipe'&&index>=0?{schemaArgument:index}:{})};
  }
  const exports={};
  if(locals){for(const [name,node] of top){const description=infer(node);if(description)exports[name]=description}return exports}
  for(const node of ast.body)if(node.type==='ExportNamedDeclaration')for(const specifier of node.specifiers??[]){
    const description=infer(top.get(specifier.local.name));if(description)exports[specifier.exported.name]=description;
  }
  return exports;
}

/** Expand static field declarations. Unknown imports, gates, spreads and recursion remain visible. */
export function describeNestedSettings(ast,root,constructors={}){
  const top=bindings(ast),imports=new Map();
  for(const node of ast.body)if(node.type==='ImportDeclaration')for(const specifier of node.specifiers)imports.set(specifier.local.name,{module:node.source.value,export:specifier.imported?.name});
  const fields=[],unresolved=[];
  const span=node=>({start:node.start,end:node.end});
  const literal=node=>node?.type==='Literal'?{value:node.value}:node?.type==='UnaryExpression'&&node.operator==='!'&&node.argument.type==='Literal'?{value:!node.argument.value}:{expression:node?.type??'missing',...(node?span(node):{})};
  const schemaMethods=new Set(['optional','nullable','nullish','catch','default','describe','refine','superRefine','min','max','int','regex','transform','pipe','and','or','strict','passthrough','strip','readonly']);
  function schemaConstructorExpression(node,scope){
    if(node?.type!=='CallExpression')return false;
    if(node.callee.type==='Identifier'){if(scope.has(node.callee.name))return false;const value=Object.hasOwn(constructors,node.callee.name)?constructors[node.callee.name]:undefined;return kinds.has(value?.kind??value);}
    if(node.callee.type==='MemberExpression'&&!node.callee.computed&&schemaMethods.has(node.callee.property.name))return schemaConstructorExpression(node.callee.object,scope);
    return false;
  }
  function visit(node,path,wrappers=[],trail=[],depth=0,scope=new Map()){
    const unknown=(reason,extra={})=>unresolved.push({path,reason,...(node?span(node):{}),...extra});
    if(depth>64){unknown('depth-limit');return}
    if(!node){unknown('missing-expression');return}
    if(['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node.type)){
      const local=new Map(scope);
      const bind=pattern=>{
        if(!pattern)return;
        if(pattern.type==='Identifier')local.set(pattern.name,null);
        else if(pattern.type==='AssignmentPattern')bind(pattern.left);
        else if(pattern.type==='RestElement')bind(pattern.argument);
        else if(pattern.type==='ArrayPattern')pattern.elements.forEach(bind);
        else if(pattern.type==='ObjectPattern')pattern.properties.forEach(property=>bind(property.type==='RestElement'?property.argument:property.value));
      };
      node.params.forEach(bind);
      for(const statement of node.body.type==='BlockStatement'?node.body.body:[]){
        if(statement.type==='VariableDeclaration')statement.declarations.forEach(value=>bind(value.id));
        else if(['FunctionDeclaration','ClassDeclaration'].includes(statement.type))bind(statement.id);
      }
      const written=new Set();
      const rootName=value=>value?.type==='Identifier'?value.name:value?.type==='MemberExpression'?rootName(value.object):undefined;
      const writes=value=>{
        if(!value?.type)return;
        if(value.type==='AssignmentExpression'||value.type==='UpdateExpression'){
          const target=value.type==='AssignmentExpression'?value.left:value.argument;
          const name=rootName(target);if(name)written.add(name);
          else if(target?.type==='ArrayPattern'||target?.type==='ObjectPattern'){
            const collect=pattern=>{if(!pattern)return;if(pattern.type==='Identifier')written.add(pattern.name);else for(const child of Object.values(pattern))if(Array.isArray(child))child.forEach(collect);else if(child?.type)collect(child)};
            collect(target);
          }
        }
        for(const child of Object.values(value))if(Array.isArray(child))child.forEach(writes);else if(child?.type)writes(child);
      };
      writes(node.body);
      for(const statement of node.body.type==='BlockStatement'?node.body.body:[])if(statement.type==='VariableDeclaration'){
        for(const declaration of statement.declarations)if(declaration.id.type==='Identifier'&&!written.has(declaration.id.name)&&declaration.init)local.set(declaration.id.name,declaration.init);
      }
      const value=returned(node);
      if(value){visit(value,path,wrappers,trail,depth+1,local);return;}
    }
    if(node.type==='CallExpression'&&node.callee.type==='MemberExpression'&&!node.callee.computed){
      const method=node.callee.property.name;
      const modifier={method,...span(node),...(method==='describe'?{}:{arguments:node.arguments.map(literal)})};
      if(['extend','merge','pick','omit','partial','required'].includes(method))unknown('shape-operation',{method});
      visit(node.callee.object,path,[...wrappers,modifier],trail,depth+1,scope);return;
    }
    if(node.type==='Identifier'||(node.type==='CallExpression'&&node.callee.type==='Identifier')){
      const symbol=node.type==='Identifier'?node.name:node.callee.name;
      if(scope.has(symbol)){
        const declaration=scope.get(symbol);
        if(node.type==='Identifier'&&declaration&&schemaConstructorExpression(declaration,scope)){
          visit(declaration,path,wrappers,[...trail,{localSchemaAlias:symbol,...span(declaration)}],depth+1,scope);
        }else unknown('lexical-binding',{symbol});
        return;
      }
      const constructor=Object.hasOwn(constructors,symbol)?constructors[symbol]:undefined;
      const kind=constructor?.kind??constructor;
      if(kind&&node.type==='CallExpression'){
        const row={path,kind,...span(node),factory:symbol,wrappers,trace:trail};
        if(kind==='enum'||kind==='literal')row.values=node.arguments[0]?.type==='ArrayExpression'?node.arguments[0].elements.map(literal):[literal(node.arguments[0])];
        fields.push(row);
        if(row.values?.some(value=>'expression' in value))unknown('dynamic-enum-values',{symbol});
        if(kind==='object'){
          const object=node.arguments[0];
          if(object?.type!=='ObjectExpression'){unknown('nonliteral-object-shape',{symbol});return}
          objectFields(object,path,trail,depth+1,scope);
        }else if(kind==='array')visit(node.arguments[0],`${path}[]`,[],trail,depth+1,scope);
        else if(kind==='record'){
          const overload=constructor?.recordValueArgumentByArity;
          const index=overload?(overload[node.arguments.length]??(node.arguments.length>=2&&schemaConstructorExpression(node.arguments[1],scope)?1:undefined)):1;
          if(index===undefined)unknown('ambiguous-record-overload',{symbol,arity:node.arguments.length});
          else visit(node.arguments[index],`${path}.*`,[],[...trail,...(overload?[{recordOverloadArity:node.arguments.length}]:[])],depth+1,scope);
        }
        else if(kind==='union'){
          const alternatives=node.arguments[0];
          if(alternatives?.type==='ArrayExpression')alternatives.elements.forEach((value,index)=>visit(value,path,wrappers,[...trail,{variant:index}],depth+1,scope));
          else unknown('dynamic-union',{symbol});
        }else if(kind==='pipe'){
          const index=constructors[symbol]?.schemaArgument;
          if(index===undefined)unknown('unknown-pipeline-output',{symbol});
          else visit(node.arguments[index],path,wrappers,[...trail,{pipeline:symbol}],depth+1,scope);
        }else if(kind==='lazy')visit(node.arguments[0],path,wrappers,[...trail,{deferred:symbol}],depth+1,scope);
        return;
      }
      if(trail.some(entry=>entry.symbol===symbol)){unknown('reference-cycle',{symbol});return}
      const declaration=top.get(symbol);
      if(declaration){
        const next=[...trail,{symbol,...span(declaration)}];
        // Cache/factory wrappers expose a declaration candidate, not proof of invocation or availability.
        if(declaration.type==='CallExpression'&&declaration.arguments.length===1&&returned(declaration.arguments[0])){
          visit(declaration.arguments[0],path,wrappers,[...next,{factoryWrapper:declaration.callee.name??declaration.callee.type}],depth+1);
        }else if(returned(declaration))visit(declaration,path,wrappers,next,depth+1);
        else unknown('nonfactory-binding',{symbol});
      }else unknown(imports.has(symbol)?'imported-factory':'unknown-factory',{symbol,...imports.get(symbol)});
      return;
    }
    unknown('unsupported-expression',{expression:node.type});
  }
  function objectFields(object,parent,trail,depth,scope=new Map()){
    for(const property of object.properties){
      const key=nameOf(property);
      if(key!==null)visit(property.value,parent?`${parent}.${key}`:String(key),[],trail,depth+1,scope);
      else if(property.type==='SpreadElement'&&property.argument.type==='UnaryExpression'&&property.argument.operator==='!'&&property.argument.argument.value===1)continue;
      else unresolved.push({path:parent,reason:'object-composition',...span(property),expression:property.type});
    }
  }
  objectFields(root,'',[],0);
  return {fields,unresolved,offsetUnits:'decoded JavaScript source code units',qualification:'Declarations and constructor tags only. Factory-wrapper candidates, unknown composition and runtime precedence are not evaluated.'};
}
