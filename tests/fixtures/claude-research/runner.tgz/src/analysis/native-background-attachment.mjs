import ts from 'typescript';
import {open} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const hash = value => createHash('sha256').update(value).digest('hex');

/** Pin declarations and dependency names without evaluating recovered modules or inferring eligibility. */
export function inspectBackgroundAttachmentSource(source, symbol, file = 'source.js') {
  if (Buffer.byteLength(source) > 16 * 1024 * 1024) throw Error('Attachment source exceeds audit bound');
  if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/u.test(symbol)) throw Error('Expected one declaration name');
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  if (ast.parseDiagnostics.length) throw Error('Attachment source has syntax errors');
  const matches = ast.statements.filter(node => (ts.isFunctionDeclaration(node) || ts.isClassDeclaration(node)) && node.name?.text === symbol);
  if (matches.length !== 1) throw Error('Expected one top-level attachment declaration: ' + symbol);
  const entry = matches[0], start = entry.getStart(ast), end = entry.end;
  const calls = new Set(), dynamicImports = new Set(); let nodes = 0;
  function visit(node) {
    if (++nodes > 500000) throw Error('Attachment declaration exceeds syntax bound');
    if (ts.isCallExpression(node)) {
      const expression = node.expression;
      if (ts.isIdentifier(expression)) calls.add(expression.text);
      else if (ts.isPropertyAccessExpression(expression)) {
        const owner = ts.isIdentifier(expression.expression) ? expression.expression.text : '*';
        calls.add(owner + '.' + expression.name.text);
      } else if (expression.kind === ts.SyntaxKind.ImportKeyword && ts.isStringLiteral(node.arguments[0])) dynamicImports.add(node.arguments[0].text);
    }
    ts.forEachChild(node, visit);
  }
  visit(entry);
  const imports = [];
  for (const node of ast.statements) {
    if (!ts.isImportDeclaration(node) || !ts.isStringLiteral(node.moduleSpecifier)) continue;
    const bindings = node.importClause?.namedBindings;
    if (!bindings || !ts.isNamedImports(bindings)) continue;
    for (const item of bindings.elements) if (calls.has(item.name.text)) imports.push({local: item.name.text, exported: item.propertyName?.text ?? item.name.text, module: node.moduleSpecifier.text});
  }
  return {file, sourceSha256: hash(source), symbol, declaration: {utf16Start: start, utf16End: end, byteStart: Buffer.byteLength(source.slice(0, start)), byteEnd: Buffer.byteLength(source.slice(0, end)), sha256: hash(source.slice(start, end))}, calls: [...calls].sort(), matchingImportDeclarations: imports, dynamicImports: [...dynamicImports].sort(), qualification: 'Static declaration/dependency evidence only; call names do not resolve lexical bindings or establish native admission, execution, or app support.'};
}
export async function inspectBackgroundAttachment(file, symbol) {
  const handle = await open(file, 'r');
  try {
    const stat = await handle.stat();
    if (!stat.isFile() || stat.size > 16 * 1024 * 1024) throw Error('Expected a bounded regular attachment source');
    const buffer = Buffer.alloc(stat.size + 1); let length = 0;
    while (length < buffer.length) {
      const {bytesRead} = await handle.read(buffer, length, buffer.length - length, length);
      if (!bytesRead) break;
      length += bytesRead;
    }
    if (length !== stat.size) throw Error('Attachment source changed during read');
    const bytes = buffer.subarray(0, length), source = bytes.toString('utf8');
    if (!Buffer.from(source).equals(bytes)) throw Error('Attachment source is not valid UTF-8');
    return inspectBackgroundAttachmentSource(source, symbol, file);
  } finally { await handle.close(); }
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const [file, symbol, ...extra] = process.argv.slice(2);
  if (!file || !symbol || extra.length) throw Error('Usage: native-background-attachment.mjs <immutable-module> <declaration>');
  console.log(JSON.stringify(await inspectBackgroundAttachment(file, symbol), null, 2));
}
