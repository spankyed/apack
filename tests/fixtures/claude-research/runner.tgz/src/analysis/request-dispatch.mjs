import { parse } from 'acorn';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { inspectRequestAliases } from './request-aliases.mjs';
import { analysisProvenance } from './provenance.mjs';
import { hash, readCompleteRun, createRun } from '../artifacts/runs.mjs';

const member = node => node?.type === 'MemberExpression' ? (node.computed ? node.property.type === 'Literal' ? node.property.value : null : node.property.name) : null;
const literal = node => node?.type === 'Literal' && typeof node.value === 'string' ? node.value : null;
function receiver(node, source) {
  return member(node) === 'subtype' && member(node.object) === 'request' ? source.slice(node.object.object.start,node.object.object.end) : null;
}

/** Syntactic request-payload comparisons, not arbitrary subtype strings or runtime reachability. */
export function inspectRequestDispatch(source, known = new Set()) {
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),sites=[];
 function walk(node,owner=null) {
  if(!node?.type)return;
  if(['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node.type)) owner={name:node.id?.name ?? null,start:node.start,end:node.end};
  if(node.type==='BinaryExpression' && ['===','==','!==','!='].includes(node.operator)) {
   for(const [subject,value] of [[node.left,node.right],[node.right,node.left]]) {
    const path=receiver(subject,source),subtype=literal(value);
    if(path!==null && subtype!==null) sites.push({subtype,kind:'comparison',operator:node.operator,receiver:path,start:node.start,end:node.end,owner,declaredInRequestUnion:known.has(subtype)});
   }
  }
  if(node.type==='SwitchStatement') {
   const path=receiver(node.discriminant,source);
   if(path!==null) for(const arm of node.cases) {const subtype=literal(arm.test);if(subtype!==null)sites.push({subtype,kind:'switch-case',receiver:path,start:arm.start,end:arm.end,owner,declaredInRequestUnion:known.has(subtype)});}
  }
  for(const value of Object.values(node)) {
   if(Array.isArray(value)){for(const child of value)if(child?.type)walk(child,owner);}
   else if(value?.type)walk(value,owner);
  }
 }
 walk(ast);return sites;
}

export async function catalogRequestDispatch(protocolRun,output) {
 const parent=await readCompleteRun(protocolRun,'protocol-schemas');
 const schemaBytes=await readFile(join(protocolRun,'protocol-schemas.json'));
 if(hash(schemaBytes)!==parent.protocolSchemasSha256)throw new Error('Protocol inventory changed');
 const known=new Set(JSON.parse(schemaBytes).requests.map(request=>request.subtype));
 const catalog=await readCompleteRun(parent.inputs.catalogRun,'catalog');
 const extraction=await readCompleteRun(catalog.inputs.extraction,'extract');
 const inventory=await readFile(join(catalog.inputs.extraction,'inventory.json'));
 if(hash(inventory)!==extraction.inventorySha256)throw new Error('Extraction inventory changed');
 const run=await createRun(output,'request-dispatch',{protocolRun,extraction:catalog.inputs.extraction,targetSha256:parent.inputs.targetSha256,...await analysisProvenance(new URL(import.meta.url)),aliasScannerSha256:hash(await readFile(new URL('./request-aliases.mjs',import.meta.url)))});
 try {
  const modules=[];let scannedModules=0;
  for(const file of JSON.parse(inventory)) {
   if(file.loader!=='js')continue;
   if(!['latin1','utf8','utf-8'].includes(file.encoding))throw new Error('Unsupported source encoding');
   const bytes=await readFile(join(catalog.inputs.extraction,'extracted',file.path));
   if(hash(bytes)!==file.sha256)throw new Error(`Source changed: ${file.path}`);
   const source=bytes.toString(file.encoding),sites=inspectRequestDispatch(source,known),aliasSites=inspectRequestAliases(source,known);scannedModules++;
   if(sites.length||aliasSites.length)modules.push({path:file.path,sha256:hash(bytes),encoding:file.encoding,sites,aliasSites});
  }
  const result={scannedModules,modules,qualification:'All verified JavaScript-loader modules parsed. Literal comparisons and switch cases on syntactic <receiver>.request.subtype only; offsets are decoded JavaScript string offsets. Separate aliasSites contain conservative lexical const request/subtype chains and destructuring candidates. Mutable/default bindings, general envelope copy chains, delegated maps and dynamic dispatch are not resolved; property mutation and runtime object identity are not proven. Negated predicates and validation are retained, not claimed as handlers. Owner is the nearest function, not proof of headless entry or reachability. No recovered code executed.'};
  const bytes=Buffer.from(JSON.stringify(result,null,2)+'\n');await writeFile(join(run.directory,'request-dispatch.json'),bytes);
  await run.finish({status:'complete',outputSha256:hash(bytes),scannedModules,modules:modules.length,sites:modules.reduce((sum,module)=>sum+module.sites.length,0),aliasSites:modules.reduce((sum,module)=>sum+module.aliasSites.length,0)});
  return {directory:run.directory,status:'complete',scannedModules,modules:modules.length,sites:modules.reduce((sum,module)=>sum+module.sites.length,0),aliasSites:modules.reduce((sum,module)=>sum+module.aliasSites.length,0)};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
