# Static JavaScript analysis

See the implemented modules in this directory, `docs/architecture.md`,
`docs/update-workflow.md`, and `docs/findings/2026-10-15-progress.md` for boundaries and verified scope.


`app-control-access.mjs` compares a verified protocol-schema run with explicitly reviewed query.ts/
ui-controls.ts transport expressions. It records literal subtype sites, fields, spread uncertainty,
dynamic forwarding and source hashes without importing app code. It is a call-site ledger, not symbol
resolution or runtime/UI coverage. Reconcile incoming handlers and original behavioral evidence
separately before updating the control reference.

`tool-access <definitions-run> <assembly-run>` records named tool candidates not linked by the supplied central assembly scan, their lexical containers, named exports and explicit incoming imports/dynamic imports/Bun require paths. It checks all extracted JS bytes but never executes them. This is navigation evidence; reviewed registration/gate/app dispositions remain separate from raw structural output.

## Analysis provenance

Index/catalog and their comparison stages record the imported Acorn version, parser entry hash,
lockfile hash, scanner hash and provenance-helper hash. Comparisons record explicit parent run IDs
and comparison.json SHA-256. Parent input files and recovered JS bytes are verified before use.
Existing runs remain immutable with their original metadata; do not backfill modern claims into them.

A full saved-source rehearsal and its limits are recorded in
[the update evidence](../../docs/reviews/analysis-provenance-rehearsal-2026-10-16.json).

Catalog comparisons also report exact source-hash multiset differences separately from selected
schema/CLI signatures. Paths are review locations, not matching keys. Rebundling/minification may
change every hash; these leads cannot establish handler/gate equivalence or behavioral changes.
See the update workflow's module-byte rehearsal for the observed 300→301 noise limit.

## Code embedded in other assets

`code-assets <extraction-run>` supplements the JS-loader index/catalog. It verifies inventory and
selected asset hashes, records actual Acorn/TypeScript parser provenance, and parses code-shaped
filenames without importing or executing them. Top-level import/export candidates include text
JS, TS/TSX and declaration assets. HTML, unsupported encodings and syntax failures remain explicit
unparsed results. A complete stage means all selected entries were accounted for, not all parsed.
Filename selection cannot establish complete discovery of executable strings or generated code;
loader sinks and runtime roles require source review. It does not compare these assets between releases.

The pinned 301 run selected 24 entries: 17 parsed, three HTML, three unsupported encodings and one
syntax failure. See [the saved metadata](../../docs/reviews/embedded-code-assets-2026-10-16.json).

The expanded decoder follows Zstandard magic rather than trusting extraction encoding, includes
`.zst` filenames, and writes hashed derived bytes beside the catalog under `decoded/`. It requires
Node's Zstandard support for compressed entries (otherwise records them unparsed), caps decoded
output/window at 16 MiB, and checks complete standard-frame boundaries before libzstd decoding.
Framing follows [RFC 8878](https://www.rfc-editor.org/rfc/rfc8878.html); skippable frames are unsupported.
UTF-16 is explicitly inferred from BOM or a bounded NUL-byte heuristic; decoding is strict. Ranges
refer to decoded asset bytes, not compressed bytes. Original extraction bytes stay unchanged.
Ambient TypeScript modules are indexed separately from ESM exports, without resolving their types.

The expanded pin run accounts for 72 assets: 58 parsed, 13 unparsed HTML and one concatenated-module
syntax failure. It recovers the shipped 651,852-byte declarations with 586 `claude-code` and 81
`claude-code/testing` top-level declaration candidates. These are declarations, not runtime feature
counts. The earlier 24-asset run remains historical evidence with its narrower selection/decoder.

## Shipped plugin declaration comparison

`mod-declarations <code-assets-run> <mod-api-run>` verifies both parent output hashes, the target
identity and decoded declaration bytes. It indexes literal `CoreEngineInterface` namespaces,
call signatures/overloads, parameter and return type text, references and source ranges. Local
nongeneric aliases and literal indexed members are followed, with cycles and unsupported shapes
left unresolved. Signature text stays in ignored output. No typechecker, target process or recovered
module executes. A same-name match does not establish compatible arguments or effective availability.

Pinned 301 has 20 namespaces, 83 method names and 90 signatures, with no unresolved selected callable
shapes. Every declared name is a runtime adapter candidate; `flag.value` is the sole runtime-only
candidate. The separate default-table review explains that filter. Generic/conditional/inherited types,
plugin augmentations and runtime gate contracts remain outside this comparison.

## Asset references and native plugin test kit

`code-assets` now verifies every JS-loader module hash and syntax-checks matching modules to record
literal `/$bunfs/root/` references. Comments and constructed paths do not count; recorded bindings
and direct calls are navigation leads, not alias/dataflow resolution. All 72 selected pin assets have
references in 37 modules. This does not prove every loader sink, delivery path or availability gate.

The selected `kit-modules.js-*.txt.zst` container follows native `//// <module path>` splitting.
The scanner records each fragment's decoded-parent byte range and independent AST imports/exports,
then checks static imports/reexports with the native kit resolver's prefix and suffix rules. The pin
contains 293 parsed fragments, all reachable from `index.js`, with 626 edges and no unresolved static
references. No module is linked or executed. Other concatenation formats remain unsupported.
The current run has zero source syntax failures, plus 13 HTML templates deliberately left unparsed.
Earlier one-failure runs remain immutable historical evidence.

## HTML inline script follow-up

`html-assets <code-assets-run>` is a static follow-up requiring Python 3. An isolated Python helper
uses the standard-library HTML parser to locate scripts/handler attributes; Acorn parses executable
inline script bodies without evaluating them. It verifies parent/decoded hashes and records Python,
HTML parser/helper and JS scanner/parser provenance. Unicode byte ranges refer to decoded HTML.
External references are recorded without fetching; data/other-language, unclosed and syntax-failed
scripts remain explicit. Handler bodies are not parsed. This is not a browser DOM or template engine.

The pinned 13 templates contain 24 script elements: 15 parsed JavaScript and nine data/other-script
blocks, no external references, handler attributes or syntax failures. The existing asset review
records two source-traced frame analytics messages, separate from NDJSON. No browser/native code ran.

## Whole-asset and declaration update comparison

`compare-assets <before-extraction> <after-extraction>` verifies inventory hashes and every compared
non-JS-loader asset's bytes/size. Its multiset key includes SHA-256, loader, encoding and entry flag;
paths are review locations. It includes arbitrary data, compressed files and native bindings without
filename filtering. It neither decompresses nor parses/executes them. Same bytes do not establish
transitive behavior; recompression can produce differences without semantic changes.

`compare-mod-types <before-code-assets> <after-code-assets>` verifies both catalogs and decoded
shipped declarations, then compares TypeScript-printer-normalized ambient declarations with comments
removed. It groups module/kind/name identities and preserves overload multiplicity. It catches edits
to referenced argument/result types even when all method names match. No type equivalence or runtime
gate compatibility is inferred; original bytes and source ranges remain available for review.

Saved 300→301 rehearsal: 253 non-JS assets on each side, 234 unchanged occurrences, 19 unmatched each
side. Declarations have one added identity, five changed and 633 unchanged; method names stay at 83.
Nine focused comparison tests pass. See the existing embedded-asset and mod API review records.

## Declaration values versus virtual module exports

`mod-declarations` also queries value exports of the shipped ambient modules using TypeScript in an
isolated noEmit/noLib/noResolve program. It does not claim a full successful compile. It compares
those names with the state-library exports and static test-kit reexport candidates; the imported
asset-helper hash is recorded. Internal/ambiguous star bindings remain candidates, not public APIs.

The pin declares seven `claude-code` values, but the selected virtual module exports only the five
state helpers. `TIERS` and `INSTRUCTION_FILE_KINDS` are declaration-only in this path. The testing
module declares five helpers, all present among 102 static runtime export candidates; the other 97
remain internal/unselected tooling. These are name-surface findings, not runtime import probes.
Nineteen focused code-asset/declaration tests pass. No code generation, source evaluation or native
execution is involved in the checker query or export fixed-point collection.

## Declared plugin event families

`mod-declarations` now separately compares fixed `CoreEventOf` keys with the native event registry,
records Engine/Classic/Op family membership, result-map keys and streaming chunk keys, and locates
the source-defined custom noun augmentation types. Its isolated checker query is not full type
validation or execution. Empty unaugmented custom-key results are never reported as absent features.

The pin resolves 144 declared core event keys (47 engine, 33 classic, 64 operation), with 144 result
keys and two streaming chunk keys (`turn.step`, `process.spawn`). Every declared key appears in the
145-name native registry; `flag.value` is the sole registry-only name. Nine focused declaration tests
pass. Event names, public methods, host dispatch and NDJSON transport remain distinct sets.

`request-dispatch <protocol-schema-run>` verifies and parses every JS-loader module. Direct sites
and conservative lexical const alias/destructuring candidates are separate arrays. Module hashes,
decoded offsets and parser/scanner/helper provenance are preserved; mutable/default aliases,
interprocedural dataflow and dynamic tables remain outside this scanner. Candidates do not prove
runtime identity, reachability or admission. See the headless-dispatch reference for the saved scan.

`keybindings <extraction-run>` verifies and parses all JS modules for terminal context/bindings
objects, literal action arrays and action-to-action alias maps. It retains examples, conditional/computed keys and unresolved
spreads as candidates, not effective keymaps. Classify the selected native registry before updating
the coverage matrix; action declarations are not new protocol controls.

`env-schema <extraction-run>` identifies top-level typed environment getter tables without reading
user values or executing getters. Resolve literal constructor arguments and review the actual merge,
parser/helper and consumer owners before interpreting names as behavior. Direct/computed reads and
external schemas remain outside its syntax scope.

`compare-env <before-env-schema-run> <after-env-schema-run>` verifies both parent outputs and
compares environment name/parser/argument multisets independent of module and minified binding names.
Duplicate counts and unresolved arguments are retained; results are declaration-review leads.

## Cross-module literal names

`module-symbols` follows explicit imports/reexports, local aliases and recovered Bun `export *`
chains without executing modules. It distinguishes shared binding origins from equal string values:
ambiguous, unknown or computed star conflicts remain unresolved. Explicit exports take precedence;
star propagation excludes default. Destructuring and loop assignments invalidate literal candidates.
This is conservative name analysis, not a complete linker or dataflow engine.

The [saved rescan](../../docs/reviews/literal-symbol-resolution-2026-10-16.json) verifies all 2,434 JS
modules and retains 175 tool-shaped sites, 154 with resolved names; no site/name classification changed
on the pinned release. Eighteen focused resolver/tool-definition/registry tests pass. The broader
feature discovery claim remains unproven.

`compare-commands <before-slash-run> <after-slash-run>` verifies expanded command catalogs and
compares resolved name/family declaration metadata multisets. It retains duplicates and unresolved
names, ignores minified locations/bindings and marks expression fields unexamined. Equal metadata
is not behavioral equivalence. Ten focused checks and the saved 300→301 rehearsal are recorded in
[the dynamic-command review](../../docs/reviews/native-dynamic-command-loaders-2.1.301.json).

The lexical-scope follow-up is closed for class declarations/expressions, for/in/of lexical bindings,
switch-case bindings and conservative loop-var write invalidation. Thirty focused resolver/catalog
consumer checks pass, and both pinned catalog byte outputs remain identical. See the same literal
resolution review for scope and limits; this is not a complete JavaScript dataflow engine or a reason
to start another scanner thread. Remaining work follows the bounded research acceptance gates.
