import ts from 'typescript';
import {readFile,writeFile,stat,realpath} from 'node:fs/promises';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';

/** Literal call-site evidence for explicitly reviewed transport expressions; never execute app source. */
export function inspectAppControlCalls(source,callees){
 const ast=ts.createSourceFile('app-controls.ts',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
 if(ast.parseDiagnostics.length)throw Error(ts.flattenDiagnosticMessageText(ast.parseDiagnostics[0].messageText,'\n'));
 const calls=[];
 function walk(node){
  if(ts.isCallExpression(node)&&callees.includes(node.expression.getText(ast))){
   const arg=node.arguments[0],start=node.getStart(ast),entry={callee:node.expression.getText(ast),line:ast.getLineAndCharacterOfPosition(start).line+1,start,end:node.end,subtypeLiteral:null,subtypeDefinite:false,fields:[],spreads:0};
   if(arg&&ts.isObjectLiteralExpression(arg)){
    let possibleOverride=false;
    for(const field of arg.properties){
     if(ts.isSpreadAssignment(field)){entry.spreads++;possibleOverride=true;continue;}
     const name=field.name&&!ts.isComputedPropertyName(field.name)?field.name.text:null;
     if(name)entry.fields.push(name);else possibleOverride=true;
     if(name==='subtype'){
      entry.subtypeLiteral=ts.isPropertyAssignment(field)&&ts.isStringLiteral(field.initializer)?field.initializer.text:null;
      possibleOverride=false;
     }
    }
    entry.subtypeDefinite=entry.subtypeLiteral!==null&&!possibleOverride;
   }
   calls.push(entry);
  }
  ts.forEachChild(node,walk);
 }
 walk(ast);return calls;
}

export async function catalogAppControlAccess(protocolRun,checkout,output){
 const parent=await readCompleteRun(protocolRun,'protocol-schemas'),bytes=await readFile(join(protocolRun,'protocol-schemas.json'));
 if(hash(bytes)!==parent.protocolSchemasSha256)throw Error('Native protocol inventory changed');
 checkout=await realpath(checkout);if(!(await stat(join(checkout,'.git'))).isFile())throw Error('Use the isolated linked worktree');
 const specs={'query.ts':['hostControls.request'],'ui-controls.ts':['request','controls.request']},sources={},calls=[];
 for(const[file,callees]of Object.entries(specs)){const source=await readFile(join(checkout,'packages/default-setup/src/features/code/be/services/claude-code',file));sources[file]=hash(source);calls.push(...inspectAppControlCalls(source.toString(),callees).map(call=>({...call,file})));}
 const native=JSON.parse(bytes),subtypes=[...new Set(calls.flatMap(call=>call.subtypeLiteral?[call.subtypeLiteral]:[]))].sort();
 const requests=native.requests.map(request=>({subtype:request.subtype,direction:request.direction,appCallSites:calls.filter(call=>call.subtypeLiteral===request.subtype)}));
 const result={requests,calls,appSubtypesOutsideDeclaredUnion:subtypes.filter(subtype=>!native.requests.some(request=>request.subtype===subtype)),qualification:'Reviewed query/UI transport expression call sites only; lexical spelling is not symbol/data-flow resolution, response handling, callback coverage, availability or app UI parity. Spreads can override a literal; dynamic forwarding remains explicit.'};
 const run=await createRun(output,'app-control-access',{targetSha256:parent.inputs.targetSha256,protocolRun,protocolRunId:parent.id,protocolSchemasSha256:hash(bytes),productCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:checkout,encoding:'utf8'}).trim(),sourceHashes:sources,scannerSha256:hash(await readFile(new URL(import.meta.url))),parser:'typescript@'+ts.version});
 try{await writeFile(join(run.directory,'app-control-access.json'),JSON.stringify(result,null,2)+'\n');await run.finish({status:'complete',nativeDeclaredRequests:requests.length,literalAppSubtypes:subtypes.length,dynamicCalls:calls.filter(call=>call.subtypeLiteral===null).length});return{directory:run.directory,status:'complete',nativeDeclaredRequests:requests.length,literalAppSubtypes:subtypes.length,dynamicCalls:calls.filter(call=>call.subtypeLiteral===null).length,appSubtypesOutsideDeclaredUnion:result.appSubtypesOutsideDeclaredUnion};}catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
