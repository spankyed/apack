import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {basename,join,posix} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
import {analysisProvenance} from './provenance.mjs';

function walk(node,visit,parents=[]){
 if(!node?.type)return;
 visit(node,parents);
 for(const value of Object.values(node)){
  if(Array.isArray(value)){for(const child of value)walk(child,visit,[...parents,node]);}
  else if(value?.type)walk(value,visit,[...parents,node]);
 }
}
const key=node=>node?.type==='Identifier'?node.name:node?.type==='Literal'?node.value:undefined;
const field=(node,name)=>node.properties?.find(property=>property.type==='Property'&&!property.computed&&key(property.key)===name)?.value;

/** Static producer identities only; mounted callbacks and native admission require process evidence. */
export function inspectNativeHelp(source){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),frames=[],tabs=[];
 walk(ast,(node,parents)=>{
  if(node.type!=='ObjectExpression')return;
  const title=field(node,'title'),id=field(node,'id');
  if(title?.type==='Literal'&&title.value==='Help'&&field(node,'defaultTab')){
   const call=parents.at(-1),owner=parents.findLast(parent=>parent.type==='FunctionDeclaration');
   if(call?.type!=='CallExpression'||call.arguments[1]!==node||!owner)throw Error('Help producer shape changed');
   frames.push({component:key(call.arguments[0]),defaultTab:field(node,'defaultTab').value,owner:owner.id.name,start:owner.start,end:owner.end,sha256:hash(source.slice(owner.start,owner.end))});
  }
  if(id?.type==='Literal'&&['general','commands','custom'].includes(id.value)&&title?.type==='Literal')tabs.push({id:id.value,title:title.value,start:node.start,end:node.end});
 });
 if(frames.length!==1)throw Error('Expected one original Help producer');
 if(JSON.stringify(tabs.map(tab=>tab.id))!==JSON.stringify(['general','commands','custom']))throw Error('Help tab contract changed');
 const functions=ast.body.filter(node=>node.type==='FunctionDeclaration').map(node=>({name:node.id.name,start:node.start,end:node.end,sha256:hash(source.slice(node.start,node.end))}));
 const imports=ast.body.filter(node=>node.type==='ImportDeclaration').flatMap(node=>node.specifiers.map(specifier=>({local:specifier.local.name,imported:specifier.imported?.name,module:basename(node.source.value)})));
 return {frame:frames[0],tabs,functions,imports};
}

export async function recoverNativeHelpContracts(extraction,output){
 const parent=await readCompleteRun(extraction,'extract'),bytes=await readFile(join(extraction,'inventory.json'));
 if(hash(bytes)!==parent.inventorySha256)throw Error('Extraction inventory changed');
 const inventory=JSON.parse(bytes),run=await createRun(output,'native-help-contracts',{extraction,targetSha256:parent.inputs.targetSha256,inventorySha256:hash(bytes),...await analysisProvenance(new URL(import.meta.url))});
 try{
  async function read(file){
   if(!file||posix.isAbsolute(file.path)||file.path.includes('\\')||file.path.split('/').includes('..'))throw Error('Unsafe source path');
   if(!['latin1','utf8','utf-8'].includes(file.encoding))throw Error('Unsupported source encoding');
   const bytes=await readFile(join(extraction,'extracted',file.path));if(hash(bytes)!==file.sha256)throw Error('Source changed: '+file.path);
   return bytes.toString(file.encoding);
  }
  const candidates=[];
  for(const file of inventory.filter(file=>file.loader==='js')){
   const source=await read(file);
   if(source.includes('Browse custom commands')&&source.includes('title:"Help"'))candidates.push({file,source});
  }
  if(candidates.length!==1)throw Error('Help module is missing or ambiguous');
  const {file,source}=candidates[0],contract=inspectNativeHelp(source);
  const wrapper=contract.imports.find(item=>item.local===contract.frame.component);if(!wrapper)throw Error('Help tab wrapper import missing');
  const dependency=inventory.find(file=>file.path==='files/'+wrapper.module),dependencySource=await read(dependency);
  const tree=parse(dependencySource,{ecmaVersion:'latest',sourceType:'module'});
  const exported=tree.body.filter(node=>node.type==='ExportNamedDeclaration').flatMap(node=>node.specifiers??[]).find(specifier=>key(specifier.exported)===wrapper.imported);
  const fn=tree.body.find(node=>node.type==='FunctionDeclaration'&&node.id.name===exported?.local.name);if(!fn)throw Error('Help wrapper export changed');
  const result={module:{path:file.path,sha256:file.sha256},...contract,wrapper:{module:dependency.path,moduleSha256:dependency.sha256,name:fn.id.name,start:fn.start,end:fn.end,sha256:hash(dependencySource.slice(fn.start,fn.end))},qualification:'Static original Help producer and tab wrapper identities. Not live command admission, callback execution, rendered shortcut/keymap coverage or actual-app acceptance.'};
  const encoded=JSON.stringify(result,null,2)+'\n';await writeFile(join(run.directory,'help-contracts.json'),encoded);await run.finish({status:'complete',outputSha256:hash(encoded)});return {directory:run.directory,...result};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
