import {readFile,writeFile} from 'node:fs/promises';
import {join,resolve,relative,isAbsolute} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';

/** Compare byte/interpretation multisets; filenames are review locations, not identities. */
export function compareAssetInventories(before,after) {
  function grouped(entries){
    const result=new Map();
    for(const entry of entries.filter(e=>e.loader!=='js')){
      if(!/^[a-f0-9]{64}$/.test(entry.sha256)||typeof entry.path!=='string'||typeof entry.loader!=='string')throw new Error('Invalid asset identity');
      const key=JSON.stringify([entry.sha256,entry.loader,entry.encoding,Boolean(entry.entry)]),values=result.get(key)??[];
      values.push(entry);result.set(key,values);
    }
    for(const values of result.values())values.sort((a,b)=>a.path.localeCompare(b.path));
    return result;
  }
  const a=grouped(before),b=grouped(after),beforeOnly=[],afterOnly=[];let unchangedOccurrences=0;
  const metadata=entry=>({path:entry.path,sha256:entry.sha256,loader:entry.loader,encoding:entry.encoding,bytes:entry.bytes,entry:Boolean(entry.entry)});
  for(const key of [...new Set([...a.keys(),...b.keys()])].sort()){
    const old=a.get(key)??[],next=b.get(key)??[],shared=Math.min(old.length,next.length);
    unchangedOccurrences+=shared;beforeOnly.push(...old.slice(shared).map(metadata));afterOnly.push(...next.slice(shared).map(metadata));
  }
  return {unchangedOccurrences,beforeOnly,afterOnly,qualification:'All inventoried non-JS-loader asset bytes plus loader/encoding/entry interpretation, as multisets ignoring filenames. Compression or rebundling may change bytes without behavior changes; unmatched entries are unpaired review leads. No decoding, code execution, semantic equivalence, binary ABI or complete extraction claim.'};
}

async function verifiedInventory(directory,parent){
  const raw=await readFile(join(directory,'inventory.json'));
  if(hash(raw)!==parent.inventorySha256)throw new Error('Extraction inventory changed');
  const entries=JSON.parse(raw),seen=new Set(),root=resolve(directory,'extracted');
  for(const entry of entries.filter(e=>e.loader!=='js')){
    const file=resolve(root,entry.path),path=relative(root,file);
    if(!path||path.startsWith('..')||isAbsolute(path)||seen.has(path))throw new Error('Unsafe or duplicate asset path');
    seen.add(path);const bytes=await readFile(file);
    if(hash(bytes)!==entry.sha256||bytes.length!==entry.bytes)throw new Error('Extracted asset changed');
  }
  return entries;
}

export async function compareExtractionAssets(before,after,output){
  const parents=await Promise.all([before,after].map(p=>readCompleteRun(p,'extract')));
  const inventories=await Promise.all([before,after].map((p,i)=>verifiedInventory(p,parents[i])));
  const run=await createRun(output,'compare-assets',{before,after,parentRunIds:parents.map(p=>p.id),targetSha256:parents.map(p=>p.inputs.targetSha256),scannerSha256:hash(await readFile(new URL(import.meta.url))),runHelperSha256:hash(await readFile(new URL('../artifacts/runs.mjs',import.meta.url)))});
  try{
    const result=compareAssetInventories(...inventories),bytes=Buffer.from(JSON.stringify(result,null,2)+'\n');
    await writeFile(join(run.directory,'comparison.json'),bytes);
    const summary={beforeAssets:inventories[0].filter(e=>e.loader!=='js').length,afterAssets:inventories[1].filter(e=>e.loader!=='js').length,unchangedOccurrences:result.unchangedOccurrences,beforeOnly:result.beforeOnly.length,afterOnly:result.afterOnly.length};
    await run.finish({status:'complete',outputSha256:hash(bytes),...summary});return {directory:run.directory,status:'complete',...summary};
  }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
