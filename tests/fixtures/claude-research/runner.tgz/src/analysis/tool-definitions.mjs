import { inspectModuleSymbols, resolveLiteralSymbol } from './module-symbols.mjs';
import { parse } from 'acorn';

/** Locate tool-shaped objects; discovery candidates, never an availability assertion. */
export function inspectToolDefinitions(source) {
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module' });
  const candidates = [];
  function walk(node) {
    if (!node?.type) return;
    if (node.type === 'ObjectExpression') {
      const fields = new Map(node.properties.filter(property => property.type === 'Property' && !property.computed)
        .map(property => [property.key.name ?? property.key.value, property]));
      if (['name', 'inputSchema', 'description'].every(field => fields.has(field))) {
        const name = fields.get('name').value;
        const deferred = fields.get('shouldDefer')?.value;
        candidates.push({ start: node.start, end: node.end,
          literalName: name.type === 'Literal' && typeof name.value === 'string' ? name.value : null,
          nameSymbol: name.type === 'Identifier' ? name.name : null,
          nameExpression: name.type,
          fields: [...fields.keys()],
          deferredLiteral: deferred?.type === 'Literal' ? deferred.value
            : deferred?.type === 'UnaryExpression' && deferred.operator === '!' && deferred.argument.type === 'Literal'
              ? !deferred.argument.value : null,
          enableGate: fields.has('isEnabled') ? { start: fields.get('isEnabled').start, end: fields.get('isEnabled').end } : null,
        });
      }
    }
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) { for (const child of value) walk(child); }
      else if (value?.type) walk(value);
    }
  }
  walk(ast);
  return candidates;
}

export async function catalogToolDefinitions(extraction, output) {
  const { readFile, writeFile } = await import('node:fs/promises');
  const { join } = await import('node:path');
  const { createRun, hash, readCompleteRun } = await import('../artifacts/runs.mjs');
  const parent = await readCompleteRun(extraction, 'extract');
  const bytes = await readFile(join(extraction, 'inventory.json'));
  if (hash(bytes) !== parent.inventorySha256) throw new Error('Inventory changed');
  const run = await createRun(output, 'tool-definitions', { extraction, targetSha256: parent.inputs.targetSha256,
    scannerSha256: hash(await readFile(new URL(import.meta.url))),
    resolverSha256: hash(await readFile(new URL('./module-symbols.mjs', import.meta.url))), parser: 'acorn@8.15.0' });
  try {
    const modules = [];
    const symbols = new Map();
    for (const file of JSON.parse(bytes)) {
      if (file.loader !== 'js') continue;
      if (!['latin1', 'utf8', 'utf-8'].includes(file.encoding)) throw new Error('Unsupported encoding');
      const source = await readFile(join(extraction, 'extracted', file.path));
      if (hash(source) !== file.sha256) throw new Error(`Source changed: ${file.path}`);
      const text = source.toString(file.encoding);
      symbols.set(file.path, inspectModuleSymbols(text));
      const tools = inspectToolDefinitions(text);
      if (tools.length) modules.push({ path: file.path, sha256: file.sha256, tools });
    }
    for (const module of modules) for (const tool of module.tools) {
      const shadowed = tool.nameSymbol && symbols.get(module.path).shadowRanges.some(range =>
        range.start < tool.start && range.end > tool.end && range.names.includes(tool.nameSymbol));
      tool.resolvedName = tool.literalName;
      tool.nameResolution = tool.literalName ? 'literal' : shadowed ? 'local-shadow-unresolved' : 'unresolved';
      if (tool.nameSymbol && !shadowed) {
        const resolved = resolveLiteralSymbol(symbols, module.path, tool.nameSymbol);
        if (resolved) { tool.resolvedName = resolved.value; tool.nameResolution = 'literal-binding-chain'; tool.nameChain = resolved.chain; }
      }
    }
    const result = JSON.stringify({ modules, qualification: 'Tool-shaped object candidates only; symbolic/dynamic names, registrations, gates and availability require separate tracing.' }, null, 2) + '\n';
    await writeFile(join(run.directory, 'tool-definitions.json'), result);
    const candidates = modules.reduce((sum, module) => sum + module.tools.length, 0);
    await run.finish({ status: 'complete', outputSha256: hash(Buffer.from(result)), candidates });
    return { directory: run.directory, status: 'complete', candidates };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
