import { parse } from 'acorn';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createRun, hash, readCompleteRun } from '../artifacts/runs.mjs';

const key = property => property.computed && property.key?.type !== 'Literal'
  ? null : property.key?.name ?? property.key?.value;
function walk(node, visit) {
  if (!node?.type) return;
  visit(node);
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) { for (const child of value) if (child?.type) walk(child, visit); }
    else if (value?.type) walk(value, visit);
  }
}
function label(node) {
  if (node?.type === 'Literal' && typeof node.value === 'string') return node.value;
  if (node?.type !== 'CallExpression') return null;
  if (node.arguments[0]?.type === 'Literal' && typeof node.arguments[0].value === 'string') return node.arguments[0].value;
  return null;
}
function modifiers(node) {
  const names = [];
  while (node?.type === 'CallExpression' && node.callee.type === 'MemberExpression') {
    names.push(node.callee.property.name ?? node.callee.property.value);
    node = node.callee.object;
  }
  return names.sort();
}

/** Follow the declared control_request payload union, without executing any factory. */
export function inspectProtocolSchemas(source) {
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module', locations: true });
  const variables = new Map();
  for (const statement of ast.body) {
    const declaration = statement.type === 'ExportNamedDeclaration' ? statement.declaration : statement;
    if (declaration?.type === 'VariableDeclaration') {
      for (const item of declaration.declarations) if (item.id.type === 'Identifier') variables.set(item.id.name, item);
    }
  }
  const envelopes = [];
  for (const declaration of variables.values()) walk(declaration.init, node => {
    if (node.type !== 'ObjectExpression') return;
    if (label(node.properties.find(property => key(property) === 'type')?.value) !== 'control_request') return;
    const request = node.properties.find(property => key(property) === 'request')?.value;
    if (request?.type === 'CallExpression' && request.callee.type === 'Identifier') {
      envelopes.push({ symbol: declaration.id.name, unionSymbol: request.callee.name, start: node.start });
    }
  });
  if (envelopes.length !== 1) throw new Error(`Expected one declared request envelope, found ${envelopes.length}`);
  const envelope = envelopes[0];
  const union = variables.get(envelope.unionSymbol);
  if (!union?.init) throw new Error('Request payload union declaration not found');
  const arrays = [];
  walk(union.init, node => {
    if (node.type === 'ArrayExpression' && node.elements.length && node.elements.every(item =>
      item?.type === 'CallExpression' && item.callee.type === 'Identifier' && item.arguments.length === 0)) arrays.push(node);
  });
  if (arrays.length !== 1) throw new Error(`Expected one explicit factory union array, found ${arrays.length}`);
  const requests = [], unresolved = [];
  for (const member of arrays[0].elements) {
    const symbol = member.callee.name;
    const declaration = variables.get(symbol);
    if (!declaration?.init) { unresolved.push({ symbol, reason: 'missing-factory-declaration' }); continue; }
    const objects = [];
    walk(declaration.init, node => {
      if (node.type === 'ObjectExpression' && node.properties.some(property =>
        key(property) === 'subtype' && label(property.value))) objects.push(node);
    });
    const roots = objects.filter(object => !objects.some(parent => parent !== object
      && parent.start < object.start && parent.end > object.end));
    if (roots.length !== 1) { unresolved.push({ symbol, reason: 'ambiguous-or-missing-schema-object', count: roots.length }); continue; }
    const object = roots[0];
    const subtype = label(object.properties.find(property => key(property) === 'subtype').value);
    let description = '';
    walk(declaration.init, node => {
      if (node.type === 'CallExpression' && node.callee.type === 'MemberExpression'
        && node.callee.property.name === 'describe' && node.callee.object.start <= object.start
        && node.callee.object.end >= object.end && node.arguments[0]?.type === 'Literal') description = node.arguments[0].value;
    });
    const spreadFields = object.properties.filter(property => property.type !== 'Property').map(property => ({ start: property.start, end: property.end }));
    const fields = object.properties.filter(property => property.type === 'Property').map(property => ({
      name: key(property), modifiers: modifiers(property.value), start: property.start, end: property.end,
    }));
    const fieldComposition = [];
    walk(declaration.init, call => {
      if (call.type !== 'CallExpression' || call.callee.type !== 'MemberExpression'
        || !['extend', 'safeExtend', 'merge', 'and', 'pick', 'omit', 'partial', 'required'].includes(call.callee.property.name)
        || call.start > object.start || call.end < object.end) return;
      const base = call.callee.object;
      const baseSymbol = base.type === 'CallExpression' && base.callee.type === 'Identifier'
        && base.arguments.length === 0 ? base.callee.name : null;
      let inherited;
      if (call.callee.property.name === 'extend' && call.arguments[0] === object && variables.get(baseSymbol)?.init) {
        const initializer = variables.get(baseSymbol).init;
        const candidates = [];
        let transformed = false;
        walk(initializer, node => {
          if (node.type === 'ObjectExpression') candidates.push(node);
          if (node.type === 'CallExpression' && node.callee.type === 'MemberExpression'
            && ['extend', 'safeExtend', 'merge', 'and', 'pick', 'omit', 'partial', 'required'].includes(node.callee.property.name)) transformed = true;
        });
        const roots = candidates.filter(candidate => !candidates.some(parent => parent !== candidate
          && parent.start < candidate.start && parent.end > candidate.end));
        if (!transformed && roots.length === 1 && roots[0].properties.every(property => property.type === 'Property' && key(property) !== null)) {
          inherited = roots[0].properties.map(property => ({ name: key(property), modifiers: modifiers(property.value),
            start: property.start, end: property.end, inheritedFrom: baseSymbol }));
        }
      }
      const resolved = inherited !== undefined;
      fieldComposition.push({ kind: call.callee.property.name, baseSymbol, start: call.start, resolved });
      if (resolved) fields.splice(0, fields.length, ...new Map([...inherited, ...fields].map(field => [field.name, field])).values());
      else unresolved.push({ symbol, reason: 'schema-composition', kind: call.callee.property.name, baseSymbol });
    });
    requests.push({ subtype, symbol, start: object.start, end: object.end, line: object.loc.start.line,
      internal: typeof description === 'string' && description.includes('@internal'), description,
      fields, spreadFields, fieldComposition });
    const computedFields = object.properties.filter(property => property.type === 'Property' && key(property) === null);
    if (computedFields.length) unresolved.push({ symbol, reason: 'computed-fields', count: computedFields.length });
    if (spreadFields.length) unresolved.push({ symbol, reason: 'spread-fields', count: spreadFields.length });
  }
  const allSymbols = new Set(arrays[0].elements.map(member => member.callee.name));
  const slices = [];
  for (const declaration of variables.values()) {
    if (!declaration.init || declaration === union) continue;
    walk(declaration.init, node => {
      if (node.type !== 'ArrayExpression' || !node.elements.length || node.elements.length >= allSymbols.size) return;
      if (!node.elements.every(member => member?.type === 'CallExpression'
        && member.callee.type === 'Identifier' && member.arguments.length === 0 && allSymbols.has(member.callee.name))) return;
      let description = '';
      walk(declaration.init, call => {
        if (call.type === 'CallExpression' && call.callee.type === 'MemberExpression'
          && call.callee.property.name === 'describe' && call.callee.object.start <= node.start
          && call.callee.object.end >= node.end && call.arguments[0]?.type === 'Literal') description = call.arguments[0].value;
      });
      let direction;
      if (/agent loop originates|loop→client RPC slice/.test(description)) direction = 'cli-to-host';
      if (/client sends to drive the loop|client→loop command slice/.test(description)) direction = 'host-to-cli';
      if (direction) slices.push({ symbol: declaration.id.name, direction, start: node.start,
        members: node.elements.map(member => member.callee.name) });
    });
  }
  for (const request of requests) {
    const owners = slices.filter(slice => slice.members.includes(request.symbol));
    if (owners.length !== 1) {
      unresolved.push({ symbol: request.symbol, reason: 'ambiguous-or-missing-direction-slice', count: owners.length });
    } else {
      request.direction = /Flows in both directions/.test(request.description) ? 'bidirectional' : owners[0].direction;
      request.directionSlice = owners[0].symbol;
    }
  }
  return { schemaVersion: 1, envelope, slices, declaredMembers: arrays[0].elements.length, requests, unresolved,
    qualification: 'Declared schema-union membership and field syntax only; factories are not executed. Directions follow explicit source-described sub-unions, with documented bidirectional exceptions; gates, opaque field types and runtime behavior require separate verification.' };
}

export async function catalogProtocolSchemas(catalogRun, output) {
  const parent = await readCompleteRun(catalogRun, 'catalog');
  const bytes = await readFile(join(catalogRun, 'catalog.json'));
  if (hash(bytes) !== parent.catalogSha256) throw new Error('Catalog changed');
  const catalog = JSON.parse(bytes);
  const candidates = catalog.modules.filter(module => ['initialize', 'can_use_tool'].every(subtype =>
    module.controls.some(control => control.subtype === subtype && control.form === 'factory-candidate')));
  if (candidates.length !== 1) throw new Error(`Expected one control-schema module, found ${candidates.length}`);
  const module = candidates[0];
  const extraction = await readCompleteRun(parent.inputs.extraction, 'extract');
  const inventoryBytes = await readFile(join(parent.inputs.extraction, 'inventory.json'));
  if (hash(inventoryBytes) !== extraction.inventorySha256) throw new Error('Extraction inventory changed');
  const metadata = JSON.parse(inventoryBytes).find(file => file.path === module.path);
  if (!metadata || !['latin1', 'utf8', 'utf-8'].includes(metadata.encoding)) throw new Error('Unsupported or missing schema source encoding');
  const source = await readFile(join(parent.inputs.extraction, 'extracted', module.path));
  if (hash(source) !== module.sha256) throw new Error('Schema source changed');
  const run = await createRun(output, 'protocol-schemas', { catalogRun, parentRunId: parent.id,
    targetSha256: catalog.targetSha256, module: module.path, sourceSha256: module.sha256, sourceEncoding: metadata.encoding,
    scannerSha256: hash(await readFile(new URL(import.meta.url))), parser: 'acorn@8.15.0' });
  try {
    const result = inspectProtocolSchemas(source.toString(metadata.encoding));
    const data = JSON.stringify(result, null, 2) + '\n';
    await writeFile(join(run.directory, 'protocol-schemas.json'), data);
    const status = result.unresolved.length ? 'failed' : 'complete';
    await run.finish({ status, protocolSchemasSha256: hash(Buffer.from(data)), declaredMembers: result.declaredMembers, resolved: result.requests.length,
      unresolved: result.unresolved.length });
    return { directory: run.directory, status, declaredMembers: result.declaredMembers,
      resolved: result.requests.length, unresolved: result.unresolved };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}

export function compareProtocolSchemaData(before, after) {
  const signatures = data => new Set(data.requests.map(request => JSON.stringify({
    subtype: request.subtype, direction: request.direction,
    fields: request.fields.map(field => ({ name: field.name, modifiers: field.modifiers }))
      .sort((a, b) => String(a.name).localeCompare(String(b.name))),
  })));
  const a = signatures(before), b = signatures(after);
  return { added: [...b].filter(value => !a.has(value)).sort().map(JSON.parse),
    removed: [...a].filter(value => !b.has(value)).sort().map(JSON.parse) };
}

export async function compareProtocolSchemas(before, after, output) {
  const parents = await Promise.all([before, after].map(path => readCompleteRun(path, 'protocol-schemas')));
  const catalogs = await Promise.all([before, after].map(async (path, index) => {
    const bytes = await readFile(join(path, 'protocol-schemas.json'));
    if (hash(bytes) !== parents[index].protocolSchemasSha256) throw new Error(`Protocol schema catalog changed: ${path}`);
    return JSON.parse(bytes);
  }));
  const run = await createRun(output, 'compare-protocol-schemas', { before, after,
    targetSha256: parents.map(parent => parent.inputs.targetSha256) });
  try {
    const comparison = { ...compareProtocolSchemaData(...catalogs),
      qualification: 'Declared request directions and top-level field/modifier syntax, including resolved local inheritance. Opaque types, response schemas, gates and implementation behavior still require review and probes.' };
    await writeFile(join(run.directory, 'comparison.json'), JSON.stringify(comparison, null, 2) + '\n');
    await run.finish({ status: 'complete', added: comparison.added.length, removed: comparison.removed.length });
    return { directory: run.directory, status: 'complete', added: comparison.added.length, removed: comparison.removed.length };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
