import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {basename,join} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';

function walk(node,fn,parents=[]){if(!node||typeof node!=='object'||!node.type)return;fn(node,parents);for(const value of Object.values(node)){if(Array.isArray(value))for(const child of value)walk(child,fn,[...parents,node]);else if(value?.type)walk(value,fn,[...parents,node]);}}
const name=node=>node?.type==='Identifier'?node.name:node?.type==='Literal'?String(node.value):null;
function callee(node){if(node?.type==='Identifier')return node.name;if(node?.type==='MemberExpression'&&!node.computed){const object=callee(node.object);return object?object+'.'+name(node.property):null;}return null;}
const isFunction=node=>['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node.type);
function reference(node,parent){
 if(!parent)return true;
 if(['ImportSpecifier','ImportDefaultSpecifier','ImportNamespaceSpecifier','ExportSpecifier'].includes(parent.type))return false;
 if(parent.type==='VariableDeclarator'&&parent.id===node)return false;
 if(isFunction(parent)&&(parent.id===node||parent.params.includes(node)))return false;
 if(['MemberExpression','Property','MethodDefinition','PropertyDefinition'].includes(parent.type)&&!parent.computed&&(parent.property===node||parent.key===node)&&!(parent.shorthand&&parent.value===node))return false;
 if(['LabeledStatement','BreakStatement','ContinueStatement'].includes(parent.type)&&parent.label===node)return false;
 return true;
}
function moduleFacts(source){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),imports=[],exports=[],unsupported=[];
 for(const node of ast.body){
  if(node.type==='ImportDeclaration')for(const spec of node.specifiers){if(spec.type==='ImportSpecifier')imports.push({local:spec.local.name,imported:name(spec.imported),from:node.source.value});else unsupported.push({type:spec.type,start:spec.start});}
  if(node.type==='ExportNamedDeclaration'){
   for(const spec of node.specifiers)exports.push({local:name(spec.local),exported:name(spec.exported),from:node.source?.value});
   const declaration=node.declaration;
   if(declaration?.type==='VariableDeclaration')for(const item of declaration.declarations){if(item.id.type==='Identifier')exports.push({local:item.id.name,exported:item.id.name});else unsupported.push({type:'export-pattern',start:item.start});}
   if(declaration?.id?.type==='Identifier')exports.push({local:declaration.id.name,exported:declaration.id.name});
  }
  const declaration=node.type==='ExportNamedDeclaration'?node.declaration:node;
  if(declaration?.type==='VariableDeclaration')for(const item of declaration.declarations){
   const member=item.init,call=member?.type==='MemberExpression'&&!member.computed?member.object:null;
   if(item.id.type==='Identifier'&&call?.type==='CallExpression'&&call.callee.type==='MemberExpression'&&!call.callee.computed&&name(call.callee.property)==='require'&&call.callee.object.type==='MetaProperty'&&name(call.callee.object.meta)==='import'&&name(call.callee.object.property)==='meta'&&call.arguments.length===1&&typeof call.arguments[0].value==='string')imports.push({local:item.id.name,imported:name(member.property),from:call.arguments[0].value,syntax:'literal-import-meta-require-member'});
  }
  if(node.type==='ExportAllDeclaration'||node.type==='ExportDefaultDeclaration')unsupported.push({type:node.type,start:node.start});
 }
 return{imports,exports,unsupported};
}
/** Direct named aliases only. Candidate references are not producer reachability or transport availability. */
export function inspectDialogAccess(modules,descriptors){
 const byPath=new Map(modules.map(module=>[module.path,{...module,...moduleFacts(module.source),locals:new Map(),public:new Map()}]));
 const byBase=new Map();for(const path of byPath.keys()){const base=basename(path);if(byBase.has(base))throw Error('Ambiguous module basename: '+base);byBase.set(base,path);}
 const resolve=(current,specifier)=>specifier.startsWith('.')?byPath.has(join(current,'..',specifier))?join(current,'..',specifier):null:byBase.get(basename(specifier));
 for(const descriptor of descriptors){const module=byPath.get(descriptor.path);if(!module)throw Error('Missing descriptor module: '+descriptor.path);if(module.locals.has(descriptor.symbol))throw Error('Duplicate descriptor binding');module.locals.set(descriptor.symbol,descriptor.id);}
 let changed=true;while(changed){changed=false;for(const module of byPath.values()){
  for(const item of module.imports){const target=byPath.get(resolve(module.path,item.from))?.public.get(item.imported);if(target&&!module.locals.has(item.local)){module.locals.set(item.local,target);changed=true;}}
  for(const item of module.exports){const target=item.from?byPath.get(resolve(module.path,item.from))?.public.get(item.local):module.locals.get(item.local);if(target&&!module.public.has(item.exported)){module.public.set(item.exported,target);changed=true;}}
 }}
 const accesses=[];
 for(const module of byPath.values()){
  if(!module.locals.size)continue;
  const ast=parse(module.source,{ecmaVersion:'latest',sourceType:'module'}),seen=new Set(),scopeBindings=new WeakMap();
  function shadowed(fn,symbol){
   let bindings=scopeBindings.get(fn);if(!bindings){bindings=new Set();for(const param of fn.params)walk(param,node=>{if(node.type==='Identifier')bindings.add(node.name);});
    const collect=node=>{if(!node||typeof node!=='object'||!node.type||isFunction(node))return;if(node.type==='VariableDeclarator')walk(node.id,child=>{if(child.type==='Identifier')bindings.add(child.name);});for(const value of Object.values(node)){if(Array.isArray(value))value.forEach(collect);else if(value?.type)collect(value);}};collect(fn.body);scopeBindings.set(fn,bindings);}
   return bindings.has(symbol)||fn.id?.name===symbol;
  }
  walk(ast,(node,parents)=>{
   if(node.type!=='Identifier'||!module.locals.has(node.name)||!reference(node,parents.at(-1)))return;
   const key=node.start+':'+node.end;if(seen.has(key))return;seen.add(key);
   const parent=parents.at(-1),call=parents.findLast(item=>item.type==='CallExpression'||item.type==='NewExpression'),fn=parents.findLast(isFunction),statement=parents.findLast(item=>item.type.endsWith('Statement')||item.type==='VariableDeclarator')??parent;
   const fnParent=fn?parents[parents.indexOf(fn)-1]:null,fnName=fn?.id?.name??(fnParent?.type==='VariableDeclarator'?name(fnParent.id):fnParent?.type==='Property'?name(fnParent.key):null);
   const anchor=call??statement??node;
   accesses.push({descriptor:module.locals.get(node.name),path:module.path,local:node.name,start:node.start,end:node.end,parentType:parent?.type,property:parent?.type==='Property'?name(parent.key):null,callee:call?callee(call.callee):null,callStart:call?.start,callEnd:call?.end,enclosingFunction:fnName,functionStart:fn?.start,functionEnd:fn?.end,possibleShadow:parents.filter(isFunction).some(item=>shadowed(item,node.name)),conditionalAncestors:parents.filter(item=>['IfStatement','ConditionalExpression','LogicalExpression','SwitchCase'].includes(item.type)).map(item=>({type:item.type,start:item.start,end:item.end})),anchor:{start:anchor.start,end:anchor.end,sha256:hash(Buffer.from(module.source.slice(anchor.start,anchor.end),module.encoding??'utf8'))}});
  });
 }
 return{descriptors:descriptors.map(item=>({...item,bindings:[...byPath.values()].flatMap(module=>[...module.locals].filter(([,id])=>id===item.id).map(([local])=>({path:module.path,local,import:module.imports.find(binding=>binding.local===local)??null}))),exports:[...byPath.values()].flatMap(module=>[...module.public].filter(([,id])=>id===item.id).map(([exported])=>({path:module.path,exported}))),accesses:accesses.filter(access=>access.descriptor===item.id)})),modules:modules.length,unsupportedModuleForms:[...byPath.values()].filter(module=>module.unsupported.length).map(module=>({path:module.path,forms:module.unsupported})),qualification:'Static direct named import/export and literal import.meta.require member aliases with lexical reference candidates only. Namespace/default/star imports/exports, dynamic imports, alias assignments, data flow and producer/transport/gate reachability are not resolved. possibleShadow conservatively flags enclosing function declarations; block scope is not resolved. Calls may be display registries or predicates rather than producers. Offsets use decoded source units; anchor hashes use original encoding. No recovered code executed.'};
}
export async function catalogDialogAccess(extractionRun,dialogRun,output){
 const extraction=await readCompleteRun(extractionRun,'extract'),dialog=await readCompleteRun(dialogRun,'user-dialogs');
 if(extraction.inputs.targetSha256!==dialog.inputs.targetSha256)throw Error('Dialog target mismatch');
 const inventoryBytes=await readFile(join(extractionRun,'inventory.json')),dialogBytes=await readFile(join(dialogRun,'user-dialogs.json'));
 if(hash(inventoryBytes)!==extraction.inventorySha256||hash(dialogBytes)!==dialog.outputSha256)throw Error('Parent content changed');
 const modules=[];for(const file of JSON.parse(inventoryBytes)){if(file.loader!=='js')continue;const bytes=await readFile(join(extractionRun,'extracted',file.path));if(hash(bytes)!==file.sha256)throw Error('Source changed: '+file.path);modules.push({path:file.path,sha256:file.sha256,encoding:file.encoding,source:bytes.toString(file.encoding)});}
 const descriptors=JSON.parse(dialogBytes).modules.flatMap(module=>module.entries.map(entry=>({id:module.path+'#'+entry.symbol,path:module.path,symbol:entry.symbol,kind:entry.kind,kindReference:entry.kindReference,start:entry.start,end:entry.end})));
 const run=await createRun(output,'dialog-access',{targetSha256:extraction.inputs.targetSha256,extractionRun,dialogRun,dialogSha256:hash(dialogBytes),scannerSha256:hash(await readFile(new URL(import.meta.url))),parser:'acorn@8.15.0'});
 try{const findings=inspectDialogAccess(modules,descriptors);findings.sourceHashes=Object.fromEntries(modules.map(module=>[module.path,module.sha256]));const bytes=Buffer.from(JSON.stringify(findings,null,2)+'\n');await writeFile(join(run.directory,'dialog-access.json'),bytes);await run.finish({status:'complete',outputSha256:hash(bytes)});return{directory:run.directory,status:'complete',modules:modules.length,descriptors:descriptors.length,referenceCandidates:findings.descriptors.reduce((sum,item)=>sum+item.accesses.length,0),withoutReferenceCandidates:findings.descriptors.filter(item=>!item.accesses.length).map(item=>item.id)};}catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
