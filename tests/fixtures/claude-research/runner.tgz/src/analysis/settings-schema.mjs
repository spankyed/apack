import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { hash, readCompleteRun, createRun } from '../artifacts/runs.mjs';
import { parse } from 'acorn';
import { describeNestedSettings, inferSchemaConstructorExports } from './nested-settings-schema.mjs';
const key = property => property.type === 'Property' && !property.computed ? property.key.name ?? property.key.value : null;
function walk(node, visit, parent = null) {
  if (!node?.type) return;
  visit(node, parent);
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) { for (const child of value) walk(child, visit, node); }
    else if (value?.type) walk(value, visit, node);
  }
}
function constant(node) {
  if (node?.type === 'Literal') return node.value;
  if (node?.type === 'ArrayExpression') {
    const values = node.elements.map(constant);
    if (values.every(value => value !== undefined)) return values;
  }
  if (node?.type === 'UnaryExpression' && node.operator === '!' && node.argument.type === 'Literal') return !node.argument.value;
  return undefined;
}
function composition(property) {
  const node = property.type === 'SpreadElement' ? property.argument : null;
  const base = { kind: property.type, start: property.start, end: property.end };
  if (node && constant(node) === false) return { ...base, resolution: 'inert-false-spread' };
  if (node?.type === 'LogicalExpression' && node.operator === '&&' && node.right.type === 'ObjectExpression') {
    return { ...base, resolution: 'conditional-object',
      gate: { kind: node.left.type, start: node.left.start, end: node.left.end },
      conditionalFields: node.right.properties.filter(item => key(item) !== null).map(item => ({ name: key(item), start: item.start })),
      unresolvedProperties: node.right.properties.filter(item => key(item) === null).length };
  }
  return { ...base, resolution: 'unresolved' };
}
/** Source declarations only; feature contribution factories and policy effects are not evaluated. */
export function inspectSettingsSchema(source, { constructors = {} } = {}) {
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module' });
  const schemas = [], policyTables = [], featureContributions = [];
  walk(ast, (node, parent) => {
    if (node.type === 'ObjectExpression') {
      const keys = node.properties.map(key);
      if (keys.includes('buildGate') && keys.includes('shape')) {
        const factory = name => node.properties.find(property => key(property) === name)?.value;
        const result = fn => fn?.type === 'ArrowFunctionExpression' && fn.body.type !== 'BlockStatement' ? fn.body : null;
        const shape = result(factory('shape'));
        const permissions = result(factory('permissionsShape'));
        const declaredFields = object => object?.type === 'ObjectExpression'
          ? object.properties.filter(property => key(property) !== null).map(property => ({ name: key(property), start: property.start })) : null;
        featureContributions.push({ name: parent?.type === 'Property' ? key(parent) : null, start: node.start, end: node.end,
          buildGate: constant(result(factory('buildGate'))) ?? 'unresolved',
          fields: declaredFields(shape), permissionFields: declaredFields(permissions),
          permissionModesDeclared: !!factory('permissionModes'),
          unresolvedShapeComposition: shape?.type === 'ObjectExpression' ? shape.properties.filter(property=>key(property)===null).map(composition) : null });
      }

      if (['$schema', 'apiKeyHelper', 'permissions', 'env'].every(name => keys.includes(name))) {
        schemas.push({ start: node.start, end: node.end,
          fields: node.properties.filter(property => key(property) !== null).map(property => ({
            name: key(property), start: property.start, end: property.end, factoryExpression: property.value.type,
          })),
          composition: node.properties.filter(property => key(property) === null).map(composition),
          nested: describeNestedSettings(ast, node, constructors),
          unresolvedComposition: node.properties.filter(property => key(property) === null).map(composition)
            .filter(item => item.resolution !== 'inert-false-spread'),
        });
      }
    }
    if (node.type === 'ArrayExpression' && node.elements.length >= 5) {
      const entries = node.elements.map(element => {
        if (element?.type !== 'ObjectExpression') return null;
        const path = element.properties.find(property => key(property) === 'path')?.value;
        const restrictiveNode = element.properties.find(property => key(property) === 'restrictive')?.value;
        const restrictive = constant(restrictiveNode);
        if (path?.type !== 'ArrayExpression' || !path.elements.every(item => item?.type === 'Literal' && typeof item.value === 'string')
          || !restrictiveNode) return null;
        return { path: path.elements.map(item => item.value),
          ...(restrictive === undefined ? { unresolvedRestrictive: { kind: restrictiveNode.type, start: restrictiveNode.start, end: restrictiveNode.end } } : { restrictive }),
          normalizeDeclared: element.properties.some(property => key(property) === 'normalize'), start: element.start };
      });
      if (entries.every(Boolean)) policyTables.push({ start: node.start, entries });
    }
  });
  return { schemas, policyTables, featureContributions,
    qualification: 'Static core setting field factories and restrictive policy table declarations. Feature composition, nested field types, precedence, gates and runtime effects remain unverified.' };
}

export async function catalogSettingsSchema(extractionRun, output) {
  const extraction = await readCompleteRun(extractionRun, 'extract');
  const inventoryBytes = await readFile(join(extractionRun, 'inventory.json'));
  if (hash(inventoryBytes) !== extraction.inventorySha256) throw new Error('Extraction inventory changed');
  const run = await createRun(output, 'settings-schema', { extractionRun,
    targetSha256: extraction.inputs.targetSha256,
    scannerSha256: hash(await readFile(new URL(import.meta.url))), nestedScannerSha256: hash(await readFile(new URL('./nested-settings-schema.mjs', import.meta.url))), parser: 'acorn@8.15.0' });
  try {
    const modules = [];
    const inventory = JSON.parse(inventoryBytes);
    const constructorCache = new Map();
    for (const file of inventory) {
      if (file.loader !== 'js') continue;
      if (!['latin1', 'utf8', 'utf-8'].includes(file.encoding)) throw new Error('Unsupported source encoding');
      const bytes = await readFile(join(extractionRun, 'extracted', file.path));
      if (hash(bytes) !== file.sha256) throw new Error(`Source changed: ${file.path}`);
      const source = bytes.toString(file.encoding);
      const constructors = {};
      // Only core settings need nested expansion; their direct Zod import provides verified tags.
      if (source.includes('$schema:') && source.includes('apiKeyHelper:') && source.includes('permissions:')) {
        const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module' });
        for (const node of ast.body) if (node.type === 'ImportDeclaration' && node.source.value.startsWith('/$bunfs/root/')) {
          const path = 'files/' + node.source.value.slice('/$bunfs/root/'.length);
          const dependency = inventory.find(item => item.path === path && item.loader === 'js');
          if (!dependency) continue;
          if (!constructorCache.has(path)) {
            const data = await readFile(join(extractionRun, 'extracted', path));
            if (hash(data) !== dependency.sha256) throw new Error(`Source changed: ${path}`);
            const text = data.toString(dependency.encoding);
            constructorCache.set(path, text.includes('$ZodType') ? inferSchemaConstructorExports(text) : {});
          }
          const exported = constructorCache.get(path);
          for (const binding of node.specifiers) if (exported[binding.imported?.name]) constructors[binding.local.name] = { ...exported[binding.imported.name], module: path, sha256: dependency.sha256 };
        }
        // This native deferred-optional builder returns an explicit lazy schema tag.
        for (const [name, description] of Object.entries(inferSchemaConstructorExports(source, { locals: true }))) constructors[name] ??= description;
      }
      const findings = inspectSettingsSchema(source, { constructors });
      if (findings.schemas.length || findings.policyTables.length || findings.featureContributions.length) modules.push({ path: file.path, sha256: file.sha256, encoding: file.encoding, constructorBindings: constructors, ...findings });
    }
    const result = JSON.stringify({ modules }, null, 2) + '\n';
    await writeFile(join(run.directory, 'settings-schema.json'), result);
    await run.finish({ status: 'complete', outputSha256: hash(Buffer.from(result)), modules: modules.length });
    return { directory: run.directory, status: 'complete', modules: modules.length };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
