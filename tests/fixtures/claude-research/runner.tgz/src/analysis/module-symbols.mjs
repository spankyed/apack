import { parse } from 'acorn';
function walk(node, fn) {
  if (!node?.type) return;
  fn(node);
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) { for (const child of value) walk(child, fn); }
    else if (value?.type) walk(value, fn);
  }
}
function boundNames(pattern, names) {
  if (!pattern) return;
  if (pattern.type === 'Identifier') names.add(pattern.name);
  else if (pattern.type === 'RestElement') boundNames(pattern.argument, names);
  else if (pattern.type === 'AssignmentPattern') boundNames(pattern.left, names);
  else if (pattern.type === 'ArrayPattern') for (const element of pattern.elements) boundNames(element, names);
  else if (pattern.type === 'ObjectPattern') for (const property of pattern.properties) boundNames(property.value ?? property.argument, names);
}
export function inspectModuleSymbols(source) {
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module' });
  const bindings = Object.create(null), exports = Object.create(null), shadowRanges = [], assigned = new Set(), starExports = [];
  for (const statement of ast.body) {
    if (statement.type === 'ExportAllDeclaration') {
      if (!statement.exported) starExports.push(statement.source.value);
      else exports[statement.exported.name ?? statement.exported.value] = `namespace:${statement.source.value}`;
    }
    if (statement.type === 'ExportNamedDeclaration' && statement.declaration?.id) {
      exports[statement.declaration.id.name] = statement.declaration.id.name;
    }
    if (statement.type === 'ImportDeclaration') for (const item of statement.specifiers) {
      if (item.type === 'ImportSpecifier') bindings[item.local.name] = { kind: 'import', source: statement.source.value,
        imported: item.imported.name ?? item.imported.value };
    }
    const declaration = statement.type === 'ExportNamedDeclaration' ? statement.declaration : statement;
    if (declaration?.type === 'VariableDeclaration') for (const item of declaration.declarations) {
      if (statement.type === 'ExportNamedDeclaration') {
        const names = new Set();
        boundNames(item.id, names);
        for (const name of names) exports[name] = name;
      }
      if (item.id.type !== 'Identifier') continue;
      if (item.init?.type === 'Literal' && typeof item.init.value === 'string') bindings[item.id.name] = { kind: 'literal', value: item.init.value };
      else if (item.init?.type === 'Identifier') bindings[item.id.name] = { kind: 'alias', local: item.init.name };
      if (statement.type === 'ExportNamedDeclaration') exports[item.id.name] = item.id.name;
    }
    if (statement.type === 'ExportNamedDeclaration') for (const item of statement.specifiers) {
      if (statement.source) bindings[`reexport:${item.exported.name}`] = { kind: 'import', source: statement.source.value, imported: item.local.name };
      exports[item.exported.name] = statement.source ? `reexport:${item.exported.name}` : item.local.name;
    }
  }
  walk(ast, node => {
    if (node.type === 'AssignmentExpression') boundNames(node.left, assigned);
    if ((node.type === 'ForOfStatement' || node.type === 'ForInStatement') && node.left.type !== 'VariableDeclaration') boundNames(node.left, assigned);
    const loopDeclaration = node.type === 'ForStatement' ? node.init : ['ForOfStatement','ForInStatement'].includes(node.type) ? node.left : null;
    if (loopDeclaration?.type === 'VariableDeclaration' && loopDeclaration.kind === 'var') {
      for (const declaration of loopDeclaration.declarations) boundNames(declaration.id, assigned);
    }
    if (node.type === 'UpdateExpression' && node.argument.type === 'Identifier') assigned.add(node.argument.name);
    if (['FunctionExpression', 'FunctionDeclaration', 'ArrowFunctionExpression', 'CatchClause', 'BlockStatement', 'StaticBlock', 'ClassExpression', 'ForStatement', 'ForOfStatement', 'ForInStatement', 'SwitchStatement'].includes(node.type)) {
      const names = new Set();
      if (node.type === 'FunctionExpression' || node.type === 'ClassExpression') boundNames(node.id, names);
      for (const parameter of node.params ?? [node.param]) boundNames(parameter, names);
      const body = ['ForStatement','ForOfStatement','ForInStatement','SwitchStatement'].includes(node.type) ? node : Array.isArray(node.body) ? { type: 'SyntheticBody', statements: node.body } : node.body;
      walk(body, child => {
        if (child.type === 'VariableDeclarator') boundNames(child.id, names);
        if (child.type === 'FunctionDeclaration' || child.type === 'ClassDeclaration') boundNames(child.id, names);
      });
      shadowRanges.push({ start: node.start, end: node.end, names: [...names] });
    }
  });
  for (const name of assigned) delete bindings[name];
  return { bindings, exports, shadowRanges, starExports };
}

function targetPath(source) {
  return source.startsWith('/$bunfs/root/') ? `files/${source.slice('/$bunfs/root/'.length)}` : null;
}

// Follow export bindings, not just equal string values: distinct origins are ambiguous.
function resolveExport(modules, path, name, seen) {
  const key = `export:${path}:${name}`;
  if (seen.has(key)) return null;
  const next = new Set(seen).add(key), module = modules.get(path);
  if (!module) return null;
  if (Object.hasOwn(module.exports, name)) return resolveLiteralSymbol(modules, path, module.exports[name], next) ?? { unresolved: true };
  if (name === 'default') return null;
  let selected = null;
  for (const source of module.starExports ?? []) {
    const target = targetPath(source);
    if (!target || !modules.get(target)) return { unresolved: true };
    const result = resolveExport(modules, target, name, next);
    if (!result) continue;
    if (result.unresolved) return result;
    if (selected && selected.chain.at(-1) !== result.chain.at(-1)) return { unresolved: true };
    selected ??= result;
  }
  return selected;
}

export function resolveLiteralSymbol(modules, path, symbol, seen = new Set()) {
  const key = `${path}:${symbol}`;
  if (seen.has(key)) return null;
  const next = new Set(seen).add(key);
  const module = modules.get(path), binding = module?.bindings[symbol];
  if (!binding) return null;
  if (binding.kind === 'literal') return { value: binding.value, chain: [key] };
  let result;
  if (binding.kind === 'alias') result = resolveLiteralSymbol(modules, path, binding.local, next);
  else {
    const target = targetPath(binding.source);
    if (target) result = resolveExport(modules, target, binding.imported, next);
  }
  return result && !result.unresolved ? { value: result.value, chain: [key, ...result.chain] } : null;
}
