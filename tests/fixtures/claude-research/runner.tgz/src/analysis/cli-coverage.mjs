import ts from 'typescript';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createRun, hash, readCompleteRun } from '../artifacts/runs.mjs';

export function inspectCliCoverage(help, source) {
  const optionText = help.split(/^Options:\s*$/m)[1]?.split(/^Commands:\s*$/m)[0];
  if (!optionText) throw new Error('Expected root help with an Options section');
  const options = optionText.split('\n').filter(line => /^ {2}--?\w/.test(line)).map(line => {
    const specification = line.trim().split(/\s{2,}/)[0];
    return { specification, flags: specification.match(/--[A-Za-z][\w-]*/g) ?? [] };
  }).filter(option => option.flags.length);
  const ast = ts.createSourceFile('apack-args.ts', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  if (ast.parseDiagnostics.length) throw new Error(ts.flattenDiagnosticMessageText(ast.parseDiagnostics[0].messageText, '\n'));
  const references = [];
  function optionFields(node, result = new Set()) {
    if (ts.isPropertyAccessExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'opts') result.add(node.name.text);
    ts.forEachChild(node, child => { optionFields(child, result); });
    return [...result].sort();
  }
  function walk(node, condition) {
    if (ts.isStringLiteral(node) && /^--[\w-]+$/.test(node.text)) {
      const start = node.getStart(ast);
      references.push({ flag: node.text, fields: condition ? optionFields(condition) : [],
        line: ast.getLineAndCharacterOfPosition(start).line + 1, start });
    }
    if (ts.isIfStatement(node)) {
      walk(node.expression, condition);
      walk(node.thenStatement, node.expression);
      if (node.elseStatement) walk(node.elseStatement, node.expression);
      return;
    }
    ts.forEachChild(node, child => { walk(child, condition); });
  }
  walk(ast);
  return { options: options.map(option => ({ ...option,
    appReferences: references.filter(reference => option.flags.includes(reference.flag)) })),
    appFlagsAbsentFromHelp: references.filter(reference => !options.some(option => option.flags.includes(reference.flag))),
    qualification: 'Root help plus AST flag literals/nearby option conditions only. Mapping is not runtime behavior or UI exposure. Hidden registrations and other entry points remain in scope.' };
}

export async function compareCliCoverage(helpRun, appArgs, output) {
  const parent = await readCompleteRun(helpRun, 'probe');
  const help = await readFile(join(helpRun, 'stdout.bin'));
  const source = await readFile(appArgs);
  const run = await createRun(output, 'cli-coverage', { helpRun, parentRunId: parent.id,
    targetSha256: parent.inputs.targetSha256, helpSha256: hash(help), appArgs,
    appSourceSha256: hash(source), scannerSha256: hash(await readFile(new URL(import.meta.url))), parser: `typescript@${ts.version}` });
  try {
    const result = inspectCliCoverage(help.toString(), source.toString());
    const mapped = result.options.filter(option => option.appReferences.length).length;
    await writeFile(join(run.directory, 'coverage.json'), JSON.stringify(result, null, 2) + '\n');
    await run.finish({ status: 'complete', options: result.options.length, mapped,
      unmapped: result.options.length - mapped, appFlagsAbsentFromHelp: new Set(result.appFlagsAbsentFromHelp.map(reference => reference.flag)).size,
      appFlagReferencesAbsentFromHelp: result.appFlagsAbsentFromHelp.length });
    return { directory: run.directory, status: 'complete', options: result.options.length, mapped,
      unmapped: result.options.length - mapped, appFlagsAbsentFromHelp: new Set(result.appFlagsAbsentFromHelp.map(reference => reference.flag)).size,
      appFlagReferencesAbsentFromHelp: result.appFlagsAbsentFromHelp.length };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
