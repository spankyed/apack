import { version } from 'acorn';
import { readFile } from 'node:fs/promises';
import { hash } from '../artifacts/runs.mjs';

/** Identify the installed parser and analysis code, not a hardcoded version label. */
export async function analysisProvenance(scannerUrl) {
  const [parser, lock, scanner, provenance] = await Promise.all([
    readFile(new URL(import.meta.resolve('acorn'))),
    readFile(new URL('../../package-lock.json', import.meta.url)),
    readFile(scannerUrl),
    readFile(new URL(import.meta.url)),
  ]);
  return { parser: `acorn@${version}`, parserSha256: hash(parser), lockSha256: hash(lock),
    scannerSha256: hash(scanner), provenanceSha256: hash(provenance) };
}
