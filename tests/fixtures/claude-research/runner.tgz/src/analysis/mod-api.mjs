import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {hash,readCompleteRun,createRun} from '../artifacts/runs.mjs';
import {analysisProvenance} from './provenance.mjs';
const key=p=>p.type==='Property'&&!p.computed?p.key.name??p.key.value:null;
function walk(node,visit){if(!node?.type)return;visit(node);for(const value of Object.values(node)){if(Array.isArray(value)){for(const child of value)walk(child,visit)}else if(value?.type)walk(value,visit)}}
const strings=node=>node?.type==='ArrayExpression'?node.elements.filter(e=>e?.type==='Literal'&&typeof e.value==='string').map(e=>e.value):[];
const has=(values,required)=>required.every(value=>values.includes(value));

/** Public adapter candidates are distinct from host dispatch operations. No wrapper is executed. */
function publicAdapterCandidates(ast, range) {
 const bindings=new Map(),roots=[];
 for(const statement of ast.body){
  const declaration=statement.type==='ExportNamedDeclaration'?statement.declaration:statement;
  if(declaration?.type==='FunctionDeclaration'&&declaration.id)bindings.set(declaration.id.name,declaration);
  if(declaration?.type==='VariableDeclaration')for(const item of declaration.declarations)if(item.id.type==='Identifier')bindings.set(item.id.name,item.init);
 }
 walk(ast,node=>{
  if(node.type!=='ObjectExpression'||!has(node.properties.map(key),['ui','model','session','prompt','tool','fs','process','env']))return;
  const namespaces=[];
  for(const property of node.properties){
   const name=key(property);
   if(name===null){namespaces.push({name:null,...range(property),unresolved:'computed-or-spread-namespace'});continue;}
   const value=property.value;
   // Recognize the observed namespace wrapper(builder(...)) shape only.
   const builder=value?.type==='CallExpression'&&value.arguments.length===1?value.arguments[0]:null;
   const symbol=builder?.type==='CallExpression'&&builder.callee.type==='Identifier'?builder.callee.name:null;
   const definition=symbol?bindings.get(symbol):null;
   let expression;
   if(['ArrowFunctionExpression','FunctionExpression','FunctionDeclaration'].includes(definition?.type)){
    if(definition.body.type!=='BlockStatement')expression=definition.body;
    else {
     const returns=definition.body.body.filter(statement=>statement.type==='ReturnStatement');
     if(returns.length===1)expression=returns[0].argument;
    }
   }
   const wrapper=expression?.type==='CallExpression'&&expression.arguments.length===1?expression.callee.type:null;
   const object=expression?.type==='ObjectExpression'?expression:wrapper?expression.arguments[0]:null;
   if(object?.type!=='ObjectExpression'){
    namespaces.push({name,symbol,...range(property),methods:[],unresolved:'unsupported-or-imported-builder'});continue;
   }
   namespaces.push({name,symbol,...range(property),builder:range(definition),returnWrapper:wrapper,
    methods:object.properties.filter(p=>key(p)!==null).map(p=>({name:key(p),implementation:p.value.type,...range(p)})),
    unresolvedProperties:object.properties.filter(p=>key(p)===null).map(p=>({kind:p.type,...range(p)})),
   });
  }
  roots.push({...range(node),namespaces});
 });
 return roots;
}

export function inspectModPublicAdapterSource(source,path='fixture.js',encoding='utf8'){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'});
 const range=node=>({module:path,byteStart:Buffer.byteLength(source.slice(0,node.start),encoding),byteEnd:Buffer.byteLength(source.slice(0,node.end),encoding)});
 return publicAdapterCandidates(ast,range);
}

/** Structural declarations only. Never executes recovered code or arbitrary mapping functions. */
export function inspectModApiModules(inputs){
 const modules=new Map(),catalogs=[],registries=[],dispatchers=[],publicAdapters=[];
 for(const input of inputs){
  const {path,source,encoding='utf8'}=input;
  const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'});
  const range=node=>({module:path,byteStart:Buffer.byteLength(source.slice(0,node.start),encoding),byteEnd:Buffer.byteLength(source.slice(0,node.end),encoding)});
  publicAdapters.push(...publicAdapterCandidates(ast,range));
  const bindings=new Map(),exports=new Map();
  const save=(name,node)=>{
   if(!node)return;
   if(node.type==='Identifier'||node.type==='ArrayExpression'||(node.type==='CallExpression'&&node.callee.type==='MemberExpression'&&['map','freeze'].includes(node.callee.property.name)))bindings.set(name,{node,range});
   const names=strings(node);
   if(has(names,['model.complete','session.identity','env.set']))catalogs.push({symbol:name,...range(node)});
   if(has(names,['plugin.register','engine.create','turn.complete']))registries.push({symbol:name,...range(node)});
  };
  for(const statement of ast.body){
   if(statement.type==='ImportDeclaration')for(const specifier of statement.specifiers)if(specifier.type==='ImportSpecifier')bindings.set(specifier.local.name,{import:statement.source.value,symbol:specifier.imported.name??specifier.imported.value});
   const declaration=statement.type==='ExportNamedDeclaration'?statement.declaration:statement;
   if(declaration?.type==='VariableDeclaration')for(const item of declaration.declarations)if(item.id.type==='Identifier'){save(item.id.name,item.init);if(statement.type==='ExportNamedDeclaration')exports.set(item.id.name,item.id.name)}
   if(statement.type==='ExportNamedDeclaration')for(const specifier of statement.specifiers){const name=specifier.exported.name??specifier.exported.value;if(statement.source){bindings.set(`export:${name}`,{import:statement.source.value,symbol:specifier.local.name??specifier.local.value});exports.set(name,`export:${name}`)}else exports.set(name,specifier.local.name??specifier.local.value)}
  }
  walk(ast,node=>{
   if(node.type!=='ObjectExpression')return;
   const names=node.properties.map(key);
   const ordinary=has(names,['model.complete','session.identity','settings.read','env.set']);
   const streaming=names.length===1&&names[0]==='process.spawn'&&node.properties[0].value.type==='ObjectExpression'&&node.properties[0].value.properties.some(p=>key(p)==='stream');
   if(!ordinary&&!streaming)return;
   dispatchers.push({...range(node),kind:streaming?'streaming':'ordinary',unresolvedProperties:node.properties.filter(p=>key(p)===null).map(p=>({kind:p.type,...range(p)})),operations:node.properties.filter(p=>key(p)!==null).map(p=>({name:key(p),...range(p),implementation:p.value.type,...(p.value.type==='ObjectExpression'?{facets:p.value.properties.map(key).filter(Boolean),unresolvedFacets:p.value.properties.filter(v=>key(v)===null).length}:{facets:null})}))});
  });
  modules.set(path,{bindings,exports});
 }
 function resolve(path,symbol,seen=new Set()){
  const identity=`${path}:${symbol}`;if(seen.has(identity))return{entries:[],unresolved:[{reason:'cycle',identity}]};
  const nested=new Set(seen).add(identity),binding=modules.get(path)?.bindings.get(symbol);
  if(!binding)return{entries:[],unresolved:[{reason:'missing-binding',identity}]};
  if(binding.import){const target=binding.import.startsWith('/$bunfs/root/')?`files/${binding.import.slice('/$bunfs/root/'.length)}`:binding.import;const exported=modules.get(target)?.exports.get(binding.symbol);return exported?resolve(target,exported,nested):{entries:[],unresolved:[{reason:'missing-import',identity,target,symbol:binding.symbol}]}}
  const {node,range}=binding;
  if(node.type==='Identifier')return resolve(path,node.name,nested);
  if(node.type==='ArrayExpression'){
   const entries=[],unresolved=[];
   for(const element of node.elements){
    if(element?.type==='Literal'&&typeof element.value==='string')entries.push({name:element.value,...range(element)});
    else if(element?.type==='SpreadElement'&&element.argument.type==='Identifier'){const part=resolve(path,element.argument.name,nested);entries.push(...part.entries);unresolved.push(...part.unresolved)}
    else unresolved.push({reason:'unsupported-array-element',kind:element?.type??'hole',...(element?range(element):{})});
   }
   return{entries,unresolved};
  }
  if(node.type==='CallExpression'&&node.callee.type==='MemberExpression'&&!node.callee.computed){
   if(node.callee.object.name==='Object'&&node.callee.property.name==='freeze'&&node.arguments.length===1&&node.arguments[0].type==='Identifier')return resolve(path,node.arguments[0].name,nested);
   const fn=node.arguments[0],body=fn?.body;
   if(node.callee.property.name==='map'&&node.callee.object.type==='Identifier'&&node.arguments.length===1&&fn.type==='ArrowFunctionExpression'&&fn.params.length===1&&fn.params[0].type==='Identifier'&&body?.type==='TemplateLiteral'&&body.expressions.length===1&&body.expressions[0].type==='Identifier'&&body.expressions[0].name===fn.params[0].name){
    const prefix=body.quasis[0].value.cooked,suffix=body.quasis[1].value.cooked;
    if(typeof prefix==='string'&&typeof suffix==='string'){const part=resolve(path,node.callee.object.name,nested);return{entries:part.entries.map(entry=>({...entry,name:prefix+entry.name+suffix,mapping:range(node)})),unresolved:part.unresolved}}
   }
  }
  return{entries:[],unresolved:[{reason:'unsupported-expression',kind:node.type,...range(node)}]};
 }
 const expandedCatalogs=catalogs.map(value=>({...value,...resolve(value.module,value.symbol)}));
 const expandedRegistries=registries.map(value=>({...value,...resolve(value.module,value.symbol)}));
 const operations=dispatchers.flatMap(value=>value.operations.map(op=>({...op,dispatcher:value.kind})));
 const catalogNames=new Set(expandedCatalogs.flatMap(value=>value.entries.map(entry=>entry.name)));
 const operationNames=new Set(operations.map(value=>value.name));
 const complete=expandedCatalogs.length===1&&expandedRegistries.length===1&&dispatchers.filter(d=>d.kind==='ordinary').length===1&&dispatchers.filter(d=>d.kind==='streaming').length===1&&[...expandedCatalogs,...expandedRegistries].every(value=>value.unresolved.length===0)&&dispatchers.every(value=>value.unresolvedProperties.length===0);
 return{complete,publicAdapters,publicAdapterQualification:'Selected structural namespace-wrapper and local builder return-object candidates. Wrapped properties are not proof of callable methods, wrapper purity, public availability, dynamic interfaces or full SDK completeness. Unsupported builders and computed/spread properties remain explicit.',catalogs:expandedCatalogs,registries:expandedRegistries,dispatchers,catalogWithoutDispatcher:[...catalogNames].filter(name=>!operationNames.has(name)),dispatcherOutsideBaseCatalog:[...operationNames].filter(name=>!catalogNames.has(name)),qualification:'Static declared operation/event registries and literal ordinary/streaming dispatch roots. Not API availability, full argument schemas, custom interface names, all registration paths or runtime verification.'};
}

export async function catalogModApi(extractionRun,output){
 const extraction=await readCompleteRun(extractionRun,'extract');const inventoryBytes=await readFile(join(extractionRun,'inventory.json'));
 if(hash(inventoryBytes)!==extraction.inventorySha256)throw new Error('Extraction inventory changed');
 const run=await createRun(output,'mod-api',{extractionRun,parentRunId:extraction.id,targetSha256:extraction.inputs.targetSha256,...await analysisProvenance(new URL(import.meta.url))});
 try{
  const inputs=[];
  // Keep source/hash provenance for every parsed JavaScript-loader module; assets are excluded by loader.
  for(const file of JSON.parse(inventoryBytes)){
   if(file.loader!=='js')continue;
   if(!['latin1','utf8','utf-8'].includes(file.encoding))throw new Error('Unsupported source encoding');
   const bytes=await readFile(join(extractionRun,'extracted',file.path));if(hash(bytes)!==file.sha256)throw new Error(`Source changed: ${file.path}`);
   inputs.push({path:file.path,sha256:file.sha256,encoding:file.encoding,source:bytes.toString(file.encoding)});
  }
  const findings=inspectModApiModules(inputs);
  const result=JSON.stringify({...findings,modules:inputs.map(({path,sha256,encoding})=>({path,sha256,encoding}))},null,2)+'\n';
  await writeFile(join(run.directory,'mod-api.json'),result);
  await run.finish({status:findings.complete?'complete':'failed',outputSha256:hash(Buffer.from(result)),parsedModules:inputs.length,...(!findings.complete?{reason:'unresolved-mod-api-roots'}:{})});
  return{directory:run.directory,status:findings.complete?'complete':'failed',baseOperations:findings.catalogs.flatMap(value=>value.entries).length,registeredEvents:findings.registries.flatMap(value=>value.entries).length,dispatchOperations:findings.dispatchers.flatMap(value=>value.operations).length};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
