import {parse} from 'acorn';
import ts from 'typescript';
import zlib from 'node:zlib';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join,posix} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
import {analysisProvenance} from './provenance.mjs';

export function codeAssetFormat(path) {
  const match=path.match(/\.([cm]?js|jsx|tsx?|html)(?:-[^/]+\.txt)?(?:\.zst)?$/);
  if(!match)return null;
  if(match[1]==='html')return 'html';
  if(['ts','tsx','jsx'].includes(match[1]))return match[1];
  return 'javascript';
}

// Check framing because Node 23's decoder can accept a truncated prefix as empty output.
// RFC 8878 sections 3.1.1.1 and 3.1.1.2; compressed payload validation remains libzstd's job.
export function verifyZstdFrames(bytes) {
  let at=0;
  function take(size){if(at+size>bytes.length)throw new Error('Truncated Zstandard frame');const start=at;at+=size;return start;}
  do {
    const magic=take(4);
    if(bytes.readUInt32LE(magic)!==0xfd2fb528)throw new Error('Unsupported Zstandard frame magic');
    const descriptor=bytes[take(1)];
    if(descriptor&8)throw new Error('Reserved Zstandard frame bit');
    const single=Boolean(descriptor&32),sizeFlag=descriptor>>>6;
    take((single?0:1)+[0,1,2,4][descriptor&3]+(sizeFlag===0?(single?1:0):[0,2,4,8][sizeFlag]));
    let last=false;
    do {
      const header=bytes.readUIntLE(take(3),3),type=(header>>>1)&3;
      if(type===3)throw new Error('Reserved Zstandard block type');
      last=Boolean(header&1);take(type===1?1:header>>>3);
    } while(!last);
    if(descriptor&4)take(4);
  } while(at<bytes.length);
}

/** Bounded data decoding only. Inferred UTF-16 is reported, never silently treated as UTF-8. */
export function decodeCodeAsset(bytes,declaredEncoding,maxOutputLength=16*1024*1024) {
  let decoded=bytes,compression='none';
  if(bytes.subarray(0,4).equals(Buffer.from([40,181,47,253]))) {
    if(typeof zlib.zstdDecompressSync!=='function')return {status:'not-parsed-compression',qualification:'This Node runtime has no Zstandard decoder.'};
    verifyZstdFrames(bytes);
    decoded=zlib.zstdDecompressSync(bytes,{maxOutputLength,params:{[zlib.constants.ZSTD_d_windowLogMax]:24}});compression='zstd';
  }
  if(decoded.length>maxOutputLength)throw new Error('Decoded asset exceeds size limit');
  let encoding='utf8',inferred=false;
  const probe=decoded.subarray(0,128);
  const pairs=Math.floor(probe.length/2);
  const oddZeros=Array.from({length:pairs},(_,i)=>probe[i*2+1]===0).filter(Boolean).length;
  if(decoded.subarray(0,2).equals(Buffer.from([255,254])) || (pairs>=8&&decoded.length%2===0&&oddZeros/pairs>=0.8)) {
    encoding='utf16le';inferred=true;
  }
  let source;
  try {source=new TextDecoder(encoding==='utf16le'?'utf-16le':encoding,{fatal:true,ignoreBOM:true}).decode(decoded);}
  catch {return {status:'not-parsed-encoding',compression,qualification:'Decoded bytes are not valid supported Unicode text; declared extraction encoding is not an assumed source encoding.'};}
  return {source,decoded,compression,sourceEncoding:encoding,encodingInferred:inferred,declaredEncoding,decodedSha256:hash(decoded),decodedBytes:decoded.length};
}

/** Source syntax only; never import, transform or execute an extracted asset. */
export function inspectCodeAsset(source,path,encoding='utf8') {
  const format=codeAssetFormat(path);
  if(!format)throw new Error('Not a selected code-shaped asset');
  const exports=[],imports=[],ambientModules=[];
  const range=node=>({byteStart:Buffer.byteLength(source.slice(0,node.start),encoding),byteEnd:Buffer.byteLength(source.slice(0,node.end),encoding)});
  if(format==='html')return {format,status:'not-parsed-html',exports,imports,qualification:'HTML template recorded, inline scripts and generated substitutions not parsed.'};
  try {
    if(format==='javascript') {
      const ast=parse(source,{ecmaVersion:'latest',sourceType:'module',allowHashBang:true});
      for(const node of ast.body) {
        if(node.type==='ImportDeclaration')imports.push({source:node.source.value,...range(node)});
        if(node.type==='ExportAllDeclaration')exports.push({name:node.exported?.name??node.exported?.value??'*',source:node.source.value,...range(node)});
        if(node.type==='ExportDefaultDeclaration')exports.push({name:'default',...range(node)});
        if(node.type!=='ExportNamedDeclaration')continue;
        if(node.declaration?.id)exports.push({name:node.declaration.id.name,...range(node.declaration)});
        for(const declaration of node.declaration?.declarations??[]) {
          if(declaration.id.type==='Identifier')exports.push({name:declaration.id.name,...range(declaration)});
          else exports.push({name:null,unresolved:'destructured-export',...range(declaration)});
        }
        for(const specifier of node.specifiers)exports.push({name:specifier.exported.name??specifier.exported.value,...node.source&&{source:node.source.value},...range(specifier)});
      }
    } else {
      const kind=format==='tsx'?ts.ScriptKind.TSX:format==='jsx'?ts.ScriptKind.JSX:ts.ScriptKind.TS;
      const ast=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true,kind);
      if(ast.parseDiagnostics.length)return {format,status:'syntax-unresolved',exports,imports,diagnostics:ast.parseDiagnostics.map(d=>({code:d.code,start:d.start,length:d.length})),qualification:'Unresolved source/template syntax; diagnostic text omitted to avoid reproducing asset contents.'};
      const location=node=>range({start:node.getStart(ast),end:node.end});
      for(const node of ast.statements.filter(ts.isModuleDeclaration)) {
        if(!node.body||!ts.isModuleBlock(node.body))continue;
        const declarations=node.body.statements.map(member=>({
          kind:ts.SyntaxKind[member.kind],name:member.name?.text??null,...location(member),
          ...member.members&&{members:member.members.map(item=>({kind:ts.SyntaxKind[item.kind],name:item.name?.text??null,optional:Boolean(item.questionToken),...location(item)}))},
        }));
        ambientModules.push({name:node.name.text,...location(node),declarations,qualification:'Ambient module declaration candidates, including implicit declarations. Not runtime exports, eligibility or complete type resolution.'});
      }
      for(const node of ast.statements) {
        if(ts.isImportDeclaration(node)&&ts.isStringLiteral(node.moduleSpecifier))imports.push({source:node.moduleSpecifier.text,...location(node)});
        if(ts.isExportAssignment(node))exports.push({name:node.isExportEquals?'export=':'default',...location(node)});
        if(ts.isExportDeclaration(node)) {
          const from=ts.isStringLiteral(node.moduleSpecifier??{})?node.moduleSpecifier.text:undefined;
          if(node.exportClause&&ts.isNamedExports(node.exportClause))for(const member of node.exportClause.elements)exports.push({name:member.name.text,...from&&{source:from},...location(member)});
          else exports.push({name:node.exportClause&&ts.isNamespaceExport(node.exportClause)?node.exportClause.name.text:'*',...from&&{source:from},...location(node)});
        }
        const modifiers=ts.canHaveModifiers(node)?ts.getModifiers(node):undefined;
        if(!modifiers?.some(m=>m.kind===ts.SyntaxKind.ExportKeyword))continue;
        const declarations=ts.isVariableStatement(node)?node.declarationList.declarations:[node];
        for(const declaration of declarations)exports.push({name:modifiers.some(m=>m.kind===ts.SyntaxKind.DefaultKeyword)?'default':declaration.name&&ts.isIdentifier(declaration.name)?declaration.name.text:null,kind:ts.SyntaxKind[declaration.kind],...location(declaration)});
      }
    }
    return {format,status:'parsed',exports,imports,ambientModules,qualification:'Static top-level import/export candidates, not execution, effective registration or complete generated-source analysis.'};
  } catch(error) {
    if(!(error instanceof SyntaxError))throw error;
    return {format,status:'syntax-unresolved',exports:[],imports:[],diagnostics:[{start:error.pos}],qualification:'Source/template parse failed; no source execution or silent completeness claim.'};
  }
}

/** Native plugin test-kit container: named modules separated by newline + "//// ". */
export function inspectKitFragments(source,encoding='utf8') {
  const marker='//// ';
  if(!source.startsWith(marker))throw new Error('Missing kit module marker');
  const starts=[0];let at=source.indexOf('\n'+marker);
  while(at!==-1){starts.push(at+1);at=source.indexOf('\n'+marker,at+1);}
  const names=new Set(),fragments=[];
  for(let i=0;i<starts.length;i++) {
    const start=starts[i]+marker.length,end=i+1<starts.length?starts[i+1]-1:source.length;
    const line=source.indexOf('\n',start);
    if(line<start||line>=end)throw new Error('Invalid kit module header');
    const path=source.slice(start,line);
    if(!/^[A-Za-z0-9_./-]+\.js$/.test(path)||path.startsWith('/')||path.split('/').includes('..')||names.has(path))throw new Error('Invalid or duplicate kit module path');
    names.add(path);
    fragments.push({path,byteStart:Buffer.byteLength(source.slice(0,line+1),encoding),byteEnd:Buffer.byteLength(source.slice(0,end),encoding),...inspectCodeAsset(source.slice(line+1,end),path,encoding)});
  }
  return fragments;
}

/** Follow the native kit resolver's literal static imports/reexports, without linking modules. */
export function inspectKitImports(fragments) {
  const names=new Set(fragments.map(f=>f.path)),edges=[],unresolved=[];
  const prefix='@/src/plugins/functionHooks/plugin-test/testing';
  for(const fragment of fragments)for(const source of [...fragment.imports.map(i=>i.source),...fragment.exports.flatMap(e=>e.source?[e.source]:[])]) {
    const internal=source===prefix||source.startsWith(prefix+'/'),relative=source==='.'||source.startsWith('./');
    if(!internal&&!relative){unresolved.push({module:fragment.path,source,reason:'outside-native-kit-resolver'});continue;}
    let path=internal?source.slice(prefix.length+1):posix.join(posix.dirname(fragment.path),source);
    path=posix.normalize(path||'.');
    const target=[path,path+'.js',posix.join(path,'index.js')].find(p=>names.has(p));
    if(target)edges.push({module:fragment.path,target,source});else unresolved.push({module:fragment.path,source,reason:'missing-kit-module'});
  }
  const reachable=new Set(),queue=names.has('index.js')?['index.js']:[];
  while(queue.length){const name=queue.pop();if(reachable.has(name))continue;reachable.add(name);queue.push(...edges.filter(e=>e.module===name).map(e=>e.target));}
  return {edges,unresolved,entryPresent:names.has('index.js'),reachableFromIndex:reachable.size,qualification:'Literal static imports and reexports only; no dynamic import, module evaluation or sandbox/admission proof.'};
}

/** Literal source references only: comments, aliases and constructed paths do not count. */
export function inspectAssetReferences(source,assetPaths,path,encoding='utf8') {
  const names=new Set(assetPaths.map(p=>p.replace(/^files\//,'')));
  const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),references=[];
  function visit(node,parent) {
    if(!node||typeof node!=='object')return;
    if(node.type==='Literal'&&typeof node.value==='string'&&node.value.startsWith('/$bunfs/root/')) {
      const name=node.value.slice('/$bunfs/root/'.length);
      if(names.has(name))references.push({asset:'files/'+name,module:path,byteStart:Buffer.byteLength(source.slice(0,node.start),encoding),byteEnd:Buffer.byteLength(source.slice(0,node.end),encoding),binding:parent?.type==='VariableDeclarator'&&parent.id.type==='Identifier'?parent.id.name:null,directCall:parent?.type==='CallExpression'&&parent.arguments.includes(node)&&parent.callee.type==='Identifier'?parent.callee.name:null});
    }
    for(const child of Object.values(node))if(Array.isArray(child))child.forEach(n=>visit(n,node));else if(child&&typeof child==='object')visit(child,node);
  }
  visit(ast);return references;
}

export async function catalogCodeAssets(extractionRun,output) {
  const parent=await readCompleteRun(extractionRun,'extract');
  const inventoryBytes=await readFile(join(extractionRun,'inventory.json'));
  if(hash(inventoryBytes)!==parent.inventorySha256)throw new Error('Extraction inventory changed');
  const inventory=JSON.parse(inventoryBytes),selected=inventory.filter(file=>file.loader!=='js'&&codeAssetFormat(file.path));
  const run=await createRun(output,'code-assets',{extractionRun,parentRunId:parent.id,targetSha256:parent.inputs.targetSha256,...await analysisProvenance(new URL(import.meta.url)),decoder:{node:process.version,zlib:process.versions.zlib,zstd:process.versions.zstd??null,maxOutputLength:16*1024*1024},typescript:ts.version,typescriptSha256:hash(await readFile(new URL(import.meta.resolve('typescript'))))});
  try {
    const assets=[];
    for(const file of selected) {
      const bytes=await readFile(join(extractionRun,'extracted',file.path));
      if(hash(bytes)!==file.sha256)throw new Error('Extracted asset changed: '+file.path);
      const decoded=decodeCodeAsset(bytes,file.encoding);
      const metadata={path:file.path,loader:file.loader,encoding:file.encoding,sha256:file.sha256,bytes:bytes.length};
      if(decoded.source===undefined){assets.push({...metadata,...decoded,exports:[],imports:[]});continue;}
      const {source,decoded:decodedBytes,...decoding}=decoded;
      const decodedPath=join('decoded',file.path);
      await mkdir(join(run.directory,'decoded','files'),{recursive:true});
      await writeFile(join(run.directory,decodedPath),decodedBytes);
      const inspected=inspectCodeAsset(source,file.path,decoded.sourceEncoding);
      if(/^files\/kit-modules\.js-.*\.txt(?:\.zst)?$/.test(file.path)) {
        inspected.fragments=inspectKitFragments(source,decoded.sourceEncoding);
        inspected.kitImports=inspectKitImports(inspected.fragments);
        inspected.status=inspected.fragments.every(f=>f.status==='parsed')?'parsed-fragments':'fragment-syntax-unresolved';
        inspected.qualification='Native named-module container split statically; fragment AST offsets are relative to each body, body byteStart/byteEnd locate it in decoded parent. No module linking or execution.';
      }
      assets.push({...metadata,...decoding,decodedPath,...inspected});
    }
    const references=[];let verifiedJsModules=0,referenceModules=0;
    const assetPaths=selected.map(f=>f.path),names=assetPaths.map(p=>p.replace(/^files\//,''));
    for(const file of inventory.filter(f=>f.loader==='js')) {
      const bytes=await readFile(join(extractionRun,'extracted',file.path));
      if(hash(bytes)!==file.sha256)throw new Error('Extracted JS changed: '+file.path);
      verifiedJsModules++;
      const source=bytes.toString(file.encoding==='latin1'?'latin1':'utf8');
      if(!names.some(name=>source.includes(name)))continue;
      const found=inspectAssetReferences(source,assetPaths,file.path,file.encoding);
      if(found.length)referenceModules++;
      references.push(...found.map(r=>({...r,sourceSha256:file.sha256})));
    }
    for(const asset of assets)asset.literalReferences=references.filter(r=>r.asset===asset.path);
    const result={assets,qualification:'Supplementary filename-selected non-JS-loader assets, including .zst payloads. Original bytes retained; derived bytes and decoding metadata recorded. UTF-16 detection is inferred from BOM or a bounded NUL-byte heuristic, not runtime loader verification. This does not enumerate all embedded code strings, virtual/generated modules, inline HTML scripts or native binaries. Literal references are syntax-checked navigation leads, not transitive loader sinks, dataflow or execution proof. Source roles and loader sinks require separate review; templates are not assumed executable.'};
    const bytes=Buffer.from(JSON.stringify(result,null,2)+'\n');
    await writeFile(join(run.directory,'code-assets.json'),bytes);
    const summary={selected:assets.length,verifiedJsModules,referenceModules,referencedAssets:assets.filter(a=>a.literalReferences.length).length,parsed:assets.filter(a=>a.status==='parsed').length,fragmentedContainers:assets.filter(a=>a.status==='parsed-fragments').length,fragments:assets.reduce((sum,a)=>sum+(a.fragments?.length??0),0),html:assets.filter(a=>a.status==='not-parsed-html').length,unsupportedCompression:assets.filter(a=>a.status==='not-parsed-compression').length,unsupportedEncoding:assets.filter(a=>a.status==='not-parsed-encoding').length,syntaxUnresolved:assets.filter(a=>['syntax-unresolved','fragment-syntax-unresolved'].includes(a.status)).length};
    await run.finish({status:'complete',outputSha256:hash(bytes),...summary});
    return {directory:run.directory,status:'complete',...summary};
  } catch(error) {await run.finish({status:'failed',error:error.message});throw error;}
}
