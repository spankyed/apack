import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../../', import.meta.url));
const catalogPath = 'docs/reference/upgrade-contracts.json';
const versionPattern = /^\d+\.\d+\.\d+$/;
const platformPattern = /^(darwin|linux|win32)-(arm64|x64)$/;
const commitPattern = /^[a-f0-9]{7,40}$/;
const text = value => typeof value === 'string' && value.trim() === value && value.length > 0;
const strings = (value, predicate = text) => Array.isArray(value) && value.every(predicate);
const plainObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const validEnv = env => env === undefined || plainObject(env)
  && Object.entries(env).every(([key, value]) => /^CLAUDE_RESEARCH_[A-Z0-9_]+$/.test(key) && text(value));

function requireValid(condition, message) {
  if (!condition) throw new Error(message);
}

async function validateEvidence(receipt, contract, repository, files) {
  requireValid(plainObject(receipt), 'Invalid evidence for ' + contract.id);
  const { kind, version, platform, path, pointer, heading, productCommit } = receipt;
  const label = contract.id + ' evidence';
  requireValid(['source', 'native', 'actual-app'].includes(kind) && text(version) && versionPattern.test(version)
    && contract.platforms.includes(platform) && text(path) && /^(docs|tests)\/[\w./-]+\.(json|md)$/.test(path)
    && !path.split('/').includes('..'), 'Invalid ' + label);
  requireValid(kind === 'actual-app' ? path.endsWith('.json') && text(productCommit)
    && commitPattern.test(productCommit) : productCommit === undefined,
    'Invalid product commit for ' + label);
  if (!files.has(path)) files.set(path, await readFile(join(repository, path), 'utf8'));
  const content = files.get(path);
  if (path.endsWith('.md')) {
    requireValid(text(heading) && pointer === undefined
      && content.split(/\r?\n/).some(line => /^#{1,6} /.test(line) && line.replace(/^#{1,6} /, '') === heading),
    'Unknown evidence heading: ' + path + ' ' + heading);
    return;
  }

  requireValid(typeof pointer === 'string' && pointer.startsWith('/') && heading === undefined,
    'Expected a JSON pointer for ' + label);
  let entry = JSON.parse(content);
  for (const part of pointer.slice(1).split('/')) {
    const key = part.replaceAll('~1', '/').replaceAll('~0', '~');
    requireValid(entry && Object.hasOwn(entry, key), 'Unknown evidence pointer: ' + path + pointer);
    entry = entry[key];
  }
  if (kind === 'actual-app') {
    requireValid(entry?.productCommit === productCommit, 'Product commit differs from receipt: ' + path + pointer);
  }
}

export async function loadUpgradeContracts(repository = root) {
  const catalog = JSON.parse(await readFile(join(repository, catalogPath), 'utf8'));
  requireValid(catalog.schemaVersion === 1 && Array.isArray(catalog.contracts) && catalog.contracts.length,
    'Expected a nonempty version 1 upgrade contract catalog');
  const ids = new Set();
  const files = new Map();
  for (const contract of catalog.contracts) {
    requireValid(plainObject(contract), 'Invalid contract record');
    const { id, expected, referenceVersion, platforms, signals, checks, evidence } = contract;
    requireValid(text(id) && /^[a-z]+(?:-[a-z]+)*$/.test(id) && !ids.has(id) && text(expected)
      && text(referenceVersion) && versionPattern.test(referenceVersion)
      && strings(platforms, item => text(item) && platformPattern.test(item))
      && platforms.length && new Set(platforms).size === platforms.length, 'Invalid or duplicate contract: ' + id);
    ids.add(id);
    requireValid(strings(signals?.families, item => text(item) && /^[a-z_]+$/.test(item)) && strings(signals?.terms)
      && signals.families.length + signals.terms.length > 0, 'Invalid signals for ' + id);
    requireValid(Array.isArray(checks) && checks.length && checks.every(check =>
      plainObject(check) && platforms.includes(check.platform) && text(check.proves)
      && validEnv(check.env) && strings(check.argv)
      && check.argv.slice(0, 4).join(' ') === 'npm run research --'
      && /^[a-z][a-z-]+$/.test(check.argv[4]) && check.argv.includes('<candidate-executable>')
      && check.argv.includes('<disposable-workspace>')), 'Invalid checks for ' + id);
    requireValid(Array.isArray(evidence) && ['source', 'native', 'actual-app'].every(kind =>
      evidence.some(receipt => receipt?.kind === kind)), 'Missing evidence types for ' + id);
    for (const receipt of evidence) await validateEvidence(receipt, contract, repository, files);
  }
  return catalog.contracts;
}
