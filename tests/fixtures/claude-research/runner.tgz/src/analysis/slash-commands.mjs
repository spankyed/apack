import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
import {analysisProvenance} from './provenance.mjs';
import {inspectModuleSymbols,resolveLiteralSymbol} from './module-symbols.mjs';
const key=node=>node?.computed?null:node?.key?.name??node?.key?.value??null;
function literal(node,depth=0){
 if(depth>8)return {kind:"expression",start:node?.start??null,end:node?.end??null};
 if(node?.type==='Literal')return {kind:'literal',value:node.value};
 if(node?.type==='UnaryExpression'&&node.operator==='!'&&node.argument.type==='Literal')return {kind:'literal',value:!node.argument.value};
 if(node?.type==='ObjectExpression'){const properties=node.properties;if(properties.every(p=>p.type==='Property'&&!p.computed&&p.kind==='init')){const values=properties.map(p=>[key(p),literal(p.value,depth+1)]);if(values.every(([,value])=>value.kind==='literal'||value.kind==='literal-array'||value.kind==='literal-object'))return {kind:'literal-object',value:Object.fromEntries(values.map(([name,value])=>[name,value.value]))};}}
 if(node?.type==='ArrayExpression'&&node.elements.every(item=>item?.type==='Literal'))return {kind:'literal-array',value:node.elements.map(item=>item.value)};
 return {kind:'expression',start:node?.start??null,end:node?.end??null};
}
/** Definition candidates, including lexical factories; never a claim of registration or availability. */
function inspectCommandCandidates(source){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),commands=[];
 function walk(node,containers=[],parent=null){
  if(!node?.type)return;
  if(node.type==='ObjectExpression'){
   const properties=node.properties.filter(p=>p.type==='Property'),type=properties.find(p=>key(p)==='type'),name=properties.find(p=>key(p)==='name');
   const typed=type?.value.type==='Literal'&&['local','local-jsx','prompt'].includes(type.value.value);
   const promptLike=!type&&properties.some(p=>key(p)==='getPromptForCommand')&&properties.some(p=>['userInvocable','whenToUse'].includes(key(p)));
   if(name&&(typed||promptLike)){
    const fields={};for(const p of properties)if(['name','aliases','supportsNonInteractive','isEnabled','isHidden','availability','requires','policyGate','thinClientDispatch','immediate','load','call','getPromptForCommand','userInvocable','whenToUse','disableModelInvocation','allowedTools'].includes(key(p)))fields[key(p)]={...literal(p.value),getter:p.kind==='get'};
    commands.push({start:node.start,end:node.end,type:typed?type.value.value:null,kind:typed?'typed-command':'untyped-prompt-candidate',nameSymbol:name.value.type==='Identifier'?name.value.name:null,
      registrationCall:parent?.type==='CallExpression'&&parent.arguments.includes(node)?{start:parent.start,end:parent.end,callee:parent.callee.type==='Identifier'?parent.callee.name:null}:null,fields,containers,spreadCount:node.properties.filter(p=>p.type==='SpreadElement').length});
   }
  }
  const scope=['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression','VariableDeclarator'].includes(node.type)?[...containers,{kind:node.type,symbol:node.id?.name??null,start:node.start,end:node.end}]:containers;
  for(const value of Object.values(node)){if(Array.isArray(value)){for(const child of value)if(child?.type)walk(child,scope,node)}else if(value?.type)walk(value,scope,node)}
 }walk(ast);return commands;
}
export function inspectSlashCommands(source){return inspectCommandCandidates(source).filter(row=>row.kind==='typed-command')}
export function inspectPromptCommandCandidates(source){return inspectCommandCandidates(source).filter(row=>row.kind==='untyped-prompt-candidate')}
export async function catalogSlashCommands(extraction,output){
 const parent=await readCompleteRun(extraction,'extract'),ib=await readFile(join(extraction,'inventory.json'));if(hash(ib)!==parent.inventorySha256)throw Error('Extraction inventory changed');
 const run=await createRun(output,'slash-commands',{extraction,targetSha256:parent.inputs.targetSha256,inventorySha256:hash(ib),...await analysisProvenance(new URL(import.meta.url)),resolverSha256:hash(await readFile(new URL('./module-symbols.mjs',import.meta.url)))});
 try{
  const modules=[],symbols=new Map(),seenPaths=new Set();let scanned=0;
  for(const file of JSON.parse(ib).filter(f=>f.loader==='js')){
   if(typeof file.path!=='string'||file.path.startsWith('/')||file.path.includes('\\')||file.path.split('/').includes('..')||seenPaths.has(file.path))throw Error('Unsafe or duplicate extracted path');
   seenPaths.add(file.path);
   const bytes=await readFile(join(extraction,'extracted',file.path));if(hash(bytes)!==file.sha256)throw Error('Extracted source changed: '+file.path);
   if(!['latin1','utf8','utf-8'].includes(file.encoding))throw Error('Unsupported source encoding');
   const source=bytes.toString(file.encoding),rows=inspectCommandCandidates(source);symbols.set(file.path,inspectModuleSymbols(source));
   const commands=rows.filter(row=>row.kind==='typed-command'),promptCandidates=rows.filter(row=>row.kind==='untyped-prompt-candidate');
   scanned++;if(rows.length)modules.push({path:file.path,sha256:file.sha256,encoding:file.encoding,commands,promptCandidates});
  }
  for(const module of modules)for(const row of [...module.commands,...module.promptCandidates]){
   const shadowed=row.nameSymbol&&symbols.get(module.path).shadowRanges.some(range=>range.start<row.start&&range.end>row.end&&range.names.includes(row.nameSymbol));
   const resolved=row.nameSymbol&&!shadowed?resolveLiteralSymbol(symbols,module.path,row.nameSymbol):null;
   row.resolvedName=row.fields.name.kind==='literal'?row.fields.name.value:resolved?.value??null;
   row.nameResolution=row.fields.name.kind==='literal'?'literal':shadowed?'local-shadow-unresolved':resolved?'literal-binding-chain':'unresolved';
   if(resolved)row.nameChain=resolved.chain;
  }
  const bytes=Buffer.from(JSON.stringify({modules,qualification:'Separate typed command objects and untyped name/getPromptForCommand objects with userInvocable or whenToUse metadata. Call-site context and conservative literal name chains are navigation evidence, not registration or reachability. Dynamic names, fields, spreads, loader behavior, runtime gates and custom/plugin/MCP command families require separate review. No recovered code executed.'},null,2)+'\n');await writeFile(join(run.directory,'slash-commands.json'),bytes);
  const count=modules.reduce((n,m)=>n+m.commands.length,0),promptCandidates=modules.reduce((n,m)=>n+m.promptCandidates.length,0);await run.finish({status:'complete',outputSha256:hash(bytes),scanned,modules:modules.length,candidates:count,promptCandidates});return{directory:run.directory,status:'complete',scanned,modules:modules.length,candidates:count,promptCandidates};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
