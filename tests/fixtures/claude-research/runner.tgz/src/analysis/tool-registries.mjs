import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {hash,readCompleteRun,createRun} from '../artifacts/runs.mjs';
import {inspectModuleSymbols,resolveLiteralSymbol} from './module-symbols.mjs';
const key=p=>p.type==='Property'&&!p.computed?p.key.name??p.key.value:null;
function walk(node,visit,parent=null){if(!node?.type)return;visit(node,parent);for(const value of Object.values(node)){if(Array.isArray(value)){for(const child of value)walk(child,visit,node)}else if(value?.type)walk(value,visit,node)}}
function requireMember(node) {
 if(node?.type!=='MemberExpression'||node.computed||node.property.type!=='Identifier')return null;
 const call=node.object,callee=call?.callee;
 if(call?.type!=='CallExpression'||call.arguments.length!==1||call.arguments[0].type!=='Literal'
  ||callee?.type!=='MemberExpression'||callee.computed||callee.property.name!=='require'
  ||callee.object.type!=='MetaProperty'||callee.object.meta.name!=='import'||callee.object.property.name!=='meta')return null;
 const source=call.arguments[0].value;
 return typeof source==='string'&&source.startsWith('/$bunfs/root/')?{kind:'import',source,imported:node.property.name}:null;
}
export function inspectToolRegistryModule(source,tools=[]){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),bindings={},initializers={},arrays={},requires={},functions={},assigned=new Set(),registries=[];
 const definitions=new Map(tools.map(tool=>[tool.start,tool]));
 for(const statement of ast.body){
  const declaration=statement.type==='ExportNamedDeclaration'?statement.declaration:statement;
  if(declaration?.type==='FunctionDeclaration')functions[declaration.id.name]=declaration;
  if(declaration?.type==='VariableDeclaration')for(const item of declaration.declarations){
   if(item.id.type!=='Identifier')continue;
   if(item.init)initializers[item.id.name]=item.init;
   if(item.init?.type==='ArrayExpression')arrays[item.id.name]=item.init;
   const required=requireMember(item.init);if(required)requires[item.id.name]=required;
   if(['ArrowFunctionExpression','FunctionExpression'].includes(item.init?.type))functions[item.id.name]=item.init;
   const object=item.init?.type==='ObjectExpression'?item.init:item.init?.type==='CallExpression'&&item.init.arguments.length===1?item.init.arguments[0]:null;
   const tool=definitions.get(object?.start);
   if(tool){
    const aliases=object.properties.find(property=>key(property)==='aliases')?.value;
    bindings[item.id.name]={name:tool.resolvedName,start:tool.start,wrapper:item.init.type==='CallExpression'?item.init.callee.type:null,
     declaredAliases:aliases?.type==='ArrayExpression'?aliases.elements.map(alias=>alias?.type==='Literal'&&typeof alias.value==='string'?{literal:alias.value}:alias?.type==='Identifier'?{symbol:alias.name}:{unresolved:alias?.type??'hole'}):aliases?{unresolved:aliases.type}:[]};
   }
  }
 }
 walk(ast,node=>{
  if(node.type==='AssignmentExpression'&&node.left.type==='Identifier')assigned.add(node.left.name);
  if(node.type==='UpdateExpression'&&node.argument.type==='Identifier')assigned.add(node.argument.name);
  if(node.type==='ObjectExpression'){
   const fields=new Map(node.properties.map(p=>[key(p),p]));
   if(['getAllBaseTools','getTools','assembleToolPool'].every(name=>fields.has(name))){
    const symbols=Object.fromEntries([...fields].filter(([name])=>name).map(([name,p])=>[name,p.value.type==='Identifier'?p.value.name:null]));
    registries.push({start:node.start,symbols});
   }
  }
 });
 for(const name of assigned){delete bindings[name];delete functions[name];delete arrays[name];delete requires[name];delete initializers[name]}
 return{ast,symbols:inspectModuleSymbols(source),bindings,initializers,arrays,requires,functions,registries};
}
export function resolveToolReference(modules,path,symbol,offset,seen=new Set()){
 const id=`${path}:${symbol}`;if(seen.has(id))return null;seen.add(id);
 const module=modules.get(path);if(!module)return null;
 if(offset!==undefined&&module.symbols.shadowRanges.some(range=>range.start<=offset&&range.end>offset&&range.names.includes(symbol)))return null;
 const tool=module.bindings[symbol];if(tool){
  const aliases=Array.isArray(tool.declaredAliases)?tool.declaredAliases.map(alias=>alias.literal?{name:alias.literal}:alias.symbol?resolveLiteralSymbol({get:path=>modules.get(path)?.symbols},path,alias.symbol):null):null;
  return{...tool,aliasNames:aliases?.map(alias=>alias?.name??alias?.value).filter(Boolean)??[],unresolvedAliases:aliases?aliases.filter(alias=>!alias).length:1,path,chain:[id]};
 }
 const binding=module.requires[symbol]??module.symbols.bindings[symbol];let found;
 if(binding?.kind==='alias')found=resolveToolReference(modules,path,binding.local,undefined,seen);
 else if(binding?.kind==='import'&&binding.source.startsWith('/$bunfs/root/')){
  const target=`files/${binding.source.slice('/$bunfs/root/'.length)}`,local=modules.get(target)?.symbols.exports[binding.imported];
  if(local)found=resolveToolReference(modules,target,local,undefined,seen);
 }
 return found?{...found,chain:[id,...found.chain]}:null;
}
function resolveCollection(modules,path,symbol,seen=new Set()) {
 const id=`${path}:${symbol}`;if(seen.has(id))return[];seen.add(id);
 const module=modules.get(path);if(!module)return[];
 const array=module.arrays[symbol];
 if(array)return array.elements.flatMap(node=>resolveExpressionReferences(modules,path,node,new Set(seen)));
 const binding=module.requires[symbol]??module.symbols.bindings[symbol];
 if(binding?.kind==='alias')return resolveCollection(modules,path,binding.local,seen);
 if(binding?.kind==='import'&&binding.source.startsWith('/$bunfs/root/')){
  const target=`files/${binding.source.slice('/$bunfs/root/'.length)}`,local=modules.get(target)?.symbols.exports[binding.imported];
  if(local)return resolveCollection(modules,target,local,seen);
 }
 return[];
}
function resolveExpressionReferences(modules,path,node,seen=new Set()) {
 const references=[];
 walk(node,(child,parent)=>{
  if(child.type==='Identifier'){
   if(parent?.type==='MemberExpression'&&!parent.computed&&parent.property===child)return;
   if(parent?.type==='Property'&&!parent.computed&&parent.key===child&&!parent.shorthand)return;
   const shadowed=modules.get(path)?.symbols.shadowRanges.some(range=>range.start<=child.start&&range.end>child.start&&range.names.includes(child.name));
   if(shadowed)return;
   const direct=resolveToolReference(modules,path,child.name,child.start);
   if(direct)references.push({symbol:child.name,offset:child.start,...direct});
   else for(const tool of resolveCollection(modules,path,child.name,new Set(seen)))references.push({...tool,collectionSymbol:child.name,collectionOffset:child.start});
  }
  const required=requireMember(child);
  if(required){
   const target=`files/${required.source.slice('/$bunfs/root/'.length)}`,local=modules.get(target)?.symbols.exports[required.imported];
   const tool=local&&resolveToolReference(modules,target,local);
   if(tool)references.push({symbol:required.imported,offset:child.start,...tool});
  }
 });
 return references;
}
function providerDescriptor(module,node) {
 const requiredExports=[];
 walk(node,child=>{const required=requireMember(child);if(required)requiredExports.push({source:required.source,export:required.imported,start:child.start})});
 const primitive=node?.type==='Literal'&&(node.value===null||['boolean','number','string'].includes(typeof node.value));
 const fn=['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(node?.type)?node:null;
 const returned=fn?.body?.type==='BlockStatement'&&fn.body.body.length===1&&fn.body.body[0].type==='ReturnStatement'?fn.body.body[0].argument:fn?.body;
 const primitiveReturn=returned?.type==='Literal'&&(returned.value===null||['boolean','number','string'].includes(typeof returned.value));
 return{kind:node.type,start:node.start,end:node.end,requiredExports,
  ...(primitive?{declaredPrimitive:node.value}:{}),...(primitiveReturn?{declaredReturnPrimitive:returned.value}:{}),
  ...(node.type==='CallExpression'&&node.callee.type==='Identifier'&&module.functions[node.callee.name]?{calledFunction:{symbol:node.callee.name,...providerDescriptor(module,module.functions[node.callee.name])}}:{})};
}
export function inspectToolRegistryRoots(modules){
 const roots=[];
 for(const[path,module]of modules)for(const registry of module.registries){
  const fn=module.functions[registry.symbols.getAllBaseTools];
  const returns=fn?.body?.type==='BlockStatement'?fn.body.body.filter(node=>node.type==='ReturnStatement'):[];
  const array=returns.length===1&&returns[0].argument?.type==='ArrayExpression'?returns[0].argument:null;
  const locals={};
  for(const statement of fn?.body?.body??[])if(statement.type==='VariableDeclaration')for(const decl of statement.declarations)if(decl.id.type==='Identifier'&&decl.init)locals[decl.id.name]=decl.init;
  const elements=array?.elements.map(node=>{
   if(!node)return{kind:'hole'};
   const references=resolveExpressionReferences(modules,path,node);
   const providers=[];
   if(!references.length){
    const names=new Set();
    walk(node,(child,parent)=>{
     if(child.type!=='Identifier'||names.has(child.name))return;
     if(parent?.type==='MemberExpression'&&!parent.computed&&parent.property===child)return;
     if(parent?.type==='Property'&&!parent.computed&&parent.key===child&&!parent.shorthand)return;
     if(module.symbols.shadowRanges.some(range=>range.start>fn.start&&range.start!==fn.body.start&&range.end<fn.end&&range.start<=child.start&&range.end>child.start&&range.names.includes(child.name)))return;
     const declaration=locals[child.name]??module.initializers[child.name]??module.functions[child.name];
     if(declaration){names.add(child.name);providers.push({symbol:child.name,scope:locals[child.name]?'factory-local':'module',...providerDescriptor(module,declaration)})}
    });
   }
   return{kind:node.type,start:node.start,end:node.end,references,providers,
    emptyLiteralSpread:node.type==='SpreadElement'&&node.argument.type==='ArrayExpression'&&node.argument.elements.length===0,
    qualification:node.type==='Identifier'&&references.length===1&&!references[0].collectionSymbol?'direct-definition-reference':'composition-or-dynamic-expression'};
  })??null;
  roots.push({path,sha256:module.sha256,start:registry.start,symbols:registry.symbols,
   selectorLocations:Object.fromEntries(Object.entries(registry.symbols).map(([role,symbol])=>[role,module.functions[symbol]?{start:module.functions[symbol].start,end:module.functions[symbol].end}:null])),factoryStart:fn?.start??null,arrayStart:array?.start??null,elements});
 }
 return roots;
}
export async function catalogToolRegistries(toolRun,output){
 const parent=await readCompleteRun(toolRun,'tool-definitions');
 const toolBytes=await readFile(join(toolRun,'tool-definitions.json'));if(hash(toolBytes)!==parent.outputSha256)throw Error('Tool definitions changed');
 const extraction=parent.inputs.extraction,manifest=await readCompleteRun(extraction,'extract');
 const inventoryBytes=await readFile(join(extraction,'inventory.json'));if(hash(inventoryBytes)!==manifest.inventorySha256)throw Error('Extraction inventory changed');
 const tools=new Map(JSON.parse(toolBytes).modules.map(module=>[module.path,module.tools]));
 const run=await createRun(output,'tool-registries',{toolRun,extraction,targetSha256:manifest.inputs.targetSha256,
  scannerSha256:hash(await readFile(new URL(import.meta.url))),symbolsSha256:hash(await readFile(new URL('./module-symbols.mjs',import.meta.url))),parser:'acorn@8.15.0'});
 try{
  const modules=new Map();
  for(const file of JSON.parse(inventoryBytes)){
   if(file.loader!=='js')continue;
   if(!['latin1','utf8','utf-8'].includes(file.encoding))throw Error('Unsupported source encoding');
   const bytes=await readFile(join(extraction,'extracted',file.path));if(hash(bytes)!==file.sha256)throw Error(`Source changed: ${file.path}`);
   modules.set(file.path,{...inspectToolRegistryModule(bytes.toString(file.encoding),tools.get(file.path)),sha256:file.sha256});
  }
  const roots=inspectToolRegistryRoots(modules);
  const result=JSON.stringify({roots,qualification:'Named assembly-interface candidates and static tool-definition references. References inside composition are conditional, not active registrations. Dynamic providers, wrappers, filtering, aliases, schemas and runtime availability remain separate work.'},null,2)+'\n';
  await writeFile(join(run.directory,'tool-registries.json'),result);await run.finish({status:'complete',outputSha256:hash(Buffer.from(result)),roots:roots.length});
  return{directory:run.directory,status:'complete',roots:roots.length};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
