import ts from 'typescript';
import { hash as digest } from '../artifacts/runs.mjs';

/** Scope-aware binding/dependency candidates only; side effects and runtime gates still need review. */
export function buildNativeExportGraph(sources) {
 const prefix='/native/';
 const files=new Map([...sources].map(([name,source])=>[prefix+name,source]));
 const opts={allowJs:true,noLib:true,checkJs:false,target:ts.ScriptTarget.ESNext,module:ts.ModuleKind.ESNext};
 const host=ts.createCompilerHost(opts);host.readFile=f=>files.get(f);host.fileExists=f=>files.has(f);host.getSourceFile=(f,l)=>files.has(f)?ts.createSourceFile(f,files.get(f),l,true,ts.ScriptKind.JS):undefined;host.resolveModuleNames=(names)=>names.map(name=>name.startsWith('/$bunfs/root/')&&files.has(prefix+'files/'+name.slice('/$bunfs/root/'.length))?{resolvedFileName:prefix+'files/'+name.slice('/$bunfs/root/'.length),extension:ts.Extension.Js}:undefined);host.writeFile=()=>{};
 const program=ts.createProgram([...files.keys()],opts,host),checker=program.getTypeChecker(),roots=new Map(),byKey=new Map(),exports=[];
 const symbol=n=>{let s=checker.getSymbolAtLocation(n);if(s?.flags&ts.SymbolFlags.Alias){try{s=checker.getAliasedSymbol(s)}catch{}}return s};
 for(const sf of program.getSourceFiles())for(const statement of sf.statements){const nodes=ts.isVariableStatement(statement)?statement.declarationList.declarations:[statement];for(const n of nodes){if(!(ts.isVariableDeclaration(n)||ts.isFunctionDeclaration(n)||ts.isClassDeclaration(n))||!n.name||!ts.isIdentifier(n.name))continue;const sym=symbol(n.name);if(sym){const entry={key:sf.fileName+':'+n.name.text,name:n.name.text,node:n,symbol:sym,file:sf.fileName,deps:[]};roots.set(sym,entry);byKey.set(entry.key,entry)}}}
 for(const entry of roots.values()){
  const locals=new Map(),deps=[],parts=[],externalBindings=new Map();
  function visit(n){if(n.kind===ts.SyntaxKind.ExportKeyword||n.kind===ts.SyntaxKind.DefaultKeyword)return;parts.push('('+n.kind);
   if(ts.isIdentifier(n)||ts.isPrivateIdentifier(n)){
    const p=n.parent,property=ts.isPropertyAccessExpression(p)&&p.name===n||((ts.isPropertyAssignment(p)||ts.isMethodDeclaration(p)||ts.isPropertyDeclaration(p)||ts.isGetAccessor(p)||ts.isSetAccessor(p)||ts.isShorthandPropertyAssignment(p))&&p.name===n);
    const s=symbol(n),dep=s&&roots.get(s);
    if(property)parts.push('property:'+n.text);
    else if(dep===entry)parts.push('self');
    else if(dep){let i=deps.indexOf(dep.key);if(i<0){i=deps.length;deps.push(dep.key)}parts.push('dep:'+i)}
    else if(s&&s.declarations?.some(d=>d.getSourceFile()===entry.node.getSourceFile()&&d.pos>=entry.node.pos&&d.end<=entry.node.end)){if(!locals.has(s))locals.set(s,locals.size);parts.push('local:'+locals.get(s))}
    else {parts.push('external:'+n.text);externalBindings.set(n.text,{name:n.text,declarations:(s?.declarations??[]).map(d=>({kind:ts.SyntaxKind[d.kind],file:d.getSourceFile().fileName.slice(prefix.length)}))})}
   }else if(ts.isStringLiteralLike(n)||ts.isNumericLiteral(n)||ts.isBigIntLiteral(n)||[ts.SyntaxKind.TemplateHead,ts.SyntaxKind.TemplateMiddle,ts.SyntaxKind.TemplateTail].includes(n.kind))parts.push('text:'+n.text);
   else ts.forEachChild(n,visit);
   parts.push(')');
  }
  visit(entry.node);entry.base=digest(parts.join(''));entry.deps=deps;entry.hash=entry.base;entry.externalBindings=[...externalBindings.values()];
 }
 for(let round=0;round<6;round++){const updated=new Map([...byKey.values()].map(e=>[e.key,digest(e.base+'|'+e.deps.map(d=>byKey.get(d)?.hash??'missing').join('|'))]));for(const e of roots.values())e.hash=updated.get(e.key)}
 for(const sf of program.getSourceFiles()){const module=checker.getSymbolAtLocation(sf);if(!module)continue;for(const exp of checker.getExportsOfModule(module)){let s=exp;if(s.flags&ts.SymbolFlags.Alias){try{s=checker.getAliasedSymbol(s)}catch{}}const root=roots.get(s);if(root)exports.push({file:sf.fileName.slice(prefix.length),exported:exp.name,local:root.name,origin:root.file.slice(prefix.length)+':'+root.name,hash:root.hash,base:root.base,dependencies:root.deps.length})}}
 return {exports,roots:roots.size,definitions:[...roots.values()].map(entry=>({key:entry.key.slice(prefix.length),file:entry.file.slice(prefix.length),name:entry.name,kind:ts.SyntaxKind[entry.node.kind],start:entry.node.getStart(),end:entry.node.end,definitionSha256:digest(entry.node.getText()),base:entry.base,hash:entry.hash,dependencies:entry.deps.map(key=>key.slice(prefix.length)),externalBindings:entry.externalBindings}))};}
export function compareNativeExportGraphs(before, after, modulePaths) {
 const index=new Map();for(const entry of after.exports){const bucket=index.get(entry.hash)??[];bucket.push(entry);index.set(entry.hash,bucket)}
 return {status:'needs-source-review',dependencyDepth:6,
  qualification:'Pinned TypeScript binding identities and six rounds of declaration/dependency shapes; not a behavioral equivalence proof. Global mutations, initialization side effects, dynamic resolution, function names and runtime gates require separate review. Duplicate origins and unresolved values remain visible.',
  roots:{before:before.roots,after:after.roots},
  exports:before.exports.filter(entry=>modulePaths.has(entry.file)).map(entry=>({...entry,candidates:index.get(entry.hash)??[]}))};
}

/** Direct native namespace consumption; local shadow bindings are not native imports. */
export function inspectNativeAdapterExports(source) {
 const file='/adapter.mjs',options={allowJs:true,noLib:true,noResolve:true,target:ts.ScriptTarget.ESNext};
 const host=ts.createCompilerHost(options);host.getSourceFile=(name,language)=>name===file?ts.createSourceFile(name,source,language,true,ts.ScriptKind.JS):undefined;host.fileExists=name=>name===file;host.readFile=name=>name===file?source:undefined;host.writeFile=()=>{};
 const program=ts.createProgram([file],options,host),checker=program.getTypeChecker(),sf=program.getSourceFile(file),namespaces=new Map(),names=new Map(),consumed=new Map();
 const add=(module,exported)=>consumed.set(module+':'+exported,{module,exported});
 const unwrap=node=>{while(node&&ts.isParenthesizedExpression(node))node=node.expression;return node};
 const imported=input=>{const node=unwrap(input);return node&&ts.isAwaitExpression(node)&&ts.isCallExpression(node.expression)&&node.expression.expression.kind===ts.SyntaxKind.ImportKeyword&&ts.isStringLiteral(node.expression.arguments[0])&&node.expression.arguments[0].text.startsWith('/$bunfs/root/')?node.expression.arguments[0].text.slice('/$bunfs/root/'.length):undefined};
 const walk=(node,visit)=>{visit(node);ts.forEachChild(node,child=>walk(child,visit))};
 walk(sf,node=>{
  const name=ts.isVariableDeclaration(node)&&ts.isIdentifier(node.name)?node.name:ts.isBinaryExpression(node)&&node.operatorToken.kind===ts.SyntaxKind.EqualsToken&&ts.isIdentifier(node.left)?node.left:undefined;
  const value=ts.isVariableDeclaration(node)?node.initializer:ts.isBinaryExpression(node)?node.right:undefined;
  if(!name||!value)return;const module=imported(value);
  if(module){namespaces.set(checker.getSymbolAtLocation(name),module);names.set(name.text,module)}
  else if(ts.isPropertyAccessExpression(value)){const module=imported(value.expression);if(module)add(module,value.name.text)}
 });
 walk(sf,node=>{if(!ts.isPropertyAccessExpression(node))return;
  if(ts.isIdentifier(node.expression)){const module=namespaces.get(checker.getSymbolAtLocation(node.expression));if(module)add(module,node.name.text)}
  else if(ts.isPropertyAccessExpression(node.expression)&&ts.isIdentifier(node.expression.expression)&&['n','native','modules'].includes(node.expression.expression.text)){const module=names.get(node.expression.name.text);if(module)add(module,node.name.text)}
 });
 return [...consumed.values()].sort((a,b)=>(a.module+':'+a.exported).localeCompare(b.module+':'+b.exported));
}
