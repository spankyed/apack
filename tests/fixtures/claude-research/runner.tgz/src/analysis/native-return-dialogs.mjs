import {parse} from 'acorn';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';

function visit(node,fn){
 if(!node||typeof node!=='object'||!node.type)return;
 fn(node);
 for(const value of Object.values(node)){
  if(Array.isArray(value))for(const child of value)visit(child,fn);
  else if(value?.type)visit(value,fn);
 }
}
function visitOwnBody(node,fn){
 const walk=value=>{if(!value||typeof value!=='object'||!value.type||['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression'].includes(value.type))return;fn(value);for(const child of Object.values(value)){if(Array.isArray(child))for(const item of child)walk(item);else if(child?.type)walk(child)}};
 walk(node.body);
}
const key=node=>node?.name??node?.value;
const memberKey=node=>node.computed?(node.property.type==='Literal'?node.property.value:undefined):node.property.name;
function hasLiteral(node,text){let found=false;visit(node,n=>{if(n.type==='Literal'&&n.value===text)found=true});return found;}
function hasCall(node,method){let found=false;visit(node,n=>{if(n.type==='CallExpression'&&n.callee?.type==='MemberExpression'&&key(n.callee.property)===method)found=true});return found;}
function hasProperty(node,name){let found=false;visitOwnBody(node,n=>{if(n.type==='MemberExpression'&&memberKey(n)===name)found=true});return found;}
function hasCallbackProperty(node,name){let found=false;visit(node,n=>{if(n.type==='MemberExpression'&&memberKey(n)===name)found=true});return found;}
function hasAssignment(node,name,predicate){let found=false;visitOwnBody(node,n=>{if(n.type==='AssignmentExpression'&&n.left.type==='MemberExpression'&&memberKey(n.left)===name&&predicate(n.right))found=true});return found;}
function hasBinding(node,name){let found=false;visit(node,n=>{if(n.type==='ObjectPattern'&&n.properties.some(property=>key(property.key)===name))found=true});return found;}
function unique(values,label){if(values.length!==1)throw Error(`${label}: expected one original source site, got ${values.length}`);return values[0];}

/** Static sites only: keep source admission, effects and mounted views distinct from app support. */
export async function inspectNativeReturnDialogs(file){
 const bytes=await readFile(file);if(bytes.length>16*1024*1024)throw Error('Return-dialog source exceeds audit bound');
 const source=bytes.toString('utf8'),ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),functions=[],variables=[],calls=[];
 for(const node of ast.body){
  if(node.type==='FunctionDeclaration')functions.push(node);
  if(node.type==='VariableDeclaration')variables.push(...node.declarations);
 }
 visit(ast,node=>{if(node.type==='CallExpression')calls.push(node)});
 const hash=value=>createHash('sha256').update(value).digest('hex');
 const site=(node,name)=>({name,utf16Start:node.start,utf16End:node.end,byteStart:Buffer.byteLength(source.slice(0,node.start)),byteEnd:Buffer.byteLength(source.slice(0,node.end)),sha256:hash(source.slice(node.start,node.end))});
 const fn=(label,predicate)=>{const node=unique(functions.filter(predicate),label);return site(node,node.id.name)};
 const wrapper=(label,properties)=>{
  const declaration=unique(variables.filter(node=>node.id.type==='Identifier'&&node.init?.type==='ArrowFunctionExpression'&&properties.every(property=>node.init.body?.arguments?.[1]?.properties?.some(item=>key(item.key)===property))),label+' wrapper');
  const registration=unique(calls.filter(node=>node.arguments.length===2&&node.arguments[1]?.type==='Identifier'&&node.arguments[1].name===declaration.id.name&&node.arguments[0]?.type==='Identifier'),label+' registration');
  const descriptor=unique(variables.filter(node=>node.id.name===registration.arguments[0].name&&node.init?.type==='CallExpression'),label+' descriptor');
  const rendererName=declaration.init.body.arguments[0]?.name;
  const renderer=unique(functions.filter(node=>node.id.name===rendererName),label+' view');
  return {descriptor:site(descriptor.init,descriptor.id.name),registration:site(registration,key(registration.callee)),wrapper:site(declaration.init,declaration.id.name),view:site(renderer,renderer.id.name)};
 };
 // Follow the notification's own JSX and the live key registration rather than matching labels.
 const inlineLine=unique(functions.filter(node=>hasLiteral(node,'upsell')&&hasCall(node,'addNotification')),'new-model line notification');
 const ownNodes=[];visitOwnBody(inlineLine,node=>ownNodes.push(node));
 const notification=unique(ownNodes.filter(node=>node.type==='ObjectExpression'&&['key','kind','jsx','timeoutMs'].every(name=>node.properties.some(property=>key(property.key)===name))),'new-model notification object');
 const property=(node,name)=>unique(node.properties.filter(item=>key(item.key)===name),'new-model '+name).value;
 const jsx=property(notification,'jsx');if(jsx.type!=='CallExpression'||jsx.arguments[0]?.type!=='Identifier'||jsx.arguments[1]?.type!=='ObjectExpression')throw Error('new-model notification JSX changed');
 const lineView=unique(functions.filter(node=>node.id.name===jsx.arguments[0].name),'new-model mounted line view');
 const onScreen=property(jsx.arguments[1],'onScreen');if(onScreen.type!=='ArrowFunctionExpression')throw Error('new-model onScreen callback changed');
 const keyRegistrations=[];
 for(const owner of functions)visitOwnBody(owner,node=>{if(node.type==='ObjectExpression')for(const item of node.properties)if(key(item.key)==='chat:defaultToNewerModel'&&item.value?.type==='ArrowFunctionExpression')keyRegistrations.push({owner,handler:item.value})});
 const lineKey=unique(keyRegistrations,'new-model live key registration');
 const resolveLiteral=(node,label)=>{if(node.type!=='Identifier')throw Error(label+' reference changed');const declaration=unique(variables.filter(value=>value.id.type==='Identifier'&&value.id.name===node.name),label+' declaration');if(declaration.init?.type!=='Literal')throw Error(label+' literal changed');return {value:declaration.init.value,...site(declaration,node.name)}};
 const inlineBoundary={mountedView:site(lineView,lineView.id.name),onScreen:site(onScreen,'onScreen'),keyOwner:site(lineKey.owner,lineKey.owner.id.name),keyHandler:site(lineKey.handler,'chat:defaultToNewerModel'),notificationKey:resolveLiteral(property(notification,'key'),'new-model notification key'),notificationTimeout:resolveLiteral(property(notification,'timeoutMs'),'new-model notification timeout')};
 const background=unique(ast.body.filter(node=>node.type==='ClassDeclaration'&&node.body.body.some(item=>key(item.key)==='onLeftArrow')),'background gesture class');
 const member=name=>{const node=unique(background.body.body.filter(item=>key(item.key)===name),'background '+name);return site(node.value??node,background.id.name+'.'+(node.key.type==='PrivateIdentifier'?'#':'')+name)};
 return {file,sourceSha256:hash(bytes),dialogs:{
  left_arrow_confirm:{...wrapper('background confirmation',['summary','carryOverCount','monitorParkCount','workflowAgents']),controller:site(background,background.id.name),parkProgress:member('isParkInFlight'),producer:member('onLeftArrow'),preconditions:member('y'),confirm:member('confirm'),cancel:member('cancelConfirm')},
  cold_resume_quota:{...wrapper('cold resume quota',['inactiveSince','percentOfFiveHourLimit','focusedAction']),gate:fn('quota admission',node=>hasLiteral(node,'tengu_cold_resume_quota_suppressed')),effect:fn('quota decision',node=>hasLiteral(node,'tengu_cold_resume_quota_action')),inputBoundary:{
   draftState:fn('quota draft state',node=>{let found=false;visitOwnBody(node,n=>{if(n.type==='ObjectExpression'&&['needsArrow','pastes','pastesAtArrow'].every(name=>n.properties.some(property=>key(property.key)===name)))found=true});return found}),
   draftChanged:fn('quota draft change guard',node=>node.params.length===2&&hasAssignment(node,'needsArrow',right=>hasCall(right,'trim'))),
   choiceNavigation:fn('quota deliberate row choice',node=>hasAssignment(node,'needsArrow',right=>right.type==='Literal'&&right.value===false||right.type==='UnaryExpression'&&right.operator==='!'&&right.argument.type==='Literal'&&right.argument.value===1)&&hasAssignment(node,'pastesAtArrow',right=>right.type==='MemberExpression'&&memberKey(right)==='pastes')),
   pasteRecorded:fn('quota paste guard',node=>{let found=false;visitOwnBody(node,n=>{if(n.type==='UpdateExpression'&&n.operator==='++'&&n.argument.type==='MemberExpression'&&memberKey(n.argument)==='pastes'||n.type==='AssignmentExpression'&&n.operator==='+='&&n.left.type==='MemberExpression'&&memberKey(n.left)==='pastes'&&n.right.type==='Literal'&&n.right.value===1)found=true});return found}),
   confirmationGuard:fn('quota confirmation guard',node=>node.body.body.length===2&&hasProperty(node,'needsArrow')&&hasProperty(node,'pastes')&&hasProperty(node,'pastesAtArrow')&&node.body.body[1].type==='ReturnStatement'),
   idleKeyboard:fn('quota idle draft keyboard',node=>['onScreen','dialogStore','draft'].every(name=>node.params.some(parameter=>parameter.type==='ObjectPattern'&&parameter.properties.some(property=>key(property.key)===name)))&&hasCall(node,'setValueRaw')&&hasCallbackProperty(node,'backspace')),
   idleAdmission:fn('quota idle payload predicate',node=>node.params.length===1&&node.body.body.length===1&&node.body.body[0].type==='ReturnStatement'&&hasLiteral(node,'idle')&&hasLiteral(node,'trigger')),
   draftSubscription:fn('quota original draft subscription',node=>node.params.length===3&&hasCall(node,'subscribe')&&hasCall(node,'getState')&&node.body.body.at(-1)?.argument?.type==='CallExpression'&&node.body.body.at(-1).argument.arguments.length===2),
  }},
  resume_return:{...wrapper('resume compact offer',['sessionAgeMinutes','estimatedTokens','hasPrecomputedSummary']),gate:fn('resume-return admission',node=>hasLiteral(node,'tengu_gleaming_fair')),effect:fn('resume-return decision',node=>hasLiteral(node,'tengu_resume_return_action'))},
  newer_model_offer:{...wrapper('newer default model',['offer']),inlineBoundary,config:fn('new-model rollout config',node=>hasLiteral(node,'tengu_hidden_volcano')),gate:fn('new-model admission',node=>hasLiteral(node,'startup-announcement')&&source.slice(node.start,node.end).includes('.resumeReturnDismissed')),effect:fn('new-model dialog decision',node=>hasLiteral(node,'cli_newer_model_offer')&&hasCall(node,'requestDialog')),dispatch:fn('new-model form dispatch',node=>hasLiteral(node,'chat:defaultToNewerModel')&&hasLiteral(node,'line')),line:fn('new-model line notification',node=>hasLiteral(node,'upsell')&&hasCall(node,'addNotification')),lineAction:fn('new-model live line action',node=>source.slice(node.start,node.end).includes('.drawnAt')&&hasBinding(node,'take')&&!hasCall(node,'addNotification')),modelGuard:fn('new-model switch guard',node=>hasLiteral(node,'cli_newer_model_offer')&&hasLiteral(node,'switch_blocked'))},
 },qualification:'Names and source sites are candidates for reviewed adapter work. Static registration and gate code do not prove runtime eligibility, account/platform availability or actual-app acceptance. No recovered implementation executes.'};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 if(process.argv.length<3)throw Error('Usage: native-return-dialogs.mjs <immutable-extracted-module> [...]');
 const rows=[];for(const file of process.argv.slice(2))rows.push(await inspectNativeReturnDialogs(file));
 console.log(JSON.stringify(rows,null,2));
}
