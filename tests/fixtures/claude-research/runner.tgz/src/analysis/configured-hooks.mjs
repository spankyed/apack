import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {hash,readCompleteRun,createRun} from '../artifacts/runs.mjs';
const key=p=>p.type==='Property'&&!p.computed?p.key.name??p.key.value:null;
function unchain(node){const methods=[];while(node?.type==='CallExpression'&&node.callee.type==='MemberExpression'&&!node.callee.computed){methods.push(node.callee.property.name);node=node.callee.object}return {node,methods}}
/** Recognize a returned collection of locally declared hook schemas without running any builder. */
export function inspectConfiguredHooks(source){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),builders=[];
 for(const fn of ast.body){
  if(fn.type!=='FunctionDeclaration'||fn.async||fn.generator)continue;
  const returns=fn.body.body.filter(node=>node.type==='ReturnStatement');
  if(returns.length!==1||returns[0].argument?.type!=='ObjectExpression')continue;
  const returned=returns[0].argument.properties;
  if(!returned.some(p=>key(p)==='BashCommandHookSchema')||!returned.some(p=>key(p)==='HttpHookSchema'))continue;
  const locals=new Map(fn.body.body.flatMap(node=>node.type==='VariableDeclaration'?node.declarations:[]).filter(node=>node.id.type==='Identifier').map(node=>[node.id.name,node.init]));
  const schemas=[],unresolved=[];
  for(const property of returned){
    const exportName=key(property),local=property.value?.name;
    const shape=unchain(locals.get(local)).node?.arguments?.[0];
    if(!exportName||shape?.type!=='ObjectExpression'){unresolved.push({exportName,local,start:property.start});continue}
    const typeField=shape.properties.find(p=>key(p)==='type');const type=unchain(typeField?.value).node?.arguments?.[0];
    schemas.push({exportName,local,type:type?.type==='Literal'?type.value:null,start:shape.start,end:shape.end,fields:shape.properties.filter(p=>key(p)!==null).map(p=>{
      const {node,methods}=unchain(p.value);
      return {name:key(p),start:p.start,end:p.end,factory:node?.callee?.name??node?.type,modifiers:methods,expressionKind:node?.type??'missing'};
    }),composition:shape.properties.filter(p=>key(p)===null).map(p=>({kind:p.type,start:p.start,end:p.end}))});
  }
  builders.push({name:fn.id.name,start:fn.start,end:fn.end,schemas,unresolved,conditionalBody:fn.body.body.some(node=>['IfStatement','SwitchStatement','TryStatement'].includes(node.type))});
 }
 return builders;
}
export async function catalogConfiguredHooks(extractionRun,output){
 const extraction=await readCompleteRun(extractionRun,'extract');const inventoryBytes=await readFile(join(extractionRun,'inventory.json'));
 if(hash(inventoryBytes)!==extraction.inventorySha256)throw Error('Extraction inventory changed');
 const run=await createRun(output,'configured-hooks',{extractionRun,targetSha256:extraction.inputs.targetSha256,scannerSha256:hash(await readFile(new URL(import.meta.url))),parser:'acorn@8.15.0'});
 try{
  const modules=[];
  for(const file of JSON.parse(inventoryBytes)){
   if(file.loader!=='js')continue;
   const bytes=await readFile(join(extractionRun,'extracted',file.path));if(hash(bytes)!==file.sha256)throw Error(`Source changed: ${file.path}`);
   const builders=inspectConfiguredHooks(bytes.toString(file.encoding));if(builders.length)modules.push({path:file.path,sha256:file.sha256,encoding:file.encoding,builders});
  }
  const result=JSON.stringify({modules,qualification:'Static local schema declarations; constructor symbols, event eligibility, conditions, failure policy and runtime effects require separate evidence.'},null,2)+'\n';
  await writeFile(join(run.directory,'configured-hooks.json'),result);await run.finish({status:'complete',outputSha256:hash(Buffer.from(result)),modules:modules.length});return {directory:run.directory,status:'complete',modules:modules.length};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
