import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {hash,createRun,readCompleteRun} from '../artifacts/runs.mjs';
import {analysisProvenance} from './provenance.mjs';
const methods=new Set(['str','rawStr','bool','triBool','int','enum']);
function literal(node,bindings,seen=new Set()) {
 if(!node)return {resolved:false};
 if(node.type==='Literal')return {resolved:true,value:node.value};
 if(node.type==='UnaryExpression'&&node.operator==='!'&&node.argument.type==='Literal')return {resolved:true,value:!node.argument.value};
 if(node.type==='Identifier'&&!seen.has(node.name))return literal(bindings.get(node.name),bindings,new Set([...seen,node.name]));
 if(node.type==='ArrayExpression'){const a=node.elements.map(n=>literal(n,bindings,seen));return a.every(x=>x.resolved)?{resolved:true,value:a.map(x=>x.value)}:{resolved:false};}
 if(node.type==='ObjectExpression'){const result={};for(const p of node.properties){if(p.type!=='Property'||p.computed)return {resolved:false};const v=literal(p.value,bindings,seen);if(!v.resolved)return v;result[p.key.name??p.key.value]=v.value;}return {resolved:true,value:result};}
 return {resolved:false};
}
/** Top-level export-getter tables pointing to typed environment-shaped parser declarations. */
export function inspectEnvSchema(source) {
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),bindings=new Map(),tables=[];
 for(const n of ast.body)if(n.type==='VariableDeclaration')for(const d of n.declarations)if(d.id.type==='Identifier')bindings.set(d.id.name,d.init);
 for(const n of ast.body) {
  if(n.type!=='ExpressionStatement'||n.expression.type!=='CallExpression')continue;
  const call=n.expression,table=call.arguments[1];if(table?.type!=='ObjectExpression'||table.properties.length===0)continue;
  const entries=[];
  for(const p of table.properties) {
   const name=p.key?.name??p.key?.value,fn=p.value;
   if(p.type!=='Property'||p.computed||!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name)||fn.type!=='ArrowFunctionExpression'||fn.params.length||fn.body.type!=='Identifier')break;
   const init=bindings.get(fn.body.name),method=init?.callee;
   if(init?.type!=='CallExpression'||method?.type!=='MemberExpression'||method.computed||!methods.has(method.property.name))break;
   entries.push({name,parser:method.property.name,parserNamespace:method.object.type==='Identifier'?method.object.name:null,
    arguments:init.arguments.map(a=>literal(a,bindings)),start:p.start,end:p.end,declaration:{start:init.start,end:init.end}});
  }
  if(entries.length===table.properties.length)tables.push({start:table.start,end:table.end,entries});
 }
 return tables;
}
export async function catalogEnvSchema(extraction,output) {
 const parent=await readCompleteRun(extraction,'extract'),inventory=await readFile(join(extraction,'inventory.json'));
 if(hash(inventory)!==parent.inventorySha256)throw Error('Extraction inventory changed');
 const run=await createRun(output,'env-schema',{extraction,targetSha256:parent.inputs.targetSha256,inventorySha256:hash(inventory),...await analysisProvenance(new URL(import.meta.url))});
 try{const modules=[];let scannedModules=0;
  for(const file of JSON.parse(inventory)){if(file.loader!=='js')continue;
   if(!['utf8','utf-8','latin1'].includes(file.encoding))throw Error('Unsupported source encoding');
   const bytes=await readFile(join(extraction,'extracted',file.path));if(hash(bytes)!==file.sha256)throw Error('Source changed');
   const tables=inspectEnvSchema(bytes.toString(file.encoding));scannedModules++;if(tables.length)modules.push({path:file.path,sha256:hash(bytes),encoding:file.encoding,tables});
  }
  const result={scannedModules,modules,qualification:'Top-level literal environment-name getter tables, at least one entry, each referring to a parser constructor from the selected method family. Literal arguments resolved syntactically; not executed. Membership in an effective environment registry, namespace semantics, consumers and runtime gates require source review. No environment values read or emitted.'};
  const raw=JSON.stringify(result,null,2)+'\n';await writeFile(join(run.directory,'env-schema.json'),raw);const counts={scannedModules,modules:modules.length,tables:modules.reduce((n,m)=>n+m.tables.length,0),entries:modules.flatMap(m=>m.tables).reduce((n,t)=>n+t.entries.length,0)};await run.finish({status:'complete',outputSha256:hash(raw),...counts});return {directory:run.directory,status:'complete',...counts};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
