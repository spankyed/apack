import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
function canonical(value){
 if(Array.isArray(value))return value.map(canonical);
 if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])]));
 return value;
}
/** Name identity with parser/argument multisets; module names and minified bindings are navigation. */
export function compareEnvCatalogs(before,after){
 function group(catalog){const grouped=new Map();for(const module of catalog.modules)for(const table of module.tables)for(const entry of table.entries){
  if(typeof entry.name!=='string'||typeof entry.parser!=='string'||!Array.isArray(entry.arguments))throw Error('Invalid environment declaration');
  const item={parser:entry.parser,arguments:entry.arguments},signature=JSON.stringify(canonical(item)),items=grouped.get(entry.name)??[];items.push({signature,...item});grouped.set(entry.name,items);
 }for(const items of grouped.values())items.sort((a,b)=>a.signature.localeCompare(b.signature));return grouped;}
 const a=group(before),b=group(after),added=[],removed=[],changed=[];let unchangedNames=0;
 const metadata=items=>items.map(({signature,...rest})=>rest);
 for(const name of [...new Set([...a.keys(),...b.keys()])].sort()){
  const old=a.get(name),next=b.get(name);
  if(!old)added.push({name,after:metadata(next)});
  else if(!next)removed.push({name,before:metadata(old)});
  else if(JSON.stringify(old.map(e=>e.signature))===JSON.stringify(next.map(e=>e.signature)))unchangedNames++;
  else changed.push({name,before:metadata(old),after:metadata(next)});
 }
 return {unchangedNames,added,removed,changed,qualification:'Candidate declaration names with parser/argument occurrence multisets; preserves duplicate counts, ignores module and minified namespace churn, normalizes object key order. Unresolved argument markers remain explicit. Declaration changes are review leads, not feature/availability changes or behavioral compatibility proof.'};
}
export async function compareEnvRuns(before,after,output){
 const paths=[before,after],parents=await Promise.all(paths.map(path=>readCompleteRun(path,'env-schema'))),catalogs=[];
 for(let i=0;i<paths.length;i++){const bytes=await readFile(join(paths[i],'env-schema.json'));if(hash(bytes)!==parents[i].outputSha256)throw Error('Environment catalog changed');catalogs.push(JSON.parse(bytes));}
 const run=await createRun(output,'compare-env',{before,after,parentRunIds:parents.map(p=>p.id),targetSha256:parents.map(p=>p.inputs.targetSha256),parentOutputSha256:parents.map(p=>p.outputSha256),scannerSha256:hash(await readFile(new URL(import.meta.url))),runHelperSha256:hash(await readFile(new URL('../artifacts/runs.mjs',import.meta.url)))});
 try{const result=compareEnvCatalogs(...catalogs),raw=JSON.stringify(result,null,2)+'\n';await writeFile(join(run.directory,'comparison.json'),raw);const counts={unchangedNames:result.unchangedNames,added:result.added.length,removed:result.removed.length,changed:result.changed.length};await run.finish({status:'complete',outputSha256:hash(raw),...counts});return {directory:run.directory,status:'complete',...counts};}catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
