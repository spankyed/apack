import { readFile, stat } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { hash, readCompleteRun } from '../artifacts/runs.mjs';
import { loadUpgradeContracts } from './upgrade-contracts.mjs';

function versionParts(version) {
  if (typeof version !== 'string' || !/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(version)) {
    throw new Error('Expected a stable release version: ' + version);
  }
  return version.split('.').map(BigInt);
}

function compareVersions(left, right) {
  const a = versionParts(left);
  const b = versionParts(right);
  const index = a.findIndex((part, i) => part !== b[i]);
  return index === -1 ? 0 : a[index] < b[index] ? -1 : 1;
}

function parseMarkdown(content) {
  const entries = [];
  const versions = [];
  let version, releaseHeadingDepth, currentEntry, fence;
  for (const [index, line] of content.split(/\r?\n/).entries()) {
    if (fence) {
      const closing = /^ {0,3}(\x60{3,}|~{3,})[ \t]*$/.exec(line);
      if (closing?.[1][0] === fence[0] && closing[1].length >= fence.length) fence = undefined;
      continue;
    }
    const opening = /^ {0,3}(\x60{3,}|~{3,})/.exec(line);
    if (opening) {
      fence = opening[1];
      currentEntry = undefined;
      continue;
    }
    const heading = /^ {0,3}(#{1,6})[ \t]+(.+?)[ \t]*#*[ \t]*$/.exec(line);
    if (heading) {
      currentEntry = undefined;
      const release = /^v?(\d+\.\d+\.\d+\S*)$/.exec(heading[2]);
      if (!release) {
        if (heading[1].length <= releaseHeadingDepth) version = undefined;
        continue;
      }
      // Keep prerelease and build-tagged notes out of adjacent stable releases.
      releaseHeadingDepth = heading[1].length;
      version = /^\d+\.\d+\.\d+$/.test(release[1]) ? release[1] : undefined;
      if (!version) continue;
      if (versions.includes(version)) throw new Error('Duplicate changelog section: ' + version);
      versions.push(version);
    } else {
      const bullet = /^[-*+]\s+(.+)$/.exec(line);
      if (version && bullet) {
        currentEntry = { id: version + ':line-' + (index + 1), version, sourceLine: index + 1,
          summary: bullet[1].trim() };
        entries.push(currentEntry);
      } else if (currentEntry && /^ {2,}\S/.test(line)) {
        currentEntry.summary += ' ' + line.trim();
      } else {
        currentEntry = undefined;
      }
    }
  }
  if (!versions.length) throw new Error('Changelog requires version headings such as "## 2.1.302"');
  return { versions, entries };
}

function parseLedger(content) {
  const ledger = JSON.parse(content);
  if (ledger.schemaVersion !== 1 || !ledger.changelog || !ledger.countsByVersion
    || !Array.isArray(ledger.entries)) throw new Error('Expected a version 1 release disposition ledger');
  const versions = Object.keys(ledger.countsByVersion);
  const seen = new Set();
  const counts = new Map();
  for (const entry of ledger.entries) {
    if (!versions.includes(entry.version) || typeof entry.id !== 'string' || seen.has(entry.id)
      || typeof entry.summary !== 'string' || !entry.summary.trim()
      || typeof entry.family !== 'string' || !Number.isSafeInteger(entry.sourceLine) || entry.sourceLine < 1) {
      throw new Error('Invalid or duplicate release note: ' + entry.id);
    }
    seen.add(entry.id);
    counts.set(entry.version, (counts.get(entry.version) ?? 0) + 1);
  }
  if (versions.some(version => ledger.countsByVersion[version] !== (counts.get(version) ?? 0))) {
    throw new Error('Release ledger totals disagree with entries');
  }
  return { versions, entries: ledger.entries, changelog: ledger.changelog, ledger };
}

// Verify provenance separately from the heuristic comparison so a copied ledger never
// substitutes its counts or summaries for the archived source.
export async function verifyReleaseLedger(ledgerPath, changelogPath) {
  const [ledgerText, changelogBytes] = await Promise.all([
    readFile(ledgerPath, 'utf8'),
    readFile(changelogPath),
  ]);
  const { versions, entries, changelog, ledger } = parseLedger(ledgerText);
  const digest = hash(changelogBytes);
  if (!/^[a-f0-9]{40}$/.test(changelog.revision) || digest !== changelog.sha256) {
    throw new Error('Archived changelog does not match the release ledger pin');
  }
  const archive = changelogBytes.toString('utf8');
  const source = parseMarkdown(archive);
  const selected = new Set(versions);
  if (!versions.length || !versions.every(version => source.versions.includes(version))) {
    throw new Error('Release ledger names a section absent from the archived changelog');
  }
  const lines = archive.split(/\r?\n/);
  const remaining = new Map(source.entries.filter(entry => selected.has(entry.version))
    .map(entry => [entry.sourceLine, entry.version]));
  const countsByDisposition = new Map();
  for (const entry of entries) {
    if (remaining.get(entry.sourceLine) !== entry.version) {
      throw new Error('Unknown or duplicate changelog line for ' + entry.id);
    }
    if (hash(lines[entry.sourceLine - 1]) !== entry.sourceEntrySha256) {
      throw new Error('Release note hash differs from archived changelog for ' + entry.id);
    }
    const family = ledger.families && Object.hasOwn(ledger.families, entry.family) ? ledger.families[entry.family] : undefined;
    if (typeof entry.disposition !== 'string' || !family || family.disposition !== entry.disposition) {
      throw new Error('Unknown release disposition or family disagreement for ' + entry.id);
    }
    remaining.delete(entry.sourceLine);
    countsByDisposition.set(entry.disposition, (countsByDisposition.get(entry.disposition) ?? 0) + 1);
  }
  if (remaining.size) throw new Error('Release ledger omits changelog lines: ' + [...remaining.keys()].join(', '));
  const reported = Object.entries(ledger.countsByDisposition ?? {});
  if (reported.length !== countsByDisposition.size
    || reported.some(([name, count]) => count !== countsByDisposition.get(name))) {
    throw new Error('Release ledger disposition totals disagree with entries');
  }
  return { changelogRevision: changelog.revision, changelogSha256: digest, entries: entries.length,
    countsByVersion: ledger.countsByVersion, countsByDisposition: ledger.countsByDisposition };
}

function gapsBetweenPatchSections(versions) {
  const gaps = [];
  for (let i = 1; i < versions.length; i++) {
    const before = versionParts(versions[i - 1]);
    const after = versionParts(versions[i]);
    if (before[0] !== after[0] || before[1] !== after[1] || after[2] - before[2] <= 1n) continue;
    const first = [before[0], before[1], before[2] + 1n].join('.');
    const last = [after[0], after[1], after[2] - 1n].join('.');
    gaps.push(first === last ? first : first + ' through ' + last);
  }
  return gaps;
}

async function readNotes(path, pinnedVersion, candidateVersion) {
  let bytes;
  try {
    bytes = await readFile(path);
  } catch (error) {
    if (error.code === 'ENOENT') return { missing: 'Release notes file is missing: ' + basename(path), changes: [] };
    throw error;
  }
  const content = bytes.toString('utf8');
  const { entries, versions, changelog } = path.endsWith('.json') ? parseLedger(content) : parseMarkdown(content);
  const noteVersions = versions.filter(version =>
    compareVersions(version, pinnedVersion) > 0 && compareVersions(version, candidateVersion) <= 0)
    .sort(compareVersions);
  const included = new Set(noteVersions);
  const changes = entries.filter(entry => included.has(entry.version))
    .sort((a, b) => compareVersions(a.version, b.version) || a.sourceLine - b.sourceLine)
    .map(({ id, version, sourceLine, sourceEntrySha256, family, summary }) => ({
      id, kind: 'release-note', version, sourceLine, sourceEntrySha256, family, summary,
    }));
  return { artifact: { file: basename(path), sha256: hash(bytes), changelog, versions: noteVersions },
    coversCandidate: included.has(candidateVersion), coversPin: versions.includes(pinnedVersion),
    patchSectionGaps: gapsBetweenPatchSections([pinnedVersion, ...noteVersions,
      ...(!included.has(candidateVersion) ? [candidateVersion] : [])]), changes };
}

async function readSource(path, pinnedVersion, candidateVersion) {
  if (!path) return { missing: 'Supply a saved compare-catalogs run or reviewed release pin for source evidence.', changes: [] };
  let info;
  try {
    info = await stat(path);
  } catch (error) {
    if (error.code === 'ENOENT') return { missing: 'Source comparison input is missing: ' + basename(path), changes: [] };
    throw error;
  }

  let added, removed, artifact;
  if (info.isDirectory()) {
    const manifest = await readCompleteRun(path, 'compare-catalogs');
    const targetSha256 = manifest.inputs?.targetSha256;
    if (!Array.isArray(targetSha256) || targetSha256.length !== 2
      || !targetSha256.every(digest => typeof digest === 'string' && /^[a-f0-9]{64}$/.test(digest))) {
      throw new Error('Source comparison manifest lacks both target hashes');
    }
    const data = await readFile(join(path, 'comparison.json'));
    const sha256 = hash(data);
    if (sha256 !== manifest.comparisonSha256) throw new Error('Source comparison bytes do not match the run manifest');
    const comparison = JSON.parse(data);
    ({ added, removed } = comparison);
    artifact = { kind: 'compare-catalogs', id: manifest.id, sha256, targetSha256,
      qualification: comparison.qualification,
      releaseAssociation: 'Caller supplies version labels for these binary hashes.',
      unmatchedModuleOccurrences: {
        before: comparison.sourceChanges?.beforeOnly?.length,
        after: comparison.sourceChanges?.afterOnly?.length,
      } };
  } else {
    const bytes = await readFile(path);
    const pin = JSON.parse(bytes);
    const comparison = pin.structuralComparison;
    if (pin.version !== candidateVersion || comparison?.beforeVersion !== pinnedVersion) {
      throw new Error('Reviewed source comparison does not match the requested release pair');
    }
    ({ selectedAdditions: added, selectedRemovals: removed } = comparison);
    artifact = { kind: 'reviewed-source-excerpt', file: basename(path), sha256: hash(bytes),
      id: comparison.run, comparisonSha256: comparison.comparisonSha256, qualification: comparison.qualification };
  }

  const changes = [];
  for (const [direction, signatures] of [['added', added], ['removed', removed]]) {
    if (!Array.isArray(signatures)) throw new Error('Source comparison lacks ' + direction + ' signatures');
    for (const [index, signature] of signatures.entries()) {
      if (typeof signature?.kind !== 'string' || typeof (signature.value ?? signature.subtype) !== 'string') {
        throw new Error('Invalid source signature: ' + direction + ' ' + (index + 1));
      }
      changes.push({ id: 'source:' + direction + ':' + (index + 1), kind: 'source-signature', direction, signature });
    }
  }
  return { artifact, changes };
}

function candidateSignals(contract) {
  return contract.signals.terms.map(term => {
    const escaped = term.replace(/[.*+?^$(){}|[\]\\]/g, '\\$&');
    return { term, pattern: new RegExp('(?<![a-z0-9_])' + escaped + '(?![a-z0-9_])', 'i') };
  });
}

function matchReasons(contract, terms, change) {
  const reasons = [];
  if (contract.signals.families.includes(change.family)) {
    reasons.push({ match: 'reviewed-family', value: change.family });
  }
  const fields = change.signature?.fields ?? [];
  const input = change.summary ?? [change.signature?.value, change.signature?.subtype,
    ...(Array.isArray(fields) ? fields.map(field => typeof field === 'string' ? field : field?.key ?? field?.name) : [])]
    .filter(Boolean).join(' ');
  for (const { term, pattern } of terms) {
    if (pattern.test(input)) reasons.push({ match: 'term', value: term });
  }
  return reasons;
}

function selectChecks(contracts) {
  const selected = new Map();
  for (const contract of contracts) {
    for (const { platform, argv, env = {}, proves } of contract.checks) {
      const overrides = Object.entries(env).sort(([left], [right]) => left.localeCompare(right, 'en'));
      const key = JSON.stringify([platform, argv, overrides]);
      if (!selected.has(key)) {
        selected.set(key, { platform, argv, env: Object.fromEntries(overrides), verifies: [] });
      }
      selected.get(key).verifies.push({ contractId: contract.id, proves });
    }
  }
  return [...selected.values()];
}

export async function compareRelease({ pinnedVersion, candidateVersion, notesPath, sourcePath }) {
  if (compareVersions(pinnedVersion, candidateVersion) >= 0) throw new Error('Candidate must be newer than the pin');
  const [contracts, notes, source] = await Promise.all([
    loadUpgradeContracts(), readNotes(notesPath, pinnedVersion, candidateVersion),
    readSource(sourcePath, pinnedVersion, candidateVersion),
  ]);
  const rules = contracts.map(contract => ({ contract, terms: candidateSignals(contract) }));
  const matchingChanges = [];
  const unmatchedChanges = [];
  const affected = new Set();
  for (const change of [...notes.changes, ...source.changes]) {
    const matches = [];
    for (const { contract, terms } of rules) {
      const reasons = matchReasons(contract, terms, change);
      if (reasons.length) {
        matches.push({ contractId: contract.id, reasons });
        affected.add(contract.id);
      }
    }
    if (matches.length) matchingChanges.push({ ...change, matches });
    else unmatchedChanges.push(change);
  }

  const reviewGaps = [notes.missing, source.missing].filter(Boolean);
  if (notes.artifact && !notes.coversCandidate) reviewGaps.push('No release-note section for the requested candidate.');
  if (notes.artifact && !notes.coversPin) reviewGaps.push('The saved notes do not reach the pin. Confirm coverage of intervening releases.');
  for (const gap of notes.patchSectionGaps ?? []) {
    reviewGaps.push('No saved changelog section for ' + gap + '. Confirm which releases were published.');
  }
  const versionsWithNotes = new Set(notes.changes.map(change => change.version));
  for (const version of notes.artifact?.versions ?? []) {
    if (versionsWithNotes.has(version)) continue;
    reviewGaps.push('The changelog section for ' + version + ' has no parsed release-note entries.');
  }
  if (!notes.changes.length) reviewGaps.push('No release-note entries for the requested range.');
  if (unmatchedChanges.length) reviewGaps.push('Review unmatched changes before deciding adoption.');
  if (source.artifact?.kind === 'reviewed-source-excerpt') {
    reviewGaps.push('Only selected source signatures were compared. Review the full saved catalog run before adoption.');
  }
  if (source.artifact?.releaseAssociation) reviewGaps.push('Verify that the source run binary hashes match the labelled release pair.');
  const byteChanges = source.artifact?.unmatchedModuleOccurrences;
  if (byteChanges?.before || byteChanges?.after) {
    reviewGaps.push('Review unmatched module occurrences in the source run. Byte changes are unpaired leads.');
  }
  const affectedContracts = contracts.filter(contract => affected.has(contract.id));
  return { schemaVersion: 1, pinnedVersion, candidateVersion, notes: notes.artifact ?? null, source: source.artifact ?? null,
    affectedContracts, selectedChecks: selectChecks(affectedContracts),
    matchingChanges, unmatchedChanges, reviewGaps,
    qualification: 'Release notes and selected static signatures identify review leads. Matching, non-matching and unchanged signatures do not establish candidate behavior or app acceptance. Contract receipts apply to their recorded inputs only.' };
}
