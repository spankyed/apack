import { parse } from 'acorn';

function walk(node, visit) {
  if (!node?.type) return;
  visit(node);
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) { for (const child of value) walk(child, visit); }
    else if (value?.type) walk(value, visit);
  }
}
const key = property => property.type === 'Property' && !property.computed ? property.key.name ?? property.key.value : null;
function literal(node) {
  if (node?.type === 'Literal') return node.value;
  if (node?.type === 'CallExpression') return literal(node.arguments[0]);
  return null;
}

/** Traverse explicitly described wire unions, retaining unresolved branches rather than claiming coverage. */
export function inspectMessageSchemas(source) {
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module' });
  const variables = new Map();
  for (const statement of ast.body) {
    const declaration = statement.type === 'ExportNamedDeclaration' ? statement.declaration : statement;
    if (declaration?.type === 'VariableDeclaration') for (const item of declaration.declarations) {
      if (item.id.type === 'Identifier') variables.set(item.id.name, item);
    }
  }
  const roots = [];
  for (const declaration of variables.values()) walk(declaration.init, node => {
    if (node.type !== 'CallExpression' || node.callee.property?.name !== 'describe') return;
    const description = node.arguments[0]?.value;
    if (typeof description !== 'string') return;
    const direction = description.startsWith('Everything the CLI writes to its output stream') ? 'stdout'
      : description.startsWith("Everything a client may write to the CLI's input stream") ? 'stdin' : null;
    if (direction) roots.push({ symbol: declaration.id.name, direction });
  });
  if (roots.length !== 2 || new Set(roots.map(root => root.direction)).size !== 2) throw new Error('Expected unique described stdin and stdout unions');
  const unresolved = [], messages = [];
  function visit(symbol, direction, ancestry = []) {
    if (ancestry.includes(symbol)) { unresolved.push({ symbol, direction, reason: 'cycle' }); return; }
    const declaration = variables.get(symbol);
    if (!declaration) { unresolved.push({ symbol, direction, reason: 'missing-declaration' }); return; }
    const unions = [], objects = [], extensions = [];
    walk(declaration.init, node => {
      if (node.type === 'ArrayExpression' && node.elements.length && node.elements.every(member =>
        member?.type === 'CallExpression' && member.callee.type === 'Identifier' && member.arguments.length === 0)) unions.push(node);
      if (node.type === 'CallExpression' && node.callee.property?.name === 'extend'
        && node.callee.object.type === 'CallExpression' && node.callee.object.callee.type === 'Identifier'
        && node.arguments.length === 1 && node.arguments[0].type === 'ObjectExpression') extensions.push(node);
      if (node.type === 'ObjectExpression' && node.properties.some(property => key(property) === 'type')) objects.push(node);
    });
    const topObjects = objects.filter(object => !objects.some(parent => parent !== object && parent.start < object.start && parent.end > object.end));
    if (topObjects.length === 1) {
      const object = topObjects[0];
      const fields = object.properties.map(property => ({ name: key(property), start: property.start, end: property.end }));
      if (fields.some(field => field.name === null)) unresolved.push({ symbol, direction, reason: 'spread-or-computed-field' });
      const type = literal(object.properties.find(property => key(property) === 'type')?.value);
      const subtype = literal(object.properties.find(property => key(property) === 'subtype')?.value);
      if (typeof type !== 'string') unresolved.push({ symbol, direction, reason: 'nonliteral-type' });
      messages.push({ symbol, direction, type, subtype, start: object.start, end: object.end, fields });
    } else if (topObjects.length === 0 && unions.length === 1) {
      for (const member of unions[0].elements) {
        if (member?.type === 'CallExpression' && member.callee.type === 'Identifier' && member.arguments.length === 0) visit(member.callee.name, direction, [...ancestry, symbol]);
        else unresolved.push({ symbol, direction, reason: 'non-factory-union-member', start: member?.start });
      }
    } else if (topObjects.length === 0 && unions.length === 0 && extensions.length === 1) {
      const extension = extensions[0], base = extension.callee.object.callee.name;
      const before = messages.length;
      visit(base, direction, [...ancestry, symbol]);
      const inherited = messages.splice(before);
      if (inherited.length !== 1) {
        unresolved.push({ symbol, direction, reason: 'ambiguous-extension-base', base });
        return;
      }
      const object = extension.arguments[0];
      const added = object.properties.map(property => ({ name: key(property), start: property.start, end: property.end }));
      if (added.some(field => field.name === null)) unresolved.push({ symbol, direction, reason: 'spread-or-computed-field' });
      messages.push({ ...inherited[0], symbol, inheritedFrom: base, start: object.start, end: object.end,
        fields: [...new Map([...inherited[0].fields, ...added].map(field => [field.name, field])).values()] });
    } else unresolved.push({ symbol, direction, reason: 'ambiguous-or-composed-schema', objects: topObjects.length, unions: unions.length });
  }
  for (const root of roots) visit(root.symbol, root.direction);
  return { roots, messages, unresolved,
    qualification: 'Static top-level union membership and literal discriminators/field names only; Simple local extends are followed; other transformations, payload types, gates and behavior are not proved.' };
}

export async function catalogMessageSchemas(protocolRun, output) {
  const { readFile, writeFile } = await import('node:fs/promises');
  const { join } = await import('node:path');
  const { readCompleteRun, createRun, hash } = await import('../artifacts/runs.mjs');
  const parent = await readCompleteRun(protocolRun, 'protocol-schemas');
  const catalog = await readCompleteRun(parent.inputs.catalogRun, 'catalog');
  await readCompleteRun(catalog.inputs.extraction, 'extract');
  const source = await readFile(join(catalog.inputs.extraction, 'extracted', parent.inputs.module));
  if (hash(source) !== parent.inputs.sourceSha256) throw new Error('Schema source changed');
  if (!['latin1', 'utf8', 'utf-8'].includes(parent.inputs.sourceEncoding)) throw new Error('Unsupported encoding');
  const run = await createRun(output, 'message-schemas', { protocolRun, targetSha256: parent.inputs.targetSha256,
    sourceSha256: hash(source), sourceEncoding: parent.inputs.sourceEncoding,
    scannerSha256: hash(await readFile(new URL(import.meta.url))), parser: 'acorn@8.15.0' });
  try {
    const result = inspectMessageSchemas(source.toString(parent.inputs.sourceEncoding));
    const data = JSON.stringify(result, null, 2) + '\n';
    await writeFile(join(run.directory, 'message-schemas.json'), data);
    const status = result.unresolved.length ? 'failed' : 'complete';
    await run.finish({ status, messageSchemasSha256: hash(Buffer.from(data)), memberships: result.messages.length,
      unresolved: result.unresolved.length });
    return { directory: run.directory, status, memberships: result.messages.length, unresolved: result.unresolved.length };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}

/** Ignore source aliases/locations while comparing the declared wire surface. */
export function compareMessageSchemaData(before, after) {
  function signatures(data) {
    return new Set(data.messages.map(message => JSON.stringify({ direction: message.direction,
      type: message.type, subtype: message.subtype,
      fields: message.fields.map(field => field.name).sort(),
    })));
  }
  const a = signatures(before), b = signatures(after);
  return { added: [...b].filter(value => !a.has(value)).sort().map(JSON.parse),
    removed: [...a].filter(value => !b.has(value)).sort().map(JSON.parse),
    qualification: 'Compares message memberships, literal discriminators and field names only; optionality, payload types, gates and behavior are not compared.' };
}

export async function compareMessageSchemas(before, after, output) {
  const { readFile, writeFile } = await import('node:fs/promises');
  const { join } = await import('node:path');
  const { readCompleteRun, createRun, hash } = await import('../artifacts/runs.mjs');
  const parents = await Promise.all([before, after].map(path => readCompleteRun(path, 'message-schemas')));
  const data = await Promise.all([before, after].map(async (path, index) => {
    const bytes = await readFile(join(path, 'message-schemas.json'));
    if (hash(bytes) !== parents[index].messageSchemasSha256) throw new Error('Message schema inventory changed');
    const value = JSON.parse(bytes);
    if (value.unresolved.length) throw new Error('Cannot compare unresolved message schemas');
    return value;
  }));
  const run = await createRun(output, 'compare-message-schemas', { before, after,
    scannerSha256: hash(await readFile(new URL(import.meta.url))) });
  try {
    const result = compareMessageSchemaData(...data);
    const bytes = JSON.stringify(result, null, 2) + '\n';
    await writeFile(join(run.directory, 'comparison.json'), bytes);
    await run.finish({ status: 'complete', comparisonSha256: hash(Buffer.from(bytes)), added: result.added.length,
      removed: result.removed.length });
    return { directory: run.directory, status: 'complete', added: result.added.length, removed: result.removed.length };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
