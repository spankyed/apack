import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
function walk(node,visit,parents=[]){if(!node?.type)return;visit(node,parents);for(const value of Object.values(node)){if(Array.isArray(value)){for(const child of value)if(child?.type)walk(child,visit,[...parents,node]);}else if(value?.type)walk(value,visit,[...parents,node]);}}
const symbol=node=>node?.name??node?.value??null;

/** Lexical access evidence only. References never imply binding resolution, execution or registration. */
export function inspectToolAccess(source,candidates=[],targetBasenames=[]){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),targets=new Set(targetBasenames),edges=[],exports=[],objects=new Map();
 walk(ast,(node,parents)=>{
  if(node.type==='ObjectExpression')objects.set(node.start,{node,parents});
  if(node.type==='ExportNamedDeclaration'){
   for(const spec of node.specifiers)exports.push({start:spec.start,local:symbol(spec.local),exported:symbol(spec.exported),source:node.source?.value??null});
   const declaration=node.declaration;
   if(declaration?.id)exports.push({start:declaration.start,local:declaration.id.name,exported:declaration.id.name,source:null});
   for(const item of declaration?.declarations??[])if(item.id.type==='Identifier')exports.push({start:item.start,local:item.id.name,exported:item.id.name,source:null});
  }
  let path,kind,bindings=[];
  if(node.type==='ImportDeclaration'||node.type==='ExportNamedDeclaration'||node.type==='ExportAllDeclaration'){
   path=node.source?.value;kind=node.type;bindings=(node.specifiers??[]).map(spec=>({imported:spec.type==='ImportDefaultSpecifier'?'default':spec.type==='ImportNamespaceSpecifier'?'*':symbol(spec.imported??spec.local),local:symbol(spec.local??spec.exported)}));
  }else if(node.type==='ImportExpression'&&node.source.type==='Literal'){path=node.source.value;kind='dynamic-import';}
  else if(node.type==='CallExpression'&&node.callee.type==='MemberExpression'&&!node.callee.computed&&node.callee.property.name==='require'&&node.callee.object.type==='MetaProperty'&&node.callee.object.meta.name==='import'&&node.callee.object.property.name==='meta'&&node.arguments.length===1&&node.arguments[0].type==='Literal'){path=node.arguments[0].value;kind='bun-require';}
  if(typeof path==='string'&&targets.has(basename(path)))edges.push({start:node.start,end:node.end,kind,source:path,bindings});
 });
 const entries=candidates.map(candidate=>{
  const found=objects.get(candidate.start);if(!found||found.node.end!==candidate.end)throw new Error('Tool candidate source range changed');
  const containers=found.parents.filter(node=>['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression','VariableDeclarator'].includes(node.type)).map(node=>({kind:node.type,start:node.start,end:node.end,symbol:symbol(node.id)}));
  return {name:candidate.resolvedName??candidate.literalName??null,start:candidate.start,end:candidate.end,containers};
 });
 return {entries,edges,exports};
}

export async function catalogToolAccess(definitionsRun,assemblyRun,output){
 const definitions=await readCompleteRun(definitionsRun,'tool-definitions'),assembly=await readCompleteRun(assemblyRun,'tool-registries');
 if(assembly.inputs.targetSha256!==definitions.inputs.targetSha256||assembly.inputs.toolRun!==definitionsRun)throw new Error('Mismatched tool assembly parent');
 const db=await readFile(join(definitionsRun,'tool-definitions.json')),ab=await readFile(join(assemblyRun,'tool-registries.json'));
 if(hash(db)!==definitions.outputSha256||hash(ab)!==assembly.outputSha256)throw new Error('Tool parent output changed');
 const linked=new Set();for(const root of JSON.parse(ab).roots)for(const slot of root.elements)for(const ref of slot.references)linked.add(`${ref.path}:${ref.start}`);
 const groups=JSON.parse(db).modules.map(module=>({...module,tools:module.tools.filter(tool=>(tool.resolvedName??tool.literalName)&&!linked.has(`${module.path}:${tool.start}`))})).filter(module=>module.tools.length);
 const wanted=new Map(groups.map(module=>[module.path,module])),names=groups.map(module=>basename(module.path));
 const extraction=await readCompleteRun(definitions.inputs.extraction,'extract'),ib=await readFile(join(definitions.inputs.extraction,'inventory.json'));
 if(extraction.inputs.targetSha256!==definitions.inputs.targetSha256)throw new Error('Mismatched extraction target');
 if(hash(ib)!==extraction.inventorySha256)throw new Error('Extraction inventory changed');
 const run=await createRun(output,'tool-access',{definitionsRun,assemblyRun,targetSha256:definitions.inputs.targetSha256,scannerSha256:hash(await readFile(new URL(import.meta.url))),parser:'acorn@8.15.0'});
 try{
  const modules=[];let scanned=0;
  for(const file of JSON.parse(ib).filter(file=>file.loader==='js')){
   const bytes=await readFile(join(definitions.inputs.extraction,'extracted',file.path));if(hash(bytes)!==file.sha256)throw new Error('Extracted source changed: '+file.path);
   if(!['latin1','utf8','utf-8'].includes(file.encoding))throw new Error('Unsupported source encoding');
   scanned++;const source=bytes.toString(file.encoding),group=wanted.get(file.path);
   if(group&&group.sha256!==file.sha256)throw new Error('Tool module identity changed');
   if(!group&&!names.some(name=>source.includes(name)))continue;
   const data=inspectToolAccess(source,group?.tools??[],names);if(group||data.edges.length)modules.push({path:file.path,sha256:file.sha256,encoding:file.encoding,...data});
  }
  if(groups.some(group=>!modules.some(module=>module.path===group.path)))throw new Error('Tool module missing from extraction');
  const result={modules,qualification:'Named candidates not linked by the supplied central assembly scan. Static import/re-export, literal dynamic import and literal import.meta.require edges only. Candidate containers are lexical ancestry, not effective registration. Basename matching is navigation, not module resolution. Computed/dynamic paths, runtime gates and lexical call binding remain unresolved. No recovered code executed.'};
  const bytes=Buffer.from(JSON.stringify(result,null,2)+'\n');await writeFile(join(run.directory,'tool-access.json'),bytes);
  const candidates=groups.reduce((n,module)=>n+module.tools.length,0);await run.finish({status:'complete',outputSha256:hash(bytes),scanned,modules:modules.length,candidateModules:groups.length,candidates});return{directory:run.directory,status:'complete',scanned,modules:modules.length,candidateModules:groups.length,candidates};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
