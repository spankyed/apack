import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
const key=node=>node?.type==='Property'&&!node.computed?node.key.name??node.key.value:null;
function visit(node,fn){if(!node||typeof node!=='object')return;fn(node);for(const value of Object.values(node)){if(Array.isArray(value))for(const child of value)visit(child,fn);else if(value&&typeof value==='object')visit(value,fn)}}
function literal(node){
 if(node?.type==='Literal')return{known:true,value:node.value};
 if(node?.type==='UnaryExpression'&&node.operator==='!'&&node.argument.type==='Literal')return{known:true,value:!node.argument.value};
 return{known:false,expressionType:node?.type??'missing'};
}
function factoryBody(node){const factory=node?.type==='CallExpression'&&node.arguments.length===1?node.arguments[0]:node;return factory?.type==='ArrowFunctionExpression'&&factory.body.type!=='BlockStatement'?factory.body:null}
function schema(node){
 const body=factoryBody(node);
 if(body?.type!=='CallExpression')return{resolved:false,expressionType:body?.type??node?.type??'missing'};
 const callee=body.callee.type==='Identifier'?body.callee.name:null,arg=body.arguments[0];
 if(arg?.type==='ArrayExpression'){
  const values=arg.elements.map(literal);return{resolved:values.every(item=>item.known),constructor:callee,literalMembers:values};
 }
 if(arg?.type==='ObjectExpression')return{resolved:!arg.properties.some(item=>item.type==='SpreadElement'||item.computed),constructor:callee,fields:arg.properties.map(key).filter(value=>value!==null)};
 return{resolved:false,constructor:callee,argumentType:arg?.type??'missing'};
}
/** Descriptor-shaped variable initializers only. Factory identity and reachable transports require review. */
export function inspectUserDialogs(source){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),entries=[],imports=new Map();
 for(const node of ast.body)if(node.type==='ImportDeclaration')for(const item of node.specifiers)if(item.type==='ImportSpecifier')imports.set(item.local.name,{path:node.source.value,imported:item.imported.name??item.imported.value});
 visit(ast,node=>{
  if(node.type!=='VariableDeclarator'||node.id.type!=='Identifier'||node.init?.type!=='CallExpression')return;
  const object=node.init.arguments[0];if(object?.type!=='ObjectExpression')return;
  const fields=new Map(object.properties.filter(item=>key(item)!==null).map(item=>[key(item),item.value]));
  if(!['kind','payload','result','default'].every(name=>fields.has(name)))return;
  const kind=literal(fields.get('kind'));
  entries.push({symbol:node.id.name,factory:node.init.callee.type==='Identifier'?node.init.callee.name:null,factoryImport:imports.get(node.init.callee.name)??null,kindReference:kind.known?null:fields.get('kind').name??fields.get('kind').type,kind:kind.known?kind.value:null,kindUnresolved:!kind.known,objectUnresolved:object.properties.some(item=>item.type==='SpreadElement'||item.computed),payload:schema(fields.get('payload')),result:schema(fields.get('result')),default:literal(fields.get('default')),additionalFields:[...fields.keys()].filter(name=>!['kind','payload','result','default'].includes(name)),start:node.start,end:node.end});
 });return entries;
}
export async function catalogUserDialogs(extractionRun,output){
 const parent=await readCompleteRun(extractionRun,'extract'),inventoryBytes=await readFile(join(extractionRun,'inventory.json'));
 if(hash(inventoryBytes)!==parent.inventorySha256)throw Error('Extraction inventory changed');
 const run=await createRun(output,'user-dialogs',{targetSha256:parent.inputs.targetSha256,extractionRun,scannerSha256:hash(await readFile(new URL(import.meta.url))),parser:'acorn@8.15.0'});
 try{
  const modules=[];let scannedJavaScript=0;
  for(const file of JSON.parse(inventoryBytes)){
   if(file.loader!=='js')continue;
   const bytes=await readFile(join(extractionRun,'extracted',file.path));if(hash(bytes)!==file.sha256)throw Error(`Source changed: ${file.path}`);
   scannedJavaScript++;const entries=inspectUserDialogs(bytes.toString(file.encoding));
   if(entries.length)modules.push({path:file.path,sha256:file.sha256,encoding:file.encoding,offsetUnits:'decoded-string',entries});
  }
  const findings={scannedJavaScript,modules,qualification:'Static descriptor-shaped variable initializers with kind/payload/result/default. Literal schemas are metadata, not validated complete types. Does not resolve factory identity, imports, spreads, dynamic definitions, gates, producer reachability or transport support. No dialog is runtime-proven by this scan.'};
  const bytes=Buffer.from(JSON.stringify(findings,null,2)+'\n');await writeFile(join(run.directory,'user-dialogs.json'),bytes);await run.finish({status:'complete',outputSha256:hash(bytes)});return{directory:run.directory,status:'complete',scannedJavaScript,modules:modules.length,entries:modules.flatMap(module=>module.entries).length};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
