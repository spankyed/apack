import { readFile, writeFile } from 'node:fs/promises';
import { join, basename } from 'node:path';
import { parse } from 'acorn';
import { buildNativeExportGraph, compareNativeExportGraphs, inspectNativeAdapterExports } from './native-export-graph.mjs';
import { createRun, hash, readCompleteRun } from '../artifacts/runs.mjs';

/** Candidate shape only: dependency identity and eligibility still require source review. */
export function nativeModuleShape(source) {
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module', allowReturnOutsideFunction: true });
  const names = new Map(), tokens = [];
  function visit(node, parent, key) {
    if (node === null || typeof node !== 'object') {
      tokens.push(typeof node === 'bigint' ? `bigint:${node}` : JSON.stringify(node) ?? 'undefined');
      return;
    }
    if (Array.isArray(node)) { tokens.push('['); for (const item of node) visit(item, node, ''); tokens.push(']'); return; }
    tokens.push('{');
    for (const [field, value] of Object.entries(node)) {
      if (['start', 'end', 'raw', 'loc'].includes(field) || node.type === 'Property' && field === 'shorthand') continue;
      tokens.push(field + ':');
      if (node.type === 'Identifier' && field === 'name') {
        const property = parent?.type === 'MemberExpression' && key === 'property' && !parent.computed
          || ['Property', 'MethodDefinition', 'PropertyDefinition'].includes(parent?.type) && key === 'key' && !parent.computed;
        if (property) tokens.push(JSON.stringify(value));
        else { if (!names.has(value)) names.set(value, names.size); tokens.push('#' + names.get(value)); }
      } else if (node.type === 'Literal' && field === 'value' && typeof value === 'string' && value.startsWith('/$bunfs/root/chunk-')) tokens.push('"<chunk>"');
      else visit(value, node, field);
    }
    tokens.push('}');
  }
  visit(ast);
  return { sha256: hash(tokens.join('')), identifiers: [...names.keys()],
    exports: ast.body.filter(n => n.type === 'ExportNamedDeclaration').flatMap(n => (n.specifiers ?? []).map(s => ({ local: s.local?.name, exported: s.exported?.name }))),
    imports: ast.body.filter(n => n.type === 'ImportDeclaration').map(n => ({ source: n.source.value, specifiers: n.specifiers.map(s => ({ local: s.local.name, imported: s.imported?.name })) })) };
}

export function compareNativeModuleShapes(before, after) {
  const index = new Map();
  for (const entry of after) { const entries = index.get(entry.shape.sha256) ?? []; entries.push(entry); index.set(entry.shape.sha256, entries); }
  const modules = before.map(entry => {
    const matches = index.get(entry.shape.sha256) ?? [], selected = matches.length === 1 ? matches[0] : undefined;
    return { before: entry.path, sourceSha256: entry.sourceSha256, shapeSha256: entry.shape.sha256,
      status: selected ? 'unique-structural-candidate' : matches.length ? 'ambiguous' : 'unmatched',
      candidates: matches.map(m => ({ path: m.path, sourceSha256: m.sourceSha256 })),
      ...(selected ? { identifiers: entry.shape.identifiers.map((name, i) => [name, selected.shape.identifiers[i]]),
        exports: entry.shape.exports.map((spec, i) => ({ before: spec, after: selected.shape.exports[i] })),
        imports: entry.shape.imports.map((spec, i) => ({ before: spec, after: selected.shape.imports[i] })) } : {}) };
  });
  const edges = new Map();
  for (const row of modules) for (const edge of row.imports ?? []) {
    if (!edge.before.source.startsWith('/$bunfs/root/') || !edge.after?.source.startsWith('/$bunfs/root/')) continue;
    const targets = edges.get(edge.before.source) ?? new Set(); targets.add(edge.after.source); edges.set(edge.before.source, targets);
  }
  return { status: 'needs-source-review', qualification: 'Structural candidates are not alpha-equivalence proofs, export compatibility, runtime eligibility or app acceptance. Never adopt ambiguous or conflicting edges automatically.',
    modules, dependencyConflicts: [...edges].filter(([, targets]) => targets.size > 1).map(([source, targets]) => ({ source, targets: [...targets].sort() })) };
}

async function loadModules(directory, selected) {
  const manifest = await readCompleteRun(directory, 'extract'), bytes = await readFile(join(directory, 'inventory.json'));
  if (hash(bytes) !== manifest.inventorySha256) throw Error('Extraction inventory integrity changed');
  const entries = [], unparsed = [], sources = new Map();
  for (const item of JSON.parse(bytes)) {
    if (!item.path.endsWith('.js') || selected && !selected.has(basename(item.path))) continue;
    if (!item.path.startsWith('files/') || item.path.split('/').some(part => !/^[a-zA-Z0-9._-]+$/.test(part) || part === '.' || part === '..')) throw Error('Unexpected source inventory path');
    const source = await readFile(join(directory, 'extracted', item.path));
    if (hash(source) !== item.sha256) throw Error('Recovered source integrity changed: ' + item.path);
    let shape;
    try { shape = nativeModuleShape(source.toString('utf8')); } catch (error) { unparsed.push({ path: item.path, error: error.message }); continue; }
    sources.set(item.path, source.toString('utf8'));
    entries.push({ path: item.path, sourceSha256: item.sha256, shape });
  }
  return { entries, unparsed, sources, targetSha256: manifest.inputs.targetSha256, inventorySha256: hash(bytes) };
}

export async function auditNativePlatformModules(beforeDirectory, afterDirectory, adapterFiles, output, { exportGraph = false, adapterRuntime } = {}) {
  const references = new Set(), adapters = [];
  for (const path of adapterFiles) { const bytes = await readFile(path); adapters.push({ path, sha256: hash(bytes) }); for (const match of bytes.toString('utf8').matchAll(/chunk-[a-z0-9]+\.js/g)) references.add(match[0]); }
  const runtimeBytes = adapterRuntime ? await readFile(adapterRuntime) : undefined;
  if (runtimeBytes) exportGraph = true;
  const run = await createRun(output, 'native-platform-map', { beforeDirectory, afterDirectory, adapters, exportGraph, ...(runtimeBytes ? { adapterRuntime: { path: adapterRuntime, sha256: hash(runtimeBytes) } } : {}), toolSha256: hash(await readFile(new URL(import.meta.url))), exportGraphToolSha256: hash(await readFile(new URL('./native-export-graph.mjs', import.meta.url))) });
  try {
    const before = await loadModules(beforeDirectory, exportGraph ? undefined : references), after = await loadModules(afterDirectory);
    const selected = before.entries.filter(entry => references.has(basename(entry.path)));
    let graph;
    if (exportGraph) {
      const beforeGraph = buildNativeExportGraph(before.sources), afterGraph = buildNativeExportGraph(after.sources);
      const graphRecords = {};
      for (const [name, value] of [['before', beforeGraph], ['after', afterGraph]]) {
        const bytes = JSON.stringify(value) + '\n', path = 'export-definitions-' + name + '.json';
        await writeFile(join(run.directory, path), bytes); graphRecords[name] = { path, sha256: hash(bytes) };
      }
      graph = { ...compareNativeExportGraphs(beforeGraph, afterGraph, new Set(selected.map(entry => entry.path))), records: graphRecords };
      if (runtimeBytes) {
        const used = inspectNativeAdapterExports(runtimeBytes.toString('utf8'));
        graph.consumed = used.map(item => {
          const entry = graph.exports.find(candidate => candidate.file === 'files/' + item.module && candidate.exported === item.exported);
          return { ...item, ...(entry ? { origin: entry.origin, candidates: entry.candidates, definitionOnlyCandidates: afterGraph.exports.filter(candidate => candidate.base === entry.base) } : { unresolvedOrigin: true }) };
        });
      }
    }
    const report = { ...compareNativeModuleShapes(selected, after.entries), ...(graph ? { exportGraph: graph } : {}), targets: { before: before.targetSha256, after: after.targetSha256 },
      inventoryHashes: { before: before.inventorySha256, after: after.inventorySha256 },
      references: [...references].sort(), missingBefore: [...references].filter(name => !before.entries.some(e => basename(e.path) === name)),
      unparsed: { before: before.unparsed, after: after.unparsed } };
    const bytes = JSON.stringify(report, null, 2) + '\n'; await writeFile(join(run.directory, 'candidates.json'), bytes);
    await run.finish({ status: 'complete', disposition: 'needs-source-review', reportSha256: hash(bytes), referencedModules: references.size,
      uniqueCandidates: report.modules.filter(m => m.status === 'unique-structural-candidate').length, dependencyConflicts: report.dependencyConflicts.length });
    return { directory: run.directory, ...run.manifest };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
