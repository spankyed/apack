import {readFile} from 'node:fs/promises';
import {dirname,join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {parse} from 'acorn';
function walk(node,visit){
 if(!node||typeof node!=='object'||!node.type)return;visit(node);
 for(const value of Object.values(node)){if(Array.isArray(value)){for(const child of value)walk(child,visit);}else if(value?.type)walk(value,visit);}
}
const name=node=>node?.name??node?.value;
function contains(node,value){let found=false;walk(node,item=>{if(item.type==='Literal'&&item.value===value)found=true;});return found;}
function binds(node,keys){let found=false;walk(node,item=>{if(item.type==='ObjectPattern'&&keys.every(key=>item.properties.some(property=>name(property.key)===key)))found=true;});return found;}
function one(items,label){if(items.length!==1)throw Error(label+': expected one source binding, found '+items.length);return items[0];}
async function source(file){const bytes=await readFile(file);if(bytes.length>16*1024*1024)throw Error('Source exceeds audit bound');const text=bytes.toString('utf8');return{file,bytes,text,ast:parse(text,{ecmaVersion:'latest',sourceType:'module'})};}
const hash=value=>createHash('sha256').update(value).digest('hex');
const site=(input,node,symbol)=>({file:input.file,symbol,utf16Start:node.start,utf16End:node.end,byteStart:Buffer.byteLength(input.text.slice(0,node.start)),byteEnd:Buffer.byteLength(input.text.slice(0,node.end)),sha256:hash(input.text.slice(node.start,node.end))});
/** Resolve the command's imported control binding; equal minified names in other modules are irrelevant. */
export async function inspectNativeBackgroundConfirmation(file){
 const input=await source(file),functions=input.ast.body.filter(node=>node.type==='FunctionDeclaration'),variables=input.ast.body.filter(node=>node.type==='VariableDeclaration').flatMap(node=>node.declarations);
 const view=one(functions.filter(node=>contains(node,'Background this session?')&&binds(node,['onDone','prompt','seed','messages','isMidTurn'])),'Background command view');
 const producer=one(variables.filter(node=>node.init?.type==='ArrowFunctionExpression'&&contains(node.init,'tengu_background_already_bg')),'Background command producer');
 let calls=[];walk(producer.init,node=>{if(node.type==='CallExpression'&&node.arguments[0]?.type==='Identifier'&&node.arguments[0].name===view.id.name)calls.push(node);});one(calls,'Producer-to-view call');
 calls=[];walk(view,node=>{if(node.type==='CallExpression'&&node.arguments[0]?.type==='Identifier'&&node.arguments[1]?.type==='ObjectExpression'&&['onConfirm','onCancel','confirmLabel'].every(key=>node.arguments[1].properties.some(property=>name(property.key)===key))&&node.arguments[1].properties.some(property=>name(property.key)==='cancelLabel'&&property.value?.value==='Stay'))calls.push(node);});
 const control=one(calls,'Background Stay/confirm control'),local=control.arguments[0].name;
 const imports=input.ast.body.filter(node=>node.type==='ImportDeclaration').flatMap(node=>node.specifiers.filter(spec=>spec.type==='ImportSpecifier'&&spec.local.name===local).map(spec=>({node,spec})));
 const imported=one(imports,'Background imported control');if(!/^\/\$bunfs\/root\/chunk-[a-z0-9]+\.js$/u.test(imported.node.source.value))throw Error('Unexpected original control module path');
 const controls=await source(join(dirname(file),basename(imported.node.source.value))),exportName=name(imported.spec.imported);
 const exported=one(controls.ast.body.filter(node=>node.type==='ExportNamedDeclaration').flatMap(node=>node.specifiers??[]).filter(spec=>name(spec.exported)===exportName),'Original control export');
 const fn=one(controls.ast.body.filter(node=>node.type==='FunctionDeclaration'&&node.id.name===name(exported.local)&&binds(node,['onConfirm','onCancel','confirmLabel','cancelLabel'])),'Original confirmation control function');
 return{sourceSha256:hash(input.bytes),controlSourceSha256:hash(controls.bytes),producer:site(input,producer.init,producer.id.name),view:site(input,view,view.id.name),controlImport:site(input,imported.spec,local),control:site(controls,fn,fn.id.name),qualification:'Static original bindings and fingerprints only. This command panel is distinct from left_arrow_confirm; runtime eligibility and app acceptance require independent evidence.'};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){const rows=[];for(const file of process.argv.slice(2))rows.push(await inspectNativeBackgroundConfirmation(file));if(!rows.length)throw Error('Usage: native-background-confirmation.mjs <immutable-core-module> [...]');console.log(JSON.stringify(rows,null,2));}
