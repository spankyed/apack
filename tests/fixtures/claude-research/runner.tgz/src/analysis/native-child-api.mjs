import ts from 'typescript';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {zstdDecompressSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const limit=8*1024*1024;
const digest=value=>createHash('sha256').update(value).digest('hex');
const nameOf=node=>node.name&&(ts.isIdentifier(node.name)||ts.isStringLiteral(node.name))?node.name.text:undefined;

/** Enumerate each declared session/prompt/ui/process context separately; never infer runtime authority. */
export function inspectChildApiDeclarations(source,file='claude-code.d.ts'){
 if(Buffer.byteLength(source)>limit)throw Error('Declaration source exceeds 8 MiB bound');
 const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
 if(ast.parseDiagnostics.length)throw Error('Declaration source has syntax errors');
 const contexts=[];let visited=0;
 function walk(node,path=[]){
  if(++visited>500000)throw Error('Declaration syntax exceeds node bound');
  const name=nameOf(node),next=name?[...path,name]:path;
  if(ts.isPropertySignature(node)&&['session','prompt','ui','process'].includes(name)&&node.type&&ts.isTypeLiteralNode(node.type)){
   const start=node.getStart(ast),body=source.slice(start,node.end);
   contexts.push({path:next.join('.'),utf16Start:start,utf16End:node.end,sha256:digest(body),members:node.type.members.map(member=>({name:nameOf(member)??'<computed>',kind:ts.SyntaxKind[member.kind],typeKind:member.type?ts.SyntaxKind[member.type.kind]:null})),qualification:'Declared members only; no execution, eligibility, lexical resolution or usable child transport is established.'});
  }
  ts.forEachChild(node,child=>walk(child,next));
 }
 walk(ast);
 return{sourceSha256:digest(source),bytes:Buffer.byteLength(source),contexts};
}

if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const path=process.argv[2];if(!path)throw Error('Usage: native-child-api.mjs <declaration.txt[.zst]>');
 const input=await readFile(path);if(input.length>limit)throw Error('Declaration input exceeds 8 MiB bound');
 const bytes=path.endsWith('.zst')?zstdDecompressSync(input,{maxOutputLength:limit}):input;
 console.log(JSON.stringify({inputSha256:digest(input),...inspectChildApiDeclarations(bytes.toString('utf8'),path)},null,2));
}
