import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join,posix} from 'node:path';
import {hash,readCompleteRun,createRun} from '../artifacts/runs.mjs';
import {analysisProvenance} from './provenance.mjs';
const key = p => !p.computed ? p.key?.name ?? p.key?.value : p.key?.type==='Literal' ? p.key.value : null;
const text = n => n?.type==='Literal' && typeof n.value==='string' ? n.value : null;
const action = n => typeof n==='string' && /^[a-zA-Z][\w-]*:[\w-]+$/.test(n);
/** Syntax candidates only: examples, declarations, defaults and effective bindings remain distinct. */
export function inspectKeybindings(source) {
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),blocks=[],actionArrays=[],aliasMaps=[];
 function bindings(node,conditional=false) {
  if(node.type==='LogicalExpression')return bindings(node.right,true);
  if(node.type!=='ObjectExpression')return [{status:'unresolved-spread',start:node.start,end:node.end,conditional}];
  return node.properties.flatMap(p=>p.type==='SpreadElement'?bindings(p.argument,conditional):
   [{status:text(p.value)!==null||p.value.type==='Literal'&&p.value.value===null?'literal':'unresolved-action',
    key:key(p),action:text(p.value),unbind:p.value.type==='Literal'&&p.value.value===null,
    conditional,computed:p.computed,start:p.start,end:p.end}]);
 }
 function walk(node) {
  if(!node?.type)return;
  if(node.type==='ObjectExpression') {
   if(node.properties.length && node.properties.every(p=>p.type==='Property'&&action(key(p))&&action(text(p.value))))
    aliasMaps.push({start:node.start,end:node.end,aliases:node.properties.map(p=>({from:key(p),to:text(p.value),start:p.start,end:p.end}))});
   const props=node.properties.filter(p=>p.type==='Property'),context=props.find(p=>key(p)==='context'),map=props.find(p=>key(p)==='bindings');
   if(text(context?.value)!==null&&map?.value.type==='ObjectExpression')blocks.push({context:text(context.value),start:node.start,end:node.end,bindings:bindings(map.value)});
  }
  if(node.type==='ArrayExpression'&&node.elements.length>=8&&node.elements.every(e=>action(text(e))))actionArrays.push({start:node.start,end:node.end,actions:node.elements.map(text)});
  for(const value of Object.values(node))if(Array.isArray(value)){for(const child of value)if(child?.type)walk(child);}else if(value?.type)walk(value);
 }
 walk(ast);return {blocks,actionArrays,aliasMaps};
}
export async function catalogKeybindings(extractionRun,output) {
 const parent=await readCompleteRun(extractionRun,'extract'),bytes=await readFile(join(extractionRun,'inventory.json'));
 if(hash(bytes)!==parent.inventorySha256)throw Error('Extraction inventory changed');
 const run=await createRun(output,'keybindings',{extraction:extractionRun,targetSha256:parent.inputs.targetSha256,inventorySha256:hash(bytes),...await analysisProvenance(new URL(import.meta.url))});
 try {
  const modules=[];let scannedModules=0;
  for(const file of JSON.parse(bytes)) {
   if(file.loader!=='js')continue;
   if(typeof file.path!=='string'||posix.isAbsolute(file.path)||file.path.includes('\\')||file.path.split('/').includes('..'))throw Error('Unsafe extracted path');
   if(!['latin1','utf8','utf-8'].includes(file.encoding))throw Error('Unsupported source encoding');
   const source=await readFile(join(extractionRun,'extracted',file.path));if(hash(source)!==file.sha256)throw Error('Source changed: '+file.path);
   const found=inspectKeybindings(source.toString(file.encoding));scannedModules++;
   if(found.blocks.length||found.actionArrays.length||found.aliasMaps.length)modules.push({path:file.path,sha256:hash(source),encoding:file.encoding,...found});
  }
  const result={scannedModules,modules,qualification:'Static context/bindings objects, literal colon-action arrays of at least eight entries, and literal action-to-action maps. Includes examples and declarations, not only registered defaults. Conditional/computed/unresolved bindings remain explicit. No execution, effective user keymap, handler reachability or availability proof.'};
  const encoded=JSON.stringify(result,null,2)+'\n';await writeFile(join(run.directory,'keybindings.json'),encoded);
  const counts={scannedModules,modules:modules.length,blocks:modules.reduce((n,m)=>n+m.blocks.length,0),actionArrays:modules.reduce((n,m)=>n+m.actionArrays.length,0),aliasMaps:modules.reduce((n,m)=>n+m.aliasMaps.length,0)};
  await run.finish({status:'complete',outputSha256:hash(encoded),...counts});return {directory:run.directory,status:'complete',...counts};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
