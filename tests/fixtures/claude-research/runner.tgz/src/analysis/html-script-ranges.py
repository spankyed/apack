"""Read HTML as data; report script/handler spans without executing browser code."""
import hashlib
import html.parser
import json
from pathlib import Path
import sys

class ScriptRanges(html.parser.HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=False)
        self.source = source
        self.lines = [0]
        self.lines.extend(i + 1 for i, char in enumerate(source) if char == '\n')
        self.scripts = []
        self.handlers = []
        self.current = None

    def position(self):
        line, column = self.getpos()
        return self.lines[line - 1] + column

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        start = self.position()
        if tag == 'script':
            self.current = {'attrs': attrs, 'bodyStart': start + len(self.get_starttag_text()),
                            'bodyEnd': len(self.source), 'closed': False}
            self.scripts.append(self.current)
        for name, value in attrs.items():
            if name.startswith('on') or (value or '').strip().lower().startswith('javascript:'):
                self.handlers.append({'tag': tag, 'name': name, 'tagStart': start})

    def handle_endtag(self, tag):
        if tag == 'script' and self.current is not None:
            self.current.update(bodyEnd=self.position(), closed=True)
            self.current = None

result = []
for item in json.load(sys.stdin):
    raw = Path(item['file']).read_bytes()
    source = raw.decode('utf-16le' if item['encoding'] == 'utf16le' else item['encoding'])
    parser = ScriptRanges(source)
    parser.feed(source)
    parser.close()
    result.append({'path': item['path'], 'sha256': hashlib.sha256(raw).hexdigest(),
                   'scripts': parser.scripts, 'handlers': parser.handlers})
parser_bytes = Path(html.parser.__file__).read_bytes()
json.dump({'python': sys.version.split()[0], 'parserSha256': hashlib.sha256(parser_bytes).hexdigest(),
           'assets': result}, sys.stdout)
