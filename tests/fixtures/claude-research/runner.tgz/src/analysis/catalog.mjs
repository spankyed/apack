import { parse } from 'acorn';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createRun, hash, readCompleteRun } from '../artifacts/runs.mjs';
import { analysisProvenance } from './provenance.mjs';

function propertyName(node) {
  if (node.computed) return null;
  return node.key?.name ?? node.key?.value ?? null;
}

function fluentModifiers(node) {
  const result = [];
  while (node?.type === 'CallExpression' && node.callee.type === 'MemberExpression') {
    if (!node.callee.computed && node.callee.property.type === 'Identifier') result.push(node.callee.property.name);
    node = node.callee.object;
  }
  return result.sort();
}

function subtypeValue(node) {
  if (node?.type === 'Literal' && typeof node.value === 'string') return { value: node.value, form: 'literal' };
  if (node?.type !== 'CallExpression') return null;
  if (node.callee.type === 'MemberExpression' &&
      ['optional', 'nullable', 'nullish', 'describe', 'default', 'readonly', 'brand'].includes(node.callee.property.name)) {
    return subtypeValue(node.callee.object);
  }
  const value = node.arguments[0];
  if (value?.type === 'Literal' && typeof value.value === 'string' &&
      (node.callee.type === 'Identifier' || node.callee.property?.name === 'literal')) {
    return { value: value.value, form: 'factory-candidate' };
  }
  return null;
}

function memberPath(node) {
  if (node?.type === 'Identifier') return node.name;
  if (node?.type !== 'MemberExpression') return null;
  const parent = memberPath(node.object);
  const key = node.computed ? node.property.value : node.property.name;
  return parent && typeof key === 'string' ? `${parent}.${key}` : null;
}

/** Static candidates only: message examples, SDK schemas and server handlers can share a subtype. */
export function inspectCatalogSource(source) {
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module', locations: true, allowHashBang: true });
  const controls = [], dispatches = [], registrations = [], names = [], unresolved = [];
  const location = node => ({ start: node.start, end: node.end, line: node.loc.start.line });
  function walk(node) {
    if (node.type === 'ObjectExpression') {
      const subtype = node.properties.find(p => p.type === 'Property' && propertyName(p) === 'subtype');
      if (subtype) {
        const label = subtypeValue(subtype.value);
        if (label) controls.push({ subtype: label.value, form: label.form, ...location(node),
          fields: node.properties.filter(p => p.type === 'Property').map(p => ({
            name: propertyName(p), modifiers: fluentModifiers(p.value),
          })).sort((a, b) => String(a.name).localeCompare(String(b.name))) });
        else unresolved.push({ role: 'subtype', ...location(subtype) });
      }
      const name = node.properties.find(p => p.type === 'Property' && propertyName(p) === 'name');
      if (name) {
        if (name.value.type === 'Literal' && typeof name.value.value === 'string' &&
            /^[\w.:/\-]{1,120}$/.test(name.value.value)) names.push({ name: name.value.value, ...location(name) });
        else unresolved.push({ role: 'name', ...location(name) });
      }
    }
    if (node.type === 'BinaryExpression' && ['===', '=='].includes(node.operator)) {
      for (const [member, value] of [[node.left, node.right], [node.right, node.left]]) {
        if (member.type === 'MemberExpression' && member.property.name === 'subtype' &&
            value.type === 'Literal' && typeof value.value === 'string') {
          dispatches.push({ subtype: value.value, kind: 'comparison', receiver: memberPath(member), ...location(node) });
        }
      }
    }
    if (node.type === 'SwitchStatement' && node.discriminant.type === 'MemberExpression' &&
        node.discriminant.property.name === 'subtype') {
      for (const branch of node.cases) if (branch.test?.type === 'Literal' && typeof branch.test.value === 'string') {
        dispatches.push({ subtype: branch.test.value, kind: 'switch', receiver: memberPath(node.discriminant), ...location(branch) });
      }
    }
    if (node.type === 'CallExpression' && node.callee.type === 'MemberExpression' &&
        ['command', 'option', 'requiredOption'].includes(node.callee.property.name)) {
      const argument = node.arguments[0];
      if (argument?.type === 'Literal' && typeof argument.value === 'string') {
        registrations.push({ kind: node.callee.property.name, value: argument.value, ...location(node) });
      } else unresolved.push({ role: `cli-${node.callee.property.name}`, ...location(node) });
    }
    if (node.type === 'NewExpression' && node.arguments[0]?.type === 'Literal' &&
        typeof node.arguments[0].value === 'string' && /^--?[a-z]/i.test(node.arguments[0].value)) {
      registrations.push({ kind: 'option-constructor-candidate', value: node.arguments[0].value, ...location(node) });
    }
    for (const [key, value] of Object.entries(node)) {
      if (key === 'loc') continue;
      if (Array.isArray(value)) { for (const child of value) if (child?.type) walk(child); }
      else if (value?.type) walk(value);
    }
  }
  walk(ast);
  return { controls, dispatches, registrations, names, unresolved };
}

export async function catalogExtraction(extraction, output) {
  const parent = await readCompleteRun(extraction, 'extract');
  const inventoryBytes = await readFile(join(extraction, 'inventory.json'));
  if (hash(inventoryBytes) !== parent.inventorySha256) throw new Error('Extraction inventory changed');
  const run = await createRun(output, 'catalog', { extraction, parentRunId: parent.id,
    targetSha256: parent.inputs.targetSha256, ...await analysisProvenance(new URL(import.meta.url)) });
  try {
    const modules = [], failures = [];
    for (const file of JSON.parse(inventoryBytes).filter(f => f.loader === 'js')) {
      const bytes = await readFile(join(extraction, 'extracted', file.path));
      if (hash(bytes) !== file.sha256) throw new Error(`Extracted source changed: ${file.path}`);
      try {
        modules.push({ path: file.path, sha256: file.sha256,
          ...inspectCatalogSource(bytes.toString(file.encoding === 'latin1' ? 'latin1' : 'utf8')) });
      } catch (error) { failures.push({ path: file.path, error: error.message }); }
    }
    const controls = [...new Set(modules.flatMap(m => m.controls.map(c => c.subtype)))].sort();
    const qualification = 'Static candidates across SDK, CLI, bridges and dependencies; each needs mode/handler/runtime classification. Locations use Acorn source-string offsets.';
    const data = JSON.stringify({ schemaVersion: 1, targetSha256: parent.inputs.targetSha256,
      qualification, modules, failures }, null, 2) + '\n';
    await writeFile(join(run.directory, 'catalog.json'), data);
    const summary = { modules: modules.length, controlNames: controls,
      dispatchSites: modules.reduce((n, m) => n + m.dispatches.length, 0),
      registrationSites: modules.reduce((n, m) => n + m.registrations.length, 0),
      unresolvedSites: modules.reduce((n, m) => n + m.unresolved.length, 0), failures, qualification };
    await writeFile(join(run.directory, 'summary.json'), JSON.stringify(summary, null, 2) + '\n');
    await run.finish({ status: failures.length ? 'failed' : 'complete', parsed: modules.length,
      controlNames: controls.length, failures, catalogSha256: hash(Buffer.from(data)) });
    return { directory: run.directory, status: run.manifest.status, ...summary };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}

function signatures(data) {
  return new Set(data.modules.flatMap(m => [
    ...m.controls.filter(c => c.form === 'factory-candidate').map(c => JSON.stringify({
      kind: 'control-schema-candidate', subtype: c.subtype, fields: c.fields,
    })),
    ...m.registrations.map(r => JSON.stringify({ kind: r.kind, value: r.value })),
  ]));
}

export function compareCatalogData(before, after) {
  const a = signatures(before), b = signatures(after);
  return { added: [...b].filter(s => !a.has(s)).sort().map(JSON.parse),
    removed: [...a].filter(s => !b.has(s)).sort().map(JSON.parse) };
}

/** Byte-level review leads, independent of candidate-signature equality or bundle filenames. */
export function compareCatalogSources(before, after) {
  function grouped(data) {
    const groups = new Map();
    for (const module of data.modules) {
      if (!/^[a-f0-9]{64}$/.test(module.sha256) || typeof module.path !== 'string') {
        throw new Error('Catalog module lacks source hash/path; regenerate catalog');
      }
      const entries = groups.get(module.sha256) ?? [];
      entries.push(module);
      groups.set(module.sha256, entries);
    }
    for (const entries of groups.values()) entries.sort((a, b) => a.path.localeCompare(b.path));
    return groups;
  }
  const a = grouped(before), b = grouped(after);
  const beforeOnly = [], afterOnly = [];
  let unchangedOccurrences = 0;
  function lead(module) {
    return { path: module.path, sha256: module.sha256,
      controlCandidates: [...new Set(module.controls.map(c => c.subtype))].sort(),
      dispatchCandidates: [...new Set(module.dispatches.map(d => d.subtype))].sort(),
      registrationCandidates: module.registrations.map(r => ({ kind: r.kind, value: r.value })),
    };
  }
  for (const digest of [...new Set([...a.keys(), ...b.keys()])].sort()) {
    const oldEntries = a.get(digest) ?? [], newEntries = b.get(digest) ?? [];
    const common = Math.min(oldEntries.length, newEntries.length);
    unchangedOccurrences += common;
    beforeOnly.push(...oldEntries.slice(common).map(lead));
    afterOnly.push(...newEntries.slice(common).map(lead));
  }
  return { unchangedOccurrences, beforeOnly, afterOnly,
    qualification: 'Exact source-byte multiset comparison, ignoring paths. Unmatched modules are review leads, not paired edits or changed features; minification/rebundling can change bytes. No semantic normalization, transitive dependency analysis or gate/handler equivalence is inferred. Duplicate occurrence identity is not stable.',
  };
}

export async function compareCatalogs(before, after, output) {
  const parents = await Promise.all([before, after].map(p => readCompleteRun(p, 'catalog')));
  const indexes = await Promise.all([before, after].map(async (p, i) => {
    const bytes = await readFile(join(p, 'catalog.json'));
    if (hash(bytes) !== parents[i].catalogSha256) throw new Error(`Catalog changed: ${p}`);
    return JSON.parse(bytes);
  }));
  const run = await createRun(output, 'compare-catalogs', { before, after, parentRunIds: parents.map(p => p.id),
    targetSha256: parents.map(p => p.inputs.targetSha256), ...await analysisProvenance(new URL(import.meta.url)) });
  try {
    const result = { ...compareCatalogData(...indexes), sourceChanges: compareCatalogSources(...indexes),
      qualification: 'Selected field/modifier and CLI registration signatures plus exact module-byte review leads; opaque types, gates, reachability and runtime semantics still require review.' };
    const data = JSON.stringify(result, null, 2) + '\n';
    await writeFile(join(run.directory, 'comparison.json'), data);
    await run.finish({ status: 'complete', added: result.added.length, removed: result.removed.length,
      comparisonSha256: hash(Buffer.from(data)),
      sourceModulesBeforeOnly: result.sourceChanges.beforeOnly.length, sourceModulesAfterOnly: result.sourceChanges.afterOnly.length });
    return { directory: run.directory, added: result.added.length, removed: result.removed.length,
      sourceModulesBeforeOnly: result.sourceChanges.beforeOnly.length, sourceModulesAfterOnly: result.sourceChanges.afterOnly.length };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
