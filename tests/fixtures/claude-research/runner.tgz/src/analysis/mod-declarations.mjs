import {inspectKitImports} from './code-assets.mjs';
import ts from 'typescript';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
import {analysisProvenance} from './provenance.mjs';

/** Selected declaration syntax, not type-checking, execution or runtime eligibility. */
export function inspectModDeclarations(source,encoding='utf8') {
  const ast=ts.createSourceFile('claude-code.d.ts',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
  if(ast.parseDiagnostics.length)throw new Error('Plugin declarations have syntax diagnostics');
  const range=n=>({byteStart:Buffer.byteLength(source.slice(0,n.getStart(ast)),encoding),byteEnd:Buffer.byteLength(source.slice(0,n.end),encoding)});
  const module=ast.statements.find(n=>ts.isModuleDeclaration(n)&&n.name.text==='claude-code');
  if(!module?.body||!ts.isModuleBlock(module.body))throw new Error('Missing claude-code declaration module');
  const declarations=module.body.statements;
  const root=declarations.find(n=>ts.isInterfaceDeclaration(n)&&n.name.text==='CoreEngineInterface');
  if(!root)throw new Error('Missing CoreEngineInterface');
  const references=n=>{const names=new Set();function visit(v){if(ts.isTypeReferenceNode(v))names.add(v.typeName.getText(ast));ts.forEachChild(v,visit)}visit(n);return [...names].sort()};
  const signature=n=>({...range(n),typeParameters:n.typeParameters?.map(p=>p.name.text)??[],parameters:n.parameters.map(p=>({name:p.name.getText(ast),optional:Boolean(p.questionToken),rest:Boolean(p.dotDotDotToken),type:p.type?.getText(ast)??null,...range(p)})),returnType:n.type?.getText(ast)??null,references:references(n)});
  const aliases=new Map(declarations.filter(n=>ts.isTypeAliasDeclaration(n)).map(n=>[n.name.text,n]));
  function resolveType(node,seen=new Set(),path=[]) {
    if(!node)return {node,path};
    if(ts.isParenthesizedTypeNode(node))return resolveType(node.type,seen,path);
    if(ts.isTypeReferenceNode(node)&&ts.isIdentifier(node.typeName)&&!node.typeArguments?.length) {
      const name=node.typeName.text,alias=aliases.get(name);
      if(!alias||alias.typeParameters?.length||seen.has(name))return {node,path};
      return resolveType(alias.type,new Set([...seen,name]),[...path,{name,...range(alias)}]);
    }
    if(ts.isIndexedAccessTypeNode(node)&&ts.isLiteralTypeNode(node.indexType)&&ts.isStringLiteral(node.indexType.literal)) {
      const object=resolveType(node.objectType,seen,path),name=node.indexType.literal.text;
      if(object.node&&ts.isTypeLiteralNode(object.node)) {
        const member=object.node.members.find(m=>m.name?.text===name);
        if(member?.type)return resolveType(member.type,seen,[...object.path,{property:name,...range(member)}]);
      }
    }
    return {node,path};
  }
  const namespaces=[],identity=[],unresolved=[];
  for(const property of root.members) {
    const name=property.name?.text;
    if(name==='plugin'){identity.push({name,...range(property)});continue;}
    if(!name||!property.type||!ts.isTypeLiteralNode(property.type)){unresolved.push({name:name??null,reason:'unsupported-namespace-shape',...range(property)});continue;}
    const methods=[];
    for(const member of property.type.members){
      const method=member.name?.text;
      if(!method){unresolved.push({namespace:name,reason:'unnamed-member',...range(member)});continue;}
      const resolved=resolveType(member.type),type=resolved.node;
      const calls=ts.isMethodSignature(member)?[member]:type&&ts.isFunctionTypeNode(type)?[type]:type&&ts.isTypeLiteralNode(type)?type.members.filter(ts.isCallSignatureDeclaration):[];
      methods.push({name:method,...range(member),resolution:resolved.path,signatures:calls.map(signature)});
      if(!calls.length)unresolved.push({namespace:name,name:method,reason:'unsupported-call-shape',...range(member)});
    }
    namespaces.push({name,...range(property),methods});
  }
  const helpers=declarations.filter(n=>['On','Register','Next','StreamNext','Registration','EngineInterface','EngineInterfaceBuilt'].includes(n.name?.text)).map(n=>({name:n.name.text,kind:ts.SyntaxKind[n.kind],...range(n),references:references(n)}));
  return {root:range(root),identity,namespaces,helpers,unresolved,qualification:'Literal CoreEngineInterface namespace and callable declarations, including overloads. Local nongeneric aliases and literal indexed members are followed with source ranges. Signature text and references are navigation evidence; imported/generic/inherited/conditional types and runtime gates are not evaluated.'};
}

export function compareModDeclarationNames(declaration,runtimeRoot) {
  const declared=new Set(declaration.namespaces.flatMap(n=>n.methods.map(m=>`${n.name}.${m.name}`)));
  const runtime=new Set(runtimeRoot.namespaces.flatMap(n=>(n.methods??[]).map(m=>`${n.name}.${m.name}`)));
  return {declared:declared.size,runtime:runtime.size,shared:[...declared].filter(n=>runtime.has(n)).sort(),declarationOnly:[...declared].filter(n=>!runtime.has(n)).sort(),runtimeOnly:[...runtime].filter(n=>!declared.has(n)).sort(),qualification:'Name comparison only. Runtime candidates may be filtered or wrapped; equal names do not prove argument compatibility, availability or app exposure.'};
}

/** Query declaration value exports only; unresolved globals are not a full typecheck result. */
function createDeclarationQuery(source) {
  const file='/virtual/claude-api.d.ts',ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true);
  if(ast.parseDiagnostics.length)throw new Error('Declaration syntax diagnostics');
  const options={noLib:true,noResolve:true,noEmit:true};
  const host=ts.createCompilerHost(options);
  host.getSourceFile=path=>path===file?ast:undefined;host.fileExists=path=>path===file;host.readFile=path=>path===file?source:undefined;
  const checker=ts.createProgram([file],options,host).getTypeChecker();
  return {ast,checker};
}

export function inspectDeclaredModuleValues(source) {
  const {ast,checker}=createDeclarationQuery(source);
  return ast.statements.filter(ts.isModuleDeclaration).map(module=>({name:module.name.text,values:checker.getExportsOfModule(checker.getSymbolAtLocation(module.name)).filter(symbol=>Boolean(symbol.flags&ts.SymbolFlags.Value)).map(symbol=>({name:symbol.name,declarations:(symbol.declarations??[]).map(node=>({kind:ts.SyntaxKind[node.kind],byteStart:Buffer.byteLength(source.slice(0,node.getStart(ast))),byteEnd:Buffer.byteLength(source.slice(0,node.end))}))})),qualification:'TypeScript module value-export lookup in an isolated in-memory noEmit/noLib/noResolve program. Not a successful typecheck, runtime export or availability assertion.'}));
}

/** Fixed core event keys and source-defined augmentation families; not firing or admission. */
export function inspectDeclaredEvents(source,nativeEntries) {
  const {ast,checker}=createDeclarationQuery(source);
  const module=ast.statements.find(n=>ts.isModuleDeclaration(n)&&n.name.text==='claude-code');
  if(!module?.body||!ts.isModuleBlock(module.body))throw new Error('Missing claude-code declaration module');
  const declarations=new Map(module.body.statements.filter(n=>n.name).map(n=>[n.name.text,n]));
  const range=n=>({byteStart:Buffer.byteLength(source.slice(0,n.getStart(ast))),byteEnd:Buffer.byteLength(source.slice(0,n.end))});
  function keys(name){
    const node=declarations.get(name);if(!node)return null;
    const type=checker.getTypeAtLocation(node);
    if(type.flags&(ts.TypeFlags.Any|ts.TypeFlags.Unknown))throw new Error('Unresolved declared event key type: '+name);
    return {name,...range(node),keys:checker.getPropertiesOfType(type).map(symbol=>symbol.name).sort()};
  }
  const families=['EngineEventOf','ClassicEventOf','OpEventOf'].map(keys).filter(Boolean),core=keys('CoreEventOf');
  if(!core)throw new Error('Missing CoreEventOf');
  const results=keys('ResultOf'),chunks=keys('ChunkOf'),native=new Set(nativeEntries.map(e=>e.name));
  const events=core.keys.map(name=>({name,families:families.filter(f=>f.keys.includes(name)).map(f=>f.name),resultDeclared:results?results.keys.includes(name):null,streamChunkDeclared:chunks?chunks.keys.includes(name):null}));
  return {families,core,results,chunks,events,declarationOnly:core.keys.filter(name=>!native.has(name)),registryOnly:[...native].filter(name=>!core.keys.includes(name)).sort(),dynamicFamilies:['EngineInterface','PluginNoun','NounEvent','NounEventOf'].filter(name=>declarations.has(name)).map(name=>({name,...range(declarations.get(name)),population:'Not enumerated: plugin declarations/augmentation determine names; noLib query results are not absence proof.'})),qualification:'TypeScript fixed core key lookup in an isolated noEmit/noLib/noResolve program, cross-checked against the selected native registry. Argument/result semantics, generic constraints, augmentation populations, eligibility and event firing are not established.'};
}

export function inspectKitExportNames(fragments) {
  const graph=inspectKitImports(fragments),names=new Map(fragments.map(f=>[f.path,new Set(f.exports.filter(e=>e.name!=='*').map(e=>e.name))]));
  let changed=true,passes=0;
  while(changed&&passes++<=fragments.length){changed=false;for(const fragment of fragments)for(const item of fragment.exports.filter(e=>e.name==='*'&&e.source)){
    const edge=graph.edges.find(e=>e.module===fragment.path&&e.source===item.source);
    if(!edge)continue;
    for(const name of names.get(edge.target)??[])if(name!=='default'&&!names.get(fragment.path).has(name)){names.get(fragment.path).add(name);changed=true;}
  }}
  return {entry:'index.js',names:[...(names.get('index.js')??[])].sort(),unresolvedImports:graph.unresolved,qualification:'Static explicit names plus star reexports, excluding default propagation. Cyclic namespaces are collected to a fixed point. This does not resolve ambiguous star bindings, evaluate modules or establish intended public support.'};
}

export function compareModValueSurfaces(source,assets) {
  const declarations=inspectDeclaredModuleValues(source),state=assets.find(a=>/\/state-library\.js-/.test(a.path)),kit=assets.find(a=>a.fragments);
  const testing=kit?inspectKitExportNames(kit.fragments):null;
  const runtime={'claude-code':state?.exports.map(e=>e.name).filter(n=>n&&n!=='*'),'claude-code/testing':testing?.names};
  return {modules:declarations.map(module=>{const declared=module.values.map(v=>v.name),names=runtime[module.name];return {...module,runtimeNames:names??null,declarationOnly:names?declared.filter(n=>!names.includes(n)):null,runtimeOnly:names?names.filter(n=>!declared.includes(n)):null};}),testing,qualification:'Selected declaration and virtual-module export names only. Extra runtime helpers may be internal; declared-only constants in this path are not assumed importable. Native loader gates and actual runtime behavior remain unverified.'};
}

export async function catalogModDeclarations(assetRun,modRun,output) {
  const parent=await readCompleteRun(assetRun,'code-assets');
  const assetsBytes=await readFile(join(assetRun,'code-assets.json'));
  if(hash(assetsBytes)!==parent.outputSha256)throw new Error('Asset catalog changed');
  const mod=await readCompleteRun(modRun,'mod-api');
  const modBytes=await readFile(join(modRun,'mod-api.json'));
  if(hash(modBytes)!==mod.outputSha256)throw new Error('Mod catalog changed');
  if(parent.inputs.targetSha256!==mod.inputs.targetSha256)throw new Error('Target mismatch');
  const assets=JSON.parse(assetsBytes).assets.filter(a=>/\/claude-code\.d\.ts-.*\.txt(?:\.zst)?$/.test(a.path));
  const roots=JSON.parse(modBytes).publicAdapters;
  if(assets.length!==1||roots.length!==1)throw new Error('Expected one declaration asset and one runtime adapter root');
  const asset=assets[0],bytes=await readFile(join(assetRun,asset.decodedPath));
  if(hash(bytes)!==asset.decodedSha256)throw new Error('Decoded declarations changed');
  const run=await createRun(output,'mod-declarations',{assetRun,parentRunId:parent.id,modRun,modRunId:mod.id,targetSha256:parent.inputs.targetSha256,declarationSha256:asset.decodedSha256,...await analysisProvenance(new URL(import.meta.url)),assetHelperSha256:hash(await readFile(new URL('./code-assets.mjs',import.meta.url))),typescript:ts.version,typescriptSha256:hash(await readFile(new URL(import.meta.resolve('typescript'))))});
  try {
    const declaration=inspectModDeclarations(bytes.toString(asset.sourceEncoding),asset.sourceEncoding);
    const comparison=compareModDeclarationNames(declaration,roots[0]);
    const valueSurface=compareModValueSurfaces(bytes.toString(asset.sourceEncoding),JSON.parse(assetsBytes).assets);
    const nativeEntries=JSON.parse(modBytes).registries.flatMap(r=>r.entries);
    const eventSurface=inspectDeclaredEvents(bytes.toString(asset.sourceEncoding),nativeEntries);
    const result={declaration,comparison,valueSurface,eventSurface};const resultBytes=Buffer.from(JSON.stringify(result,null,2)+'\n');
    await writeFile(join(run.directory,'mod-declarations.json'),resultBytes);
    const summary={namespaces:declaration.namespaces.length,methods:comparison.declared,signatures:declaration.namespaces.reduce((sum,n)=>sum+n.methods.reduce((s,m)=>s+m.signatures.length,0),0),unresolved:declaration.unresolved.length,declarationOnly:comparison.declarationOnly,runtimeOnly:comparison.runtimeOnly,declaredCoreEvents:eventSurface.events.length,eventDeclarationOnly:eventSurface.declarationOnly,eventRegistryOnly:eventSurface.registryOnly,declaredOnlyValues:valueSurface.modules.filter(m=>m.declarationOnly?.length).map(m=>({module:m.name,names:m.declarationOnly})),runtimeExtraValueCandidates:valueSurface.modules.filter(m=>m.runtimeOnly?.length).map(m=>({module:m.name,count:m.runtimeOnly.length}))};
    await run.finish({status:'complete',outputSha256:hash(resultBytes),...summary});
    return {directory:run.directory,status:'complete',...summary};
  }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}

/** Normalized declaration syntax including referenced types, not runtime compatibility. */
export function compareModDeclarationSyntax(beforeSource,afterSource) {
  const printer=ts.createPrinter({removeComments:true});
  function declarations(source){
    const ast=ts.createSourceFile('api.d.ts',source,ts.ScriptTarget.Latest,true);
    if(ast.parseDiagnostics.length)throw new Error('Declaration syntax diagnostics');
    const result=new Map();
    for(const module of ast.statements.filter(ts.isModuleDeclaration)){
      if(!module.body||!ts.isModuleBlock(module.body))throw new Error('Unsupported declaration module');
      for(const node of module.body.statements){
        const name=node.name?.text??(ts.isVariableStatement(node)?node.declarationList.declarations.map(d=>d.name.getText(ast)).join(','):null);
        const identity={module:module.name.text,kind:ts.SyntaxKind[node.kind],name};
        const item={...identity,sha256:hash(Buffer.from(printer.printNode(ts.EmitHint.Unspecified,node,ast))),byteStart:Buffer.byteLength(source.slice(0,node.getStart(ast))),byteEnd:Buffer.byteLength(source.slice(0,node.end))};
        const key=JSON.stringify(identity),items=result.get(key)??[];items.push(item);result.set(key,items);
      }
    }
    if(!result.size)throw new Error('No ambient module declarations');
    for(const items of result.values())items.sort((a,b)=>a.sha256.localeCompare(b.sha256));
    return result;
  }
  const a=declarations(beforeSource),b=declarations(afterSource),added=[],removed=[],changed=[];let unchangedIdentities=0;
  for(const key of [...new Set([...a.keys(),...b.keys()])].sort()){
    const old=a.get(key),next=b.get(key);
    if(!old)added.push(...next);else if(!next)removed.push(...old);
    else if(JSON.stringify(old.map(i=>i.sha256))!==JSON.stringify(next.map(i=>i.sha256)))changed.push({identity:JSON.parse(key),before:old,after:next});
    else unchangedIdentities++;
  }
  return {added,removed,changed,unchangedIdentities,qualification:'TypeScript printer-normalized ambient declaration syntax, excluding comments and source positions from matching. Grouped overload identities preserve multiplicity. No type equivalence, runtime adapter/gate analysis or behavioral compatibility is inferred.'};
}

export async function compareModTypes(before,after,output) {
  async function load(directory){
    const parent=await readCompleteRun(directory,'code-assets'),bytes=await readFile(join(directory,'code-assets.json'));
    if(hash(bytes)!==parent.outputSha256)throw new Error('Asset catalog changed');
    const assets=JSON.parse(bytes).assets.filter(a=>/\/claude-code\.d\.ts-.*\.txt(?:\.zst)?$/.test(a.path));
    if(assets.length!==1)throw new Error('Expected one declaration asset');
    const asset=assets[0],raw=await readFile(join(directory,asset.decodedPath));
    if(hash(raw)!==asset.decodedSha256)throw new Error('Decoded declarations changed');
    return {parent,asset,source:raw.toString(asset.sourceEncoding)};
  }
  const inputs=await Promise.all([before,after].map(load));
  const run=await createRun(output,'compare-mod-types',{before,after,parentRunIds:inputs.map(i=>i.parent.id),targetSha256:inputs.map(i=>i.parent.inputs.targetSha256),declarationSha256:inputs.map(i=>i.asset.decodedSha256),...await analysisProvenance(new URL(import.meta.url)),assetHelperSha256:hash(await readFile(new URL('./code-assets.mjs',import.meta.url))),typescript:ts.version,typescriptSha256:hash(await readFile(new URL(import.meta.resolve('typescript'))))});
  try{
    const result=compareModDeclarationSyntax(...inputs.map(i=>i.source)),bytes=Buffer.from(JSON.stringify(result,null,2)+'\n');
    await writeFile(join(run.directory,'comparison.json'),bytes);const summary={added:result.added.length,removed:result.removed.length,changed:result.changed.length,unchangedIdentities:result.unchangedIdentities};
    await run.finish({status:'complete',outputSha256:hash(bytes),...summary});return {directory:run.directory,status:'complete',...summary};
  }catch(error){await run.finish({status:'failed',error:error.message});throw error;}
}
