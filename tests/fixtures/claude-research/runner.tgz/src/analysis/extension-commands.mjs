import {parse} from 'acorn';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createRun,hash,readCompleteRun} from '../artifacts/runs.mjs';
const property=node=>node?.type==='MemberExpression'&&!node.computed?node.property.name:null;
const key=node=>node.type==='Property'&&!node.computed?node.key.name??node.key.value:null;
function visit(node,fn){if(!node||typeof node!=='object')return;fn(node);for(const [name,value] of Object.entries(node)){if(name==='start'||name==='end')continue;if(Array.isArray(value))for(const child of value)visit(child,fn);else if(value&&typeof value==='object')visit(value,fn)}}
function boolean(node){if(node?.type==='Literal'&&typeof node.value==='boolean')return node.value;if(node?.type==='UnaryExpression'&&node.operator==='!'&&node.argument.type==='Literal')return !node.argument.value;return null}
function chain(node){const calls=[];while(node?.type==='CallExpression'&&property(node.callee)){calls.push({method:property(node.callee),args:node.arguments});node=node.callee.object}return{calls,receiver:node?.type==='Identifier'?node.name:null}}
/** Literal chained action registrations only; does not identify every Commander instance or root path. */
export function inspectExtensionCommands(source){
 const ast=parse(source,{ecmaVersion:'latest',sourceType:'module'}),readers=new Set(),entries=[];
 for(const node of ast.body){
  if(node.type!=='FunctionDeclaration')continue;
  let stdin=false;visit(node.body,value=>{if(value.type==='MemberExpression'&&property(value)==='stdin'&&value.object?.type==='Identifier'&&value.object.name==='Bun')stdin=true});
  if(stdin)readers.add(node.id.name);
 }
 visit(ast,node=>{
  if(node.type!=='CallExpression'||property(node.callee)!=='action')return;
  const {calls,receiver}=chain(node),registration=calls.find(call=>call.method==='command');
  if(registration?.args[0]?.type!=='Literal'||typeof registration.args[0].value!=='string')return;
  const options=registration.args[1];let hidden=false,visibilityUnresolved=false;
  if(options){
   if(options.type!=='ObjectExpression')visibilityUnresolved=true;
   else{const field=options.properties.find(p=>key(p)==='hidden');hidden=field?boolean(field.value):false;visibilityUnresolved=hidden===null||options.properties.some(p=>p.type==='SpreadElement'||p.computed)}
  }
  if(calls.some(call=>call.method==='hideHelp')){hidden=true;visibilityUnresolved=false}
  if(!hidden&&!visibilityUnresolved)return;
  const imports=[],awaitedCalls=[],stdinReaderCalls=[];
  visit(node.arguments[0],value=>{
   if(value.type==='ImportExpression'&&value.source.type==='Literal'&&typeof value.source.value==='string')imports.push({path:value.source.value,start:value.start,end:value.end});
   if(value.type==='AwaitExpression'&&value.argument.type==='CallExpression'&&value.argument.callee.type==='Identifier'){
    const name=value.argument.callee.name;awaitedCalls.push(name);
    if(readers.has(name)){const limit=value.argument.arguments[0];stdinReaderCalls.push({reader:name,numericArgument:limit?.type==='Literal'&&typeof limit.value==='number'?limit.value:null,start:value.start,end:value.end})}
   }
  });
  entries.push({name:registration.args[0].value,receiver,hidden:hidden===true,visibilityUnresolved,start:node.start,end:node.end,options:calls.filter(call=>['option','requiredOption'].includes(call.method)).map(call=>({method:call.method,flags:call.args[0]?.type==='Literal'?call.args[0].value:null})),imports,awaitedCalls:[...new Set(awaitedCalls)],stdinReaderCalls});
 });return entries;
}
export async function catalogExtensionCommands(extractionRun,output){
 const parent=await readCompleteRun(extractionRun,'extract'),inventoryBytes=await readFile(join(extractionRun,'inventory.json'));
 if(hash(inventoryBytes)!==parent.inventorySha256)throw Error('Extraction inventory changed');
 const run=await createRun(output,'extension-commands',{targetSha256:parent.inputs.targetSha256,extractionRun,scannerSha256:hash(await readFile(new URL(import.meta.url))),parser:'acorn@8.15.0'});
 try{
  const modules=[];
  for(const file of JSON.parse(inventoryBytes)){
   if(file.loader!=='js')continue;const bytes=await readFile(join(extractionRun,'extracted',file.path));if(hash(bytes)!==file.sha256)throw Error(`Source changed: ${file.path}`);
   const entries=inspectExtensionCommands(bytes.toString(file.encoding));if(entries.length)modules.push({path:file.path,sha256:file.sha256,encoding:file.encoding,offsetUnits:'decoded-string',entries});
  }
  const findings={modules,qualification:'Static candidates: explicit hidden/unknown visibility literal command().action() chains. Receiver root paths, dynamic/addCommand registration, imported gates, numeric argument meaning, schemas and effects require review; absence is not proof of absence.'};
  const bytes=Buffer.from(JSON.stringify(findings,null,2)+'\n');await writeFile(join(run.directory,'extension-commands.json'),bytes);await run.finish({status:'complete',outputSha256:hash(bytes)});return{directory:run.directory,status:'complete',modules:modules.length,entries:modules.flatMap(module=>module.entries).length};
 }catch(error){await run.finish({status:'failed',error:error.message});throw error}
}
