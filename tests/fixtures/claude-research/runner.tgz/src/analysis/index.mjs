import { parse } from 'acorn';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createRun, hash, readCompleteRun } from '../artifacts/runs.mjs';
import { analysisProvenance } from './provenance.mjs';

export function inspectJavaScript(source) {
  const ast = parse(source, { ecmaVersion: 'latest', sourceType: 'module', locations: true, allowHashBang: true });
  const strings = [], imports = [], properties = [], calls = [];
  function walk(node) {
    if (!node || typeof node !== 'object') return;
    if (node.type === 'Literal' && typeof node.value === 'string') {
      strings.push({ value: node.value, start: node.start, end: node.end, line: node.loc.start.line });
    }
    if (node.type === 'ImportDeclaration' || node.type === 'ExportNamedDeclaration' || node.type === 'ExportAllDeclaration') {
      if (node.source) imports.push(node.source.value);
    }
    if (node.type === 'ImportExpression' && node.source.type === 'Literal') imports.push(node.source.value);
    if (node.type === 'Property' && !node.computed) {
      const key = node.key.name ?? node.key.value;
      if (['subtype', 'type', 'name', 'command', 'permissionMode'].includes(key)) {
        properties.push({ key, start: node.start, end: node.end, line: node.loc.start.line,
          literal: node.value.type === 'Literal' ? node.value.value : null });
      }
    }
    if (node.type === 'CallExpression' && node.callee.type === 'MemberExpression') {
      const method = node.callee.property.name;
      if (['command', 'option', 'addOption'].includes(method)) {
        calls.push({ method, argument: node.arguments[0]?.value ?? null, start: node.start, line: node.loc.start.line });
      }
    }
    for (const [key, value] of Object.entries(node)) {
      if (key === 'loc') continue;
      if (Array.isArray(value)) { for (const child of value) if (child?.type) walk(child); }
      else if (value?.type) walk(value);
    }
  }
  walk(ast);
  return { strings, imports, properties, calls };
}

export async function indexExtraction(extraction, output) {
  const parent = await readCompleteRun(extraction, 'extract');
  const inventoryBytes = await readFile(join(extraction, 'inventory.json'));
  if (hash(inventoryBytes) !== parent.inventorySha256) throw new Error('Extraction inventory changed');
  const inventory = JSON.parse(inventoryBytes);
  const run = await createRun(output, 'index', { extraction, parentRunId: parent.id, targetSha256: parent.inputs.targetSha256,
    ...await analysisProvenance(new URL(import.meta.url)) });
  try {
    const modules = [], failures = [];
    for (const file of inventory.filter(f => f.loader === 'js')) {
      const bytes = await readFile(join(extraction, 'extracted', file.path));
      if (hash(bytes) !== file.sha256) throw new Error(`Extracted source changed: ${file.path}`);
      try {
        const source = bytes.toString(file.encoding === 'latin1' ? 'latin1' : 'utf8');
        modules.push({ path: file.path, sha256: file.sha256, ...inspectJavaScript(source) });
      } catch (error) { failures.push({ path: file.path, error: error.message }); }
    }
    const data = { schemaVersion: 1, targetSha256: parent.inputs.targetSha256, modules, failures };
    const text = JSON.stringify(data);
    await writeFile(join(run.directory, 'index.json'), text + '\n');
    await run.finish({ status: failures.length ? 'failed' : 'complete', parsed: modules.length, failures,
      indexSha256: hash(Buffer.from(text + '\n')) });
    return { directory: run.directory, status: run.manifest.status, parsed: modules.length, failures };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}

export async function compareIndexes(before, after, output) {
  const parents = await Promise.all([before, after].map(p => readCompleteRun(p, 'index')));
  const indexes = await Promise.all([before, after].map(async (p, i) => {
    const bytes = await readFile(join(p, 'index.json'));
    if (hash(bytes) !== parents[i].indexSha256) throw new Error(`Index changed: ${p}`);
    return JSON.parse(bytes);
  }));
  // Strings are review candidates, not a behavioral feature-parity determination.
  const values = indexes.map(data => new Set(data.modules.flatMap(m => m.strings.map(s => s.value))));
  const run = await createRun(output, 'compare', { before, after, parentRunIds: parents.map(p => p.id),
    targetSha256: parents.map(p => p.inputs.targetSha256), ...await analysisProvenance(new URL(import.meta.url)) });
  try {
    const result = { added: [...values[1]].filter(s => !values[0].has(s)).sort(),
      removed: [...values[0]].filter(s => !values[1].has(s)).sort(), qualification: 'Literal changes require source and runtime review.' };
    const data = JSON.stringify(result, null, 2) + '\n';
    await writeFile(join(run.directory, 'comparison.json'), data);
    await run.finish({ status: 'complete', added: result.added.length, removed: result.removed.length,
      comparisonSha256: hash(Buffer.from(data)) });
    return { directory: run.directory, added: result.added.length, removed: result.removed.length };
  } catch (error) { await run.finish({ status: 'failed', error: error.message }); throw error; }
}
