// Use the pinned extension's existing profiler; no custom native instrumentation or execution change.
import assert from 'node:assert/strict';
import { readFileSync,writeFileSync,existsSync,openSync,readSync,closeSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { setTimeout as pause } from 'node:timers/promises';
import { SqliteDatabase } from '../../src/sqlite/database.ts';
import { createEarsEngine } from '../../src/index.ts';
import { startHeartbeat } from './load-metrics.ts';
const [corpusPath,truthFile,snapshot,output]=process.argv.slice(2);assert(output&&!existsSync(output));
const sha=b=>createHash('sha256').update(b).digest('hex');
const fileSha=file=>{const h=createHash('sha256'),fd=openSync(file,'r'),b=Buffer.allocUnsafe(1024*1024);try{for(;;){const n=readSync(fd,b,0,b.length,null);if(!n)break;h.update(b.subarray(0,n));}return h.digest('hex');}finally{closeSync(fd);}};
const manifestBytes=readFileSync(join(corpusPath,'manifest.json')),manifest=JSON.parse(manifestBytes),truthBytes=readFileSync(truthFile),truth=JSON.parse(truthBytes);
assert.equal(sha(manifestBytes),truth.manifestSha256);assert.equal(fileSha(join(corpusPath,'corpus.f32')),manifest.files['corpus.f32'].sha256);
assert.equal(truth.protocol,'ears-real-vector-fresh-truth/1');assert.deepEqual(truth.queryOrdinals,Array.from({length:100},(_,q)=>499+999*q));
const fd=openSync(join(corpusPath,'corpus.f32'),'r'),queryBytes=truth.queryOrdinals.map(i=>{const b=Buffer.alloc(1536*4);assert.equal(readSync(fd,b,0,b.length,i*b.length),b.length);return b;});closeSync(fd);
assert.equal(sha(Buffer.concat(queryBytes)),truth.queriesSha256);const vectors=queryBytes.map(b=>Array.from(new Float32Array(b.buffer,b.byteOffset,1536))),excluded=new Set(truth.excludedOrdinals);
const before=fileSha(join(snapshot,'data.sqlite3'));assert.equal(before,process.env.EARS_POLICY_DATABASE_SHA256);
const report={protocol:'ears-owner-projection-query/1',qualification:false,source:process.env.EARS_TEST_SOURCE,partition:'updated-only internal attribution; not complete acceptance',
 manifestSha256:sha(manifestBytes),truthSha256:sha(truthBytes),databaseSha256:before,cohorts:[],counterUnit:'upstream hardware timer; relative ticks, not asserted CPU time',node:process.version,arch:process.arch,platform:process.platform};
const save=()=>writeFileSync(output,JSON.stringify(report,null,2)+'\n');let db;
try{
 db=new SqliteDatabase({path:snapshot,readOnly:true,nativeVectorExtension:process.env.EARS_VEC1_EXTENSION});assert.equal(db.sql.readonly,true);
 const model=db.get("SELECT generation,model_sha256 FROM vector_training WHERE state='ready'");assert.equal(model.model_sha256,process.env.EARS_POLICY_MODEL_SHA256);report.model=model;
 const physical=db.get("SELECT id FROM vector_indexes WHERE generation=? AND state='ready'",[model.generation]);assert(physical);
 const table='ann_'+physical.id;
 const profile=()=>{const row=db.get("SELECT qprofile FROM vec1cat WHERE database='main' AND name=?",[table]);assert(row&&row.qprofile);return JSON.parse(row.qprofile);};
 const initial=profile();assert(initial.total);report.initialProfile=initial;
 const e=createEarsEngine({database:db});
 const originalAll=db.all.bind(db);let nativeCalls=0;const plans=new Map();
 report.ownerProjection=process.env.EARS_OWNER_PROJECTION;
 db.all=(sql,parameters=[])=>{
  const match=/^SELECT owner FROM (ann_\d+)\(\?,\?\) WHERE /.exec(sql);
  if(match){
   nativeCalls++;
   if(process.env.EARS_OWNER_PROJECTION==='sql'){
    const table=match[1];
    sql=sql.replace(/^SELECT owner FROM ann_\d+\(\?,\?\)/,
      `SELECT b.c0 owner,b.id __base_id FROM ${table}(?,?) q LEFT JOIN ${table}_base b ON b.id=q.rowid`);
   }
   if(!plans.has(sql))plans.set(sql,parameters);
  }
  const rows=originalAll(sql,parameters);
  if(match&&process.env.EARS_OWNER_PROJECTION==='sql')return rows.map(row=>{
   if(row.__base_id==null)throw Object.assign(new Error('Missing native base row'),{code:'CORRUPT'});
   const {__base_id,...result}=row;return result;
  });
  return rows;
 };
 for(const size of [1000,10000,99900])for(const percent of [100,10,1]){
  const expected=truth.cohorts.find(c=>c.phase==='updated'&&c.size===size&&c.scopePercent===percent);assert(expected);
  const startProfile=profile(),wallStartMs=Date.now(),callsBefore=nativeCalls,samples=[],pulse=startHeartbeat(1);
  try{for(let q=0;q<100;q++){
   let query=e.query('Row');if(size!==99900)query=query.where(size===1000?'prefix1000':'prefix10000',true);if(percent!==100)query=query.where(percent===10?'scope10':'scope1',true);
   const at=performance.now(),wallStartMs=Date.now(),hits=query.near(vectors[q],{k:10}).hits(),ms=performance.now()-at,ordinals=hits.map(h=>Number(h.id.slice(4))),answer=expected.answers[q].ordinals;
   assert.equal(ordinals.length,answer.length);assert.equal(new Set(ordinals).size,ordinals.length);assert(ordinals.every(i=>i>=0&&i<size&&i%100<percent&&i%97!==0&&!excluded.has(i)));assert(hits.every(h=>Number.isFinite(h.score)));
   samples.push({q,ms,wallStartMs,wallEndMs:Date.now(),recall:ordinals.filter(i=>answer.includes(i)).length/answer.length,ordinals,scores:hits.map(h=>h.score)});await pause(0);
  }}finally{pulse.stop();}
  const endProfile=profile(),delta=Object.fromEntries(Object.keys(startProfile).map(k=>[k,{cnt:endProfile[k].cnt-startProfile[k].cnt,cycle:endProfile[k].cycle-startProfile[k].cycle}]));
  assert.equal(delta.total.cnt,nativeCalls-callsBefore);
  if(delta.total.cnt)assert(delta.total.cycle>0,'The native hardware timer must actually be supported');
  const cohort={size,scopePercent:percent,eligible:expected.eligible,wallStartMs,wallEndMs:Date.now(),samples,heartbeatSamples:pulse.delaysMs,nativeCandidateCalls:nativeCalls-callsBefore,profileDelta:delta,
   meanRecall:samples.reduce((n,q)=>n+q.recall,0)/100};
  if(cohort.eligible>4096)assert(cohort.nativeCandidateCalls>=100);
  report.cohorts.push(cohort);save();console.log(JSON.stringify({size,percent,calls:cohort.nativeCandidateCalls,profile:delta}));
 }
 report.ownerLookupPlans=[...plans].map(([sql,parameters])=>({sql,plan:originalAll('EXPLAIN QUERY PLAN '+sql,parameters)}));report.maxRssKiB=process.resourceUsage().maxRSS;
 db.all=originalAll;db.close();db=undefined;report.unchangedDatabaseSha256=fileSha(join(snapshot,'data.sqlite3'));assert.equal(report.unchangedDatabaseSha256,before);report.completed=true;save();
}catch(error){report.failure={message:error.message,stack:error.stack};save();throw error;}
finally{db?.close();}
