from pathlib import Path
import subprocess,json,os,hashlib
r=Path('/electron');o=Path('/results');report={'source':'measured scalar execution policy WIP after02e4914f03','scope':'All five changed EARS inputs mounted over verified a9 dependencies; full EARS typecheck and focused suites','steps':[]}
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_EVALUATION_BACKEND':'sqlite','EARS_VEC1_EXTENSION':'/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so'}
 commands=[('types',['node','node_modules/typescript/bin/tsc','-p','packages/apack-ears','--incremental','false']),
 ('elmdb',['node','node_modules/vitest/vitest.mjs','run','--config','/electron/packages/apack-ears/vitest.config.ts','--root','/electron/packages/apack-ears','tests/engine/queries.spec.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile=/results/elmdb.json']),
 ('sqlite',['node','node_modules/vitest/vitest.mjs','run','--config','/electron/packages/apack-ears/vitest.config.ts','--root','/electron/packages/apack-ears','tests/engine/queries.spec.ts','tests/engine/storage-port.spec.ts','tests/sqlite/query-cost.spec.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile=/results/sqlite.json'])]
 for name,args in commands:
  env['EARS_EVALUATION_BACKEND']='' if name=='elmdb' else 'sqlite'
  with(o/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  report['steps'].append({'name':name,'exitCode':p.returncode});assert p.returncode==0,(name,(o/(name+'.log')).read_text()[-5000:]);print(name+' passed',flush=True)
 report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
