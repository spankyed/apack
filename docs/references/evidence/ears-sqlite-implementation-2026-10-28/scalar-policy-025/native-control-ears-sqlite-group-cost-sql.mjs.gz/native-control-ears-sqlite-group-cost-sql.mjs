import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';import {tmpdir} from 'node:os';import {join} from 'node:path';
import {createEarsEngine} from '/electron/packages/apack-ears/src/index.ts';
import {openDatabase as native} from '/electron/packages/apack-ears/src/lmdb/index.ts';
import {openDatabase as sqlite} from '/electron/packages/apack-ears/src/sqlite/index.ts';
const report={source:'28dfa80beb',qualification:false,scope:'Source runtime with all changed EARS files over frozen dependencies; synthetic warm query CPU pilot, syncs disabled, not application qualification',samples:[]};
for(const size of [1000,5000,20000])for(const backend of size===5000?['sqlite','elmdb']:['elmdb','sqlite']){
 const path=mkdtempSync(join(tmpdir(),'ears-group-cost-'));const db=(backend==='sqlite'?sqlite:native)({path,syncs:false,schema:{types:{Row:{required:[],fields:{rank:{type:'number'},bucket:{type:'string'}}}},relations:{},roles:[]}});
 try{
  const e=createEarsEngine({database:db}),ids=Array.from({length:size},(_,i)=>'Row-'+String(i).padStart(5,'0'));
  e.transact(()=>ids.forEach((id,i)=>e.create('Row',{id,rank:i,bucket:'bucket-'+i%20})));await db.indexesReady();
  const expected={rank:new Map(ids.map((id,i)=>[i,[id]])),bucket:new Map()};ids.forEach((id,i)=>{const key='bucket-'+i%20;const held=expected.bucket.get(key)??[];held.push(id);expected.bucket.set(key,held);});
  for(let round=0;round<3;round++)for(const field of ['rank','bucket'])for(const operation of ['distinct','groupBy']){
   const cpu=process.cpuUsage(),at=performance.now(),result=operation==='distinct'?e.query('Row').distinct(field).ids():e.query('Row').groupBy(field),ms=performance.now()-at,used=process.cpuUsage(cpu);
   if(operation==='distinct')assert.deepEqual(result,field==='rank'?ids:ids.slice(0,20));else assert.deepEqual(result,expected[field]);
   report.samples.push({size,backend,round,timed:round>0,field,operation,ms,cpuUserMs:used.user/1000,cpuSystemMs:used.system/1000});
  }
  writeFileSync('/results/probe.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({size,backend,samples:report.samples.length}));
 }finally{db.close();rmSync(path,{recursive:true,force:true});}
}
report.completed=true;writeFileSync('/results/probe.json',JSON.stringify(report,null,2)+'\n');
