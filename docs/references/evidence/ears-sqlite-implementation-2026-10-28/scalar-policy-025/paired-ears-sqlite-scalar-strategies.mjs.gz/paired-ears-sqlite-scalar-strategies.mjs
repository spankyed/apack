import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';import {tmpdir} from 'node:os';import {join} from 'node:path';
import {createEarsEngine} from '/electron/packages/apack-ears/src/index.ts';import {openDatabase} from '/electron/packages/apack-ears/src/sqlite/index.ts';
const report={source:'28dfa80beb',qualification:false,scope:'Same SQLite snapshot, alternating SQL and forced batched fallback. Scratch metadata-guard override only; no production option, parameters or stored data change.',samples:[]};
for(const size of [1000,5000,20000]){
 const path=mkdtempSync(join(tmpdir(),'ears-scalar-strategies-'));const db=openDatabase({path,syncs:false,schema:{types:{Row:{required:[],fields:{rank:{type:'number'},bucket:{type:'string'}}}},relations:{},roles:[]}});
 const layout=db.values.layout.bind(db.values),all=db.all.bind(db);let variant='sql',aggregates=0;
 try{
  const e=createEarsEngine({database:db}),ids=Array.from({length:size},(_,i)=>'Row-'+String(i).padStart(5,'0'));
  e.transact(()=>ids.forEach((id,i)=>e.create('Row',{id,rank:i,bucket:'bucket-'+i%20})));await db.indexesReady();
  const expected={rank:new Map(ids.map((id,i)=>[i,[id]])),bucket:new Map()};ids.forEach((id,i)=>{const key='bucket-'+i%20,held=expected.bucket.get(key)??[];held.push(id);expected.bucket.set(key,held);});
  // Seeding cached the authoritative Row layout. Refusing only the optional SQL guard selects the
  // ordinary batched implementation; hydration still reads its cached real layout and stored cells.
  db.values.layout=(...args)=>variant==='sql'?layout(...args):undefined;
  db.all=(sql,parameters=[])=>{if(sql.includes('GROUP BY kind,value COLLATE BINARY'))aggregates++;return all(sql,parameters);};
  const before=db.sequence;
  for(let round=0;round<6;round++)for(const field of ['rank','bucket'])for(const operation of ['distinct','groupBy'])for(variant of round%2?['batched','sql']:['sql','batched']){
   aggregates=0;const cpu=process.cpuUsage(),at=performance.now(),result=operation==='distinct'?e.query('Row').distinct(field).ids():e.query('Row').groupBy(field),ms=performance.now()-at,used=process.cpuUsage(cpu);
   assert.equal(aggregates,variant==='sql'?1:0,'Strategy must actually execute');
   if(operation==='distinct')assert.deepEqual(result,field==='rank'?ids:ids.slice(0,20));else assert.deepEqual(result,expected[field]);
   assert.equal(db.sequence,before);report.samples.push({size,variant,round,timed:round>0,field,operation,ms,cpuUserMs:used.user/1000,cpuSystemMs:used.system/1000});
  }
  writeFileSync('/results/probe.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({size,samples:report.samples.length}));
 }finally{db.values.layout=layout;db.all=all;db.close();rmSync(path,{recursive:true,force:true});}
}
assert.equal(report.samples.length,144);report.completed=true;writeFileSync('/results/probe.json',JSON.stringify(report,null,2)+'\n');
