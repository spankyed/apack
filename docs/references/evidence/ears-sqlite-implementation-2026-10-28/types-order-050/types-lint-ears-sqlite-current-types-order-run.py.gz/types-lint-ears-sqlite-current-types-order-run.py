from pathlib import Path
import subprocess,json,os,hashlib
r=Path('/electron');o=Path('/results');report={'source':'050b935a78','scope':'All five changed EARS inputs mounted over verified a9 dependencies; full EARS typecheck and focused suites','steps':[]}
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_EVALUATION_BACKEND':'sqlite','EARS_VEC1_EXTENSION':'/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so'}
 commands=[('types',['node','node_modules/typescript/bin/tsc','-p','packages/apack-ears','--incremental','false']),('lint',['node_modules/.bin/oxlint','packages/apack-ears/src/sqlite/numeric-order.ts','packages/apack-ears/src/sqlite/vectors.ts','packages/apack-ears/tests/sqlite/query-cost.spec.ts','packages/apack-ears/tests/sqlite/vector-models.spec.ts','packages/apack-ears/bench/watch-stress.ts','-D','correctness']),('tests',['node','node_modules/vitest/vitest.mjs','run','--config','packages/apack-ears/vitest.config.ts','--root','packages/apack-ears','tests/sqlite/query-cost.spec.ts','tests/sqlite/vector-models.spec.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile=/results/tests.json'])]
 for name,args in commands:
  with(o/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  report['steps'].append({'name':name,'exitCode':p.returncode});assert p.returncode==0,(name,(o/(name+'.log')).read_text()[-5000:]);print(name+' passed',flush=True)
 report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
