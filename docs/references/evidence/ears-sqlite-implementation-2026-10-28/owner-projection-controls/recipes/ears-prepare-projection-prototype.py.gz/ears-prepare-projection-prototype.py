from pathlib import Path
import hashlib,difflib,json
source=Path('/private/tmp/ears-direct-in-prototype-source/vec1.c');raw=source.read_text();assert hashlib.sha256(source.read_bytes()).hexdigest()=='04043ede29b2998b2cd0e7735cc696dba2158554a0bf9036e2a77849dec0425a'
s=raw
old='    pIdxInfo->idxNum = 5;';assert s.count(old)==1;s=s.replace(old,'    pIdxInfo->idxNum = bDistance ? 5 : 7;',1)
a=s.index('static int vec1FilterMethod(');before=s[:a];tail=s[a:]
old='  int rc = SQLITE_OK;\n';assert old in tail;tail=tail.replace(old,'  int rc = SQLITE_OK;\n  int bMetadataOnly = (idxNum==7);\n  if( bMetadataOnly ) idxNum = 5;\n',1)
old='''        rc = vec1PrepareSql(pTab, &pCsr->pStmt,
            "SELECT * FROM %Q.'%q_base' WHERE id=?", 
            pTab->zDb, pTab->zName
        );''';assert tail.count(old)==1
new='''        if( bMetadataOnly ){
          /* Retain base-row existence and metadata positions without loading
          ** an unused raw vector into the SQLite result registers. */
          sqlite3_str *pSql = sqlite3_str_new(pTab->db);
          char *zSql;
          int ii;
          sqlite3_str_appendall(pSql, "SELECT id,NULL");
          for(ii=0; ii<pTab->nMeta; ii++){
            sqlite3_str_appendf(pSql, ",c%d", ii);
          }
          sqlite3_str_appendf(pSql, " FROM %Q.'%q_base' WHERE id=?",
              pTab->zDb, pTab->zName);
          zSql = sqlite3_str_finish(pSql);
          if( zSql ){
            rc = vec1PrepareSql(pTab, &pCsr->pStmt, "%s", zSql);
            sqlite3_free(zSql);
          }else{
            rc = SQLITE_NOMEM;
          }
        }else{
'''+old+'''
        }'''
tail=tail.replace(old,new,1);s=before+tail
out=Path('/private/tmp/ears-projection-prototype-source');assert not out.exists();out.mkdir();(out/'baseline.c').write_text(raw);(out/'vec1.c').write_text(s);(out/'projection.patch').write_text(''.join(difflib.unified_diff(raw.splitlines(True),s.splitlines(True),fromfile='a/vec1.c',tofile='b/vec1.c')))
meta={'baselineSourceSha256':hashlib.sha256(raw.encode()).hexdigest(),'candidateSourceSha256':hashlib.sha256(s.encode()).hexdigest(),'status':'private prepared only; not compiled, run or selected','scope':'metadata-only indexed ANN lookup; full scan, index:none and vector/distance projections unchanged; base row existence seek retained'};(out/'source.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
