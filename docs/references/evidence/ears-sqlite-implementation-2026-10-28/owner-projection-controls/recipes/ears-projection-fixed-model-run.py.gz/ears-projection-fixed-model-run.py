from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');meta=json.loads((o/'source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
p=r/'native/vectors/projection-fixed-model-test.mjs';assert not p.exists();shutil.copyfile('/prototype/membership-fixed-model-test.mjs',p);assert sha(p)==meta['testSha256'];subprocess.run(['node','--check',str(p)],check=True)
models=r/'.temp/ears-projection-fixed-model-models';models.mkdir(exist_ok=False);report={'source':meta['source'],'limits':limits,'variants':[]};started=time.time()
try:
 for label,lib in [('baseline','baseline'),('projection','projection'),('sql','baseline')]:
  extension=r/'.temp/ears-projection-prototype'/lib/'vec1.so';expected=meta['projectionExtensionSha256' if lib=='projection' else 'baselineExtensionSha256'];assert sha(extension)==expected
  env={**os.environ,'EARS_TEST_SOURCE':meta['source'],'EARS_PROJECTION_VARIANT':label,'EARS_PROJECTION_MODELS_DIR':str(models)}
  with(o/(label+'.log')).open('w') as f:presult=subprocess.run(['node',str(p),str(extension),str(o/(label+'.json'))],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
  report['variants'].append({'label':label,'extensionSha256':sha(extension),'exitCode':presult.returncode});assert presult.returncode==0,(o/(label+'.log')).read_text()[-6000:]
  d=json.loads((o/(label+'.json')).read_text());assert d['completed'] and len(d['groups'])==15 and sum(g['checks'] for g in d['groups'])==735;print(label,'735 controls plus vector/distance/corruption controls complete',flush=True)
 base=json.loads((o/'baseline.json').read_text())
 for label in ('projection','sql'):
  candidate=json.loads((o/(label+'.json')).read_text());assert len(base['groups'])==len(candidate['groups'])==15
  for a,b in zip(base['groups'],candidate['groups']):
   keys=('mode','fixture','distanceResultSha256','vectorPayloadsChecked','missingBaseRefused','modelSha256');assert tuple(a.get(k) for k in keys)==tuple(b.get(k) for k in keys),(label,a['mode'],a['fixture'])
 report['completed']=True;assert sha(r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so')==meta['baselineExtensionSha256'];report['packagedBinaryUnchanged']=True
except BaseException as e:report['failure']={'message':str(e),'type':type(e).__name__};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
