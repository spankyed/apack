import assert from 'node:assert/strict';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { compileFunction } from 'node:vm';
const source=readFileSync('/private/tmp/ears-sqlite-query-integration/.github/scripts/ears-sqlite-platform.mjs','utf8');
const snippet=source.slice(source.indexOf('  const privateFiles ='),source.indexOf('  const publication ='));
const gate=compileFunction(snippet,['host','assert']);
const directory='/private/tmp/ears-strict-2cb-platform-artifacts',results=[];
for(const name of readdirSync(directory)){
 const host=JSON.parse(readFileSync(join(directory,name,'host.json'),'utf8'));
 gate(host,assert);
 const file=host.testResults.find(file=>file.name.replaceAll('\\','/').endsWith('/tests/private-file.spec.ts'));
 const target=file.assertionResults.findIndex(test=>test.fullName.endsWith('opens a writable directory descriptor for the Windows publication barrier'));
 assert(target>=0);
 for(const mutation of ['omit','skip','rename']){
  const changed=structuredClone(host),cases=changed.testResults.find(item=>item.name===file.name).assertionResults;
  if(mutation==='omit')cases.splice(target,1);
  if(mutation==='skip')cases[target].status='pending';
  if(mutation==='rename')cases[target].fullName='Unrelated passing case';
  assert.throws(()=>gate(changed,assert));results.push({platform:name,mutation,rejected:true});
 }
 const additive=structuredClone(host);
 additive.testResults.find(item=>item.name===file.name).assertionResults.push({status:'passed',fullName:'Additional future durability contract'});
 gate(additive,assert);results.push({platform:name,originalCases:file.assertionResults.length,actualAccepted:true,additionalPassedCaseAccepted:true});
}
writeFileSync('/private/tmp/ears-private-file-gate-check.json',JSON.stringify({completed:true,results},null,2)+'\n');
console.log(JSON.stringify({completed:true,results}));
