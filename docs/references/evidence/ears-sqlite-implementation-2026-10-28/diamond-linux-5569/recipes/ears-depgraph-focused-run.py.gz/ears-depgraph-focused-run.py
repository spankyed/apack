from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');meta=json.loads((o/'source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in json.loads((o/'inputs.json').read_text()).items():assert (r/n).exists() and sha(r/n)==h,n
p=r/'packages/apack-cli/tests/build/dependency-graph.integration.spec.ts';shutil.copyfile('/spec.ts',p);assert sha(p)==meta['specSha256']
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
report={'source':meta['source'],'limits':limits,'originalHookDeadlineMs':240000};started=time.time()
try:
 args=['node','scripts/with-source.mjs','node','node_modules/vitest/vitest.mjs','run','--config','vitest.integration.config.ts','--project','@apackdev/cli','packages/apack-cli/tests/build/dependency-graph.integration.spec.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile=/results/test.json']
 env={**os.environ,'APACK_PACKAGES_PREBUILT':'1','APACK_CHAIN_CORES':'2','CARGO_BUILD_JOBS':'2','npm_config_jobs':'2','NODE_OPTIONS':'--max-old-space-size=4096'};env.pop('EARS_EVALUATION_BACKEND',None)
 with(o/'test.log').open('w') as f:result=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['args']=args;report['exitCode']=result.returncode;assert result.returncode==0,(o/'test.log').read_text()[-6000:]
 d=json.loads((o/'test.json').read_text());assert d['numPassedTests']==5 and d['numFailedTests']==d['numPendingTests']==0 and d['success'];report['completed']=True
except BaseException as e:report['failure']={'message':str(e),'type':type(e).__name__};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
