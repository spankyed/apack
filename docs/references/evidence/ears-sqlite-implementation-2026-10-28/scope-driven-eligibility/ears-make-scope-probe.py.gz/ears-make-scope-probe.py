from pathlib import Path
import hashlib,json,subprocess
r=Path('/private/tmp/ears-sqlite-query-integration');s=Path('/private/tmp/ears-query-policy.mjs').read_text()
s=s.replace("protocol:'ears-readonly-query-policy/1'", "protocol:'ears-scope-driven-eligibility/1'")
s=s.replace("configurations:[{target:256,nprobe:32},{target:128,nprobe:32},{target:256,nprobe:16},{target:128,nprobe:16}]", "configurations:[{rewrite:false},{rewrite:true}]")
a=s.index(' const all=db.all.bind(db),original=');b=s.index(' const canonical=createHash',a)
s=s[:a]+''' const all=db.all.bind(db),originalSearch=db.search.vectors.search.bind(db.search.vectors);let active,context,nativeCalls=0,rewritten=0;
 db.search.vectors.search=(...args)=>{const previous=context;context=args;try{return originalSearch(...args);}finally{context=previous;}};
 db.all=(sql,parameters=[])=>{
  if(/^SELECT owner FROM ann_\\d+\\(\\?,\\?\\)/.test(sql))nativeCalls++;
  if(active?.rewrite&&context?.[0]&&sql.startsWith('WITH eligible AS MATERIALIZED (')){
   const [scope,type,name,generation,,,,exclude]=context;
   const original=`SELECT c.entity_id id,c.embedding_id,e.seq FROM chunks c JOIN entities e ON e.id=c.entity_id
      WHERE c.type=? AND c.index_name=? AND c.generation=? AND c.embedding_id IS NOT NULL
      AND c.entity_id IN (${scope.sql}) AND c.entity_id!=? LIMIT 4097`;
   assert.equal(sql.split(original).length,2,'Only the intended eligibility page may change');
   assert.deepEqual(parameters.slice(0,3),[type,name,generation]);assert.deepEqual(parameters.slice(3,3+scope.parameters.length),scope.parameters);assert.equal(parameters[3+scope.parameters.length],exclude??'');
   // DISTINCT includes physical chunk identity: duplicate scope IDs cannot duplicate chunks,
   // while separate chunks reusing the same embedding remain separate for the route threshold.
   const replacement=`SELECT DISTINCT c.entity_id id,c.embedding_id,e.seq,c.rowid chunk_rowid
      FROM (${scope.sql}) scoped CROSS JOIN chunks c ON c.entity_id=scoped.id
      JOIN entities e ON e.id=c.entity_id
      WHERE c.type=? AND c.index_name=? AND c.generation=? AND c.embedding_id IS NOT NULL
      AND c.entity_id!=? LIMIT 4097`;
   sql=sql.replace(original,replacement);
   parameters=[...scope.parameters,type,name,generation,exclude??'',...parameters.slice(4+scope.parameters.length)];rewritten++;
  }
  return all(sql,parameters);
 };
''' +s[b:]
a=s.index(' // Prove the parameterized');b=s.index(' for(const configuration of report.configurations)',a)
s=s[:a]+''' // Compare actual production answers/scores before timing either shape.
 let controls=0;
 for(const size of [1000,10000,99900])for(const percent of [100,10,1])for(let q=0;q<100;q++){
  active={rewrite:false};const baseline=queryFor(size,percent).near(vectors[q],{k:10}).hits();
  active={rewrite:true};const changed=queryFor(size,percent).near(vectors[q],{k:10}).hits();assert.deepEqual(changed,baseline);controls++;
 }
 report.productionHelperEquivalenceQueries=controls;assert.equal(controls,900);mark('equivalence-complete');save();
''' +s[b:]
s=s.replace("active=configuration;const variant={...configuration,cohorts:[]};report.variants.push(variant);mark('policy-start-'+configuration.target+'-'+configuration.nprobe);\n  db.indexBuilds.nativeVectorOwners=(generation,vector,scope,exclude)=>selectedOwners(generation,vector,scope,exclude,configuration.target);", "active=configuration;const variant={...configuration,cohorts:[]};report.variants.push(variant);mark('rewrite-start-'+configuration.rewrite);")
s=s.replace('target:configuration.target,nprobe:configuration.nprobe,','rewrite:configuration.rewrite,')
s=s.replace("mark('policy-end-'+configuration.target+'-'+configuration.nprobe)","mark('rewrite-end-'+configuration.rewrite)")
s=s.replace(' db.indexBuilds.nativeVectorOwners=original;db.all=all;db.close();db=undefined;', ' report.rewrittenEligibilityQueries=rewritten;assert(rewritten>0);db.search.vectors.search=originalSearch;db.all=all;db.close();db=undefined;')
s=s.replace("report.productionHelperEquivalenceQueries=controls;assert.equal(controls,900);mark('equivalence-complete');save();",'''report.productionHelperEquivalenceQueries=controls;assert.equal(controls,900);
 const shapes=[
  ['duplicate-ids',()=>e.query.ids(Array.from({length:5000},(_,i)=>i%2?'Row-000001':'Row-000002'))],
  ['prior-limit',()=>e.query('Row').where('prefix1000',true).limit(24)],
  ['prior-empty-limit',()=>e.query('Row').where('prefix1000',true).limit(0)],
  ['prior-order-limit',()=>e.query('Row').where('prefix1000',true).orderBy('title').limit(24)],
  ['empty-id-scope',()=>e.query.ids([])],
 ];
 report.pipelineEquivalence=[];
 for(const [name,make] of shapes){let pairs=0;for(let q=0;q<10;q++){
  active={rewrite:false};const baseline=make().near(vectors[q],{k:10}).hits();
  active={rewrite:true};const changed=make().near(vectors[q],{k:10}).hits();assert.deepEqual(changed,baseline,name);pairs++;
 }report.pipelineEquivalence.push({name,pairs});}
 mark('equivalence-complete');save();''')
s=s.replace("parameters=[...scope.parameters,type,name,generation,exclude??'',...parameters.slice(4+scope.parameters.length)];rewritten++;","""parameters=[...scope.parameters,type,name,generation,exclude??'',...parameters.slice(4+scope.parameters.length)];rewritten++;
   report.rewrittenPlans??=[];
   if(!report.rewrittenPlans.some(p=>p.sql===sql))report.rewrittenPlans.push({sql,plan:all('EXPLAIN QUERY PLAN '+sql,parameters)});""")
Path('/private/tmp/ears-scope-probe.mjs').write_text(s)
# Preparation only: do not run concurrently with the live block-size study.
print('Private scope-driven eligibility diagnostic prepared; no production changes and not launched')
