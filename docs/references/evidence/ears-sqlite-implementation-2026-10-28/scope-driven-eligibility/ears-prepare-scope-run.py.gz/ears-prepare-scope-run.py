from pathlib import Path
import hashlib,json,subprocess
r=Path('/private/tmp/ears-sqlite-query-integration');o=Path('/private/tmp/ears-scope-results');assert not o.exists();o.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','packages/apack-ears/src','packages/apack-ears/bench/sqlite/load-metrics.ts'],cwd=r,text=True).splitlines();inputs={n:sha(r/n) for n in files};(o/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
meta={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'probeSha256':sha(Path('/private/tmp/ears-scope-probe.mjs')),'expectedModelSha256':'5f90eea4ed59a1d018753a4f80e29ce58a40aec9c823382cdc051abce7a823b6','expectedDatabaseSha256':'4e7b922650edb9bacefdda9fcb9b0c5a04f91e5919510c1b03d0b6f1971de935','extension':'/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so','extensionSha256':'b16f6c4fcd84c776c1c3e1d3f2df33a5229dc987a1b8fd3b7d0343683fc10fd0'};(o/'source.json').write_text(json.dumps(meta,indent=2)+'\n')
for name in ['ears-run-direct-query.py','ears-wait-direct-package.py']:
 s=Path('/private/tmp/'+name).read_text()
 s=s.replace('direct-query','scope').replace('direct-package','scope').replace('ears-native-qprofile.mjs','ears-scope-probe.mjs')
 dest='ears-run-scope.py' if name.startswith('ears-run-') else 'ears-wait-scope.py';Path('/private/tmp/'+dest).write_text(s)
print('Prepared read-only scope diagnostic at',meta['source'],'with',len(inputs),'input hashes')
