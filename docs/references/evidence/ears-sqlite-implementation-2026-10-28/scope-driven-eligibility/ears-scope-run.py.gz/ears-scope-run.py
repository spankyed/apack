from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');meta=json.loads((o/'source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
p=r/'packages/apack-ears/bench/sqlite/scope-driven-probe.mjs';assert not p.exists();shutil.copyfile('/probe.mjs',p);assert sha(p)==meta['probeSha256'];subprocess.run(['node','--check',str(p)],check=True)
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
assert sha(Path(meta['extension']))==meta['extensionSha256'];report={'source':meta['source'],'limits':limits,'qualification':False};started=time.time()
try:
 args=['node','--import','tsx',str(p),'/corpus','/truth/truth.json','/electron/.temp/ears-query-attribution-retained','/results/query.json'];env={**os.environ,'EARS_TEST_SOURCE':meta['source'],'EARS_VEC1_EXTENSION':meta['extension'],'EARS_POLICY_MODEL_SHA256':meta['expectedModelSha256'],'EARS_POLICY_DATABASE_SHA256':meta['expectedDatabaseSha256'],'NODE_OPTIONS':'--max-old-space-size=4096'}
 with(o/'query.log').open('w') as f:result=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['exitCode']=result.returncode;assert result.returncode==0,(o/'query.log').read_text()[-6000:]
 d=json.loads((o/'query.json').read_text());assert d['completed'] and d['databaseSha256']==d['unchangedDatabaseSha256'] and d['productionHelperEquivalenceQueries']==900
 assert len(d['variants'])==2;assert len(d['variants'][0]['cohorts'])==len(d['variants'][1]['cohorts'])==9;pairs=0
 for bc,dc in zip(d['variants'][0]['cohorts'],d['variants'][1]['cohorts']):
  assert (bc['size'],bc['scopePercent'])==(dc['size'],dc['scopePercent']);assert len(bc['passes'])==len(dc['passes'])==4
  for bp,dp in zip(bc['passes'],dc['passes']):
   assert bp['nativeCandidateCalls']==dp['nativeCandidateCalls'];assert len(bp['samples'])==len(dp['samples'])==100
   for b,c in zip(bp['samples'],dp['samples']):assert (b['ordinals'],b['scores'])==(c['ordinals'],c['scores']);pairs+=1
 assert pairs==3600;report['identicalOrderedAnswerPairs']=pairs;report['completed']=True
except BaseException as e:report['failure']={'message':str(e),'type':type(e).__name__};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
