// Supported ANN query controls on one closed updated snapshot; diagnostic, never adoption acceptance.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync,openSync,readSync,closeSync,existsSync,writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { setTimeout as pause } from 'node:timers/promises';
import { SqliteDatabase } from '../../src/sqlite/database.ts';
import { SqliteVectorIndex } from '../../src/sqlite/vector-index.ts';
import { createEarsEngine } from '../../src/index.ts';
import { startHeartbeat } from './load-metrics.ts';
const [corpusPath,truthFile,snapshot,output]=process.argv.slice(2);
assert(output&&!existsSync(output));
const sha=data=>createHash('sha256').update(data).digest('hex');
const fileSha=file=>{const fd=openSync(file,'r'),buffer=Buffer.allocUnsafe(1024*1024),h=createHash('sha256');try{for(;;){const n=readSync(fd,buffer,0,buffer.length,null);if(!n)break;h.update(buffer.subarray(0,n));}return h.digest('hex');}finally{closeSync(fd);}};
const manifestBytes=readFileSync(join(corpusPath,'manifest.json')),manifest=JSON.parse(manifestBytes),truthBytes=readFileSync(truthFile),truth=JSON.parse(truthBytes);
assert.equal(truth.protocol,'ears-real-vector-fresh-truth/1');assert.equal(truth.manifestSha256,sha(manifestBytes));
assert.equal(fileSha(join(corpusPath,'corpus.f32')),manifest.files['corpus.f32'].sha256);
const queryOrdinals=Array.from({length:100},(_,q)=>499+999*q);assert.deepEqual(queryOrdinals,truth.queryOrdinals);
const fd=openSync(join(corpusPath,'corpus.f32'),'r'),queryBytes=queryOrdinals.map(ordinal=>{const b=Buffer.alloc(1536*4);assert.equal(readSync(fd,b,0,b.length,ordinal*b.length),b.length);return b;});closeSync(fd);
assert.equal(sha(Buffer.concat(queryBytes)),truth.queriesSha256);
const excluded=new Set(truth.excludedOrdinals);
const vectors=queryBytes.map(b=>Array.from(new Float32Array(b.buffer,b.byteOffset,1536)));
const datafile=join(snapshot,'data.sqlite3'),before=fileSha(datafile);assert.equal(before,process.env.EARS_POLICY_DATABASE_SHA256);
const report={protocol:'ears-scope-driven-eligibility/1',qualification:false,source:process.env.EARS_TEST_SOURCE,
  partition:'updated-only diagnostic; complete initial/update acceptance remains required',manifestSha256:sha(manifestBytes),truthSha256:sha(truthBytes),
  databaseSha256:before,configurations:[{rewrite:false},{rewrite:true}],variants:[],phases:[],node:process.version,arch:process.arch,platform:process.platform};
const pct=(a,p)=>[...a].sort((x,y)=>x-y)[Math.max(0,Math.ceil(a.length*p)-1)]??null;
const summary=a=>({count:a.length,p50:pct(a,.5),p95:pct(a,.95),p99:pct(a,.99),max:Math.max(...a)});
const save=()=>writeFileSync(output,JSON.stringify(report,null,2)+'\n');
const mark=phase=>report.phases.push({phase,wallMs:Date.now(),monotonicMs:performance.now()});
let db;
try{
 db=new SqliteDatabase({path:snapshot,readOnly:true,nativeVectorExtension:process.env.EARS_VEC1_EXTENSION});
 assert.equal(db.readOnly,true);assert.equal(db.sql.readonly,true);
 report.readOnly={requested:db.readOnly,native:db.sql.readonly,queryOnlyFlag:db.sql.pragma('query_only',{simple:true})};
 report.cacheKiB=-db.sql.pragma('cache_size',{simple:true});report.synchronous=db.sql.pragma('synchronous',{simple:true});
 const e=createEarsEngine({database:db}),index=new SqliteVectorIndex(db,process.env.EARS_VEC1_EXTENSION);
 const model=db.get("SELECT generation,model_sha256,state FROM vector_training WHERE state='ready'");assert(model);
 assert.equal(model.model_sha256,process.env.EARS_POLICY_MODEL_SHA256);assert.equal(index.ready(model.generation).model_sha256,model.model_sha256);
 report.model=model;report.sqlite=db.get('SELECT sqlite_version() v').v;
 const all=db.all.bind(db),originalSearch=db.search.vectors.search.bind(db.search.vectors);let active,context,nativeCalls=0,rewritten=0;
 db.search.vectors.search=(...args)=>{const previous=context;context=args;try{return originalSearch(...args);}finally{context=previous;}};
 db.all=(sql,parameters=[])=>{
  if(/^SELECT owner FROM ann_\d+\(\?,\?\)/.test(sql))nativeCalls++;
  if(active?.rewrite&&context?.[0]&&sql.startsWith('WITH eligible AS MATERIALIZED (')){
   const [scope,type,name,generation,,,,exclude]=context;
   const original=`SELECT c.entity_id id,c.embedding_id,e.seq FROM chunks c JOIN entities e ON e.id=c.entity_id
      WHERE c.type=? AND c.index_name=? AND c.generation=? AND c.embedding_id IS NOT NULL
      AND c.entity_id IN (${scope.sql}) AND c.entity_id!=? LIMIT 4097`;
   assert.equal(sql.split(original).length,2,'Only the intended eligibility page may change');
   assert.deepEqual(parameters.slice(0,3),[type,name,generation]);assert.deepEqual(parameters.slice(3,3+scope.parameters.length),scope.parameters);assert.equal(parameters[3+scope.parameters.length],exclude??'');
   // DISTINCT includes physical chunk identity: duplicate scope IDs cannot duplicate chunks,
   // while separate chunks reusing the same embedding remain separate for the route threshold.
   const replacement=`SELECT DISTINCT c.entity_id id,c.embedding_id,e.seq,c.rowid chunk_rowid
      FROM (${scope.sql}) scoped CROSS JOIN chunks c ON c.entity_id=scoped.id
      JOIN entities e ON e.id=c.entity_id
      WHERE c.type=? AND c.index_name=? AND c.generation=? AND c.embedding_id IS NOT NULL
      AND c.entity_id!=? LIMIT 4097`;
   sql=sql.replace(original,replacement);
   parameters=[...scope.parameters,type,name,generation,exclude??'',...parameters.slice(4+scope.parameters.length)];rewritten++;
   report.rewrittenPlans??=[];
   if(!report.rewrittenPlans.some(p=>p.sql===sql))report.rewrittenPlans.push({sql,plan:all('EXPLAIN QUERY PLAN '+sql,parameters)});
  }
  return all(sql,parameters);
 };
 const canonical=createHash('sha256'),expected=createHash('sha256');let count=0;const corpus=openSync(join(corpusPath,'corpus.f32'),'r'),bytes=Buffer.alloc(1536*4);
 try{for(const row of db.statement('SELECT v.embedding FROM embedding_values v JOIN entities e ON e.id=v.entity_id ORDER BY e.seq,v.chunk').iterate()){
   const ordinal=count%100===7?(count+31337)%99900:count;assert.equal(readSync(corpus,bytes,0,bytes.length,ordinal*bytes.length),bytes.length);expected.update(bytes);canonical.update(row.embedding);count++;
 }}finally{closeSync(corpus);}
 assert.equal(count,99900);assert.equal(canonical.digest('hex'),expected.digest('hex'));report.canonicalRowsVerified=count;
 const queryFor=(size,percent)=>{let q=e.query('Row');if(size!==99900)q=q.where(size===1000?'prefix1000':'prefix10000',true);if(percent!==100)q=q.where(percent===10?'scope10':'scope1',true);return q;};
 // Compare actual production answers/scores before timing either shape.
 let controls=0;
 for(const size of [1000,10000,99900])for(const percent of [100,10,1])for(let q=0;q<100;q++){
  active={rewrite:false};const baseline=queryFor(size,percent).near(vectors[q],{k:10}).hits();
  active={rewrite:true};const changed=queryFor(size,percent).near(vectors[q],{k:10}).hits();assert.deepEqual(changed,baseline);controls++;
 }
 report.productionHelperEquivalenceQueries=controls;assert.equal(controls,900);
 const shapes=[
  ['duplicate-ids',()=>e.query.ids(Array.from({length:5000},(_,i)=>i%2?'Row-000001':'Row-000002'))],
  ['prior-limit',()=>e.query('Row').where('prefix1000',true).limit(24)],
  ['prior-empty-limit',()=>e.query('Row').where('prefix1000',true).limit(0)],
  ['prior-order-limit',()=>e.query('Row').where('prefix1000',true).orderBy('title').limit(24)],
  ['empty-id-scope',()=>e.query.ids([])],
 ];
 report.pipelineEquivalence=[];
 for(const [name,make] of shapes){let pairs=0;for(let q=0;q<10;q++){
  active={rewrite:false};const baseline=make().near(vectors[q],{k:10}).hits();
  active={rewrite:true};const changed=make().near(vectors[q],{k:10}).hits();assert.deepEqual(changed,baseline,name);pairs++;
 }report.pipelineEquivalence.push({name,pairs});}
 mark('equivalence-complete');save();
 for(const configuration of report.configurations){
  active=configuration;const variant={...configuration,cohorts:[]};report.variants.push(variant);mark('rewrite-start-'+configuration.rewrite);
  for(const size of [1000,10000,99900])for(const percent of [100,10,1]){
   const expected=truth.cohorts.find(c=>c.phase==='updated'&&c.size===size&&c.scopePercent===percent);assert(expected);
   const cohort={size,scopePercent:percent,eligible:expected.eligible,passes:[]};variant.cohorts.push(cohort);
   for(let pass=0;pass<4;pass++){
    const samples=[],wallStartMs=Date.now(),pulse=startHeartbeat(1),callsBefore=nativeCalls;
    try{for(let q=0;q<100;q++){
     const wallStartMs=Date.now(),at=performance.now(),hits=queryFor(size,percent).near(vectors[q],{k:10}).hits(),ms=performance.now()-at;
     const ordinals=hits.map(hit=>Number(hit.id.slice(4))),answer=expected.answers[q].ordinals;
     assert.equal(ordinals.length,answer.length);assert.equal(new Set(ordinals).size,ordinals.length);
     assert(ordinals.every(i=>i>=0&&i<size&&i%100<percent&&i%97!==0&&!excluded.has(i)));
     assert(hits.every(hit=>Number.isFinite(hit.score)));
     samples.push({q,ms,wallStartMs,wallEndMs:Date.now(),recall:ordinals.filter(i=>answer.includes(i)).length/answer.length,ordinals,scores:hits.map(hit=>hit.score)});
     await pause(0);
    }}finally{pulse.stop();}
    const result={pass,timed:pass!==0,wallStartMs,wallEndMs:Date.now(),samples,nativeCandidateCalls:nativeCalls-callsBefore,
     meanRecall:samples.reduce((sum,s)=>sum+s.recall,0)/100,latencyMs:summary(samples.map(s=>s.ms)),heartbeatMs:summary(pulse.delaysMs),heartbeatSamples:pulse.delaysMs};
    result.gates={recall:result.meanRecall>=.95,heartbeat:result.heartbeatMs.p99<=16,diagnosticLatency:size<10000||result.latencyMs.p95<=(size===10000?100:200)};
    cohort.passes.push(result);save();console.log(JSON.stringify({rewrite:configuration.rewrite,size,percent,pass,recall:result.meanRecall,p95:result.latencyMs.p95,heartbeatP99:result.heartbeatMs.p99}));
   }
  }
  variant.frozenGatesPassed=variant.cohorts.every(c=>c.passes.every(p=>p.gates.recall&&p.gates.heartbeat&&p.gates.diagnosticLatency));
  mark('rewrite-end-'+configuration.rewrite);save();
 }
 report.rewrittenEligibilityQueries=rewritten;assert(rewritten>0);db.search.vectors.search=originalSearch;db.all=all;db.close();db=undefined;
 report.unchangedDatabaseSha256=fileSha(datafile);assert.equal(report.unchangedDatabaseSha256,before);
 report.maxRssKiB=process.resourceUsage().maxRSS;report.completed=true;save();
}catch(error){report.failure={message:error.message,stack:error.stack};save();throw error;}
finally{db?.close();}
