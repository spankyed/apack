from pathlib import Path
import subprocess,json,os,hashlib
r=Path('/electron');o=Path('/results');report={'source':'025923f874 with scoped workflow environment','scope':'All five changed EARS inputs mounted over verified a9 dependencies; full EARS typecheck and focused suites','steps':[]}
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_EVALUATION_BACKEND':'sqlite','EARS_VEC1_EXTENSION':'/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so'}
 env.pop('APACK_STORAGE_FORMAT',None)
 commands=[('unit',['node','node_modules/vitest/vitest.mjs','run','--config','/electron/vitest.config.ts','--project','@apackdev/host','--project','@apackdev/cli','--project','@app/api',
 'packages/apack-cli/tests/commands/backup.spec.ts','packages/apack-cli/tests/commands/db-rebuild.spec.ts','packages/apack-host/tests/backup/import.spec.ts','packages/apack-host/tests/backup/storage.spec.ts','packages/apack-host/tests/database/open-app-database.spec.ts','packages/apack-host/tests/services/run-history.spec.ts','packages/api/tests/runtime/host-data-services.spec.ts','--maxWorkers=2','--reporter=default','--reporter=json','--outputFile=/results/unit.json']),
 ('integration',['node','node_modules/vitest/vitest.mjs','run','--config','/electron/packages/apack-cli/vitest.integration.config.ts','--root','/electron/packages/apack-cli','tests/commands/db.integration.spec.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile=/results/integration.json'])]
 for name,args in commands:
  with(o/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  report['steps'].append({'name':name,'exitCode':p.returncode});assert p.returncode==0,(name,(o/(name+'.log')).read_text()[-6000:]);print(name+' passed',flush=True)
 report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
