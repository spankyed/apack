import { Graph, leiden } from '/leiden/index.js';
import fs from 'node:fs';
let state=17; const random=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};
const report={package:'leiden-ts@0.1.0',cases:0,failures:[],completed:false};
function verify(n,edges,seed,resolution){
 const graph=Graph.fromEdgeList(n,edges,{selfLoops:'allow'});
 const first=leiden(graph,{seed,resolution}), second=leiden(graph,{seed,resolution});
 const ids=Array.from(first.partition.assignments);
 if(JSON.stringify(ids)!==JSON.stringify(Array.from(second.partition.assignments))) throw Error('nondeterministic');
 const groups=new Map();ids.forEach((group,id)=>{if(!groups.has(group))groups.set(group,[]);groups.get(group).push(id);});
 const adj=Array.from({length:n},()=>[]);for(const [a,b] of edges){adj[a].push(b);adj[b].push(a);}
 for(const members of groups.values()){
  const allowed=new Set(members),seen=new Set([members[0]]),stack=[members[0]];
  while(stack.length){for(const far of adj[stack.pop()])if(allowed.has(far)&&!seen.has(far)){seen.add(far);stack.push(far);}}
  if(seen.size!==members.length)throw Error('disconnected community '+JSON.stringify({members,edges,seed,resolution}));
 }
 if(!Number.isFinite(first.modularity))throw Error('nonfinite modularity');
 report.cases++;
}
try{
 for(let trial=0;trial<500;trial++){
  const n=3+Math.floor(random()*48),edges=[],density=.02+random()*.4;
  for(let a=0;a<n;a++)for(let b=a+1;b<n;b++)if(random()<density)edges.push([a,b,1+Math.floor(random()*4)]);
  if(trial%5===0)edges.push([0,0,1]);
  const seed=(random()*4294967296)>>>0,resolution=trial%3===0?0:trial%3===1?1:2;
  try{verify(n,edges,seed,resolution);}catch(error){report.failures.push({trial,n,edges,seed,resolution,message:error.message});}
 }
 report.completed=true;
}finally{fs.writeFileSync('/results/report.json',JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({cases:report.cases,failures:report.failures.length,completed:report.completed}));
if(report.failures.length)process.exitCode=1;
