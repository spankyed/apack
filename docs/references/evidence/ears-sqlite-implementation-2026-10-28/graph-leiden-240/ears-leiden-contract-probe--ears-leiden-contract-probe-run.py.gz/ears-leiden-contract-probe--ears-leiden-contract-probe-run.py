import subprocess,json
from pathlib import Path
p=subprocess.run(['node','/probe.mjs'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
Path('/results/probe.log').write_text(p.stdout)
print(p.stdout,flush=True)
raise SystemExit(p.returncode)
