from pathlib import Path
import hashlib,json
root=Path('/private/tmp/ears-sqlite-query-integration');source=root/'packages/apack-ears/bench/sqlite/real-vector-ears.mjs';s=source.read_text()
s=s.replace("import { loadedNativeBindings, startHeartbeat } from './load-metrics.ts';","import { loadedNativeBindings, startHeartbeat } from './load-metrics.ts';\nimport { renameSync } from 'node:fs';")
s=s.replace("assert(mode === undefined || ['diagnose','native-fresh','native-diagnose'].includes(mode));","assert.equal(mode,'native-fresh','This diagnostic preserves the complete fresh matrix');")
s=s.replace("const path = mkdtempSync(join(tmpdir(),'ears-real-vector-'));","const retainedPath='/electron/.temp/ears-query-attribution-retained';\nassert(!existsSync(retainedPath),'Never replace a retained profiling database');\nconst path = mkdtempSync(join('/electron/.temp','ears-query-attribution-'));")
s=s.replace("protocol:'ears-integrated-real-vector/1'","protocol:'ears-query-attribution/1'")
s=s.replace("const save = () => writeFileSync(output,JSON.stringify(report,null,2)+'\\n');","const save = () => writeFileSync(output,JSON.stringify(report,null,2)+'\\n');\nreport.phases=[];\nconst mark=phase=>report.phases.push({phase,wallMs:Date.now(),monotonicMs:performance.now()});\nmark('start');")
s=s.replace("  report.createMs = performance.now()-started;", "  mark('created');report.createMs = performance.now()-started;")
s=s.replace("  assert.equal(stored,size); report.embedMs=performance.now()-started;", "  assert.equal(stored,size);mark('embedded');report.embedMs=performance.now()-started;")
s=s.replace("    const pulse=startHeartbeat(1),admissionAt=performance.now()", "    mark('native-admission-start');\n    const pulse=startHeartbeat(1),admissionAt=performance.now()")
s=s.replace("    assert.equal(db.sequence,sequence);", "    mark('native-admission-end');assert.equal(db.sequence,sequence);")
instrument=r'''
  const sqlDefinitions=[], knownSql=new Map(), planInputs=new Map();
  let queryStages, activeFrame;
  const originalStatement=db.statement.bind(db), originalAll=db.all.bind(db), originalGet=db.get.bind(db);
  const parameterShape=value=>value instanceof Uint8Array?{kind:'bytes',length:value.byteLength,sha256:sha(value)}:
    typeof value==='string'?{kind:'string',length:value.length}:{kind:typeof value,value};
  db.statement=sql=>{
    const begin=performance.now();
    try{return originalStatement(sql);}
    finally{if(activeFrame)activeFrame.preparationMs+=performance.now()-begin;}
  };
  const capture=(method,operation)=>(sql,parameters=[])=>{
    if(!queryStages)return operation(sql,parameters);
    const prior=activeFrame,frame={preparationMs:0},wallStartMs=Date.now(),begin=performance.now();
    activeFrame=frame;
    let answer,failed=false;
    try{answer=operation(sql,parameters);return answer;}
    catch(error){failed=true;throw error;}
    finally{
      const ms=performance.now()-begin;activeFrame=prior;
      const key=method+'\0'+sql;let id=knownSql.get(key);
      if(id===undefined){
        id=knownSql.size;knownSql.set(key,id);
        sqlDefinitions.push({id,method,sql,parameters:parameters.map(parameterShape)});
        planInputs.set(id,[sql,[...parameters]]);
      }
      queryStages.push({id,ms,preparationMs:frame.preparationMs,
        bindingExecutionMaterializationMs:Math.max(0,ms-frame.preparationMs),
        rows:Array.isArray(answer)?answer.length:answer===undefined?0:1,failed,wallStartMs,wallEndMs:Date.now()});
    }
  };
  db.all=capture('all',originalAll);db.get=capture('get',originalGet);
  // Preparation is measured separately. The binding does not expose an independent native row-decoding timer.
  // Iterate/other work outside these entry points remains explicitly unattributed, not labelled JavaScript time.
  report.attribution={captured:['all','get'],unattributed:'iterator and other facade/binding work',
    qualification:false,fullQueryMatrix:true,retention:'closed updated database; private volume only'};
  mark('query-matrix-start');
'''
needle='  const queryFor=(cohortSize,percent,selected)=>{';assert needle in s;s=s.replace(needle,instrument+'\n'+needle,1)
# Change only the full-matrix query call; retain every cohort, query, pass, update and assertion.
needle='''            const begin=performance.now();
            const hits=queryFor(cohortSize,percent,selected).near(queryVectors[q],{k:10}).hits();
            const ms=performance.now()-begin,ordinals='''
replace='''            const begin=performance.now(),wallStartMs=Date.now();queryStages=[];
            let hits,stages;
            try{hits=queryFor(cohortSize,percent,selected).near(queryVectors[q],{k:10}).hits();}
            finally{stages=queryStages;queryStages=undefined;}
            const ms=performance.now()-begin,wallEndMs=Date.now(),ordinals='''
assert needle in s;s=s.replace(needle,replace,1)
s=s.replace("samples.push({q,ms,recall:","samples.push({q,ms,wallStartMs,wallEndMs,stages,recall:")
s=s.replace("        const samples=[],pulse=startHeartbeat(1),callsBefore=nativeCalls;","        const wallStartMs=Date.now(),samples=[],pulse=startHeartbeat(1),callsBefore=nativeCalls;")
s=s.replace("        const result={pass,timed:pass!==0,nativeCandidateCalls:","        const result={pass,wallStartMs,wallEndMs:Date.now(),timed:pass!==0,nativeCandidateCalls:")
needle="  report.maxRssKiB=process.resourceUsage().maxRSS; report.filesAfterQueries=files();report.completed=true;save();"
replace='''  mark('query-matrix-end');
  db.all=originalAll;db.get=originalGet;db.statement=originalStatement;
  for(const row of sqlDefinitions){const [sql,parameters]=planInputs.get(row.id);row.plan=db.sql.prepare('EXPLAIN QUERY PLAN '+sql).all(...parameters);}
  report.sqlDefinitions=sqlDefinitions;
  report.maxRssKiB=process.resourceUsage().maxRSS;report.filesAfterQueries=files();
  report.finalCanonicalRowsVerified=canonicalHash(true);assert.equal(report.finalCanonicalRowsVerified,size);
  await models?.stop();models=undefined;db.close();db=undefined;
  renameSync(path,retainedPath);report.retainedDatabase={path:retainedPath,closed:true,updated:true};
  mark('closed-database-retained');report.completed=true;save();'''
assert needle in s;s=s.replace(needle,replace)
assert "for(const phase of ['initial','updated'])" in s and "for(let q=0;q<100;q++)" in s and "pass<4" in s
assert 'wal_checkpoint' not in s and 'synchronous=OFF' not in s
probe=Path('/private/tmp/ears-query-attribution.mjs');probe.write_text(s)
o=Path('/private/tmp/ears-query-attribution-results');o.mkdir(exist_ok=True)
(o/'source.json').write_text(json.dumps({'source':'1eb47d88e11e17e897056173b3e147c328008453','baseProbeSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'probeSha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'qualification':False,'matrix':'unchanged 18 cohorts x4passes x100queries; real app-owned model admission','measured':'preparation and combined binding/execution/materialization; rest explicitly unattributed','retainedDatabase':'private closed updated store /electron/.temp/ears-query-attribution-retained','phaseWallMarkers':True},indent=2)+'\n')
(o/'inputs.json').write_bytes(Path('/private/tmp/ears-allocation-study-results/inputs.json').read_bytes())
print('Prepared full-matrix query-attribution probe; production source unchanged.')
