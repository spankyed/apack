from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');inputs=json.loads((o/'inputs.json').read_text())
for n,h in inputs.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
p=r/'packages/apack-ears/bench/sqlite/query-attribution.mjs';shutil.copyfile('/probe.mjs',p)
meta=json.loads((o/'source.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['probeSha256']
subprocess.run(['node','--check',str(p)],check=True)
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
args=['node','--import','tsx',str(p),'/corpus','/truth/truth.json','99900','/results/query-attribution.json','native-fresh'];env={**os.environ,'EARS_TEST_SOURCE':meta['source'],'EARS_VEC1_EXTENSION':str(r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so')}
start=time.time()
with(o/'query-attribution.log').open('w') as f:result=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
(o/'run.json').write_text(json.dumps({'source':meta['source'],'limits':limits,'args':args,'exitCode':result.returncode,'startedWallMs':start*1000,'endedWallMs':time.time()*1000,'seconds':time.time()-start,'inputs':inputs},indent=2)+'\n');print('Query attribution exit',result.returncode,flush=True)
assert result.returncode==0,(o/'query-attribution.log').read_text()[-6000:]
d=json.loads((o/'query-attribution.json').read_text());assert d['completed'] and not d.get('failure') and len(d['cohorts'])==18
assert all(len(c['passes'])==4 and all(len(p['samples'])==100 for p in c['passes']) for c in d['cohorts'])
assert d['initialCanonicalRowsVerified']==99900 and d['updatedCanonicalRowsVerified']==99900 and d['finalCanonicalRowsVerified']==99900
assert d['sqlDefinitions'] and all(row.get('plan') for row in d['sqlDefinitions'])
retained=Path(d['retainedDatabase']['path']);assert retained.is_dir() and (retained/'data.sqlite3').is_file()
print('Full matrix, canonical vectors, SQL plans and closed private database retained',flush=True)
