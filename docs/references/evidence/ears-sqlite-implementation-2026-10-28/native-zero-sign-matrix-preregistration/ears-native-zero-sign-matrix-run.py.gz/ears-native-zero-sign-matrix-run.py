from pathlib import Path
import json,subprocess,hashlib,time,os,shutil
r=Path('/electron');o=Path('/results');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((o/'source.json').read_text())
report={'source':meta['source'],'qualification':False};at=time.time();p=r/'packages/apack-ears/bench/sqlite/native-zero-sign-matrix.mjs'
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
 limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'};report['limits']=limits
 report['volumeFreeBytesBefore']=shutil.disk_usage(r/'.temp').free;assert report['volumeFreeBytesBefore']>=8*1024**3,'Require8GiBfree for retained clone and independent canonical dump'
 assert not p.exists();shutil.copyfile('/probe.mjs',p);assert sha(p)==meta['probeSha256']
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_TEST_SOURCE':meta['source']}
 with(o/'probe.log').open('w') as log:result=subprocess.run(['node','--import','tsx',str(p),'/corpus','/truth/truth.json',str(o/'probe.json')],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 report['exitCode']=result.returncode;assert result.returncode==0,(o/'probe.log').read_text()[-6000:]
 d=json.loads((o/'probe.json').read_text());assert d['completed'] and len(d['cohorts'])==18 and all(len(c['passes'])==4 for c in d['cohorts']);assert len(d['canonical'])==3 and all(c['embeddings']==99900 for c in d['canonical'] if c['phase']!='checkpoint');assert sum(len(p['samples']) for c in d['cohorts'] for p in c['passes'])==7200;report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:report['seconds']=time.time()-at;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n');p.unlink(missing_ok=True)
