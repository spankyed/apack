// Private current-elmdb baseline preflight; no candidate runtime or ANN settings are changed.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {createRequire} from 'node:module';
import {readFileSync,writeFileSync,mkdtempSync,rmSync,openSync,readSync,closeSync,statSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {setTimeout as pause} from 'node:timers/promises';
import {unpack} from 'msgpackr';
import {createEarsEngine} from '/electron/packages/apack-ears/src/index.ts';
import {adaptDatabase} from '/electron/packages/apack-ears/src/lmdb/adapter.ts';
import {toElmdbSchema} from '/electron/packages/apack-ears/src/schema.ts';
import {startHeartbeat} from '/electron/packages/apack-ears/bench/sqlite/load-metrics.ts';
const [corpusPath,truthPath,output]=process.argv.slice(2);assert(corpusPath&&truthPath&&output);
const sha=b=>createHash('sha256').update(b).digest('hex');
const binding='/electron/.temp/elmdb-2441-source/crates/elmdb-node/elmdb.linux-arm64-gnu.node';
const cli='/electron/.temp/elmdb-2441-target/release/elmdb';
assert.equal(sha(readFileSync(binding)),'5d813c95e373c79f36c47889c75b0491b8987c7cc6f9669f4428e4dd69a27687');
assert.equal(sha(readFileSync(cli)),'b3992070d8c9a3c9ad28e37576f8a101fe2a570391d0e157289fffa85fbdbf2c');
const native=createRequire(import.meta.url)(binding),manifestBytes=readFileSync(join(corpusPath,'manifest.json')),manifest=JSON.parse(manifestBytes);
const truthBytes=readFileSync(truthPath),truth=JSON.parse(truthBytes);assert.equal(truth.protocol,'ears-real-vector-fresh-truth/1');assert.equal(sha(manifestBytes),truth.manifestSha256);
const corpus=readFileSync(join(corpusPath,'corpus.f32'));assert.equal(sha(corpus),manifest.files['corpus.f32'].sha256);
const size=99900,bytes=1536*4,excluded=new Set(truth.excludedOrdinals),vector=i=>Array.from(new Float32Array(corpus.buffer,corpus.byteOffset+i*bytes,1536));
const ordinals=Array.from({length:100},(_,q)=>499+999*q);assert.deepEqual(ordinals,truth.queryOrdinals);
const queryVectors=ordinals.map(vector);
assert.equal(sha(Buffer.concat(ordinals.map(i=>corpus.subarray(i*bytes,(i+1)*bytes)))),truth.queriesSha256);
const schema=toElmdbSchema({types:{Row:{required:[],indexes:['prefix1000','prefix10000','scope10','scope1'],embed:{from:['title'],model:'public-fixture',dims:1536,chunk:'whole'}}},relations:{},roles:[]});
const incumbent='/electron/.temp/ears-migration-checkpoint-20261031/native-db';
const hashFile=async path=>{const h=createHash('sha256');for await(const part of createReadStream(path))h.update(part);return h.digest('hex');};
assert.equal(await hashFile(join(incumbent,'data.mdb')),'0fe282f82d18121c62f2828867099dedac26be67d30327b65f30b851ab5a1d00');
const scratch='/electron/.temp/ears-native-resumed-a2D0Vp',databasePath=join(scratch,'database');
assert.equal(await hashFile(join(databasePath,'data.mdb')),'0fe282f82d18121c62f2828867099dedac26be67d30327b65f30b851ab5a1d00');
const report={protocol:'ears-current-elmdb-resumed-real-matrix/2-known-zero-sign-loss',diagnosticOnly:true,canonicalZeroSignFailures:[],storageBoundary:'OrbStack Seagate APFS backing; Linux named-volume copy of compacted migration snapshot',databasePath,incumbent,preservesOriginalFreshIngestTiming:false,source:process.env.EARS_TEST_SOURCE,nativeRevision:'2441af4658d961f547c7094cd041c2ac246668c5',size,qualification:false,acknowledgment:'transact durable:true for every logical mutation; default syncs enabled',truthSha256:sha(truthBytes),manifestSha256:sha(manifestBytes),querySha256:truth.queriesSha256,cohorts:[],canonical:[]};
const save=()=>writeFileSync(output,JSON.stringify(report,null,2)+'\n');
const percentile=(xs,p)=>[...xs].sort((a,b)=>a-b)[Math.max(0,Math.ceil(xs.length*p)-1)]??null;
let db,e;const open=()=>{db=adaptDatabase(native.Database.open(databasePath,{schema}));e=createEarsEngine({database:db});};
let writePhase='create';report.durableBatches=[];const durable=fn=>{const at=performance.now();try{return e.transact(fn,{durable:true});}finally{report.durableBatches.push({phase:writePhase,ms:performance.now()-at});}};
const updates=[],updateIds=new Set();
function rememberUpdate(row){const i=Number(row.id.slice(4));if(i%100===7&&!updateIds.has(row.id)){updateIds.add(row.id);updates.push({id:row.id,chunk:row.chunk,hash:row.hash,model:row.model,ordinal:i});}}
function canonical(phase){
 const dump=join(scratch,phase+'.dump'),at=performance.now();
 const result=spawnSync(cli,['dump',databasePath,dump],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);
 const fd=openSync(dump,'r');let offset=0,count=0,embeddings=0,entities=0,zeroSignChanges=0;const seen=new Uint8Array(size),entitySeen=new Uint8Array(size);
 const read=n=>{const b=Buffer.alloc(n);let done=0;while(done<n){const amount=readSync(fd,b,done,n-done,offset+done);assert(amount>0,'truncated dump');done+=amount;}offset+=n;return b;};
 try{
  assert.equal(read(8).toString(),'ELMDBDMP');assert.equal(read(4).readUInt32LE(),1);const schemaBytes=read(read(4).readUInt32LE());assert(schemaBytes.length>0);
  for(;;){const length=read(4).readUInt32LE();if(length===0xffffffff){assert.equal(read(8).readBigUInt64LE(),BigInt(count));break;}assert(length<128*1024,'unexpected unbounded frame');const row=unpack(read(length));count++;
   if(row.load==='entity'){const i=Number(row.id.slice(4));assert(Number.isInteger(i)&&i>=0&&i<size&&!entitySeen[i]);entitySeen[i]=1;entities++;if(phase==='checkpoint'){assert(!row.trashed);assert.equal(row.fields.title,`row ${i}`);assert.equal(row.fields.prefix1000,i<1000);assert.equal(row.fields.prefix10000,i<10000);assert.equal(row.fields.scope10,i%100<10);assert.equal(row.fields.scope1,i%100<1);}}
   if(row.load==='embedding'){
    assert.equal(row.chunk,0);assert.equal(row.model,'public-fixture');assert.equal(row.vector.length,1536);
    const i=Number(row.id.slice(4));assert(Number.isInteger(i)&&i>=0&&i<size&&!seen[i]);seen[i]=1;
    const expected=phase==='updated'&&i%100===7?(i+31337)%99900:i;
    const actual=Buffer.from(Float32Array.from(row.vector).buffer);const wanted=corpus.subarray(expected*bytes,(expected+1)*bytes);if(!actual.equals(wanted)){for(let j=0;j<1536;j++)if(actual.readUInt32LE(j*4)!==wanted.readUInt32LE(j*4)){assert(actual.readFloatLE(j*4)===0&&wanted.readFloatLE(j*4)===0,'Nonzero canonical component mismatch must stop diagnostic');zeroSignChanges++;report.canonicalZeroSignFailures.push({phase,id:row.id,component:j,expectedBits:wanted.readUInt32LE(j*4).toString(16),actualBits:actual.readUInt32LE(j*4).toString(16)});}}embeddings++;if(phase==='checkpoint')rememberUpdate(row);
   }
  }
  assert.equal(offset,statSync(dump).size);assert.equal(entities,size);assert(entitySeen.every(x=>x===1));if(phase!=='checkpoint'){assert.equal(embeddings,size);assert(seen.every(x=>x===1));}else{assert(embeddings>0&&embeddings<size);report.checkpointEmbeddings=embeddings;}
 }finally{closeSync(fd);rmSync(dump);}
 report.canonical.push({phase,embeddings,entities,zeroSignChanges,canonicalBytesPassed:zeroSignChanges===0,loads:count,ms:performance.now()-at});save();
}
try{
 open();const ids=Array.from({length:size},(_,i)=>`Row-${String(i).padStart(6,'0')}`);canonical('checkpoint');const initialPending=e.pendingEmbeddings('Row',{limit:64});assert.equal(initialPending.count,size-report.checkpointEmbeddings);report.initialPending=initialPending.count;writePhase='resume-embed';let at=performance.now(),stored=0;save();
 for(;;){const pending=e.pendingEmbeddings('Row',{limit:64});if(!pending.count)break;assert(pending.chunks.length);const batch=pending.chunks.map(chunk=>{const i=Number(chunk.id.slice(4));rememberUpdate({...chunk,model:pending.model});return {...chunk,model:pending.model,vector:vector(i)};});const answer=durable(()=>e.embed(batch));assert.equal(answer.stored,batch.length);stored+=batch.length;if(stored%4096===0){report.resumeStored=stored;save();console.log(JSON.stringify({stage:'embedded',stored}));}}
 assert.equal(stored+report.checkpointEmbeddings,size);assert.equal(updates.length,999);report.resumeEmbedMs=performance.now()-at;save();writePhase='trash';console.log(JSON.stringify({stage:'embedded',rows:size,ms:report.resumeEmbedMs}));
 durable(()=>{for(let i=0;i<size;i++)if(i%97===0||excluded.has(i))e.write(ids[i]).trash();});
 for(const phase of ['initial','updated']){
  if(phase==='updated'){writePhase='update';at=performance.now();for(let offset=0;offset<updates.length;offset+=64)durable(()=>e.embed(updates.slice(offset,offset+64).map(({ordinal,...chunk})=>({...chunk,vector:vector((ordinal+31337)%99900)}))));report.updateMs=performance.now()-at;}
  await db.durable();canonical(phase);db.close();open();
  for(const cohortSize of [1000,10000,99900])for(const percent of [100,10,1]){
   const expected=truth.cohorts.find(c=>c.size===cohortSize&&c.phase===phase&&c.scopePercent===percent);assert(expected);
   const record={phase,size:cohortSize,scopePercent:percent,eligible:expected.eligible,passes:[]};report.cohorts.push(record);
   for(let pass=0;pass<4;pass++){
    const samples=[],pulse=startHeartbeat(1);
    try{for(let q=0;q<100;q++){
     const start=performance.now();let query=e.query('Row');if(cohortSize!==size)query=query.where(cohortSize===1000?'prefix1000':'prefix10000',true);if(percent!==100)query=query.where(percent===10?'scope10':'scope1',true);
     const hits=query.near(queryVectors[q],{k:10}).hits(),ms=performance.now()-start,found=hits.map(h=>Number(h.id.slice(4))),answer=expected.answers[q].ordinals;
     assert.equal(found.length,answer.length);assert.equal(new Set(found).size,found.length);assert(found.every(i=>i>=0&&i<cohortSize&&i%100<percent&&i%97!==0&&!excluded.has(i)));assert(hits.every(h=>Number.isFinite(h.score)));
     samples.push({q,ms,recall:found.filter(i=>answer.includes(i)).length/answer.length,ordinals:found,scores:hits.map(h=>h.score)});await pause(0);
    }}finally{pulse.stop();}
    record.passes.push({pass,timed:pass!==0,connectionReopenedFirstPass:pass===0&&percent===100&&cohortSize===1000,meanRecall:samples.reduce((n,s)=>n+s.recall,0)/100,latencyMs:{p50:percentile(samples.map(s=>s.ms),.5),p95:percentile(samples.map(s=>s.ms),.95),p99:percentile(samples.map(s=>s.ms),.99)},heartbeatMs:{p99:percentile(pulse.delaysMs,.99)},heartbeatSamples:pulse.delaysMs,samples});save();console.log(JSON.stringify({phase,cohortSize,percent,pass,meanRecall:record.passes.at(-1).meanRecall}));
   }
  }
 }
 report.gates=report.cohorts.map(c=>({size:c.size,phase:c.phase,scopePercent:c.scopePercent,passes:c.passes.map(p=>({pass:p.pass,recall:p.meanRecall>=.95,heartbeat:p.heartbeatMs.p99<=16,diagnosticLatency:c.size<10000||p.latencyMs.p95<=(c.size===10000?100:200)}))}));report.queryGatesPassed=report.gates.every(c=>c.passes.every(p=>p.recall&&p.heartbeat&&p.diagnosticLatency));report.canonicalBytesPassed=report.canonical.every(c=>c.canonicalBytesPassed);report.frozenGatesPassed=report.queryGatesPassed&&report.canonicalBytesPassed;report.completed=true;report.maxRssKiB=process.resourceUsage().maxRSS;save();
}catch(error){report.failure={message:error.message,stack:error.stack};save();throw error;}
finally{if(db?.isOpen)db.close();report.incumbentMainSha256After=await hashFile(join(incumbent,'data.mdb'));assert.equal(report.incumbentMainSha256After,'0fe282f82d18121c62f2828867099dedac26be67d30327b65f30b851ab5a1d00');save();}
