from pathlib import Path
import subprocess,json,os,hashlib,time
r=Path('/electron');o=Path('/results');report={'source':'2584617f8c','scope':'Fresh synthetic ordered-query profile, syncs disabled; not write/durability acceptance'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096'}
 args=['node','--import','tsx','/probe.mjs']
 with(o/'test.log').open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 report['exitCode']=p.returncode
 if p.returncode:print((o/'test.log').read_text()[-6000:],flush=True)
 report['completed']=True
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(report['exitCode'])
