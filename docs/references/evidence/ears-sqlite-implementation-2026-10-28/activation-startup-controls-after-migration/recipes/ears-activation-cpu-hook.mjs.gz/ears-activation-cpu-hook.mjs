// Private observer: no SQL, arguments, return values, policy or product entry points are replaced.
import { SqliteDatabase } from '/electron/packages/apack-ears/src/sqlite/database.ts';
import { writeFileSync } from 'node:fs';
import {Session} from 'node:inspector';
const profiler=new Session();
const post=(method,parameters={})=>new Promise((resolve,reject)=>profiler.post(method,parameters,(error,value)=>error?reject(error):resolve(value)));
const output=process.env.EARS_ACTIVATION_REPORT;let active=false,started,cpu,stats=new Map();
for(const name of ['setSchema','commitWrite','write','batch','run','get','all','finish']){
 const original=SqliteDatabase.prototype[name];if(typeof original!=='function')throw Error('Missing observed method '+name);
 SqliteDatabase.prototype[name]=function(...args){
  if(!active)return original.apply(this,args);
  const at=performance.now(),store=(this.path?.endsWith('/ears-db')||this.path?.endsWith('/lmdb'))?'primary':this.path?.includes('run-history')?'runs':'other';
  const shape=['run','get','all'].includes(name)?String(args[0]).trim().split(/\s+/).slice(0,3).join(' '):'';
  try{return original.apply(this,args);}finally{
   const ms=performance.now()-at,key=store+':'+name+(shape?':'+shape:'');const held=stats.get(key)??{key,count:0,totalMs:0,maxMs:0};held.count++;held.totalMs+=ms;held.maxMs=Math.max(held.maxMs,ms);stats.set(key,held);
  }
 };
}
async function signal(){
 if(!active){
  profiler.connect();await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:1000});await post('Profiler.start');
  stats=new Map();started=performance.now();cpu=process.cpuUsage();active=true;writeFileSync(output,JSON.stringify({state:'active',pid:process.pid})+'\n');
 }else{
  active=false;const wallMs=performance.now()-started,cpuMicroseconds=process.cpuUsage(cpu);
  try{
   const {profile}=await post('Profiler.stop');writeFileSync(output+'.cpuprofile',JSON.stringify(profile)+'\n');
   writeFileSync(output,JSON.stringify({state:'complete',pid:process.pid,wallMs,cpuMicroseconds,profileFile:output+'.cpuprofile',profileKind:'V8 sampled stack time; not a syscall/CPU-wait decomposition',stats:[...stats.values()].sort((a,b)=>b.totalMs-a.totalMs)},null,2)+'\n');
  }finally{profiler.disconnect();}
 }
}
process.on('SIGUSR2',()=>{void signal().catch(error=>{try{profiler.disconnect();}catch{}writeFileSync(output,JSON.stringify({state:'failed',message:error.message,stack:error.stack})+'\n');});});
