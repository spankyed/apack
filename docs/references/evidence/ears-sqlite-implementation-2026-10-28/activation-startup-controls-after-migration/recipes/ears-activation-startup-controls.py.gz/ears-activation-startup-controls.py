from pathlib import Path
import subprocess,os,json,time,tempfile,socket,signal,hashlib,shutil
r=Path('/electron');o=Path('/results');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in json.loads(Path('/expected/inputs.json').read_text()).items():assert sha(r/n)==h,n
for n,h in json.loads(Path('/expected/expected-built-inputs.json').read_text()).items():assert sha(r/n)==h,n
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
report={'source':'1d7a3de090d74028ca36eba574686da8c794609a','limits':limits,'controls':[],'qualification':False,'scope':'Old/new preload API bootstrap controls; original45sec bound. New ready process additionally measures real activation.'};client=r/'tests/scripts/_support/activation-startup-client.mjs';assert not client.exists();shutil.copyfile('/client.mjs',client)
try:
 with tempfile.TemporaryDirectory(prefix='ears-startup-controls-') as scratch:
  for label,hook in [('old','/old-hook.mjs'),('new','/new-hook.mjs')]:
   profile=Path(scratch)/label;config=profile/'apack/installed-packs.json';config.parent.mkdir(parents=True);config.write_text(json.dumps({'packs':[{'id':'default-setup','enabled':False}]}))
   with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
   env={**os.environ,'APACK_ENV':'test','APACK_USER_DATA_DIR':str(profile),'APACK_STORAGE_FORMAT':'sqlite/1','APACK_API_TOKEN':'synthetic-activation-profile-token','API_PORT':str(port),'SHIPPED_PACKS_DIR':str(r/'packages'),'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_TEST_SOURCE':report['source'],'EARS_ACTIVATION_REPORT':str(o/(label+'-hook.json')),'APACK_PACKAGES_PREBUILT':'1'}
   entry={'label':label,'samples':[]};report['controls'].append(entry);at=time.monotonic()
   with(o/(label+'-api.log')).open('w') as log:
    child=subprocess.Popen(['node','--import','tsx','--import',hook,'packages/api/dist/server.js'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
     while True:
      endpoint=profile/'apack/api-port';elapsed=time.monotonic()-at
      if endpoint.exists() and json.loads(endpoint.read_text()).get('port')==port:entry['started']=True;break
      if child.poll() is not None:entry['childExitCode']=child.returncode;entry['started']=False;break
      if elapsed>=45:entry['started']=False;entry['timeoutSeconds']=45;break
      if not entry['samples'] or elapsed-entry['samples'][-1]['elapsed']>=5:
       sample={'elapsed':elapsed}
       for name in ['stat','wchan']:
        try:sample[name]=Path('/proc',str(child.pid),name).read_text().strip()
        except OSError as error:sample[name]=str(error)
       entry['samples'].append(sample)
      time.sleep(.1)
     entry['startupSeconds']=time.monotonic()-at;entry['filesAtObservation']=[str(p.relative_to(profile)) for i,p in enumerate(profile.rglob('*')) if i<60];print(label,'started',entry['started'],'seconds',round(entry['startupSeconds'],2),flush=True)
     if label=='new' and entry['started']:
      with(o/'activation-client.log').open('w') as f:result=subprocess.run(['node',str(client),str(o/'activation.json')],cwd=r,env={**env,'EARS_API_PID':str(child.pid)},stdout=f,stderr=subprocess.STDOUT)
      entry['activationExitCode']=result.returncode;assert result.returncode==0,(o/'activation-client.log').read_text()[-5000:]
    finally:
     if child.poll() is None:
      child.send_signal(signal.SIGTERM)
      try:child.wait(timeout=15)
      except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();entry['forcedStop']=True
     entry['finalChildExitCode']=child.returncode
 report['completed']=True;report['allStarted']=all(c['started'] for c in report['controls'])
except BaseException as error:report['failure']={'type':type(error).__name__,'message':str(error)};raise
finally:client.unlink(missing_ok=True);(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
