from pathlib import Path
import os,subprocess,shutil,json,time
r=Path('/electron');o=Path('/results');env={**os.environ,'EARS_VEC1_EXTENSION':str(r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so')};rows=[]
subprocess.run(['tar','--no-same-owner','-xf','/overlay.tar','-C',str(r)],check=True)
target=r/'packages/apack-cli/src/commands/db/target.ts';fixed=target.read_bytes()
base=['node','node_modules/vitest/vitest.mjs','run','--root','packages/apack-cli']
def run(label,args,expected=0):
 start=time.time()
 with (o/(label+'.log')).open('w') as f:p=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 rows.append({'label':label,'args':args,'exitCode':p.returncode,'seconds':time.time()-start});(o/'qualification.json').write_text(json.dumps({'commands':rows},indent=2)+'\n')
 assert p.returncode==expected,(o/(label+'.log')).read_text()[-6000:]
try:
 shutil.copyfile('/baseline-target.ts',target)
 run('baseline-final',base+['tests/commands/db-target.spec.ts','--maxWorkers','1','--minWorkers','1','--reporter=default','--reporter=json','--outputFile=/results/baseline-final.json'],1)
 assert json.loads((o/'baseline-final.json').read_text())['numFailedTests']==5
finally:target.write_bytes(fixed)
run('lint',['node','node_modules/oxlint/bin/oxlint','packages/apack-cli/src/commands/db/target.ts','packages/apack-cli/tests/commands/db-target.spec.ts','-D','correctness'])
run('fixed-final',base+['tests/commands/db-rebuild.spec.ts','tests/commands/db-logical.spec.ts','tests/commands/sqlite-profile.spec.ts','tests/commands/db-target.spec.ts','--maxWorkers','1','--minWorkers','1','--reporter=default','--reporter=json','--outputFile=/results/fixed-final.json'])
run('verifier-syntax',['node','--check','.github/scripts/ears-sqlite-platform.mjs'])
run('outcome-verifier-controls',['node','/verifier.cjs'])
run('backup-verifier-controls',['node','/backup-verifier.cjs'])
print('Original close wrapper 5 failures reproduced; final platform CLI selection and both safety verifier control suites pass; source restored.',flush=True)
