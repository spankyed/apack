const fs = require('node:fs'), assert = require('node:assert/strict'), crypto = require('node:crypto');
const source = fs.readFileSync('/electron/.github/scripts/ears-sqlite-platform.mjs', 'utf8');
const helper = source.slice(source.indexOf('function requirePassingCases('), source.indexOf('const requiredPublicationCases'));
const definition = source.match(/const requiredBackupPublicationCases = \[([\s\S]*?)\n\];/)[0];
const selector = source.match(/^  const reset = .*;$/m)[0];
const call = source.match(/^  requirePassingCases\(reset, requiredBackupPublicationCases,.*;$/m)[0];
const check = Function('assert', 'cli', `${helper}\n${definition}\n${selector}\n${call}\nreturn requiredBackupPublicationCases;`);
const report = JSON.parse(fs.readFileSync('/results/fixed-final.json', 'utf8')), rows = [];
const record = (name, action) => { action(); rows.push({ name, passed: true }); };
const required = check(assert, report);
record('actual passing Linux report', () => assert.equal(required.length, 8));
for (const name of required) for (const mode of ['missing', 'pending']) {
 const copy = structuredClone(report); let mutated = false;
 for (const file of copy.testResults) {
  const i = file.assertionResults.findIndex(test => test.fullName === name);
  if (i < 0) continue;
  if (mode === 'missing') file.assertionResults.splice(i, 1, { fullName: 'unrelated additional passing case', status: 'passed' });
  else file.assertionResults[i].status = mode;
  mutated = true; break;
 }
 assert(mutated, 'Control must reach actual case');
 record(`${mode}: ${name}`, () => assert.throws(() => check(assert, copy), /required case must execute/));
}
const fileOf = copy => copy.testResults.find(file => file.name.replaceAll('\\', '/').endsWith('/tests/commands/sqlite-profile.spec.ts'));
const duplicate = structuredClone(report); fileOf(duplicate).assertionResults.push(structuredClone(fileOf(duplicate).assertionResults[0]));
record('duplicate witness refuses', () => assert.throws(() => check(assert, duplicate), /duplicate witness/));
const extra = structuredClone(report); fileOf(extra).assertionResults.push({ fullName: 'additional passing case', status: 'passed' });
record('additional passing case accepted', () => check(assert, extra));
const windows = structuredClone(report); for (const file of windows.testResults) file.name = file.name.replaceAll('/', '\\');
record('Windows path normalization', () => check(assert, windows));
fs.writeFileSync('/results/backup-cleanup-verifier-controls.json', JSON.stringify({ verifierSha256: crypto.createHash('sha256').update(source).digest('hex'), checks: rows }, null, 2) + '\n');
console.log(`${rows.length} actual-report verifier controls pass`);
