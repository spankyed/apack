// Supported ANN query controls on one closed updated snapshot; diagnostic, never adoption acceptance.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync,openSync,readSync,closeSync,existsSync,writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { setTimeout as pause } from 'node:timers/promises';
import { SqliteDatabase } from '../../src/sqlite/database.ts';
import { SqliteVectorIndex } from '../../src/sqlite/vector-index.ts';
import { createEarsEngine } from '../../src/index.ts';
import { startHeartbeat } from './load-metrics.ts';
const [corpusPath,truthFile,snapshot,output]=process.argv.slice(2);
assert(output&&!existsSync(output));
const sha=data=>createHash('sha256').update(data).digest('hex');
const fileSha=file=>{const fd=openSync(file,'r'),buffer=Buffer.allocUnsafe(1024*1024),h=createHash('sha256');try{for(;;){const n=readSync(fd,buffer,0,buffer.length,null);if(!n)break;h.update(buffer.subarray(0,n));}return h.digest('hex');}finally{closeSync(fd);}};
const manifestBytes=readFileSync(join(corpusPath,'manifest.json')),manifest=JSON.parse(manifestBytes),truthBytes=readFileSync(truthFile),truth=JSON.parse(truthBytes);
assert.equal(truth.protocol,'ears-real-vector-fresh-truth/1');assert.equal(truth.manifestSha256,sha(manifestBytes));
assert.equal(fileSha(join(corpusPath,'corpus.f32')),manifest.files['corpus.f32'].sha256);
const queryOrdinals=Array.from({length:100},(_,q)=>499+999*q);assert.deepEqual(queryOrdinals,truth.queryOrdinals);
const fd=openSync(join(corpusPath,'corpus.f32'),'r'),queryBytes=queryOrdinals.map(ordinal=>{const b=Buffer.alloc(1536*4);assert.equal(readSync(fd,b,0,b.length,ordinal*b.length),b.length);return b;});closeSync(fd);
assert.equal(sha(Buffer.concat(queryBytes)),truth.queriesSha256);
const excluded=new Set(truth.excludedOrdinals);
const vectors=queryBytes.map(b=>Array.from(new Float32Array(b.buffer,b.byteOffset,1536)));
const datafile=join(snapshot,'data.sqlite3'),before=fileSha(datafile);assert.equal(before,process.env.EARS_POLICY_DATABASE_SHA256);
const report={protocol:'ears-readonly-query-policy/1',qualification:false,source:process.env.EARS_TEST_SOURCE,
  partition:'updated-only diagnostic; complete initial/update acceptance remains required',manifestSha256:sha(manifestBytes),truthSha256:sha(truthBytes),
  databaseSha256:before,configurations:[{target:256,nprobe:32},{target:128,nprobe:32},{target:256,nprobe:16},{target:128,nprobe:16}],variants:[],phases:[],node:process.version,arch:process.arch,platform:process.platform};
const pct=(a,p)=>[...a].sort((x,y)=>x-y)[Math.max(0,Math.ceil(a.length*p)-1)]??null;
const summary=a=>({count:a.length,p50:pct(a,.5),p95:pct(a,.95),p99:pct(a,.99),max:Math.max(...a)});
const save=()=>writeFileSync(output,JSON.stringify(report,null,2)+'\n');
const mark=phase=>report.phases.push({phase,wallMs:Date.now(),monotonicMs:performance.now()});
let db;
try{
 db=new SqliteDatabase({path:snapshot,readOnly:true,nativeVectorExtension:process.env.EARS_VEC1_EXTENSION});
 assert.equal(db.readOnly,true);assert.equal(db.sql.readonly,true);
 report.readOnly={requested:db.readOnly,native:db.sql.readonly,queryOnlyFlag:db.sql.pragma('query_only',{simple:true})};
 report.cacheKiB=-db.sql.pragma('cache_size',{simple:true});report.synchronous=db.sql.pragma('synchronous',{simple:true});
 const e=createEarsEngine({database:db}),index=new SqliteVectorIndex(db,process.env.EARS_VEC1_EXTENSION);
 const model=db.get("SELECT generation,model_sha256,state FROM vector_training WHERE state='ready'");assert(model);
 assert.equal(model.model_sha256,process.env.EARS_POLICY_MODEL_SHA256);assert.equal(index.ready(model.generation).model_sha256,model.model_sha256);
 report.model=model;report.sqlite=db.get('SELECT sqlite_version() v').v;
 const all=db.all.bind(db),original=db.indexBuilds.nativeVectorOwners.bind(db.indexBuilds);let active, nativeCalls=0;
 db.all=(sql,parameters=[])=>{
  if(/^SELECT owner FROM ann_\d+\(\?,\?\)/.test(sql)){
   nativeCalls++;assert(active);const options=JSON.parse(parameters[1]);assert.equal(options.nprobe,32);
   parameters=[...parameters];parameters[1]=JSON.stringify({...options,nprobe:active.nprobe});
  }
  return all(sql,parameters);
 };
 function selectedOwners(generation,vector,scope,exclude,target){
  if(!index.ready(generation))return;
  for(let limit=target;limit<=4096;limit*=2){
   const rows=index.candidates(generation,vector,limit,scope,exclude,'owners'),owners=[...new Set(rows.map(row=>Number(row.owner)))];
   if(owners.some(owner=>!Number.isSafeInteger(owner)||owner<1))throw Object.assign(new Error('Invalid native candidate owner'),{code:'CORRUPT'});
   if(owners.length>=target)return owners;
   if(rows.length<limit)break;
  }
 }
 const canonical=createHash('sha256'),expected=createHash('sha256');let count=0;const corpus=openSync(join(corpusPath,'corpus.f32'),'r'),bytes=Buffer.alloc(1536*4);
 try{for(const row of db.statement('SELECT v.embedding FROM embedding_values v JOIN entities e ON e.id=v.entity_id ORDER BY e.seq,v.chunk').iterate()){
   const ordinal=count%100===7?(count+31337)%99900:count;assert.equal(readSync(corpus,bytes,0,bytes.length,ordinal*bytes.length),bytes.length);expected.update(bytes);canonical.update(row.embedding);count++;
 }}finally{closeSync(corpus);}
 assert.equal(count,99900);assert.equal(canonical.digest('hex'),expected.digest('hex'));report.canonicalRowsVerified=count;
 const queryFor=(size,percent)=>{let q=e.query('Row');if(size!==99900)q=q.where(size===1000?'prefix1000':'prefix10000',true);if(percent!==100)q=q.where(percent===10?'scope10':'scope1',true);return q;};
 // Prove the parameterized owner selector reproduces the production helper on the actual persisted model.
 active={target:256,nprobe:32};let controls=0;
 for(const size of [1000,10000,99900])for(const percent of [100,10,1])for(let q=0;q<100;q++){
  db.indexBuilds.nativeVectorOwners=original;const baseline=queryFor(size,percent).near(vectors[q],{k:10}).hits();
  db.indexBuilds.nativeVectorOwners=(generation,vector,scope,exclude)=>selectedOwners(generation,vector,scope,exclude,256);
  const parameterized=queryFor(size,percent).near(vectors[q],{k:10}).hits();assert.deepEqual(parameterized,baseline);controls++;
 }
 report.productionHelperEquivalenceQueries=controls;assert.equal(controls,900);mark('equivalence-complete');save();
 for(const configuration of report.configurations){
  active=configuration;const variant={...configuration,cohorts:[]};report.variants.push(variant);mark('policy-start-'+configuration.target+'-'+configuration.nprobe);
  db.indexBuilds.nativeVectorOwners=(generation,vector,scope,exclude)=>selectedOwners(generation,vector,scope,exclude,configuration.target);
  for(const size of [1000,10000,99900])for(const percent of [100,10,1]){
   const expected=truth.cohorts.find(c=>c.phase==='updated'&&c.size===size&&c.scopePercent===percent);assert(expected);
   const cohort={size,scopePercent:percent,eligible:expected.eligible,passes:[]};variant.cohorts.push(cohort);
   for(let pass=0;pass<4;pass++){
    const samples=[],wallStartMs=Date.now(),pulse=startHeartbeat(1),callsBefore=nativeCalls;
    try{for(let q=0;q<100;q++){
     const wallStartMs=Date.now(),at=performance.now(),hits=queryFor(size,percent).near(vectors[q],{k:10}).hits(),ms=performance.now()-at;
     const ordinals=hits.map(hit=>Number(hit.id.slice(4))),answer=expected.answers[q].ordinals;
     assert.equal(ordinals.length,answer.length);assert.equal(new Set(ordinals).size,ordinals.length);
     assert(ordinals.every(i=>i>=0&&i<size&&i%100<percent&&i%97!==0&&!excluded.has(i)));
     assert(hits.every(hit=>Number.isFinite(hit.score)));
     samples.push({q,ms,wallStartMs,wallEndMs:Date.now(),recall:ordinals.filter(i=>answer.includes(i)).length/answer.length,ordinals,scores:hits.map(hit=>hit.score)});
     await pause(0);
    }}finally{pulse.stop();}
    const result={pass,timed:pass!==0,wallStartMs,wallEndMs:Date.now(),samples,nativeCandidateCalls:nativeCalls-callsBefore,
     meanRecall:samples.reduce((sum,s)=>sum+s.recall,0)/100,latencyMs:summary(samples.map(s=>s.ms)),heartbeatMs:summary(pulse.delaysMs),heartbeatSamples:pulse.delaysMs};
    result.gates={recall:result.meanRecall>=.95,heartbeat:result.heartbeatMs.p99<=16,diagnosticLatency:size<10000||result.latencyMs.p95<=(size===10000?100:200)};
    cohort.passes.push(result);save();console.log(JSON.stringify({target:configuration.target,nprobe:configuration.nprobe,size,percent,pass,recall:result.meanRecall,p95:result.latencyMs.p95,heartbeatP99:result.heartbeatMs.p99}));
   }
  }
  variant.frozenGatesPassed=variant.cohorts.every(c=>c.passes.every(p=>p.gates.recall&&p.gates.heartbeat&&p.gates.diagnosticLatency));
  mark('policy-end-'+configuration.target+'-'+configuration.nprobe);save();
 }
 db.indexBuilds.nativeVectorOwners=original;db.all=all;db.close();db=undefined;
 report.unchangedDatabaseSha256=fileSha(datafile);assert.equal(report.unchangedDatabaseSha256,before);
 report.maxRssKiB=process.resourceUsage().maxRSS;report.completed=true;save();
}catch(error){report.failure={message:error.message,stack:error.stack};save();throw error;}
finally{db?.close();}
