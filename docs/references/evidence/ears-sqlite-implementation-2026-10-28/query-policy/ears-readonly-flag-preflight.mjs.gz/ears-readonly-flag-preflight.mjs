import assert from 'node:assert/strict';
import { mkdtempSync,rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { SqliteDatabase } from '/electron/packages/apack-ears/src/sqlite/database.ts';
const path=mkdtempSync(join(tmpdir(),'ears-readonly-flag-'));
let db;
try{
 db=new SqliteDatabase({path});db.close();
 db=new SqliteDatabase({path,readOnly:true});
 assert.equal(db.readOnly,true);assert.equal(db.sql.readonly,true);
 const queryOnly=db.sql.pragma('query_only',{simple:true});
 assert.throws(()=>db.sql.exec("UPDATE meta SET value=value WHERE key='commit'"),error=>error.code==='SQLITE_READONLY');
 console.log(JSON.stringify({requestedReadOnly:db.readOnly,nativeReadonly:db.sql.readonly,queryOnly,mainWriteRefused:true}));
}finally{db?.close();rmSync(path,{recursive:true,force:true});}
