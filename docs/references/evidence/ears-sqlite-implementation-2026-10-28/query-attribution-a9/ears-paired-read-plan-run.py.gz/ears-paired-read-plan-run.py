from pathlib import Path
import json,hashlib,subprocess,os,time
r=Path('/electron');o=Path('/results');started=time.time();report={'source':'a9c9340df74f90b85434e8ddafa9742bd6867cbf','qualification':False,'steps':[]}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
 meta=json.loads((o/'source.json').read_text());assert sha(Path('/probe.mjs'))==meta['probeSha256']
 limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'};report['limits']=limits
 s=json.loads(Path('/sqlite-witness.json').read_text());files={'native':r/'.temp/ears-native-resumed-a2D0Vp/database/data.mdb','sqlite':Path(s['variants'][0]['retainedCandidate'])/'data.sqlite3'}
 report['mainSha256Before']={k:sha(p) for k,p in files.items()}
 for backend in ['sqlite','native']:
  env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_TEST_SOURCE':report['source']}
  with(o/(backend+'.log')).open('w') as log:p=subprocess.run(['node','--import','tsx','/probe.mjs',backend,str(o/(backend+'.json'))],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  report['steps'].append({'backend':backend,'exitCode':p.returncode});assert p.returncode==0,(o/(backend+'.log')).read_text()[-6000:]
  d=json.loads((o/(backend+'.json')).read_text());assert d['completed'] and len(d['observations'])==24 and len(d['explanations'])==12
 report['mainSha256After']={k:sha(p) for k,p in files.items()};assert report['mainSha256Before']==report['mainSha256After'];report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
