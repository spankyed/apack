import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {readFileSync,writeFileSync,renameSync} from 'node:fs';
import {setTimeout as pause} from 'node:timers/promises';
import {createEarsEngine} from '/electron/packages/apack-ears/src/index.ts';
import {adaptDatabase} from '/electron/packages/apack-ears/src/lmdb/adapter.ts';
import {SqliteDatabase} from '/electron/packages/apack-ears/src/sqlite/database.ts';
const [backend,output]=process.argv.slice(2);assert(['native','sqlite'].includes(backend)&&output);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const corpus=readFileSync('/corpus/corpus.f32'),manifest=JSON.parse(readFileSync('/corpus/manifest.json','utf8'));
assert.equal(sha(corpus),manifest.files['corpus.f32'].sha256);
const witness=JSON.parse(readFileSync(backend==='native'?'/native-witness.json':'/sqlite-witness.json','utf8'));
const cohorts=(backend==='native'?witness:witness.variants[0]).cohorts;
const indices=[0,17,53],vectors=new Map(indices.map(q=>{const i=499+999*q;return[q,Array.from(new Float32Array(corpus.buffer,corpus.byteOffset+i*1536*4,1536))];}));
const scopes=[[1000,10],[10000,1],[99900,100],[99900,10]];
const report={source:process.env.EARS_TEST_SOURCE,backend,qualification:false,readOnly:true,
 scope:'Updated retained copies only; CPU/wall and explain attribution, not replacement benchmark or OS-cold evidence',observations:[],explanations:[]};
const save=()=>{writeFileSync(output+'.next',JSON.stringify(report,null,2)+'\n');renameSync(output+'.next',output);};
let db;
try {
 if(backend==='native') {
  const binding='/electron/.temp/elmdb-2441-source/crates/elmdb-node/elmdb.linux-arm64-gnu.node';
  assert.equal(sha(readFileSync(binding)),'5d813c95e373c79f36c47889c75b0491b8987c7cc6f9669f4428e4dd69a27687');
  db=adaptDatabase(createRequire(import.meta.url)(binding).Database.open('/electron/.temp/ears-native-resumed-a2D0Vp/database',{readOnly:true}));
 } else {
  const extension='/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so';
  assert.equal(sha(readFileSync(extension)),'b16f6c4fcd84c776c1c3e1d3f2df33a5229dc987a1b8fd3b7d0343683fc10fd0');
  db=new SqliteDatabase({path:witness.variants[0].retainedCandidate,readOnly:true,nativeVectorExtension:extension});
  assert.equal(db.sql.readonly,true);
 }
 assert.equal(db.readOnly,true);const e=createEarsEngine({database:db});
 const query=(size,percent,q)=>{
  let x=e.query('Row');if(size!==99900)x=x.where(size===1000?'prefix1000':'prefix10000',true);
  if(percent!==100)x=x.where(percent===10?'scope10':'scope1',true);
  return x.near(vectors.get(q),{k:10});
 };
 const scrub=value=>{
  if(ArrayBuffer.isView(value))return{bytes:value.byteLength,sha256:sha(Buffer.from(value.buffer,value.byteOffset,value.byteLength))};
  if(typeof value==='string'&&value.length>200)return{stringLength:value.length,sha256:sha(value)};
  if(Array.isArray(value))return value.map(scrub);
  return value;
 };
 for(const [size,percent] of scopes) {
  const expected=cohorts.find(c=>c.phase==='updated'&&c.size===size&&c.scopePercent===percent);assert(expected);
  for(const pass of [0,1])for(const q of indices){
   const cpu=process.cpuUsage(),at=performance.now(),hits=query(size,percent,q).hits(),wallMs=performance.now()-at,cpuUsed=process.cpuUsage(cpu);
   const prior=expected.passes[3].samples[q];assert.equal(prior.q,q);
   assert.deepEqual(hits.map(h=>Number(h.id.slice(4))),prior.ordinals);
   assert.deepEqual(hits.map(h=>h.score),prior.scores);
   report.observations.push({size,percent,q,pass,wallMs,cpuUserMs:cpuUsed.user/1000,cpuSystemMs:cpuUsed.system/1000,ids:hits.map(h=>h.id)});
   await pause(0);
  }
  for(const q of indices){
   const explained=query(size,percent,q).explain();
   assert.deepEqual(explained.ids,report.observations.find(x=>x.size===size&&x.percent===percent&&x.q===q).ids);
   if(explained.backend==='sqlite')for(const statement of explained.statements)statement.parameters=statement.parameters.map(scrub);
   report.explanations.push({size,percent,q,...explained});await pause(0);
  }
  save();console.log(JSON.stringify({backend,size,percent,observations:report.observations.length,explanations:report.explanations.length}));
 }
 assert.equal(report.observations.length,24);assert.equal(report.explanations.length,12);report.completed=true;save();
}catch(error){report.failure={message:error.message,stack:error.stack};save();throw error;}
finally{db?.close();}
