from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');inputs=json.loads((o/'inputs.json').read_text())
for n,h in inputs.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
p=r/'packages/apack-ears/bench/sqlite/native-qprofile.mjs';shutil.copyfile('/probe.mjs',p)
meta=json.loads((o/'source.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['probeSha256']
subprocess.run(['node','--check',str(p)],check=True)
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
args=['node','--import','tsx',str(p),'/corpus','/truth/truth.json','/electron/.temp/ears-query-attribution-retained','/results/native-qprofile.json'];env={**os.environ,'EARS_TEST_SOURCE':meta['source'],'EARS_VEC1_EXTENSION':str(r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so'),'EARS_POLICY_MODEL_SHA256':meta['expectedModelSha256'],'EARS_POLICY_DATABASE_SHA256':meta['expectedDatabaseSha256']}
start=time.time()
with(o/'native-qprofile.log').open('w') as f:result=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
(o/'run.json').write_text(json.dumps({'source':meta['source'],'limits':limits,'args':args,'exitCode':result.returncode,'startedWallMs':start*1000,'endedWallMs':time.time()*1000,'seconds':time.time()-start,'inputs':inputs},indent=2)+'\n');print('Query attribution exit',result.returncode,flush=True)
assert result.returncode==0,(o/'native-qprofile.log').read_text()[-6000:]
d=json.loads((o/'native-qprofile.json').read_text());assert d['completed'] and not d.get('failure') and len(d['cohorts'])==9
assert d['databaseSha256']==d['unchangedDatabaseSha256'] and all(len(c['samples'])==100 for c in d['cohorts'])
print('Upstreamnative profiler complete; snapshot bytes unchanged; no production change',flush=True)
