from pathlib import Path
import subprocess,json,os,hashlib,time
r=Path('/electron');o=Path('/results');report={'source':'d57021f70e','scope':'Two current source/test files mounted read-only over frozen a9 dependencies; focused regressions only'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_EVALUATION_BACKEND':'sqlite','EARS_VEC1_EXTENSION':'/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so'}
 args=['node','/electron/node_modules/vitest/vitest.mjs','run','tests/sqlite/vector-models.spec.ts','--maxWorkers=1','-t','expands repeated chunk owners|recovers a durable training attempt','--reporter=default','--reporter=json','--outputFile=/results/tests.json']
 with(o/'test.log').open('w') as log:p=subprocess.run(args,cwd=r/'packages/apack-ears',env=env,stdout=log,stderr=subprocess.STDOUT)
 report['exitCode']=p.returncode
 if p.returncode:print((o/'test.log').read_text()[-6000:],flush=True)
 report['completed']=True
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(report['exitCode'])
