import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,readdirSync,statSync,openSync,closeSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {SqliteDatabase} from '/electron/packages/apack-ears/src/sqlite/database.ts';
import {createEarsEngine} from '/electron/packages/apack-ears/src/index.ts';
import {toElmdbSchema} from '/electron/packages/apack-ears/src/schema.ts';
const [mode,output]=process.argv.slice(2);assert(['prepare','read'].includes(mode));assert(output&&!existsSync(output));
const root='/electron/.temp/ears-physical-readonly-aea408',schema=toElmdbSchema({types:{Row:{required:[]}},relations:{},roles:[]});
const digest=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
const snapshot=()=>Object.fromEntries(['live','backup'].flatMap(kind=>readdirSync(join(root,kind)).map(name=>[kind+'/'+name,{bytes:statSync(join(root,kind,name)).size,sha256:digest(join(root,kind,name))}])));
const report={protocol:'ears-real-readonly-mount/1',source:process.env.EARS_TEST_SOURCE,mode,cases:[]};
try{
 if(mode==='prepare'){
  assert(!existsSync(root));mkdirSync(root,{recursive:true});const db=new SqliteDatabase({path:join(root,'live'),schema});
  try{const e=createEarsEngine({database:db});e.create('Row',{id:'Row-incumbent',title:'read-only mount witness'});await db.durable();db.backup(join(root,'backup'));report.sequence=db.sequence;}finally{db.close();}
  report.before=snapshot();writeFileSync(join(root,'preparation.json'),JSON.stringify(report,null,2)+'\n');
 }else{
  report.before=snapshot();assert.deepEqual(report.before,JSON.parse(readFileSync(join(root,'preparation.json'))).before);
  let fd,refusal;try{fd=openSync(join(root,'backup/data.sqlite3'),'r+');}catch(error){refusal=error;}finally{if(fd!==undefined)closeSync(fd);}
  assert.equal(refusal?.code,'EROFS','Require real kernel read-only mount, not chmod under root');report.kernelWriteRefusal=refusal.code;
  for(const kind of ['live','backup']){
   const entry={kind};report.cases.push(entry);let db;
   try{
    db=new SqliteDatabase({path:join(root,kind),readOnly:true});const e=createEarsEngine({database:db});
    assert.deepEqual(e.query('Row').pickAll('title'),[{id:'Row-incumbent',title:'read-only mount witness'}]);entry.sequence=db.sequence;entry.readPassed=true;
    assert.throws(()=>e.create('Row',{id:'Row-refused'}),error=>error.code==='READ_ONLY');entry.logicalWriteRefused=true;
   }catch(error){entry.error={code:error.code,message:error.message};throw error;}finally{db?.close();}
  }
  report.after=snapshot();assert.deepEqual(report.after,report.before);report.filesUnchanged=true;
 }
 report.completed=true;
}catch(error){report.failure={code:error.code,message:error.message,stack:error.stack};throw error;}
finally{writeFileSync(output,JSON.stringify(report,null,2)+'\n');}
