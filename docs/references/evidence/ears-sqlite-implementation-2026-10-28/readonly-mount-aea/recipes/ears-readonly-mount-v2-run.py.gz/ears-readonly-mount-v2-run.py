from pathlib import Path
import json,subprocess,time,hashlib
root=Path('/private/tmp/ears-readonly-mount-v2-results');root.mkdir(exist_ok=False)
report={'source':'aea408425154c52f46de5b5abd8de6ba181c9922','limits':{'cpus':0.5,'memory':'768m','memorySwap':'768m','capDrop':'ALL'},'steps':[]};start=time.time()
try:
 for mode in ['read']:
  args=['docker','run','--rm','--name','ears-readonly-mount-'+mode,'--cpus','.5','--memory','768m','--memory-swap','768m','--cap-drop','ALL','-v','ears-electron-runtime-work:/electron'+(':ro' if mode=='read' else ''),'-v','/private/tmp/ears-readonly-mount-probe-v2.mjs:/probe.mjs:ro','-v',str(root)+':/results','-w','/electron','-e','EARS_TEST_SOURCE='+report['source'],'-e','NODE_OPTIONS=--conditions=@apackdev/source --max-old-space-size=512','apack-linux-test:74d4b8cfe839','node','--import','tsx','/probe.mjs',mode,'/results/'+mode+'.json']
  at=time.time()
  with(root/(mode+'.log')).open('w') as f:result=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
  report['steps'].append({'mode':mode,'exitCode':result.returncode,'seconds':time.time()-at});print(mode,result.returncode,flush=True);assert result.returncode==0,(root/(mode+'.log')).read_text()[-5000:]
 report['completed']=True
except BaseException as e:report['failure']=str(e);raise
finally:report['seconds']=time.time()-start;(root/'run.json').write_text(json.dumps(report,indent=2)+'\n')
