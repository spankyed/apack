import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { SqliteDatabase } from '/electron/packages/apack-ears/src/sqlite/database.ts';
const root=mkdtempSync(join(tmpdir(),'ears-allocation-binding-'));
const db=new SqliteDatabase({path:root});
try {
  db.loadNativeVectors('/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so');
  db.sql.exec('CREATE VIRTUAL TABLE ann_config USING vec1(v,owner,active)');
  for (const minimum of [16384,4096]) {
    assert.equal(db.get('SELECT typeof(?) type',[minimum]).type,'real');
    assert.throws(()=>db.run("INSERT INTO ann_config(cmd,arg) VALUES ('blocksize-min',?)",[minimum]),/requires an integer/);
    assert.equal(db.get('SELECT typeof(?) type',[BigInt(minimum)]).type,'integer');
    db.run("INSERT INTO ann_config(cmd,arg) VALUES ('blocksize-min',?)",[BigInt(minimum)]);
    console.log(JSON.stringify({minimum,numberRejected:true,bigintAccepted:true}));
  }
} finally { db.close();rmSync(root,{recursive:true,force:true}); }
