from pathlib import Path
import json,hashlib,subprocess
r=Path('/private/tmp/ears-sqlite-query-integration');s=(r/'packages/apack-ears/bench/sqlite/real-vector-ears.mjs').read_text()
prefix=s[:s.index('  if(fresh) {\n    const job=db.indexBuilds.jobs()')]
prefix=prefix.replace("import { SqliteVectorModels }", "import { SqliteVectorIndex } from '../../src/sqlite/vector-index.ts';\nimport { SqliteVectorTraining } from '../../src/sqlite/vector-training.ts';\nimport { copyFileSync, mkdirSync } from 'node:fs';\nimport { SqliteVectorModels }",1)
prefix=prefix.replace('const report = {','let report = {',1).replace('JSON.stringify(report,null,2)', 'JSON.stringify(rootReport??report,null,2)',1).replace('let db,models,nativeCalls=0;','let db,models,nativeCalls=0,rootReport;',1).replace('if(fresh)models=new SqliteVectorModels(db,process.env.EARS_VEC1_EXTENSION);','if(fresh)new SqliteVectorIndex(db,process.env.EARS_VEC1_EXTENSION);',1).replace('  const e = createEarsEngine({database:db}), ids=[], updates=[];','  let e = createEarsEngine({database:db}); const ids=[], updates=[];',1)
# The initial load, sealed corpus/oracle checks and all query/update assertions stay verbatim.
q=s[s.index('  const queryFor='):s.index('  if(diagnostic) {\n    report.sql=')]
a=s.index("  for(const phase of ['initial','updated'])");b=s.index('  if(fresh&&!diagnostic)',a);matrix=s[a:b];assert matrix.endswith('  }\n  }\n');matrix=matrix[:-4]
gates=s[s.index('  if(fresh&&!diagnostic)'):s.index('  report.maxRssKiB=')]
body='''
  rootReport=report; rootReport.protocol='ears-fixed-model-allocation/1';rootReport.qualification=false;
  const job=db.indexBuilds.jobs().find(job=>job.type==='Row'&&job.kind==='vector');assert(job);
  const training=new SqliteVectorTraining(db,process.env.EARS_VEC1_EXTENSION),trainingAt=performance.now();
  const trained=await training.train(job);await training.stop();
  rootReport.model={sha256:trained.modelSha256,samples:trained.samples,sourceCommitHex:trained.sourceCommitHex,
    extensionSha256:trained.extensionSha256,workerSha256:trained.workerSha256,trainingMs:performance.now()-trainingAt};
  const base=join(path,'base');db.backup(base);db.close();db=undefined;
  const common={...rootReport};rootReport.variants=[];
  // Each configuration starts from the same closed, audited-by-byte snapshot before physical admission.
  for(const minimum of [16384,4096]) {
    const candidate=join(path,'variant-'+minimum);mkdirSync(candidate);copyFileSync(join(base,'data.sqlite3'),join(candidate,'data.sqlite3'));
    db=new SqliteDatabase({path:candidate});e=createEarsEngine({database:db});nativeCalls=0;
    const index=new SqliteVectorIndex(db,process.env.EARS_VEC1_EXTENSION);
    report={...common,minimum,cohorts:[],projection:[],modelSha256:trained.modelSha256};rootReport.variants.push(report);
    assert.equal(canonicalHash(false),size);assert.equal(db.sql.pragma('synchronous',{simple:true}),2);
    assert.equal(db.sql.pragma('wal_autocheckpoint',{simple:true}),1000);
    const pulse=startHeartbeat(1),begin=performance.now();let batches=0,ready=false;
    db.sql.exec('BEGIN IMMEDIATE');
    try {
      index.admit(job,trained.model);
      const physical=db.get("SELECT id FROM vector_indexes WHERE generation=? AND state='building'",[job.generation]);
      db.run(`INSERT INTO ann_${physical.id}(cmd,arg) VALUES ('blocksize-min',?)`,[BigInt(minimum)]);db.commitWrite();
    }catch(error){if(db.sql.inTransaction)db.sql.exec('ROLLBACK');throw error;}
    try {
      while(!ready) {
        const previous=db.get("SELECT after_id FROM vector_indexes WHERE generation=? AND state='building'",[job.generation]).after_id;
        const start=performance.now();db.sql.exec('BEGIN IMMEDIATE');let projected,committed;
        try {ready=index.step(job.generation,128);projected=performance.now();db.commitWrite();committed=performance.now();}
        catch(error){if(db.sql.inTransaction)db.sql.exec('ROLLBACK');throw error;}
        report.projection.push({projectionMs:projected-start,commitMs:committed-projected,totalMs:committed-start});
        assert(++batches<=size+2);if(!ready)assert(db.get("SELECT after_id FROM vector_indexes WHERE generation=? AND state='building'",[job.generation]).after_id>previous);
        await new Promise(resolve=>setImmediate(resolve));
      }
    }finally{pulse.stop();}
    report.admission={ms:performance.now()-begin,batches,heartbeat:summary(pulse.delaysMs),samples:pulse.delaysMs};
    assert.equal(db.get("SELECT count(*) n FROM vector_indexes WHERE state='ready'").n,1);
    assert.equal(canonicalHash(false),size);
    const all=db.all.bind(db);db.all=(sql,params=[])=>{if(/FROM ann_\\d+\\(\\?,\\?\\)/.test(sql))nativeCalls++;return all(sql,params);};
    save();console.log(JSON.stringify({stage:'allocation-ready',minimum,admission:report.admission.ms,heartbeat:report.admission.heartbeat}));
'''
ending='''
    report.maxRssKiB=process.resourceUsage().maxRSS;
    report.databaseBytes=statSync(join(candidate,'data.sqlite3')).size;report.walBytes=statSync(join(candidate,'data.sqlite3-wal')).size;
    report.canonicalRowsVerified=canonicalHash(true);assert.equal(report.canonicalRowsVerified,size);
    db.close();db=undefined;rmSync(candidate,{recursive:true,force:true});save();
  }
  report=rootReport;report.completed=true;save();
} catch(error){(rootReport??report).failure={message:error.message,stack:error.stack};save();throw error;}
finally{try{await models?.stop();}finally{db?.close();rmSync(path,{recursive:true,force:true});}}
'''
text=prefix+body+q+matrix+gates+ending
Path('/private/tmp/ears-allocation-study.mjs').write_text(text)
o=Path('/private/tmp/ears-allocation-study-results');o.mkdir(exist_ok=True)
files=subprocess.check_output(['git','ls-files','packages/apack-ears/src','native/vectors'],cwd=r,text=True).splitlines()
(o/'inputs.json').write_text(json.dumps({n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in files},indent=2)+'\n')
(o/'source.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'baseProbeSha256':hashlib.sha256(s.encode()).hexdigest(),'probeSha256':hashlib.sha256(text.encode()).hexdigest(),'sameModel':True,'queryMatrix':'verbatim initial/updated 1k/10k/99900 x100/10/1percent x100queries x4passes','configurations':[16384,4096],'qualification':False},indent=2)+'\n')
