from pathlib import Path
import subprocess,json,hashlib,os,time,signal,re
r=Path('/electron');o=Path('/results');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'source':'45180293a3248ea7ec364672fb294ed1f322fc9c','qualification':False,'purpose':'Correct missing native artifact setting; separate prefix search/growth evidence from retained native model-based timeout. Not a retry or replacement of the full failed suite.','steps':[]}
def run(label,args,timeout=600,dist=False):
 env={**os.environ,'EARS_EVALUATION_BACKEND':'sqlite','EARS_VEC1_EXTENSION':'/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so','NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_COST_SOURCE':report['source']}
 if dist:env.pop('NODE_OPTIONS',None)
 at=time.monotonic()
 try:
  with(o/(label+'.log')).open('w') as f:
   p=subprocess.Popen(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait();raise
  step={'label':label,'exitCode':code,'seconds':time.monotonic()-at}
 except subprocess.TimeoutExpired:step={'label':label,'timeoutSeconds':timeout,'seconds':time.monotonic()-at}
 report['steps'].append(step);(o/'run.json').write_text(json.dumps(report,indent=2));print(label,step,flush=True)
try:
 previous=json.loads(Path('/prior/run.json').read_text());assert previous.get('failure') or previous.get('completed'),'Prior run must be terminal'
 limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'};report['limits']=limits
 for n,h in json.loads(Path('/expected/inputs.json').read_text()).items():
  if n=='packages/apack-ears/src/sqlite/text.ts':h=sha(Path('/prototype/src/sqlite/text.ts'))
  assert sha(r/n)==h,n
 artifact=r/'packages/apack-ears/dist/sqlite/native/linux-arm64';manifest=json.loads((artifact/'manifest.json').read_text());assert sha(artifact/'vec1.so')==manifest['extensionSha256'];assert manifest['sourceSha256']=='04043ede29b2998b2cd0e7735cc696dba2158554a0bf9036e2a77849dec0425a';report['nativeManifest']=manifest
 base=['node','node_modules/vitest/vitest.mjs','run','--root','packages/apack-ears','--maxWorkers=2','--reporter=default','--reporter=json']
 requested=['tests/engine/search.spec.ts','tests/engine/search-relevance.spec.ts']+['tests/sqlite/'+n+'.spec.ts' for n in ['text-typos','text-limits','search-recovery','text-documents','search-builds']]
 passed=set(re.findall(r'^\s*✓ (tests/\S+\.spec\.ts) \(\d+ tests\)',Path('/prior/sqlite-contracts.log').read_text(),flags=re.MULTILINE))
 needed=[n for n in requested if n not in passed];report['affectedFilesAlreadyPassed']=sorted(set(requested)&passed);report['affectedFilesRemaining']=needed
 if needed:run('prefix-focused',base+needed+['--outputFile=/results/prefix-focused.json'])
 run('prefix-growth',['node','/cost.mjs',str(o/'growth.json')],timeout=180,dist=True)
 # Corrected setup runs exactly the four files that require the missing setting.
 run('native-missing',base+['tests/sqlite/'+n+'.spec.ts' for n in ['vector-models','vector-audit','vector-training','vector-index']]+['--outputFile=/results/native-missing.json'])
 report['completed']=True;report['allStepsPassed']=all(x.get('exitCode')==0 for x in report['steps'])
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
