from pathlib import Path
import subprocess,time,os,json
cid=Path('/private/tmp/ears-prefix-followup.cid');assert not cid.exists(),'A query policy run has already been created; inspect it instead'
Path('/private/tmp/ears-prefix-followup-admission.pid').write_text(str(os.getpid())+'\n')
prior=json.loads(Path('/private/tmp/ears-prefix-qualification-results/run.json').read_text());assert prior.get('failure') or prior.get('completed'),'Prior prefix run not terminal'
quiet=None;last=0
print('Waiting for 30 seconds with no running containers before admitting the existing native query-profiler diagnostic',flush=True)
while True:
 if Path('/private/tmp/ears-prefix-followup-admission.stop').exists():raise SystemExit('Admission stopped before container creation')
 p=subprocess.run(['docker','ps','-q'],capture_output=True,text=True)
 now=time.monotonic()
 if p.returncode or p.stdout.strip():quiet=None
 elif quiet is None:quiet=now
 if now-last>=20:
  print(json.dumps({'pid':os.getpid(),'otherContainers':p.stdout.splitlines(),'quietSeconds':0 if quiet is None else round(now-quiet),'dockerExitCode':p.returncode,'dockerError':p.stderr.strip()[:240]}),flush=True);last=now
 if quiet is not None and now-quiet>=30:
  p=subprocess.run(['python3','/private/tmp/ears-run-prefix-followup.py'])
  if cid.exists():raise SystemExit(p.returncode) # A started run is never restarted by this admission watcher.
  if p.returncode==0:raise SystemExit('Runner exited without creating its expected container')
  quiet=None # The final admission guard caught a new competing build; no check has started yet.
 time.sleep(2)
