from pathlib import Path
import subprocess,os,hashlib,json,time,shutil
r=Path('/electron');o=Path('/results');subprocess.run(['tar','--no-same-owner','-xf','/inputs.tar','-C',str(r)],check=True)
for n,h in json.loads((o/'inputs.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
p=r/'tests/e2e/ui/host-settings.spec.ts'
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
report={'limits':limits,'specSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'steps':[]};env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=4096'}
try:
 for name,args in [('lint',['./node_modules/.bin/oxlint','tests/e2e/ui/host-settings.spec.ts','-D','correctness']),('types',['node','node_modules/typescript/bin/tsc','-p','tests','--noEmit','--incremental','false'])]:
  at=time.time()
  with (o/(name+'.log')).open('w') as f:p=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
  report['steps'].append({'name':name,'exitCode':p.returncode,'seconds':time.time()-at});print(name,p.returncode,flush=True)
  assert p.returncode==0,(o/(name+'.log')).read_text()[-5000:]
 report['completed']=True
except BaseException as e:report['failure']=str(e);raise
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
