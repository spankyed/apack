import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream,readFileSync,openSync,readSync,closeSync,statSync,rmSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {Packr,unpack} from 'msgpackr';
const output=process.argv[2],path='/electron/.temp/ears-native-resumed-a2D0Vp/database',cli='/electron/.temp/elmdb-2441-target/release/elmdb',dump='/tmp/ears-native-canonical.dump';
assert(output);assert.equal(createHash('sha256').update(readFileSync(cli)).digest('hex'),'b3992070d8c9a3c9ad28e37576f8a101fe2a570391d0e157289fffa85fbdbf2c');
const hashFile=async p=>{const h=createHash('sha256');for await(const b of createReadStream(p))h.update(b);return h.digest('hex');};
const report={qualification:false,scope:'Read-only diagnosis of failed resumed-copy canonical check; no embeddings or primary writes',path,embeddings:0,mismatchingVectors:0,mismatchingComponents:0,zeroSignChanges:0,otherChanges:0,samples:[]};
report.limits=Object.fromEntries(['cpu.max','memory.max','memory.swap.max'].map(n=>[n,readFileSync('/sys/fs/cgroup/'+n,'utf8').trim()]));assert.deepEqual(report.limits,{'cpu.max':'50000 100000','memory.max':'805306368','memory.swap.max':'0'});
report.mainHashBefore=await hashFile(path+'/data.mdb');
const codec=new Packr({useRecords:false,skipValues:[undefined]}),encoded=codec.pack([-0]);report.codecNegativeZero={encodedHex:Buffer.from(encoded).toString('hex'),inputIsNegativeZero:Object.is(-0,-0),decodedIsNegativeZero:Object.is(unpack(encoded)[0],-0)};
let fd,corpus;
try{
 const result=spawnSync(cli,['dump',path,dump],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);
 fd=openSync(dump,'r');corpus=openSync('/corpus/corpus.f32','r');let offset=0,count=0;
 const read=n=>{const b=Buffer.alloc(n);let done=0;while(done<n){const amount=readSync(fd,b,done,n-done,offset+done);assert(amount>0);done+=amount;}offset+=n;return b;};
 assert.equal(read(8).toString(),'ELMDBDMP');assert.equal(read(4).readUInt32LE(),1);read(read(4).readUInt32LE());
 for(;;){const length=read(4).readUInt32LE();if(length===0xffffffff){assert.equal(read(8).readBigUInt64LE(),BigInt(count));break;}assert(length<128*1024);const row=unpack(read(length));count++;
  if(row.load!=='embedding')continue;report.embeddings++;const ordinal=Number(row.id.slice(4));assert(Number.isInteger(ordinal)&&ordinal>=0&&ordinal<99900);assert.equal(row.vector.length,1536);const expected=Buffer.alloc(6144);assert.equal(readSync(corpus,expected,0,6144,ordinal*6144),6144);const actual=Buffer.from(Float32Array.from(row.vector).buffer);let mismatched=false;
  for(let j=0;j<1536;j++)if(actual.readUInt32LE(j*4)!==expected.readUInt32LE(j*4)){mismatched=true;report.mismatchingComponents++;const a=actual.readFloatLE(j*4),e=expected.readFloatLE(j*4),zero=a===0&&e===0;if(zero)report.zeroSignChanges++;else report.otherChanges++;if(report.samples.length<12)report.samples.push({id:row.id,component:j,expectedBits:expected.readUInt32LE(j*4).toString(16),actualBits:actual.readUInt32LE(j*4).toString(16),expected:e,actual:a,zeroSignOnly:zero});}
  if(mismatched)report.mismatchingVectors++;
 }
 assert.equal(offset,statSync(dump).size);report.loads=count;report.completed=true;
}catch(error){report.failure={message:error.message,stack:error.stack};throw error;}
finally{if(fd!==undefined)closeSync(fd);if(corpus!==undefined)closeSync(corpus);rmSync(dump,{force:true});report.mainHashAfter=await hashFile(path+'/data.mdb');assert.equal(report.mainHashAfter,report.mainHashBefore);writeFileSync(output,JSON.stringify(report,null,2)+'\n');}
