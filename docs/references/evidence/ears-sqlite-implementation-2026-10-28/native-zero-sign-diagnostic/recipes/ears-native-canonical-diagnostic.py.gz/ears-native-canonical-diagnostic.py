from pathlib import Path
import subprocess,shutil,json
r=Path('/electron');p=r/'packages/apack-ears/bench/sqlite/native-canonical-diagnostic.mjs';assert not p.exists();shutil.copyfile('/probe.mjs',p)
try:
 with Path('/results/probe.log').open('w') as f:
  result=subprocess.run(['node',str(p),'/results/probe.json'],cwd=r,stdout=f,stderr=subprocess.STDOUT)
 assert result.returncode==0
finally:p.unlink(missing_ok=True)
