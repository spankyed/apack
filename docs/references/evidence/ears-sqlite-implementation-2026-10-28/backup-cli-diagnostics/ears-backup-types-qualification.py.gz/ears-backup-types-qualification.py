from pathlib import Path
import subprocess,os,json,hashlib,time
r=Path('/electron');o=Path('/results');subprocess.run(['tar','--no-same-owner','-xf','/overlay.tar','-C',str(r)],check=True)
inputs=json.loads((o/'inputs.json').read_text())
for p,h in inputs.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
rows=[];env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=4096','EARS_VEC1_EXTENSION':str(r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so')}
commands=[('cli-types',['node','node_modules/typescript/bin/tsc','-p','packages/apack-cli','--noEmit','--incremental','false']),('testing-types',['node','node_modules/typescript/bin/tsc','-p','packages/apack-testing','--noEmit','--incremental','false']),('packages',['npm','run','packages:build']),('lint',['node','node_modules/oxlint/bin/oxlint','packages/apack-cli/src/commands/db/backup.ts','packages/apack-cli/tests/commands/sqlite-profile.spec.ts','-D','correctness']),('platform-cli',['node','node_modules/vitest/vitest.mjs','run','--root','packages/apack-cli','tests/commands/db-rebuild.spec.ts','tests/commands/db-logical.spec.ts','tests/commands/sqlite-profile.spec.ts','tests/commands/db-target.spec.ts','--maxWorkers','2','--minWorkers','1','--reporter=default','--reporter=json','--outputFile=/results/platform-cli.json'])]
for label,args in commands:
 started=time.time()
 with(o/(label+'.log')).open('w') as f:p=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'label':label,'args':args,'exitCode':p.returncode,'seconds':time.time()-started});(o/'qualification.json').write_text(json.dumps({'parent':'a8e12b1cd1fbbbb47ec8c4d149669319d836b53e','inputs':inputs,'limits':limits,'commands':rows},indent=2)+'\n');print(label,p.returncode,flush=True)
 assert p.returncode==0,(o/(label+'.log')).read_text()[-6000:]
