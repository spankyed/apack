from pathlib import Path
import json,hashlib,subprocess,os,tempfile,shutil,time
r=Path('/electron');o=Path('/results');started=time.time();report={'source':'a9c9340df74f90b85434e8ddafa9742bd6867cbf','qualification':False}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
original=Path(json.loads(Path('/sqlite-witness.json').read_text())['variants'][0]['retainedCandidate'])/'data.sqlite3'
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
 meta=json.loads((o/'source.json').read_text());assert sha(Path('/probe.mjs'))==meta['probeSha256']
 limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'};report['limits']=limits
 report['originalShaBefore']=sha(original);assert report['originalShaBefore']=='60cf59f596e5c3dfb2dfcd2d1b8ec43017fff4c4aace1bcd4c47d120828bc21e'
 assert shutil.disk_usage(r/'.temp').free>=8*1024**3
 work=Path(tempfile.mkdtemp(prefix='ears-sqlite-owner-reuse-',dir=r/'.temp'));report['ownedCopy']=str(work);shutil.copyfile(original,work/'data.sqlite3');assert sha(work/'data.sqlite3')==report['originalShaBefore']
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_TEST_SOURCE':report['source']}
 with(o/'probe.log').open('w') as log:p=subprocess.run(['node','--import','tsx','/probe.mjs',str(work),str(o/'probe.json')],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 report['exitCode']=p.returncode;assert p.returncode==0,(o/'probe.log').read_text()[-6000:]
 d=json.loads((o/'probe.json').read_text());assert d['completed'] and len(d['observations'])==144 and len(d['explanations'])==8
 report['originalShaAfter']=sha(original);assert report['originalShaBefore']==report['originalShaAfter'];report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
