import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,renameSync} from 'node:fs';
import {setTimeout as pause} from 'node:timers/promises';
import {createEarsEngine} from '/electron/packages/apack-ears/src/index.ts';
import {SqliteDatabase} from '/electron/packages/apack-ears/src/sqlite/database.ts';
const [copy,output]=process.argv.slice(2);assert(copy&&output);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const extension='/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so';assert.equal(sha(readFileSync(extension)),'b16f6c4fcd84c776c1c3e1d3f2df33a5229dc987a1b8fd3b7d0343683fc10fd0');
const corpus=readFileSync('/corpus/corpus.f32'),manifest=JSON.parse(readFileSync('/corpus/manifest.json','utf8'));assert.equal(sha(corpus),manifest.files['corpus.f32'].sha256);
const witness=JSON.parse(readFileSync('/sqlite-witness.json','utf8')).variants[0];
const qs=[0,17,53],vectors=new Map(qs.map(q=>{const i=499+999*q;return[q,Array.from(new Float32Array(corpus.buffer,corpus.byteOffset+i*6144,1536))];}));
const scopes=[[1000,10],[10000,1],[99900,100],[99900,10]],pattern='index_builds b CROSS JOIN field_index x CROSS JOIN';
let state='same-retained-store',variant='baseline',rewrites=0;
const report={source:process.env.EARS_TEST_SOURCE,qualification:false,scope:'Owned copied store; only skip redundant native-owner rerank eligibility; not acceptance or ANN retuning',candidate:'772cbe32df',observations:[],explanations:[]};
const save=()=>{writeFileSync(output+'.next',JSON.stringify(report,null,2)+'\n');renameSync(output+'.next',output);};
const db=new SqliteDatabase({path:copy,nativeVectorExtension:extension});
const primary=()=>({commit:db.sql.prepare("SELECT hex(value) value FROM meta WHERE key='commit'").get().value,entities:db.sql.prepare('SELECT count(*) n FROM entities').get().n,embeddings:db.sql.prepare('SELECT count(*) n FROM embedding_values').get().n});
const original={all:db.all,get:db.get};
try {
 report.primaryBefore=primary();report.stat4Compiled=Boolean(db.sql.prepare("SELECT sqlite_compileoption_used('ENABLE_STAT4') n").get().n);
 report.initialStat1=Boolean(db.sql.prepare("SELECT 1 FROM sqlite_schema WHERE name='sqlite_stat1'").get());
 for(const method of ['all','get'])db[method]=function(sql,parameters=[]){
  if(sql.startsWith('SELECT c.entity_id id,')&&sql.includes('seq IN (SELECT value FROM json_each(?))')){
   if(variant==='reuse'){
    assert(sql.includes('AND c.entity_id!=?'));
    const next=sql.replace(/AND c.type=\? AND c.index_name=\? AND c.generation=\? AND c.embedding_id IS NOT NULL[\s\S]*?GROUP BY c.entity_id/,
      'AND c.type=? AND c.index_name=? AND c.generation=? AND c.embedding_id IS NOT NULL GROUP BY c.entity_id');
    assert.notEqual(next,sql);sql=next;parameters=[...parameters.slice(0,5),parameters.at(-1)];rewrites++;
   }
   sql=`/* owner-reuse ${variant} */ `+sql;
  }
  return original[method].call(this,sql,parameters);
 };
 const e=createEarsEngine({database:db});
 const query=(size,percent,q)=>{let x=e.query('Row');if(size!==99900)x=x.where(size===1000?'prefix1000':'prefix10000',true);if(percent!==100)x=x.where(percent===10?'scope10':'scope1',true);return x.near(vectors.get(q),{k:10});};
 const scrub=x=>ArrayBuffer.isView(x)?{bytes:x.byteLength,sha256:sha(Buffer.from(x.buffer,x.byteOffset,x.byteLength))}:typeof x==='string'&&x.length>200?{stringLength:x.length,sha256:sha(x)}:Array.isArray(x)?x.map(scrub):x;
 {
  for(const [size,percent] of scopes){
   const expected=witness.cohorts.find(c=>c.phase==='updated'&&c.size===size&&c.scopePercent===percent);assert(expected);
   for(const round of [0,1,2,3,4,5])for(variant of round%2?['reuse','baseline']:['baseline','reuse'])for(const q of qs){
    const cpu=process.cpuUsage(),at=performance.now(),hits=query(size,percent,q).hits(),wallMs=performance.now()-at,used=process.cpuUsage(cpu),prior=expected.passes[3].samples[q];
    assert.deepEqual(hits.map(h=>Number(h.id.slice(4))),prior.ordinals);assert.deepEqual(hits.map(h=>h.score),prior.scores);
    report.observations.push({state,variant,size,percent,round,timed:round>0,q,wallMs,cpuUserMs:used.user/1000,cpuSystemMs:used.system/1000});await pause(0);
   }
   for(variant of ['baseline','reuse']){
    const explained=query(size,percent,0).explain();assert.deepEqual(explained.ids,expected.passes[3].samples[0].ordinals.map(i=>'Row-'+String(i).padStart(6,'0')));
    for(const s of explained.statements)s.parameters=s.parameters.map(scrub);
    report.explanations.push({state,variant,size,percent,...explained});
   }
   save();console.log(JSON.stringify({state,size,percent,observations:report.observations.length,rewrites}));
  }
 }
 assert(rewrites>0);assert.equal(report.observations.length,144);assert.equal(report.explanations.length,8);report.primaryAfter=primary();assert.deepEqual(report.primaryAfter,report.primaryBefore);report.completed=true;save();
}catch(error){report.failure={message:error.message,stack:error.stack};save();throw error;}
finally{db.all=original.all;db.get=original.get;db.close();}
