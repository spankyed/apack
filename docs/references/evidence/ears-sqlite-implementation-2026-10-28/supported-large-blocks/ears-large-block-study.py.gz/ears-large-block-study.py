from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');inputs=json.loads((o/'inputs.json').read_text())
for n,h in inputs.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
p=r/'packages/apack-ears/bench/sqlite/large-block-study.mjs';shutil.copyfile('/study.mjs',p)
meta=json.loads((o/'source.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['probeSha256']
subprocess.run(['node','--check',str(p)],check=True)
limits={name:Path('/sys/fs/cgroup',name).read_text().strip() for name in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
args=['node','--import','tsx',str(p),'/corpus','/truth/truth.json','99900','/results/large-block-study.json','native-fresh'];env={**os.environ,'EARS_TEST_SOURCE':meta['source'],'EARS_VEC1_EXTENSION':str(r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so'),'EARS_CHECKPOINT_PROBE':'auto'}
start=time.time()
with(o/'large-block-study.log').open('w') as f:result=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
(o/'run.json').write_text(json.dumps({'source':meta['source'],'limits':limits,'args':args,'exitCode':result.returncode,'seconds':time.time()-start,'inputs':inputs},indent=2)+'\n');print('Current admission diagnostic exit',result.returncode,flush=True)
assert result.returncode==0,(o/'large-block-study.log').read_text()[-6000:]
d=json.loads((o/'large-block-study.json').read_text());assert d['completed'] and len(d['variants'])==3
for v in d['variants']:assert v['canonicalRowsVerified']==99900 and v['modelSha256']==d['model']['sha256']
print([(v['minimum'],v['admission']['ms'],v['admission']['heartbeat'],v['frozenGatesPassed']) for v in d['variants']],flush=True)
