from pathlib import Path
import hashlib,json,subprocess
r=Path('/private/tmp/ears-sqlite-query-integration');s=Path('/private/tmp/ears-allocation-study.mjs').read_text()
s=s.replace("import { copyFileSync, mkdirSync } from 'node:fs';","import { copyFileSync, mkdirSync, openSync, readSync, closeSync } from 'node:fs';")
s=s.replace("const path = mkdtempSync(join(tmpdir(),'ears-real-vector-'));", "const path = mkdtempSync('/electron/.temp/ears-large-block-');\nconst snapshot='/electron/.temp/ears-query-attribution-retained';\nconst fileSha=file=>{const h=createHash('sha256'),fd=openSync(file,'r'),b=Buffer.allocUnsafe(1024*1024);try{for(;;){const n=readSync(fd,b,0,b.length,null);if(!n)break;h.update(b.subarray(0,n));}return h.digest('hex');}finally{closeSync(fd);}};\nconst retainedSha=fileSha(join(snapshot,'data.sqlite3'));assert.equal(retainedSha,'4e7b922650edb9bacefdda9fcb9b0c5a04f91e5919510c1b03d0b6f1971de935');")
a=s.index('  const training=new SqliteVectorTraining');b=s.index("  const base=join(path,'base')",a)
s=s[:a]+'''  const retained=new SqliteDatabase({path:snapshot,readOnly:true,nativeVectorExtension:process.env.EARS_VEC1_EXTENSION});
  assert.equal(retained.sql.readonly,true);
  let trained;
  try {
    const state=retained.get("SELECT id,model_sha256 FROM vector_indexes WHERE state='ready'");assert(state&&Number.isSafeInteger(state.id));
    const model=retained.get(`SELECT val FROM ann_${state.id}_model WHERE id=1`).val;
    assert.equal(sha(model),state.model_sha256);assert.equal(sha(model),'5f90eea4ed59a1d018753a4f80e29ce58a40aec9c823382cdc051abce7a823b6');
    trained={model:Buffer.from(model),modelSha256:sha(model)};
  } finally {retained.close();}
  rootReport.model={sha256:trained.modelSha256,origin:'read-only retained prior owner model; no retraining'};
  rootReport.retainedSnapshotSha256=retainedSha;
''' + s[b:]
s=s.replace("rootReport.protocol='ears-fixed-model-allocation/1'", "rootReport.protocol='ears-supported-large-blocks/1'")
s=s.replace('for(const minimum of [16384,4096])','for(const minimum of [16384,65536,262144])')
s=s.replace('    const pulse=startHeartbeat(1),begin=performance.now();','    report.wallStartMs=Date.now();\n    const pulse=startHeartbeat(1),begin=performance.now();')
s=s.replace('const start=performance.now();db.sql.exec', 'const wallStartMs=Date.now(),start=performance.now();db.sql.exec')
s=s.replace('report.projection.push({projectionMs:', 'report.projection.push({wallStartMs,wallEndMs:Date.now(),projectionMs:')
s=s.replace('report.admission={ms:', 'report.admission={wallEndMs:Date.now(),ms:')
s=s.replace('    save();console.log(JSON.stringify({stage:', '''    const profile=()=>JSON.parse(db.get("SELECT qprofile FROM vec1cat WHERE database='main' AND name=?",['ann_'+db.get("SELECT id FROM vector_indexes WHERE state='ready'").id]).qprofile);
    save();console.log(JSON.stringify({stage:''')
s=s.replace('const samples=[],pulse=startHeartbeat(1),callsBefore=nativeCalls;', 'const wallStartMs=Date.now(),profileBefore=profile(),samples=[],pulse=startHeartbeat(1),callsBefore=nativeCalls;')
s=s.replace('const begin=performance.now();\n            const hits=', 'const queryWallStartMs=Date.now(),begin=performance.now();\n            const hits=')
s=s.replace('samples.push({q,ms,recall:', 'samples.push({q,ms,wallStartMs:queryWallStartMs,wallEndMs:Date.now(),recall:')
s=s.replace('const result={pass,timed:', "const profileAfter=profile();\n        const result={wallStartMs,wallEndMs:Date.now(),profileDelta:Object.fromEntries(Object.keys(profileBefore).map(k=>[k,{cnt:profileAfter[k].cnt-profileBefore[k].cnt,cycle:profileAfter[k].cycle-profileBefore[k].cycle}])),pass,timed:")
s=s.replace("report=rootReport;report.completed=true;save();", "report=rootReport;report.unchangedRetainedSnapshotSha256=fileSha(join(snapshot,'data.sqlite3'));assert.equal(report.unchangedRetainedSnapshotSha256,retainedSha);report.completed=true;save();")
Path('/private/tmp/ears-large-block-study.mjs').write_text(s)
o=Path('/private/tmp/ears-large-block-study-results');o.mkdir(exist_ok=False)
files=subprocess.check_output(['git','ls-files','packages/apack-ears/src','native/vectors'],cwd=r,text=True).splitlines()
(o/'inputs.json').write_text(json.dumps({n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in files},indent=2)+'\n')
(o/'source.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'probeSha256':hashlib.sha256(s.encode()).hexdigest(),'qualification':False,'variants':[16384,65536,262144],'matrix':'3 variants x18 initial/updated cohorts x4passes x100queries','model':'5f90eea4ed59a1d018753a4f80e29ce58a40aec9c823382cdc051abce7a823b6','storage':'same private named volume; one base plus one candidate at a time','budgets':'unchanged mean recall>=.95, heartbeatp99<=16ms, p95diagnosticlatency100/200ms','notAcceptance':'direct physical admission, not complete app-owned scheduler; cumulative processRSS not isolatedvariantmemory'},indent=2)+'\n')
# Reuse the already qualified guarded runner structure, with a new identity and three variants.
s=Path('/private/tmp/ears-allocation-study.py').read_text().replace('allocation-study','large-block-study').replace('len(d[\'variants\'])==2','len(d[\'variants\'])==3')
Path('/private/tmp/ears-large-block-study.py').write_text(s)
for a,b in [('ears-run-allocation-study.py','ears-run-large-block-study.py'),('ears-wait-allocation-study.py','ears-wait-large-block-study.py')]:
 s=Path('/private/tmp',a).read_text().replace('allocation-study','large-block-study')
 if a.startswith('ears-run'):
  s=s.replace("assert not subprocess.check_output", "assert __import__('shutil').disk_usage('/private/tmp').free>=7*1024**3,'Require7GiB free before allocating controlled base/candidate'\nassert not subprocess.check_output",1)
 Path('/private/tmp',b).write_text(s)
print('Prepared fixed-model 16/64/256KiB controlled study; production unchanged')
