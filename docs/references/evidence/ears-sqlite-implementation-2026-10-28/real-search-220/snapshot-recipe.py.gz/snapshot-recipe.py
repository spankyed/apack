from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/private/tmp/ears-sqlite-query-integration');files=sorted((root/'docs/public-facing').glob('*.md'))+sorted((root/'packages/default-setup/src/content/commands/internal').glob('*.md'))+[root/'packages/default-setup/src/content/notes/welcome.md']
documents=[];sources=[]
for p in files:
 path=str(p.relative_to(root));text=p.read_text();sources.append({'path':path,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});parents=[];start=0;section='Introduction';fence=None;parts=[]
 for at,line in enumerate(text.splitlines(keepends=True)):
  marker=re.match(r'^\s{0,3}(`{3,}|~{3,})',line)
  if marker:
   if fence is None:fence=marker[1][0]
   elif marker[1][0]==fence:fence=None
  match=re.match(r'^(#{1,3})\s+(.+?)\s*#*\s*$',line) if fence is None else None
  if match:
   if parts:documents.append({'source':path,'section':section,'body':''.join(parts)})
   level=len(match[1]);parents=[(n,t) for n,t in parents if n<level];parents.append((level,match[2]));section=' / '.join(t for n,t in parents);parts=[]
  parts.append(line)
 if parts:documents.append({'source':path,'section':section,'body':''.join(parts)})
for d in documents:
 key=d['source']+'#'+d['section'];d['id']='Document-'+hashlib.sha256(key.encode()).hexdigest()[:16];d['name']=Path(d['source']).stem+' / '+d['section']
assert len({d['id'] for d in documents})==len(documents)
def key(file,section):
 matches=[d for d in documents if d['source']==file and (d['section'].split(' / ')[-1]==section or d['section']==section)]
 assert len(matches)==1,(file,section,[d['section'] for d in matches]);return matches[0]['id']
cases=[]
def case(name,query,file,section,options=None,highlight=None):
 c={'name':name,'query':query,'options':options or {'fuzzy':False},'relevant':[key(file,section)],'topK':5}
 if highlight:c['highlight']=highlight
 cases.append(c)
def guide(name,query,file,section,options=None):case(name,query,'docs/public-facing/'+file+'.md',section,options)
guide('find encrypted credential storage','encrypted keys','architecture','Secrets store')
guide('find physical backup import API','importBackup','architecture','Backups')
guide('find environment path resolver','resolveAppEnvironment','architecture','App environment and data directory')
guide('find backend startup composition','setupBackend','architecture','Backend boot')
guide('find frontend dependency sharing','import map','architecture','Frontend: an import map')
guide('find backend dependency sharing','module bridge','architecture','Backend: the module bridge')
guide('find generated metadata ownership','generate-entries','architecture','Generated files')
guide('find PageRank graph ordering','PageRank','services-and-data','Graph algorithms')
guide('find explicit trash access','withTrashed','services-and-data','Trash')
guide('find reactive view subscriptions','subscribes','services-and-data','Views')
guide('find typed entity identity','EntityId','services-and-data','Entity ids')
guide('find recursive hierarchy traversal','descendants','services-and-data','Hierarchies')
guide('find model test doubles','mockInference','testing','Models')
guide('find content import test harness','importContent','testing','Content')
guide('find frontend shell test harness','startShell','testing','Frontend')
guide('find artifact extension declarations','ArtifactDefinition','extensions','Artifacts')
guide('find static DSL discovery','getDslDeclarations','extensions','DSL editor assistance')
guide('find content applier module contract','ContentApplier','content','ContentApplier modules')
guide('find removed shipped content policy','edited shipping','content','Content you stop shipping')
guide('restrict graph phrase to document titles','"Graph algorithms"','services-and-data','Graph algorithms',{'fields':['name'],'fuzzy':False})
guide('correct a transposed test API identifier','mockInfernece','testing','Models',{'fuzzy':True})
commands='packages/default-setup/src/content/commands/internal/'
case('find shipped Codex resume command','cdx-resume',commands+'codex.md','Introduction',highlight={'field':'body','text':'resume'})
case('complete shipped Codex command prefix','cdx-res',commands+'codex.md','Introduction',{'prefix':True,'fuzzy':False})
case('find shipped PR-to-Markdown command','pr2md',commands+'chat.md','Introduction')
case('find shipped welcome kanban explanation','kanban','packages/default-setup/src/content/notes/welcome.md','⚡ What You Can Do')
fixture={'description':'Frozen real repository guides and shipped note/command content, sectioned outside code fences. Predeclared engineering-document usefulness judgments; not private user data, language/hybrid qualification or an app performance claim. Every query must place a relevant section in the first five hits. Snapshot updates are deliberate, not regenerated during tests.','sourceRevision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sources':sources,'documents':documents,'cases':cases}
p=root/'packages/apack-ears/tests/fixtures/real-search-relevance.json';p.write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'documents':len(documents),'cases':len(cases),'bytes':p.stat().st_size}))
