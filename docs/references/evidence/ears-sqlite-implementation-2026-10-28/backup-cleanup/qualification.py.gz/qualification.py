from pathlib import Path
import os,subprocess,shutil,json,time,hashlib
r=Path('/electron');o=Path('/results');env={**os.environ,'EARS_VEC1_EXTENSION':str(r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so')};rows=[]
subprocess.run(['tar','--no-same-owner','-xf','/overlay.tar','-C',str(r)],check=True)
backup=r/'packages/apack-cli/src/commands/db/backup.ts'
fixed=backup.read_bytes()
base=['node','node_modules/vitest/vitest.mjs','run','--root','packages/apack-cli']
def run(label,args,expected=0):
 start=time.time()
 with (o/(label+'.log')).open('w') as f:p=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 rows.append({'label':label,'args':args,'exitCode':p.returncode,'seconds':time.time()-start})
 (o/'qualification.json').write_text(json.dumps({'commands':rows},indent=2)+'\n')
 assert p.returncode==expected,(o/(label+'.log')).read_text()[-6000:]
 return p
try:
 shutil.copyfile('/baseline-backup.ts',backup)
 run('baseline-final',base+['tests/commands/sqlite-profile.spec.ts','-t','cleanup|write lock also fails','--maxWorkers','1','--minWorkers','1','--reporter=default','--reporter=json','--outputFile=/results/baseline-final.json'],1)
 data=json.loads((o/'baseline-final.json').read_text());assert data['numFailedTests']==3
finally:backup.write_bytes(fixed)
run('lint-final',['node','node_modules/oxlint/bin/oxlint','packages/apack-cli/src/commands/db/backup.ts','packages/apack-cli/tests/commands/sqlite-profile.spec.ts','-D','correctness'])
run('fixed-final',base+['tests/commands/db-rebuild.spec.ts','tests/commands/db-logical.spec.ts','tests/commands/sqlite-profile.spec.ts','--maxWorkers','1','--minWorkers','1','--reporter=default','--reporter=json','--outputFile=/results/fixed-final.json'])
run('verifier-syntax',['node','--check','.github/scripts/ears-sqlite-platform.mjs'])
run('verifier-controls',['node','/verifier.cjs'])
print('Baseline 3 actual cleanup failures reproduced; all platform CLI cases and verifier controls pass; production source restored.',flush=True)
