from pathlib import Path
import subprocess,json
out=Path('/private/tmp/ears-graph-frozen-cleanup-results');out.mkdir(exist_ok=True)
assert not subprocess.check_output(['docker','ps','-q'],text=True).strip(),'Other container active; cleanup not admitted'
script=r'''from pathlib import Path
import json,hashlib
root=Path('/electron');manifest=json.loads(Path('/inputs.json').read_text());report={'scope':'Remove only owned empty overlay mountpoints; no database files touched','files':{},'directories':{}}
def verify():
 for n,h in manifest.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
 return len(manifest)
report['originalHashesBefore']=verify()
files=['src/sqlite/field-query.ts','src/sqlite/scalar-groups.ts','src/sqlite/value-groups.ts','src/sqlite/graph-algorithms.ts','src/sqlite/communities.ts','src/sqlite/community-core.ts','tests/sqlite/graph-algorithms.spec.ts','tests/sqlite/community-core.spec.ts']
for n in files:
 n='packages/apack-ears/'+n;assert n not in manifest;p=root/n
 if p.exists():
  assert p.is_file() and not p.is_symlink() and p.stat().st_size==0,n
  p.unlink();report['files'][n]='removed owned empty mount point'
for n in ['node_modules/leiden-ts','packages/apack-ears/dist/sqlite/graph']:
 p=root/n
 if p.exists():
  assert p.is_dir() and not p.is_symlink() and not list(p.iterdir()),n
  p.rmdir();report['directories'][n]='removed owned empty mount point'
report['originalHashesAfter']=verify();report['completed']=True
Path('/results/report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
'''
args=['docker','run','--rm','--read-only','--cpus','.1','--memory','64m','--memory-swap','64m','--network','none','--cap-drop','ALL','-v','ears-electron-runtime-work:/electron','-v','/private/tmp/ears-sqlite-join-plan-results/inputs.json:/inputs.json:ro','-v',str(out)+':/results','apack-linux-test:74d4b8cfe839','python3','-c',script]
subprocess.run(args,check=True)
