import sqlite3,json,math,random
from pathlib import Path
r=random.Random(7391);checks=0
for trial in range(48):
 db=sqlite3.connect(':memory:');db.executescript('CREATE TABLE entities(id TEXT PRIMARY KEY,trashed INTEGER);CREATE TABLE relations(source TEXT,target TEXT,kind TEXT,seq INTEGER);CREATE INDEX relations_source ON relations(source,kind,seq);CREATE INDEX relations_target ON relations(target,kind,seq);')
 names=[str(n) for n in range(9)];trashed={n:r.randrange(4)==0 for n in names};db.executemany('INSERT INTO entities VALUES (?,?)',trashed.items())
 edges=[(a,b,k,len(names)*i+j) for i,a in enumerate(names) for j,b in enumerate(names) for k in ['refs','extra'] if a!=b and r.random()<.19];db.executemany('INSERT INTO relations VALUES (?,?,?,?)',edges)
 for scope in ['live','trashed','withTrashed']:
  alive=lambda n:scope!='live' or not trashed[n]
  admitted=lambda n:trashed[n] if scope=='trashed' else alive(n)
  candidates=[n for n in ['5','2','1','4','3','6'] if admitted(n)]
  for direction in ['out','in','both']:
   def neighbors(n,back=False):
    sides=['out','in'] if direction=='both' else [direction];found={}
    for kind in ['refs','refs','extra']:
     for side in sides:
      out=(side=='out')!=back
      for a,b,k,_ in sorted(edges,key=lambda e:e[3]):
       if k!=kind:continue
       far=b if out and a==n else a if not out and b==n else None
       if far is not None and alive(far):found[far]=None
    return list(found)
   ours=neighbors('0') if alive('0') else []
   for measure in ['jaccard','adamicAdar']:
    call=json.load(open(f'/private/tmp/ears-similar-corrected-{scope}-{direction}-{measure}.json'));args=call['args'];args[1]=json.dumps(candidates);expected=[]
    for n in candidates:
     theirs=neighbors(n);common=[z for z in ours if z in theirs]
     if not common:continue
     score=len(common)/len(set(ours)|set(theirs)) if measure=='jaccard' else sum(1/math.log(len(neighbors(z,True))) for z in common)
     expected.append((n,score))
    expected.sort(key=lambda t:-t[1]);actual=db.execute(call['sql'],args).fetchall()
    assert {n for n,s in actual}=={n for n,s in expected},(trial,scope,direction,measure,actual,expected)
    expected_scores=dict(expected)
    assert all(abs(score-expected_scores[n])<1e-12 for n,score in actual)
    for a,b in zip(actual,actual[1:]):
     assert a[1]>=b[1]
     if a[1]==b[1]:assert candidates.index(a[0])<candidates.index(b[0])
    checks+=1
 db.close()
report={'completed':True,'checks':checks,'seed':7391,'runtime':'Python SQLite '+sqlite3.sqlite_version,'scope':'Corrected duplicate/multiple-kind and trash-start/step distinction; diagnostic, not pinned Electron qualification'}
Path('/private/tmp/ears-check-similarity-corrected.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
