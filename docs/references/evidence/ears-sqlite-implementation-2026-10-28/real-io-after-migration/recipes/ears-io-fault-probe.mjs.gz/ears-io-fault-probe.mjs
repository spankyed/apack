// Actual SQLite syscalls fail through a private, one-shot Linux interposer; no JS method is replaced.
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync,writeFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
import {SqliteDatabase} from '/electron/packages/apack-ears/src/sqlite/database.ts';
import {createEarsEngine} from '/electron/packages/apack-ears/src/index.ts';
import {toElmdbSchema} from '/electron/packages/apack-ears/src/schema.ts';
const [operation,kind,phase,output]=process.argv.slice(2);assert(['write','bulkLoad','unit','schema','open'].includes(operation));assert(['sync','write','read'].includes(kind));assert(['before','after'].includes(phase));assert(output&&!existsSync(output));
const root=mkdtempSync(join(tmpdir(),'ears-real-io-')),path=join(root,'database'),arm=join(root,'armed'),log=join(root,'injection.jsonl');
const shape={types:{Row:{required:[]}},relations:{},roles:[]},schema=toElmdbSchema(shape),seen=[];
const report={protocol:'ears-real-io-fault/1',source:process.env.EARS_TEST_SOURCE,operation,kind,phase,cases:[],qualification:false};
let db,watch;
const save=()=>writeFileSync(output,JSON.stringify(report,null,2)+'\n');
try{
 db=new SqliteDatabase({path,schema});let e=createEarsEngine({database:db});e.create('Row',{id:'Row-before',title:'incumbent'});await db.durable();const sequence=db.sequence;
 report.sequenceBefore=sequence;report.synchronous=db.sql.pragma('synchronous',{simple:true});report.checkpoint=db.sql.pragma('wal_autocheckpoint',{simple:true});assert.equal(report.synchronous,2);assert.equal(report.checkpoint,1000);
 if(operation!=='open'){watch=e.watch(()=>e.query('Row').ids(),ids=>seen.push([...ids]));await e.admin.watchesSettled();assert.deepEqual(seen,[['Row-before']]);}
 else {db.close();db=undefined;}
 const target=join(path,kind==='read'?'data.sqlite3':'data.sqlite3-wal');assert(existsSync(target));
 if(operation==='open')report.mainBefore=createHash('sha256').update(readFileSync(target)).digest('hex');
 process.env.EARS_IO_TARGET=target;process.env.EARS_IO_ARM=arm;process.env.EARS_IO_LOG=log;process.env.EARS_IO_KIND=kind;process.env.EARS_IO_PHASE=phase;writeFileSync(arm,'one owned call\n',{flag:'wx'});
 let failure;
 try{
  if(operation==='open')db=new SqliteDatabase({path,readOnly:true});
  else if(operation==='write')e.create('Row',{id:'Row-candidate'});
  else if(operation==='bulkLoad')db.bulkLoad([{load:'entity',id:'Row-candidate',fields:{title:'candidate'}}]);
  else if(operation==='unit')e.transact(()=>{e.create('Row',{id:'Row-earlier'});e.create('Row',{id:'Row-candidate'});});
  else e.admin.setSchema({...shape,types:{...shape.types,Added:{required:[]}}});
 }catch(error){failure=error;}
 assert(failure,'The armed actual I/O call must fail');assert(!existsSync(arm),'Injection must not pass vacuously');
 const injections=readFileSync(log,'utf8').trim().split('\n').map(line=>JSON.parse(line));assert.equal(injections.length,1);assert.equal(injections[0].injectedErrno,5);assert.equal(injections[0].phase,phase);assert.equal(injections[0].actualCalled,phase==='after');if(phase==='after')assert(injections[0].actualResult>=0);
 report.injections=injections;report.failure={code:failure.code,message:failure.message,causeCode:failure.cause?.code,stack:failure.stack};
 delete process.env.EARS_IO_TARGET;delete process.env.EARS_IO_ARM;
 if(operation==='open'){
  assert(/^SQLITE_IOERR/.test(failure.code));report.mainAfter=createHash('sha256').update(readFileSync(target)).digest('hex');assert.equal(report.mainAfter,report.mainBefore);
 }else {
  assert.equal(db.sql.inTransaction,false);
  if(failure.code==='COMMIT_UNKNOWN'){
   assert(/^SQLITE_IOERR/.test(failure.cause?.code));
   for(const operation of [()=>e.query('Row').ids(),()=>e.create('Row',{id:'Row-no-replay'}),()=>db.sequence])assert.throws(operation,error=>error===failure);
   await assert.rejects(db.indexesReady(),error=>error===failure);report.fenced=true;report.outcome='unknown';
  }else {
   assert(/^SQLITE_IOERR/.test(failure.code));assert.deepEqual(e.query('Row').ids(),['Row-before']);assert.equal(db.sequence,sequence);assert.equal(e.isEntityType('Added'),false);report.outcome='refused';
  }
  await e.admin.watchesSettled();assert.deepEqual(seen,[['Row-before']]);report.watchSilence=true;watch.stop();watch=undefined;db.close();db=undefined;
 }
 db=new SqliteDatabase({path});e=createEarsEngine({database:db});const ids=e.query('Row').ids(),added=e.isEntityType('Added'),committed=operation==='schema'?added:ids.includes('Row-candidate');
 if(operation==='open'){assert.deepEqual(ids,['Row-before']);assert.equal(db.sequence,sequence);}
 else {
  assert.equal(db.sequence,sequence+Number(committed));assert.deepEqual(ids,operation==='schema'||!committed?['Row-before']:operation==='unit'?['Row-before','Row-earlier','Row-candidate']:['Row-before','Row-candidate']);
 }
 if(report.outcome==='refused')assert.equal(committed,false);assert(!ids.includes('Row-no-replay'));report.reopened={sequence:db.sequence,ids,added,observedCommitted:committed};
 const beforeRecovery=db.sequence;e.create('Row',{id:'Row-recovered'});assert.equal(db.sequence,beforeRecovery+1);report.sequenceAfterRecovery=db.sequence;
 db.close();db=undefined;db=new SqliteDatabase({path,readOnly:true});assert(createEarsEngine({database:db}).query('Row').ids().includes('Row-recovered'));report.recoveredReadOnly=true;report.completed=true;save();
}catch(error){report.probeFailure={message:error.message,stack:error.stack};save();throw error;}
finally{watch?.stop();db?.close();rmSync(root,{recursive:true,force:true});}
