from pathlib import Path
import subprocess,time,os,json
cid=Path('/private/tmp/ears-io-fault.cid');assert not cid.exists(),'A query policy run has already been created; inspect it instead'
Path('/private/tmp/ears-io-fault-admission.pid').write_text(str(os.getpid())+'\n')
quiet=None;last=0
print('Waiting for 30 seconds with no running containers before admitting the queued owned syscall fault diagnostic',flush=True)
while True:
 if Path('/private/tmp/ears-io-fault-admission.stop').exists():raise SystemExit('Admission stopped before container creation')
 p=subprocess.run(['docker','ps','-q'],capture_output=True,text=True)
 now=time.monotonic()
 if p.returncode or p.stdout.strip():quiet=None
 elif quiet is None:quiet=now
 if now-last>=20:
  print(json.dumps({'pid':os.getpid(),'otherContainers':p.stdout.splitlines(),'quietSeconds':0 if quiet is None else round(now-quiet),'dockerExitCode':p.returncode,'dockerError':p.stderr.strip()[:240]}),flush=True);last=now
 if quiet is not None and now-quiet>=30:
  p=subprocess.run(['python3','/private/tmp/ears-run-io-fault.py'])
  if cid.exists():raise SystemExit(p.returncode) # A started run is never restarted by this admission watcher.
  if p.returncode==0:raise SystemExit('Runner exited without creating its expected container')
  quiet=None # The final admission guard caught a new competing build; no check has started yet.
 time.sleep(2)
