#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
/* Test-only Linux interposer. Faults one armed call on one exact owned file. */
static int take(int fd, const char *kind){
  const char *target=getenv("EARS_IO_TARGET"), *arm=getenv("EARS_IO_ARM"), *selected=getenv("EARS_IO_KIND"), *phase=getenv("EARS_IO_PHASE");
  char name[64], held[4096]; ssize_t n;
  if(!target || !arm || !selected || strcmp(kind,selected) || !phase) return 0;
  snprintf(name,sizeof(name),"/proc/self/fd/%d",fd);
  n=readlink(name,held,sizeof(held)-1); if(n<0) return 0; held[n]=0;
  if(strcmp(held,target) || unlink(arm)) return 0;
  return !strcmp(phase,"before") ? 1 : !strcmp(phase,"after") ? 2 : 0;
}
static void note(const char *call,int plan,long actual,int saved){
  const char *path=getenv("EARS_IO_LOG");char bytes[512];int n,fd;
  if(!path) return;
  n=snprintf(bytes,sizeof(bytes),"{\"call\":\"%s\",\"phase\":\"%s\",\"actualCalled\":%s,\"actualResult\":%ld,\"actualErrno\":%d,\"injectedErrno\":%d}\n",call,plan==1?"before":"after",plan==1?"false":"true",actual,saved,EIO);
  fd=open(path,O_WRONLY|O_CREAT|O_APPEND|O_CLOEXEC,0600);
  if(fd>=0){syscall(SYS_write,fd,bytes,(size_t)n);close(fd);}
}
int fsync(int fd){
  int plan=take(fd,"sync"),rc,saved;
  if(plan==1){note("fsync",plan,-1,0);errno=EIO;return -1;}
  rc=(int)syscall(SYS_fsync,fd);saved=errno;
  if(plan==2 && rc==0){note("fsync",plan,rc,0);errno=EIO;return -1;}
  errno=saved;return rc;
}
int fdatasync(int fd){
  int plan=take(fd,"sync"),rc,saved;
  if(plan==1){note("fdatasync",plan,-1,0);errno=EIO;return -1;}
  rc=(int)syscall(SYS_fdatasync,fd);saved=errno;
  if(plan==2 && rc==0){note("fdatasync",plan,rc,0);errno=EIO;return -1;}
  errno=saved;return rc;
}
ssize_t pwrite64(int fd,const void *buf,size_t count,off64_t offset){
  int plan=take(fd,"write"),saved;ssize_t rc;
  if(plan==1){note("pwrite64",plan,-1,0);errno=EIO;return -1;}
  rc=(ssize_t)syscall(SYS_pwrite64,fd,buf,count,offset);saved=errno;
  if(plan==2 && rc>=0){note("pwrite64",plan,rc,0);errno=EIO;return -1;}
  errno=saved;return rc;
}
ssize_t pwrite(int fd,const void *buf,size_t count,off_t offset){
  return pwrite64(fd,buf,count,(off64_t)offset);
}
ssize_t pread64(int fd,void *buf,size_t count,off64_t offset){
  int plan=take(fd,"read"),saved;ssize_t rc;
  if(plan==1){note("pread64",plan,-1,0);errno=EIO;return -1;}
  rc=(ssize_t)syscall(SYS_pread64,fd,buf,count,offset);saved=errno;
  if(plan==2 && rc>=0){note("pread64",plan,rc,0);errno=EIO;return -1;}
  errno=saved;return rc;
}
ssize_t pread(int fd,void *buf,size_t count,off_t offset){
  return pread64(fd,buf,count,(off64_t)offset);
}
