from pathlib import Path
import subprocess,os,json,time
r=Path('/electron');o=Path('/results');report={'source':'1d7a3de090d74028ca36eba574686da8c794609a','steps':[],'scope':'Preload/module controls after preserved45sec API startup observation failure; no API test or deadline relaxation'}
try:
 for label,args in [('syntax',['node','--check','/new-hook.mjs']),('tsx-only',['node','--import','tsx','--input-type=module','-e',"console.log('IMPORT_READY')"]),('old-hook',['node','--import','tsx','--import','/old-hook.mjs','--input-type=module','-e',"console.log('IMPORT_READY')"]),('new-hook',['node','--import','tsx','--import','/new-hook.mjs','--input-type=module','-e',"console.log('IMPORT_READY')"])]:
  at=time.time();step={'label':label};report['steps'].append(step)
  with(o/(label+'.log')).open('w') as log:
   try:
    p=subprocess.run(args,cwd=r,env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=512'},stdout=log,stderr=subprocess.STDOUT,timeout=30);step['exitCode']=p.returncode
   except subprocess.TimeoutExpired:step['timeoutSeconds']=30
  step['seconds']=time.time()-at;print(label,step,flush=True)
 report['completed']=True
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
