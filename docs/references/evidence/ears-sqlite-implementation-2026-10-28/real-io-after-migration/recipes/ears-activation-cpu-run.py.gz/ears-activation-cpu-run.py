from pathlib import Path
import subprocess,os,json,time,tempfile,socket,signal,shutil,hashlib
r=Path('/electron');o=Path('/results');meta=json.loads((o/'source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in json.loads((o/'inputs.json').read_text()).items():assert (r/n).exists() and sha(r/n)==h,n
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
for n,h in json.loads((o/'expected-built-inputs.json').read_text()).items():assert (r/n).exists() and sha(r/n)==h,n
(o/'built-inputs.json').write_text(json.dumps({n:sha(r/n) for n in json.loads((o/'expected-built-inputs.json').read_text())},indent=2)+'\n')
client=r/'tests/scripts/_support/activation-cpu-client.mjs';assert not client.exists();shutil.copyfile('/client.mjs',client);assert sha(client)==meta['clientSha256'];assert sha(Path('/hook.mjs'))==meta['hookSha256']
report={'source':meta['source'],'limits':limits,'cases':[],'qualification':False,'scope':'Backend-only sampled-stack attribution with SQL spans; no renderer/five-second/causal-speed qualification'};started=time.time()
try:
 with tempfile.TemporaryDirectory(prefix='ears-activation-') as scratch:
  for label in ['sqlite','elmdb']:
   profile=Path(scratch)/label;profile.mkdir();config=profile/'apack/installed-packs.json';config.parent.mkdir();config.write_text(json.dumps({'packs':[{'id':'default-setup','enabled':False}]}))
   with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
   hook=o/(label+'-hook.json');env={**os.environ,'APACK_ENV':'test','APACK_USER_DATA_DIR':str(profile),'APACK_STORAGE_FORMAT':label+'/1','APACK_API_TOKEN':'synthetic-activation-profile-token','API_PORT':str(port),'SHIPPED_PACKS_DIR':str(r/'packages'),'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_TEST_SOURCE':meta['source'],'EARS_ACTIVATION_REPORT':str(hook),'APACK_PACKAGES_PREBUILT':'1'}
   args=['node','--import','tsx','--import','/hook.mjs','packages/api/dist/server.js']
   with(o/(label+'-api.log')).open('w') as log:
    child=subprocess.Popen(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
     at=time.monotonic()
     while True:
      if child.poll() is not None:raise RuntimeError((o/(label+'-api.log')).read_text()[-8000:])
      endpoint=profile/'apack/api-port'
      if endpoint.exists() and json.loads(endpoint.read_text()).get('port')==port:break
      assert time.monotonic()-at<45,'API startup observation exceeded45sec';time.sleep(.1)
     with(o/(label+'-client.log')).open('w') as f:result=subprocess.run(['node',str(client),str(o/(label+'.json'))],cwd=r,env={**env,'EARS_API_PID':str(child.pid)},stdout=f,stderr=subprocess.STDOUT)
     assert result.returncode==0,(o/(label+'-client.log')).read_text()[-8000:]
     d=json.loads((o/(label+'.json')).read_text());assert d['completed'];commits=sum(s['count'] for s in d['profile']['stats'] if ':commitWrite' in s['key']);assert commits>0 if label=='sqlite' else commits==0
     report['cases'].append({'label':label,'backendReadyMs':d['backendReadyMs'],'observedSqliteCommits':commits});print(label,'backendReadyMs',round(d['backendReadyMs'],2),'SQLitecommits',commits,flush=True)
    finally:
     if child.poll() is None:
      child.send_signal(signal.SIGTERM)
      try:child.wait(timeout=15)
      except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();raise
 report['completed']=True
except BaseException as e:report['failure']={'message':str(e),'type':type(e).__name__};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n');client.unlink(missing_ok=True)
