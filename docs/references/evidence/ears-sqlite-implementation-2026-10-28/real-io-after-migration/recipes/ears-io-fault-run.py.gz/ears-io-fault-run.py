from pathlib import Path
import json,subprocess,os,hashlib,time
r=Path('/electron');o=Path('/results');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((o/'source.json').read_text())
for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
assert sha(Path('/fault.c'))==meta['shimSha256'];assert sha(Path('/probe.mjs'))==meta['probeSha256']
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'50000 100000','memory.max':'805306368','memory.swap.max':'0'}
def stream_sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
checks={
 '.temp/ears-migration-checkpoint-20261031/native-db/data.mdb':'0fe282f82d18121c62f2828867099dedac26be67d30327b65f30b851ab5a1d00',
 '.temp/elmdb-2441-target/release/elmdb':'b3992070d8c9a3c9ad28e37576f8a101fe2a570391d0e157289fffa85fbdbf2c',
 '.temp/elmdb-2441-source/crates/elmdb-node/elmdb.linux-arm64-gnu.node':'5d813c95e373c79f36c47889c75b0491b8987c7cc6f9669f4428e4dd69a27687',
}
actual={name:stream_sha(r/name) for name in checks};assert actual==checks,'Preserved snapshot/native artifact mismatch'
(o/'migration-verification.json').write_text(json.dumps({'completed':True,'files':actual,'mode':'read-only volume; verify before open'},indent=2)+'\n')
report={'source':meta['source'],'limits':limits,'steps':[],'qualification':False};started=time.time()
try:
 args=['cc','-shared','-fPIC','-O2','-Wall','-Wextra','-Werror','/fault.c','-o','/tmp/ears-io-fault.so']
 with(o/'compile.log').open('w') as log:built=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 report['build']={'args':args,'exitCode':built.returncode};assert built.returncode==0,(o/'compile.log').read_text();report['shimBinarySha256']=sha(Path('/tmp/ears-io-fault.so'))
 # A disabled injector must fail the observer, rather than manufacture an I/O witness.
 cases=[('disabled-control','write','sync','before',False)]+[(operation+'-'+kind+'-'+phase,operation,kind,phase,True) for operation in ['write','bulkLoad','unit','schema'] for kind in ['sync','write'] for phase in ['before','after']]+[('open-read-'+phase,'open','read',phase,True) for phase in ['before','after']]
 for label,operation,kind,phase,enabled in cases:
  env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=512','EARS_TEST_SOURCE':meta['source']}
  if enabled:env['LD_PRELOAD']='/tmp/ears-io-fault.so'
  else:env.pop('LD_PRELOAD',None)
  at=time.time()
  with(o/(label+'.log')).open('w') as log:result=subprocess.run(['node','--import','tsx','/probe.mjs',operation,kind,phase,str(o/(label+'.json'))],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  step={'label':label,'exitCode':result.returncode,'seconds':time.time()-at};report['steps'].append(step);print(label,result.returncode,flush=True)
  d=json.loads((o/(label+'.json')).read_text())
  if not enabled:
   assert result.returncode!=0 and not d.get('injections') and 'must fail' in d['probeFailure']['message'];step['guardRefusedMissingInjector']=True;continue
  assert result.returncode==0,(o/(label+'.log')).read_text()[-6000:];assert d['completed'] and len(d['injections'])==1 and d['recoveredReadOnly'];step['outcome']=d.get('outcome','open-refused');step['observedCommitted']=d['reopened']['observedCommitted']
 report['completed']=True
except BaseException as e:report['failure']=str(e);raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
