from pathlib import Path
import subprocess,json,os,hashlib
r=Path('/electron');o=Path('/results');report={'runtimeSource':'a9c9340df74f90b85434e8ddafa9742bd6867cbf','benchmarkSource':'006bcb1901 with source imports; numeric-order65caaa962d','qualification':False,'scope':'Built frozen runtime, current benchmark only; short pilot, not sustained application acceptance','samples':[]}
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
 for tasks,seconds in [(20000,5)]:
  for ack in ['durable','default']:
   for views in ['views']:
    for backend in ['sqlite']:
     name=f'{tasks}-{ack}-{views}-{backend}'
     env={**os.environ,'EARS_WATCH_TASKS':str(tasks),'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096'}
     with(o/(name+'.log')).open('w') as log:p=subprocess.run(['node','--import','tsx','packages/apack-ears/bench/watch-stress.ts',str(seconds),views,backend,ack],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
     assert p.returncode==0,(name,(o/(name+'.log')).read_text()[-4000:])
     lines=(o/(name+'.log')).read_text().splitlines();d=json.loads(next(line for line in reversed(lines) if line.startswith('{')))
     assert d['converged'] and d['commitsPerSecond']>0
     report['samples'].append({'tasks':tasks,'seconds':seconds,'viewMode':views,**d});(o/'probe.json').write_text(json.dumps(report,indent=2)+'\n');print(name,flush=True)
 report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
