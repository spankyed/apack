from pathlib import Path
import subprocess,hashlib,json,difflib
r=Path('/private/tmp/ears-sqlite-query-integration');o=Path('/private/tmp/ears-direct-in-prototype-source');o.mkdir(exist_ok=False)
f=o/'vec1.c';f.write_bytes((r/'native/vectors/upstream.c').read_bytes());subprocess.run(['git','apply','--no-index','--unsafe-paths',str(r/'native/vectors/vec1-membership.patch')],cwd=o,check=True)
s=f.read_text();assert hashlib.sha256(s.encode()).hexdigest()=='5d49d5ea17fbeaa1f22141305a81a5aeac8feb1af652a0d8229ea906bd5c973b';(o/'baseline.c').write_text(s);original=s
needle='''    rc = vec1FilterToIntOp(pFilter,
        (szInt==4 ? VEC1_META_4BYTEMIN : 0),'''
replacement='''    /* Integer RHS entries are already sorted and owned by this query. Search
    ** them directly instead of narrowing/copying the entire list per block.
    ** Mixed operands retain the upstream conversion path below. */
    if( pFilter->bSortedIntegerIn ){
      const u8 *a = &pMeta->a[VEC1_META_SZHDR];
      int ii;
      for(ii=0; ii<nEntry; ii++){
        i64 lo = 0, hi = pFilter->iVal;
        i64 v = szInt==1 ? (i64)a[ii] : (i64)(int)vec1GetU32(&a[ii*sizeof_u32]);
        i64 nullValue = szInt==1 ? VEC1_META_1BYTENULL : VEC1_META_4BYTENULL;
        if( pBitmask->a[ii/8] & (1 << (ii%8)) ) continue;
        while( lo<hi ){
          i64 mid = lo + (hi-lo)/2;
          if( pFilter[mid+1].iVal<v ) lo = mid+1; else hi = mid;
        }
        if( v==nullValue || lo==pFilter->iVal || pFilter[lo+1].iVal!=v ){
          pBitmask->a[ii/8] |= (1 << (ii%8));
        }
      }
      return SQLITE_OK;
    }

    rc = vec1FilterToIntOp(pFilter,
        (szInt==4 ? VEC1_META_4BYTEMIN : 0),'''
assert s.count(needle)==1;s=s.replace(needle,replacement);f.write_text(s)
(o/'direct-in.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='baseline.c',tofile='vec1.c')))
t=(r/'native/vectors/membership-test.mjs').read_text();needle='Array.from({ length: 128 }, (_, i) => BigInt(i))];';replacement='''Array.from({ length: 128 }, (_, i) => BigInt(i)),
      [255n,2147483647n,0n,1n,2n,3n,4n,5n,6n,7n],
      [-9223372036854775808n,9223372036854775807n,-2147483649n,2147483648n,-2n,-1n,0n,1n,2n,3n],
      [-2n,-1n,0n,1n,2n,3n,4n,5.0,6.5,2147483647n],
      [128n,129n,130n,131n,132n,133n,134n,255n,256n]];''';assert t.count(needle)==1;t=t.replace(needle,replacement);(o/'membership-test.mjs').write_text(t)
(o/'source.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'baselineSha256':hashlib.sha256(original.encode()).hexdigest(),'prototypeSha256':hashlib.sha256(s.encode()).hexdigest(),'membershipSha256':hashlib.sha256(t.encode()).hexdigest(),'productionChanged':False,'allocationAdded':False,'formatChanged':False,'tests':'735ordinarySQLitecomparisons eachbaseline/prototype,existingnone/flat/IVFfixtures+integerNULLsentinels/wideRHS/mixed/compactemptyrange'},indent=2)+'\n');print('Prepared allocation-free private compact-IN prototype; no production change')
