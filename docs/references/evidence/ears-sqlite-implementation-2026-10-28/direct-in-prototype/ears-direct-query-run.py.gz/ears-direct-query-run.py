from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');meta=json.loads((o/'source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
p=r/'packages/apack-ears/bench/sqlite/direct-in-query.mjs';assert not p.exists();shutil.copyfile('/probe.mjs',p);assert sha(p)==meta['probeSha256'];subprocess.run(['node','--check',str(p)],check=True)
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
packaged=r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so';before=sha(packaged)
report={'source':meta['source'],'qualification':False,'partition':'updated-only diagnostic; not full initial/update acceptance','limits':limits,'variants':[]};started=time.time()
try:
 for variant in meta['variants']:
  extension=Path(variant['extension']);assert sha(extension)==variant['extensionSha256'];label=variant['label']
  args=['node','--import','tsx',str(p),'/corpus','/truth/truth.json','/electron/.temp/ears-query-attribution-retained',str(o/(label+'.json'))]
  env={**os.environ,'EARS_TEST_SOURCE':meta['source'],'EARS_VEC1_EXTENSION':str(extension),'EARS_POLICY_MODEL_SHA256':meta['expectedModelSha256'],'EARS_POLICY_DATABASE_SHA256':meta['expectedDatabaseSha256']};at=time.time()
  with(o/(label+'.log')).open('w') as f:result=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
  report['variants'].append({**variant,'args':args,'startedWallMs':at*1000,'endedWallMs':time.time()*1000,'exitCode':result.returncode})
  assert result.returncode==0,(o/(label+'.log')).read_text()[-6000:]
  d=json.loads((o/(label+'.json')).read_text());assert d['completed'] and not d.get('failure') and len(d['cohorts'])==9 and all(len(c['samples'])==100 for c in d['cohorts']);assert d['databaseSha256']==d['unchangedDatabaseSha256'];print(label,'900 actualEARSqueries complete; snapshot unchanged',flush=True)
 base=json.loads((o/'baseline.json').read_text());direct=json.loads((o/'direct.json').read_text());assert len(base['cohorts'])==len(direct['cohorts']);pairs=0
 for bc,dc in zip(base['cohorts'],direct['cohorts']):
  assert (bc['size'],bc['scopePercent'],bc['eligible'])==(dc['size'],dc['scopePercent'],dc['eligible']) and bc['nativeCandidateCalls']==dc['nativeCandidateCalls']
  assert len(bc['samples'])==len(dc['samples'])
  for b,c in zip(bc['samples'],dc['samples']):assert (b['ordinals'],b['scores'])==(c['ordinals'],c['scores']);pairs+=1
 assert pairs==900;report['identicalOrderedAnswerPairs']=pairs;assert sha(packaged)==before;report['packagedArtifactUnchanged']=True;report['completed']=True
except BaseException as e:report['failure']={'message':str(e),'type':type(e).__name__};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
