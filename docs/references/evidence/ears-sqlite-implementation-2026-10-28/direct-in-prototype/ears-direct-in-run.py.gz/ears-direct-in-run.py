from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');src=Path('/prototype');meta=json.loads((src/'source.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(src/'baseline.c')==meta['baselineSha256'] and sha(src/'vec1.c')==meta['prototypeSha256'] and sha(src/'membership-test.mjs')==meta['membershipSha256']
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
published=r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so';before=sha(published)
work=r/'.temp/ears-direct-in-prototype';work.mkdir(exist_ok=False)
test=r/'native/vectors/direct-in-test.mjs';assert not test.exists();shutil.copyfile(src/'membership-test.mjs',test)
subprocess.run(['node','--check',str(test)],check=True)
manifest=Path(subprocess.check_output(['node','-p',"require.resolve('better-sqlite3/package.json')"],cwd=r,text=True).strip());header=manifest.parent/'deps/sqlite3';assert (header/'sqlite3ext.h').exists()
report={'source':meta['source'],'qualification':False,'limits':limits,'input':meta,'packagedExtensionSha256Before':before,'variants':[]};start=time.time()
try:
 for label,c in [('baseline','baseline.c'),('direct','vec1.c')]:
  folder=work/label;folder.mkdir();shutil.copyfile(src/c,folder/'vec1.c');extension=folder/'vec1.so'
  args=['cc','-O3','-DNDEBUG','-Werror=implicit-function-declaration','-shared','-fPIC','-I'+str(header),str(folder/'vec1.c'),'-lm','-o',str(extension)]
  with(o/(label+'-build.log')).open('w') as f:subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT,check=True)
  at=time.time()
  with(o/(label+'-membership.log')).open('w') as f:result=subprocess.run(['node',str(test),str(extension),str(o/(label+'-membership.json'))],cwd=r,env={**os.environ,'EARS_TEST_SOURCE':meta['source']},stdout=f,stderr=subprocess.STDOUT)
  v={'label':label,'compilerArgs':args,'extension':str(extension),'extensionSha256':sha(extension),'sourceSha256':sha(folder/'vec1.c'),'testExit':result.returncode,'seconds':time.time()-at};report['variants'].append(v)
  assert result.returncode==0,(o/(label+'-membership.log')).read_text()[-6000:]
  d=json.loads((o/(label+'-membership.json')).read_text());assert d['completed'] and len(d['groups'])==15 and sum(g['checks'] for g in d['groups'])==735
  v['groups']=15;v['ordinarySQLiteComparisons']=735;print(label,'735 independent ordinarySQLite comparisons passed',flush=True)
 report['packagedExtensionSha256After']=sha(published);assert report['packagedExtensionSha256After']==before;report['completed']=True
except BaseException as e:
 report['failure']={'message':str(e),'type':type(e).__name__};raise
finally:
 report['seconds']=time.time()-start;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
