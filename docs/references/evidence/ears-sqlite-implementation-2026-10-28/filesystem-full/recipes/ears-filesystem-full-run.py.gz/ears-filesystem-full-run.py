from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');meta=json.loads((o/'source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'50000 100000','memory.max':'805306368','memory.swap.max':'0'}
p=r/'packages/apack-ears/bench/sqlite/filesystem-full-probe.mjs';assert not p.exists();shutil.copyfile('/probe.mjs',p);assert sha(p)==meta['probeSha256']
report={'source':meta['source'],'limits':limits,'steps':[]};started=time.time()
try:
 subprocess.run(['node','--check',str(p)],cwd=r,check=True)
 args=['node','--import','tsx',str(p),'/fault','/results/fault.json'];env={**os.environ,'EARS_TEST_SOURCE':meta['source'],'NODE_OPTIONS':'--max-old-space-size=384'}
 with (o/'fault.log').open('w') as f:result=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['exitCode']=result.returncode;assert result.returncode==0,(o/'fault.log').read_text()[-6000:]
 d=json.loads((o/'fault.json').read_text());assert d['completed'] and len(d['cases'])==4 and all(c['completed'] for c in d['cases']);report['completed']=True
except BaseException as e:report['failure']={'message':str(e),'type':type(e).__name__};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
