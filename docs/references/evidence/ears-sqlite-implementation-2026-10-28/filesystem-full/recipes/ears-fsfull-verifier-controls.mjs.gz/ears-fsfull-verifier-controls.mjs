import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { verifyFilesystemFull } from '/verifier.mjs';
const [input,output]=process.argv.slice(2),bytes=readFileSync(input),report=JSON.parse(bytes),rejected=[];
verifyFilesystemFull(report,report.source);
const control=(name,mutate)=>{const changed=structuredClone(report);const value=mutate(changed);assert.throws(()=>verifyFilesystemFull(value===undefined?changed:value,report.source),undefined,name);rejected.push(name);};
control('null-report',()=>null);control('wrong-source',r=>{r.source='different';});control('not-completed',r=>{r.completed=false;});
control('wrong-protocol',r=>{r.protocol='wrong';});control('wrong-filesystem',r=>{r.filesystem.type=0;});control('unbounded-filesystem',r=>{r.filesystem.bytes*=2;});
control('empty-cases',r=>{r.cases=[];});control('duplicate-case',r=>{r.cases[1]=structuredClone(r.cases[0]);});control('missing-enospc',r=>{delete r.cases[0].fillerError;});
for(let i=0;i<4;i++){
 control('missing-case-'+i,r=>{r.cases.splice(i,1);});control('incomplete-case-'+i,r=>{r.cases[i].completed=false;});
 control('not-a-commit-'+i,r=>{r.cases[i].enteredCommit=false;});control('synthetic-page-quota-'+i,r=>{r.cases[i].maxPageCount=8;});
 control('syncs-disabled-'+i,r=>{r.cases[i].synchronous=0;});control('not-full-'+i,r=>{r.cases[i].error.code='SQLITE_BUSY';});
}
control('space-remains',r=>{r.cases[0].availableBytesAtFailure=4096;});control('checkpoint-changed',r=>{r.cases[0].walAutocheckpoint=0;});
control('commit-on-refusal',r=>{r.cases[0].sequenceAfterRefusal++;});control('no-recovery-commit',r=>{r.cases[0].sequenceAfterRecovery--;});
control('missing-sequence',r=>{delete r.cases[0].sequenceBefore;});control('visible-refusal',r=>{r.cases[0].afterRefusalIds.push('Row-refused');});
control('not-reopened',r=>{r.cases[0].reopenedReadOnly=false;});control('missing-invisibility',r=>{r.cases[0].refusedWriteInvisible=false;});
control('extra-watch',r=>{r.cases[0].watchNotifications.push(['Row-refused']);});
writeFileSync(output,JSON.stringify({source:report.source,inputSha256:createHash('sha256').update(bytes).digest('hex'),completed:true,acceptedActualCases:4,rejectedControls:rejected},null,2)+'\n');
console.log('Accepted four actual cases; rejected',rejected.length,'missing/invalid witness controls');
