from pathlib import Path
import json,hashlib,os,subprocess
r=Path('/electron');o=Path('/results')
for n,h in json.loads((o/'inputs.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --import=tsx --max-old-space-size=4096'}
with(o/'probe.log').open('w')as log:p=subprocess.run(['node','/probe.mjs'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
print((o/'probe.log').read_text()[-6000:],flush=True)
raise SystemExit(p.returncode)
