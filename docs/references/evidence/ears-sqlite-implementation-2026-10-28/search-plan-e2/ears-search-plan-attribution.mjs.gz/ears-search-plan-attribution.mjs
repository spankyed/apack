import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, writeFileSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createEarsEngine } from '/electron/packages/apack-ears/src/index.ts';
import { SqliteDatabase } from '/electron/packages/apack-ears/src/sqlite/database.ts';
import { toElmdbSchema } from '/electron/packages/apack-ears/src/schema.ts';
import { searchTable } from '/electron/packages/apack-ears/src/sqlite/index-builds.ts';
const report={source:'e2f569fa25 EARS source overlays',qualification:false,
 protocol:'Fresh fixtures; seed/admission outside timing; syncs:false; five SQL variants, 13 alternating-order rounds; first retained separately, 12 warm; warm OS caches; no app budget waiver',profiles:[],completed:false};
const save=()=>writeFileSync('/results/report.json',JSON.stringify(report,null,2)+'\n');
assert.equal(readFileSync('/sys/fs/cgroup/cpu.max','utf8').trim(),'200000 100000');
assert.equal(readFileSync('/sys/fs/cgroup/memory.max','utf8').trim(),String(6*1024**3));
try{
 for(const n of [1000,10000,100000]){
  const path=mkdtempSync('/electron/.temp/ears-search-attribution-');
  let db;
  try{
   const schema={types:{Row:{required:[]}},relations:{},roles:[]};
   db=new SqliteDatabase({path,syncs:false,schema:toElmdbSchema(schema)});
   const e=createEarsEngine({database:db}),profile={n,variants:{},sql:{},plans:{}};report.profiles.push(profile);
   let start=performance.now();
   for(let offset=0;offset<n;offset+=256)e.transact(()=>{for(let i=offset;i<Math.min(n,offset+256);i++)e.create('Row',{
    id:`Row-${i}`,name:'lex'+i.toString(36).padStart(7,'0'),body:'sharedword'});});
   profile.seedMs=performance.now()-start;
   start=performance.now();e.admin.setSchema({...schema,types:{Row:{required:[],search:{fields:{name:3,body:1}}}}});
   await db.indexesReady();profile.admissionToReadyMs=performance.now()-start;
   const explained=e.query('Row').search('sharedword',{fuzzy:false}).limit(10).explain();
   assert.equal(explained.backend,'sqlite');
   const statement=explained.statements.find(s=>s.sql.includes('c0 AS MATERIALIZED')&&s.sql.includes('accepted AS'));
   assert(statement);const base=statement.sql,args=statement.parameters;
   assert(base.includes('FROM c0 GROUP BY id'));
   const grouped=base.replace('FROM c0 GROUP BY id','FROM c0 GROUP BY seq');
   const slim=base.replace('f.rowid docid,','').replace('f.entity_id id,f.field,f.element,f.owner','f.entity_id id,f.owner');
   assert.notEqual(slim,base);
   const job=db.get("SELECT * FROM index_builds WHERE type='Row' AND kind='text' AND state='ready'");
   const table=searchTable({...job,definition:JSON.parse(job.definition)});
   const native=`SELECT f.entity_id id,-f.rank score,f.owner,e.seq FROM ${table} f JOIN entities e ON e.id=f.entity_id
     WHERE ${table} MATCH ? AND f.rank MATCH 'bm25(0,0,0,1,1,0)' AND CAST(f.field AS INTEGER)=1 AND e.trashed=0
     ORDER BY f.rank LIMIT 10`;
   const variants=[['base',base,args],['integerGroup',grouped,args],['slim',slim,args],
    ['slimInteger',slim.replace('FROM c0 GROUP BY id','FROM c0 GROUP BY seq'),args],
    ['nativeRankOnly',native,['(body : "sharedword" OR aliases : "sharedword")']]];
   const expected=db.all(base,args).map(row=>[row.id,row.score]);
   assert.deepEqual(expected.map(row=>row[0]),Array.from({length:10},(_,i)=>`Row-${i}`));
   for(const [name,sql,parameters] of variants){profile.sql[name]={sql,parameters};profile.plans[name]=db.all('EXPLAIN QUERY PLAN '+sql,parameters);profile.variants[name]={firstInvocationMs:null,warmMs:[]};}
   for(let round=0;round<13;round++){
    const order=round%2?[...variants].reverse():variants;
    for(const [name,sql,parameters] of order){await new Promise(resolve=>setImmediate(resolve));
     start=performance.now();const rows=db.all(sql,parameters);const ms=performance.now()-start;
     assert.deepEqual(rows.map(row=>[row.id,row.score]),expected,`${n}/${name}/${round}`);
     if(!round)profile.variants[name].firstInvocationMs=ms;else profile.variants[name].warmMs.push(ms);
    }
   }
   for(const state of Object.values(profile.variants)){const sorted=[...state.warmMs].sort((a,b)=>a-b);state.summary={p50:sorted[6],p99:sorted[11],min:sorted[0]};}
   profile.memory=process.memoryUsage();profile.completed=true;save();console.log(JSON.stringify({n,variants:Object.fromEntries(Object.entries(profile.variants).map(([name,s])=>[name,s.summary]))}));
  }finally{db?.close();rmSync(path,{recursive:true,force:true});}
 }
 report.completed=true;
}catch(error){report.failure={message:error.message,stack:error.stack};throw error;}finally{save();}
