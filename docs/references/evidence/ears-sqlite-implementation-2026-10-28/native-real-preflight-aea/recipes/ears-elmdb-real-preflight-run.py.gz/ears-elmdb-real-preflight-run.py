from pathlib import Path
import json,subprocess,hashlib,time,os,shutil
r=Path('/electron');o=Path('/results');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();meta=json.loads((o/'source.json').read_text())
for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
p=r/'packages/apack-ears/bench/sqlite/elmdb-real-preflight.mjs';assert not p.exists();shutil.copyfile('/probe.mjs',p);assert sha(p)==meta['probeSha256']
report={'source':meta['source'],'limits':limits,'qualification':False};at=time.time()
try:
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_TEST_SOURCE':meta['source']}
 with(o/'probe.log').open('w') as log:result=subprocess.run(['node','--import','tsx',str(p),'/corpus','/truth/truth.json',str(o/'probe.json')],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 report['exitCode']=result.returncode;assert result.returncode==0,(o/'probe.log').read_text()[-6000:]
 d=json.loads((o/'probe.json').read_text());assert d['completed'] and len(d['cohorts'])==6 and all(len(c['passes'])==4 for c in d['cohorts']);assert all(c['embeddings']==1000 for c in d['canonical']);report['completed']=True
except BaseException as e:report['failure']=str(e);raise
finally:report['seconds']=time.time()-at;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n');p.unlink(missing_ok=True)
