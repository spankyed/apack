// Actual EARS path over the sealed real-model projection. No source IDs or vector payloads in reports.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { endianness, tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as pause } from 'node:timers/promises';
import { getLoadablePath } from 'sqlite-vec';
import { PerformanceObserver } from 'node:perf_hooks';
import { createEarsEngine } from '../../src/index.ts';
import { SqliteDatabase } from '../../src/sqlite/database.ts';
import { SqliteVectorIndex } from '../../src/sqlite/vector-index.ts';
import { SqliteVectorTraining } from '../../src/sqlite/vector-training.ts';
import { copyFileSync, mkdirSync, openSync, readSync, closeSync } from 'node:fs';
import { SqliteVectorModels } from '../../src/sqlite/vector-models.ts';
import { toElmdbSchema } from '../../src/schema.ts';
import { loadedNativeBindings, startHeartbeat } from './load-metrics.ts';

const [corpusPath, truthFile, sizeArg, output, mode] = process.argv.slice(2), size = Number(sizeArg);
assert([1000,99900].includes(size) && output && !existsSync(output));
assert(mode === undefined || ['diagnose','native-fresh','native-diagnose'].includes(mode));
const fresh=mode==='native-fresh'||mode==='native-diagnose',diagnostic=mode==='diagnose'||mode==='native-diagnose';
if(fresh)assert(process.env.EARS_VEC1_EXTENSION,'A trusted native extension is required');
assert.equal(endianness(),'LE');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const manifestBytes = readFileSync(join(corpusPath,'manifest.json')), manifest = JSON.parse(manifestBytes);
const truthBytes = readFileSync(truthFile), truth = JSON.parse(truthBytes);
assert.equal(truth.protocol,fresh?'ears-real-vector-fresh-truth/1':'ears-real-vector-truth/1'); assert.equal(sha(manifestBytes),truth.manifestSha256);
const corpus = readFileSync(join(corpusPath,'corpus.f32')), queries = readFileSync(join(corpusPath,'queries.f32'));
assert.equal(sha(corpus),manifest.files['corpus.f32'].sha256); assert.equal(sha(queries),manifest.files['queries.f32'].sha256);
const bytes = 1536*4, vector = i => Array.from(new Float32Array(corpus.buffer,corpus.byteOffset+i*bytes,1536));
const queryOrdinals=Array.from({length:100},(_,j)=>499+999*j);
const excluded=new Set(fresh?truth.excludedOrdinals:[]);
if(fresh) {
  assert.deepEqual(truth.queryOrdinals,queryOrdinals);
  const heldOut=new Set(queryOrdinals),expected=new Set(queryOrdinals);
  for(let i=7;i<99900;i+=100)if(heldOut.has((i+31337)%99900))expected.add(i);
  assert.deepEqual([...excluded].sort((a,b)=>a-b),[...expected].sort((a,b)=>a-b));
  const projected=Buffer.concat(queryOrdinals.map(i=>corpus.subarray(i*bytes,(i+1)*bytes)));
  assert.equal(sha(projected),truth.queriesSha256);
  assert.equal(sha(Buffer.from(Uint32Array.from([...excluded].sort((a,b)=>a-b)).buffer)),truth.exclusionsSha256);
}
const queryVectors = Array.from({length:100},(_,q)=>fresh?vector(queryOrdinals[q]):Array.from(new Float32Array(queries.buffer,queries.byteOffset+q*bytes,1536)));
const path=process.env.EARS_MATRIX_ROOT;assert(path&&existsSync(path));
const snapshot='/electron/.temp/ears-query-attribution-retained';
const fileSha=file=>{const h=createHash('sha256'),fd=openSync(file,'r'),b=Buffer.allocUnsafe(1024*1024);try{for(;;){const n=readSync(fd,b,0,b.length,null);if(!n)break;h.update(b.subarray(0,n));}return h.digest('hex');}finally{closeSync(fd);}};
const retainedSha=fileSha(join(snapshot,'data.sqlite3'));assert.equal(retainedSha,'4e7b922650edb9bacefdda9fcb9b0c5a04f91e5919510c1b03d0b6f1971de935');
let report = {protocol:'ears-integrated-real-vector/1',qualification:false,source:process.env.EARS_TEST_SOURCE,
  size,diagnostic,partition:fresh?'fresh':'original',native:fresh,
  querySha256:fresh?truth.queriesSha256:manifest.files['queries.f32'].sha256,exclusionsSha256:fresh?truth.exclusionsSha256:null,truthSha256:sha(truthBytes),manifestSha256:sha(manifestBytes),node:process.version,arch:process.arch,
  platform:process.platform,batches:{create:128,embed:64,update:64},cohorts:[]};
const save = () => writeFileSync(output,JSON.stringify(rootReport??report,null,2)+'\n');
const pct = (values,p) => [...values].sort((a,b)=>a-b)[Math.max(0,Math.ceil(values.length*p)-1)] ?? null;
const summary = values => ({count:values.length,p50:pct(values,.5),p95:pct(values,.95),p99:pct(values,.99),max:Math.max(...values)});
const files = () => Object.fromEntries(readdirSync(path).map(name=>[name,statSync(join(path,name)).size]));
let db,models,nativeCalls=0,rootReport;
try {
  db = new SqliteDatabase({path,schema:toElmdbSchema({types:{Row:{required:[],...(fresh?{indexes:['prefix1000','prefix10000','scope10','scope1']}:{}),embed:{from:['title'],model:'public-fixture',dims:1536,chunk:'whole'}}},relations:{},roles:[]})});
  if(fresh)new SqliteVectorIndex(db,process.env.EARS_VEC1_EXTENSION);
  let e = createEarsEngine({database:db}); const ids=[], updates=[];
  report.sqlite = db.get('SELECT sqlite_version() v').v; report.sqliteVec = db.get('SELECT vec_version() v').v;
  report.loadedNative = loadedNativeBindings([getLoadablePath(),...(fresh?[process.env.EARS_VEC1_EXTENSION]:[])]);
  report.cacheKiB = -db.sql.pragma('cache_size',{simple:true});
  report.synchronous = db.sql.pragma('synchronous',{simple:true});
  if(fresh)assert.equal(report.synchronous,2,'Fresh validation requires FULL durability');
  let started = performance.now();
  for(let offset=0;offset<size;offset+=128) e.transact(()=>{
    for(let i=offset;i<Math.min(size,offset+128);i++) ids.push(e.create('Row',{id:`Row-${String(i).padStart(6,'0')}`,title:`row ${i}`,...(fresh?{prefix1000:i<1000,prefix10000:i<10000,scope10:i%100<10,scope1:i%100<1}:{})}).id());
  });
  report.createMs = performance.now()-started; save(); started=performance.now();
  let stored=0;
  for(;;) {
    const pending=e.pendingEmbeddings('Row',{limit:64});
    if(!pending.count) break;
    assert(pending.chunks.length>0);
    const batch=pending.chunks.map(chunk=>{
      const ordinal=Number(chunk.id.slice(4)); assert(ordinal>=0&&ordinal<size);
      if(ordinal%100===7) updates.push({...chunk,model:pending.model,ordinal});
      return {...chunk,model:pending.model,vector:vector(ordinal)};
    });
    assert.equal(e.embed(batch).stored,batch.length); stored+=batch.length;
    if(stored%4096===0) console.log(JSON.stringify({stage:'embed',stored}));
  }
  assert.equal(stored,size); report.embedMs=performance.now()-started;
  e.transact(()=>{for(let i=0;i<size;i++)if(i%97===0||excluded.has(i))e.write(ids[i]).trash();});
  function canonicalHash(updated) {
    const actual=createHash('sha256'), expected=createHash('sha256'); let count=0;
    for(const row of db.statement('SELECT v.embedding FROM embedding_values v JOIN entities e ON e.id=v.entity_id ORDER BY e.seq,v.chunk').iterate()) {
      actual.update(row.embedding);
      const index=updated&&count%100===7?(count+31337)%99900:count;
      expected.update(corpus.subarray(index*bytes,(index+1)*bytes));count++;
    }
    assert.equal(count,size); assert.equal(actual.digest('hex'),expected.digest('hex'));
    return count;
  }
  report.initialCanonicalRowsVerified=canonicalHash(false); report.filesAfterLoad=files(); save();

  rootReport=report; rootReport.protocol='ears-supported-large-blocks/1';rootReport.qualification=false;
  const job=db.indexBuilds.jobs().find(job=>job.type==='Row'&&job.kind==='vector');assert(job);
  const retained=new SqliteDatabase({path:snapshot,readOnly:true,nativeVectorExtension:process.env.EARS_VEC1_EXTENSION});
  assert.equal(retained.sql.readonly,true);
  let trained;
  try {
    const state=retained.get("SELECT id,model_sha256 FROM vector_indexes WHERE state='ready'");assert(state&&Number.isSafeInteger(state.id));
    const model=retained.get(`SELECT val FROM ann_${state.id}_model WHERE id=1`).val;
    assert.equal(sha(model),state.model_sha256);assert.equal(sha(model),'5f90eea4ed59a1d018753a4f80e29ce58a40aec9c823382cdc051abce7a823b6');
    trained={model:Buffer.from(model),modelSha256:sha(model)};
  } finally {retained.close();}
  rootReport.model={sha256:trained.modelSha256,origin:'read-only retained prior owner model; no retraining'};
  rootReport.retainedSnapshotSha256=retainedSha;
  const base=join(path,'base');db.backup(base);db.close();db=undefined;
  writeFileSync(join(path,'model.bin'),trained.model,{flag:'wx'});
  const prepared={...rootReport,job,canonicalBaseSha256:fileSha(join(base,'data.sqlite3'))};
  writeFileSync(join(path,'prepared.json'),JSON.stringify(prepared,null,2)+'\n',{flag:'wx'});
  rootReport.preparedBaseSha256=prepared.canonicalBaseSha256;
  rootReport.retainedSnapshotUnchanged=fileSha(join(snapshot,'data.sqlite3'))===retainedSha;assert(rootReport.retainedSnapshotUnchanged);
  for(const name of ['data.sqlite3','data.sqlite3-wal','data.sqlite3-shm'])if(existsSync(join(path,name)))rmSync(join(path,name));
  rootReport.completed=true;save();
}catch(error){(rootReport??report).failure={message:error.message,stack:error.stack};save();throw error;}
finally{db?.close();}
