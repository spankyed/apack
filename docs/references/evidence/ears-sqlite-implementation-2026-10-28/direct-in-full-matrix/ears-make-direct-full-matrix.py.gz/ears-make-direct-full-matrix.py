from pathlib import Path
import json,hashlib,subprocess
r=Path('/private/tmp/ears-sqlite-query-integration');s=Path('/private/tmp/ears-large-block-study.mjs').read_text();o=Path('/private/tmp/ears-direct-full-results');assert not Path('/private/tmp/ears-direct-full.cid').exists();o.mkdir(exist_ok=True);assert not (o/'run.json').exists()
# Reuse sealed corpus/truth checks, canonical verification, the original admission loop and complete query matrix.
cut=s.index('  const common={...rootReport};rootReport.variants=[];')
producer=s[:cut].replace("const path = mkdtempSync('/electron/.temp/ears-large-block-');", "const path=process.env.EARS_MATRIX_ROOT;assert(path&&existsSync(path));")
producer+='''  writeFileSync(join(path,'model.bin'),trained.model,{flag:'wx'});
  const prepared={...rootReport,job,canonicalBaseSha256:fileSha(join(base,'data.sqlite3'))};
  writeFileSync(join(path,'prepared.json'),JSON.stringify(prepared,null,2)+'\\n',{flag:'wx'});
  rootReport.preparedBaseSha256=prepared.canonicalBaseSha256;
  rootReport.retainedSnapshotUnchanged=fileSha(join(snapshot,'data.sqlite3'))===retainedSha;assert(rootReport.retainedSnapshotUnchanged);
  for(const name of ['data.sqlite3','data.sqlite3-wal','data.sqlite3-shm'])if(existsSync(join(path,name)))rmSync(join(path,name));
  rootReport.completed=true;save();
}catch(error){(rootReport??report).failure={message:error.message,stack:error.stack};save();throw error;}
finally{db?.close();}
'''
producer=producer.replace(r"+'\\n'",r"+'\n'")
header=s[:s.index('try {\n  db = new SqliteDatabase')]
header=header.replace("const path = mkdtempSync('/electron/.temp/ears-large-block-');", "const matrixRoot=process.env.EARS_MATRIX_ROOT;assert(matrixRoot&&existsSync(matrixRoot));\nconst path=mkdtempSync(join(matrixRoot,'consumer-'));")
a=s.index('  function canonicalHash(updated)');b=s.index('  report.initialCanonicalRowsVerified=',a);canonical=s[a:b]
a=s.index('  // Each configuration starts');b=s.index('  report=rootReport;report.unchangedRetainedSnapshotSha256=',a);matrix=s[a:b]
matrix=matrix.replace('for(const minimum of [16384,65536,262144])','for(const minimum of [16384])')
matrix=matrix.replace("copyFileSync(join(base,'data.sqlite3'),join(candidate,'data.sqlite3'));", "copyFileSync(join(base,'data.sqlite3'),join(candidate,'data.sqlite3'));assert.equal(fileSha(join(candidate,'data.sqlite3')),prepared.canonicalBaseSha256);")
matrix=matrix.replace('report={...common,minimum,cohorts:', "report={...common,library:process.env.EARS_MATRIX_LIBRARY,loadedNative:loadedNativeBindings([getLoadablePath(),process.env.EARS_VEC1_EXTENSION]),minimum,cohorts:")
consumer=header+'''try {
  const prepared=JSON.parse(readFileSync(join(matrixRoot,'prepared.json'),'utf8')),base=join(matrixRoot,'base');
  assert.equal(fileSha(join(base,'data.sqlite3')),prepared.canonicalBaseSha256);
  const trained={model:readFileSync(join(matrixRoot,'model.bin')),modelSha256:prepared.model.sha256};assert.equal(sha(trained.model),trained.modelSha256);
  db=new SqliteDatabase({path:base,readOnly:true,nativeVectorExtension:process.env.EARS_VEC1_EXTENSION});assert.equal(db.sql.readonly,true);
  const job=prepared.job,current=db.indexBuilds.index(job.type,job.kind,job.name);assert.equal(current.generation,job.generation);assert.deepEqual(current.definition,job.definition);
  const ids=db.all('SELECT id FROM entities WHERE type=? ORDER BY seq',['Row']).map(row=>row.id);assert.equal(ids.length,size);
  const updates=db.all("SELECT entity_id id,chunk,hash,model FROM chunks WHERE generation=? AND CAST(substr(entity_id,5) AS INTEGER)%100=7 ORDER BY entity_id,chunk",[job.generation]).map(row=>({...row,ordinal:Number(row.id.slice(4))}));assert.equal(updates.length,999);assert(updates.every(row=>row.chunk===0));
  db.close();db=undefined;let e,started;
  rootReport={...prepared,source:process.env.EARS_TEST_SOURCE,protocol:'ears-direct-in-full-matrix/1',qualification:false,variants:[]};delete rootReport.job;
  const common={...rootReport};delete common.variants;
'''+canonical+matrix+'''  report=rootReport;
  report.unchangedBaseSha256=fileSha(join(base,'data.sqlite3'));assert.equal(report.unchangedBaseSha256,prepared.canonicalBaseSha256);
  report.unchangedRetainedSnapshotSha256=fileSha(join(snapshot,'data.sqlite3'));assert.equal(report.unchangedRetainedSnapshotSha256,retainedSha);
  report.completed=true;save();
}catch(error){(rootReport??report).failure={message:error.message,stack:error.stack};save();throw error;}
finally{db?.close();rmSync(path,{recursive:true,force:true});}
'''
for name,text in [('ears-direct-full-producer.mjs',producer),('ears-direct-full-consumer.mjs',consumer)]:Path('/private/tmp',name).write_text(text)
prior=json.loads(Path('/private/tmp/ears-direct-in-results/run.json').read_text());assert prior['completed']
files=subprocess.check_output(['git','ls-files','packages/apack-ears/src','native/vectors'],cwd=r,text=True).splitlines();inputs={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in files};(o/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
meta={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'qualification':False,'producerSha256':hashlib.sha256(producer.encode()).hexdigest(),'consumerSha256':hashlib.sha256(consumer.encode()).hexdigest(),'variants':[{k:v[k] for k in ['label','extension','extensionSha256','sourceSha256']} for v in prior['variants']],'modelSha256':'5f90eea4ed59a1d018753a4f80e29ce58a40aec9c823382cdc051abce7a823b6','matrix':'two separate Node processes, one identical closed initial base/model; each18cohorts4passes100queries, total14400queries','budgets':'unchanged recall>=.95 heartbeatp99<=16ms diagnosticlatencyp95100/200ms, FULL/defaultcheckpoints/16KiB minimum','scope':'direct physical admission, not app-owned scheduler/fresh model training acceptance','preserveBase':True};(o/'source.json').write_text(json.dumps(meta,indent=2)+'\n')
print('Prepared shared-base/separate-process full matrix; production C unchanged')
