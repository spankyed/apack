from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
r=Path('/electron');o=Path('/results');meta=json.loads((o/'source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
scripts={}
for kind in ['producer','consumer']:
 p=r/('packages/apack-ears/bench/sqlite/direct-full-'+kind+'.mjs');assert not p.exists();shutil.copyfile('/'+kind+'.mjs',p);assert sha(p)==meta[kind+'Sha256'];subprocess.run(['node','--check',str(p)],check=True);scripts[kind]=p
limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'}
work=r/'.temp/ears-direct-full-matrix';work.mkdir(mode=0o700,exist_ok=False)
packaged=r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so';before=sha(packaged)
for v in meta['variants']:assert sha(Path(v['extension']))==v['extensionSha256']
report={'source':meta['source'],'qualification':False,'limits':limits,'separateNodeProcesses':True,'workRoot':str(work),'steps':[]};started=time.time()
def run(kind,label,extension):
 output=o/(label+'.json');args=['node','--import','tsx',str(scripts[kind]),'/corpus','/truth/truth.json','99900',str(output),'native-fresh']
 env={**os.environ,'EARS_TEST_SOURCE':meta['source'],'EARS_VEC1_EXTENSION':extension,'EARS_MATRIX_ROOT':str(work),'EARS_MATRIX_LIBRARY':label};at=time.time()
 with(o/(label+'.log')).open('w') as f:p=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['steps'].append({'label':label,'args':args,'extension':extension,'startedWallMs':at*1000,'endedWallMs':time.time()*1000,'exitCode':p.returncode})
 assert p.returncode==0,(o/(label+'.log')).read_text()[-6000:]
 d=json.loads(output.read_text());assert d['completed'] and not d.get('failure');return d
try:
 prepared=run('producer','prepared',meta['variants'][0]['extension']);assert prepared['model']['sha256']==meta['modelSha256'];print('Shared initialbase/model prepared; original snapshot unchanged',flush=True)
 reports=[]
 for variant in meta['variants']:
  d=run('consumer',variant['label'],variant['extension']);v=d['variants'][0]
  assert len(d['variants'])==1 and v['canonicalRowsVerified']==99900 and v['updatedCanonicalRowsVerified']==99900 and v['modelSha256']==meta['modelSha256']
  assert len(v['cohorts'])==18 and all(len(c['passes'])==4 and all(len(p['samples'])==100 for p in c['passes']) for c in v['cohorts'])
  assert d['unchangedBaseSha256']==prepared['preparedBaseSha256'];reports.append(v);print(variant['label'],'complete 7200 queries canonicalverified frozenGates',v['frozenGatesPassed'],flush=True)
 pairs=0
 for bc,dc in zip(reports[0]['cohorts'],reports[1]['cohorts']):
  assert (bc['phase'],bc['size'],bc['scopePercent'])==(dc['phase'],dc['size'],dc['scopePercent'])
  for bp,dp in zip(bc['passes'],dc['passes']):
   assert bp['nativeCandidateCalls']==dp['nativeCandidateCalls']
   for b,d in zip(bp['samples'],dp['samples']):
    assert (b['ordinals'],b['scores'])==(d['ordinals'],d['scores']),(bc['phase'],bc['size'],bc['scopePercent'],b['q']);pairs+=1
 assert pairs==7200;report['identicalOrderedAnswerPairs']=pairs;report['packagedArtifactUnchanged']=sha(packaged)==before;assert report['packagedArtifactUnchanged'];report['completed']=True
except BaseException as e:report['failure']={'message':str(e),'type':type(e).__name__};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
