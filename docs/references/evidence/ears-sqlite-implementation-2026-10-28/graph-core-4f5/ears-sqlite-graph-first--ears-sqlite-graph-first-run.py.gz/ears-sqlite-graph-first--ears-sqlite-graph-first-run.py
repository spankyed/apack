from pathlib import Path
import subprocess,json,os,hashlib
r=Path('/electron');o=Path('/results');report={'source':'4f57386fd3 plus graph request/projection/three algorithms WIP','scope':'Three selected new graph contracts; SQLite only, frozen a9 dependencies, no new-pin native qualification','steps':[]}
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_EVALUATION_BACKEND':'sqlite','EARS_VEC1_EXTENSION':'/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so'}
 commands=[('sqlite',['node','node_modules/vitest/vitest.mjs','run','--config','/electron/packages/apack-ears/vitest.config.ts','--root','/electron/packages/apack-ears','tests/engine/relations.spec.ts','--testNamePattern=rank orders|weakComponents groups|strongComponents groups','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile=/results/sqlite.json'])]
 for name,args in commands:
  env['EARS_EVALUATION_BACKEND']='' if name=='elmdb' else 'sqlite'
  with(o/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  report['steps'].append({'name':name,'exitCode':p.returncode});assert p.returncode==0,(name,(o/(name+'.log')).read_text()[-5000:]);print(name+' passed',flush=True)
 report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
