from pathlib import Path
import subprocess,time,json,os
root=Path('/private/tmp');task='ears-sqlite-graph-core';cid=root/(task+'.cid');out=root/(task+'-results')
assert not cid.exists(),'Inspect the existing run instead of restarting'
assert json.loads((root/'ears-native-zero-sign-matrix-results/run.json').read_text())['completed']
assert json.loads((root/'ears-seagate-sqlite-matrix-results/run.json').read_text())['completed']
assert(root/(task+'-run.py')).is_file()
(root/(task+'.pid')).write_text(str(os.getpid())+'\n');quiet=None;last=0
print('Matched sustained watch pilot: waiting30quietseconds; original data protected',flush=True)
while True:
 if(root/(task+'.stop')).exists():raise SystemExit('Stopped before admission')
 p=subprocess.run(['docker','ps','-q'],capture_output=True,text=True);now=time.monotonic()
 if p.returncode or p.stdout.strip():quiet=None
 elif quiet is None:quiet=now
 if now-last>=20:print(json.dumps({'pid':os.getpid(),'other':p.stdout.splitlines(),'quietSeconds':0 if quiet is None else round(now-quiet)}),flush=True);last=now
 if quiet is not None and now-quiet>=30:
  if subprocess.check_output(['docker','ps','-q'],text=True).strip():quiet=None;continue
  break
 time.sleep(2)
args=['docker', 'run', '--rm', '--cidfile', '/private/tmp/ears-sqlite-graph-core.cid', '--name', 'ears-sqlite-graph-core', '--cpus', '2', '--memory', '6g', '--memory-swap', '6g', '--cap-drop', 'ALL', '--network', 'none', '-v', 'ears-electron-runtime-work:/electron', '-v', '/private/tmp/ears-sqlite-graph-core-run.py:/run.py:ro', '-v', '/private/tmp/ears-sqlite-graph-core-results:/results', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/bench/watch-stress.ts:/electron/packages/apack-ears/bench/watch-stress.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/sqlite/database.ts:/electron/packages/apack-ears/src/sqlite/database.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/sqlite/field-query.ts:/electron/packages/apack-ears/src/sqlite/field-query.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/sqlite/numeric-order.ts:/electron/packages/apack-ears/src/sqlite/numeric-order.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/sqlite/query.ts:/electron/packages/apack-ears/src/sqlite/query.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/sqlite/scalar-groups.ts:/electron/packages/apack-ears/src/sqlite/scalar-groups.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/sqlite/value-groups.ts:/electron/packages/apack-ears/src/sqlite/value-groups.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/sqlite/vectors.ts:/electron/packages/apack-ears/src/sqlite/vectors.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/tests/engine/queries.spec.ts:/electron/packages/apack-ears/tests/engine/queries.spec.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/tests/sqlite/query-cost.spec.ts:/electron/packages/apack-ears/tests/sqlite/query-cost.spec.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/tests/sqlite/vector-models.spec.ts:/electron/packages/apack-ears/tests/sqlite/vector-models.spec.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/storage.ts:/electron/packages/apack-ears/src/storage.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/query.ts:/electron/packages/apack-ears/src/query.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/runtime.ts:/electron/packages/apack-ears/src/runtime.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/src/sqlite/graph-algorithms.ts:/electron/packages/apack-ears/src/sqlite/graph-algorithms.ts:ro', '-v', '/private/tmp/ears-sqlite-query-integration/packages/apack-ears/tests/engine/relations.spec.ts:/electron/packages/apack-ears/tests/engine/relations.spec.ts:ro', '-w', '/electron', 'apack-linux-test:74d4b8cfe839', 'python3', '/run.py']
(out/'host-launch.json').write_text(json.dumps({'args':args,'scope':'Read-only source/test mounts; fresh temporary fixture databases only; no benchmark data touched'},indent=2)+'\n')
p=subprocess.Popen(args);owned=None
while p.poll() is None:
 if owned is None and cid.exists():owned=cid.read_text().strip()
 if owned:
  state=subprocess.run(['docker','inspect',owned,'--format','{{json .State}}'],capture_output=True,text=True)
  if state.returncode==0:
   state=json.loads(state.stdout);others=[x for x in subprocess.check_output(['docker','ps','-q','--no-trunc'],text=True).splitlines() if x!=owned]
   action='pause' if others and not state['Paused'] else 'unpause' if not others and state['Paused'] else None
   if action:
    x=subprocess.run(['docker',action,owned],capture_output=True,text=True)
    with(out/'resource-watch.log').open('a') as f:f.write(json.dumps({'time':time.time(),'action':action,'others':others,'exitCode':x.returncode})+'\n')
 time.sleep(2)
raise SystemExit(p.returncode)
