from pathlib import Path
import subprocess,json,os,hashlib
r=Path('/electron');o=Path('/results');report={'source':'563ec93ed0 plus independent native Karate modularity regression','scope':'Full EARS typecheck; all relations, graph oracle, query/cost/storage-port cases on SQLite; pinned Leiden readonly package; no new-pin native qualification','steps':[]}
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_EVALUATION_BACKEND':'sqlite','EARS_VEC1_EXTENSION':'/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so'}
 commands=[('types',['node','node_modules/typescript/bin/tsc','-p','packages/apack-ears','--incremental','false']),('sqlite',['node','node_modules/vitest/vitest.mjs','run','--config','/electron/packages/apack-ears/vitest.config.ts','--root','/electron/packages/apack-ears','tests/engine/relations.spec.ts','tests/sqlite/graph-algorithms.spec.ts','tests/engine/queries.spec.ts','tests/engine/storage-port.spec.ts','tests/sqlite/query-cost.spec.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile=/results/sqlite.json'])]
 for name,args in commands:
  env['EARS_EVALUATION_BACKEND']='' if name=='elmdb' else 'sqlite'
  with(o/(name+'.log')).open('w') as log:p=subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  report['steps'].append({'name':name,'exitCode':p.returncode});assert p.returncode==0,(name,(o/(name+'.log')).read_text()[-5000:]);print(name+' passed',flush=True)
 report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
