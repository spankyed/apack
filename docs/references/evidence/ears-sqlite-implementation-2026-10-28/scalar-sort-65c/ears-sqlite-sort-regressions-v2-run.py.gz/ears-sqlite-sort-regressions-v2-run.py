from pathlib import Path
import subprocess,json,os,hashlib,time
r=Path('/electron');o=Path('/results');report={'source':'working numeric-order fix after7b315e4c5a','scope':'Two current source/test files mounted read-only over frozen a9 dependencies; focused regressions only'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_EVALUATION_BACKEND':'sqlite','EARS_VEC1_EXTENSION':'/electron/packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so'}
 args=['node','/electron/node_modules/vitest/vitest.mjs','run','tests/sqlite/query-cost.spec.ts','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile=/results/tests.json']
 with(o/'test.log').open('w') as log:p=subprocess.run(args,cwd=r/'packages/apack-ears',env=env,stdout=log,stderr=subprocess.STDOUT)
 report['exitCode']=p.returncode
 if p.returncode:print((o/'test.log').read_text()[-6000:],flush=True)
 if p.returncode==0:
  with(o/'profile.log').open('w') as log:q=subprocess.run(['node','--import','tsx','/probe.mjs'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
  report['profileExitCode']=q.returncode;assert q.returncode==0,(o/'profile.log').read_text()[-3000:]
 report['completed']=True
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(report['exitCode'])
