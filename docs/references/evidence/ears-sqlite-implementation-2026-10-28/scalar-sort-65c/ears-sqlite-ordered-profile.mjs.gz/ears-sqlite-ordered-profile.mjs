import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {createEarsEngine} from '/electron/packages/apack-ears/src/index.ts';
import {SqliteDatabase} from '/electron/packages/apack-ears/src/sqlite/database.ts';
import {toElmdbSchema} from '/electron/packages/apack-ears/src/schema.ts';
const report={source:'a9c9340df74f90b85434e8ddafa9742bd6867cbf',qualification:false,cases:[]};
for(const size of [1000,5000,20000]){
 const path=mkdtempSync(join(tmpdir(),'ears-ordered-profile-'));
 const db=new SqliteDatabase({path,syncs:false,schema:toElmdbSchema({types:{Task:{required:[],indexes:['status']}},relations:{},roles:[]})});
 try{
  const e=createEarsEngine({database:db});e.admin.bulkLoad(()=>{for(let i=0;i<size;i++){
   const id='Task-'+String(i).padStart(5,'0');e.admin.bulkLoadAttr(id,'title','Task '+i);e.admin.bulkLoadAttr(id,'status',['open','done','blocked'][i%3]);e.admin.bulkLoadAttr(id,'rank',i);
  }});await db.indexesReady();
  const records=[],methods={all:db.all,get:db.get};
  for(const method of ['all','get'])db[method]=function(sql,parameters=[]){
   const at=performance.now(),value=methods[method].call(this,sql,parameters),ms=performance.now()-at;
   records.push({method,sql,ms,parameters:parameters.map(p=>typeof p==='string'&&p.length>200?{length:p.length,sha256:createHash('sha256').update(p).digest('hex')}:p),rows:Array.isArray(value)?value.length:value?1:0,plan:methods.all.call(this,'EXPLAIN QUERY PLAN '+sql,parameters)});return value;
  };
  const at=performance.now(),rows=e.query('Task').where('status','open').orderBy('rank').pick(['rank']),ms=performance.now()-at;
  assert.equal(rows.length,Math.ceil(size/3));assert(rows.every((r,i)=>r.rank===i*3));report.cases.push({size,ms,records});
  db.all=methods.all;db.get=methods.get;writeFileSync('/results/probe.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({size,ms,slowest:[...records].sort((a,b)=>b.ms-a.ms).slice(0,3).map(s=>({ms:s.ms,sql:s.sql.slice(0,90)}))}));
 }finally{db.close();rmSync(path,{recursive:true,force:true});}
}
report.completed=true;writeFileSync('/results/probe.json',JSON.stringify(report,null,2)+'\n');
