from pathlib import Path
import subprocess,json,hashlib,os,shutil,time
r=Path('/electron');o=Path('/results');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'source':'45180293a3248ea7ec364672fb294ed1f322fc9c','baselineRuntimeSource':'1d7a3de090d74028ca36eba574686da8c794609a','prototype':{},'steps':[],'qualification':False}
def run(label,args,backend='sqlite',expected=0,timeout=600):
 env={**os.environ,'EARS_EVALUATION_BACKEND':backend,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096'}
 at=time.monotonic()
 with (o/(label+'.log')).open('w') as f:p=subprocess.run(args,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 report['steps'].append({'label':label,'exitCode':p.returncode,'seconds':time.monotonic()-at});(o/'run.json').write_text(json.dumps(report,indent=2));print(label,p.returncode,flush=True)
 assert p.returncode==expected,label
 return p
try:
 limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'};report['limits']=limits
 for n,h in json.loads(Path('/expected/inputs.json').read_text()).items():assert sha(r/n)==h,n
 binding=r/'vendor/elmdb/crates/elmdb-node/elmdb.linux-arm64-gnu.node'
 report['bindingSha256']=sha(binding);assert report['bindingSha256']=='5d813c95e373c79f36c47889c75b0491b8987c7cc6f9669f4428e4dd69a27687','Normal package native binding does not match pinned2441; refuse control'
 for rel in ['tests/fixtures/search-relevance.json']:
  shutil.copyfile(Path('/prototype')/rel,r/'packages/apack-ears'/rel)
 base=['node','node_modules/vitest/vitest.mjs','run','--root','packages/apack-ears','--maxWorkers=2','--reporter=default','--reporter=json']
 test='tests/engine/search-relevance.spec.ts'
 run('native-gold',base+[test,'--outputFile=/results/native-gold.json'],backend='lmdb')
 run('sqlite-before',base+[test,'--outputFile=/results/sqlite-before.json'],expected=1)
 before=json.loads((o/'sqlite-before.json').read_text());assert before['numFailedTests']==2 and before['numPassedTests']==34,before
 for rel in ['src/sqlite/text.ts','tests/sqlite/text-typos.spec.ts']:
  p=Path('/prototype')/rel;report['prototype'][rel]=sha(p);shutil.copyfile(p,r/'packages/apack-ears'/rel)
 run('lint',['node','node_modules/oxlint/bin/oxlint','packages/apack-ears/src/sqlite/text.ts','packages/apack-ears/tests/sqlite/text-typos.spec.ts','-D','correctness'])
 run('types',['node','node_modules/typescript/bin/tsc','-p','packages/apack-ears','--noEmit','--incremental','false'])
 run('packages-build',['npm','run','packages:build'])
 run('sqlite-contracts',base+['--outputFile=/results/sqlite-contracts.json'])
 env={**os.environ,'EARS_COST_SOURCE':report['source']+'+prefix-prototype'};env.pop('NODE_OPTIONS',None)
 with (o/'growth.log').open('w') as f:p=subprocess.run(['node','/cost.mjs',str(o/'growth.json')],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 report['steps'].append({'label':'prefix-growth','exitCode':p.returncode});assert p.returncode==0,'growth'
 report['completed']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:(o/'run.json').write_text(json.dumps(report,indent=2)+'\n')
