from pathlib import Path
import hashlib,json,subprocess,os,shutil,time
r=Path('/electron');o=Path('/results');meta=json.loads((o/'source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=r/'packages/apack-ears/bench/sqlite/seagate-sqlite-matrix.mjs';started=time.time();report={'source':meta['source'],'qualification':False}
try:
 for n,h in json.loads((o/'inputs.json').read_text()).items():assert sha(r/n)==h,n
 limits={n:Path('/sys/fs/cgroup',n).read_text().strip() for n in ['cpu.max','memory.max','memory.swap.max']};assert limits=={'cpu.max':'200000 100000','memory.max':'6442450944','memory.swap.max':'0'};report['limits']=limits
 assert shutil.disk_usage(r/'.temp').free>=8*1024**3
 extension=r/'packages/apack-ears/dist/sqlite/native/linux-arm64/vec1.so';before=sha(extension);assert before=='b16f6c4fcd84c776c1c3e1d3f2df33a5229dc987a1b8fd3b7d0343683fc10fd0'
 assert not p.exists();shutil.copyfile('/probe.mjs',p);assert sha(p)==meta['probeSha256']
 work=r/'.temp/ears-seagate-sqlite-matrix';work.mkdir(mode=0o700,exist_ok=False)
 env={**os.environ,'NODE_OPTIONS':'--conditions=@apackdev/source --max-old-space-size=4096','EARS_TEST_SOURCE':meta['source'],'EARS_MATRIX_ROOT':str(work),'EARS_VEC1_EXTENSION':str(extension),'EARS_MATRIX_LIBRARY':'normal-packaged-compact-IN'}
 with(o/'probe.log').open('w') as log:result=subprocess.run(['node','--import','tsx',str(p),'/corpus','/truth/truth.json','99900',str(o/'probe.json'),'native-fresh'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 report['exitCode']=result.returncode;assert result.returncode==0,(o/'probe.log').read_text()[-6000:]
 d=json.loads((o/'probe.json').read_text());assert d['completed'] and not d.get('failure');assert len(d['variants'])==1
 v=d['variants'][0];assert v['canonicalRowsVerified']==v['updatedCanonicalRowsVerified']==99900;assert len(v['cohorts'])==18;assert all(len(c['passes'])==4 and all(len(p['samples'])==100 for p in c['passes']) for c in v['cohorts']);assert sha(extension)==before
 report['completed']=True;report['frozenGatesPassed']=v['frozenGatesPassed'];report['packagedArtifactUnchanged']=True
except BaseException as e:report['failure']={'type':type(e).__name__,'message':str(e)};raise
finally:report['seconds']=time.time()-started;(o/'run.json').write_text(json.dumps(report,indent=2)+'\n');p.unlink(missing_ok=True)
