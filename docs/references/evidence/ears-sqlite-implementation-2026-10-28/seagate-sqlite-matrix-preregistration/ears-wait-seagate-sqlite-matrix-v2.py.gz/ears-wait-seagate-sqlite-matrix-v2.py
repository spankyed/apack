from pathlib import Path
import subprocess,time,os,json
cid=Path('/private/tmp/ears-seagate-sqlite-matrix.cid');assert not cid.exists(),'A query policy run has already been created; inspect it instead'
Path('/private/tmp/ears-seagate-sqlite-matrix-admission.pid').write_text(str(os.getpid())+'\n')
nativeResult=Path('/private/tmp/ears-native-zero-sign-matrix-results/run.json')
quiet=None;last=0
print('Waiting for 30 seconds with no running containers before admitting the preregistered matched SQLite matrix after native completion',flush=True)
while True:
 if Path('/private/tmp/ears-seagate-sqlite-matrix-admission.stop').exists():raise SystemExit('Admission stopped before container creation')
 p=subprocess.run(['docker','ps','-q'],capture_output=True,text=True)
 now=time.monotonic()
 if nativeResult.exists():
  native=json.loads(nativeResult.read_text());assert native.get('completed') and not native.get('failure'),'Native run terminal failure: inspect before candidate admission'
 if not nativeResult.exists() or p.returncode or p.stdout.strip():quiet=None
 elif quiet is None:quiet=now
 if now-last>=20:
  print(json.dumps({'pid':os.getpid(),'otherContainers':p.stdout.splitlines(),'quietSeconds':0 if quiet is None else round(now-quiet),'dockerExitCode':p.returncode,'dockerError':p.stderr.strip()[:240]}),flush=True);last=now
 if quiet is not None and now-quiet>=30:
  p=subprocess.run(['python3','/private/tmp/ears-run-seagate-sqlite-matrix.py'])
  if cid.exists():raise SystemExit(p.returncode) # A started run is never restarted by this admission watcher.
  if p.returncode==0:raise SystemExit('Runner exited without creating its expected container')
  if p.returncode!=75:raise SystemExit('Launcher refused before admission; inspect instead of retrying: '+str(p.returncode))
  quiet=None # Only an explicit competing-container refusal may return to quiet admission.
 time.sleep(2)
